# Fantasy Life RPG — Lobi Kota Fantasi 3D (Godot 4.3, GDScript)

Prototipe RPG Android landscape: lobi kota fantasi 3D bergaya anime yang bisa dijelajahi, menu lengkap,
dialog NPC, dan fondasi petualangan (pilih stage → party → pertarungan → hasil → kembali ke lobi).
Seluruh aset (model, tekstur, ikon, suara, UI) dibuat sendiri lewat kode/skrip di proyek ini — tidak ada
aset berhak cipta dari game lain. Nuansa lobi terinspirasi umum dari game gacha-RPG, tetapi karakter,
peta, nama, dan UI semuanya orisinal.

## Cara membuka & menjalankan
1. Pasang **Godot 4.3** (atau 4.3+ stabil) — versi *Standard* (GDScript), bukan .NET.
2. Ekstrak ZIP, buka Godot → **Import** → pilih `project.godot`.
3. Tunggu impor aset pertama kali selesai, lalu tekan **F5** (scene utama: `scenes/title.tscn`).
4. Renderer: **GL Compatibility** (sudah diatur) supaya ringan di Android.

### Godot Android Editor (di HP)
1. Pasang Godot 4.3 Android Editor, salin folder proyek ke penyimpanan HP, lalu **Import** `project.godot`.
2. Jalankan langsung dengan tombol ▶ (editor Android dapat menjalankan proyek di perangkat yang sama).
3. Ekspor APK: *Project → Export → Android*. Preset sudah ada (`export_presets.cfg`, arm64-v8a,
   paket `com.fantasylife.rpg.lobby`). Isi keystore debug jika diminta (atau matikan *Signed*), lalu *Export Project*.
   Jika templat ekspor belum ada, editor akan menawarkan untuk mengunduhnya.

> Catatan jujur: proyek ini **belum pernah diekspor ke APK / dijalankan di perangkat Android** oleh saya.
> Pengujian dilakukan di Linux (headless + layar virtual). Performa di HP nyata belum diukur.

## Kontrol
| Aksi | Sentuh (Android) | Keyboard | Gamepad |
|---|---|---|---|
| Gerak (8 arah) | Joystick kiri (melayang/tetap, diatur di Pengaturan) | WASD / panah | Stik kiri |
| Serang | Tombol kanan-bawah | J / Spasi | X |
| Skill | Tombol biru | K | Y |
| Hindar (dodge) | Tombol hijau | L / Shift | B |
| Interaksi / bicara | Tombol kuning (menyala bila ada target) | E / F | A |
| Kamera | Seret layar di luar kontrol (putar), cubit (zoom) | Q / R | – |
| Ganti karakter (di stage) | Ketuk kartu karakter di kiri-atas | 1–4 | – |
| Kembali / jeda | Tombol Back Android | Esc | Start |

Mode tangan kidal, ukuran tombol, ukuran/opasitas joystick, getar, dan grafis ada di **Pengaturan**.

## Isi game
- **Lobi "Aurelia"**: plaza dengan air mancur, guild, portal, toko senjata/armor, toko ramuan, pandai besi,
  area quest/NPC, rumah, taman, jalan, gerbang kota, area party. Siklus siang-malam.
- **Karakter utama** model blok-anime (bukan kapsul) dengan animasi Idle/Walk/Run/Turn/Attack/Skill/Damage/Death.
- **NPC (8 + 4 warga berjalan)**: Orwen (Guild Master), Rowan (Pedagang), Mira (Ramuan), Tobias (Pandai Besi),
  Selin (Info), Kael (Party), Elio (Penjaga Gerbang), Pip (Pendeta); dialog bercabang.
- **UI**: profil + Lv, HP, gold, diamond; tombol Character, Party, Inventory, Equipment, Quest, Gacha, Shop,
  Settings, Start Adventure — semuanya membuka panel yang berfungsi.
- **Petualangan**: pilih stage (5 stage: padang, hutan, gua, bos Golem Kristal, dan bos baru Penguasa Gua di arena "Sarang Penguasa Gua"), pilih/atur party,
  gelombang monster (slime, kelelawar, jamur, 2 bos masing-masing 2 fase), ramuan, jeda, layar hasil (menang/kalah,
  bintang 1–3, hadiah), kembali ke lobi. Progres tersimpan.
- **Sistem**: gacha (rate 2/10/28/30/30 %, pity 50, 10× menjamin ≥4★), tempa senjata, jual-beli, equipment,
  quest dengan klaim hadiah, simpan/muat (JSON di `user://`).

## Struktur folder
```
autoload/      Data, GameState (simpan/muat), Sfx, Flow (pindah scene + toast)
scenes/        title.tscn, lobby/lobby.tscn, stages/stage.tscn
scripts/
  lobby/       lobby.gd, lobby_world.gd, lobby_layout.gd, day_night.gd
  buildings/   bangunan prosedural
  characters/  rig, animasi, tampilan karakter
  player/ npc/ camera/ title/
  stages/      stage.gd, enemy.gd, arena.gd, fx, proyektil, HUD, hasil
  ui/          tema, ikon, HUD, dialog, kontrol sentuh, panel_host + panels/
  systems/     gacha, quality, mesh_kit, material dunia
resources/     data karakter, item, quest, stage (.tres)
shaders/       toon_flat.gdshader dll.
assets/        audio (dibuat skrip), tekstur, material, model
tools/         skrip uji/bot & pembuat aset (tidak ikut di APK)
```

## Status jujur
### Berfungsi (sudah diuji — hasil nyata, bukan perkiraan)
Diuji di Godot 4.3 Linux, headless / layar virtual (xvfb), renderer OpenGL3:
- `tools/test_data.tscn`: data 4 karakter, 33 item, 12 quest, 5 stage termuat — **LULUS**.
- `panel_bot`: klaim quest (+200 gold), beli senjata & ramuan, pasang equipment, tempa +1, party, gacha ×10
  (900 diamond, ≥4★) — semua pemeriksaan lulus.
- `stage_bot` (bot bermain otomatis): menang di s1_1, s1_2, s1_3, s1_boss, dan s2_boss; rekor tersimpan; jalur
  **kalah** (`--lose=1`) menampilkan layar KALAH dengan hadiah hiburan.
- `flow_bot`: lobi → Pilih Stage → Mulai → stage → hasil → "Kembali ke Lobi" → lobi — semua pemeriksaan lulus.
- Layar judul tampil dan berpindah ke lobi.
- Tangkapan layar lobi, HUD, dialog, panel, dan tiap tema stage sudah dilihat langsung.

### Lagu utama
`assets/audio/music_main.mp3` ("obsesius", dibuat pengguna dengan Suno, 3:25) dipakai sebagai lagu layar judul dan lobi, berulang otomatis.
Intro-nya sengaja sangat pelan (piano minimalis) sehingga detik-detik pertama terdengar nyaris sunyi; ini bukan bug. Bila gagal dimuat,
`sfx.gd` memakai `music_village`. Pastikan kamu berhak memakai lagu ini jika game dipublikasikan.

### Animasi kroco (slime, kelelawar, jamur)
Digerakkan kode di `enemy.gd` (`_animate_slime/_bat/_mushroom`): slime melompat dengan tekan-regang (squash & stretch) dan menekuk sebelum menerkam;
kelelawar mengangkat sayap saat aba-aba, merapatkannya saat menukik, dan miring saat mengitari; jamur bergoyang berjalan, menggembung bergetar,
lalu kempis setelah menyemprot spora. Semua punya kedutan saat terkena pukulan, "pop" saat muncul, dan kematian khas
(slime menguap, kelelawar jatuh berputar, jamur pecah). Dilihat lewat lembar kontak `tools/minion_sheet.gd` (rekaman potongan gambar per 0,14 s).
Belum dinilai: kenyamanan/kehalusan gerak di HP dan perasaan "juicy" oleh pemain sungguhan.

### Adventure Bab 2 dan tata kota
- Stage baru: 2-1 Lorong Bayangan (gua, Lv 8), 2-2 Jurang Bara (sarang, Lv 8), 2-3 Gerbang Sarang (sarang, Lv 9, 4 gelombang), lalu 2-B Penguasa Gua.
  Berurutan: tiap stage terbuka setelah yang sebelumnya selesai. Daftar Pilih Stage kini dikelompokkan per bab.
  Bot menang di 2-1 dan 2-2; 2-3 pernah dikalahkan bot pada versi pertama (terlalu berat) sehingga jumlah monster dikurangi; setelah itu bot menang di 2-3 (Lv 9).
- Lobi ditata ulang (`lobby_layout.gd`): jalan utama selatan-utara, bulevar timur-barat (kamp party di ujung barat, portal di ujung timur),
  dua jalan samping, bangunan selalu menghadap jalan, pohon berjajar di tepi jalan. Dilihat lewat foto atas (`tools/lobby_overview.gd`).
  NPC dipindah ke depan bangunannya dan menghadap jalan. Belum dijalani/diperiksa langsung dengan karakter di setiap sudut kota.

### Bos Penguasa Gua (stage 2-B, ditambahkan dari model GLB buatan pengguna)
- Model `assets/boss/cave_monster_rigged.glb` + `scripts/stages/monster_rig.gd` + `scenes/stages/monster_rig.tscn`
  (6 animasi: Idle, Walking, Attack, HitReaction, Death, Roar) dipasang sebagai musuh `cave_beast` di `enemy.gd`.
- Serangan: **Cakar** (area di depan), **Seruduk** (melesat lurus, lalu terengah), **Raungan** (gelombang kejut). Fase 2 di HP 50 %:
  lebih cepat, meraung, dan memanggil 2 kelelawar. Tiap serangan punya lingkaran peringatan merah/oranye.
- Arena baru bertema `lair` (`arena.gd`): lantai batu gelap, retakan bara menyala, stalagmit, kristal oranye. Stage `resources/stages/s2_boss.tres`
  (Lv rekomendasi 10, terbuka setelah 1-B).
- Sinkronisasi animasi (`enemy.gd`, `_animate_beast`): puncak gerakan klip (cakar menghantam di 0,6 s, raungan penuh di 1,0 s) disetel jatuh tepat
  saat serangan mengenai; klip tidak lagi dimulai ulang saat serangan; seruduk menahan pose bersiap lalu berlari; jalan memakai kecepatan klip 1,6×.
  Diukur otomatis oleh `tools/anim_check.gd` (selisih posisi klip < 0,2 s). Kaki masih sedikit "meluncur" saat bos berlari karena klip jalan
  dibuat untuk langkah lebih pendek dari kecepatan gerak bos.
- Suara bos (dibuat skrip `tools/gen_boss_audio.py`): raungan, geraman, desir cakar, benturan cakar, gemuruh seruduk, tabrakan,
  gelombang kejut, langkah berat (juga dipakai golem), kesakitan, kematian, plus musik `music_lair` untuk stage 2-B.
  Pengujian otomatis (`tools/sfx_probe.gd`) memastikan ke-10 efek benar-benar terpicu saat pertarungan dan musik yang terpasang `music_lair`.
  Bila file suara baru gagal dimuat, `autoload/sfx.gd` memakai suara lama sebagai cadangan (dan mencatat peringatan di log) supaya tidak senyap; suara bos panjang punya pemutar khusus agar tidak terpotong.
  **Saya tidak bisa mendengar hasilnya** — kualitas/keras-pelannya belum dinilai telinga manusia; volume per efek diatur di `enemy.gd` (`_sfx(...)`).
- Yang sudah dilihat langsung lewat tangkapan layar: bos muncul, tiap serangan (windup + strike), kena pukul, fase 2, dan mati.
  Bot menang di stage ini. **Belum** dinilai: keseimbangan dan kesesuaian waktu animasi dengan momen serangan oleh manusia
  (waktu serangan diset kira-kira; mungkin perlu disetel), serta performa model di HP.

### Karakter baru Zeya + bonus login 3 hari
- **Zeya** (Pendekar Bayangan, kelas Assassin): pedang, serangan arc cepat (jeda 0,32 dtk, jangkauan 2,4), skill "Tebasan Bayangan" (kerucut ×2,8, jeda 5,5 dtk), HP/ATK/DEF dasar 95/14/3, gerak 6,6.
  Hanya didapat dari bonus login (tidak ada di gacha). Skin dibuat `tools/gen_skins.py`, perlengkapan (jubah, ikat kepala, sabuk) di `character_looks.gd`.
- **Bonus login 3 hari**: tombol "Hadiah" di HUD kanan atas (titik merah bila ada hadiah) dan panel terbuka otomatis saat masuk lobi bila ada hadiah.
  Satu klaim per hari kalender (jam perangkat), tidak harus berturut-turut. Hari 1: 2.000 emas + 100 berlian + 3 Ramuan Kecil;
  hari 2: 3.000 emas + 200 berlian + 2 Ramuan Besar; hari 3: Zeya + 300 berlian. Progres tersimpan di file simpanan.
- Diuji (bot `tools/login_bot.gd`, tanggal dipalsukan lewat `--date`/`_fake_date`): ketiga hadiah diterima sesuai jumlah, klaim ganda di hari sama ditolak,
  jeda seminggu tetap bisa klaim, setelah selesai tidak bisa klaim lagi, Zeya terbuka dengan senjata awal, progres bertahan setelah simpan lalu muat ulang proses.
  Tampilan panel, tombol, dan model 3D Zeya dilihat lewat tangkapan layar.
- Belum diuji: pergantian tanggal nyata di HP (hanya tanggal palsu), perubahan jam perangkat/zona waktu (pemain bisa memajukan jam untuk klaim lebih cepat; tidak ada pengecekan server),
  dan Zeya dipakai bertarung di stage (tidak dijalankan khusus untuk Zeya).

### Animasi serang & skill berfase
- Semua animasi serang/skill (pedang ×2 kombo, tongkat, hantam Guardian, panah, dan skill tiap kelas) ditulis ulang dengan fase jelas:
  **antisipasi** (menarik/menggulung badan) → **ayunan cepat** (melewati target sedikit agar bertenaga) → **tahan/follow-through** → **pemulihan** ke siaga.
  Skill Guardian: jongkok → lompat → banting; skill penyihir: kumpulkan tenaga (badan naik) → hunjam; skill pedang: gulung badan → sapuan putar.
- Damage, efek tebasan, dan suara "swing" kini jatuh tepat di momen impak animasi (`AnimLibrary.IMPACT`), bukan waktu tetap. Karakter juga terdorong sedikit
  ke depan saat tebasan mengenai (mundur sedikit untuk tembakan), dan berkilau warna aksen saat mengumpulkan tenaga skill.
- Diuji (`tools/attack_sheet.gd`, waktu diperlambat): untuk 5 karakter × (serangan 1, serangan 2, skill) sinyal damage jatuh dalam 0,08 dtk dari waktu impak animasi
  (selisih terukur 0,00–0,02 dtk). Lembar frame tiap fase dilihat langsung untuk pedang dan hantam; bot stage 1-1 tetap menang 3 bintang.
- Belum dicoba: rasa/ritme animasi di tangan sungguhan (HP), dan efek lunge terhadap tabrakan di sudut sempit; kesan "kaku" bersifat subjektif — sesuaikan angka pose di `anim_library.gd` bila perlu.

### Efek skill Nova Bintang (Lyra)
- Saat Lyra mengumpulkan tenaga, **lingkaran sihir bintang** (cincin rune, heptagram, bintang segi lima) muncul di tanah di atas piringan biru gelap lembut,
  dua lapisannya berputar berlawanan arah dan bintang-bintang kecil naik. Tepat di momen damage, lingkaran berdenyut terang, dua cincin gelombang
  melebar, dan percikan bintang menyebar, lalu memudar. Tekstur dibuat prosedural oleh `tools/gen_magic_circle.py` (`assets/fx/magic_*.png`, orisinal).
- Diuji lewat `tools/nova_shots.gd` (stage 1-1, waktu diperlambat): tangkapan layar tiap fase dilihat langsung; denyut mengikuti waktu impak animasi (0,61 dtk).
  Efek ini hanya untuk skill bertipe `nova`; skill karakter lain belum diberi efek baru. Performa efek di HP belum diukur.

### Upacara gacha
- Tarikan kini diawali **lingkaran sihir** yang berputar mengumpulkan cahaya (warna mengikuti rarity terbaik: emas ★5, ungu ★4, biru lainnya), kilatan, lalu
  kartu hasil muncul **terbalik** dan dibuka satu per satu dengan efek membalik. ★4+ mendapat kilau partikel & suara khusus; ★5 ledakan emas + layar bergetar.
  Ketuk di mana saja untuk melewati. Setelah selesai ada tombol **OK** dan **Tarik lagi** (mengulang jumlah tarikan yang sama bila diamond cukup).
  Penghitung pity kini berupa bar dan teks "★5 pasti dalam N tarikan lagi". Peluang, harga, dan pity TIDAK diubah (tetap 2/10/28/30/30 %, pity 50).
- Diuji (`tools/gacha_bot.gd`, tarik 10× dengan pity 49): diamond berkurang 900, tarikan pertama ★5 dan pity ter-reset, 10 hasil, lewati lewat ketukan membuka semua kartu,
  tombol OK menutup, tarik 1×, "Tarik lagi" memulai tarikan baru; tangkapan layar tiap tahap dilihat langsung. `panel_bot` lama tetap dijalankan ulang.
- Belum diuji: ketukan jari asli di HP, dan kenyamanan tempo animasi (bisa disetel lewat angka waktu di `scripts/ui/gacha_reveal.gd`).

### Tanggal & jam dunia nyata
- Di tengah atas HUD lobi kini ada dua baris: "Jam kota HH:MM" (jam siang-malam dalam game) dan di bawahnya **tanggal + jam dunia nyata** dari jam perangkat
  (zona waktu lokal), mis. "Selasa, 3 November 2026 · 09:40", dalam bahasa Indonesia; diperbarui terus. Diuji (`tools/clock_bot.gd`): teks cocok dengan jam sistem
  sandbox, dua contoh format tetap benar, dan tangkapan layar dilihat. Zona waktu HP asli belum diuji.

### Event berjadwal (muncul & hilang sesuai tanggal/jam)
- Semua event ada di **`data/events.json`** — tambah/ubah di sana, tidak perlu menyentuh kode. Tiap event: `id`, `type` (`"banner"` = banner gacha karakter terbatas),
  `title`, `description`, `start`, `end` (format `"YYYY-MM-DD HH:MM"`, atau `"YYYY-MM-DD"` = mulai 00:00 / selesai 23:59), `character` (id karakter), `featured_share`
  (peluang hasil ★5 menjadi karakter event, mis. 0.5). Waktu mengikuti **jam perangkat pemain**.
- Selama event aktif: tombol **Event** muncul di HUD (titik merah bila belum dilihat; panel Event ikut terbuka otomatis saat masuk lobi jika tidak ada hadiah login),
  panel Event menampilkan hitung mundur, dan panel Gacha mendapat tab **"Event: <karakter>"**. Event yang belum mulai tampil di "Akan datang".
- Setelah `end` lewat: tombol Event hilang, banner hilang dari Gacha (panel yang sedang terbuka menutup banner sendiri dan memberi tahu), dan **karakter event tidak bisa
  ditarik lagi** (banner menolak tarikan tanpa memotong diamond). Karakter yang sudah dimiliki tetap dimiliki. Karakter event tidak ada di banner standar.
  Bila karakter event sudah dimiliki saat menarik lagi, hasilnya Pecahan Jiwa ×10.
- Contoh yang disertakan: **"Festival Bara: Ember"** (3–10 November 2026), karakter contoh **Ember** (Penyihir Bara, tongkat/bola api). Ganti tanggal/karakter sesuai kebutuhan;
  karakter baru dibuat seperti Zeya/Ember (`resources/characters/*.tres`, skin di `tools/gen_skins.py`, tampilan di `character_looks.gd`, daftar di `Data.CHAR_ORDER`).
- Diuji (`tools/event_bot.gd`, jam dipalsukan dengan `GameState.set_fake_now`/`--now=`): sebelum event (tidak aktif, "akan datang", banner menolak tarikan, tombol tersembunyi),
  tepat saat mulai (aktif, tombol + titik merah muncul), hitung mundur (contoh "Sisa 5 hari 11 jam" benar), Ember didapat lewat banner (dan jadi Pecahan ×10 saat kedua kali),
  banner standar tidak pernah memberi Ember (300 tarikan), setelah event berakhir (event hilang, tarikan ditolak tanpa potong diamond, panel gacha menutup banner, tombol hilang,
  Ember yang sudah dimiliki tetap ada). Tangkapan layar dilihat.
- Belum diuji: pergantian waktu sungguhan saat game terbuka berjam-jam di HP; pemain bisa memajukan jam perangkat untuk membuka event lebih awal (tidak ada pengecekan server);
  `data/events.json` ikut terkemas di APK sehingga mengubah jadwal butuh ekspor ulang; Ember dipakai bertarung di stage (hanya data & tampilan diperiksa).

### Belum diuji / belum ada
- **APK & perangkat Android nyata**: belum diekspor, performa/FPS di HP belum diukur.
- **Sentuhan multi-touch asli**: logika joystick/tombol ditulis dan dipakai lewat emulasi mouse,
  tetapi belum dicoba dengan jari sungguhan.
- Keseimbangan (balance) bos dan kesulitan hanya dicek dengan bot yang bermain sempurna.
- Tampilan siang/malam di berbagai jam belum ditinjau satu per satu.
- Tombol "Lanjutkan"/"Permainan Baru" di judul diuji hanya untuk jalur "Mulai Bermain" (data baru).

### Keterbatasan / belum diimplementasikan
- Tidak ada **minimap**.
- Boneka latihan belum memberi umpan balik pukulan.
- Mode multiplayer/co-op **tidak ada**; "party 4 karakter" = 4 slot party (mode solo, ganti karakter
  langsung). Saat mulai baru hanya 3 karakter yang terbuka (karakter ke-5, Zeya, dari bonus login); karakter ke-4 (Sera) didapat sebagai hadiah quest menyelesaikan stage 1-1 (alur klaim quest ini diuji lewat quest lain; hadiah Sera sendiri belum diuji langsung).
- Ikon senjata di UI berupa pedang untuk semua kelas senjata.
- Model/animasi sederhana (blok prosedural); suara dibuat sintetis oleh skrip.
- Stage hanya 5; tidak ada cerita panjang, PvP, guild online, atau toko uang asli.

## Regenerasi aset (opsional)
`tools/gen_audio.py`, `gen_textures.py`, `gen_skins.py` membuat audio/tekstur; hanya perlu jika ingin
mengubah aset. Proyek sudah menyertakan hasilnya.

## Menjalankan uji sendiri
```
GODOT=/path/ke/godot
$GODOT --headless --path . res://tools/test_data.tscn
mkdir -p /tmp/shots
xvfb-run -a -s "-screen 0 1280x720x24" $GODOT --path . --rendering-driver opengl3 scenes/stages/stage.tscn \
  -- --bot=1 --botscript=stage_bot --stage=s1_1 --shots=/tmp/shots --fresh
```
Flag uji: `--bot=1 --botscript=<nama di tools/> --shots=<folder> --fresh --stage=<id> --level=N --lose=1 --speed=N`.

## Bos baru: Dewa Wither (stage 3-B "Altar Kehampaan")
- Model: `assets/boss/wither_god_rigged.glb` (kiriman pengguna). GLB hanya membawa animasi Idle; klip cast/slam/roar/hit/death dibuat lewat kode (`scripts/stages/wither_rig.gd`).
- Serangan: hujan sihir (rain), tembakan bola (volley), gelombang nova; fase 2 saat HP ≤ 50%.
- Peta baru: tema "abyss" (lingkaran sihir, kubus melayang) + musik `music_abyss`. Kamera otomatis mundur & condong ke bos.
- Diuji: bot stage s3_boss (bos muncul, 3 serangan jalan, bos bisa mati), test_data LULUS.
- BELUM diuji: perangkat/APK asli, performa, keseimbangan oleh manusia, suara didengar manusia. Efek suara memakai ulang efek bos lama.

## Identitas pemain (offline)
- ID `FL-XXXX-XXXX` = hash SHA-256 satu arah dari ID perangkat (tidak bisa dibalik jadi ID aslinya), jadi sama lagi walau data game dihapus. Hanya bila perangkat tidak memberi ID, dipakai ID acak yang disimpan di `user://identity.json`. Tidak ada fitur ubah ID di game. Nama bisa diganti (2–14 huruf) lewat ketuk profil di HUD. Profil TIDAK menampilkan (dan kode tidak menyimpan) merek/model HP, OS, atau tanggal mulai.
- Batasan jujur: karena offline, tidak ada yang divalidasi server; pemain yang paham file bisa mengubah save-nya. ID bisa berubah bila ID perangkat berubah (reset pabrik / tanda tangan APK beda). Pengamanan sungguhan butuh server (belum ada).
- Diuji: tools/profile_bot (format, unik, rename, panel). Belum diuji di HP asli.

## Satu save, tanpa slot SV (menggantikan "3 slot simpan & nama dunia")
- **Slot SV 1–3 dan nama dunia dihapus.** Layar judul: *Mulai Bermain* / *Lanjutkan* / *Mulai Baru* (konfirmasi) / *Pulihkan dari Kode Cadangan* (hanya bila tidak ada data) / *Hapus Data* (konfirmasi) / *Pengaturan*.
- **Satu file** `user://save.dat`. **Tidak ada `.bak`**, tidak ada file identitas, tidak ada meta. Menulis memakai `save.dat.tmp` sementara yang langsung diganti nama (tidak tertinggal). **Hapus data = progres benar-benar hilang dari perangkat** dan ID pemain berubah.
- **ID pemain ACAK** saat dunia baru dimulai dan disimpan DI DALAM save (bukan lagi turunan ID perangkat; tidak "menempel" ke HP setelah data dihapus).
- Android: `user_data_backup/allow=false` sudah ada di `export_presets.cfg` (cadangan otomatis Google tidak memulihkan data yang sudah dihapus).
- **Migrasi sekali jalan**: bila ada sisa sistem lama, slot yang terakhir dimainkan menjadi save tunggal (ID baru), lalu SEMUA sisa (`save_slot_*.json`, `.bak`, `identity.json`, `meta.json`) dihapus. Slot lain TIDAK dimigrasikan.

## Cadangan lewat kode: terikat perangkat + deteksi berbagi
- Pengaturan → Data → "Salin kode cadangan". Format `FLSAVE2:<base64(gzip(json))>:<HMAC-SHA256>`; memuat hash satu arah ID perangkat (`device_hash()`, tak bisa dibalik) dan ID pemain.
- **Pemulihan hanya jika tidak ada save** di perangkat (hapus data dulu) → kode tidak bisa dipakai memutar balik progres atau menggandakan akun di perangkat yang sama.
- Kode diubah/terpotong/versi lama (`FLSAVE1`) → ditolak (tanpa blokir).
- **Kode dari perangkat lain dipulihkan di sini → terdeteksi sebagai save yang dibagikan → akun DIBLOKIR di perangkat itu**: catatan `user://sanction.dat` (sengaja bertahan walau data dihapus), layar judul menampilkan "AKUN DIBLOKIR", tombol main/pulihkan hilang, `Flow.goto` menolak masuk lobi/stage.
- **BATAS YANG JUJUR (game offline):** (1) tidak ada server, jadi "ID yang sama dimainkan di dua HP pada waktu berbeda" **tidak bisa dideteksi secara global**; yang terdeteksi hanya saat kode dari perangkat lain dipulihkan di perangkat ini. Deteksi sungguhan butuh server. (2) Kunci tanda tangan tertanam di aplikasi: cukup untuk mencegah edit/bagi biasa, bukan terhadap orang yang membongkar aplikasi. (3) Blokir bersifat lokal: "Hapus data aplikasi"/pasang ulang menghapusnya. (4) Konsekuensi aturan ini: **pindah ke HP baru lewat kode TIDAK bisa** (dianggap berbagi). (5) Bila ID perangkat Android berubah (reset pabrik / tanda tangan APK berbeda) kode lama dianggap dari perangkat lain.
- Diuji: `tools/save_test` (34 cek: tanpa sisa file, ID tersimpan di save & baru setelah hapus, 20 ID acak unik, ekspor→hapus→pulihkan, impor saat ada save ditolak, MAC salah/terpotong/FLSAVE1/teks acak ditolak tanpa blokir, kode palsu perangkat lain → blokir + tercatat di disk + bertahan setelah hapus data + dimuat ulang, migrasi sisa lama) dan `tools/title_bot` (tombol per kondisi + foto). Belum diuji di HP asli (`OS.get_unique_id()` Android, clipboard Android).

## Misi harian, pencapaian & kehidupan lobi
- **Misi Harian** (tombol "Misi" di HUD kanan): 3 misi baru tiap tanggal (kalahkan monster, selesaikan stage, + satu dari summon/upgrade/habiskan gold), dipilih deterministik dari tanggal. Tiap misi 300 gold + 20 diamond; semua selesai = bonus 100 diamond + 2 Ramuan Kecil. Reset saat tanggal berganti (memakai jam perangkat, jadi bisa dicurangi dengan mengubah jam HP — game ini offline).
- **Pencapaian** (12 buah, sekali seumur hidup): kill, stage, summon, level, jumlah karakter, upgrade. Tersimpan di save.
- **Lobi hidup**: kupu-kupu di siang hari, kunang-kunang di malam hari (18 sprite di sekitar pemain; mati di kualitas "Lancar").
- **Area aman layar**: HUD, HUD stage, dan kontrol sentuh dimundurkan dari notch/lubang kamera (`UiTheme.safe_insets`). Logika diuji dengan angka; BELUM dicoba di HP bernotch asli.
- **Paket regresi**: `tools/run_all.sh` (set `GODOT=/path/godot`) menjalankan uji: data, unit, save, judul, profil, misi, panel, stage 1-1, bos Wither. Hasil terakhir: 8/8 lulus di mesin ini (bukan di HP).
- Belum dikerjakan: stage/musuh/karakter baru, hewan berjalan di lobi, preset ekspor APK belum dibuild (butuh template ekspor Godot + keystore).

## Tombol "Menu" (hub)
- Tombol Hadiah, Misi, dan Event yang terpisah di kanan HUD digabung jadi satu tombol **Menu** (lencana = jumlah hal yang siap diambil). Menu membuka 4 kartu: Hadiah Login 3 Hari, Misi & Pencapaian, Event, Profil & ID. Diuji dengan `tools/menu_bot` (tombol, lencana, tiap kartu membuka panel yang benar).

## Keamanan data simpanan
- **Simpan aman**: tulis ke `save.dat.tmp` → dibaca ulang & dicocokkan → diganti nama jadi `save.dat`. Bila game mati saat menulis, file utama lama tetap utuh. Tidak ada cadangan `.bak` (sengaja: data yang dihapus tidak boleh hidup lagi). Konsekuensi: file save yang rusak = tidak bisa dimuat (layar judul: "Data permainan rusak", ketuk Mulai Bermain).
- **Simpan otomatis** langsung saat game dijeda/pindah ke latar belakang, kehilangan fokus, tombol kembali, atau ditutup (selain simpan berkala tiap perubahan).
- BELUM diuji di Android: pemicu NOTIFICATION_APPLICATION_PAUSED asli saat aplikasi ke latar belakang (diuji dengan memanggil notifikasinya langsung), clipboard Android (batas ukuran kode ±550 karakter di save awal; save panjang lebih besar), dan rename file di penyimpanan Android.

## Keseimbangan bos & bidik otomatis (hasil ukur bot)
- **Bidik otomatis**: saat menyerang/skill, karakter menghadap musuh terdekat dalam jangkauan (kecuali joystick diarahkan >100° ke arah lain). Sebelumnya pukulan bisa meleset terus bila pemain berdiri diam; ditemukan lewat bot yang macet di bos 1-B (2 dari 10 run macet sebelum perbaikan; 8 dari 8 selesai sesudahnya — sampel kecil).
- **Dewa Wither** dibuat lebih besar (skala 1.4), lebih terang (warna + cahaya ungu), kamera condong ke bos; HP 1000 (x skala bab), atk 28, def 5.
- Hasil bot (stage_bot, speed 3, tiap angka = 2–3 run, semuanya menang; "pingsan" = anggota party yang kalah dari 3):
  - 3-B Wither: Lv 12 (rekomendasi) 70–79 dtk, 1–2 pingsan · Lv 8 ≈100 dtk, 2 pingsan · Lv 15 ≈60–66 dtk, 2 pingsan.
  - 2-B Penguasa Gua Lv 10: ≈51–56 dtk, 0–1 pingsan · 1-B Golem Lv 7: ≈49–59 dtk, 0 pingsan.
  - Party Lv 1 kalah di 2-B dan 3-B (di luar rekomendasi level; stage terkunci sampai stage sebelumnya selesai).
- Catatan jujur: bot bukan manusia (ia menghindar hanya saat bos bersiap dan tidak pernah salah tekan). Pemain sungguhan kemungkinan lebih sering pingsan; keseimbangan akhir butuh uji main manusia di HP.

## Jalan cerita
- Naskah orisinal di `data/story.json`: 9 adegan (42 dialog) — Prolog di lobi (Kristal Bintang meredup, Kehampaan melemahkan segel), lalu pembuka stage 1-1/1-B/2-1/2-B/3-B dan penutup bos 1-B/2-B/3-B (Golem tercemar → serpihan berbisik → prasasti Penjaga Pertama → Dewa Wither yang ternyata penjaga segel). Bab 4-5 ditambahkan (lihat bagian "Update besar: Bab 4-5" di bawah).
- Pemutar `StoryPlayer`: kotak dialog dengan nama berwarna, teks mengetik, ketuk untuk lanjut (ketuk saat mengetik = selesaikan baris), tombol Lewati; game dijeda selama adegan. Tiap adegan diputar otomatis SEKALI per dunia (status di save slot), lalu bisa dibaca ulang dari **Menu → Cerita** (adegan belum dibuka tampil "???").
- Diuji (story_bot 16 cek, story_stage_bot 9 cek): data valid, prolog otomatis, jeda/lanjut, ketuk lewat, intro menjeda stage sebelum gelombang, outro tampil sebelum layar hasil. Ditemukan & diperbaiki: pemutar gagal dipasang saat dipanggil dari `_ready` (kini `call_deferred`).
- Belum: suara/musik khusus adegan, potret karakter, pilihan dialog bercabang.

## Efek serangan (dioptimalkan)
- **Tebasan menyapu**: selain juring statis, ada "ujung tebasan" terang yang menyapu dari satu sisi ke sisi lain; arah bergantian per kombo (`Fx.slash(..., flip)`). Tampak di rumput terang (blend biasa, bukan aditif).
- **Hit-stop**: waktu melambat ~94% selama 0,03–0,075 dtk saat kritikal (0,075), skill/hantaman berat (0,055), atau memukul bos (0,03). Bisa dimatikan di Pengaturan → Grafis → "Hit-stop". Waktu dipastikan kembali normal (juga saat stage ditutup/dijeda).
- **Percikan searah pukulan** (menjauhi pemain), **cincin kilat + angka "meletup"** saat kritikal.
- Diuji (fx_bot 11 cek): efek membersihkan diri (0 node sisa setelah 40 pukulan), hit-stop kembali normal/mati lewat pengaturan/tak aktif saat jeda, angka kritikal mengendap ke skala 1. Kecepatan frame di HP BELUM diukur (renderer uji adalah llvmpipe); efek memakai ≤ ~12 node per pukulan.

## Gaya serang per karakter (diperbarui)
Keluhan: Assassin (Zeya) bergaya sama dengan Swordsman (Ren) — keduanya memakai animasi pedang yang sama, dan jeda serangan terasa tidak ada.
- **Zeya (Assassin) kini beda total**: memakai **dua belati**, animasi sendiri (kuda-kuda rendah, tebas kanan → tebas kiri → penutup putaran silang sambil melompat kecil). Satu kombo = 3 pukulan cepat (jeda 0,26 dtk; animasi 0,30 dtk), tiap pukulan kecil (×0,5), **penutup ×2,0** dengan tebasan lebar + dorongan keras dan jeda ekstra 0,4 dtk. Kritikal 25%, mengabaikan 60% DEF musuh (agar pukulan kecil tidak habis dimakan DEF). Skill **Tebasan Bayangan**: menerjang ke depan (kebal ±0,5 dtk) dan menyilang dua tebasan beruntun.
- **Ren (Swordsman)** dibuat lebih berbobot: jeda 0,42 → 0,55 dtk (+0,15 dtk setelah kombo 2 pukulan), damage ×1,1.
- **Jeda serangan kini benar-benar berlaku**: serangan berikutnya tidak bisa lebih cepat dari `attack_cooldown` (+ `combo_recovery` pada penutup), walau tombol ditahan. Brann dinaikkan ×1,35 → ×1,55 karena DPS-nya terlalu rendah.
- Data baru di `CharacterData`: `anim_style`, `combo_hits`, `finisher_mult`, `combo_recovery`, `crit_chance`, `armor_pen`.
- **Animasi lebih tidak kaku (semua karakter)**: pinggul ikut memutar saat menyerang (torsi kaki-pinggul-bahu), lari/jalan punya putaran pinggul berlawanan bahu + kemiringan, napas & berat badan berpindah saat diam.
- Diuji bot (`tools/combat_bot.gd`, 5 karakter menyerang 6 dtk ke target latihan): jeda minimum antar-serangan ≥ cooldown data untuk semua; pola kombo Zeya 0,1,2,0,1,2; DPS terukur di putaran terakhir (6 dtk, level & perlengkapan sama, ada acak kritikal sehingga bergeser antar-putaran): Ren 37,5 · Zeya 38,8 · Brann 36,8 · Lyra 37 · Sera 34,7 (putaran sebelumnya Brann hanya 22 sebelum dinaikkan ke ×1,55, jadi selisih besar itu juga ikut dipengaruhi acak — belum diulang berkali-kali). `attack_sheet`: damage jatuh ≤0,08 dtk dari momen impak animasi untuk semua 16 aksi.
- **Belum**: rasa pukulan/animasi hanya dinilai lewat foto pose & angka bot di llvmpipe; belum dirasakan di HP asli, jadi angka balans mungkin perlu disetel setelah kamu main. Efek belati (kilau/bekas tebasan) masih memakai efek tebasan yang sama dengan lebar/durasi berbeda. Animasi musuh belum diubah.

## Efek serangan khas tiap karakter (`scripts/stages/char_fx.gd`)
Sebelumnya semua karakter berbagi efek yang mirip (juring + percikan sama; Ember & Brann sama-sama "gelombang"). Sekarang tiap karakter punya identitas sendiri:
- **Ren (es & fajar)**: sabit es biru tegak yang menyapu, serpihan es & salju; skill = dua sabit biru-emas + garis fajar.
- **Zeya (bayangan)**: sabit tipis merah muda dengan bayangan ungu di belakangnya; penutup kombo berbentuk "X" + cincin bayangan + kelopak; skill = garis terjang + asap bayangan + tebasan silang; kena = kilatan "X".
- **Lyra (bintang)**: peluru bintang 8 sudut berputar + kerlip ungu/putih; Nova Bintang ditambah kerlip naik.
- **Ember (api)**: bola api berdenyut dengan jejak api naik; skill "Gelombang Bara" = cincin api, lidah api melingkar, bekas hangus (tidak lagi sama dengan Brann).
- **Brann (tanah)**: retakan tanah + debu + pecahan batu; skill = retakan besar, debu melingkar, batu terlontar.
- **Sera (angin & daun)**: panah berkepala runcing dengan jejak angin; Hujan Panah diawali cincin angin + daun; kena = daun beterbangan.
- Hemat: partikel CPU sekali-jalan, mesh & material dipakai bersama (cache), partikel mengecil sendiri, jumlah partikel mengikut Pengaturan > Kualitas (Lancar = setengah & tanpa jejak peluru & tanpa lampu peluru). Id karakter lain memakai efek umum lama.
- **Perbaikan kamera**: di dekat tepi arena kamera sempat berada di dalam cincin pohon sehingga tajuk hijau besar menutupi layar (itulah "poligon hijau" yang muncul di foto sebelumnya). Kini kamera otomatis naik (pitch sampai 74°) bila berada di luar tepi arena, dan kembali normal di tengah.
- Diuji (`tools/charfx_bot.gd`, 6 karakter × serangan/kombo/skill): tak ada error skrip; semua efek membersihkan diri (sisa 0–1 node); node efek puncak 49–121 per ±2,4 dtk menyerang terus (batas uji 160); kamera tepi arena naik, kamera tengah tidak berubah. Foto fase efek diperiksa lewat tangkapan layar.
- Belum: frame-rate di HP asli tidak diukur (renderer uji llvmpipe, jadi "hemat" baru dibuktikan lewat jumlah node, bukan FPS); retakan Brann tampak seperti garis kuning-hitam bergaya (belum ideal); efek tidak bersuara khusus; efek bos/musuh tidak diubah.

## Dua gacha di Altar Bintang (Gacha Karakter & Gacha Perlengkapan)
Panel Altar Bintang kini punya dua tab terpisah, masing-masing dengan peluang, hadiah, dan **pity sendiri** (hitungan 50 tarikan tidak tercampur):
- **Gacha Karakter ("Panggilan Jiwa")**: ★5 2% = Sera/Zeya, ★4 13% = Ren/Lyra/Brann, ★3 85% = Pecahan Jiwa ×3 (karakter milikmu). Karakter baru langsung terbuka; yang sudah dimiliki jadi Pecahan Jiwa (★5 ×10, ★4 ×5). **Banner event** (karakter terbatas seperti Ember) ada di tab ini; Ember tidak pernah keluar di banner standar.
- **Gacha Perlengkapan ("Panggilan Perlengkapan")**: ★5 2% legendaris, ★4 10% epik, ★3 28% perlengkapan langka, ★2 30% Ramuan Besar ×2, ★1 30% Ramuan Kecil ×3. Tidak pernah memberi karakter/Pecahan Jiwa.
- Harga sama untuk keduanya (100 / 900 diamond, `GACHA_SINGLE/GACHA_TEN` di `game_state.gd`); 10× menjamin ≥ ★4; upacara pemanggilan sama. Simpanan lama tetap terbaca (`pity` lama = pity karakter, `pity_item` mulai 0).
- Diuji (`tools/gacha_split_bot.gd`, 17 cek + `save_test`): 1500 tarikan tiap gacha — item hanya item, karakter hanya karakter/pecahan (tanpa Ember); distribusi ★ sesuai (±6 poin); pity terpisah; banner ditolak di tab item; tab di panel berfungsi; pity item tersimpan di save.
- Catatan jujur: setelah semua karakter standar terbuka, Gacha Karakter praktis hanya memberi Pecahan Jiwa (karakter yang bisa didapat memang baru 6, dan Ember hanya lewat event). Harga/peluang belum diuji keseimbangannya dengan pemain nyata. Tarikan di HP asli belum dicoba.

## Tampilan Menu baru (laci dari samping, kartu miring)
- Menu kini **meluncur masuk dari sisi kanan** (0,3 dtk, latar memudar gelap) dan meluncur keluar saat ditutup (tombol panah bulat kiri-atas, ketuk area gelap di kiri, atau tombol Back).
- Warna tema **sama dengan panel lain** (biru malam + emas, judul emas, bingkai emas; kartu ber-hadiah berbingkai emas terang): panel biru malam bergaris miring; dua kartu besar miring (Hadiah Login, Misi & Pencapaian) dan tiga kartu lebih kecil (Event, Cerita, Profil & ID) dengan garis warna aksen, ikon besar pudar, dan lencana "!"/angka. Gerigi di kanan-atas membuka Pengaturan (lalu kembali ke Menu). Kartu muncul bertahap.
- Tata letak "kartu miring pilih mode" terinspirasi game bergenre sama, tetapi semua gambar/ikon/warna dibuat sendiri lewat kode (tidak memakai gambar atau merek game lain).
- Diuji (`tools/menu_bot.gd`, 12 cek): laci mulai di luar layar, berhenti di posisi akhir, menutup dengan animasi, tiap kartu membuka panelnya, lencana hilang setelah klaim. Foto layar diperiksa. Belum: sentuhan di HP asli (kartu memakai emulasi mouse dari sentuhan bawaan Godot; diuji lewat klik/sinyal, bukan jari sungguhan); tidak ada potret karakter di kartu (belum ada aset ilustrasi orisinal).

### Perapihan Menu
Margin dan jarak antar-elemen diseragamkan, ada garis pemisah emas di bawah header, ubin diperbesar, teks diletakkan di bagian atas ubin dan ikon pudar di pojok kanan bawah sehingga tidak saling menimpa, plus petunjuk "Ketuk area gelap untuk menutup" di bawah. Diuji lewat bot di layar 1280x720 (belum diuji di perangkat Android sungguhan).

### Karakter ★6 baru: Hakuya + sistem kelangkaan karakter
- **Hakuya** (Samurai, ★6, id `hakuya`): rambut perak panjang diikat tinggi, haori putih, hakama hitam, katana + sarung (tampilan dari kode, skin dari `tools/gen_skins.py`; semua orisinal, hanya terinspirasi gambar referensi). Serangan `arc` jangkauan 3,1 m, kombo 2 pukulan (penutup 1,9x), kritikal 22%, menembus 30% DEF. Skill **Tebasan Bulan Pucat** (`iai`): tebasan lurus sangat panjang (7,5 m) lalu tebasan lebar penutup berbalut api biru. Efek serang, skill, dan efek kena khasnya ada di `CharFx` (putih tipis + biru).
- **Kelangkaan** (`rarity` di CharacterData, terpisah dari bintang kebangkitan): Hakuya ★6; Lyra, Sera, Zeya, Ember ★4; Ren, Brann ★3. Sera, Zeya, Ember, dan Lyra dinerf statnya (ATK/pertumbuhan, kritikal/penetrasi Zeya, HP Ember).
- **Gacha karakter**: ★6 1,5% (pity 80), ★4 13,5% (Sera/Zeya/Lyra), ★3 85% (Ren/Brann atau Pecahan Jiwa). Pecahan duplikat: ★6 ×20, ★4 ×5, ★3 ×3. Banner event kini mengganti sebagian hasil ★4 (Ember). Gacha perlengkapan tidak berubah (★5 tertinggi, pity 50).

### Gulir sentuh yang ramah Android + efek lebih tebal + api biru Hakuya
- **Gulir (`scripts/ui/touch_scroll.gd`, kelas `TouchScroll`)** dipakai semua daftar (Toko, Inventori, Quest, Karakter, Party, Equipment, Stage, Pengaturan, Gacha, dst.). Seret di mana pun, termasuk di atas kartu/tombol, menggulir (ambang 12 px) dengan inersia; begitu seretan mulai, tekanan tombol dibatalkan sehingga tidak ada pembelian/pilihan nyasar. Kartu kini aktif saat jari DILEPAS di dalam kartu (`BasePanel.tap_on`), dan posisi gulir dipertahankan saat daftar dibangun ulang (sebelumnya melompat ke atas setiap memilih item). Penggulir sentuh bawaan Godot dimatikan agar tidak bentrok. Roda mouse tetap bekerja.
- **Efek**: tebasan/bulan sabit lebih tebal + lapisan cahaya tambahan, garis terjang lebih lebar, jumlah partikel naik ±25% (menyesuaikan Pengaturan > Kualitas).
- **Api biru Hakuya**: aura api biru menyala di kaki (dipasang otomatis saat Hakuya aktif), lidah api biru halus (billboard bertekstur, bukan balok) di penutup kombo, jejak api sepanjang tebasan skill, dan kobaran api biru di tanah setelah skill. Jumlah node dijaga di bawah 160 per aksi.
- Uji: `tools/scroll_bot.gd` (simulasi seret/ketuk lewat peristiwa mouse), `tools/hakuya_look_bot.gd` (foto aura & skill).

### Efek Hakuya terinspirasi video referensi
Katana menyala: lidah api biru kecil sepanjang bilah + bara bercahaya yang tertinggal di udara saat diayun (`CharFx.blade_fire`); jejak tebasan berbentuk bulan sabit runcing (`CharFx.taper_mesh`, tebal di tengah, tajam di ujung); semburan garis percikan saat kena dan garis kecepatan di skill (`CharFx.spark_lines`); bara melayang (`CharFx.embers`); api memakai tekstur lidah api halus (billboard), bukan balok. Foto uji dekat: `tools/hakuya_look_bot.gd`.

### Hakuya: skin, rambut, dan jejak katana
- **Skin** (`tools/gen_skins.py`, `paint_hakuya`): dicat ulang mengikuti template 2D dari gambarmu: haori putih bermotif silang hitam, kimono dalam gelap berbentuk V, obi hitam, pembalut lengan hitam dengan X putih, hakama hitam berlipit, sepatu hitam, rambut perak berserat.
- **Rambut**: ekor kuda tinggi yang tebal, bergelombang dan berayun, helai liar tipis, sisi rambut mengembang, dan tudung rambut (`CharacterLooks._ponytail`).
- **Jejak katana sungguhan** (`CharFx.BladeTrail`): pita cahaya putih-biru yang mengikuti ujung dan pangkal bilah selama serangan dasar dan skill, memudar cepat, seperti di video referensi. Kamera game tidak diubah.

### Panel Party baru (terinspirasi layar "Party Settings" gim sejenis, desain sendiri)
- Kiri: 4 kartu slot tinggi dengan potret 3D setengah badan, nama, bintang kelangkaan berwarna, peran + kekuatan; slot 1 bertanda ♛ Pemimpin.
- Kanan: grid karakter 3 kolom (potret kepala, bintang kelangkaan, "Slot N" / kekuatan / petunjuk quest bila terkunci) di dalam `TouchScroll`, tombol **Urut** (Rarity → Kekuatan → Nama).
- Bawah: bar info (kekuatan regu, petunjuk slot terpilih) + aksi "♛ Jadikan pemimpin" / "Lepas".
- Potret dirender sekali oleh `scripts/ui/portraits.gd` (SubViewport transparan per karakter, di-cache) dan panel menyegarkan diri saat siap.
- Uji: `tools/party_bot.gd` (potret ter-render berisi piksel, ketuk roster mengisi/menukar slot, urutan berganti), masuk `run_all.sh` sebagai `party`.

### 4 karakter baru (dari gambar referensi; semua orisinal berbasis voxel)
| Karakter | ★ | Senjata / gaya | Skill | Efek |
|---|---|---|---|---|
| **Vael** – Pemburu Fajar Biru | 5 | pedang raksasa bercahaya cyan, tebasan lebar berat (`arc`) | Gelombang Fajar Biru (`cone`) | bulan sabit cyan/putih, cincin, percikan, bara, aura api cyan |
| **Lucien** – Tuan Monokel Bertongkat | 5 | tongkat emas, peluru bayangan emas (`bolt`, tembus armor 35%) | Hujan Pedang Bayangan (`volley`) | bintang/bilah emas, cincin emas-ungu, bara |
| **Wenyu** – Peniup Seruling Senja | 4 | seruling, bola angin berkelopak (`bolt`) | Lagu Kelopak Senja (`nova`) | kelopak putih-biru, aura kelopak |
| **Kuroha** – Samurai Mantel Malam | 4 | katana, tebasan cepat (`arc`) | Terjang Bayangan Tinta (`dash_cut`) | bulan sabit tinta + perak, X flash, aura bayangan |
| **Aion** – Penjaga Jarum Waktu | 5 | tongkat jam, serpihan jarum jam (`bolt`) | **Jeda Waktu** (`chrono`): jam terbentang di tanah, damage sedang + musuh melambat 50% selama 3,5 dtk | gagak tinta, cipratan tinta biru, wajah jam berputar |
- Skin: `tools/gen_skins.py`; model/aksesori: `CharacterLooks._vael/_lucien/_wenyu/_kuroha`; efek: `CharFx` (per id).
- Gacha karakter kini punya ★5 (3,5%): pool ★6 Hakuya; ★5 Vael, Lucien; ★4 Sera, Zeya, Lyra, Wenyu, Kuroha; ★3 Ren, Brann. Pity 80 tetap untuk ★6.

### Ilustrasi beranimasi (GIF) — DIHAPUS
- Atas permintaan, GIF/ilustrasi beranimasi karakter (Lucien & Wenyu) dihapus seluruhnya: `assets/art/`, `scripts/ui/anim_art.gd` (`AnimArt`), dan tes `art_bot`/`seni_anim`. Panel Karakter dan kartu hasil gacha tidak lagi menampilkan gambar GIF; semua karakter memakai potret 3D `Portraits` / ikon seperti sebelum ada GIF.

### Panel Party v2 (gaya daftar karakter, lebih hidup)
- Kartu roster: latar gradien biru berkilau, lencana "Slot N" / "Lv", potret setengah badan, baris bawah berisi ikon senjata | bintang kelangkaan | kekuatan (atau petunjuk quest bila terkunci); bingkai emas untuk anggota regu.
- Kartu slot tinggi memakai gradien sesuai kelangkaan. **Semua karakter memakai potret 3D** yang dirender `Portraits` (kartu slot = seluruh badan, kartu roster = setengah badan). Render yang gagal/kosong otomatis diulang.

### Perbaikan bug serangan (audit semua karakter)
- **Ayunan hantu:** ayunan/skill yang tertunda (menunggu momen kena) kini dibatalkan saat **menghindar**, **ganti karakter**, atau **mati** (`Player.cancel_actions`). Sebelumnya tebasan/tembakan tetap keluar setelah animasinya terputus, bahkan memakai data karakter yang baru. Menghindar saat menyiapkan serangan mengembalikan cooldown serangan/skill yang belum sempat kena.
- **Arah serangan terkunci:** selama membidik sampai momen kena, arah hadap tidak lagi ikut berputar ke arah joystick, jadi tembakan/tebasan tidak meleset ke arah jalan.
- **Terkena saat menyiapkan serangan:** tidak lagi terhuyung (animasi hurt memutus ayunan lalu damage tetap keluar) — ayunan lanjut sampai selesai, damage tetap diterima.
- Ayunan yang jatuh tempo setelah stage berakhir / pemain mati diabaikan oleh stage.
- Uji: `tools/serang_bot.gd` (`audit_serang` di run_all) — 11 karakter × 10 pemeriksaan: serangan & skill mengenai walau awalnya menghadap salah, arah terkunci, dorongan wajar, batal saat dodge/ganti/mati, tetap keluar saat terkena, dan kembali normal setelah spam aksi acak.

## Build ADMIN (uji karakter penuh)
Build terpisah, **salinan persis** game ini + alat uji. Dibuat otomatis: `python3 tools/make_admin.py` → `../fantasy_life_rpg_admin` (ZIP: `fantasy_life_rpg_admin.zip`). Game utama tetap bersih (tanpa kode admin).
- Tombol merah **ADMIN** di tengah atas semua layar → jendela alat: buka semua karakter, ★ maks, level 50, +gold/diamond, buka semua stage, item ×99, senjata +10, pity gacha hampir penuh; God Mode, One-hit, Tanpa cooldown, pulihkan HP, bunuh semua musuh, kecepatan 0.4x/1x/2x; ganti ke karakter mana pun langsung (lobi & stage); mulai stage mana pun; spawn jenis musuh/bos apa pun.
- Nama proyek "... ADMIN" → save terpisah dari game asli.
- Kait di build admin saja: `player.take_damage` (god), cooldown di `player._physics_process`, `stage._hit_enemy` (one-hit).
- Tes: `tools/admin/admin_bot.gd` (stage, 18 cek) dan `admin_lobby_bot.gd` (lobi, 4 cek) — dijalankan di salinan admin.

## Perbaikan arah efek tebasan (laporan: efek/partikel tebasan ke atas, bukan ke depan)
- **Penyebab:** `CharFx.crescent()` (sabit tebasan semua karakter jarak dekat) memasang busur **berdiri tegak seperti pelangi ∩ di depan pemain** (bidang tegak lurus arah hadap), sehingga tampak seperti payung/topi di atas kepala. Partikel bara/serpihan juga disemburkan ke `Vector3.UP`.
- **Perbaikan:** busur kini **mendatar mengelilingi pemain pada jarak jangkauan, miring diagonal ±15° (ayunan pedang) dan menyapu dari satu sisi ke sisi lain searah hadap**. Bara/serpihan/percik pada tebasan & skill jarak dekat (Ren, Zeya, Hakuya, Vael, Kuroha, iai) disemburkan **ke arah hadap** (`embers()` punya parameter `dir`).
- **Tes baru:** `tools/fx_dir_bot.gd` (`run_all.sh` → `arah_tebasan`): setiap frame mengukur semua mesh busur efek — tinggi/lebar ≤ 0.5, puncak ≤ 3 m, pusat tidak di belakang pemain — untuk semua karakter jarak dekat (serangan & skill), plus foto `dir_*` di `--shots`.

## Performa perangkat ringan–menengah (Helio P22/P32, PowerVR GE8320) & grafis "Bagus" lebih bagus
Pengaturan → Grafis → **Kualitas: Otomatis / Lancar / Sedang / Bagus** + saklar **Resolusi dinamis**.
- **Otomatis** menebak kelas HP dari nama GPU (PowerVR/Adreno <510/Mali lama → Lancar; Mali-G52/G57/G72/Adreno 5xx–6xx → Sedang; Adreno 6xx+/Mali-G7x+/Immortalis → Bagus), RAM (≤3,3 GB → Lancar, ≤4,3 GB → maks Sedang) dan jumlah inti. Tidak dikenali → Sedang. Nama GPU dari Android kadang tidak informatif, jadi pemain bisa memilih manual.
- **Lancar**: resolusi 3D ≈ 0,55 MP (UI tetap tajam), tanpa bayangan nyata (diganti bayangan semu bulat di tanah), tanpa MSAA/glow, lampu titik dekor mati, jarak pandang 200 m.
- **Sedang**: ≈ 0,8 MP, bayangan 1 kaskade 1024 px dekat.
- **Bagus**: resolusi penuh, bayangan 2 kaskade 2048 px halus, MSAA 2x, glow lembut + kontras/saturasi sedikit naik.
- **Resolusi dinamis** (`autoload/perf.gd`): tiap detik mengukur waktu bingkai; bila rata-rata > 18,8 ms skala 3D turun bertahap (ada batas bawah per kelas), bila stabil dicoba naik lagi dengan jeda yang membesar bila gagal.
- Penyebab terbesar lag: bayangan teks Label memecah batching UI (lobi 547 draw call). Diganti outline → **lobi 195 draw call (Lancar), 223 (Sedang), 289 (Bagus)** (ukuran bot, deterministik).
- Uji: `tools/perf_test.tscn` (tebakan kelas HP, skala, governor, preset) — 25 cek lulus.
- **Jujur**: belum diuji di HP sungguhan. Jumlah draw call/segitiga terukur nyata, tetapi FPS hanya diukur di renderer perangkat lunak (relatif, bukan FPS Helio P22/P32). Target 60 FPS di Helio P22 belum bisa dijamin; governor akan menurunkan resolusi otomatis bila masih berat.

## Bangunan 10% lebih besar + tata letak dirapikan
- Semua bangunan (kecuali air mancur dan gerbang yang terikat plaza/tembok) diperbesar 10% (`LobbyLayout.BUILDING_SCALE`); area larangan pohon/dekorasi ikut membesar.
- Badan bangunan digeser mundur menjauhi jalan sebesar pertambahan kedalamannya, supaya muka bangunan tetap di garis jalan dan tidak menjorok ke jalan/NPC.
- Guild digeser 1,8 m ke selatan (z -39,2) agar tidak menempel tembok kota setelah membesar.
- Diperiksa lewat foto peta dari atas (`tools/lobby_overview.gd`) dan seluruh paket regresi. Catatan: uji `scroll` sekali gagal saat mesin sibuk dan lulus dua kali saat dijalankan ulang (uji berbasis waktu); belum diuji di HP sungguhan.

## Mode grafis "Klasik" (bawaan) — laporan performa turun setelah update optimasi
- Pengguna melaporkan FPS di HP-nya justru turun setelah update optimasi. Penyebab pasti tidak bisa diukur tanpa HP-nya; dugaan: resolusi dinamis (ubah ukuran render berulang kali), bayangan semu, glow/MSAA di kelas Bagus, dan pilihan Otomatis yang menebak kelas HP.
- Ditambah pilihan **Klasik** di Pengaturan → Grafis : resolusi 3D penuh, tanpa resolusi dinamis, tanpa bayangan semu/glow/MSAA, bayangan jarak 55 m, pandang 420 m (mendekati perilaku sebelum optimasi; bukan salinan byte-per-byte).
- Save pengaturan lama (tanpa `gfx_v`) otomatis dikembalikan ke Klasik sekali; pengaturan lain tidak berubah. Setelah itu pilihan pemain dihormati. Lancar/Sedang/Bagus/Otomatis tetap ada untuk dicoba.
- Perbaikan murah yang tetap aktif di semua mode: bayangan teks UI diganti outline (lobi 547→~195 draw call).

## Bawaan grafis = Sedang (laporan pengguna)
Laporan: sebelum grafis diperbagus 60 FPS; setelah update (saat masih ada GIF karakter) turun ke 48 FPS; setelah GIF dihapus + optimasi, kelas **Sedang** kembali 60 FPS di HP-nya. Maka bawaan sekarang **Sedang** (bukan Klasik); save lama dimigrasikan ke Sedang sekali. Klasik tetap tersedia sebagai pilihan. Ini laporan pengguna, bukan hasil ukur saya.

## Deploy ke GitHub -> APK otomatis (GitHub Actions)
File: `.github/workflows/buildapk.yml` (+ `export_presets.cfg` sudah mengaktifkan arm64 **dan** armeabi-v7a, karena banyak HP Helio P22/P32 memakai Android 32-bit).
1. Buat repo baru di GitHub, lalu dari folder proyek: `git init && git add . && git commit -m "Fantasy Life RPG" && git branch -M main && git remote add origin <URL-repo> && git push -u origin main`.
2. Tab **Actions** -> workflow **Build APK** berjalan otomatis (menjalankan uji data/unit/save/perf lalu ekspor APK). Hasilnya ada di **Artifacts** -> `fantasy-life-rpg-apk`.
3. **Rilis**: `git tag v0.2.0 && git push origin v0.2.0` -> APK (game + admin) otomatis terlampir di halaman **Releases**; unduh dari HP lewat browser lalu pasang.
4. Versi ADMIN manual: Actions -> Build APK -> Run workflow -> centang "admin".
**Jujur:** workflow ini belum pernah dijalankan (saya tidak punya akses GitHub/Android SDK di sini). Langkah ekspor memakai praktik umum Godot 4.3 (setup-godot + Android SDK + keystore debug); kalau gagal di run pertama, kirim log-nya ke saya. APK bertanda-tangan debug (cukup untuk dipasang, bukan untuk Play Store).

## Menu diperbanyak & dirapikan (3 baris kartu)
- Menu (laci kanan) kini 8 kartu: Hadiah Login, Misi & Pencapaian, Event, Cerita, Profil & ID, **Koleksi** (bilah kemajuan karakter & item per jenis), **Statistik** (waktu main, musuh, stage/bintang, gacha, gold, tempa, cerita — dari data save nyata), **Panduan** (kontrol, tips, cara dapat karakter, performa, data).
- Kartu pendek tidak lagi ditimpa ikon (ukuran ikon dibatasi, teks menyisakan ruang). Diuji `tools/menu_bot.gd` (kartu -> panel benar) + dilihat lewat screenshot.
- Belum dikerjakan (saran): ikon HUD tombol atas bisa dikelompokkan/dikecilkan, panel Gacha/Toko perlu pass visual yang sama, dan lag di HP asli hanya bisa dipastikan lewat uji di perangkat.

## Poles lanjutan (Gacha, Toko, HUD, Statistik, Koleksi)
- Gacha: teks peluang tidak lagi terpotong (membungkus baris); area hasil yang kosong diisi petunjuk nyata (karakter yang belum dimiliki + hitungan pity).
- Toko: barang pertama otomatis terpilih sehingga panel detail tidak kosong.
- HUD: tombol atas diperkecil (72 px) agar tidak terlalu ramai dan tidak menutup dunia.
- Statistik: ditambah daftar kemajuan stage (bintang). Koleksi: galeri karakter (terkunci ditampilkan "???").
- Belum: uji rasa serangan di HP asli, dan musik/efek suara per area (belum dikerjakan).

## Poles Gacha, Toko, HUD, Statistik, Koleksi
- **Gacha**: baris peluang membungkus (tidak terpotong lagi); area hasil yang kosong kini menampilkan petunjuk nyata (karakter yang belum dimiliki + hitungan pity).
- **Toko**: barang pertama terpilih otomatis sehingga panel detail + tombol Beli langsung terisi.
- **HUD**: tombol atas dikecilkan (72 px, ikon 32) agar tidak menutupi dunia 3D.
- **Statistik**: ditambah daftar kemajuan stage; **Koleksi**: ditambah chip semua karakter (dimiliki / "???" bila belum). Margin kanan agar scrollbar tidak memotong.
- Tidak dikerjakan: tes rasa serangan di HP asli dan suara/musik per area (butuh perangkat / aset audio).

## Poles lanjutan: Karakter, Inventori, Pengaturan
- **Karakter**: daftar kiri kini bisa digulir (sebelumnya panel melebihi layar sehingga tombol "Pemimpin" & "Ganti Equipment" jatuh di luar layar — bug nyata, sudah diperbaiki); ditambah potret 3D seluruh badan di sisi kanan (siluet gelap bila terkunci).
- **Inventori**: item pertama terpilih otomatis (detail/tombol langsung terisi, baris tersorot).
- **Pengaturan**: tab lebih besar & jelas (area sentuh), teks catatan suara dirapikan.

## ULT (jurus pamungkas, 1× per match)
- Tiap karakter punya ULT (`ult_name/ult_kind/ult_mult/ult_range` di `resources/characters/<id>.tres`). Tombol ULT (ungu-pink, di atas-kanan tombol serang) / keyboard **U** / gamepad RB. Setelah dipakai tombol menampilkan "SUDAH" dan tidak bisa dipakai lagi di match itu (per karakter; karakter lain di party masih punya jatah sendiri; reset saat stage baru).
- Saat ULT: pemain terkunci ~1.7 dtk & kebal ~2.4 dtk; lingkaran sihir bercahaya → 7 serangan area di musuh → ledakan penutup (total ≈ ATK × ult_mult).
- Tiap ULT punya bahasa visual sendiri sesuai karakter: Ren pedang cahaya jatuh + pedang raksasa, Lyra konstelasi (lingkaran bintang), Brann hantaman bumi, Sera hujan panah, Ember api oranye, Zeya tebasan silang bayangan, Hakuya api biru, Vael pilar cahaya, Lucien lingkaran jam emas, **Wenyu simfoni nota musik + paranada**, Kuroha naga bayangan. Lingkaran sihir hanya untuk penyihir (Lyra, Lucien).
- Efek orisinal prosedural di `scripts/stages/ult_fx.gd` (tekstur dari `tools/gen_ult_art.py` → `assets/fx/`): pedang cahaya jatuh, pilar cahaya, kolom api (oranye/biru), gempa & kristal, naga tinta/bayangan.
- Tes: `tools/ult_bot.gd` (di run_all sebagai `ult`).

## Mata karakter
- Mesh mata/alis lama (titik hitam) dihapus dari `assets/hero/hero.glb`; diganti tekstur mata gaya chibi anime (iris besar gradasi warna karakter, 2 kilau, bulu mata) + alis + kedip acak. Dibuat oleh `tools/gen_eyes.py` → `assets/hero/eyes/`.

## Gerak per karakter (diam / jalan / lari / siaga)
- `AnimLibrary.STYLES` memberi tiap karakter animasi `idle@id`, `walk@id`, `run@id`, `ready@id` sendiri (Brann kuda-kuda lebar & langkah berat, Zeya merunduk, Wenyu memegang seruling & meliuk, Hakuya tenang tangan di sarung, dst). Dibuat lazy (`ensure_style`).
- Setelah serangan dasar/skill, karakter berpose siaga (`ready@id`) selama 3.5 dtk saat diam, lalu kembali santai (blend halus di `CharacterRig`).
- Brann: animasi hantam diperberat (kumpul tenaga, angkat, banting, tahan, bangkit) + partikel tanah (debu, pecahan batu, percikan, gelombang susulan; pukulan ke-3 lebih besar).
- Wenyu: peluru, skill ("Lagu Kelopak Senja"), dan ULT memakai NOTA musik (`assets/fx/note_*.png` dari `tools/gen_ult_art.py`) + paranada, tanpa lingkaran sihir.
- Foto pose: `tools/pose_bot.gd` (`POSE_IDS=brann,wenyu`).


## Update besar: Bab 4 "Kuil Bayangan" & Bab 5 "Menara Rantai Merah" (musuh karakter humanoid)
**Musuh baru berwujud manusia** (`scripts/stages/humanoid_enemy.gd`, turunan `Enemy`; memakai rig karakter hero.glb + skin sendiri + aksesori `CharacterLooks.apply_enemy`):
- Kroco: **Pengikut Berkerudung** (menusuk meluncur), **Penyihir Bayangan** (jarak jauh, menembak 1 bola / 3 bola menyebar, menjaga jarak), **Ksatria Rantai** (tebasan + sapuan rantai area), **Ronin Bayangan** (tebasan cepat + terjang menembus).
- Bos: **Uranos** (peluru kipas, hujan meteor, nova, berpindah tempat/teleport bila didekati, fase 2: memanggil pengikut) dan **Raja Rantai Merah** (bantingan pedang, sapuan rantai, sangkar rantai, seruduk; fase 2: memanggil Ksatria Rantai).
- Semua serangan punya telegraf merah dan animasi diselaraskan dengan momen pukulan (bukan di awal windup). Skin dibuat `tools/gen_skins.py` (varian `e_*`).
**Lokasi baru** (tema arena `temple` dan `chains` di `arena.gd`): 4-1 Gerbang Kuil, 4-2 Halaman Seribu Lentera, 4-3 Aula Bayangan, 4-B Singgasana Uranos; 5-1 Kaki Menara, 5-2 Lorong Belenggu, 5-B Takhta Rantai Merah. Total 16 stage; terbuka berantai mulai dari 3-B.
**Cerita**: 9 adegan baru (total 18) di `data/story.json`; penutup 3-B kini mengarah ke Bab 4; penutup 5-B membuka kelanjutan cerita.
**Uji**: `humanoid_bot` (4 kroco: muncul, mengejar, menyerang, mati, dibersihkan), `humanoid_boss_bot` (kedua bos, semua serangan, fase 2, mati), `test_data` (semua musuh/tema/rantai unlock valid), `story_bot`.
**Jujur**: belum diuji di perangkat Android sungguhan; keseimbangan angka (HP/ATK bos) baru diuji lewat bot, belum lewat bermain manual. Musik Bab 4-5 memakai ulang lagu yang ada (music_abyss / music_boss).

## Langit hidup & Pengaturan baru
- **Awan 3D, matahari/bulan bergerak** (`scripts/lobby/sky_life.gd`, `assets/sky/*`): awan kumulus kartun dari mesh blob (dasar rata + menara gumpalan, pencahayaan toon, bayangan abu-biru di bawah) melayang pelan di sekeliling kota; bayangan awan lembut bergeser di tanah (terlihat dari kamera biasa); matahari siang & bulan malam mengikuti arah cahaya DayNight. Awan terlihat saat kamera diturunkan: Pengaturan > Kamera > "Sudut miring" kini bisa sampai 10° (sebelumnya 25°). Aktif di lobi dan stage luar ruangan. Kualitas Lancar: awan lebih sedikit & tanpa bayangan awan. (Versi awal memakai gambar 2D tempel; dibuang karena jelek.)
- **Pengaturan dirombak**: tiap opsi dalam kartu dengan kolom label seragam, petunjuk di bawah nama, judul bagian, tab lebih besar, saklar AKTIF (hijau)/MATI, deskripsi kualitas dinamis. Opsi baru di tab Lobi: "Awan & matahari bergerak" dan "Bayangan awan di tanah".
- **Jujur**: kamera lobi menatap ke bawah, jadi langit 3D hampir tak terlihat; efek awan paling nyata lewat bayangan di tanah dan lapisan langit 2D di atas layar (halus, bukan awan 3D besar di layar). Belum diuji di HP sungguhan; dampak FPS belum diukur di perangkat (hanya ringan: <=12 quad awan, 1 bidang bayangan).

## Rig V2: jari & mata bertulang, pegangan & ayunan pedang diperbaiki

Sumber: paket `[ZN] RIG V2` (proyek Prisma 3D). Format `.proj` adalah MessagePack sehingga bisa dibaca skrip; rig asli punya tulang jari (4 jari x 2 ruas + telapak) dan tulang pupil. `hero.glb` lama (17 tulang) kini dipasca-proses oleh `tools/rig/add_fingers.py` (sumber lama: `tools/rig/hero_v1_backup.glb`):

- **Tangan baru**: plat tangan kotak dibuang, diganti telapak + 4 jari x 2 ruas + jempol x 2 ruas per tangan, **semua bertulang** (`f0_l_a`, `f0_l_b` ... `th_l_a`, `th_l_b`, sisi kanan `_r`). Total 39 sendi. Geometri jari buatan sendiri (kotak, mengikuti gaya blok), bukan salinan mesh jari Prisma (letaknya di rig asli adalah kepalan tertutup yang tidak bisa dibuka).
- **Genggaman**: `CharacterRig.set_grip("r"/"l", 0..1)`; otomatis 1.0 saat memegang senjata, santai (0.35) bila kosong. Gagang senjata sekarang tepat di pusat kepalan (`GRIP_X/Y/Z` di `character_rig.gd`).
- **Mata**: dua sendi `eye_l/eye_r`; kuad mata menempel di bidang wajah (z=0.29, dulu 0.455 sehingga melayang saat dilihat dari samping). Kedip = skala Y tulang, melirik acak = geser tulang (`set_eye_state`).
- **Ayunan pedang** (`attack_sword1/2`): pose dihitung lewat FK + optimasi (bilah tidak lagi menembus tanah/kaki, tangan tetap di depan badan) dan ada kunci tengah busur. Alat bantu: `tools/blade_probe.tscn` (cetak arah bilah per frame), `tools/preview_anims.tscn --anims=... --hero=ren --rigyaw=`.

## Multiplayer Co-op (WiFi / Hotspot)

Menu **Lainnya → Multiplayer**. Semua pemain harus di WiFi/hotspot yang sama (HP host boleh yang menyalakan hotspot).
- **Buat Room**: nama room, password (opsional), stage. Room disiarkan lewat UDP broadcast (port 47777); game ENet di port 47778. Maks 4 pemain.
- **Gabung**: daftar room otomatis (ikon kunci bila berpassword) atau ketik IP host manual (cadangan bila broadcast diblokir hotspot). Password salah / room penuh / game sudah mulai / versi beda → ditolak dengan pesan.
- **Ruang tunggu**: daftar pemain, host memilih stage lalu **Mulai!**.
- **Di dalam stage**: host menjalankan AI musuh, gelombang, bos, hasil (otoritatif, HP musuh x(1+0.6 per pemain tambahan)); client menjalankan pemain sendiri, mengirim posisi & damage (RPC), melihat musuh sebagai puppet dari snapshot 10 Hz; pemain lain tampil sebagai ghost bernama; musuh menarget pemain terdekat yang hidup; semua pingsan = kalah, satu hidup = pemain lain menonton; host putus → client kembali ke lobi.
- Kode: `autoload/net.gd` (room, password, RPC), `scripts/net/coop_sync.gd`, `scripts/net/coop_ghost.gd`, `scripts/ui/panels/multiplayer_panel.gd`; izin Android INTERNET/ACCESS_NETWORK_STATE/ACCESS_WIFI_STATE/CHANGE_WIFI_MULTICAST_STATE sudah di `export_presets.cfg`.
- Uji: `tools/coop_test.tscn` (dua proses di satu mesin, loopback: penemuan room, password salah, gabung, mulai, damage client→host, selesai).
- **Batas jujur**: PVP belum ada (ditunda). Belum diuji di dua HP sungguhan / hotspot sungguhan. Telegraph lingkaran serangan musuh tidak terlihat di client (hanya kilat peringatan). Password tidak mengenkripsi lalu lintas (cukup untuk LAN pribadi). Setelah stage selesai, room tetap ada dan host bisa memulai lagi dari panel.

## Mata kotak (pixel)
Mata kotak SOLID (tanpa lubang transparan): sklera lavender, iris besar bergradasi warna karakter, pupil, kilau, garis bulu mata tebal; ukuran besar ala skin Minecraft populer. Generator: `tools/gen_eyes_box.py`; tekstur anime sebelumnya ada di `tools/eyes_old/`. Kedip & lirikan lewat bone mata.

## Mata per karakter + kilau skill
Tiap karakter punya gaya mata sendiri (bentuk kelopak, lebar iris, pupil bulat/celah, jenis kilau, warna) lewat `tools/gen_eyes_box.py`. Saat skill/ULT mata bersinar sesaat (`eye_glow` di `character_looks.gd`, dipicu `CharacterRig.play_action("skill")`).

## Rambut berlapis (semua karakter + NPC)
`CharacterLooks._hair_volume` menambah poni berlapis, rambut samping, lapisan belakang bergoyang, jambul (Ren) dan ekor (Sera, Ember) di atas rambut bawaan skin; gaya per karakter di `HAIR_STYLE`. NPC memakai warna rambut hasil sampling skin dan kini juga punya mata. Hakuya/Wenyu/Kuroha tetap memakai rambut khusus mereka. Musuh humanoid (berkerudung/bertopeng) belum diubah.

## PVP (WiFi / Hotspot)
Di menu **Multiplayer**, pilih arena `PVP · ...` (Padang Duel, Hutan Bayangan, Gua Kristal, Aula Marmer) saat membuat room / sebagai host. Semua pemain di room (2-4) langsung bertarung: hitung mundur 3-2-1, lalu tanpa musuh. Serangan basic, skill, proyektil dan ULT mengenai pemain lain. Damage antar pemain = damage normal x0.5 (`Stage.PVP_SCALE`). Pemain tersingkir bila seluruh party-nya pingsan; pertandingan selesai saat tersisa 1 pemain atau waktu 150 dtk habis (menang = kill terbanyak di antara yang hidup; imbang = SERI). Tidak ada hadiah/EXP (arena PVP bukan stage petualangan).
- Model: tiap pemain menghitung damage serangannya sendiri, dikirim lewat host (`Net._pvp_hit` → `_pvp_hurt`); host mengatur skor, waktu, dan akhir pertandingan. Lag/curang tidak dicegah (tidak ada server otoritatif penuh).
- Uji: `tools/coop_test.gd` dengan `--stage=pvp_meadow` (dua proses, loopback). Bot menempel ke lawan agar fokus menguji rute damage; gerak/akurasi arah asli belum diuji di HP.

## Optimasi perangkat ringan (tahap lanjut)
- Pengaturan tidak lagi memuat sebutan kelas perangkat; ringkasan memakai "Kualitas otomatis".
- Kualitas Lancar: NPC & warga yang jauh dari kamera (>42 m) disembunyikan dan animasinya dihentikan; rambut NPC dilewati; helai rambut lebih sedikit; kilau mata disembunyikan secara default.
- Angka perf hanya dari rasterizer software (relatif), belum diuji di perangkat asli.

## PVP duel 1v1 (perbaikan)
- PVP kini duel 2 pemain (room PVP maks. 2), jadi pilihan teratas di menu Multiplayer ("[DUEL 1v1]"); co-op tetap ada ("[CO-OP]", maks. 4).
- Efek tebasan/skill/proyektil pemain lain kini terlihat (`Stage.ghost_fx`, visual saja; damage tetap dihitung penyerang).
- Match langsung selesai bila lawan keluar; klien yang lambat memuat stage tetap ikut mulai (sinkron lewat skor); host menunggu hingga 30 dtk.

## Peta stage lebih luas, jarak render, rekor PVP, poles Menu
- **Jarak render (chunk)**: Pengaturan → Grafis → "Jarak render": Otomatis / 6 / 9 / 12 chunk (1 chunk = 16 m). Otomatis = 6 (Lancar), 9 (Sedang), 12 (Bagus). Jarak ini juga menentukan seberapa jauh pemandangan di luar arena dibangun.
- **Arena diperbesar 1,3x** (`StageArena.R_SCALE`) dan dunia di luar arena diisi: gunung bersalju, bukit, hutan jauh, danau (padang/hutan); dinding gua, stalaktit & kristal (gua/sarang); pagoda, lentera & pegunungan (kuil); pulau melayang & menara pilar (jurang/rantai/bos). Tiap objek jauh berkurang di kualitas Lancar. Alat: `tools/arena_view_bot.gd` (tangkapan layar pemandangan).
- **Rekor duel PVP**: menang/kalah/seri/kill tersimpan (`GameState.record_pvp`), tampil di layar hasil, Statistik, dan Profil.
- **Poles Menu**: helper `BasePanel.section/info_row` (gaya kartu Pengaturan); Profil & Quest ditata ulang, daftar gulir tidak lagi menutupi kartu; menu "Co-op WiFi" menjadi "Multiplayer".


## Aion – manipulasi waktu (karakter ★5 baru)
- Desain orisinal: rambut putih disisir miring dengan kuncir rendah berklip emas, mata heterokromia (ungu & hijau), mantel panjang putih-hitam ramping dengan pelindung bahu bersudut, jubah pendek asimetris, dasi pita teal & bros jam emas, tongkat berhias cincin jam (versi ramping: stola bulu, simpul bulat, sanggul & anting sudah dihapus). Skin `tools/gen_skins.py`, mata `tools/gen_eyes_box.py` (`aion`, `aion_r`), model `CharacterLooks._aion/_clock_staff`.
- Seimbang (tidak OP): HP/ATK di bawah Vael & Lucien, serangan dasar lambat-sedang (`attack_mult` 0,85), skill cooldown 8 dtk. Kekuatan utamanya kontrol, bukan damage:
  - **Jeda Waktu** (skill): damage 1,7x + slow 50% (3,5 dtk). Slow tidak menumpuk; bos hanya melambat maksimal 40% (faktor ≥ 0,6).
  - **Putaran Jam Raya** (ULT): musuh dalam jangkauan melambat 80% selama 3 dtk, tujuh serpihan jarum jam jatuh + ledakan penutup (mult 7, lebih rendah dari ULT lain).
- Mekanik `Enemy.apply_slow(factor, dur)`: skala waktu lokal (gerak, serangan, animasi), semburat biru + cincin jam kecil di kaki.
- Efek: `scripts/stages/chrono_fx.gd` (wajah jam, jarum, cipratan tinta, gagak), tekstur buatan `tools/gen_clock_art.py` (`clock_face.png`, `ink_splash.png`). Pool gacha ★5: Vael, Lucien, Aion.
- Batasan: slow hanya mempengaruhi AI musuh di sisi host; klien co-op melihat tandanya saja; PVP tidak memperlambat lawan. Belum diuji di perangkat nyata.


## Musuh lebih tangguh & lebih bagus
- **Keluhan:** musuh mudah dikalahkan, HP sedikit, tampilan kurang bagus.
- **HP/ATK:** musuh biasa HP ×2,6 & ATK ×1,2; bos HP ×1,8 & ATK ×1,1 (konstanta `HP_MULT_*`/`ATK_MULT_*` di `enemy.gd`). Kecepatan naik 2,5% per level rekomendasi.
- **Poise:** pukulan kecil tidak lagi membatalkan aba-aba serangan musuh (dulu setiap pukulan membuat musuh terpental/stagger). Hanya pukulan ≥ 28% HP maks yang memotong, dan setelah stagger ada kekebalan 0,9 dtk (tidak bisa di-stunlock).
- **Lebih agresif:** pemulihan musuh biasa 25% lebih cepat, serangan menukik kelelawar lebih sering, terjang slime lebih cepat.
- **Slime pecah:** slime mati → dua Slime Kecil (HP kecil, cepat) muncul.
- **Musuh ELIT:** sebagian musuh gelombang (10% + 5% per gelombang, maks 35%) jadi elit: HP ×2, ATK ×1,3, DEF +1, lebih besar, berpendar emas, label "ELIT", bar HP emas selalu tampak, tidak terpotong serangannya.
- **Tampilan:** slime punya 3 warna (hijau/biru/merah muda), inti berpendar, kilap, gelembung, pipi, jambul; kelelawar punya taring & dada terang. Elit pada klien co-op belum ditandai (host yang menentukan).
- Uji: `tools/enemy_look_bot.gd` (statistik, poise, slime pecah, foto close-up).


## Perbaikan logika: rumah tembus pandang, gerak, goresan pedang
- **Rumah tembus pandang saat didekati:** penyebabnya kotak bangunan diperbesar 0,3 m sebelum dites terhadap garis kamera→kepala, sehingga berdiri dekat dinding saja sudah membuat bangunan memudar. Sekarang kotak diperkecil 0,25 m dan garis harus menembus bangunan minimal 0,8 m sebelum sampai ke pemain (`segment_hits_aabb(..., end_margin)`). Bangunan hanya memudar bila benar-benar berada di antara kamera dan pemain. Uji: `tools/occlusion_bot.gd`.
- **Gerak & gravitasi** (`player.gd`): percepatan 46 m/s² dan perlambatan 60 m/s² (tidak lagi langsung loncat ke kecepatan penuh / berhenti mendadak), kontrol di udara 35%, jatuh 1,35× lebih berat dengan kecepatan jatuh maksimum 38 m/s, menempel ke lantai lebih kuat (turun lereng tidak melayang), bergerak sambil menyerang 45% (dulu 35%). Uji: `tools/gerak_bot.gd`.
- **Goresan/“salinan” pedang di belakang karakter:** pita jejak bilah (`BladeTrail`) dulu menyimpan titik 0,26 dtk dan menutupi seluruh panjang bilah, sehingga saat diayun ia tertinggal seperti bayangan pedang. Kini hidup 0,15 dtk, hanya sepertiga ujung bilah, memudar lebih cepat; pita "ujung tebasan" di tanah dibuat lebih tipis dan tidak seputih sebelumnya. Penyebab pasti di perangkat nyata belum bisa direproduksi di PC (hanya diverifikasi lewat tangkapan layar), jadi mohon dicek ulang di HP.

## Audit bug & optimasi untuk Android (Back, Party, HUD)

Perbaikan (semua diuji bot di Godot 4.3 + GL virtual; **belum diuji di HP sungguhan**):
- **Tombol Back Android menutup seluruh game.** `application/config/quit_on_go_back` masih `true` (bawaan), dan Back tidak menghasilkan event keyboard sehingga menu/jeda tak pernah tersambung. Kini `quit_on_go_back=false`; `Flow` mengubah notifikasi Back menjadi aksi `menu_back` (panel menutup, stage jeda/lanjut). Di lobi/judul tanpa panel: Back dua kali dalam 2 detik untuk keluar. Handler Back ganda di `PanelHost` dihapus. Uji: `tools/back_party_bot.gd`, `tools/back_stage_bot.gd`.
- **Save dengan party > 4** kini dipotong ke `PARTY_SIZE` saat dimuat. `set_party_slot` ke slot yang sama tidak lagi memancarkan sinyal/menyimpan.
- **Urutan roster Party tidak stabil** saat rarity/kekuatan sama (kartu bisa melompat); kini urut nama lalu id.
- **`InputSetup.ensure()`** menambah event gamepad/stik berulang tiap pindah scene; kini sekali.
- **Potret yang gagal dirender** tak lagi dicoba ulang tiap panel dibuka (`Portraits._failed`).

Optimasi (angka dari 1 CPU + llvmpipe, bandingkan rasio, bukan angka mutlak; bot: `tools/party_perf_bot.gd`, `tools/hud_perf_bot.gd`):
- Panel Party: kekuatan dihitung sekali per refresh; refresh dipecah (slot/roster/bar); gradien & StyleBox dipakai bersama. Ketuk slot 67 -> 24 ms. Refresh penuh tetap ~68 ms (didominasi pembuatan node).
- Potret 3D yang selesai dirender kini mengisi **hanya kartunya** (`_on_portrait_ready`), bukan membangun ulang seluruh panel: saat Party pertama dibuka, `refresh()` penuh 17x -> 1x (terukur dengan `tools/party_open_bot.gd`; total waktu muat dominan oleh render potret).
- `BasePanel.queue_refresh()`: beberapa sinyal dalam satu frame = satu refresh (dulu satu per sinyal).
- `StageHud.update_party`: StyleBox kartu dibuat sekali, bukan 4 objek baru tiap 0,1 dtk (0,164 -> 0,010 ms per panggilan).
- `Enemy._separate` (tiap musuh tiap frame fisika) memakai jarak kuadrat: hasil identik (checksum sama), 0,291 -> 0,181 ms per frame untuk 24 musuh (-38%). `Projectile` tidak lagi membuat array gabungan tiap frame bila tak ada pemain ghost (co-op/PVP). Bot ukur: `tools/sep_perf_bot.gd`.
- CI: langkah **APK RILIS** opsional (`buildapk.yml`), jalan bila Secrets `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEY_ALIAS`, `ANDROID_KEYSTORE_PASSWORD` diisi. Belum pernah dijalankan.

Catatan: `tools/scroll_bot.gd` (cek inersia) tidak stabil di mesin 1 CPU (gagal acak juga di kode sebelum perubahan). Play Store butuh AAB (Gradle build) dan keystore rilis; proyek ini belum disiapkan untuk AAB.

Catatan uji: `tools/charfx_bot.gd` (batas 160 node efek) juga tidak stabil di mesin 1 CPU: puncak Zeya berkisar 118-220 pada kode sebelum perubahan. Opsi yang sengaja TIDAK dipasang karena belum bisa diuji di HP: `physics/common/max_physics_steps_per_frame` lebih kecil dari 8 (mencegah spiral fisika di HP lambat, tapi game melambat di bawah ~15 fps).
