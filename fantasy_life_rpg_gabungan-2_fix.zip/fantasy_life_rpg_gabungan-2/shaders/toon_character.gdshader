shader_type spatial;
// Shader karakter bergaya anime: bayangan berundak (cel shading), cahaya tepi (rim), dan kilatan saat terkena serangan.
// Dipakai untuk semua karakter berkulit (MC, party, NPC). Tekstur memakai filter nearest agar piksel tetap tajam.
render_mode cull_back, diffuse_lambert, specular_disabled;

uniform sampler2D skin : source_color, filter_nearest, repeat_disable;
uniform vec4 tint : source_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform vec4 flash : source_color = vec4(1.0, 1.0, 1.0, 0.0);      // a = kekuatan kilatan
uniform vec4 rim_color : source_color = vec4(0.75, 0.88, 1.0, 1.0);
uniform float rim_power = 2.6;
uniform float rim_strength = 0.30;
uniform float shade_soft = 0.16;     // kelembutan batas bayangan
uniform float ambient_lift = 0.0;    // tambahan terang untuk sisi gelap

void fragment() {
	vec4 t = texture(skin, UV);
	ALPHA_SCISSOR_THRESHOLD = 0.5;
	ALPHA = t.a;
	ALBEDO = t.rgb * COLOR.rgb * tint.rgb;
	ROUGHNESS = 1.0;
	float rim = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), rim_power);
	EMISSION = rim_color.rgb * rim * rim_strength + flash.rgb * flash.a + ALBEDO * ambient_lift;
}

void light() {
	float ndl = dot(NORMAL, LIGHT);
	float band1 = smoothstep(-0.05, shade_soft, ndl);
	float band2 = smoothstep(0.55, 0.55 + shade_soft, ndl);
	float toon = 0.62 * band1 + 0.38 * band2;
	DIFFUSE_LIGHT += LIGHT_COLOR * ATTENUATION * toon / PI;
}
