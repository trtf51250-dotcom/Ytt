shader_type spatial;
// Dedaunan/rumput/bunga/spanduk: dua sisi, alpha scissor, goyang tertiup angin.
render_mode cull_disabled, diffuse_lambert, specular_disabled;
#include "res://shaders/world_common.gdshaderinc"

void vertex() {
	v_tile = UV2.x;
	world_vertex(VERTEX, UV2, MODEL_MATRIX);
}

void fragment() {
	vec4 t = world_sample(UV);
	ALPHA_SCISSOR_THRESHOLD = 0.5;
	ALPHA = t.a;
	ALBEDO = grade(t.rgb * COLOR.rgb);
	ROUGHNESS = 1.0;
	EMISSION = ALBEDO * (1.0 - COLOR.a) * glow;
	if (!FRONT_FACING) {
		NORMAL = -NORMAL;
	}
}
