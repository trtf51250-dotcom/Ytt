shader_type spatial;
// Sama dengan world.gdshader, tetapi bisa memudar (dither) saat bangunan menutupi pemain.
render_mode cull_back, diffuse_lambert, specular_disabled;
#include "res://shaders/world_common.gdshaderinc"

uniform float fade = 1.0;

void vertex() {
	v_tile = UV2.x;
	world_vertex(VERTEX, UV2, MODEL_MATRIX);
}

void fragment() {
	float ign = fract(52.9829189 * fract(dot(FRAGCOORD.xy, vec2(0.06711056, 0.00583715))));
	if (fade < ign) {
		discard;
	}
	vec4 t = world_sample(UV);
	ALBEDO = grade(t.rgb * COLOR.rgb);
	ROUGHNESS = 1.0;
	EMISSION = ALBEDO * (1.0 - COLOR.a) * glow;
}
