shader_type spatial;
// Pusaran portal petualangan: cakram bercahaya berputar (aditif, tanpa pencahayaan).
render_mode unshaded, blend_add, cull_disabled, depth_draw_never;

uniform vec4 col_a : source_color = vec4(0.30, 0.58, 1.0, 1.0);
uniform vec4 col_b : source_color = vec4(0.82, 0.5, 1.0, 1.0);
uniform float speed = 1.0;

void fragment() {
	vec2 p = UV * 2.0 - 1.0;
	float r = length(p);
	float a = atan(p.y, p.x);
	float s1 = sin(a * 4.0 + r * 11.0 - TIME * 2.6 * speed) * 0.5 + 0.5;
	float s2 = sin(a * 3.0 - r * 8.0 + TIME * 1.7 * speed) * 0.5 + 0.5;
	vec3 c = mix(col_a.rgb, col_b.rgb, s1 * s2);
	float edge = smoothstep(1.0, 0.8, r);
	float core = smoothstep(0.0, 0.55, r);
	float ripple = 0.55 + 0.45 * sin(r * 22.0 - TIME * 4.0 * speed);
	ALBEDO = c * (0.55 + 0.7 * s1) * (0.75 + 0.25 * ripple);
	ALPHA = edge * (0.25 + 0.75 * core) * 0.85;
}
