shader_type spatial;
// Material dunia utama (opaque): atlas tekstur + warna vertex + emisi + goyangan angin.
render_mode cull_back, diffuse_lambert, specular_disabled;
#include "res://shaders/world_common.gdshaderinc"

void vertex() {
	v_tile = UV2.x;
	world_vertex(VERTEX, UV2, MODEL_MATRIX);
}

void fragment() {
	vec4 t = world_sample(UV);
	ALBEDO = grade(t.rgb * COLOR.rgb);
	ROUGHNESS = 1.0;
	EMISSION = ALBEDO * (1.0 - COLOR.a) * glow;
}
