shader_type spatial;
// Aksesori karakter (jubah, senjata, topi): warna dari vertex color, bayangan berundak seperti toon_character.
// COLOR.a = 1 - emisi. UV2.y > 0 = bobot goyangan kain (jubah/syal) di ruang model.
render_mode cull_disabled, diffuse_lambert, specular_disabled;

uniform float sway_amp = 0.035;
uniform float rim_strength = 0.22;
uniform float shade_soft = 0.16;
uniform float flash_amount : hint_range(0.0, 1.0) = 0.0;
uniform vec3 flash_color : source_color = vec3(1.0, 1.0, 1.0);

void vertex() {
	if (UV2.y > 0.0) {
		float t = TIME * 2.6 + VERTEX.y * 3.0;
		VERTEX.x += sin(t) * sway_amp * UV2.y;
		VERTEX.z += cos(t * 0.8 + 1.0) * sway_amp * 0.6 * UV2.y;
	}
}

void fragment() {
	ALBEDO = COLOR.rgb;
	ROUGHNESS = 1.0;
	float rim = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 2.6);
	EMISSION = vec3(0.75, 0.88, 1.0) * rim * rim_strength + COLOR.rgb * (1.0 - COLOR.a) * 0.9 + flash_color * flash_amount;
	if (!FRONT_FACING) {
		NORMAL = -NORMAL;
	}
}

void light() {
	float ndl = dot(NORMAL, LIGHT);
	float band1 = smoothstep(-0.05, shade_soft, ndl);
	float band2 = smoothstep(0.55, 0.55 + shade_soft, ndl);
	float toon = 0.62 * band1 + 0.38 * band2;
	DIFFUSE_LIGHT += LIGHT_COLOR * ATTENUATION * toon / PI;
}
