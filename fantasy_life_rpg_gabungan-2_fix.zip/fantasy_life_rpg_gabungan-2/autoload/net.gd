extends Node
## Autoload "Net": multiplayer lewat WiFi / hotspot (jaringan lokal, tanpa server internet).
##  - Host membuka room (nama + password opsional) di port UDP 47778 (ENet) dan menyiarkan pengumuman UDP broadcast di port 47777.
##  - Client mencari room otomatis (daftar) atau bergabung manual lewat IP, lalu mengirim hash password. Host menolak bila salah / penuh / sudah mulai.
##  - Semua RPC berada di sini (satu path /root/Net di semua perangkat); logika permainan ada di CoopSync (anak Stage).
## Catatan jujur: password hanya mencegah orang tak sengaja masuk; lalu lintas ENet tidak dienkripsi (cukup untuk LAN/hotspot pribadi).

signal rooms_changed
signal members_changed
signal state_changed
signal join_failed(reason: String)
signal left_room(reason: String)

const PORT := 47778
const DISC_PORT := 47777
const MAX_PLAYERS := 4
const VERSION := 1
const TAG := "FLRPG"

var mode := "none"                 # none | host | client
var room_name := ""
var host_name := ""
var selected_stage := ""
var members: Dictionary = {}       # peer_id -> {"name", "char"}
var rooms: Dictionary = {}         # "ip:port" -> {room, host, ip, port, lock, n, max, stage, started, seen}
var session_started := false       # true sejak _begin diterima sampai kembali ke lobby
var in_stage := false
var coop: Node                     # CoopSync milik Stage yang sedang berjalan
var connected_ok := false          # client: sudah lolos autentikasi
var _hash := ""
var _authed: Dictionary = {}
var _pending_hash := ""
var _send: PacketPeerUDP
var _listen: PacketPeerUDP
var _bc_t := 0.0
var _searching := false
var _tx_ready := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_conn_failed)
	multiplayer.server_disconnected.connect(_on_server_gone)


# ---------------------------------------------------------------- util
static func make_hash(pw: String) -> String:
	return "" if pw == "" else (pw + "|" + TAG + str(VERSION)).sha256_text()


static func local_ips() -> Array:
	var out: Array = []
	for a in IP.get_local_addresses():
		var s := str(a)
		if s.count(".") == 3 and not s.begins_with("127.") and not s.begins_with("169.254."):
			out.append(s)
	return out


func coop_active() -> bool:
	return mode != "none" and session_started


## PVP = duel 1 lawan 1 (2 pemain); co-op sampai 4 pemain.
func max_players() -> int:
	return 2 if is_pvp() else MAX_PLAYERS


func is_pvp() -> bool:
	return selected_stage.begins_with("pvp_")


func my_char() -> String:
	return str(GameState.party[0]) if not GameState.party.is_empty() else "ren"


func member_count() -> int:
	return members.size()


func is_host() -> bool:
	return mode == "host"


func my_id() -> int:
	return multiplayer.get_unique_id() if multiplayer.multiplayer_peer != null else 1


# ---------------------------------------------------------------- host
func host_room(rname: String, pw: String, stage_id: String) -> String:
	close_room("")
	rname = rname.strip_edges()
	if rname == "":
		rname = "Room %s" % GameState.player_name
	var p := ENetMultiplayerPeer.new()
	var err := p.create_server(PORT, MAX_PLAYERS - 1)
	if err != OK:
		return "Gagal membuka room (port %d dipakai?)" % PORT
	multiplayer.multiplayer_peer = p
	mode = "host"
	room_name = rname
	host_name = GameState.player_name
	_hash = make_hash(pw)
	selected_stage = stage_id
	members = {1: {"name": GameState.player_name, "char": my_char()}}
	_authed.clear()
	session_started = false
	in_stage = false
	_open_sender()
	state_changed.emit()
	members_changed.emit()
	return ""


func set_stage(stage_id: String) -> void:
	selected_stage = stage_id
	if mode == "host":
		_set_stage.rpc(stage_id)
	members_changed.emit()


func start_game() -> String:
	if mode != "host":
		return "Hanya host yang bisa memulai"
	if Data.stage(selected_stage) == null:
		return "Pilih stage dulu"
	in_stage = true
	for id in _authed:
		_begin.rpc_id(id, selected_stage)
	_begin_local(selected_stage)
	return ""


func _begin_local(stage_id: String) -> void:
	session_started = true
	in_stage = true
	Flow.start_stage(stage_id)


# ---------------------------------------------------------------- client
func join_room(ip: String, port: int, pw: String) -> String:
	close_room("")
	if ip.strip_edges() == "":
		return "Isi alamat IP host"
	var p := ENetMultiplayerPeer.new()
	var err := p.create_client(ip.strip_edges(), port)
	if err != OK:
		return "Tidak bisa terhubung ke %s" % ip
	multiplayer.multiplayer_peer = p
	mode = "client"
	connected_ok = false
	_pending_hash = make_hash(pw)
	members = {}
	session_started = false
	state_changed.emit()
	return ""


func back_to_lobby() -> void:
	session_started = false
	in_stage = false
	if mode == "host":
		_push_members()
	members_changed.emit()


func close_room(reason: String) -> void:
	var was := mode
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null
	mode = "none"
	connected_ok = false
	session_started = false
	in_stage = false
	members = {}
	_authed.clear()
	_close_sender()
	state_changed.emit()
	members_changed.emit()
	if was != "none":
		left_room.emit(reason)


func _on_connected() -> void:
	_srv_auth.rpc_id(1, GameState.player_name, my_char(), _pending_hash, VERSION)


func _on_conn_failed() -> void:
	close_room("")
	join_failed.emit("Gagal terhubung (cek WiFi/hotspot & IP)")


func _on_server_gone() -> void:
	var was_stage := in_stage
	close_room("Host terputus")
	if was_stage and coop != null and is_instance_valid(coop):
		coop.on_host_lost()


func _on_peer_connected(_id: int) -> void:
	pass


func _on_peer_disconnected(id: int) -> void:
	if mode != "host":
		return
	_authed.erase(id)
	if members.erase(id):
		_push_members()
		members_changed.emit()
	if coop != null and is_instance_valid(coop):
		coop.on_peer_left(id)


func _push_members() -> void:
	for id in _authed:
		_members.rpc_id(id, members, selected_stage)


# ---------------------------------------------------------------- RPC: lobi room
@rpc("any_peer", "call_remote", "reliable")
func _srv_auth(pname: String, ch: String, h: String, ver: int) -> void:
	if mode != "host":
		return
	var id := multiplayer.get_remote_sender_id()
	var why := ""
	if ver != VERSION:
		why = "Versi game berbeda"
	elif h != _hash:
		why = "Password salah"
	elif in_stage:
		why = "Permainan sudah dimulai"
	elif members.size() >= max_players():
		why = "Room penuh"
	if why != "":
		_auth_fail.rpc_id(id, why)
		await get_tree().create_timer(0.4).timeout
		if multiplayer.multiplayer_peer != null and id in multiplayer.get_peers():
			multiplayer.multiplayer_peer.disconnect_peer(id)
		return
	_authed[id] = true
	members[id] = {"name": pname.left(16), "char": ch}
	_auth_ok.rpc_id(id, room_name, host_name)
	_push_members()
	members_changed.emit()


@rpc("authority", "call_remote", "reliable")
func _auth_ok(rname: String, hname: String) -> void:
	connected_ok = true
	room_name = rname
	host_name = hname
	state_changed.emit()


@rpc("authority", "call_remote", "reliable")
func _auth_fail(reason: String) -> void:
	var m := mode
	close_room("")
	if m == "client":
		join_failed.emit(reason)


@rpc("authority", "call_remote", "reliable")
func _members(m: Dictionary, stage_id: String) -> void:
	members = m
	selected_stage = stage_id
	members_changed.emit()


@rpc("authority", "call_remote", "reliable")
func _set_stage(stage_id: String) -> void:
	selected_stage = stage_id
	members_changed.emit()


@rpc("authority", "call_remote", "reliable")
func _begin(stage_id: String) -> void:
	_begin_local(stage_id)


# ---------------------------------------------------------------- RPC: dalam stage (diteruskan ke CoopSync)
@rpc("any_peer", "call_remote", "reliable")
func _peer_ready() -> void:
	if mode == "host" and coop != null and _authed.has(multiplayer.get_remote_sender_id()):
		coop.on_peer_ready(multiplayer.get_remote_sender_id())


@rpc("any_peer", "call_remote", "unreliable_ordered")
func _pstate(a: Array) -> void:
	if mode == "host" and coop != null and _authed.has(multiplayer.get_remote_sender_id()):
		coop.on_pstate(multiplayer.get_remote_sender_id(), a)


@rpc("authority", "call_remote", "unreliable_ordered")
func _snap(enemies: Array, players: Dictionary, meta: Array) -> void:
	if coop != null:
		coop.on_snap(enemies, players, meta)


@rpc("authority", "call_remote", "reliable")
func _spawn(id: int, kind: String, pos: Vector3, max_hp: int) -> void:
	if coop != null:
		coop.on_spawn(id, kind, pos, max_hp)


@rpc("authority", "call_remote", "reliable")
func _edead(id: int) -> void:
	if coop != null:
		coop.on_enemy_dead(id)


@rpc("any_peer", "call_remote", "reliable")
func _hit(id: int, dmg: int, from: Vector3, knock: float, crit: bool) -> void:
	if mode == "host" and coop != null and _authed.has(multiplayer.get_remote_sender_id()):
		coop.on_client_hit(multiplayer.get_remote_sender_id(), id, dmg, from, knock, crit)


@rpc("authority", "call_remote", "reliable")
func _hurt(dmg: int, from: Vector3) -> void:
	if coop != null:
		coop.on_hurt(dmg, from)


@rpc("authority", "call_remote", "reliable")
func _event(ev: String, data: Array) -> void:
	if coop != null:
		coop.on_event(ev, data)


@rpc("any_peer", "call_remote", "reliable")
func _pvp_hit(target: int, dmg: int, from: Vector3) -> void:
	if mode == "host" and coop != null and _authed.has(multiplayer.get_remote_sender_id()):
		coop.on_pvp_hit(multiplayer.get_remote_sender_id(), target, dmg, from)


@rpc("authority", "call_remote", "reliable")
func _pvp_hurt(attacker: int, dmg: int, from: Vector3) -> void:
	if coop != null:
		coop.on_pvp_hurt(attacker, dmg, from)


@rpc("any_peer", "call_remote", "reliable")
func _pvp_down(attacker: int) -> void:
	if mode == "host" and coop != null and _authed.has(multiplayer.get_remote_sender_id()):
		coop.on_pvp_down(multiplayer.get_remote_sender_id(), attacker)


@rpc("any_peer", "call_remote", "reliable")
func _action(kind: String) -> void:
	if mode == "host" and coop != null and _authed.has(multiplayer.get_remote_sender_id()):
		coop.on_action(multiplayer.get_remote_sender_id(), kind)


@rpc("authority", "call_remote", "reliable")
func _gaction(peer: int, kind: String) -> void:
	if coop != null:
		coop.on_ghost_action(peer, kind)


# ---------------------------------------------------------------- penemuan room (UDP broadcast)
func _open_sender() -> void:
	_send = PacketPeerUDP.new()
	_send.set_broadcast_enabled(true)
	_tx_ready = true
	_bc_t = 0.0


func _close_sender() -> void:
	if _send != null:
		_send.close()
		_send = null
	_tx_ready = false


func start_search() -> void:
	if _searching:
		return
	_listen = PacketPeerUDP.new()
	_listen.set_broadcast_enabled(true)
	var err := _listen.bind(DISC_PORT, "*")
	if err != OK:
		_listen = null
		return
	_searching = true
	rooms.clear()
	rooms_changed.emit()


func stop_search() -> void:
	_searching = false
	if _listen != null:
		_listen.close()
		_listen = null


func is_searching() -> bool:
	return _searching


func _announce() -> void:
	var pkt := JSON.stringify({"t": TAG, "v": VERSION, "room": room_name, "host": host_name, "port": PORT, "lock": _hash != "",
		"n": members.size(), "max": max_players(), "stage": selected_stage, "started": in_stage}).to_utf8_buffer()
	var targets: Array = ["255.255.255.255", "127.0.0.1"]
	for ip in local_ips():
		var parts: PackedStringArray = str(ip).split(".")
		targets.append("%s.%s.%s.255" % [parts[0], parts[1], parts[2]])      # broadcast subnet /24 (hotspot sering memblokir 255.255.255.255)
	for t in targets:
		_send.set_dest_address(t, DISC_PORT)
		_send.put_packet(pkt)


func _process(delta: float) -> void:
	if mode == "host" and _tx_ready and _send != null:
		_bc_t -= delta
		if _bc_t <= 0.0:
			_bc_t = 1.0
			_announce()
	if _searching and _listen != null:
		var changed := false
		while _listen.get_available_packet_count() > 0:
			var data := _listen.get_packet().get_string_from_utf8()
			var ip := _listen.get_packet_ip()
			var j: Variant = JSON.parse_string(data)
			if typeof(j) != TYPE_DICTIONARY or str(j.get("t", "")) != TAG:
				continue
			var key := "%s:%d" % [ip, int(j.get("port", PORT))]
			var is_new := not rooms.has(key)
			rooms[key] = {"room": str(j.get("room", "?")), "host": str(j.get("host", "?")), "ip": ip, "port": int(j.get("port", PORT)),
				"lock": bool(j.get("lock", false)), "n": int(j.get("n", 1)), "max": int(j.get("max", MAX_PLAYERS)), "stage": str(j.get("stage", "")),
				"started": bool(j.get("started", false)), "seen": Time.get_ticks_msec(), "ver": int(j.get("v", 0))}
			changed = changed or is_new
		var now := Time.get_ticks_msec()
		for k in rooms.keys():
			if now - int(rooms[k]["seen"]) > 4500:
				rooms.erase(k)
				changed = true
		if changed or Engine.get_process_frames() % 30 == 0:
			rooms_changed.emit()
