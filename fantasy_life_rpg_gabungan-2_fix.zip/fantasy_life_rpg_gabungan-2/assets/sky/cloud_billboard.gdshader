shader_type spatial;
render_mode unshaded, blend_mix, depth_draw_never, cull_disabled, fog_disabled;
// Awan sprite: selalu menghadap kamera, memudar bila dekat kamera / terlalu jauh dari pusat.
uniform sampler2D tex : source_color, filter_linear;
uniform vec4 tint : source_color = vec4(1.0);
uniform float fade_near = 40.0;
uniform float fade_far = 110.0;
uniform float opacity = 0.9;
varying float vfade;
void vertex() {
	vec3 sc = vec3(length(MODEL_MATRIX[0].xyz), length(MODEL_MATRIX[1].xyz), length(MODEL_MATRIX[2].xyz));
	mat4 bb = mat4(INV_VIEW_MATRIX[0], INV_VIEW_MATRIX[1], INV_VIEW_MATRIX[2], MODEL_MATRIX[3]);
	bb[0] *= sc.x;
	bb[1] *= sc.y;
	bb[2] *= sc.z;
	MODELVIEW_MATRIX = VIEW_MATRIX * bb;
	vec3 wp = MODEL_MATRIX[3].xyz;
	vfade = smoothstep(fade_near, fade_far, length(wp - CAMERA_POSITION_WORLD));
}
void fragment() {
	vec4 c = texture(tex, UV);
	ALBEDO = c.rgb * tint.rgb;
	ALPHA = c.a * opacity * vfade * tint.a;
}
