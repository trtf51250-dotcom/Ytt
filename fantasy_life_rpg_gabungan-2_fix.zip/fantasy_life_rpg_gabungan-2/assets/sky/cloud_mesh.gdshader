shader_type spatial;
render_mode diffuse_toon, specular_disabled, shadows_disabled;
// Awan kartun 3D (gumpalan blob): warna dari vertex (atas terang, bawah abu-biru), pencahayaan toon dari matahari + sedikit emisi agar tak gelap.
uniform vec4 tint : source_color = vec4(1.0);
uniform float glow = 0.5;
void fragment() {
	vec3 c = COLOR.rgb * tint.rgb;
	ALBEDO = c;
	EMISSION = c * glow;
	ROUGHNESS = 1.0;
}
