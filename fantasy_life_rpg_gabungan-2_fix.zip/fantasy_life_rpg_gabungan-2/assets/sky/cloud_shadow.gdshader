shader_type spatial;
render_mode unshaded, blend_mix, depth_draw_never, cull_disabled, fog_disabled;
// Bayangan awan yang bergeser di tanah: dua lapis noise bergerak ke arah angin.
uniform sampler2D noise : filter_linear, repeat_enable;
uniform vec2 scroll = vec2(0.0);
uniform float strength = 0.25;
uniform vec3 shade_color : source_color = vec3(0.06, 0.1, 0.24);
uniform float scale = 0.0075;
varying vec3 wpos;
void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}
void fragment() {
	vec2 uv = wpos.xz * scale + scroll;
	float n = texture(noise, uv).r * 0.65 + texture(noise, uv * 2.3 + vec2(0.37, 0.11) - scroll * 0.4).r * 0.35;
	float m = smoothstep(0.42, 0.70, n);
	ALBEDO = shade_color;
	ALPHA = m * strength;
}
