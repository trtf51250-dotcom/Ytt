extends RefCounted
## Bot: uji 4 musuh kroco humanoid (cultist, shadow_mage, chain_knight, ronin): muncul, mengejar, menyerang (telegraf -> pukulan), kena pukul, mati.
var st: Node3D
func _w(s: float) -> void:
	await st.get_tree().create_timer(s).timeout
func run(s: Node3D) -> void:
	st = s
	await _w(1.0)
	for e in st.get_tree().get_nodes_in_group("enemies"):
		e.queue_free()
	st._pending = 0
	var fails := 0
	var base: Vector3 = st.player.global_position
	for kind in ["cultist", "shadow_mage", "chain_knight", "ronin"]:
		var e: Enemy = st._spawn_enemy(kind, base + Vector3(0, 0, -6))
		await _w(1.0)
		var ok_cls := e is HumanoidEnemy and (e as HumanoidEnemy).rig != null
		var seen := {}
		var hits := 0
		var hp0 := 0
		for ps in st.party_state:
			hp0 += int(ps["hp"])
		var t := 0.0
		var shot := false
		while t < 9.0 and not e.dead:
			await _w(0.1)
			t += 0.1
			seen[e.state + ":" + e._attack] = true
			if e.state == "windup" and not shot:
				shot = true
				await st._shot("h_%s_windup" % kind)
			for ps in st.party_state:
				ps["hp"] = maxi(int(ps["hp"]), 1)
		var hp1 := 0
		for ps in st.party_state:
			hp1 += int(ps["hp"])
		print("kind ", kind, " cls=", ok_cls, " seen=", seen.keys(), " hp_loss=", hp0 - hp1)
		var attacked := false
		for k2 in seen.keys():
			if String(k2).begins_with("windup"):
				attacked = true
		print("CHECK ", "PASS" if (ok_cls and attacked) else "FAIL", " ", kind, " mengejar & menyerang")
		if not (ok_cls and attacked):
			fails += 1
		e.take_damage(1, base, 3.0)
		await _w(0.25)
		await st._shot("h_%s_hit" % kind)
		var k0: int = st.kills
		e.take_damage(e.hp + 5, base, 3.0)
		await _w(0.3)
		var dead_ok: bool = e.dead and st.kills == k0 + 1
		print("CHECK ", "PASS" if dead_ok else "FAIL", " ", kind, " mati & dihitung")
		if not dead_ok:
			fails += 1
		await _w(1.6)
		print("CHECK ", "PASS" if not is_instance_valid(e) else "FAIL", " ", kind, " dibersihkan setelah mati")
	print("SUMMARY fails=", fails)
