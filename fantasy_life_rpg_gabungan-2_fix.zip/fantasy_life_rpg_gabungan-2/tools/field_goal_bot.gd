extends RefCounted
## Bot: wilayah jelajah = langkah Adventure. Mengalahkan FIELD_GOAL monster menaklukkan wilayah sekali (hadiah tamat), tidak dobel.
##   -- --bot=1 --botscript=field_goal_bot --stage=f_plains --fresh
var fails := 0


func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1


func run(st: Node) -> void:
	await st.get_tree().create_timer(1.5).timeout
	var gs := GameState
	var id: String = st.sd.id
	gs.stages = {}
	for sid in Data.adventure_order:               # semua langkah sebelum wilayah ini sudah selesai
		if sid == id:
			break
		gs.stages[sid] = {"cleared": true, "stars": 3}
	check("wilayah belum selesai", not gs.stage_cleared(id))
	check("wilayah adalah langkah Adventure berikutnya", gs.adventure_next() == id, gs.adventure_next())
	var g0 := gs.gold
	for i in st.FIELD_GOAL - 1:
		st._field_progress()
	check("sebelum target: belum selesai", not gs.stage_cleared(id), "%d/%d" % [st._field_kills, st.FIELD_GOAL])
	st._field_progress()
	check("mencapai target: wilayah ditaklukkan", gs.stage_cleared(id))
	check("hadiah tamat diterima", gs.gold >= g0 + st.sd.reward_gold, "gold +%d" % (gs.gold - g0))
	check("langkah berikutnya maju", gs.adventure_next() != id and gs.adventure_next() != "", gs.adventure_next())
	var g1 := gs.gold
	for i in 5:
		st._field_progress()
	check("kill berikutnya tidak memberi hadiah tamat lagi", gs.gold == g1)
	print("CHECK SUMMARY fails=", fails)
