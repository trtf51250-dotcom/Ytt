extends RefCounted
## Fitur render apa yang BENAR-BENAR berefek di Compatibility 4.3? Bandingkan gambar (selisih rata-rata piksel) & primitif.
func _shot(scene: Node) -> Image:
	await scene.get_tree().create_timer(0.6).timeout
	return scene.get_viewport().get_texture().get_image()
func _diff(a: Image, b: Image) -> float:
	var s := 0.0
	var n := 0
	for y in range(0, a.get_height(), 5):
		for x in range(0, a.get_width(), 5):
			var ca := a.get_pixel(x, y); var cb := b.get_pixel(x, y)
			s += absf(ca.r - cb.r) + absf(ca.g - cb.g) + absf(ca.b - cb.b)
			n += 1
	return s / n / 3.0 * 255.0
func _prims(scene: Node) -> int:
	await scene.get_tree().process_frame
	await scene.get_tree().process_frame
	return int(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME))
func run(scene: Node) -> void:
	var t := scene.get_tree()
	if "autoplay" in scene: scene.autoplay = true
	await t.create_timer(1.5).timeout
	GameState.set_setting("quality", 2, false)
	await t.create_timer(1.0).timeout
	var env: Environment = scene.daynight.env
	var base := await _shot(scene)
	env.glow_enabled = true; env.glow_intensity = 1.5; env.glow_bloom = 0.4; env.glow_hdr_threshold = 0.6
	var g := await _shot(scene)
	print("FEAT glow diff=%.2f" % _diff(base, g))
	env.glow_enabled = false
	env.adjustment_enabled = true; env.adjustment_saturation = 1.5; env.adjustment_contrast = 1.3
	var a := await _shot(scene)
	print("FEAT adjustment(sat1.5,contrast1.3) diff=%.2f" % _diff(base, a))
	env.adjustment_enabled = false
	var vp := scene.get_viewport()
	print("FEAT has anisotropic_filtering_level property: ", "anisotropic_filtering_level" in vp)
	vp.set("anisotropic_filtering_level", 0)
	var an0 := await _shot(scene)
	vp.set("anisotropic_filtering_level", 4)
	var an8 := await _shot(scene)
	print("FEAT aniso 0 vs 16x diff=%.2f" % _diff(an0, an8))
	vp.mesh_lod_threshold = 1.0
	var p1 := await _prims(scene)
	vp.mesh_lod_threshold = 16.0
	var p16 := await _prims(scene)
	vp.mesh_lod_threshold = 1.0
	print("FEAT mesh_lod_threshold prims 1.0=%d 16.0=%d" % [p1, p16])
	vp.msaa_3d = Viewport.MSAA_4X
	var m4 := await _shot(scene)
	vp.msaa_3d = Viewport.MSAA_DISABLED
	var m0 := await _shot(scene)
	print("FEAT msaa 4x vs off diff=%.2f" % _diff(m0, m4))
	vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA
	var fx := await _shot(scene)
	vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED
	print("FEAT fxaa vs off diff=%.2f" % _diff(m0, fx))
	var sun: DirectionalLight3D = scene.daynight.sun
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	var s4 := await _shot(scene)
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	var s1 := await _shot(scene)
	print("FEAT shadow 4 splits vs 1 diff=%.2f" % _diff(s1, s4))
	print("SUMMARY fails=0")
