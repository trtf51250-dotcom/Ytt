extends RefCounted
## Biaya CPU per bingkai tanpa render (jalankan --headless): rata-rata TIME_PROCESS / TIME_PHYSICS_PROCESS, jumlah node, objek, dan monster hidup.
##   --headless ... -- --bot=1 --botscript=cpu_cost_bot [--stage=s2_1]
func run(scene: Node) -> void:
	var t := scene.get_tree()
	if "autoplay" in scene:
		scene.autoplay = true
	await t.create_timer(4.0).timeout
	var p := 0.0
	var f := 0.0
	var n := 0
	var frames := 0
	var t0 := Time.get_ticks_msec()
	for i in 240:
		await t.process_frame
		p += Performance.get_monitor(Performance.TIME_PROCESS)
		f += Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS)
		n += 1
	var wall := float(Time.get_ticks_msec() - t0) / n
	print("CPU proses=%.2fms fisika=%.2fms wall/bingkai=%.2fms node=%d objek=%d monster=%d" % [p / n * 1000.0, f / n * 1000.0, wall,
		Performance.get_monitor(Performance.OBJECT_NODE_COUNT), Performance.get_monitor(Performance.OBJECT_COUNT), t.get_nodes_in_group("enemy").size()])
	print("SUMMARY fails=0")
