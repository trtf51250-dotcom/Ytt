extends RefCounted
## Diagnosis UI 2D: draw call per CanvasLayer dan per anak langsungnya (preset Lancar).
func _meas(t: SceneTree, n: int = 12) -> int:
	var d := 0
	for i in n:
		await t.process_frame
		d += int(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME))
	return d / n
func _count(n: Node) -> Dictionary:
	var c := {"ctl": 0, "vis": 0, "label": 0, "button": 0, "panel": 0, "tex": 0, "custom_draw": 0}
	for x in n.find_children("*", "CanvasItem", true, false):
		c["ctl"] += 1
		if (x as CanvasItem).is_visible_in_tree(): c["vis"] += 1
		if x is Label: c["label"] += 1
		if x is BaseButton: c["button"] += 1
		if x is PanelContainer or x is Panel: c["panel"] += 1
		if x is TextureRect: c["tex"] += 1
	return c
func run(scene: Node) -> void:
	var t := scene.get_tree()
	if "autoplay" in scene: scene.autoplay = true
	await t.create_timer(1.5).timeout
	GameState.set_setting("quality", 0, false)
	await t.create_timer(1.0).timeout
	var base := await _meas(t)
	print("P2 base draws=", base)
	for l in t.root.find_children("*", "CanvasLayer", true, false):
		var cl := l as CanvasLayer
		var c := _count(cl)
		cl.visible = false
		var d := await _meas(t)
		cl.visible = true
		print("P2 layer %-22s layer=%d draws_removed=%4d  items=%d visible=%d labels=%d buttons=%d panels=%d textures=%d" % [cl.name, cl.layer, base - d, c["ctl"], c["vis"], c["label"], c["button"], c["panel"], c["tex"]])
		var rows: Array = []
		for ch in cl.get_children():
			if not (ch is CanvasItem): continue
			var ci := ch as CanvasItem
			var was := ci.visible
			ci.visible = false
			var dd := await _meas(t, 8)
			ci.visible = was
			rows.append([base - dd, str(ch.name), _count(ch)])
		rows.sort_custom(func(a, b): return a[0] > b[0])
		for r in rows.slice(0, 8):
			print("P2     child %-26s draws_removed=%4d items=%d visible=%d labels=%d buttons=%d panels=%d textures=%d" % [r[1], r[0], r[2]["ctl"], r[2]["vis"], r[2]["label"], r[2]["button"], r[2]["panel"], r[2]["tex"]])
	print("SUMMARY fails=0")
