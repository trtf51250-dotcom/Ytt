extends RefCounted
## Arah efek tebasan: semua tebasan/skill jarak dekat harus menyapu MENDATAR KE DEPAN pemain (bukan berdiri tegak seperti pelangi di atas kepala).
## Ukur tiap frame: bentuk busur (ArrayMesh) di fx_root -> tinggi bbox harus kecil dibanding lebar mendatarnya, tidak lebih tinggi dari 2.3 m,
## dan pusatnya tidak boleh di belakang pemain. Plus foto di --shots untuk dilihat mata.
var st: Node3D
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1

func run(s: Node3D) -> void:
	st = s
	var t := st.get_tree()
	st.autoplay = true
	await t.create_timer(0.8).timeout
	for e in t.get_nodes_in_group("enemies"): e.queue_free()
	await t.create_timer(0.2).timeout
	var p: Player = st.player
	p.invuln = 999.0
	var only := OS.get_environment("FXDIR_ONLY")
	for id in Data.character_ids():
		if only != "" and id != only: continue
		GameState.unlock_character(id)
		p.set_character(id)
		var cd: CharacterData = p.data
		var melee_atk := cd.attack_kind in ["arc", "dagger", "smash"]
		var melee_skill := cd.skill_kind in ["cone", "dash_cut", "iai"]
		var dd := 2.0
		p.control_enabled = true
		p.velocity = Vector3.ZERO
		p.global_position = Vector3(0, 0.1, 0)
		p.facing = 0.0
		for e in t.get_nodes_in_group("enemies"): e.queue_free()
		var d: Enemy = st._spawn_enemy("slime", Vector3(0, 0, dd))
		await t.create_timer(1.0).timeout
		d.hp = 99999999; d.max_hp = 99999999
		d.set_physics_process(false)
		d.global_position = Vector3(0, 0, dd)
		st.cam.snap_to_target()
		await t.create_timer(1.0).timeout
		for act in ["atk", "skill"]:
			if (act == "atk" and not melee_atk) or (act == "skill" and not melee_skill):
				continue
			var worst := 0.0
			var maxy := 0.0
			var minfwd := 99.0
			var seen := 0
			p.global_position = Vector3(0, 0.1, 0)
			p.facing = 0.0
			p.attack_cd = 0.0; p.skill_cd = 0.0; p._act_t = 0.0; p._combo = 0
			Engine.time_scale = 0.2
			if act == "atk": p.do_attack()
			else: p.do_skill()
			var el := 0.0
			var imp: float = p.rig.action_impact("attack1" if act == "atk" else "skill")
			var marks := [imp + 0.03, imp + 0.1]
			var mk := 0
			var fwd := Vector3(0, 0, 1)
			while el < 1.4:
				await t.process_frame
				el += st.get_process_delta_time()
				p.global_position = Vector3(0, 0.1, 0)
				fwd = p.forward_dir()
				for e in t.get_nodes_in_group("enemies"):        # hanya satu target (di depan); musuh gelombang lain dibuang
					if e != d: e.queue_free()
				for n in st.fx_root.find_children("*", "MeshInstance3D", true, false):
					var mi := n as MeshInstance3D
					if not (mi.mesh is ArrayMesh) or not mi.is_visible_in_tree(): continue
					var bb: AABB = mi.global_transform * mi.get_aabb()
					var horiz := maxf(bb.size.x, bb.size.z)
					if horiz < 0.8: continue
					seen += 1
					worst = maxf(worst, bb.size.y / horiz)
					maxy = maxf(maxy, bb.end.y)
					minfwd = minf(minfwd, (bb.get_center() - p.global_position).dot(fwd))
				if mk < marks.size() and el >= marks[mk]:
					await st._shot("dir_%s_%s_%d" % [id, act, mk])
					mk += 1
			Engine.time_scale = 1.0
			check("%s/%s: tebasan mendatar ke depan (rasio tinggi/lebar %.2f <= 0.5; y maks %.2f <= 3.0; pusat z %.2f >= -0.5; sampel %d)" % [id, act, worst, maxy, minfwd, seen],
				seen > 0 and worst <= 0.5 and maxy <= 3.0 and minfwd >= -0.5, "")
			await t.create_timer(2.5).timeout
		d.queue_free()
		await t.create_timer(0.3).timeout
	print("SUMMARY fails=", fails)
