extends Node
## Memastikan lagu utama termuat sebagai MP3 berulang (loop), diputar di layar judul, dan keluar di mixer (puncak sinyal > 0).
func _ready():
	var cap := AudioEffectCapture.new()
	AudioServer.add_bus_effect(0, cap)
	var st = Sfx._sounds.get("music_main")
	print("CHECK music_main class=", st.get_class() if st else "null", " loop=", st.loop if st is AudioStreamMP3 else "-", " len=%.1f" % (st.get_length() if st else 0.0))
	Sfx.music("music_main", 0.3)
	for i in 4:
		await get_tree().create_timer(1.5).timeout
		var b := cap.get_buffer(cap.get_frames_available())
		var q := 0.0
		for f in b:
			q = maxf(q, maxf(absf(f.x), absf(f.y)))
		print("  t=%.1f pos=%.2f vol=%.1f dB peak=%.3f" % [1.5 * (i + 1), Sfx._music.get_playback_position(), Sfx._music.volume_db, q])
	await get_tree().create_timer(0.5).timeout
	print("CHECK playing=", Sfx._music.playing, " name=", Sfx._music_name)
	var buf := cap.get_buffer(cap.get_frames_available())
	var pk := 0.0
	for f in buf:
		pk = maxf(pk, maxf(absf(f.x), absf(f.y)))
	print("CHECK mixer peak=%.3f frames=%d" % [pk, buf.size()])
	get_tree().quit()
