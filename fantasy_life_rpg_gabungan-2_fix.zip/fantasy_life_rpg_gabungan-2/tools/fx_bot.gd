extends RefCounted
## Uji efek serangan: sapuan tebasan (foto bertahap), percikan searah, angka kritikal, hit-stop (waktu kembali normal, bisa dimatikan,
## tidak aktif saat jeda), dan tidak ada node efek yang bocor setelah banyak pukulan.
var st: Node3D
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1
func run(s: Node3D) -> void:
	st = s
	var t := st.get_tree()
	await t.create_timer(0.8).timeout
	# kosongkan musuh & bekukan gerak pemain
	for e in t.get_nodes_in_group("enemies"): e.queue_free()
	var pl: Node3D = st.player
	pl.global_position = Vector3(0, 0.1, 0)
	var yaw := 0.0
	var col := Color(0.5, 0.8, 1.0)
	# --- sapuan tebasan: 3 foto
	# foto: durasi diperpanjang (1.2 dtk) agar fase sapuan terlihat di renderer lambat; nilai asli 0.22-0.3 dtk
	Fx.slash(st.fx_root, pl.global_position, yaw, 3.6, 75.0, col.lightened(0.35), 1.2, false)
	await t.create_timer(0.2).timeout
	await st._shot("fx_slash_a")
	await t.create_timer(0.35).timeout
	await st._shot("fx_slash_b")
	await t.create_timer(2.3).timeout     # +0,7 dtk: efek kemunculan/ELIT musuh gelombang ikut sempat habis
	var left: int = st.fx_root.get_child_count()
	var names := []
	for c in st.fx_root.get_children(): names.append(str(c.name) + ":" + c.get_class())
	check("tebasan membersihkan diri (node efek habis)", left == 0, "sisa=%d %s" % [left, str(names)])
	# --- hit-stop
	var base := Engine.time_scale
	GameState.settings["hit_stop"] = true
	st._hit_stop(0.1)
	check("hit-stop memperlambat waktu", Engine.time_scale < base * 0.2, "%.3f" % Engine.time_scale)
	st._hit_stop(0.1)
	check("hit-stop tidak menumpuk (nilai dasar aman)", is_equal_approx(st._hs_base, base))
	await t.create_timer(0.25, true, false, true).timeout
	check("waktu kembali normal setelah hit-stop", is_equal_approx(Engine.time_scale, base), "%.3f" % Engine.time_scale)
	GameState.settings["hit_stop"] = false
	st._hit_stop(0.1)
	check("hit-stop mati lewat pengaturan", is_equal_approx(Engine.time_scale, base))
	GameState.settings["hit_stop"] = true
	t.paused = true
	st._hit_stop(0.1)
	check("tidak aktif saat dijeda", is_equal_approx(Engine.time_scale, base))
	t.paused = false
	# --- pukulan nyata pada musuh uji
	var dummy: Enemy = st._spawn_enemy("slime", Vector3(0, 0, -2.5))
	await t.create_timer(1.0).timeout
	dummy.hp = 99999; dummy.max_hp = 99999
	var peak := 0
	for i in 40:
		st._hit_enemy(dummy, 12.0, 6.0 if i % 5 == 0 else 3.0, col)
		peak = maxi(peak, st.fx_root.get_child_count())
		await t.create_timer(0.03, true, false, true).timeout
	await st._shot("fx_hits")
	await t.create_timer(2.5, true, false, true).timeout
	var remain: int = st.fx_root.get_child_count()
	check("40 pukulan: efek puncak %d node, sisa setelah 2.5 dtk = %d" % [peak, remain], remain <= 1)
	check("waktu normal setelah rentetan pukulan", is_equal_approx(Engine.time_scale, base), "%.3f" % Engine.time_scale)
	# --- angka kritikal: skala akhir 1
	var lbl_count := 0
	Fx.float_text(st.fx_root, Vector3(0, 2, 0), "99!", Color(1, 0.9, 0.3), 1.25)
	await t.create_timer(0.35, true, false, true).timeout
	for c in st.fx_root.get_children():
		if c is Label3D:
			lbl_count += 1
			check("angka kritikal mengendap ke skala 1", c.scale.is_equal_approx(Vector3.ONE), str(c.scale))
	check("ada label kritikal", lbl_count >= 1)
	print("CHECK SUMMARY fails=", fails)
