extends RefCounted
## Bot: membuka Pilih Stage (data baru, bab 1 dibersihkan) untuk memeriksa daftar bab & kunci stage.
func run(l: Node3D) -> void:
	var tree := l.get_tree()
	await tree.create_timer(1.0).timeout
	for id in ["s1_1", "s1_2", "s1_3", "s1_boss"]:
		GameState.stages[id] = {"cleared": true, "stars": 3}
	print("CHECK s2_1 unlocked=", GameState.stage_unlocked("s2_1"), " s2_2 unlocked=", GameState.stage_unlocked("s2_2"), " s2_boss unlocked=", GameState.stage_unlocked("s2_boss"))
	l.host.open("stage_select", {"stage": "s2_1"})
	await tree.create_timer(0.6).timeout
	await l._shot("adv_select_s21")
	l.host.current.set("selected", "s2_boss")
	l.host.current.call("refresh")
	await tree.create_timer(0.4).timeout
	await l._shot("adv_select_boss_locked")
