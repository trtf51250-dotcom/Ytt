extends RefCounted
## Menguji panel Party baru: potret ter-render, 4 slot, ganti slot/tukar, urutan, lepas, pemimpin. Cetak "CHECK ...".

var lobby: Node3D
var fails := 0


func _wait(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout


func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1


func _click(c: Control) -> void:
	var p := c.get_global_rect().get_center()
	for pressed in [true, false]:
		var ev := InputEventMouseButton.new()
		ev.button_index = MOUSE_BUTTON_LEFT
		ev.pressed = pressed
		ev.position = p
		ev.global_position = p
		Input.parse_input_event(ev)
		await _wait(0.05)


func _find(n: Node, pred: Callable, out: Array) -> void:
	if pred.call(n):
		out.append(n)
	for c in n.get_children():
		_find(c, pred, out)


func run(l: Node3D) -> void:
	lobby = l
	await _wait(0.6)
	var gs := GameState
	for id in ["hakuya", "sera", "zeya", "lucien", "wenyu"]:
		gs.unlock_character(id)
	lobby.host.open("party", {})
	var waited := 0.0
	while waited < 40.0 and not (Portraits._cache.has("ren") and Portraits._cache.has("ember") and Portraits._cache.has("hakuya#full")):
		await _wait(0.5)                  # tunggu studio potret selesai merender semua karakter
		waited += 0.5
	print("potret siap setelah ", waited, " dtk")
	await _wait(0.8)
	await lobby._shot("party_1")
	var imgs: Array = []
	_find(lobby, func(n): return n is TextureRect and ((n as TextureRect).texture is ImageTexture or (n as TextureRect).texture is AtlasTexture), imgs)
	check("potret 3D ter-render (>= 7 TextureRect)", imgs.size() >= 7, str(imgs.size()))
	var t0: Texture2D = (imgs[0] as TextureRect).texture
	var im: Image = t0.get_image()
	var opaque := 0
	for y in range(0, im.get_height(), 4):
		for x in range(0, im.get_width(), 4):
			if im.get_pixel(x, y).a > 0.5:
				opaque += 1
	check("potret berisi piksel karakter", opaque > 300, str(opaque))
	# klik kartu roster: tukar slot 1 dengan karakter ke-4 yang belum di party
	var before: Array = gs.party.duplicate()
	var cards: Array = []
	_find(lobby, func(n): return n is PanelContainer and (n as PanelContainer).custom_minimum_size.y == 200, cards)
	check("kartu roster sebanyak karakter", cards.size() == Data.character_ids().size(), str(cards.size()))
	var order: Array = lobby.host.current._sorted_ids()
	var target := ""
	for id in order:
		if gs.is_unlocked(id) and not gs.party.has(id):
			target = id
	check("ada karakter di luar party untuk diuji", target != "", target)
	await _click(cards[order.find(target)])
	await _wait(0.4)
	check("ketuk kartu roster menaruh karakter di slot 1", gs.party[0] == target, str(gs.party))
	var uniq := {}
	for x in gs.party:
		uniq[x] = true
	check("party tetap unik & <= 4", gs.party.size() <= 4 and uniq.size() == gs.party.size(), str(gs.party))
	cards = []
	_find(lobby, func(n): return n is PanelContainer and (n as PanelContainer).custom_minimum_size.y == 200, cards)
	# ketuk kartu yang sudah di slot lain = tukar
	var other: String = gs.party[1]
	var first: String = gs.party[0]
	await _click(cards[order.find(other)])
	await _wait(0.4)
	check("karakter di slot lain ditukar ke slot 1", gs.party[0] == other and gs.party[1] == first, str(gs.party))
	# ganti urutan
	var sort_btns: Array = []
	_find(lobby, func(n): return n is Button and (n as Button).text.begins_with("Urut:"), sort_btns)
	check("tombol urut ada", sort_btns.size() == 1)
	if sort_btns.size() == 1:
		await _click(sort_btns[0])
		await _wait(0.4)
		check("urutan berganti", (sort_btns[0] as Button).text.contains("Kekuatan"), (sort_btns[0] as Button).text)
	await lobby._shot("party_2")
	# pilih slot 2 lalu jadikan pemimpin
	var l0: String = gs.leader()
	var make: Array = []
	_find(lobby, func(n): return n is Button and (n as Button).text.contains("pemimpin"), make)
	check("tombol pemimpin hanya muncul untuk slot > 1", make.size() == 0)
	# Lucien & Wenyu masuk party -> kartu memakai potret 3D (GIF/ilustrasi beranimasi sudah dihapus)
	gs.set_party_slot(0, "lucien")
	gs.set_party_slot(1, "wenyu")
	await _wait(1.2)
	var imgs2: Array = []
	_find(lobby, func(n): return n is TextureRect and ((n as TextureRect).texture is ImageTexture or (n as TextureRect).texture is AtlasTexture), imgs2)
	check("kartu Party (slot + roster) memakai potret 3D", imgs2.size() >= 4, str(imgs2.size()))
	await lobby._shot("party_3")
	print("SUMMARY fails=", fails)
