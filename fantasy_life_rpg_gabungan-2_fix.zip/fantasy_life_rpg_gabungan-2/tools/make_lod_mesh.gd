extends SceneTree
## Membuat mesh karakter versi ringan dari hero.glb: (1) menyatukan titik kembar, (2) memakai pembangkit LOD bawaan Godot (meshoptimizer) untuk
## meleburkan segitiga-segitiga kecil sebidang, (3) memadatkan titik terpakai, lalu menyimpan res://assets/hero/hero_low.res.
##   godot --headless --path . -s res://tools/make_lod_mesh.gd
func _key(v: Vector3, n: Vector3, uv: Vector2, c: Color, b: PackedInt32Array, w: PackedFloat32Array, o: int) -> String:
	return "%d,%d,%d|%d,%d,%d|%d,%d|%d,%d,%d,%d|%d,%d,%d,%d|%d,%d,%d,%d" % [
		roundi(v.x * 10000), roundi(v.y * 10000), roundi(v.z * 10000), roundi(n.x * 100), roundi(n.y * 100), roundi(n.z * 100),
		roundi(uv.x * 10000), roundi(uv.y * 10000), roundi(c.r * 100), roundi(c.g * 100), roundi(c.b * 100), roundi(c.a * 100),
		b[o], b[o + 1], b[o + 2], b[o + 3], roundi(w[o] * 100), roundi(w[o + 1] * 100), roundi(w[o + 2] * 100), roundi(w[o + 3] * 100)]


func _init() -> void:
	var ps: PackedScene = load("res://assets/hero/hero.glb")
	var inst := ps.instantiate()
	var src: MeshInstance3D = null
	for mi in inst.find_children("*", "MeshInstance3D", true, false):
		src = mi
	var mesh: ArrayMesh = src.mesh
	var a := mesh.surface_get_arrays(0)
	var V: PackedVector3Array = a[Mesh.ARRAY_VERTEX]
	var N: PackedVector3Array = a[Mesh.ARRAY_NORMAL]
	var U: PackedVector2Array = a[Mesh.ARRAY_TEX_UV]
	var C: PackedColorArray = a[Mesh.ARRAY_COLOR]
	var B: PackedInt32Array = a[Mesh.ARRAY_BONES]
	var W: PackedFloat32Array = a[Mesh.ARRAY_WEIGHTS]
	var I: PackedInt32Array = a[Mesh.ARRAY_INDEX]
	print("original: verts=", V.size(), " tris=", I.size() / 3, " bones/vert=", B.size() / V.size())
	var map := {}
	var remap := PackedInt32Array()
	remap.resize(V.size())
	var nv := PackedVector3Array(); var nn := PackedVector3Array(); var nu := PackedVector2Array(); var nc := PackedColorArray()
	var nb := PackedInt32Array(); var nw := PackedFloat32Array()
	for i in V.size():
		var k := _key(V[i], N[i], U[i], C[i] if C.size() > 0 else Color.WHITE, B, W, i * 4)
		if map.has(k):
			remap[i] = map[k]
		else:
			map[k] = nv.size()
			remap[i] = nv.size()
			nv.append(V[i]); nn.append(N[i]); nu.append(U[i]); nc.append(C[i] if C.size() > 0 else Color.WHITE)
			for q in 4:
				nb.append(B[i * 4 + q]); nw.append(W[i * 4 + q])
	var ni := PackedInt32Array()
	ni.resize(I.size())
	for i in I.size():
		ni[i] = remap[I[i]]
	print("setelah disatukan: verts=", nv.size())
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = nv; arr[Mesh.ARRAY_NORMAL] = nn; arr[Mesh.ARRAY_TEX_UV] = nu; arr[Mesh.ARRAY_COLOR] = nc
	arr[Mesh.ARRAY_BONES] = nb; arr[Mesh.ARRAY_WEIGHTS] = nw; arr[Mesh.ARRAY_INDEX] = ni
	var im := ImporterMesh.new()
	im.add_surface(Mesh.PRIMITIVE_TRIANGLES, arr, [], {}, mesh.surface_get_material(0), "hero")
	im.generate_lods(25.0, 25.0, [])
	var n := im.get_surface_lod_count(0)
	print("jumlah LOD=", n)
	for k in n:
		print("  lod ", k, " tris=", im.get_surface_lod_indices(0, k).size() / 3, " ukuran=", im.get_surface_lod_size(0, k))
	quit()
