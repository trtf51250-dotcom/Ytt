extends RefCounted
## Bot uji minimap stage & peti medan.
var st: Node3D
var fails := 0

func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1

func run(s: Node3D) -> void:
	st = s
	st.autoplay = true
	await st.get_tree().create_timer(1.0).timeout
	check("minimap stage ada", st.hud.stage_minimap != null and st.hud.stage_minimap.is_visible_in_tree(), "")
	var chests := st.get_tree().get_nodes_in_group("stage_chests")
	check("ada satu peti medan", chests.size() == 1, str(chests.size()))
	if chests.is_empty():
		print("CHECK SUMMARY fails=", fails)
		return
	var ch: Node3D = chests[0]
	check("peti medan di dalam arena & tidak di dalam benda", Vector2(ch.global_position.x, ch.global_position.z).length() < st.arena.radius and not st.spot_blocked(ch.global_position + Vector3(0, 0, 1.5), 0.4), str(ch.global_position))
	var g0: int = GameState.gold
	var d0: int = GameState.diamonds
	await st.get_tree().create_timer(0.3).timeout
	await st._shot("stage_minimap")
	st.player.global_position = ch.global_position + Vector3(0, 0.1, 1.4)
	await st.get_tree().create_timer(0.6).timeout
	var expect: int = 40 + st.sd.recommended_level * 12
	check("peti medan memberi emas", GameState.gold >= g0 + expect, "gold %d -> %d (+%d)" % [g0, GameState.gold, expect])
	check("diamond bonus pertama kali", GameState.diamonds == d0 + 20, "")
	check("peti hilang dari grup setelah dibuka", st.get_tree().get_nodes_in_group("stage_chests").is_empty(), "")
	var g1: int = GameState.gold
	st.player.global_position = ch.global_position + Vector3(0, 0.1, 1.4)
	await st.get_tree().create_timer(0.6).timeout
	check("peti tak memberi dua kali", GameState.gold == g1, "")
	check("stage_first tersimpan", Explore._d().get("stage_first", []).has(st.sd.id), "")
	print("CHECK SUMMARY fails=", fails)
