"""Tekstur jam orisinal untuk efek Aion: clock_face.png (cincin + penanda jam + angka romawi sederhana), ink_splash.png."""
import math, random
from PIL import Image, ImageDraw, ImageFilter
S = 512
c = S / 2
im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(im)
W = (255, 255, 255, 255)
d.ellipse([8, 8, S - 8, S - 8], outline=W, width=8)
d.ellipse([30, 30, S - 30, S - 30], outline=(255, 255, 255, 150), width=3)
d.ellipse([c - 120, c - 120, c + 120, c + 120], outline=(255, 255, 255, 110), width=2)
for i in range(60):
    a = i / 60 * math.tau
    big = i % 5 == 0
    r0 = c - (64 if big else 48)
    r1 = c - 34
    w = 7 if big else 3
    d.line([c + math.sin(a) * r0, c - math.cos(a) * r0, c + math.sin(a) * r1, c - math.cos(a) * r1], fill=W, width=w)
for i in range(12):
    a = i / 12 * math.tau
    x, y = c + math.sin(a) * (c - 100), c - math.cos(a) * (c - 100)
    d.polygon([(x, y - 14), (x + 8, y), (x, y + 14), (x - 8, y)], fill=W)
d.ellipse([c - 10, c - 10, c + 10, c + 10], fill=W)
im.save("assets/fx/clock_face.png")

random.seed(7)
S2 = 256
ink = Image.new("L", (S2, S2), 0)
di = ImageDraw.Draw(ink)
cx = S2 / 2
di.ellipse([cx - 46, cx - 46, cx + 46, cx + 46], fill=255)
for _ in range(26):
    a = random.random() * math.tau
    r = random.uniform(40, 100)
    s = random.uniform(5, 18)
    x, y = cx + math.cos(a) * r, cx + math.sin(a) * r
    di.line([cx + math.cos(a) * 40, cx + math.sin(a) * 40, x, y], fill=255, width=int(max(2, s / 3)))
    di.ellipse([x - s, y - s, x + s, y + s], fill=255)
ink = ink.filter(ImageFilter.GaussianBlur(2.2)).point(lambda v: 255 if v > 110 else int(v * 2.0))
out = Image.new("RGBA", (S2, S2), (255, 255, 255, 0))
out.putalpha(ink)
out.save("assets/fx/ink_splash.png")
print("ok")
