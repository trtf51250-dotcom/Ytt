extends RefCounted
## Lembar kontak animasi kroco: merekam potongan gambar sekitar satu musuh tiap 0.15 s dan menyusunnya jadi satu PNG per jenis.
## Pemain dibuat kebal (HP dipulihkan); musuh bertindak normal (kejar -> aba-aba -> serang -> pemulihan), lalu dipukul sekali dan dimatikan.
var st: Node3D
func _w(s: float) -> void:
	await st.get_tree().create_timer(s).timeout
func _tile(img: Image, r: Rect2i) -> Image:
	var tile := Image.create(220, 220, false, Image.FORMAT_RGBA8)
	if r.size.x > 0 and r.size.y > 0:
		var part := img.get_region(r)
		part.convert(Image.FORMAT_RGBA8)
		tile.blit_rect(part, Rect2i(0, 0, r.size.x, r.size.y), Vector2i(0, 0))
	return tile


func run(s: Node3D) -> void:
	st = s
	var dir := ""
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shots="):
			dir = a.substr(8)
	await _w(2.5)
	for e in st.get_tree().get_nodes_in_group("enemies"):
		e.queue_free()
	await _w(0.2)
	for kind in ["slime", "bat", "mushroom"]:
		var p: Vector3 = st.player.global_position
		var e: Enemy = st._spawn_enemy(kind, p + Vector3(6.0, 0, 0.0))
		var tiles: Array = []
		var t := 0.0
		var hit_done := false
		var last_pos: Vector3 = e.global_position
		while t < 4.2 and is_instance_valid(e) and not e.dead:
			await st.get_tree().create_timer(0.14).timeout
			t += 0.14
			for ps in st.party_state:
				ps["hp"] = ps["max"]
			if not hit_done and t > 3.0:
				hit_done = true
				e.take_damage(1, st.player.global_position, 2.0)
			var img: Image = st.get_viewport().get_texture().get_image()
			last_pos = e.global_position
			var sp: Vector2 = st.cam.cam.unproject_position(e.global_position + Vector3(0, 0.8 if not e.flying else 0.0, 0))
			var r := Rect2i(int(sp.x) - 110, int(sp.y) - 110, 220, 220)
			r = r.intersection(Rect2i(0, 0, img.get_width(), img.get_height()))
			tiles.append([_tile(img, r), e.state])
		if is_instance_valid(e) and not e.dead:
			e.take_damage(99999, st.player.global_position, 2.0)
		for k in 3:
			await st.get_tree().create_timer(0.1).timeout
			var img2: Image = st.get_viewport().get_texture().get_image()
			var sp2: Vector2 = st.cam.cam.unproject_position((e.global_position if is_instance_valid(e) else last_pos) + Vector3(0, 0.6, 0))
			var r2 := Rect2i(int(sp2.x) - 110, int(sp2.y) - 110, 220, 220).intersection(Rect2i(0, 0, img2.get_width(), img2.get_height()))
			tiles.append([_tile(img2, r2), "dead"])
		var cols := 8
		var rows := int(ceil(float(tiles.size()) / cols))
		var sheet := Image.create(cols * 220, rows * 220, false, Image.FORMAT_RGBA8)
		var states := []
		for i in tiles.size():
			sheet.blit_rect(tiles[i][0], Rect2i(0, 0, 220, 220), Vector2i((i % cols) * 220, (i / cols) * 220))
			states.append(tiles[i][1])
		sheet.save_png("%s/sheet_%s.png" % [dir, kind])
		print("sheet ", kind, " states: ", states)
		await _w(0.6)
