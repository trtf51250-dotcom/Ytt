extends RefCounted
## Hitung berapa kali panel Party dibangun ulang saat PERTAMA dibuka (potret 3D masuk satu per satu). Jalankan di lobi:
##   godot --path . scenes/lobby/lobby.tscn -- --bot=1 --botscript=party_open_bot --fresh
var lobby: Node3D


func _wait(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout


func run(l: Node3D) -> void:
	lobby = l
	await _wait(0.6)
	for id in ["hakuya", "sera", "zeya", "lucien", "wenyu"]:
		GameState.unlock_character(id)
	var cnt := [0]
	Portraits.changed_signal(lobby).connect(func(): cnt[0] += 1)
	var t0 := Time.get_ticks_msec()
	lobby.host.open("party", {})
	await _wait(0.5)
	var waited := 0.0
	while waited < 90.0 and Portraits._inst != null and (Portraits._inst._busy or not Portraits._inst._queue.is_empty()):
		await _wait(0.3)
		waited += 0.3
	await _wait(1.0)
	var pn = lobby.host.current
	var calls = pn.get("refresh_calls")
	var n: int = int(calls) if calls != null else cnt[0] + 1     # versi lama: tiap potret = satu refresh() + satu saat dibuka
	print("PERF buka Party: potret selesai %d kali -> refresh() penuh %d kali, total %.1f dtk" % [cnt[0], n, (Time.get_ticks_msec() - t0) / 1000.0])
	print("SUMMARY fails=0")
