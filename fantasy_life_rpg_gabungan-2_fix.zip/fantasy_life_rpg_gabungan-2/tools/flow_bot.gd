extends RefCounted
## Bot uji layar pemuatan: pindah scene tuntas, kunci _busy terlepas, jalur gagal tidak macet, kecepatan menyesuaikan waktu muat.
var fails := 0

func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1

func run(lb: Node3D) -> void:
	var tree := lb.get_tree()
	if Engine.has_meta("flow_bot_ran"):
		await tree.create_timer(600.0).timeout      # scene yang dimuat ulang tidak boleh menutup game; bot pertama yang mengakhiri uji
		return
	Engine.set_meta("flow_bot_ran", true)
	await tree.create_timer(0.5).timeout
	var t0 := Time.get_ticks_msec()
	GameState.current_stage_id = "s1_1"
	await Flow.goto(Flow.SCENE_STAGE)
	var ms := Time.get_ticks_msec() - t0
	await tree.process_frame
	check("lobi -> stage selesai & scene benar", tree.current_scene != null and tree.current_scene.name == "Stage", "%s %d ms" % [tree.current_scene.name if tree.current_scene else "null", ms])
	check("kunci pemuatan terlepas", not Flow.is_busy(), "")
	check("layar muat tidak menghalangi sentuhan", Flow._fade.mouse_filter == Control.MOUSE_FILTER_IGNORE and Flow._fade.modulate.a < 0.01, "a=%.2f" % Flow._fade.modulate.a)
	check("waktu muat tercatat", Flow._load_ms > 0.0, "load_ms=%.0f speed_slow=%.2f" % [Flow._load_ms, Flow.speed_slow()])
	# jalur gagal
	var t1 := Time.get_ticks_msec()
	await Flow.goto("res://scenes/tidak_ada.tscn")
	check("scene tak ada: tidak macet di layar muat", not Flow.is_busy() and Flow._fade.modulate.a < 0.01, "%d ms" % (Time.get_ticks_msec() - t1))
	check("scene lama tetap berjalan setelah gagal", tree.current_scene != null and tree.current_scene.name == "Stage", "")
	# panggilan ganda diabaikan
	Flow.goto(Flow.SCENE_LOBBY)
	await tree.process_frame
	Flow.goto(Flow.SCENE_LOBBY)          # ketukan kedua saat sibuk harus diabaikan
	await tree.create_timer(0.2).timeout
	while Flow.is_busy():
		await tree.process_frame
	check("ketukan ganda tidak merusak pemuatan", tree.current_scene != null and tree.current_scene.name == "Lobby", tree.current_scene.name if tree.current_scene else "null")
	# kecepatan menyesuaikan: HP lambat vs cepat
	var keep := Flow._load_ms
	Flow._load_ms = 100.0
	var fast := Flow.speed_slow()
	Flow._load_ms = 2500.0
	var slow := Flow.speed_slow()
	Flow._load_ms = keep
	check("HP cepat dinilai lebih cepat dari HP lambat", fast < slow and slow >= 0.99, "fast=%.2f slow=%.2f" % [fast, slow])
	print("CHECK SUMMARY fails=", fails)
	tree.quit()
