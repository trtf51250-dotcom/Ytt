extends RefCounted
## Memeriksa teks tanggal/jam dunia nyata di HUD: format Indonesia, cocok dengan jam sistem, dan contoh tanggal tetap.
var lobby: Node3D
var fails := 0
func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1
func run(l: Node3D) -> void:
	lobby = l
	await lobby.get_tree().create_timer(0.8).timeout
	var txt: String = lobby.hud._date_lbl.text
	var now := Time.get_datetime_dict_from_system(false)
	print("HUD: ", txt, "   | kota: ", lobby.hud._time_lbl.text)
	check("label tanggal terisi", txt != "")
	check("memuat tahun sistem", txt.contains(str(now["year"])), txt)
	check("memuat bulan Indonesia", txt.contains(Hud.MONTHS_ID[int(now["month"]) - 1]), txt)
	check("memuat nama hari Indonesia", txt.contains(Hud.DAYS_ID[int(now["weekday"])]), txt)
	var fixed := Hud.real_datetime_text({"year": 2026, "month": 11, "day": 3, "weekday": 2, "hour": 9, "minute": 5})
	check("format tetap", fixed == "Selasa, 3 November 2026 · 09:05", fixed)
	var fixed2 := Hud.real_datetime_text({"year": 2027, "month": 1, "day": 1, "weekday": 5, "hour": 0, "minute": 0})
	check("format 1 Januari", fixed2 == "Jumat, 1 Januari 2027 · 00:00", fixed2)
	await lobby._shot("hud_clock")
	print("BOT DONE fails=", fails)
	lobby.get_tree().quit(fails)
