extends RefCounted
## Ukur beban render per preset kualitas (lobi atau stage). Angka yang berarti lintas perangkat: draw call, objek, primitif, node.
## Waktu bingkai di mesin uji (rasterizer CPU) HANYA pembanding relatif antar preset, bukan FPS di HP.
## Env: PERF_QS="0,1,2" memilih preset. Mencetak "PERF q=.. fps=.. ms=.. draws=.. objs=.. prims=.. nodes=.. vram=.. fx=.."
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1

func _info() -> Dictionary:
	return {
		"draws": int(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)),
		"objs": int(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME)),
		"prims": int(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME)),
	}

func run(scene: Node) -> void:
	var t := scene.get_tree()
	if "autoplay" in scene: scene.autoplay = true
	await t.create_timer(1.5).timeout
	var qs: Array = []
	for x in OS.get_environment("PERF_QS").split(",", false): qs.append(int(x))
	if qs.is_empty(): qs = [0, 1, 2]
	var kind := "stage" if scene.has_method("_spawn_enemy") else "lobi"
	GameState.set_setting("shadows", true, false)
	for q in qs:
		GameState.set_setting("quality", q, false)
		await t.create_timer(1.2).timeout
		var n := 90
		var tt := 0.0
		var dr := 0; var ob := 0; var pr := 0
		var worst := 0.0
		for i in n:
			await t.process_frame
			var d := scene.get_process_delta_time()
			tt += d; worst = maxf(worst, d)
			var inf := _info()
			dr += inf["draws"]; ob += inf["objs"]; pr += inf["prims"]
		print("PERF %s q=%d fps=%.1f ms=%.1f worst_ms=%.1f draws=%d objs=%d prims=%d nodes=%d vram_mb=%.0f msaa=%d" % [kind, q, n / tt, tt / n * 1000.0, worst * 1000.0, dr / n, ob / n, pr / n,
			int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT)), Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED) / 1048576.0, int(scene.get_viewport().msaa_3d)])
	print("SUMMARY fails=", fails)
