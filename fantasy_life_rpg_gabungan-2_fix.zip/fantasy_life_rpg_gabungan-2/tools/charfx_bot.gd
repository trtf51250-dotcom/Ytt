extends RefCounted
## Uji efek khas karakter: tiap karakter (semua karakter, termasuk Vael, Lucien, Wenyu, Kuroha) menjalankan serangan, kombo, dan skill di depan target latihan.
## Mengukur: tak ada error, node efek puncak per aksi, nol node tersisa setelah selesai, biaya CPU pembuatan efek (ms, mesin uji ini),
## dan memotret fase efek (waktu diperlambat) ke --shots.
var st: Node3D
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1

func _count(n: Node) -> int:
	var c := 0
	for ch in n.get_children():
		if ch is Label3D:      # angka damage (Fx.float_text) bukan efek karakter; masa hidupnya mengikuti kecepatan frame
			continue
		c += 1 + _count(ch)
	return c

func run(s: Node3D) -> void:
	st = s
	var t := st.get_tree()
	await t.create_timer(0.8).timeout
	for e in t.get_nodes_in_group("enemies"): e.queue_free()
	await t.create_timer(0.2).timeout
	var p: Player = st.player
	p.invuln = 999.0
	var peaks := {}
	for id in ["ren", "zeya", "lyra", "ember", "brann", "sera", "hakuya", "vael", "lucien", "wenyu", "kuroha", "aion"]:
		GameState.unlock_character(id)
		p.set_character(id)
		p.control_enabled = true
		p.velocity = Vector3.ZERO
		p.global_position = Vector3(0, 0.1, 0)
		p.facing = 0.0
		var rng: float = p.data.attack_range
		var dist: float = 2.0 if rng < 4.0 else 6.0
		var dummy: Enemy = st._spawn_enemy("slime", Vector3(0, 0, dist))
		await t.create_timer(1.0).timeout
		dummy.hp = 99999999; dummy.max_hp = 99999999
		dummy.set_physics_process(false)
		dummy.global_position = Vector3(0, 0, dist)
		await t.create_timer(2.5).timeout          # biarkan sisa efek awal habis
		var base: int = _count(st.fx_root)
		var peak := base
		var ms_total := 0.0
		var calls := 0
		# 1) 3 siklus serangan biasa penuh (kombo), 2) skill
		for step in 2:
			var tt := 0.0
			while tt < (2.4 if step == 0 else 2.2):
				p.global_position = Vector3(0, 0.1, 0)
				p.velocity = Vector3.ZERO
				var t0 := Time.get_ticks_usec()
				var did := false
				if step == 0:
					did = p.do_attack()
				elif tt < 0.05:
					p.skill_cd = 0.0
					did = p.do_skill()
				ms_total += float(Time.get_ticks_usec() - t0) / 1000.0 if did else 0.0
				calls += 1 if did else 0
				await t.physics_frame
				tt += 1.0 / 60.0
				peak = maxi(peak, _count(st.fx_root))
		print("  %s: node efek puncak=%d (awal %d), aksi=%d" % [id, peak, base, calls])
		peaks[id] = peak
		await t.create_timer(3.5).timeout
		var left: int = _count(st.fx_root)
		if left > base:
			for ch in st.fx_root.get_children():
				print("  SISA: ", ch.name, " ", ch.get_class(), " children=", ch.get_child_count())
		check("%s: efek membersihkan diri (sisa %d, awal %d)" % [id, left, base], left <= base + 1, "")
		check("%s: node efek puncak wajar (<= 160)" % id, peak <= 160, "peak=%d" % peak)
		dummy.queue_free()
		await t.create_timer(0.3).timeout
	# mekanik slow Aion: melambat lalu pulih sendiri; yang terkuat menang; bos tidak bisa < 0.6
	var sl: Enemy = st._spawn_enemy("slime", Vector3(8, 0, 8))
	await t.create_timer(1.0).timeout
	sl.apply_slow(0.5, 1.0)
	check("slow: faktor 0.5 terpasang", is_equal_approx(sl._slow, 0.5), "slow=%f" % sl._slow)
	sl.apply_slow(0.8, 1.0)
	check("slow: yang lebih kuat tidak ditimpa", is_equal_approx(sl._slow, 0.5), "slow=%f" % sl._slow)
	check("slow: ada tanda jam di kaki musuh", sl.get_node_or_null("SlowMark") != null, "")
	await t.create_timer(1.5).timeout
	check("slow: pulih ke 1.0 setelah habis", is_equal_approx(sl._slow, 1.0), "slow=%f" % sl._slow)
	sl.queue_free()
	# foto fase efek (waktu diperlambat) per karakter: serangan, skill, kena
	for id in ["ren", "zeya", "lyra", "ember", "brann", "sera", "hakuya", "vael", "lucien", "wenyu", "kuroha", "aion"]:
		p.set_character(id)
		p.velocity = Vector3.ZERO
		p.global_position = Vector3(0, 0.1, 0)
		p.facing = 0.0
		var dd: float = 2.0 if p.data.attack_range < 4.0 else 6.0
		var d2: Enemy = st._spawn_enemy("slime", Vector3(0, 0, dd))
		await t.create_timer(1.0).timeout
		d2.hp = 99999999; d2.max_hp = 99999999
		d2.set_physics_process(false)
		d2.global_position = Vector3(0, 0, dd)
		p.global_position = Vector3(0, 0.1, 0)
		st.cam.snap_to_target()
		await t.create_timer(1.2).timeout
		var cp: Vector3 = st.cam.cam.global_position if "cam" in st.cam else st.cam.global_position
		var hits: Array = []
		for n in st.find_children("*", "MeshInstance3D", true, false):
			var mi3 := n as MeshInstance3D
			if mi3.mesh == null or not mi3.is_visible_in_tree() or mi3.get_parent() == st.fx_root:
				continue
			var bb: AABB = mi3.global_transform * mi3.get_aabb()
			if bb.size.length() > 6.0 and bb.intersects_segment(cp, p.global_position + Vector3(0, 1, 0)):
				hits.append("%s(%s) size=%s" % [mi3.name, mi3.get_parent().name, str(bb.size)])
		print("  DBG ", id, " cam=", cp, " player=", p.global_position, " occluders=", hits.slice(0, 4))
		for act in ["atk", "skill"]:
			p.attack_cd = 0.0; p.skill_cd = 0.0; p._act_t = 0.0; p._combo = 2 if id == "zeya" and act == "atk" else 0
			Engine.time_scale = 0.12
			if act == "atk": p.do_attack()
			else: p.do_skill()
			var imp: float = p.rig.action_impact("attack1" if act == "atk" else "skill")
			var el := 0.0
			var marks := [imp + 0.04, imp + 0.12]
			var mi := 0
			while el < imp + 0.3:
				await t.process_frame
				el += st.get_process_delta_time()
				if mi < marks.size() and el >= marks[mi]:
					await st._shot("fx_%s_%s_%d" % [id, act, mi])
					mi += 1
			Engine.time_scale = 1.0
			await t.create_timer(3.0).timeout
		d2.queue_free()
		await t.create_timer(0.3).timeout
	# kamera di tepi arena: tidak boleh tertutup tajuk pohon (foto sebelum/sesudah ada di --shots)
	p.set_character("ren")
	var ar: float = st.arena.radius / 20.0        # posisi tepi relatif terhadap radius arena
	for edge in [Vector3(18.0, 0.1, 7.5) * ar, Vector3(-18.0, 0.1, 8.0) * ar, Vector3(0.0, 0.1, 19.5) * ar]:
		p.velocity = Vector3.ZERO
		p.global_position = edge
		st.cam.snap_to_target()
		await t.create_timer(1.5).timeout
		await st._shot("rim_%d_%d" % [int(edge.x), int(edge.z)])
		check("kamera tepi arena naik (pitch efektif > 55 derajat)", absf(st.cam._pitch_node.rotation.x) > deg_to_rad(55.0), "pitch=%.0f" % rad_to_deg(absf(st.cam._pitch_node.rotation.x)))
	p.global_position = Vector3(0, 0.1, 0)
	st.cam.snap_to_target()
	await t.create_timer(1.5).timeout
	check("kamera tengah arena tidak berubah (pitch = pengaturan)", absf(absf(st.cam._pitch_node.rotation.x) - st.cam.pitch) < 0.02, "pitch=%.0f" % rad_to_deg(absf(st.cam._pitch_node.rotation.x)))
	print("FAILS=", fails)
