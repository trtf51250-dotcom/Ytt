extends RefCounted
## Bot uji lobi (dipanggil lewat `-- --bot=1 --shots=/dir`): memindahkan pemain, membuka dialog/panel, mengambil tangkapan layar.
## Dipakai hanya oleh pengembang untuk memeriksa tampilan UI secara headless (xvfb + llvmpipe).

var lobby: Node3D


func _wait(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout


func _tp(p: Vector3) -> void:
	lobby.player.global_position = p
	lobby.player.velocity = Vector3.ZERO
	lobby.cam.snap_to_target()
	for i in 6:
		await lobby.get_tree().physics_frame


func run(l: Node3D) -> void:
	lobby = l
	await _wait(0.8)
	await lobby._shot("ui_01_hud")
	# dekati Orwen
	await _tp(Vector3(-3.5, 0.1, -24.8))
	lobby.player.facing = PI
	await _wait(0.3)
	await lobby._shot("ui_02_prompt")
	print("target: ", lobby._target.get("prompt", "-"))
	lobby._try_interact()
	await _wait(1.8)
	await lobby._shot("ui_03_dialogue")
	lobby.dialogue.advance()
	await _wait(0.2)
	lobby.dialogue.advance()
	await _wait(2.0)
	lobby.dialogue.advance()
	await _wait(2.0)
	await lobby._shot("ui_04_choices")
	print("quest welcome: ", GameState.quest_state("q_welcome"))
	lobby.dialogue.close()
	await _wait(0.3)
	# panel yang belum ada
	lobby.host.open("quest")
	await _wait(0.4)
	await lobby._shot("ui_05_panel")
	lobby.host.close()
