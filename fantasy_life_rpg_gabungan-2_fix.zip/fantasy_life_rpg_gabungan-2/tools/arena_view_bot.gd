extends RefCounted
## Tangkapan layar pemandangan arena (kamera bebas). Pakai: --botscript=arena_view_bot --stage=ID --shots=DIR
func run(st: Node3D) -> void:
	await st.get_tree().create_timer(1.0).timeout
	var r: float = st.arena.radius
	for e in st.get_tree().get_nodes_in_group("enemies"):
		e.queue_free()
	st.cam.enabled = false
	var c := Camera3D.new()
	c.far = Quality.view_far()
	st.add_child(c)
	c.current = true
	var shots := [["a", Vector3(0, 5, r * 0.6), Vector3(0, 7, -r * 3.0)], ["b", Vector3(r * 0.6, 5, 0), Vector3(-r * 3.0, 9, r * 0.6)], ["c", Vector3(0, 40, r * 1.1), Vector3(0, 0, -10)]]
	for sh in shots:
		c.global_position = sh[1]
		c.look_at(sh[2], Vector3.UP)
		await st.get_tree().create_timer(0.6).timeout
		await st._shot("view_%s_%s" % [st.sd.id, sh[0]])
	st.get_tree().quit()
