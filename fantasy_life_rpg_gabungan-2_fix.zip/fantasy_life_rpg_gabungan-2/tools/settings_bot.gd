extends RefCounted
## Bot: buka Pengaturan, tangkap layar tiap tab, uji slider/toggle/pilihan berfungsi & tersimpan.
var lobby: Node3D
var fails := 0
func _w(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout
func check(n: String, ok: bool, extra := "") -> void:
	print("CHECK ", "PASS" if ok else "FAIL", " ", n, " ", extra)
	if not ok:
		fails += 1
func run(l: Node3D) -> void:
	lobby = l
	await _w(1.0)
	lobby.host.open("settings", {})
	await _w(0.6)
	var panel = lobby.host.current if "current" in lobby.host else null
	var tabs: TabContainer = _find_tabs(lobby.host)
	check("TabContainer pengaturan ada", tabs != null)
	if tabs == null:
		return
	for i in tabs.get_tab_count():
		tabs.current_tab = i
		await _w(0.4)
		await lobby._shot("set_tab_%d_%s" % [i, tabs.get_tab_title(i)])
	print("SUMMARY fails=", fails)
func _find_tabs(n: Node) -> TabContainer:
	if n is TabContainer:
		return n
	for c in n.get_children():
		var r := _find_tabs(c)
		if r:
			return r
	return null
