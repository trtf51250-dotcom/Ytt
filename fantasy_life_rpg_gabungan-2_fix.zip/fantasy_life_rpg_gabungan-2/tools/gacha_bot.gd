extends RefCounted
## Menguji upacara gacha: tarik 10x dengan pity 49 (menjamin ★5 pada tarikan pertama), tangkapan layar tiap tahap,
## uji lewati lewat ketukan, tombol OK, tarik 1x. Mencetak CHECK.
var lobby: Node3D
var fails := 0
func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1
func _w(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout
func run(l: Node3D) -> void:
	lobby = l
	await _w(0.6)
	var gs := GameState
	gs.diamonds = 5000
	gs.pity = 79
	lobby.host.open("gacha")
	await _w(0.5)
	await lobby._shot("gacha_panel")
	var panel = lobby.host.current
	var d0 := gs.diamonds
	panel._do(10)
	check("diamond berkurang 900", gs.diamonds == d0 - 900, "%d -> %d" % [d0, gs.diamonds])
	check("pity di-reset setelah ★5", gs.pity < 10, str(gs.pity))
	var rv: GachaReveal = panel._reveal
	check("overlay muncul", rv != null and is_instance_valid(rv))
	check("10 hasil", rv.results.size() == 10)
	check("tarikan pertama ★6", int(rv.results[0]["rarity"]) == 6, str(rv.results[0]))
	await _w(0.7)
	await lobby._shot("gacha_charge")
	await _w(0.9)
	await lobby._shot("gacha_flash")
	await _w(1.2)
	await lobby._shot("gacha_cards_back")
	await _w(1.6)
	await lobby._shot("gacha_reveal_mid")
	rv._skip = true
	await _w(1.5)
	check("selesai setelah dilewati", rv._done)
	await lobby._shot("gacha_done")
	var all_face := true
	for c in rv._cards:
		if not c.get_node("Face").visible or c.get_node("Back").visible:
			all_face = false
	check("semua kartu terbuka", all_face)
	# tombol OK
	var btns := rv._btn_row.get_children()
	check("tombol OK & Tarik lagi", btns.size() == 2)
	btns[0].emit_signal("pressed")
	await _w(0.3)
	check("overlay tertutup", panel._reveal == null)
	# tarik 1x
	gs.pity = 0
	panel._do(1)
	await _w(0.5)
	rv = panel._reveal
	check("tarik 1x: 1 kartu", rv != null and rv.results.size() == 1)
	rv._skip = true
	await _w(2.0)
	await lobby._shot("gacha_single_done")
	rv._btn_row.get_children()[1].emit_signal("pressed")   # tarik lagi
	await _w(0.5)
	check("tarik lagi memulai tarikan baru", panel._reveal != null and gs.stats["pulls"] == 12, str(gs.stats["pulls"]))
	print("BOT DONE fails=", fails)
	lobby.get_tree().quit(fails)
