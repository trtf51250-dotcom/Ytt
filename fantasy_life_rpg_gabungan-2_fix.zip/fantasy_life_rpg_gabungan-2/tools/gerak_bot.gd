extends RefCounted
## Fisika gerak: jatuh lalu mendarat, kecepatan naik halus (tidak langsung penuh), berhenti halus, tidak tembus lantai.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func run(st: Node3D) -> void:
	var t := st.get_tree()
	st.autoplay = true
	await t.create_timer(1.0).timeout
	for e in t.get_nodes_in_group("enemies"):
		e.queue_free()
	var p: Player = st.player
	p.global_position = Vector3(0, 6.0, 0)
	p.velocity = Vector3.ZERO
	var vmax := 0.0
	await t.physics_frame
	await t.physics_frame
	for i in 240:
		await t.physics_frame
		vmax = maxf(vmax, -p.velocity.y)
		if p.is_on_floor():
			break
	check("jatuh dari 6 m lalu mendarat di lantai", p.is_on_floor() and p.global_position.y < 0.6, "y=%.2f" % p.global_position.y)
	check("kecepatan jatuh dibatasi (terminal)", vmax <= Player.TERMINAL_V + 0.1, "vmax=%.1f" % vmax)
	await t.create_timer(0.3).timeout
	p.control_enabled = true
	p.move_input = Vector2(0, -1)
	await t.physics_frame
	await t.physics_frame
	var v1 := Vector3(p.velocity.x, 0, p.velocity.z).length()
	check("mulai bergerak halus (belum kecepatan penuh di 2 frame)", v1 < p.run_speed * 0.9, "v=%.2f run=%.2f" % [v1, p.run_speed])
	await t.create_timer(0.5).timeout
	var v2 := Vector3(p.velocity.x, 0, p.velocity.z).length()
	check("mencapai kecepatan lari", v2 > p.run_speed * 0.9, "v=%.2f" % v2)
	p.move_input = Vector2.ZERO
	await t.physics_frame
	await t.physics_frame
	var v3 := Vector3(p.velocity.x, 0, p.velocity.z).length()
	check("berhenti halus (tidak langsung nol)", v3 > 0.05 and v3 < v2, "v=%.2f" % v3)
	await t.create_timer(0.5).timeout
	var v4 := Vector3(p.velocity.x, 0, p.velocity.z).length()
	check("akhirnya berhenti", v4 < 0.1, "v=%.2f" % v4)
	print("FAILS=", fails)
	t.quit()
