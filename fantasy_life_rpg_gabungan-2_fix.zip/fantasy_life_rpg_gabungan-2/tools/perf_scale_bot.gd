extends RefCounted
## Apakah Viewport.scaling_3d_scale bekerja di renderer Compatibility? Ukur fps (rasterizer CPU = sangat peka terhadap jumlah piksel) + buat foto.
func run(scene: Node) -> void:
	var t := scene.get_tree()
	if "autoplay" in scene: scene.autoplay = true
	await t.create_timer(1.5).timeout
	GameState.set_setting("quality", 0, false)
	var vp := scene.get_viewport()
	print("SC window=", vp.get_visible_rect().size, " mode=", vp.scaling_3d_mode, " fsr_sharp=", vp.fsr_sharpness)
	for sc in [1.0, 0.75, 0.5, 1.0]:
		vp.scaling_3d_scale = sc
		await t.create_timer(1.0).timeout
		var tt := 0.0
		for i in 40:
			await t.process_frame
			tt += scene.get_process_delta_time()
		var img := vp.get_texture().get_image()
		print("SC scale=%.2f fps=%.1f ms=%.1f shot=%s" % [sc, 40.0 / tt, tt / 40.0 * 1000.0, str(img.get_size())])
		var dir := ""
		for x in OS.get_cmdline_user_args():
			if x.begins_with("--shots="): dir = x.substr(8)
		if dir != "": img.save_png("%s/scale_%02d.png" % [dir, int(sc * 100)])
	print("SUMMARY fails=0")
