extends Node3D
## Alat pengembang: menampilkan sejumlah bangunan berderet dan menyimpan screenshot.
##   godot --path . res://tools/town_preview.tscn -- --kinds=house_a,house_b --out=/tmp/x.png --cam=0,9,20 --look=0,2,0
func _arg(key: String, default: String) -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % key):
			return a.substr(key.length() + 3)
	return default


func _vec(s: String) -> Vector3:
	var p := s.split(",")
	return Vector3(float(p[0]), float(p[1]), float(p[2]))


func _ready() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.55, 0.75, 0.95)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.72, 0.78, 0.95)
	e.ambient_light_energy = 0.55
	env.environment = e
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -30, 0)
	sun.light_color = Color(1.0, 0.95, 0.85)
	sun.light_energy = 0.95
	sun.shadow_enabled = true
	add_child(sun)
	var kinds := _arg("kinds", "house_a,house_b,house_c,house_d").split(",")
	var spacing := float(_arg("spacing", "16"))
	var ground := MeshKit.new(1)
	ground.plane(Vector3(0, 0, 0), 200, 120, MeshKit.T_GRASS, Color(0.95, 1, 0.9), 1.0)
	var gm := ground.build()
	ground.apply_materials(gm)
	var gi := MeshInstance3D.new()
	gi.mesh = gm
	add_child(gi)
	var x := -spacing * (kinds.size() - 1) * 0.5
	var roofs := [Pal.RED, Pal.BLUE, Pal.TEAL, Pal.ORANGE, Pal.PURPLE]
	var i := 0
	for kd in kinds:
		var b := Building.new()
		b.kind = kd
		b.seed_value = 10 + i
		b.roof_color = roofs[i % roofs.size()]
		b.position = Vector3(x, 0, 0)
		add_child(b)
		x += spacing
		i += 1
	var cam := Camera3D.new()
	cam.fov = float(_arg("fov", "40"))
	cam.position = _vec(_arg("cam", "0,12,28"))
	add_child(cam)
	cam.look_at(_vec(_arg("look", "0,2.5,0")))
	for n in 6:
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png(_arg("out", "/tmp/town.png"))
	print("saved ", _arg("out", "/tmp/town.png"))
	get_tree().quit()
