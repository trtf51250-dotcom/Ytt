extends RefCounted
## Menguji event berjadwal dengan jam palsu (GameState.set_fake_now): sebelum event, saat event, dan sesudah event berakhir.
## Contoh: event ev_ember_fest = 2026-11-03 00:00 s/d 2026-11-10 23:59 (data/events.json).
var lobby: Node3D
var fails := 0
func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1
func _w(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout
func run(l: Node3D) -> void:
	lobby = l
	var gs := GameState
	await _w(0.6)
	gs.diamonds = 100000
	# ---- 1) SEBELUM event
	gs.set_fake_now("2026-11-02T23:59:00")
	check("sebelum mulai: tidak ada event aktif", LiveEvents.active().is_empty())
	check("sebelum mulai: tercatat akan datang", LiveEvents.upcoming().size() == 1)
	check("sebelum mulai: banner tidak bisa dipakai", Gacha.pull(1, "ev_ember_fest").is_empty() and gs.diamonds == 100000)
	await _w(0.4)
	check("sebelum mulai: tidak ada event aktif", LiveEvents.active().is_empty())
	lobby.host.open("event")
	await _w(0.5)
	await lobby._shot("event_upcoming")
	lobby.host.close()
	# ---- 2) SAAT event
	gs.set_fake_now("2026-11-03T00:00:00")
	check("tepat jam mulai: event aktif", LiveEvents.active().size() == 1)
	await _w(0.4)
	check("saat event: ada event aktif (ubin Event di Menu)", not LiveEvents.active().is_empty())
	check("saat event: titik merah di Menu (belum dilihat)", gs.unseen_event_count() == 1 and lobby.hud.more_badge_count() >= 1, str(lobby.hud.more_badge_count()))
	await lobby._shot("hud_event_button")
	gs.set_fake_now("2026-11-05T12:30:00")
	lobby.host.open("event")
	await _w(0.5)
	check("panel event menandai sudah dilihat", gs.unseen_event_count() == 0)
	await lobby._shot("event_active")
	var t: String = LiveEvents.countdown_text(LiveEvents.find("ev_ember_fest"))
	check("hitung mundur benar (5 Nov 12:30 -> 10 Nov 23:59:59)", t == "Sisa 5 hari 11 jam", t)
	# tombol ke banner
	lobby.host.open("gacha", {"banner": "ev_ember_fest"})
	await _w(0.6)
	var panel = lobby.host.current
	check("gacha dibuka langsung di banner event", panel._banner == "ev_ember_fest")
	await lobby._shot("gacha_banner")
	# tarik banyak sampai Ember keluar (50% dari hasil ★4 adalah Ember): batas atas 600 tarikan
	var got_new := false
	var got_shard := false
	var pulls := 0
	for i in 60:
		var res := Gacha.pull(10, "ev_ember_fest")
		pulls += 10
		for r in res:
			if r["kind"] == "character" and r["id"] == "ember":
				got_new = true
			if r["kind"] == "shards" and r["id"] == "ember":
				got_shard = true
		if got_new and got_shard:
			break
	check("Ember bisa didapat saat event", gs.is_unlocked("ember"), "setelah %d tarikan" % pulls)
	check("Ember kedua kali menjadi Pecahan Jiwa x5", got_shard, "")
	# banner standar tidak pernah memberi Ember (uji statistik atas 300 tarikan standar pada akun yang belum punya Ember)
	gs.roster.erase("ember")
	gs.party.erase("ember")
	var std_ember := false
	gs.pity = 0
	for i in 30:
		for r in Gacha.pull(10, ""):
			if r["id"] == "ember":
				std_ember = true
	check("banner standar: tidak pernah memberi karakter event (300 tarikan)", not std_ember and not gs.is_unlocked("ember"))
	# ---- 3) SESUDAH event berakhir
	panel._banner = "ev_ember_fest"
	lobby.host.close()
	lobby.host.open("gacha", {"banner": "ev_ember_fest"})
	await _w(0.5)
	panel = lobby.host.current
	check("masih aktif: banner terpilih", panel._banner == "ev_ember_fest")
	gs.set_fake_now("2026-11-11T00:00:00")
	check("setelah berakhir: tidak ada event aktif", LiveEvents.active().is_empty())
	var d0 := gs.diamonds
	check("setelah berakhir: banner menolak tarikan (diamond tidak terpotong)", Gacha.pull(10, "ev_ember_fest").is_empty() and gs.diamonds == d0)
	await _w(1.4)
	check("panel gacha yang terbuka menutup banner sendiri", panel._banner == "")
	await lobby._shot("gacha_after_event")
	lobby.host.close()
	await _w(0.4)
	check("setelah berakhir: tidak ada event aktif", LiveEvents.active().is_empty())
	# karakter yang sudah dimiliki tetap dimiliki
	gs.unlock_character("ember")
	check("karakter event yang sudah dimiliki tetap ada setelah event", gs.is_unlocked("ember"))
	# pemakaian lagi di waktu sebelum event kedua? (tidak ada) -> tarikan standar tetap normal
	gs.pity = 0
	check("banner standar tetap berfungsi setelah event", Gacha.pull(1, "").size() == 1)
	print("BOT DONE fails=", fails)
	lobby.get_tree().quit(fails)
