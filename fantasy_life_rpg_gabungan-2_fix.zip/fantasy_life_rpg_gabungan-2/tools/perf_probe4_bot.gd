extends RefCounted
## Mikro-uji: berapa draw call yang dihabiskan 1 Label menurut setelan (bayangan, jumlah huruf, tema).
func _meas(t: SceneTree, n: int = 8) -> int:
	var d := 0
	for i in n:
		await t.process_frame
		d += int(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME))
	return d / n
func _case(t: SceneTree, name: String, make: Callable) -> void:
	var cl := CanvasLayer.new()
	cl.layer = 50
	t.root.add_child(cl)
	var base := await _meas(t)
	var n: Control = make.call()
	cl.add_child(n)
	var d := await _meas(t)
	print("P4 %-48s +%d draws" % [name, d - base])
	cl.queue_free()
	await t.process_frame
func run(scene: Node) -> void:
	var t := scene.get_tree()
	if "autoplay" in scene: scene.autoplay = true
	await t.create_timer(1.5).timeout
	GameState.set_setting("quality", 0, false)
	await t.create_timer(1.0).timeout
	var theme := UiTheme.get_theme()
	var T := "AbcdefGhij AbcdefGhij AbcdefGhij AbcdefGh"
	await _case(t, "tanpa bayangan, tanpa outline", func(): var l := Label.new(); l.theme = theme; l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0)); l.text = T; return l)
	await _case(t, "tanpa bayangan, outline 6", func(): var l := Label.new(); l.theme = theme; l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0)); l.add_theme_constant_override("outline_size", 6); l.add_theme_color_override("font_outline_color", Color.BLACK); l.text = T; return l)
	await _case(t, "tanpa bayangan, outline 2", func(): var l := Label.new(); l.theme = theme; l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0)); l.add_theme_constant_override("outline_size", 2); l.add_theme_color_override("font_outline_color", Color.BLACK); l.text = T; return l)
	await _case(t, "LabelSettings tanpa bayangan + outline 4", func(): var l := Label.new(); var ls := LabelSettings.new(); ls.outline_size = 4; ls.outline_color = Color.BLACK; l.label_settings = ls; l.text = T; return l)
	await _case(t, "bayangan saja, offset 1,1", func(): var l := Label.new(); l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.5)); l.add_theme_constant_override("shadow_offset_x", 1); l.add_theme_constant_override("shadow_offset_y", 1); l.text = T; return l)
	print("SUMMARY fails=0")
