extends RefCounted
## Bot uji wilayah jelajah: tata letak, spawn monster berkeliaran, peti, area rahasia, gerbang, bangkit setelah pingsan.
var st: Node3D
var fails := 0

func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1

func _wait(t: float) -> void:
	await st.get_tree().create_timer(t).timeout

func run(s: Node3D) -> void:
	st = s
	st.autoplay = true
	await _wait(1.0)
	var R: float = st.arena.radius
	check("mode wilayah aktif & arena luas", st.field and R > 40.0, "R=%.1f" % R)
	check("minimap wilayah ada", st.hud.stage_minimap != null, "")
	check("pemain mulai di lantai", st.player.is_on_floor(), str(st.player.global_position))
	check("6 peti & 2 zona rahasia", st.field_chests.size() == 6 and st.field_zones.size() == 2, "%d/%d" % [st.field_chests.size(), st.field_zones.size()])
	var bad := 0
	for c: Dictionary in st.field_chests:
		var pc: Vector2 = c["pos"]
		if pc.length() > R * 0.95 or pc.length() < 3.0:
			bad += 1
	check("posisi peti di dalam arena", bad == 0, "bermasalah %d" % bad)
	check("gerbang di dalam arena", st.field_gate.length() < R * 0.95, str(st.field_gate))
	# monster berkeliaran muncul bertahap, tidak dekat pemain
	await _wait(9.0)
	var es := st.get_tree().get_nodes_in_group("enemies")
	check("monster berkeliaran muncul", es.size() >= 2, "n=%d" % es.size())
	var near_bad := 0
	for i in 20:
		var before := st.get_tree().get_nodes_in_group("enemies").size()
		st._field_spawn()
		var now := st.get_tree().get_nodes_in_group("enemies")
		if now.size() > before:
			var ne: Node3D = now[now.size() - 1]
			if Vector2(ne.global_position.x - st.player.global_position.x, ne.global_position.z - st.player.global_position.z).length() < 14.0:
				near_bad += 1
	check("titik muncul monster minimal 14 m dari pemain", near_bad == 0, "dekat %d/20" % near_bad)
	es = st.get_tree().get_nodes_in_group("enemies")
	check("tidak ada layar kemenangan/kalah (wilayah tak berakhir)", st.state != st.S.ENDED, "")
	# peti: dekati & buka (kosongkan musuh dulu)
	for e in es:
		if is_instance_valid(e):
			e.queue_free()
	var c0: Dictionary = st.field_chests[0]
	var g0: int = GameState.gold
	st.player.global_position = Vector3(c0["pos"].x, 0.1, c0["pos"].y + 1.4)
	await _wait(0.8)
	check("peti terbuka & emas bertambah", Explore.is_opened(c0["id"]) and GameState.gold > g0, "gold %d -> %d" % [g0, GameState.gold])
	var g1: int = GameState.gold
	st.player.global_position = Vector3(c0["pos"].x, 0.1, c0["pos"].y + 1.4)
	await _wait(0.8)
	check("peti tidak dibuka dua kali", GameState.gold - g1 < 60, "")
	# zona rahasia
	var z0: Dictionary = st.field_zones[0]
	var d0: int = GameState.diamonds
	st.player.global_position = Vector3(z0["pos"].x, 0.1, z0["pos"].y)
	await _wait(0.8)
	check("zona rahasia ditemukan + diamond", Explore.is_discovered(z0["id"]) and GameState.diamonds >= d0 + int(z0["diamonds"]), "dia %d -> %d" % [d0, GameState.diamonds])
	# gerbang: titik mulai pemain cukup jauh dari gerbang (tidak langsung keluar)
	check("titik mulai jauh dari gerbang", Vector2(0, R * 0.72).distance_to(st.field_gate) > 5.0, "")
	st.player.global_position = Vector3(0, 0.1, 0)
	await _wait(0.5)
	check("gerbang aktif setelah menjauh", st._gate_armed, "")
	st.player.global_position = Vector3(st.field_gate.x, 0.1, st.field_gate.y)
	await _wait(0.4)
	check("berdiri di gerbang menambah timer keluar", st._gate_hold > 0.1, "hold=%.2f" % st._gate_hold)
	st.player.global_position = Vector3(0, 0.1, 0)
	await _wait(0.5)
	# bangkit setelah semua pingsan
	for ps: Dictionary in st.party_state:
		ps["dead"] = true
		ps["hp"] = 0
	st.player.hp = 0
	st.player.dead = true
	st._field_revive()
	await _wait(0.4)
	check("bangkit di gerbang dengan HP 50%", not st.player.dead and st.player.hp > 0 and st.player.hp <= st.player.max_hp * 0.6, "hp %d/%d" % [st.player.hp, st.player.max_hp])
	await st._shot("field_" + st.sd.id)
	print("CHECK SUMMARY fails=", fails)
