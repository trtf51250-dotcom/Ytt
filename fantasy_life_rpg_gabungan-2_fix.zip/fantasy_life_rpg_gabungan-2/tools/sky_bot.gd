extends RefCounted
## Bot: langit hidup di lobi (awan sprite bergerak, bayangan awan, matahari/bulan) + saklar pengaturan & tidak menambah beban berlebih.
var lobby: Node3D
var fails := 0
func _w(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout
func check(n: String, ok: bool, extra := "") -> void:
	print("CHECK ", "PASS" if ok else "FAIL", " ", n, " ", extra)
	if not ok:
		fails += 1
func run(l: Node3D) -> void:
	lobby = l
	await _w(1.0)
	var sky: SkyLife = lobby.get_node_or_null("SkyLife")
	check("SkyLife ada di lobi", sky != null)
	if sky == null:
		return
	check("awan sprite dibuat", sky._clouds.size() >= 4, str(sky._clouds.size()))
	var mi: MeshInstance3D = sky._clouds[0]["mi"]
	var p0 := mi.position
	await _w(1.5)
	check("awan bergerak mengikuti angin", mi.position.distance_to(p0) > 0.5, str(mi.position.distance_to(p0)))
	var sc0 = sky._scroll
	await _w(1.0)
	check("bayangan awan bergeser", sky._scroll != sc0 or sky._shadow == null)
	# saklar
	GameState.set_setting("sky_life", false)
	await _w(0.5)
	check("saklar 'Awan & matahari' mematikan awan", not mi.visible and not sky._sun.visible)
	GameState.set_setting("sky_life", true)
	await _w(0.5)
	check("saklar menyalakan lagi", mi.visible)
	lobby.player.global_position = Vector3(0, 0.1, 22)
	lobby.cam.snap_to_target()
	await _w(0.5)
	for m in [1, 2, 3]:
		GameState.set_setting("time_mode", m)
		lobby.daynight.apply_mode()
		await _w(0.5)
		lobby.cam.pitch = deg_to_rad(42.0)
		await _w(0.4)
		await lobby._shot("sky_m%d_normal" % m)
		lobby.cam.pitch = deg_to_rad(18.0)
		lobby.cam.distance = 20.0
		await _w(0.6)
		await lobby._shot("sky_m%d_low" % m)
		lobby.cam.min_pitch = 0.02
		lobby.cam.pitch = deg_to_rad(3.0)
		lobby.cam.distance = 26.0
		await _w(0.6)
		await lobby._shot("sky_m%d_horizon" % m)
	print("SUMMARY fails=", fails)
