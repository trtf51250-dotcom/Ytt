extends RefCounted
## Memotret efek skill Nova Bintang Lyra di stage (waktu diperlambat): pengumpulan -> impak -> memudar.
var st: Node3D
func run(s: Node3D) -> void:
	st = s
	await st.get_tree().create_timer(1.5, true, false, true).timeout
	var p: Player = st.player
	GameState.unlock_character("lyra")
	p.set_character("lyra")
	p.global_position = Vector3(0, 0.1, 3)
	await st.get_tree().create_timer(0.8, true, false, true).timeout
	for e in st.get_tree().get_nodes_in_group("enemies"):
		e.queue_free()
	st.cam.distance = 11.0
	var dir: String = "/tmp"
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shots="):
			dir = a.substr(8)
	Engine.time_scale = 0.12
	p.skill_cd = 0.0
	p.do_skill()
	var imp: float = p.rig.action_impact("skill")
	var marks := [0.1, imp * 0.5, imp * 0.9, imp + 0.04, imp + 0.2, imp + 0.45, imp + 0.7]
	var el := 0.0
	var i := 0
	while i < marks.size():
		await st.get_tree().process_frame
		el += st.get_process_delta_time()
		if el >= marks[i]:
			st.get_viewport().get_texture().get_image().save_png("%s/nova_%d.png" % [dir, i])
			i += 1
	Engine.time_scale = 1.0
	print("NOVA DONE impak=", imp)
	st.get_tree().quit(0)
