extends RefCounted
## Mengukur biaya render per tingkat grafis (Lancar/Sedang/Bagus) di lobi atau stage: draw call, objek, primitif, node, dan rata-rata waktu proses.
## Angka draw call/objek/primitif tidak bergantung pada GPU (berlaku juga di render software); waktu ms hanya pembanding relatif.
##   -- --bot=1 --botscript=render_cost_bot [--stage=s1_1]
func run(scene: Node) -> void:
	var t := scene.get_tree()
	if "autoplay" in scene:
		scene.autoplay = true
	await t.create_timer(2.5).timeout
	var cam := scene.get_viewport().get_camera_3d()
	for q in [0, 1, 2]:
		GameState.settings["quality"] = q
		Quality.apply(scene.get_viewport(), scene.get("daynight").sun if scene.get("daynight") != null else null, cam, scene.get("daynight").env if scene.get("daynight") != null else null)
		await t.create_timer(1.2).timeout
		var dc := 0.0
		var ob := 0.0
		var pr := 0.0
		var n := 0
		for i in 30:
			await t.process_frame
			dc += RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
			ob += RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME)
			pr += RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME)
			n += 1
		var nodes := int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))
		var vis_rigs := 0
		for v in scene.find_children("*", "MeshInstance3D", true, false):
			if (v as MeshInstance3D).is_visible_in_tree():
				vis_rigs += 1
		print("COST q=%d draw=%d objek=%d primitif=%d node=%d mesh_terlihat=%d proses=%.2fms fisika=%.2fms" % [q, dc / n, ob / n, pr / n, nodes, vis_rigs,
			Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0, Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0])
	print("SUMMARY fails=0")
