"""Membuat aset langit orisinal: noise awan yang bisa diulang (cloud_noise), 3 sprite awan (cloud_1..3), matahari (sun_disc), bulan (moon_disc).
Jalankan: python3 tools/gen_sky_art.py"""
import numpy as np
from PIL import Image, ImageFilter
import os
rng = np.random.default_rng(7)
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "sky")
os.makedirs(OUT, exist_ok=True)

def tile_noise(n=256, octaves=5):
    out = np.zeros((n, n), dtype=np.float32)
    amp, tot = 1.0, 0.0
    for o in range(octaves):
        g = 4 * 2 ** o
        base = rng.random((g, g)).astype(np.float32)
        im = Image.fromarray((base * 255).astype(np.uint8)).resize((n, n), Image.BICUBIC)
        # supaya tileable: bungkus dengan padding wrap sebelum resize
        pad = np.tile(base, (3, 3))
        im = Image.fromarray((pad * 255).astype(np.uint8)).resize((n * 3, n * 3), Image.BICUBIC).crop((n, n, 2 * n, 2 * n))
        out += amp * np.asarray(im, dtype=np.float32) / 255.0
        tot += amp
        amp *= 0.5
    out /= tot
    out = (out - out.min()) / (out.max() - out.min())
    return out

n = tile_noise()
Image.fromarray((n * 255).astype(np.uint8), "L").save(f"{OUT}/cloud_noise.png")

def blob_cloud(seed, size=(512, 256)):
    r = np.random.default_rng(seed)
    w, h = size
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    a = np.zeros((h, w), dtype=np.float32)
    k = r.integers(7, 11)
    for i in range(k):
        t = (i + 0.5) / k
        cx = w * (0.14 + 0.72 * t) + r.normal(0, 8)
        rad = h * (0.22 + 0.2 * np.sin(t * np.pi)) * r.uniform(0.8, 1.2)
        cy = h * 0.62 - rad * 0.35 * np.sin(t * np.pi) + r.normal(0, 4)
        d = np.sqrt((xx - cx) ** 2 + ((yy - cy) * 1.05) ** 2) / rad
        a = np.maximum(a, np.clip(1.0 - d, 0, 1) ** 0.6)
    a[int(h * 0.80):, :] *= np.linspace(1, 0, h - int(h * 0.80))[:, None]       # dasar rata
    a = np.asarray(Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(3)), dtype=np.float32) / 255.0
    shade = np.clip(1.0 - (yy / h - 0.30) * 1.5, 0.52, 1.0)                  # bagian bawah abu-biru: awan terbaca di latar terang
    img = np.zeros((h, w, 4), dtype=np.uint8)
    img[..., 0] = (255 * np.clip(shade * 0.96, 0, 1))
    img[..., 1] = (255 * np.clip(shade * 0.98, 0, 1))
    img[..., 2] = (255 * np.clip(shade + 0.10, 0, 1))
    img[..., 3] = (np.clip(a, 0, 1) ** 0.9 * 235)
    return Image.fromarray(img, "RGBA")

for i in range(3):
    blob_cloud(11 + i * 5).save(f"{OUT}/cloud_{i+1}.png")

def disc(path, core, halo, size=256, core_r=0.17, craters=False):
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float32)
    d = np.sqrt((xx - size / 2) ** 2 + (yy - size / 2) ** 2) / (size / 2)
    glow = np.clip(1.0 - d, 0, 1) ** 2.2
    disc_a = np.clip((core_r - d) / 0.012, 0, 1)
    img = np.zeros((size, size, 4), dtype=np.float32)
    for c in range(3):
        img[..., c] = halo[c] * (1 - disc_a) + core[c] * disc_a
    a = np.clip(glow * 0.75 + disc_a, 0, 1)
    if craters:
        r = np.random.default_rng(3)
        for _ in range(9):
            cx, cy = r.normal(0, 0.07, 2)
            rr = r.uniform(0.012, 0.035)
            dd = np.sqrt((xx / (size / 2) - 1 - cx) ** 2 + (yy / (size / 2) - 1 - cy) ** 2)
            m = np.clip((rr - dd) / 0.008, 0, 1) * disc_a
            for c in range(3):
                img[..., c] *= 1 - 0.14 * m
    img[..., 3] = a
    Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8), "RGBA").save(path)

disc(f"{OUT}/sun_disc.png", (1.0, 0.97, 0.82), (1.0, 0.82, 0.5))
disc(f"{OUT}/moon_disc.png", (0.93, 0.95, 1.0), (0.6, 0.7, 1.0), core_r=0.15, craters=True)
print("ok")
