extends RefCounted
## Bot uji peta: titik spawn tidak boleh di dalam benda padat, pemain tidak bisa keluar/jatuh dari arena, dan tidak macet di tepi.
## Jalankan: -- --bot=1 --botscript=map_bot --stage=<id> --fresh

var st: Node3D
var fails := 0


func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1


func _blocked(p: Vector3, r: float = 0.35) -> bool:
	var q := PhysicsShapeQueryParameters3D.new()
	var sp := SphereShape3D.new()
	sp.radius = r
	q.shape = sp
	q.transform = Transform3D(Basis(), p + Vector3(0, r + 0.3, 0))
	q.collision_mask = 1
	return not st.get_world_3d().direct_space_state.intersect_shape(q, 1).is_empty()


func _clear_enemies() -> void:
	for e in st.get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(e):
			e.queue_free()


func run(s: Node3D) -> void:
	st = s
	st.autoplay = true
	await st.get_tree().create_timer(1.0).timeout
	var R: float = st.arena.radius
	var p: Player = st.player
	check("pemain mulai di lantai & tidak di dalam benda", p.is_on_floor() and not _blocked(p.global_position), "pos=%s" % [p.global_position])
	# titik spawn musuh yang benar-benar dipakai stage (_spawn_pos) tidak boleh di dalam benda padat
	var bad := 0
	for i in 300:
		if _blocked(st._spawn_pos(), 0.5):
			bad += 1
	check("titik spawn musuh bebas dari benda padat", bad == 0, "terblokir %d/300 (R=%.0f)" % [bad, R])
	var bp: Vector3 = st.free_spot(Vector3(0, 0, -R * 0.55), 1.0)
	var bp2: Vector3 = st.free_spot(Vector3(0, 0, -R * 0.3), 1.0)
	print("  bos1 ", bp, " blk=", _blocked(bp, 1.0), "  bos2 ", bp2, " blk=", _blocked(bp2, 1.0), " | tanpa-free ", _blocked(Vector3(0, 0, -R * 0.55), 1.0), _blocked(Vector3(0, 0, -R * 0.3), 1.0))
	check("titik spawn bos tidak terblokir", not _blocked(bp, 1.0) and not _blocked(bp2, 1.0), "%s %s" % [bp, bp2])
	# uji tepi: berjalan ke luar di 8 arah, tidak boleh keluar arena / jatuh
	var esc := 0
	var worst := 0.0
	for k in 8:
		_clear_enemies()
		var a := k * TAU / 8.0
		var start := Vector3(cos(a), 0, sin(a)) * R * 0.7
		if _blocked(start, 0.4):
			start = Vector3(cos(a), 0, sin(a)) * R * 0.5
		p.global_position = start + Vector3(0, 0.1, 0)
		p.velocity = Vector3.ZERO
		await st.get_tree().create_timer(0.3).timeout
		var d3 := Vector3(cos(a), 0, sin(a))
		var v := d3.rotated(Vector3.UP, -st.cam.yaw)
		var t := 0.0
		while t < 3.0:
			_clear_enemies()
			p.hp = p.max_hp
			p.cam_yaw = st.cam.yaw
			p.move_input = Vector2(v.x, v.z)
			await st.get_tree().create_timer(0.1).timeout
			t += 0.1
		p.move_input = Vector2.ZERO
		var dist := Vector2(p.global_position.x, p.global_position.z).length()
		worst = maxf(worst, dist)
		if dist > R + 1.5 or p.global_position.y < -1.0:
			esc += 1
			print("  lolos arah ", k, " dist=%.1f y=%.1f" % [dist, p.global_position.y])
	check("pemain tidak bisa keluar/jatuh dari arena", esc == 0, "jarak terjauh %.1f dari R=%.0f" % [worst, R])
	check("tidak ada NaN pada posisi pemain", is_finite(p.global_position.x) and is_finite(p.global_position.y), "")
	print("CHECK SUMMARY fails=", fails)
