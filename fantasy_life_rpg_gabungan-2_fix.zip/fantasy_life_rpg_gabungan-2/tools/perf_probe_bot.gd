extends RefCounted
## Eksperimen: matikan satu kategori dan ukur selisih draw call (preset Lancar). Hanya alat diagnosis.
func _meas(scene: Node, n: int = 20) -> String:
	var t := scene.get_tree()
	var d := 0; var o := 0; var p := 0
	for i in n:
		await t.process_frame
		d += int(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME))
		o += int(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME))
		p += int(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME))
	return "draws=%d objs=%d prims=%d" % [d / n, o / n, p / n]
func run(scene: Node) -> void:
	var t := scene.get_tree()
	if "autoplay" in scene: scene.autoplay = true
	await t.create_timer(1.5).timeout
	GameState.set_setting("quality", int(OS.get_environment("PERF_Q") if OS.get_environment("PERF_Q") != "" else "0"), false)
	await t.create_timer(1.0).timeout
	print("PROBE base            ", await _meas(scene))
	var layers := t.root.find_children("*", "CanvasLayer", true, false)
	for l in layers: (l as CanvasLayer).visible = false
	print("PROBE no canvaslayers ", await _meas(scene), " (", layers.size(), " layers)")
	for l in layers: (l as CanvasLayer).visible = true
	var labels := scene.find_children("*", "Label3D", true, false)
	for l in labels: (l as Node3D).visible = false
	print("PROBE no label3d      ", await _meas(scene), " (", labels.size(), ")")
	for l in labels: (l as Node3D).visible = true
	var omni := scene.find_children("*", "OmniLight3D", true, false)
	for l in omni: (l as Node3D).visible = false
	print("PROBE no omni         ", await _meas(scene), " (", omni.size(), ")")
	for l in omni: (l as Node3D).visible = true
	var cp := scene.find_children("*", "CPUParticles3D", true, false)
	for l in cp: (l as Node3D).visible = false
	print("PROBE no cpuparticles ", await _meas(scene), " (", cp.size(), ")")
	for l in cp: (l as Node3D).visible = true
	var world := scene.get_node_or_null("World")
	if world: world.visible = false
	print("PROBE no World        ", await _meas(scene))
	if world: world.visible = true
	var npcs := scene.get_node_or_null("Npcs")
	if npcs: npcs.visible = false
	print("PROBE no Npcs         ", await _meas(scene))
	if npcs: npcs.visible = true
	var amb := scene.get_node_or_null("Ambient")
	if amb: amb.visible = false
	print("PROBE no Ambient      ", await _meas(scene))
	print("SUMMARY fails=0")
