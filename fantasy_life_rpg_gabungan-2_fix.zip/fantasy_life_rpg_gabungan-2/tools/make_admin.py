#!/usr/bin/env python3
"""Membuat build ADMIN dari proyek utama: salinan identik + alat uji (autoload Admin) + beberapa kait kecil.
Pemakaian: python3 tools/make_admin.py [tujuan]   (default ../fantasy_life_rpg_admin)
Build utama TIDAK berubah. Folder data user:// terpisah (nama proyek berbeda) sehingga save admin tidak menimpa save asli."""
import os, shutil, sys
src = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
dst = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(src), "fantasy_life_rpg_admin")
if os.path.exists(dst):
    shutil.rmtree(dst)
shutil.copytree(src, dst, ignore=shutil.ignore_patterns(".godot", "*.zip", "tools/admin"))
shutil.copy(os.path.join(src, "tools/admin/admin.gd"), os.path.join(dst, "autoload/admin.gd"))
for _f in ("admin_bot.gd", "admin_lobby_bot.gd"):
    shutil.copy(os.path.join(src, "tools/admin", _f), os.path.join(dst, "tools", _f))
shutil.rmtree(os.path.join(dst, "tools/admin"), ignore_errors=True)

def patch(path, old, new, count=1):
    p = os.path.join(dst, path)
    s = open(p).read()
    assert old in s, (path, old)
    s = s.replace(old, new, count)
    open(p, "w").write(s)

patch("project.godot", 'config/name="Fantasy Life RPG"', 'config/name="Fantasy Life RPG ADMIN"')
patch("project.godot", 'Flow="*res://autoload/flow.gd"', 'Flow="*res://autoload/flow.gd"\nAdmin="*res://autoload/admin.gd"')
# kait: god mode
patch("scripts/player/player.gd", "func take_damage(amount: int, from: Vector3 = Vector3.ZERO) -> bool:\n	if dead or invuln > 0.0:",
      "func take_damage(amount: int, from: Vector3 = Vector3.ZERO) -> bool:\n	if Admin.god and not dead:\n		return false\n	if dead or invuln > 0.0:")
# kait: tanpa cooldown
patch("scripts/player/player.gd", "	attack_cd = maxf(attack_cd - delta, 0.0)\n",
      "	attack_cd = maxf(attack_cd - delta, 0.0)\n	if Admin.no_cd:\n		attack_cd = 0.0\n		skill_cd = 0.0\n		dodge_cd = 0.0\n")
# kait: one-hit
patch("scripts/stages/stage.gd", "	final = maxi(final, 1)\n	e.take_damage(final, player.global_position, knock)",
      "	final = maxi(final, 1)\n	if Admin.one_hit:\n		final = 99999999\n	e.take_damage(final, player.global_position, knock)")
open(os.path.join(dst, "README_ADMIN.md"), "w").write("""# Fantasy Life RPG — BUILD ADMIN

Salinan **persis sama** dengan game utama + alat uji. Tombol merah **ADMIN** muncul di tengah atas semua layar (lobi, stage, menu).

## Alat di jendela ADMIN
- **Akun:** buka SEMUA karakter, ★ awakening maks, level 50, +1.000.000 gold, +100.000 diamond, buka & selesaikan semua stage, semua item ×99, senjata +10 semua, pity gacha hampir penuh.
- **Mode uji:** God Mode (kebal), One-hit kill, Tanpa cooldown (serang/skill/dodge), pulihkan HP, bunuh semua musuh, kecepatan game 0.4x / 1x / 2x.
- **Ganti karakter langsung:** ketuk nama karakter mana pun (lobi: jadi pemimpin; stage: jadi karakter aktif) untuk menguji serangan, skill, dan efeknya.
- **Stage & musuh:** mulai stage mana pun, spawn jenis musuh/bos apa pun di depan pemain, kembali ke lobi.

## Catatan
- Nama proyek berbeda ("... ADMIN") sehingga data simpanan (`user://`) terpisah dari game utama; save asli tidak tertimpa.
- Dibuat otomatis oleh `tools/make_admin.py` dari proyek utama (jalankan ulang setelah proyek utama berubah).
- Jangan dirilis ke pemain: build ini sengaja memberi semua kemampuan curang.
""")
print("Build admin dibuat di", dst)
