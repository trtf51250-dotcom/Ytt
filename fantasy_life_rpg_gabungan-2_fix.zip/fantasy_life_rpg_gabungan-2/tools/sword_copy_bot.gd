extends RefCounted
## Foto fase ayunan pedang dari samping untuk mencari "salinan pedang" di belakang karakter.
var st: Node3D
func run(s: Node3D) -> void:
	st = s
	var t := st.get_tree()
	var dir := "/tmp"
	var ids := ["ren"]
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shots="):
			dir = a.substr(8)
		if a.begins_with("--ids="):
			ids = a.substr(6).split(",")
	st.autoplay = true
	await t.create_timer(1.0).timeout
	for e in t.get_nodes_in_group("enemies"):
		e.queue_free()
	var p: Player = st.player
	for id in ids:
		GameState.unlock_character(id)
		p.set_character(id)
		p.invuln = 99.0
		p.global_position = Vector3(0, 0.1, 0)
		p.facing = 0.0
		p.control_enabled = true
		var cam := Camera3D.new()
		st.add_child(cam)
		cam.fov = 45.0
		cam.global_position = Vector3(-4.2, 2.6, -3.6)      # dari belakang-samping (karakter menghadap +Z)
		cam.look_at(Vector3(0, 1.0, 0.3))
		cam.make_current()
		await t.create_timer(0.5).timeout
		Engine.time_scale = 0.2
		p.attack_cd = 0.0
		p.do_attack()
		for i in 10:
			await t.create_timer(0.06).timeout
			st.get_viewport().get_texture().get_image().save_png("%s/sw_%s_%d.png" % [dir, id, i])
		Engine.time_scale = 1.0
		await t.create_timer(1.0).timeout
		cam.queue_free()
	print("done")
	t.quit()
