extends RefCounted
## Uji gaya serang per karakter: jeda serangan benar-benar berlaku, kombo Zeya 3 pukulan (penutup lebih kuat), DPS melawan
## target latihan (tiap karakter, level sama), skill menerjang Zeya kebal sesaat, foto pose belati.
var st: Node3D
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1

var _log: Array = []
func _on_hit(e, dmg: float) -> void:
	pass

func run(s: Node3D) -> void:
	st = s
	var t := st.get_tree()
	await t.create_timer(0.8).timeout
	for e in t.get_nodes_in_group("enemies"): e.queue_free()
	await t.create_timer(0.2).timeout
	var p: Player = st.player
	var dps := {}
	for id in ["ren", "zeya", "brann", "lyra", "sera", "hakuya"]:
		GameState.unlock_character(id)
		p.set_character(id)
		p.control_enabled = true
		p.velocity = Vector3.ZERO
		p.global_position = Vector3(0, 0.1, 0)
		p.facing = 0.0
		p.invuln = 99.0
		var rng: float = p.data.attack_range
		var dist: float = 1.8 if rng < 4.0 else 5.0
		var dummy: Enemy = st._spawn_enemy("slime", Vector3(0, 0, dist))
		await t.create_timer(1.0).timeout
		for oe in t.get_nodes_in_group("enemies"):      # musuh gelombang kini lebih tebal & tidak cepat mati: singkirkan agar tidak menyerap peluru
			if oe != dummy:
				oe.queue_free()
		dummy.hp = 9999999; dummy.max_hp = 9999999
		dummy.set_physics_process(false)
		dummy.global_position = Vector3(0, 0, dist)
		var hp0: int = dummy.hp
		var times: Array = []
		var idxs: Array = []
		var finals: Array = []
		var clk := [0.0]
		var T := 6.0
		var swings := [0]
		var cb := func(kind, _o, _d):
			if kind == "attack":
				times.append(clk[0])
				idxs.append(p.swing_idx)
				finals.append(p.swing_final)
		p.swing.connect(cb)
		while clk[0] < T:
			p.global_position = Vector3(0, 0.1, 0)
			p.do_attack()
			await t.physics_frame
			clk[0] += 1.0 / 60.0
		p.swing.disconnect(cb)
		var dealt := hp0 - dummy.hp
		dps[id] = dealt / T
		var min_gap := 99.0
		for i in range(1, times.size()):
			min_gap = minf(min_gap, times[i] - times[i - 1])
		print("  %s: pukulan=%d dmg=%d DPS=%.1f jeda_min=%.3f cd=%.2f idx=%s" % [id, times.size(), dealt, dealt / T, min_gap, p.data.attack_cooldown, str(idxs.slice(0, 7))])
		check("%s: jeda antar-serangan >= cooldown data (%.2f)" % [id, p.data.attack_cooldown], times.size() < 2 or min_gap >= p.data.attack_cooldown - 0.03, "min=%.3f" % min_gap)
		if id == "zeya":
			check("zeya: pola kombo 0,1,2,0,1,2", idxs.slice(0, 6) == [0, 1, 2, 0, 1, 2], str(idxs.slice(0, 6)))
			check("zeya: hanya pukulan ke-3 jadi penutup", finals.slice(0, 6) == [false, false, true, false, false, true])
			# kecepatan: tiga pukulan kombo lebih cepat dari 2 pukulan Ren
		dummy.queue_free()
		await t.create_timer(0.3).timeout
	check("hakuya ★6: DPS lebih tinggi dari karakter ★3-4 jarak dekat (Ren, Zeya)", dps["hakuya"] > dps["ren"] and dps["hakuya"] > dps["zeya"], "hakuya=%.1f ren=%.1f zeya=%.1f" % [dps["hakuya"], dps["ren"], dps["zeya"]])
	check("hakuya ★6: DPS masih wajar (<= 1.9x karakter jarak dekat terkuat; kritikal acak ±10%)", dps["hakuya"] <= maxf(dps["ren"], dps["zeya"]) * 1.9, "hakuya=%.1f" % dps["hakuya"])
	var rmax := maxf(dps["lyra"], dps["sera"])
	check("balans: DPS Ren & Zeya (jarak dekat, tanpa jarak aman) tidak melebihi jarak jauh +20% (kritikal acak membuat DPS 6 dtk bergeser ±10%)", dps["ren"] <= rmax * 1.2 and dps["zeya"] <= rmax * 1.2, "ren=%.1f lyra=%.1f sera=%.1f" % [dps["ren"], dps["lyra"], dps["sera"]])
	print("  DPS: ", dps)
	# kecepatan per pukulan zeya vs ren (waktu animasi)
	p.set_character("zeya")
	var za: float = p.rig.action_length("attack1")
	p.set_character("ren")
	var ra: float = p.rig.action_length("attack1")
	check("animasi pukulan Zeya lebih cepat dari Ren", za < ra * 0.7, "zeya=%.2f ren=%.2f" % [za, ra])
	# skill Zeya
	p.set_character("zeya")
	p.global_position = Vector3(0, 0.1, 0)
	p.facing = 0.0
	p.invuln = 0.0
	p.skill_cd = 0.0
	var e1: Enemy = st._spawn_enemy("slime", Vector3(0, 0, 3.0))
	await t.create_timer(1.0).timeout
	for oe in t.get_nodes_in_group("enemies"):
		if oe != e1:
			oe.queue_free()
	e1.hp = 99999; e1.max_hp = 99999
	e1.set_physics_process(false)
	p.velocity = Vector3.ZERO
	p.global_position = Vector3(0, 0.1, 0)
	e1.global_position = Vector3(0, 0, 3.0)
	p.facing = 0.0
	await t.physics_frame
	var hp1: int = e1.hp
	var x0 := p.global_position
	check("skill Zeya dipakai", p.do_skill())
	await t.create_timer(0.1).timeout
	check("skill Zeya: kebal sesaat", p.invuln > 0.3, "invuln=%.2f" % p.invuln)
	await t.create_timer(0.35).timeout
	await st._shot("zeya_skill")
	await t.create_timer(0.9).timeout
	var moved := p.global_position.distance_to(x0)
	check("skill Zeya menerjang maju & kena 2x", moved > 1.5 and hp1 - e1.hp > 0, "maju=%.1f dmg=%d musuh_z=%.1f hp=%d" % [moved, hp1 - e1.hp, e1.global_position.z, e1.hp])
	# foto kombo Zeya (pose belati)
	p.skill_cd = 0.0
	p.global_position = Vector3(0, 0.1, 0)
	p.attack_cd = 0.0
	p.do_attack()
	await t.create_timer(0.1).timeout
	await st._shot("zeya_atk1")
	await t.create_timer(0.35).timeout
	p.do_attack()
	await t.create_timer(0.2).timeout
	await st._shot("zeya_atk2")
	await t.create_timer(0.3).timeout
	p.do_attack()
	await t.create_timer(0.25).timeout
	await st._shot("zeya_atk3")
	print("FAILS=", fails)
