extends RefCounted
## Ukur Enemy._separate (dipanggil tiap musuh tiap frame fisika) dan cetak checksum hasilnya (harus sama sebelum/sesudah optimasi).
##   godot --path . scenes/stages/stage.tscn -- --bot=1 --botscript=sep_perf_bot --stage=s1_1 --fresh
func run(st: Node3D) -> void:
	await st.get_tree().create_timer(1.0).timeout
	var list: Array = []
	for i in 24:
		var a := float(i) * 0.9
		var e: Enemy = st._spawn_enemy("slime", Vector3(cos(a) * (1.0 + (i % 5) * 0.35), 0, sin(a) * (1.0 + (i % 4) * 0.4)))
		e.set_physics_process(false)                       # bekukan supaya checksum deterministik
		e.global_position = Vector3(cos(a) * (1.0 + (i % 5) * 0.35), 0, sin(a) * (1.0 + (i % 4) * 0.4))
		list.append(e)
	await st.get_tree().process_frame
	for e in list:
		e.global_position = Vector3(cos(float(list.find(e)) * 0.9) * (1.0 + (list.find(e) % 5) * 0.35), 0, sin(float(list.find(e)) * 0.9) * (1.0 + (list.find(e) % 4) * 0.4))
	var all: Array = list
	var sum := 0.0
	for e in all:
		if e is Enemy:
			e.velocity = Vector3.ZERO
			e._separate(0.016)
			sum += e.velocity.length() + e.velocity.x * 0.37 - e.velocity.z * 0.11
	print("PERF separate checksum: %.5f (%d musuh)" % [sum, all.size()])
	var n := 40
	var t0 := Time.get_ticks_usec()
	for k in n:
		for e in all:
			if e is Enemy:
				e._separate(0.016)
	var calls := n * all.size()
	print("PERF separate: %.4f ms/panggilan, %.3f ms per frame untuk %d musuh" % [(Time.get_ticks_usec() - t0) / 1000.0 / calls, (Time.get_ticks_usec() - t0) / 1000.0 / n, all.size()])
	print("SUMMARY fails=0")
