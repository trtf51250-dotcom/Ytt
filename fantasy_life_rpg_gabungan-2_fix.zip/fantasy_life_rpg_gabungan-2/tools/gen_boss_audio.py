#!/usr/bin/env python3
"""Efek suara & musik tambahan untuk bos Penguasa Gua (sintetis, tanpa aset luar).
Jalankan:  python3 tools/gen_boss_audio.py   -> assets/audio/boss_*.wav, music_lair.wav
Memakai fungsi bantu dari gen_audio.py; tidak menyentuh file audio yang sudah ada."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen_audio as g  # noqa: E402

SR = g.SR
rng = np.random.default_rng(21)


def nz(n):
    return rng.uniform(-1, 1, n)


def saw_from_freq(f):
    ph = np.cumsum(f) / SR
    return 2.0 * (ph % 1.0) - 1.0


def env(n, a=0.08, r=0.3):
    e = np.ones(n)
    na, nr = max(int(n * a), 1), max(int(n * r), 1)
    e[:na] = np.linspace(0, 1, na)
    e[-nr:] = np.linspace(1, 0, nr)
    return e


def roar(dur, f0, f1, growl_hz=30.0, noise_amt=0.8, vib=14.0):
    t = g.tt(dur, SR)
    n = len(t)
    f = np.linspace(f0, f1, n) * (1.0 + 0.06 * np.sin(2 * np.pi * vib * t))
    body = saw_from_freq(f) * 0.6 + saw_from_freq(f * 1.5) * 0.25
    am = 0.55 + 0.45 * np.sin(2 * np.pi * growl_hz * t)
    rasp = g.lowpass(nz(n), 0.09) * noise_amt * 2.2
    return (body + rasp) * am


def make():
    # raungan panjang (muncul / fase 2 / gelombang kejut)
    r = roar(1.7, 62, 40, 26, 0.9)
    r *= np.concatenate([np.linspace(0, 1, int(SR * 0.25)), np.ones(len(r) - int(SR * 0.25) - int(SR * 0.5)), np.linspace(1, 0, int(SR * 0.5))])
    g.write_wav("boss_roar", r, SR)
    # geraman pendek (aba-aba cakar / seruduk)
    r = roar(0.55, 95, 70, 38, 0.6)
    g.write_wav("boss_growl", r * env(len(r), 0.12, 0.45), SR)
    # sabetan cakar: desir + sobekan
    t = g.tt(0.32, SR)
    n = len(t)
    air = (g.lowpass(nz(n), 0.55) - g.lowpass(nz(n), 0.06)) * np.sin(np.pi * np.linspace(0, 1, n)) ** 0.8
    g.write_wav("boss_swipe", air + g.sweep(700, 180, t, "sine") * 0.25 * g.decay(n, 3), SR)
    # benturan cakar ke tanah: gebuk + serpihan
    t = g.tt(0.4, SR)
    n = len(t)
    x = (g.sweep(210, 55, t, "sine") * 1.0 + nz(n) * 0.7 * g.decay(n, 9)) * g.decay(n, 5)
    for k in (0.05, 0.11, 0.18):
        i = int(k * SR)
        x[i:i + 300] += nz(300) * 0.4 * g.decay(300, 6)
    g.write_wav("boss_claw_hit", x, SR)
    # seruduk: gemuruh menggebu
    t = g.tt(0.8, SR)
    n = len(t)
    am = 0.6 + 0.4 * np.sin(2 * np.pi * np.linspace(10, 22, n) * t)
    x = (g.lowpass(nz(n), 0.05) * 2.0 + g.sweep(48, 95, t, "sine") * 0.9) * am * np.linspace(0.3, 1, n) * np.concatenate([np.ones(n - int(SR * 0.12)), np.linspace(1, 0, int(SR * 0.12))])
    g.write_wav("boss_charge", x, SR)
    # tabrakan seruduk / dinding
    t = g.tt(0.8, SR)
    n = len(t)
    x = (g.lowpass(nz(n), 0.18) * 1.6 + g.sweep(95, 28, t, "sine") * 1.2) * g.decay(n, 4.5)
    for k in (0.08, 0.15, 0.26, 0.33):
        i = int(k * SR)
        x[i:i + 400] += nz(400) * 0.35 * g.decay(400, 6)
    g.write_wav("boss_crash", x, SR)
    # gelombang kejut: denyut rendah naik lalu pecah
    t = g.tt(1.1, SR)
    n = len(t)
    f = 38 + 85 * np.sin(np.pi * np.linspace(0, 1, n) ** 0.6)
    x = saw_from_freq(f) * 0.0 + np.sin(2 * np.pi * np.cumsum(f) / SR) * 1.0
    x += g.lowpass(nz(n), 0.07) * 1.3 * np.concatenate([np.linspace(0.2, 1, int(n * 0.35)), g.decay(n - int(n * 0.35), 3.5)])
    g.write_wav("boss_wave", x * np.concatenate([np.linspace(0, 1, int(n * 0.1)), np.ones(n - int(n * 0.1))]), SR)
    # langkah berat
    t = g.tt(0.28, SR)
    n = len(t)
    g.write_wav("boss_step", (g.sweep(95, 38, t, "sine") * 1.0 + g.lowpass(nz(n), 0.12) * 0.55) * g.decay(n, 7.5), SR)
    # kesakitan
    r = roar(0.5, 200, 110, 22, 0.7, vib=9)
    g.write_wav("boss_hurt", r * g.decay(len(r), 2.2) * env(len(r), 0.04, 0.1), SR)
    # mati: raungan menurun lalu ambruk
    r = roar(2.0, 120, 30, 16, 0.9, vib=6)
    r *= np.linspace(1, 0.15, len(r)) * env(len(r), 0.03, 0.25)
    t = g.tt(0.9, SR)
    n = len(t)
    thud = (g.sweep(80, 25, t, "sine") * 1.3 + g.lowpass(nz(n), 0.15) * 1.0) * g.decay(n, 4)
    out = np.concatenate([r, np.zeros(int(SR * 0.1)), thud])
    g.write_wav("boss_death", out, SR)


def make_music():
    # sarang: A phrygian berat, 132 bpm, bass kasar + drum
    Pl = [[0, 0, 2, 0, 1, 0, 2, 3], [0, 2, 0, 3, 2, 1, 0, None], [4, 3, 2, 3, 1, 2, 0, 1], [0, None, 1, 0, 2, 1, 3, 2]]
    g.write_wav("music_lair", g.render(45, g.PHRYG, [0, 1, 0, 6], Pl, 132, lead="sq", bass="sq", drums=True, arp=True, vol_lead=0.22, bars=8, seed=3), g.MSR, loop=True)

    # altar kehampaan: A minor lebih lambat & suram, 118 bpm, bass segitiga + drum, arpeggio lead
    Pa = [[0, None, 2, 0, 4, 2, 0, None], [3, 2, 0, 2, 4, 3, 2, 0], [0, 2, 4, 6, 4, 2, 3, 1], [2, 0, None, 1, 2, 3, 4, 2]]
    g.write_wav("music_abyss", g.render(40, g.MINOR, [0, 5, 3, 6], Pa, 118, lead="sq", bass="tri", drums=True, arp=True, vol_lead=0.2, bars=8, seed=9), g.MSR, loop=True)


if __name__ == "__main__":
    make()
    make_music()
    for fn in sorted(os.listdir(g.OUT)):
        if fn.startswith("boss_") or fn in ("music_lair.wav", "music_abyss.wav"):
            print("%-20s %7.1f KB" % (fn, os.path.getsize(os.path.join(g.OUT, fn)) / 1024))
