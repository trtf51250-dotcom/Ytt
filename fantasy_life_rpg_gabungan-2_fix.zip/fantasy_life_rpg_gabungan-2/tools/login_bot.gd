extends RefCounted
## Menguji bonus login 3 hari dengan tanggal palsu (GameState._fake_date). Mode:
##   (default)  : jalankan dengan --fresh; klaim hari 1-3, cek hadiah, cek klaim ganda, tangkapan layar.
##   --mode=save: tanpa --fresh; reset simpan, klaim hari 1-3, simpan ke disk.
##   --mode=load: tanpa --fresh; muat simpanan dan cek progres login + Zeya tetap ada.
var lobby: Node3D
var fails := 0


func _wait(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout


func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1


func run(l: Node3D) -> void:
	lobby = l
	var gs := GameState
	var mode: String = lobby._arg("mode")
	await _wait(0.5)
	if mode == "load":
		check("simpanan: login_days = 3", gs.login_days == 3, str(gs.login_days))
		check("simpanan: Zeya ada di roster", gs.is_unlocked("zeya"))
		check("simpanan: tidak bisa klaim lagi", not gs.login_claimable())
		print("login_last=", gs.login_last, " roster=", gs.roster.keys())
		print("BOT DONE fails=", fails)
		lobby.get_tree().quit(fails)
		return
	if mode == "save":
		gs.delete_save()
		gs._volatile = false
		gs.new_game()
	gs._fake_date = "2026-11-02"
	check("awal: belum punya Zeya", not gs.is_unlocked("zeya"))
	check("awal: bisa klaim", gs.login_claimable())
	if mode == "":
		lobby.host.open("login")
		await _wait(0.5)
		await lobby._shot("login_day1")
		lobby.host.close()
		await _wait(0.3)
		await lobby._shot("lobby_gift_badge")
	# hari 1
	var g0 := gs.gold
	var d0 := gs.diamonds
	var p0 := gs.item_count("p_small")
	var r := gs.claim_login()
	check("hari 1: emas +1000", gs.gold == g0 + 1000, "%d -> %d" % [g0, gs.gold])
	check("hari 1: berlian +100", gs.diamonds == d0 + 100)
	check("hari 1: ramuan kecil +3", gs.item_count("p_small") == p0 + 3)
	check("hari 1: bukan karakter", not r.get("new_character", true))
	check("klaim ganda di hari yang sama ditolak", gs.claim_login().is_empty() and gs.gold == g0 + 1000)
	# hari 2 (besok)
	gs._fake_date = "2026-11-03"
	check("besok: bisa klaim", gs.login_claimable())
	g0 = gs.gold
	d0 = gs.diamonds
	var b0 := gs.item_count("p_big")
	gs.claim_login()
	check("hari 2: emas +1500, berlian +150, ramuan besar +2", gs.gold == g0 + 1500 and gs.diamonds == d0 + 150 and gs.item_count("p_big") == b0 + 2)
	check("hari 2: Zeya belum ada", not gs.is_unlocked("zeya"))
	# hari 3 setelah jeda 1 minggu (tidak harus berturut-turut)
	gs._fake_date = "2026-11-10"
	check("jeda seminggu: tetap bisa klaim", gs.login_claimable())
	if mode == "":
		lobby.host.open("login")
		await _wait(0.5)
		await lobby._shot("login_day3_ready")
		lobby.host.close()
	d0 = gs.diamonds
	var party0 := gs.party.size()
	r = gs.claim_login()
	check("hari 3: Zeya terbuka", gs.is_unlocked("zeya") and r.get("new_character", false))
	check("hari 3: berlian +200", gs.diamonds == d0 + 200)
	check("Zeya punya senjata awal", str(gs.equipment.get("zeya", {}).get("weapon", "")) != "", str(gs.equipment.get("zeya", {})))
	print("party sebelum=", party0, " sesudah=", gs.party.size(), " -> ", gs.party)
	check("login_days = 3", gs.login_days == 3)
	gs._fake_date = "2026-12-25"
	check("setelah selesai: tidak ada klaim lagi", not gs.login_claimable() and gs.claim_login().is_empty())
	if mode == "save":
		gs.save_game()
		print("saved to disk")
	if mode == "":
		lobby.host.open("login")
		await _wait(0.5)
		await lobby._shot("login_done")
		lobby.host.open("party")
		await _wait(0.5)
		await lobby._shot("party_with_zeya")
		lobby.host.open("character", {"id": "zeya"})
		await _wait(0.6)
		await lobby._shot("character_zeya")
		lobby.host.close()
		await _wait(0.3)
		await lobby._shot("lobby_gift_hidden")
	print("BOT DONE fails=", fails)
	lobby.get_tree().quit(fails)
