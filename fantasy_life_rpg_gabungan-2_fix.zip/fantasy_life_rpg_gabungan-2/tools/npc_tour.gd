extends RefCounted
## Bot: memindahkan pemain ke depan tiap NPC/bangunan penting dan memotret (memeriksa penempatan setelah penataan ulang kota).
func run(l: Node3D) -> void:
	var tree := l.get_tree()
	await tree.create_timer(1.0).timeout
	l.hud.visible = false
	for id in ["merchant", "blacksmith", "party_leader", "priestess", "gate_guard", "info"]:
		var n: Node3D = l.npcs[id]
		var fwd := Vector3(sin(n.rotation.y), 0, cos(n.rotation.y))
		l.player.global_position = n.global_position + fwd * 4.0
		l.player.facing = n.rotation.y + PI
		l.cam.snap_to_target()
		await tree.create_timer(0.5).timeout
		await l._shot("npc_" + id)
	# portal & altar
	for it in l.world.interactions:
		if it["id"] in ["portal", "altar", "party_table"]:
			l.player.global_position = it["pos"] + Vector3(0, 0, 3.0)
			l.cam.snap_to_target()
			await tree.create_timer(0.5).timeout
			await l._shot("spot_" + it["id"])
