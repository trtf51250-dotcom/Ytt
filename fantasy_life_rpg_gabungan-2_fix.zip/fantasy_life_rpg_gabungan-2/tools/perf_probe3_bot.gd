extends RefCounted
## Telusur rekursif UI: tampilkan node yang jika disembunyikan mengurangi >= MIN draw call.
const MIN := 6
func _meas(t: SceneTree, n: int = 6) -> int:
	var d := 0
	for i in n:
		await t.process_frame
		d += int(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME))
	return d / n
func _drill(t: SceneTree, n: Node, base: int, depth: int) -> void:
	for ch in n.get_children():
		if not (ch is CanvasItem) or not (ch as CanvasItem).visible: continue
		var ci := ch as CanvasItem
		ci.visible = false
		var d := await _meas(t)
		ci.visible = true
		var rem := base - d
		if rem >= MIN:
			var extra := ""
			if ch is Label: extra = " text='%s' outline=%d" % [(ch as Label).text.substr(0, 16), (ch as Label).get_theme_constant("outline_size")]
			if ch.get_script() != null: extra += " script=" + str(ch.get_script().resource_path.get_file())
			print("P3 %s%-28s %-16s removed=%3d%s" % ["  ".repeat(depth), ch.name, ch.get_class(), rem, extra])
			if depth < 4: await _drill(t, ch, base, depth + 1)
func run(scene: Node) -> void:
	var t := scene.get_tree()
	if "autoplay" in scene: scene.autoplay = true
	await t.create_timer(1.5).timeout
	GameState.set_setting("quality", 0, false)
	await t.create_timer(1.0).timeout
	var base := await _meas(t)
	print("P3 base=", base)
	for l in t.root.find_children("*", "CanvasLayer", true, false):
		if (l as CanvasLayer).layer == 10:
			await _drill(t, l, base, 0)
	print("SUMMARY fails=0")
