extends Node
## Foto layar judul: tanpa data, dengan data, data diblokir. Menulis ke user:// (dibersihkan di akhir). Jalankan tanpa --fresh.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1
func _shot(name: String) -> void:
	var dir := ""
	for x in OS.get_cmdline_user_args():
		if x.begins_with("--shots="): dir = x.substr(8)
	if dir != "":
		get_viewport().get_texture().get_image().save_png("%s/%s.png" % [dir, name])
func _titles() -> Array:
	var out: Array = []
	for b in get_tree().root.find_children("*", "Button", true, false):
		if (b as Button).is_visible_in_tree(): out.append((b as Button).text)
	return out
func _open() -> Node:
	var t: Node = load("res://scenes/title.tscn").instantiate()
	add_child(t)
	await get_tree().create_timer(0.6).timeout
	return t
func _ready() -> void:
	var gs := GameState
	gs.delete_save(); DirAccess.remove_absolute(ProjectSettings.globalize_path(gs.SANCTION_PATH)); gs.banned = false
	var t := await _open()
	var tx := _titles()
	check("tanpa data: Mulai Bermain + Pulihkan, TANPA Lanjutkan/Hapus", "Mulai Bermain" in tx and "Pulihkan dari Kode Cadangan" in tx and not ("Lanjutkan" in tx) and not ("Hapus Data" in tx), str(tx))
	await _shot("title_kosong")
	t.queue_free(); await get_tree().process_frame
	gs.start_new_game(); gs.player_name = "Gt"; gs.level = 7; gs.save_game()
	t = await _open()
	tx = _titles()
	check("ada data: Lanjutkan + Mulai Baru + Hapus Data, TANPA Pulihkan", "Lanjutkan" in tx and "Mulai Baru" in tx and "Hapus Data" in tx and not ("Pulihkan dari Kode Cadangan" in tx), str(tx))
	await _shot("title_ada_data")
	check("tidak ada kata SV/slot/dunia di tombol", not tx.any(func(s): return s.contains("SV") or s.to_lower().contains("slot") or s.to_lower().contains("dunia")), str(tx))
	t.queue_free(); await get_tree().process_frame
	gs._impose_ban("Kode cadangan dari perangkat lain dipakai di perangkat ini (save dibagikan).", gs.player_id)
	t = await _open()
	tx = _titles()
	check("diblokir: tidak ada tombol Lanjutkan/Mulai/Pulihkan", not ("Lanjutkan" in tx) and not ("Mulai Bermain" in tx) and not ("Pulihkan dari Kode Cadangan" in tx), str(tx))
	await _shot("title_diblokir")
	t.queue_free(); await get_tree().process_frame
	gs.delete_save(); DirAccess.remove_absolute(ProjectSettings.globalize_path(gs.SANCTION_PATH)); gs.banned = false
	print("CHECK SUMMARY fails=", fails)
	get_tree().quit()
