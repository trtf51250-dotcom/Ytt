extends Node3D
## Alat pengembang: membangun LobbyWorld penuh, mencetak statistik + cek tumpang tindih, dan menyimpan screenshot dari kamera yang diberikan.
##   --cam=x,y,z --look=x,y,z --out=file.png --fov=60
func _arg(key: String, default: String) -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % key):
			return a.substr(key.length() + 3)
	return default


func _vec(s: String) -> Vector3:
	var p := s.split(",")
	return Vector3(float(p[0]), float(p[1]), float(p[2]))


func _ready() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.6, 0.78, 0.95)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.75, 0.8, 0.95)
	e.ambient_light_energy = 0.5
	e.fog_enabled = true
	e.fog_light_color = Color(0.72, 0.84, 0.97)
	e.fog_density = 0.0
	e.fog_depth_begin = 120.0
	e.fog_depth_end = 360.0
	env.environment = e
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -30, 0)
	sun.light_color = Color(1.0, 0.95, 0.86)
	sun.light_energy = 0.85
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 120.0
	add_child(sun)
	var t0 := Time.get_ticks_msec()
	var w := LobbyWorld.new()
	add_child(w)
	w.build()
	print("world build ms: ", Time.get_ticks_msec() - t0)
	var verts := 0
	for c in w.get_children():
		if c is MeshInstance3D:
			verts += (c.mesh as ArrayMesh).surface_get_array_len(0) if (c.mesh as ArrayMesh).get_surface_count() > 0 else 0
	print("buildings: ", w.buildings.size(), "  chunk meshes verts(surface0): ", verts, "  colliders: ", w.sink.items.size(), "  trees: ", w.tree_positions.size())
	# cek tumpang tindih antarbangunan
	var bl: Array = w.buildings
	for i in bl.size():
		for j in range(i + 1, bl.size()):
			var a: Building = bl[i]
			var b: Building = bl[j]
			var d := Vector2(a.position.x - b.position.x, a.position.z - b.position.z).length()
			if d < (a.footprint + b.footprint) * 0.72:
				print("OVERLAP? ", a.name, " <-> ", b.name, " d=", snappedf(d, 0.1), " fp=", a.footprint, "+", b.footprint)
	var cam := Camera3D.new()
	cam.fov = float(_arg("fov", "60"))
	cam.far = 600.0
	cam.position = _vec(_arg("cam", "0,90,100"))
	add_child(cam)
	cam.look_at(_vec(_arg("look", "0,0,5")))
	for n in 8:
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png(_arg("out", "/tmp/world.png"))
	print("saved")
	get_tree().quit()
