extends RefCounted
var lobby: Node3D
func run(l: Node3D) -> void:
	lobby = l
	await lobby.get_tree().create_timer(0.8).timeout
	var dn: DayNight = lobby.daynight
	for hh in [11.0, 22.5]:
		dn.fixed_hour = hh
		dn.hour = hh
		await lobby.get_tree().create_timer(1.2).timeout
		await lobby._shot("amb_%d" % int(hh))
		var vis := 0
		for c in lobby.get_node("Ambient").get_children():
			if c.visible: vis += 1
		print("CHECK ambient visible at ", hh, ": ", vis, " of ", lobby.get_node("Ambient").get_child_count())
