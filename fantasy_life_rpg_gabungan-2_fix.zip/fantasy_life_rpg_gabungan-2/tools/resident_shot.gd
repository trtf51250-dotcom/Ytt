extends RefCounted
func run(l: Node3D) -> void:
	var tree := l.get_tree()
	await tree.create_timer(1.0).timeout
	l.hud.visible = false
	var v: Villager = null
	for x in l.villagers:
		if x._def.get("home", false):
			v = x
			break
	l.player.global_position = v.global_position + Vector3(4, 0, 0)
	l.player.facing = -PI / 2
	l.cam.snap_to_target()
	await tree.create_timer(1.0).timeout
	await l._shot("resident")
	tree.quit()
