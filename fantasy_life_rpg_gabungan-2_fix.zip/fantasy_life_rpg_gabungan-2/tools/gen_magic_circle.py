"""Membuat tekstur lingkaran sihir bintang (orisinal, dihasilkan prosedural): assets/fx/magic_outer.png dan magic_inner.png.
Putih-kebiruan di atas transparan; diwarnai & dibuat bersinar (additive) di game. Jalankan: python3 tools/gen_magic_circle.py"""
import math, random, os
from PIL import Image, ImageDraw, ImageFilter

S = 2048          # kanvas kerja (dikecilkan ke 1024)
C = S // 2
R = C - 40
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "fx")
os.makedirs(OUT, exist_ok=True)
rng = random.Random(7)


def pt(r, a):
    return (C + math.cos(a) * r * R, C + math.sin(a) * r * R)


def ring(d, r, w):
    d.ellipse([C - r * R, C - r * R, C + r * R, C + r * R], outline=255, width=w)


def poly_star(d, r, n, k, w, rot=-math.pi / 2):
    pts = [pt(r, rot + i * 2 * math.pi * k / n) for i in range(n)]
    for i in range(n):
        d.line([pts[i], pts[(i + 1) % n]], fill=255, width=w)


def star4(d, cx, cy, s, w):
    d.line([(cx - s, cy), (cx + s, cy)], fill=255, width=w)
    d.line([(cx, cy - s), (cx, cy + s)], fill=255, width=w)
    d.line([(cx - s * .55, cy - s * .55), (cx + s * .55, cy + s * .55)], fill=255, width=max(2, w // 2))
    d.line([(cx - s * .55, cy + s * .55), (cx + s * .55, cy - s * .55)], fill=255, width=max(2, w // 2))


def rune(d, r, a, size, w):
    """Goresan rune acak (bukan huruf asli): beberapa garis pendek & lengkung di sekitar titik (r,a)."""
    cx, cy = pt(r, a)
    ang = a + math.pi / 2
    ux, uy = math.cos(ang), math.sin(ang)
    vx, vy = -uy, ux
    n = rng.randint(3, 5)
    px, py = 0.0, 0.0
    for _ in range(n):
        nx = px + rng.uniform(0.3, 1.0) * size
        ny = rng.uniform(-0.8, 0.8) * size
        d.line([(cx + ux * px + vx * py, cy + uy * px + vy * py), (cx + ux * nx + vx * ny, cy + uy * nx + vy * ny)], fill=255, width=w)
        px, py = nx, ny
    # satu titik/garis penanda
    d.ellipse([cx + vx * size * .9 - w, cy + vy * size * .9 - w, cx + vx * size * .9 + w, cy + vy * size * .9 + w], fill=255)


def glow(mask, strength=1.0):
    base = mask.filter(ImageFilter.GaussianBlur(3)).point(lambda v: min(255, int(v * 1.0)))
    g1 = mask.filter(ImageFilter.GaussianBlur(14)).point(lambda v: int(v * 0.8 * strength))
    g2 = mask.filter(ImageFilter.GaussianBlur(40)).point(lambda v: int(v * 0.7 * strength))
    out = Image.new("L", mask.size, 0)
    from PIL import ImageChops
    for layer in (g2, g1, base):
        out = ImageChops.lighter(out, layer)
    return out


def save(mask, name):
    a = glow(mask, 1.7).resize((1024, 1024), Image.LANCZOS)
    rgb = Image.merge("RGB", [a.point(lambda v: min(255, int(v * 0.75 + 70 * (v / 255.0)))), a.point(lambda v: min(255, int(v * 0.93 + 40 * (v / 255.0)))), a])
    img = Image.merge("RGBA", [*rgb.split(), a])
    img.save(os.path.join(OUT, name))


# ---- luar: cincin ganda, pita rune, 8 bintang kecil
m = Image.new("L", (S, S), 0)
d = ImageDraw.Draw(m)
ring(d, 1.0, 16)
ring(d, 0.955, 8)
ring(d, 0.78, 10)
ring(d, 0.745, 6)
for i in range(8):
    a = i * math.pi / 4 + math.pi / 8
    x, y = pt(0.867, a)
    d.ellipse([x - 62, y - 62, x + 62, y + 62], outline=255, width=8)
    star4(d, x, y, 40, 8)
for i in range(8):
    a0 = i * math.pi / 4 + math.pi / 8
    for j in range(3):
        a = a0 + math.radians(9 + j * 11)
        rune(d, 0.867, a, 38, 7)
save(m, "magic_outer.png")

# ---- dalam: heptagram, pentagram bintang, cincin dalam, rune kecil
m = Image.new("L", (S, S), 0)
d = ImageDraw.Draw(m)
poly_star(d, 0.70, 7, 2, 14)
poly_star(d, 0.40, 5, 2, 18)
ring(d, 0.62, 6)
ring(d, 0.50, 8)
ring(d, 0.20, 8)
ring(d, 0.075, 8)
star4(d, C, C, 0.09 * R, 8)
for i in range(7):
    a = -math.pi / 2 + i * 2 * math.pi / 7 + math.pi / 7
    rune(d, 0.54, a, 30, 6)
for i in range(5):
    a = -math.pi / 2 + i * 2 * math.pi / 5
    x, y = pt(0.40, a)
    d.ellipse([x - 20, y - 20, x + 20, y + 20], fill=255)
save(m, "magic_inner.png")
print("ok")
