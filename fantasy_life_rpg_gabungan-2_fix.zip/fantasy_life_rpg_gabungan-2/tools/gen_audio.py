#!/usr/bin/env python3
"""Membuat semua efek suara & musik chiptune untuk game (tanpa aset luar).

Jalankan:  python3 tools/gen_audio.py   -> assets/audio/*.wav
"""
import os
import struct

import numpy as np

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "audio")
os.makedirs(OUT, exist_ok=True)
RNG = np.random.default_rng(7)


def write_wav(name, data, sr, loop=False):
    data = np.asarray(data, dtype=np.float64)
    peak = np.max(np.abs(data)) or 1.0
    data = data / peak * 0.85
    pcm = (data * 32767).astype("<i2").tobytes()
    fmt = struct.pack("<HHIIHH", 1, 1, sr, sr * 2, 2, 16)
    chunks = b"fmt " + struct.pack("<I", len(fmt)) + fmt
    if loop:
        n = len(data)
        smpl = struct.pack("<IIIIIIIII", 0, 0, int(1e9 / sr), 60, 0, 0, 0, 1, 0)
        smpl += struct.pack("<IIIIII", 0, 0, 0, n - 1, 0, 0)
        chunks += b"smpl" + struct.pack("<I", len(smpl)) + smpl
    chunks += b"data" + struct.pack("<I", len(pcm)) + pcm
    riff = b"RIFF" + struct.pack("<I", 4 + len(chunks)) + b"WAVE" + chunks
    with open(os.path.join(OUT, name + ".wav"), "wb") as f:
        f.write(riff)


def tt(d, sr):
    return np.arange(int(sr * d)) / sr


def sq(f, t, duty=0.5):
    ph = (f * t) % 1.0
    return np.where(ph < duty, 1.0, -1.0)


def tri(f, t):
    return 2 * np.abs(2 * ((f * t) % 1.0) - 1) - 1


def sine(f, t):
    return np.sin(2 * np.pi * f * t)


def noise(n):
    return RNG.uniform(-1, 1, n)


def decay(n, k=6.0):
    return np.exp(-k * np.linspace(0, 1, n))


def sweep(f0, f1, t, shape="sq"):
    d = t[-1] if len(t) else 1.0
    f = f0 + (f1 - f0) * (t / max(d, 1e-6))
    ph = np.cumsum(f) / (len(t) / max(d, 1e-6))
    if shape == "sine":
        return np.sin(2 * np.pi * ph)
    if shape == "tri":
        return 2 * np.abs(2 * (ph % 1.0) - 1) - 1
    return np.where((ph % 1.0) < 0.5, 1.0, -1.0)


def lowpass(x, a=0.2):
    y = np.zeros_like(x)
    acc = 0.0
    for i, v in enumerate(x):
        acc += a * (v - acc)
        y[i] = acc
    return y


SR = 22050


def make_sfx():
    t = tt(0.16, SR)
    write_wav("swing", lowpass(noise(len(t)), 0.35) * np.sin(np.pi * np.linspace(0, 1, len(t))) ** 0.7, SR)
    t = tt(0.14, SR)
    write_wav("hit", (sweep(240, 70, t, "sine") * 0.9 + noise(len(t)) * 0.5) * decay(len(t), 5), SR)
    t = tt(0.32, SR)
    write_wav("hurt", sweep(300, 90, t, "sq") * decay(len(t), 3.5), SR)
    t = tt(0.22, SR)
    n = len(t)
    pk = np.concatenate([sq(880, t[: n // 2], 0.25), sq(1320, t[n // 2:], 0.25)]) * decay(n, 3)
    write_wav("pickup", pk, SR)
    # shard: arpeggio panjang
    notes = [523, 659, 784, 1047, 1319, 1568, 2093]
    parts = []
    for i, f in enumerate(notes):
        tn = tt(0.16, SR)
        parts.append((tri(f, tn) * 0.8 + sine(f * 2, tn) * 0.3) * decay(len(tn), 3))
    sh = np.concatenate(parts + [tri(1047, tt(0.6, SR)) * decay(int(SR * 0.6), 2.5)])
    write_wav("shard", sh, SR)
    t = tt(0.55, SR)
    write_wav("door", lowpass(noise(len(t)), 0.08) * 1.5 * (1 - np.linspace(0, 1, len(t)) ** 2) + sweep(90, 50, t, "sine") * 0.8, SR)
    t = tt(0.7, SR)
    write_wav("boom", (lowpass(noise(len(t)), 0.1) * 1.4 + sweep(110, 35, t, "sine")) * decay(len(t), 4), SR)
    t = tt(0.09, SR)
    write_wav("select", sq(660, t, 0.25) * decay(len(t), 3), SR)
    t = tt(0.2, SR)
    write_wav("dash", lowpass(noise(len(t)), 0.15) * np.sin(np.pi * np.linspace(0, 1, len(t))), SR)
    t = tt(0.18, SR)
    write_wav("shoot", sweep(900, 300, t, "sq") * decay(len(t), 4), SR)
    t = tt(0.45, SR)
    write_wav("die", (sweep(400, 60, t, "sq") * 0.7 + noise(len(t)) * 0.3) * decay(len(t), 3), SR)
    parts = [sq(f, tt(0.1, SR), 0.25) * decay(int(SR * 0.1), 2) for f in (392, 494, 659)]
    write_wav("chest", np.concatenate(parts + [tri(784, tt(0.35, SR)) * decay(int(SR * 0.35), 3)]), SR)
    t = tt(1.1, SR)
    ph = 1.0 + 0.25 * np.sin(2 * np.pi * 7 * t)
    write_wav("portal", (sine(220 * ph + 220 * t, t) + sine(330 * ph, t) * 0.5) * np.sin(np.pi * t / t[-1]), SR)
    t = tt(0.035, SR)
    write_wav("dialog", sq(520, t, 0.5) * decay(len(t), 3) * 0.6, SR)
    t = tt(0.4, SR)
    write_wav("roar", (lowpass(noise(len(t)), 0.06) * 1.5 + sweep(80, 45, t, "sq") * 0.5) * np.sin(np.pi * np.linspace(0, 1, len(t))) ** 0.5, SR)
    t = tt(0.5, SR)
    write_wav("heal", sweep(300, 900, t, "tri") * np.sin(np.pi * np.linspace(0, 1, len(t))), SR)
    t = tt(0.14, SR)
    write_wav("break", (noise(len(t)) * 0.9 + sweep(180, 60, t, "sine")) * decay(len(t), 6), SR)


# ----------------------------------------------------------------- musik
MSR = 16000
MAJOR = [0, 2, 4, 5, 7, 9, 11]
MINOR = [0, 2, 3, 5, 7, 8, 10]
DORIAN = [0, 2, 3, 5, 7, 9, 10]
PHRYG = [0, 1, 3, 5, 7, 8, 10]


def midi(root, scale, deg):
    octv, idx = divmod(deg, 7)
    return root + scale[idx] + 12 * octv


def hz(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


def note(wave, f, dur, vol, a=0.01, r=0.08, duty=0.5):
    t = tt(dur, MSR)
    n = len(t)
    if wave == "sq":
        s = sq(f, t, duty)
    elif wave == "tri":
        s = tri(f, t)
    else:
        s = sine(f, t)
    env = np.ones(n)
    na = max(1, int(a * MSR))
    nr = max(1, int(r * MSR))
    env[:na] = np.linspace(0, 1, na)
    env[-nr:] *= np.linspace(1, 0, nr)
    return s * env * vol


def render(root, scale, prog, pats, bpm, lead="sq", bass="tri", drums=False, arp=True, vol_lead=0.28, swing=0.0, octave_up=True, bars=8, seed=0):
    beat = 60.0 / bpm
    bar = beat * 4
    total = int(MSR * bar * bars)
    buf = np.zeros(total + MSR)
    eighth = beat / 2
    rng = np.random.default_rng(seed)
    for b in range(bars):
        croot = prog[b % len(prog)]
        pat = pats[(b // 2) % len(pats)]
        t0 = b * bar
        # bass
        for q in range(4):
            m = midi(root - 12, scale, croot)
            if q % 2 == 1:
                m = midi(root - 12, scale, croot + 4)
            s = note(bass, hz(m), beat * 0.9, 0.42, r=0.06)
            i = int((t0 + q * beat) * MSR)
            buf[i:i + len(s)] += s
        # lead (8 not per bar)
        tones = [croot, croot + 2, croot + 4, croot + 7, croot + 9]
        for k in range(8):
            idx = pat[k]
            if idx is None:
                continue
            deg = tones[idx % len(tones)]
            shift = 7 if (octave_up and b >= bars // 2 and k % 4 == 3) else 0
            m = midi(root + 12, scale, deg + shift)
            s = note(lead, hz(m), eighth * 0.85, vol_lead, r=0.05, duty=0.25)
            i = int((t0 + k * eighth) * MSR)
            buf[i:i + len(s)] += s
        # arpeggio / pad
        if arp:
            for k in range(8):
                deg = [croot, croot + 2, croot + 4, croot + 2][k % 4]
                m = midi(root, scale, deg)
                s = note("sq", hz(m), eighth * 0.5, 0.07, r=0.03, duty=0.125)
                i = int((t0 + k * eighth) * MSR)
                buf[i:i + len(s)] += s
        if drums:
            for q in range(4):
                tk = tt(0.12, MSR)
                kick = sweep(150, 45, tk, "sine") * decay(len(tk), 5) * 0.8
                i = int((t0 + q * beat) * MSR)
                buf[i:i + len(kick)] += kick
            for k in range(8):
                if k % 2 == 1:
                    th = tt(0.05, MSR)
                    hat = noise(len(th)) * decay(len(th), 7) * 0.18
                    i = int((t0 + k * eighth) * MSR)
                    buf[i:i + len(hat)] += hat
    return buf[:total]


def make_music():
    P = [[0, 1, 2, 1, 0, 1, 2, 3], [2, 1, 0, 1, 2, 3, 2, 1], [0, None, 2, 1, 3, 2, 1, 0], [3, 2, 1, 2, 3, 4, 3, 2]]
    # judul / desa: C mayor, tenang
    write_wav("music_village", render(60, MAJOR, [0, 4, 5, 3], P, 92, lead="tri", bass="tri", arp=True, vol_lead=0.4), MSR, loop=True)
    # gurun: D phrygian, eksotis
    write_wav("music_desert", render(62, PHRYG, [0, 1, 0, 6], P[::-1], 104, lead="sq", bass="tri", arp=True, vol_lead=0.22), MSR, loop=True)
    # gua: A minor, tegang
    write_wav("music_cave", render(57, MINOR, [0, 5, 3, 4], P, 112, lead="sq", bass="sq", drums=True, arp=True, vol_lead=0.2), MSR, loop=True)
    # benteng: dorian gelap
    write_wav("music_castle", render(55, DORIAN, [0, 3, 5, 4], P[::-1], 84, lead="tri", bass="sq", arp=True, vol_lead=0.38), MSR, loop=True)
    # bos: minor cepat
    Pb = [[0, 0, 2, 0, 3, 0, 2, 1], [0, 2, 0, 3, 0, 4, 3, 2], [4, 3, 2, 3, 4, 2, 3, 0], [0, 0, 1, 0, 2, 0, 3, 2]]
    write_wav("music_boss", render(52, MINOR, [0, 0, 5, 6], Pb, 150, lead="sq", bass="sq", drums=True, arp=True, vol_lead=0.25), MSR, loop=True)
    # kemenangan / ending: mayor hangat
    write_wav("music_ending", render(65, MAJOR, [0, 5, 3, 4], P, 76, lead="tri", bass="tri", arp=True, vol_lead=0.42, bars=8), MSR, loop=True)


if __name__ == "__main__":
    make_sfx()
    make_music()
    total = 0
    for fn in sorted(os.listdir(OUT)):
        sz = os.path.getsize(os.path.join(OUT, fn))
        total += sz
        print("%-20s %7.1f KB" % (fn, sz / 1024))
    print("total %.2f MB" % (total / 1048576))
