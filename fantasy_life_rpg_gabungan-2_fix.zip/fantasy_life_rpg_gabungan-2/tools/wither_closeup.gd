extends RefCounted
## Bot: foto close-up Dewa Wither dengan pemain di jarak bertarung (bukan di ujung arena).
func run(st: Node3D) -> void:
	var guard := 0.0
	while st.boss == null and guard < 40.0:
		await st.get_tree().create_timer(0.3).timeout
		guard += 0.3
		for e in st.get_tree().get_nodes_in_group("enemies"):
			if not e.is_boss and e.state != "spawn":
				e.take_damage(99999, st.player.global_position, 0.0)
	var b = st.boss
	st.player.hit_radius = 0.0
	await st.get_tree().create_timer(1.5).timeout
	st.player.global_position = Vector3(0, 0.1, b.global_position.z + 9.0)
	await st.get_tree().create_timer(2.0).timeout
	await st._shot("wc_far")
	st.player.global_position = Vector3(0, 0.1, b.global_position.z + 6.0)
	await st.get_tree().create_timer(1.5).timeout
	await st._shot("wc_mid")
	print("CHECK wc boss=", b.kind, " hp=", b.hp, "/", b.max_hp)
