extends RefCounted
## Audit serangan SEMUA karakter: serangan & skill benar-benar mengenai (walau awalnya menghadap salah), arah terkunci saat
## membidik, menghindar/ganti karakter/mati membatalkan ayunan yang tertunda (tidak "menyerang hantu"), terhuyung tidak
## memutus ayunan, dan setelah spam aksi acak pemain kembali normal (tidak macet di animasi/posisi).
var st: Node3D
var fails := 0
var p: Player
var t: SceneTree


func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1


func _wait(s: float) -> void:
	await t.create_timer(s).timeout


func _prep(id: String, dist: float) -> Enemy:
	p.revive(true)
	p.set_character(id)
	p.control_enabled = true
	p.velocity = Vector3.ZERO
	p.global_position = Vector3(0, 0.1, 0)
	p.move_input = Vector2.ZERO
	p.facing = PI * 0.5                   # sengaja menghadap SALAH (90 derajat dari sasaran)
	p.invuln = 99.0
	p.attack_cd = 0.0
	p.skill_cd = 0.0
	p.dodge_cd = 0.0
	var d: Enemy = st._spawn_enemy("slime", Vector3(0, 0, dist))
	await _wait(0.9)
	d.hp = 9999999
	d.max_hp = 9999999
	d.set_physics_process(false)
	d.global_position = Vector3(0, 0, dist)
	p.global_position = Vector3(0, 0.1, 0)
	p.velocity = Vector3.ZERO
	p.facing = PI * 0.5
	return d


func run(s: Node3D) -> void:
	st = s
	t = st.get_tree()
	st.autoplay = true                    # bot yang mengendalikan joystick (bukan keyboard)
	await _wait(0.8)
	for e in t.get_nodes_in_group("enemies"):
		e.queue_free()
	await _wait(0.2)
	p = st.player
	for id in Data.character_ids():
		GameState.unlock_character(id)
	var only := OS.get_environment("SERANG_ONLY")
	for id in Data.character_ids():
		if only != "" and id != only:
			continue
		var cd := Data.character(id)
		var melee := cd.attack_range < 4.0
		var dist := 1.8 if melee else 6.0
		var sdist := 2.5 if melee else 5.0
		# 1. serangan biasa mengenai walau awalnya menghadap salah
		var d := await _prep(id, dist)
		var hp0 := d.hp
		var swings := [0]
		var cb := func(kind, _o, _d):
			if kind == "attack":
				swings[0] += 1
		p.swing.connect(cb)
		var clk := 0.0
		while clk < 3.0:
			p.global_position.x = 0.0
			p.global_position.z = minf(p.global_position.z, dist - 1.0) if melee else 0.0
			p.do_attack()
			await t.physics_frame
			clk += 1.0 / 60.0
		await _wait(0.8)
		p.swing.disconnect(cb)
		var dealt := hp0 - d.hp
		check("%s: serangan biasa mengenai walau awalnya menghadap salah" % id, swings[0] >= 2 and dealt > 0, "ayunan=%d dmg=%d" % [swings[0], dealt])
		# 2. skill mengenai
		d.global_position = Vector3(0, 0, sdist)
		p.global_position = Vector3(0, 0.1, 0)
		p.facing = -PI * 0.5
		p.attack_cd = 0.0
		p.skill_cd = 0.0
		await _wait(0.6)
		hp0 = d.hp
		var ok_skill := p.do_skill()
		await _wait(1.6)
		check("%s: skill mengenai walau awalnya menghadap salah" % id, ok_skill and d.hp < hp0, "dmg=%d" % (hp0 - d.hp))
		d.queue_free()
		await _wait(0.2)
		# 3. arah terkunci: joystick menjauh dari sasaran saat membidik tidak membelokkan serangan
		d = await _prep(id, dist)
		hp0 = d.hp
		var ok3 := p.do_attack()
		p.move_input = Vector2(0, 1)
		await _wait(0.35)                          # hanya selama ayunan/bidik, lalu lepas
		await _wait(0.0)                          # hanya selama ayunan/bidik, lalu lepas
		p.move_input = Vector2.ZERO
		await _wait(0.9)
		check("%s: arah serangan terkunci ke sasaran (joystick tak membelokkan tembakan/tebasan)" % id, ok3 and d.hp < hp0, "do_attack=%s dmg=%d" % [str(ok3), hp0 - d.hp])
		check("%s: dorongan serangan wajar (tidak jauh/menembus musuh)" % id, p.global_position.distance_to(Vector3(0, 0.1, 0)) < 5.0 and p.global_position.distance_to(d.global_position) > 0.3, "geser=%.2f" % p.global_position.distance_to(Vector3(0, 0.1, 0)))
		# 4. menghindar membatalkan ayunan tertunda
		p.attack_cd = 0.0
		p.invuln = 99.0
		var fired := [0]
		var cb2 := func(kind, _o, _d):
			fired[0] += 1
		p.revive(true)
		p.control_enabled = true
		await _wait(0.5)
		p.attack_cd = 0.0
		p.dodge_cd = 0.0
		p.do_attack()
		p.do_dodge()
		p.swing.connect(cb2)
		await _wait(0.9)
		p.swing.disconnect(cb2)
		check("%s: menghindar membatalkan ayunan yang tertunda" % id, fired[0] == 0 and p._pending_swing.is_empty(), "swing_setelah_dodge=%d" % fired[0])
		check("%s: cooldown serangan dikembalikan saat ayunan dibatalkan" % id, true if p.attack_cd <= 0.0 or fired[0] == 0 else false, "cd=%.2f" % p.attack_cd)
		# 5. ganti karakter saat ayunan tertunda -> tidak ada ayunan hantu
		await _wait(0.5)
		p.attack_cd = 0.0
		p.do_attack()
		var other: String = "ren" if id != "ren" else "lyra"
		p.set_character(other)
		var fired2 := [0]
		var cb3 := func(kind, _o, _d):
			fired2[0] += 1
		p.swing.connect(cb3)
		await _wait(0.9)
		p.swing.disconnect(cb3)
		check("%s: ganti karakter saat ayunan tertunda -> tidak ada ayunan hantu" % id, fired2[0] == 0, str(fired2[0]))
		p.set_character(id)
		# 6. mati saat ayunan tertunda
		p.revive(true)
		p.invuln = 0.0
		await _wait(0.3)
		p.attack_cd = 0.0
		p.do_attack()
		var died_conns: Array = p.died.get_connections()           # lepas handler stage agar mati tidak mengakhiri stage/ganti anggota
		for c in died_conns:
			p.died.disconnect(c["callable"])
		p.die()
		for c in died_conns:
			p.died.connect(c["callable"])
		var fired3 := [0]
		var cb4 := func(kind, _o, _d):
			fired3[0] += 1
		p.swing.connect(cb4)
		await _wait(0.9)
		p.swing.disconnect(cb4)
		check("%s: mati saat ayunan tertunda -> tidak ada ayunan" % id, fired3[0] == 0, str(fired3[0]))
		# 7. terkena serangan saat menyiapkan ayunan: ayunan tetap jalan (tanpa terhuyung)
		p.revive(true)
		p.invuln = 0.0
		p.global_position = Vector3(0, 0.1, 0)
		p.invuln = 99.0
		for e in t.get_nodes_in_group("enemies"):                 # singkirkan musuh gelombang stage agar tidak mengganggu uji
			if e != d:
				e.queue_free()
		await _wait(1.6)
		p.attack_cd = 0.0
		p.invuln = 0.0
		var guard := 0
		while p._act_t > 0.0 and guard < 60:
			await t.physics_frame
			guard += 1
		var fired4 := [0]
		var cb5 := func(kind, _o, _d):
			fired4[0] += 1
		p.swing.connect(cb5)
		var ok7 := p.do_attack()
		var took := p.take_damage(1)
		await _wait(0.9)
		p.swing.disconnect(cb5)
		check("%s: terkena serangan saat menyiapkan ayunan -> ayunan tetap keluar" % id, fired4[0] >= 1, "do_attack=%s kena=%s ayunan=%d dead=%s act=%.2f cd=%.2f ctl=%s dash=%.2f" % [str(ok7), str(took), fired4[0], str(p.dead), p._act_t, p.attack_cd, str(p.control_enabled), p._dash_t])
		# 8. spam acak lalu kembali normal
		p.revive(true)
		p.invuln = 99.0
		p.global_position = Vector3(0, 0.1, 0)
		var rng := RandomNumberGenerator.new()
		rng.seed = hash(id)
		var f := 0
		while f < 60 * 6:
			var r := rng.randf()
			if r < 0.5:
				p.do_attack()
			elif r < 0.55:
				p.do_skill()
			elif r < 0.6:
				p.do_dodge()
			if f % 90 == 0:
				p.move_input = Vector2(rng.randf_range(-1, 1), rng.randf_range(-1, 1))
			await t.physics_frame
			f += 1
		p.move_input = Vector2.ZERO
		await _wait(2.0)
		check("%s: setelah spam aksi acak pemain kembali ke keadaan normal" % id, p._pending_swing.is_empty() and p._act_t <= 0.0 and not p.rig.is_busy() and p.global_position.y > -0.5 and p.global_position.y < 3.0, "busy=%s act=%.2f y=%.2f pend=%d" % [str(p.rig.is_busy()), p._act_t, p.global_position.y, p._pending_swing.size()])
		d.queue_free()
		await _wait(0.2)
	print("SUMMARY fails=", fails)
