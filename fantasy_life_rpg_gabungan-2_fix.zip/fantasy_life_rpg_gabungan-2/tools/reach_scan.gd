extends RefCounted
## Alat desain: peta ASCII lobi (. dapat dicapai dari spawn, # padat, o ruang kosong tak terjangkau) untuk menempatkan chest/area rahasia.
var lb: Node3D

func _blocked(x: float, z: float) -> bool:
	var q := PhysicsShapeQueryParameters3D.new()
	var sp := SphereShape3D.new()
	sp.radius = 0.45
	q.shape = sp
	q.transform = Transform3D(Basis(), Vector3(x, 1.0, z))
	q.collision_mask = 1
	return not lb.get_world_3d().direct_space_state.intersect_shape(q, 1).is_empty()

func run(l: Node3D) -> void:
	lb = l
	await lb.get_tree().create_timer(1.0).timeout
	var x0 := int(LobbyLayout.BOUNDS_MIN.x); var x1 := int(LobbyLayout.BOUNDS_MAX.x); var z0 := int(LobbyLayout.BOUNDS_MIN.y); var z1 := int(LobbyLayout.BOUNDS_MAX.y)
	var W := x1 - x0 + 1
	var H := z1 - z0 + 1
	var blk := {}
	for z in range(z0, z1 + 1):
		for x in range(x0, x1 + 1):
			blk[Vector2i(x, z)] = _blocked(x, z)
	var seen := {}
	var sp := Vector2i(int(LobbyLayout.SPAWN.x), int(LobbyLayout.SPAWN.z))
	var st: Array = [sp]
	seen[sp] = true
	while not st.is_empty():
		var c: Vector2i = st.pop_back()
		for d in [Vector2i(1,0), Vector2i(-1,0), Vector2i(0,1), Vector2i(0,-1)]:
			var n: Vector2i = c + d
			if n.x < x0 or n.x > x1 or n.y < z0 or n.y > z1 or seen.has(n) or blk[n]:
				continue
			seen[n] = true
			st.push_back(n)
	var f := FileAccess.open("/tmp/reach.txt", FileAccess.WRITE)
	f.store_line("x from %d to %d, z from %d to %d (2 m per char)" % [x0, x1, z0, z1])
	for z in range(z0, z1 + 1, 2):
		var line := "%4d " % z
		for x in range(x0, x1 + 1, 2):
			var c := Vector2i(x, z)
			line += "." if seen.has(c) else ("#" if blk[c] else "o")
		f.store_line(line)
	f.close()
	print("reach cells ", seen.size())
	# semua titik desain: peti, titik teleport, area rahasia, NPC, titik interaksi bangunan (data aktual, bukan angka tetap)
	var cands := {}
	for c in Explore.CHESTS:
		cands[c["id"]] = Vector2i(int(c["pos"].x), int(c["pos"].y))
	for w in Explore.WAYPOINTS:
		cands[w["id"]] = Vector2i(int(w["pos"].x), int(w["pos"].y))
	for z in Explore.ZONES:
		cands[z["id"]] = Vector2i(int(z["pos"].x), int(z["pos"].y))
	for n in LobbyLayout.NPC_SPOTS:
		cands["npc_" + n] = Vector2i(int(LobbyLayout.NPC_SPOTS[n].x), int(LobbyLayout.NPC_SPOTS[n].y))
	for it in lb.world.interactions:
		cands["int_" + str(it["id"])] = Vector2i(int(it["pos"].x), int(it["pos"].z))
	var bad := 0
	for k in cands:
		var c0: Vector2i = cands[k]
		var open: bool = seen.has(c0)
		var d_free := 0.0
		if not open:
			var bd := 1e9
			for c in seen:
				var dd := Vector2(c - c0).length()
				if dd < bd:
					bd = dd
			d_free = bd
			bad += 1
		if not open and d_free <= 2.5:           # titik berisi benda sendiri (peti, batu teleport, NPC) -> cukup ada lantai bebas <= 2,5 m
			open = true
			bad -= 1
		print("PT ", k, " ", c0, " dapat dicapai" if open else " TIDAK dapat dicapai (titik terdekat %.1f m)" % d_free)
	print("REACH_BAD ", bad, " dari ", cands.size())
	print("CHECK ", "PASS " if bad == 0 else "FAIL ", "semua titik desain dapat dicapai dari spawn")
	lb.get_tree().quit()
