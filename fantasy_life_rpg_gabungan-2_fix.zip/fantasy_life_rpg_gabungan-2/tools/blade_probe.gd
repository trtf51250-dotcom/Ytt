extends Node
## Mencetak arah bilah pedang (dalam bingkai badan: x=kiri karakter? y=atas z=depan) untuk tiap frame animasi serangan. Pakai: --anim=attack_sword1
func _arg(k: String, d: String) -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % k):
			return a.substr(k.length() + 3)
	return d

func _ready() -> void:
	var tex: Texture2D = load("res://assets/hero/skin_ren.png")
	var rig := CharacterRig.new()
	add_child(rig)
	rig.setup(1.8, tex, false, true)
	CharacterLooks.apply_hero(rig, _arg("hero", "ren"))
	var an := _arg("anim", "attack_sword1")
	rig.player.play(an)
	var len: float = rig.player.get_animation(an).length
	var w: Node3D = rig.weapon_holder.get_child(0)
	for i in 21:
		var u := i / 20.0
		rig.player.seek(u * len, true)
		rig.player.pause()
		await get_tree().process_frame
		await get_tree().process_frame
		var tip: Vector3 = w.global_transform.basis.y.normalized()
		var f := rig.global_transform.basis.z.normalized()
		var r := rig.global_transform.basis.x.normalized()
		var d := Vector3(tip.dot(r), tip.y, tip.dot(f))
		var hp: Vector3 = w.global_position - rig.global_position
		print("u=%.2f blade(right,up,fwd)=(%.2f,%.2f,%.2f) hand(right,up,fwd)=(%.2f,%.2f,%.2f)" % [u, d.x, d.y, d.z, hp.dot(r), hp.y, hp.dot(f)])
	get_tree().quit()
