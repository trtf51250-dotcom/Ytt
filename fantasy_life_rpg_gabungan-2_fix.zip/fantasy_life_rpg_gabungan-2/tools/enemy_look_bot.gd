extends RefCounted
## Foto close-up musuh biasa & elit (cek tampilan model baru) + cek statistik/penyeimbang.
var st: Node3D
func _w(s: float) -> void:
	await st.get_tree().create_timer(s).timeout
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
var fails := 0
func run(s: Node3D) -> void:
	st = s
	var dir := "/tmp"
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shots="):
			dir = a.substr(8)
	await _w(2.5)
	for e in st.get_tree().get_nodes_in_group("enemies"):
		e.queue_free()
	await _w(0.3)
	var p: Vector3 = st.player.global_position
	var kinds := ["slime", "slime", "slime_mini", "bat", "mushroom", "cultist", "ronin"]
	var made: Array = []
	for i in kinds.size():
		var e: Enemy = st._spawn_enemy(kinds[i], p + Vector3(-5.5 + i * 1.9, 0, 4.5))
		made.append(e)
	made[1].make_elite()
	made[6].make_elite()
	# statistik: HP musuh biasa sekarang jauh lebih tebal
	check("slime HP >= 90", made[0].max_hp >= 90, "hp=%d" % made[0].max_hp)
	check("elit HP 2x", made[1].max_hp >= made[0].max_hp * 2 - 2, "hp=%d" % made[1].max_hp)
	check("slime kecil lebih lemah", made[2].max_hp < made[0].max_hp / 2, "hp=%d" % made[2].max_hp)
	await _w(1.0)
	for e in st.get_tree().get_nodes_in_group("enemies"):
		if not made.has(e):
			e.queue_free()
	for e in made:
		e._cooldown = 99.0
		e.set_physics_process(false)
	for ps in st.party_state:
		ps["hp"] = ps["max"]
	for i in made.size():
		made[i].global_position = Vector3(p.x - 5.4 + i * 1.8, 0.05 if not made[i].flying else 1.0, p.z + 4.5)
		made[i].rotation.y = 0.0
	var cam := Camera3D.new()
	st.add_child(cam)
	cam.fov = 40.0
	cam.global_position = Vector3(p.x, 2.2, p.z + 12.5)
	cam.look_at(Vector3(p.x, 0.9, p.z + 4.5))
	cam.make_current()
	await _w(0.5)
	st.get_viewport().get_texture().get_image().save_png(dir + "/enemy_look.png")
	print("shot enemy_look")
	# poise: pukulan kecil saat aba-aba tidak membatalkan serangan
	var t: Enemy = made[0]
	t.set_physics_process(true)
	t._set_state("windup", 0.8)
	t.take_damage(3, p, 2.0)
	check("poise: pukulan kecil tidak memotong aba-aba", t.state == "windup", "state=" + t.state)
	t.take_damage(int(t.max_hp * 0.4), p, 2.0)
	check("poise: pukulan besar memotong aba-aba", t.state == "stagger", "state=" + t.state)
	# slime pecah jadi dua
	var before: int = st.get_tree().get_nodes_in_group("enemies").size()
	t.take_damage(999999, p, 2.0)
	await _w(0.3)
	var after: int = st.get_tree().get_nodes_in_group("enemies").size()
	check("slime pecah jadi 2 slime kecil", after == before - 1 + 2, "sebelum=%d sesudah=%d" % [before, after])
	print("FAILS=", fails)
	st.get_tree().quit()
