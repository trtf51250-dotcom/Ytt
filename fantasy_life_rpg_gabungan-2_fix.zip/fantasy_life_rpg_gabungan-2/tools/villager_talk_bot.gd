extends RefCounted
## Bot: warga yang berjalan-jalan bisa diajak bicara (target, dialog, berhenti saat bicara, lanjut jalan sesudahnya).
var fails := 0

func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1

func run(l: Node3D) -> void:
	var tree := l.get_tree()
	await tree.create_timer(1.0).timeout
	check("ada warga di lobi", l.villagers.size() > 0, "n=%d" % l.villagers.size())
	for d in NpcDefs.VILLAGERS:
		check("data warga lengkap " + str(d.get("name", "?")), d.has("name") and d.has("title") and d.has("say") and (d["say"] as Array).size() >= 2, "")
	var v: Villager = null
	for x in l.villagers:
		if is_instance_valid(x) and x.visible:
			v = x
			break
	check("ada warga terlihat", v != null, "")
	if v == null:
		print("CHECK SUMMARY fails=", fails); tree.quit(); return
	# dekati warga -> menjadi target interaksi
	l.player.global_position = v.global_position + Vector3(1.2, 0, 0)
	await tree.process_frame
	await tree.process_frame
	var t: Dictionary = l._find_target()
	check("warga menjadi target interaksi", t.get("kind", "") == "npc" and t.get("npc") == v, str(t.get("prompt", "")))
	check("teks tombol memuat nama", str(t.get("prompt", "")).contains(v.display_name), str(t.get("prompt", "")))
	# bicara
	l._try_interact()
	await tree.process_frame
	check("kotak dialog terbuka", l.dialogue.is_open, "")
	check("pemain terkunci saat bicara", not l.player.control_enabled, "")
	var p0 := v.global_position
	await tree.create_timer(1.0).timeout
	check("warga berhenti berjalan selama bicara", v.global_position.distance_to(p0) < 0.15, "geser=%.2f" % v.global_position.distance_to(p0))
	# struktur dialog: semua pilihan menuju simpul yang ada
	var dd: Dictionary = v.dialogue()
	var ok := dd.has("start")
	for k in dd:
		for c in dd[k]["choices"]:
			var g: String = c.get("goto", "")
			if g != "" and not dd.has(g):
				ok = false
	check("semua simpul dialog valid", ok, str(dd.keys()))
	var hint: String = dd["hint"]["lines"][0]
	check("petunjuk tidak kosong", hint.length() > 20, hint)
	# tutup & lanjut
	l.dialogue.close()
	await tree.process_frame
	check("dialog tertutup, pemain bebas lagi", not l.dialogue.is_open and l.player.control_enabled, "")
	check("look_at dilepas", v.look_at_node == null, "")
	await tree.create_timer(3.5).timeout
	check("warga lanjut berjalan", v.global_position.distance_to(p0) > 0.3, "geser=%.2f" % v.global_position.distance_to(p0))
	# variasi antar-kunjungan
	var g1: String = NpcDefs.villager_dialogue("uji", NpcDefs.VILLAGERS[0])["start"]["lines"][0]
	var g2: String = NpcDefs.villager_dialogue("uji", NpcDefs.VILLAGERS[0])["start"]["lines"][0]
	check("sapaan kunjungan kedua berbeda", g1 != g2, "")
	print("CHECK SUMMARY fails=", fails)
	tree.quit()
