extends RefCounted
## Ukur biaya StageHud.update_party (dipanggil tiap 0,1 dtk saat bertarung). Jalankan di stage:
##   godot --path . scenes/stages/stage.tscn -- --bot=1 --botscript=hud_perf_bot --stage=s1_1 --fresh
func run(st: Node3D) -> void:
	await st.get_tree().create_timer(1.5).timeout
	var n := 3000
	for i in 50:
		st.hud.update_party(st.party_state, st.active)
	var t0 := Time.get_ticks_usec()
	for i in n:
		st.hud.update_party(st.party_state, st.active)
	print("PERF update_party: %.4f ms/panggilan (%d anggota)" % [(Time.get_ticks_usec() - t0) / 1000.0 / n, st.party_state.size()])
	print("SUMMARY fails=0")
