extends Node3D
## Pratinjau pose klip WitherRig (cast/slam/roar/hit/death) dari depan dan samping (alat uji).
func _ready() -> void:
	var dir := "/tmp"
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shots="):
			dir = a.substr(8)
	var env := WorldEnvironment.new()
	env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR
	env.environment.background_color = Color(0.25, 0.3, 0.4)
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.environment.ambient_light_color = Color(0.8, 0.8, 0.9)
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-45, 30, 0)
	add_child(sun)
	var rig: WitherRig = load("res://scenes/stages/wither_rig.tscn").instantiate()
	add_child(rig)
	var cam := Camera3D.new()
	add_child(cam)
	await get_tree().create_timer(0.3).timeout
	var c := Vector3(0, 0.2, -0.7)
	var shots := [["idle", 0.5], ["cast", 0.8], ["cast", 1.1], ["slam", 0.55], ["slam", 0.75], ["roar", 0.9], ["hit", 0.12], ["death", 0.9]]
	var i := 0
	for s in shots:
		rig.anim_player.play(s[0], 0.0)
		rig.anim_player.seek(float(s[1]), true)
		rig.anim_player.pause()
		for v in [Vector3(0, 0.15, 1), Vector3(1, 0.15, 0.3)]:
			cam.position = c + v.normalized() * 8.0
			cam.look_at(c)
			await get_tree().process_frame
			await get_tree().process_frame
			get_viewport().get_texture().get_image().save_png("%s/wp_%d_%s_%d.png" % [dir, i, s[0], 0 if v.z > 0.9 else 1])
		i += 1
	get_tree().quit()
