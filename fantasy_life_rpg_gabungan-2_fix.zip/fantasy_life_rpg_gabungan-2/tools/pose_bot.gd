extends RefCounted
## Foto pose diam & siaga (setelah serang) tiap karakter, kamera samping. Hasil di --shots: pose_<id>_idle/ready.png
var lobby: Node3D
func _w(s: float) -> void:
	await lobby.get_tree().create_timer(s, true, false, true).timeout
func run(l: Node3D) -> void:
	lobby = l
	await _w(0.5)
	var pl: Player = lobby.player
	var only := OS.get_environment("POSE_IDS")
	for cid in Data.character_ids():
		if only != "" and not (cid in only.split(",")): continue
		GameState.unlock_character(cid)
		GameState.set_party_slot(0, cid)
		await _w(0.9)
		lobby.cam.distance = 4.2
		lobby.cam.pitch = deg_to_rad(10.0)
		lobby.cam.yaw = PI * 0.5
		await _w(0.9)
		await lobby._shot("pose_%s_idle" % cid)
		pl._act_t = 0.0; pl.attack_cd = 0.0
		pl.do_attack()
		await _w(1.6)
		await lobby._shot("pose_%s_ready" % cid)
		await _w(4.0)
	print("SUMMARY fails=0")
