extends RefCounted
## Hitung segitiga model tiap karakter (hanya aksesori/Looks) di tiap kualitas -> pastikan Aion tidak jauh lebih berat dari yang lain.
var fails := 0
func _tris(n: Node) -> int:
	var t := 0
	if n is MeshInstance3D and (n as MeshInstance3D).mesh != null:
		var m: Mesh = (n as MeshInstance3D).mesh
		for si in m.get_surface_count():
			var arr := m.surface_get_arrays(si)
			var idx = arr[Mesh.ARRAY_INDEX]
			t += (idx.size() if idx != null and idx.size() > 0 else arr[Mesh.ARRAY_VERTEX].size()) / 3
	for c in n.get_children():
		t += _tris(c)
	return t
func run(st: Node3D) -> void:
	var tr := st.get_tree()
	await tr.create_timer(1.0).timeout
	var p: Player = st.player
	var ids := ["ren", "vael", "hakuya", "lucien", "kuroha", "aion"]
	var res := {}
	for q in [0, 1, 2]:
		GameState.settings["quality"] = q
		for id in ids:
			GameState.unlock_character(id)
			p.set_character(id)
			await tr.process_frame
			res["%d/%s" % [q, id]] = _tris(p.rig)
	for k in res:
		print("TRIS ", k, " = ", res[k])
	var worst0 := 0
	for id in ids:
		if id != "aion":
			worst0 = maxi(worst0, res["0/" + id])
	print("CHECK ", "PASS" if res["0/aion"] <= worst0 * 1.5 else "FAIL", " Lancar: Aion <= 1,5x karakter terberat lain  aion=%d lain=%d" % [res["0/aion"], worst0])
	if res["0/aion"] > worst0 * 1.5:
		fails += 1
	print("FAILS=", fails)
	tr.quit()
