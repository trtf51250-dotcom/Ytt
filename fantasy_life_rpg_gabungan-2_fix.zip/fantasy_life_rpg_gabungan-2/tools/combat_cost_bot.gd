extends RefCounted
## Biaya render saat bertarung (autoplay) di Lancar: rata-rata & puncak draw call / objek / primitif, node, monster hidup.
##   -- --bot=1 --botscript=combat_cost_bot --stage=s2_1
func run(scene: Node) -> void:
	var t := scene.get_tree()
	GameState.settings["quality"] = 0
	var dn = scene.get("daynight")
	Quality.apply(scene.get_viewport(), null, scene.get_viewport().get_camera_3d(), null)
	if OS.get_environment("LOD") != "":
		scene.get_viewport().mesh_lod_threshold = float(OS.get_environment("LOD"))
	print("LOD threshold=", scene.get_viewport().mesh_lod_threshold)
	if "autoplay" in scene:
		scene.autoplay = true
	await t.create_timer(3.0).timeout
	var sum := Vector3.ZERO
	var peak := Vector3.ZERO
	var n := 0
	var en_max := 0
	var nodes_max := 0
	for i in 900:
		await t.process_frame
		var v := Vector3(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME), RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME), RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME))
		sum += v
		peak = Vector3(maxf(peak.x, v.x), maxf(peak.y, v.y), maxf(peak.z, v.z))
		en_max = maxi(en_max, t.get_nodes_in_group("enemy").size())
		nodes_max = maxi(nodes_max, int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT)))
		n += 1
	print("COMBAT draw avg=%d puncak=%d | objek avg=%d puncak=%d | primitif avg=%d puncak=%d | monster_maks=%d node_maks=%d" % [sum.x / n, peak.x, sum.y / n, peak.y, sum.z / n, peak.z, en_max, nodes_max])
	var by := {}
	for m in scene.find_children("*", "MeshInstance3D", true, false):
		var mi := m as MeshInstance3D
		if mi.mesh == null or not mi.is_visible_in_tree():
			continue
		var tris := 0
		for k in mi.mesh.get_surface_count():
			var arr := mi.mesh.surface_get_arrays(k)
			if arr.size() > 0 and arr[Mesh.ARRAY_INDEX] != null:
				tris += (arr[Mesh.ARRAY_INDEX] as PackedInt32Array).size() / 3
		var key := str(scene.get_path_to(mi)).split("/")[0] + "/" + str(mi.get_parent().get_parent().name if mi.get_parent() != null and mi.get_parent().get_parent() != null else "")
		var g: Array = by.get(key, [0, 0])
		g[0] += 1
		g[1] += tris
		by[key] = g
	var ks := by.keys()
	ks.sort_custom(func(a, b): return by[a][1] > by[b][1])
	for k in ks.slice(0, 8):
		print("COMBAT_TRIS %-40s mi=%d tris=%d" % [k, by[k][0], by[k][1]])
	print("SUMMARY fails=0")
