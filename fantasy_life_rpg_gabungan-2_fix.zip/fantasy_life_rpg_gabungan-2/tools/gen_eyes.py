#!/usr/bin/env python3
"""Membuat tekstur mata & alis karakter (orisinal, prosedural) -> assets/hero/eyes/. Mata digambar dengan sudut luar di KIRI gambar; mata sebelahnya dicerminkan di game."""
import math
from PIL import Image, ImageDraw, ImageFilter, ImageChops

SS = 4
W, H = 256, 160
IRIS = {
    "ren": (64, 153, 255), "lyra": (184, 115, 255), "brann": (242, 153, 51), "sera": (89, 217, 115), "ember": (255, 107, 38),
    "zeya": (230, 77, 191), "hakuya": (77, 179, 255), "vael": (64, 230, 255), "lucien": (255, 204, 77), "wenyu": (77, 217, 204), "kuroha": (217, 51, 77),
}

def lerp(a, b, t): return a + (b - a) * t
def mix(c1, c2, t): return tuple(int(lerp(c1[i], c2[i], t)) for i in range(3))

def eye(col):
    """Gaya chibi anime sederhana: tanpa sklera putih, iris besar gelap bergradasi warna karakter, 2 kilau, garis bulu mata tebal."""
    w, h = W * SS, H * SS
    cx, cy = 0.52 * w, 0.54 * h
    rx, ry = 0.40 * w, 0.46 * h
    base = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(base)
    dark = (18, 14, 30)
    d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=dark + (255,))
    # gradasi warna iris dari bawah (terang) ke atas (gelap)
    g = Image.new("RGBA", (w, h), (0, 0, 0, 0)); dg = ImageDraw.Draw(g)
    for y in range(int(cy - ry), int(cy + ry)):
        t = (y - (cy - ry)) / (2 * ry)
        t = max(0.0, (t - 0.25) / 0.75) ** 1.3
        c = mix(dark, tuple(min(255, int(v * 1.15)) for v in col), t)
        dg.line([(0, y), (w, y)], fill=c + (255,))
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).ellipse([cx - rx * 0.92, cy - ry * 0.93, cx + rx * 0.92, cy + ry * 0.93], fill=255)
    m = m.filter(ImageFilter.GaussianBlur(3 * SS))
    base.paste(g, (0, 0), m)
    d = ImageDraw.Draw(base)
    # pupil lonjong gelap
    d.ellipse([cx - rx * 0.30, cy - ry * 0.42, cx + rx * 0.30, cy + ry * 0.42], fill=dark + (255,))
    # kilau besar (kiri atas) + kecil (kanan bawah) + titik kecil
    r1 = 0.085 * w
    d.ellipse([cx - rx * 0.50 - r1, cy - ry * 0.48 - r1, cx - rx * 0.50 + r1, cy - ry * 0.48 + r1], fill=(255, 255, 255, 255))
    r2 = 0.042 * w
    d.ellipse([cx + rx * 0.42 - r2, cy + ry * 0.45 - r2, cx + rx * 0.42 + r2, cy + ry * 0.45 + r2], fill=(255, 255, 255, 235))
    r3 = 0.022 * w
    d.ellipse([cx + rx * 0.2 - r3, cy - ry * 0.55 - r3, cx + rx * 0.2 + r3, cy - ry * 0.55 + r3], fill=(255, 255, 255, 200))
    # garis bulu mata atas tebal + ekor di sudut luar (kiri)
    ink = (14, 10, 24, 255)
    pts = []
    for i in range(0, 101):
        t = i / 100
        x = cx - rx * 1.02 + 2 * rx * 1.02 * t
        y = cy - ry * (0.98 * math.sin(math.pi * (0.04 + 0.92 * t)) ** 0.7) - 0.02 * h
        pts.append((x, y))
    for i in range(100):
        t = i / 100
        wd = int(h * (0.11 - 0.06 * t) * (0.6 + 0.6 * math.sin(math.pi * min(1, t * 1.3))))
        d.line([pts[i], pts[i + 1]], fill=ink, width=max(4, wd))
    d.polygon([(pts[0][0] + 0.02 * w, pts[0][1] + 0.03 * h), (pts[0][0] - 0.07 * w, pts[0][1] - 0.15 * h), (pts[6][0], pts[6][1] - 0.02 * h)], fill=ink)
    return base.resize((W, H), Image.LANCZOS)

def brow():
    w, h = 256, 64
    s = Image.new("RGBA", (w * SS, h * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(s)
    pts_top = [(0.05, 0.62), (0.3, 0.3), (0.62, 0.2), (0.96, 0.34)]
    pts_bot = [(0.96, 0.46), (0.62, 0.42), (0.3, 0.56), (0.05, 0.7)]
    d.polygon([(x * w * SS, y * h * SS) for x, y in pts_top + pts_bot], fill=(255, 255, 255, 255))
    return s.resize((w, h), Image.LANCZOS)

for k, c in IRIS.items():
    eye(c).save(f"assets/hero/eyes/eye_{k}.png")
brow().save("assets/hero/eyes/brow.png")
print("ok")
