extends RefCounted
func run(st: Node3D) -> void:
	var guard := 0.0
	while st.boss == null and guard < 40.0:
		await st.get_tree().create_timer(0.3).timeout
		guard += 0.3
		for e in st.get_tree().get_nodes_in_group("enemies"):
			if not e.is_boss and e.state != "spawn":
				e.take_damage(99999, st.player.global_position, 0.0)
	await st.get_tree().create_timer(8.0).timeout
	var b = st.boss
	print("DBG boss pos=", b.global_position, " player=", st.player.global_position, " state=", b.state)
	print("DBG visual scale=", b._visual.scale, " vis=", b._visual.visible, " pos=", b._visual.position)
	var w = b._wrig
	print("DBG wrig scale=", w.scale, " pos=", w.position, " global=", w.global_position)
	var mn := Vector3(1e9,1e9,1e9); var mx := Vector3(-1e9,-1e9,-1e9); var cnt := 0
	for n in w.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		var a := mi.global_transform * mi.get_aabb()
		mn = mn.min(a.position); mx = mx.max(a.end); cnt += 1
		if cnt < 4: print("DBG mesh ", mi.name, " vis=", mi.is_visible_in_tree(), " layers=", mi.layers)
	print("DBG meshes=", cnt, " aabb ", mn, " -> ", mx)
	var c: Camera3D = st.cam.cam
	print("DBG cam pos=", c.global_position, " dist=", st.cam.distance)
	for p in [b.global_position, b.global_position + Vector3(0,5,0), (mn+mx)/2.0]:
		print("DBG screen ", c.unproject_position(p), " behind=", c.is_position_behind(p))
	var sk: Skeleton3D = w.find_children("*", "Skeleton3D", true, false)[0]
	print("DBG skel bones=", sk.get_bone_count(), " vis=", sk.is_visible_in_tree())
	for bn in ["Head", "Spine", "Root"]:
		var bi := sk.find_bone(bn)
		if bi >= 0: print("DBG bone ", bn, " global=", sk.global_transform * sk.get_bone_global_pose(bi).origin, " scale=", sk.get_bone_pose_scale(bi))
	print("DBG anim=", w.get("anim_player"), " ", b._wrig.get_children())
	for n in w.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		var m := StandardMaterial3D.new(); m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED; m.albedo_color = Color(1,0.2,0.2)
		pass
	await st.get_tree().create_timer(0.3).timeout
	st.player.global_position = Vector3(0,0.1,b.global_position.z+7.0)
	await st.get_tree().create_timer(1.5).timeout
	await st._shot("dbg_red")
	await st._shot("dbg")
