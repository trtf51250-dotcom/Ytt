extends Node
## Uji unit kecil tanpa scene: area aman layar & data misi.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1
func _ready() -> void:
	# HP dengan notch: jendela 2400x1080, area aman x 132..2268 -> skala 1.5 -> margin 88
	var m := UiTheme.insets_from(Rect2(132, 0, 2136, 1080), Vector2(2400, 1080), Vector2(1280, 720))
	check("notch: kiri/kanan 88, atas/bawah 0", is_equal_approx(m["left"], 88.0) and is_equal_approx(m["right"], 88.0) and m["top"] == 0.0 and m["bottom"] == 0.0, str(m))
	var z := UiTheme.insets_from(Rect2(0, 0, 1280, 720), Vector2(1280, 720), Vector2(1280, 720))
	check("tanpa notch: nol", z["left"] == 0.0 and z["top"] == 0.0 and z["right"] == 0.0 and z["bottom"] == 0.0)
	var big := UiTheme.insets_from(Rect2(900, 0, 600, 1080), Vector2(2400, 1080), Vector2(1280, 720))
	check("margin dibatasi maks 120", big["left"] <= 120.0 and big["right"] <= 120.0, str(big))
	check("PC (bot) -> nol", UiTheme.safe_insets()["left"] == 0.0)
	for d in ["2026-01-01", "2026-06-15", "2026-11-04", "2027-02-28"]:
		var ms := Missions.daily_for(d)
		check("misi %s: 3 misi valid" % d, ms.size() == 3 and ms[0]["kind"] == "kill" and ms[1]["kind"] == "clear_stage" and Missions.KIND_TEXT.has(ms[2]["kind"]) and int(ms[2]["need"]) > 0)
	var ids := {}
	var ok := true
	for a in Missions.ACH:
		if ids.has(a["id"]): ok = false
		ids[a["id"]] = true
	check("id pencapaian unik (%d)" % Missions.ACH.size(), ok)
	print("CHECK SUMMARY fails=", fails)
	get_tree().quit()
