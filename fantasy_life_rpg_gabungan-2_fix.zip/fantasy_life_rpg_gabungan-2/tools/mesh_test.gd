extends Node3D
## Alat pengembang: menguji primitif MeshKit + shader dunia dan menyimpan screenshot.
##   xvfb-run -a godot --path . --rendering-driver opengl3 --resolution 1280x720 res://tools/mesh_test.tscn -- --out=/tmp/mesh.png
func _arg(key: String, default: String) -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % key):
			return a.substr(key.length() + 3)
	return default


func _ready() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.5, 0.72, 0.95)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.72, 0.78, 0.95)
	e.ambient_light_energy = 0.7
	env.environment = e
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -35, 0)
	sun.light_color = Color(1.0, 0.95, 0.85)
	sun.light_energy = 1.1
	sun.shadow_enabled = true
	add_child(sun)

	var k := MeshKit.new(5)
	# tanah
	k.plane(Vector3(0, 0, 0), 40, 30, MeshKit.T_GRASS, Color(0.95, 1, 0.9), 1.0)
	k.plane(Vector3(0, 0.02, 4), 4, 20, MeshKit.T_COBBLE, Color(1, 1, 1))
	k.disc(Vector3(-8, 0.03, -2), 3.2, 24, MeshKit.T_PLAZA, Color(1, 1, 1))
	# rumah
	k.push()
	k.move(-4, 0, -4)
	k.box_b(Vector3.ZERO, Vector3(6, 3.4, 5), MeshKit.T_TIMBER, Color(1, 0.96, 0.88), MeshKit.T_PLASTER)
	k.gable_roof(Vector3(0, 3.4, 0), 6, 5, 2.4, 0.4, MeshKit.T_ROOF, Color(0.85, 0.32, 0.28), MeshKit.T_PLASTER, Color(1, 0.96, 0.88))
	k.quad(Vector3(-0.6, 0, 2.52), Vector3(0.6, 0, 2.52), Vector3(0.6, 2.2, 2.52), Vector3(-0.6, 2.2, 2.52), MeshKit.T_DOOR, Color(1, 1, 1), 1.0, 0.0, 0.6)
	k.quad(Vector3(1.4, 1.2, 2.52), Vector3(2.4, 1.2, 2.52), Vector3(2.4, 2.2, 2.52), Vector3(1.4, 2.2, 2.52), MeshKit.T_WINDOW, MeshKit.glow(Color(1, 1, 1), 0.2), 1.0, 0.0, 0.5)
	k.pop()
	# menara
	k.push()
	k.move(5, 0, -6)
	k.cylinder(Vector3.ZERO, 1.8, 1.6, 6.0, 12, MeshKit.T_BRICK, Color(0.95, 0.92, 0.88))
	k.spire(Vector3(0, 6.0, 0), 2.2, 3.6, 12, MeshKit.T_ROOF, Color(0.3, 0.45, 0.85), 0.3)
	k.pop()
	# pohon
	k.push()
	k.move(-9, 0, 4)
	k.cylinder(Vector3.ZERO, 0.4, 0.3, 2.6, 7, MeshKit.T_BARK, Color(1, 1, 1))
	k.blob(Vector3(0, 3.6, 0), 1.9, MeshKit.T_LEAVES, Color(0.9, 1.0, 0.8), 5, 9, 0.85, 0.35, 0.6)
	k.blob(Vector3(0.9, 3.0, 0.4), 1.3, MeshKit.T_LEAVES, Color(0.8, 1.0, 0.75), 4, 8, 0.85, 0.35, 0.6)
	k.pop()
	# torus + kristal + rumput
	k.torus_xy(Vector3(8, 2.4, 4), 1.8, 0.28, 24, 8, MeshKit.T_METAL, Color(0.8, 0.9, 1))
	k.crystal(Vector3(8, 0, 0), 0.5, 1.6, Color(0.5, 0.85, 1.0))
	for i in 12:
		k.cross_quads(Vector3(-12 + i * 0.4, 0, 8), 0.8, 0.8, MeshKit.T_TUFT, Color(0.9, 1, 0.8), 1.0, i * 17)
	for i in 5:
		k.cross_quads(Vector3(-10 + i * 0.6, 0, 9), 0.5, 0.6, MeshKit.T_FLOWER, [Color(1, 0.5, 0.6), Color(0.6, 0.7, 1), Color(1, 0.9, 0.4)][i % 3], 1.0, i * 40)
	var mesh := k.build()
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = WorldMats.opaque()
	add_child(mi)
	print("verts: ", k.vertex_count())
	var cam := Camera3D.new()
	cam.fov = 40
	cam.position = Vector3(8, 9, 18)
	add_child(cam)
	cam.look_at(Vector3(-1, 1.5, 0))
	for i in 5:
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png(_arg("out", "/tmp/mesh.png"))
	print("saved")
	get_tree().quit()
