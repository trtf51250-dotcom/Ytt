extends RefCounted
## Bot: alur Adventure tanpa daftar pilih. Langkah berikutnya otomatis (stage -> wilayah jelajah -> stage ...), wilayah selesai lewat finish_stage,
## dan stage yang sudah selesai hanya bisa diulang lewat tombol ulang (farming).  -- --bot=1 --botscript=adventure_flow_bot --shots=/dir
var lobby: Node3D
var fails := 0


func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1


func _wait(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout


func run(l: Node3D) -> void:
	lobby = l
	await _wait(0.8)
	var gs := GameState
	gs.stages = {}
	check("awal: langkah berikutnya = s1_1", gs.adventure_next() == "s1_1", gs.adventure_next())
	lobby.host.open("stage_select", {"adventure": true})
	await _wait(0.6)
	var p = lobby.host.current
	check("panel Adventure: daftar pilih disembunyikan", p != null and bool(p.get("adv")) and not p._list.get_parent().get_parent().visible, "")
	check("panel langsung memilih langkah berikutnya", str(p.get("selected")) == "s1_1", str(p.get("selected")))
	await lobby._shot("adv_flow_1")
	# selesai s1_1 -> wilayah Padang Angin (disisipkan setelah s1_1) jadi langkah berikutnya, BUKAN s1_2
	gs.stages["s1_1"] = {"cleared": true, "stars": 3}
	check("setelah s1_1: langkah berikutnya = f_plains", gs.adventure_next() == "f_plains", gs.adventure_next())
	lobby.host.close()
	lobby.host.open("stage_select", {"adventure": true})
	await _wait(0.6)
	p = lobby.host.current
	check("panel memilih wilayah jelajah", str(p.get("selected")) == "f_plains", str(p.get("selected")))
	await lobby._shot("adv_flow_field")
	# tamatkan wilayah lewat finish_stage -> lanjut ke s1_2; hadiah tercatat sekali
	var g0 := gs.gold
	var d0 := gs.diamonds
	var res := gs.finish_stage("f_plains", {"win": true, "kills": 12, "time": 60.0, "stars": 3})
	check("wilayah selesai memberi hadiah tamat", res["gold"] == 250 and gs.gold >= g0 + 250 and gs.diamonds == d0 + 40, "gold %d dia %d" % [gs.gold - g0, gs.diamonds - d0])
	check("setelah wilayah: langkah berikutnya = s1_2", gs.adventure_next() == "s1_2", gs.adventure_next())
	# ulang (farming): tombol ulang bergerak di antara langkah yang sudah selesai saja
	lobby.host.close()
	lobby.host.open("stage_select", {"adventure": true})
	await _wait(0.6)
	p = lobby.host.current
	check("kembali ke panel: s1_2", str(p.get("selected")) == "s1_2", str(p.get("selected")))
	p.set("selected", "s1_1")
	p.call("refresh")
	await _wait(0.4)
	await lobby._shot("adv_flow_farm")
	check("mode ulang menampilkan stage selesai", str(p.get("selected")) == "s1_1" and GameState.stage_cleared("s1_1"))
	# tamat semua
	for id in Data.adventure_order:
		gs.stages[id] = {"cleared": true, "stars": 3}
	check("semua selesai: tidak ada langkah berikutnya", gs.adventure_next() == "")
	lobby.host.close()
	lobby.host.open("stage_select", {"adventure": true})
	await _wait(0.6)
	check("panel tamat tetap terbuka (stage terakhir untuk diulang)", lobby.host.current != null and str(lobby.host.current.get("selected")) != "")
	await lobby._shot("adv_flow_done")
	print("CHECK SUMMARY fails=", fails)
