extends RefCounted
## Membuka setiap panel di lobi, mengambil tangkapan layar, dan mengeksekusi aksi nyata (beli, pasang, klaim, tarik gacha, tempa).
## Mencetak "CHECK ..." untuk tiap pemeriksaan; gagal bila nilai tidak sesuai. Jalankan:  -- --bot=1 --botscript=panel_bot --shots=/dir

var lobby: Node3D
var fails := 0


func _wait(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout


func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1


func _open(id: String, args: Dictionary = {}, shot: String = "") -> void:
	lobby.host.open(id, args)
	await _wait(0.5)
	if shot != "":
		await lobby._shot(shot)


func run(l: Node3D) -> void:
	lobby = l
	await _wait(0.6)
	var gs := GameState
	# --- quest: bicara -> siap klaim -> klaim
	gs.report_event("talk", "guild_master")
	check("quest welcome siap", gs.quest_state("q_welcome") == "ready")
	await _open("quest", {}, "p_quest")
	var gold0 := gs.gold
	var got := gs.claim_quest("q_welcome")
	check("klaim quest memberi gold", gs.gold == gold0 + 200 and not got.is_empty(), "gold %d" % gs.gold)
	await _wait(0.3)
	await lobby._shot("p_quest_after")
	# --- shop
	await _open("shop", {"tab": "weapon"}, "p_shop_weapon")
	var g1 := gs.gold
	var ok := gs.buy_item("w_sword_steel")
	check("beli pedang baja", ok and gs.item_count("w_sword_steel") == 1 and gs.gold < g1, "gold %d -> %d" % [g1, gs.gold])
	await _open("shop", {"tab": "item"}, "p_shop_item")
	check("beli ramuan menyelesaikan quest 'buy potion'", gs.buy_item("p_small", 2) and gs.quest_state("q_shop_potion") == "ready", gs.quest_state("q_shop_potion"))
	await _open("shop", {"tab": "sell"}, "p_shop_sell")
	# --- inventory + equipment
	await _open("inventory", {}, "p_inventory")
	check("pasang pedang baja pada Ren", gs.equip("ren", "w_sword_steel") and gs.equipped("ren", "weapon") == "w_sword_steel")
	await _open("equipment", {"char": "ren"}, "p_equipment")
	# --- smith
	var plus0 := gs.weapon_plus("ren")
	await _open("smith", {"char": "ren"}, "p_smith")
	check("tempa senjata +1", gs.upgrade_weapon("ren") and gs.weapon_plus("ren") == plus0 + 1, "+%d" % gs.weapon_plus("ren"))
	# --- character / party
	await _open("character", {}, "p_character")
	await _open("party", {}, "p_party")
	check("party awal 3 anggota", gs.party.size() == 3, str(gs.party))
	# --- gacha
	await _open("gacha", {}, "p_gacha")
	var d0 := gs.diamonds
	var res := Gacha.pull(10)
	check("gacha x10 menghasilkan 10 hasil & memotong 900 diamond", res.size() == 10 and gs.diamonds == d0 - 900, "diamond %d -> %d" % [d0, gs.diamonds])
	var has4 := false
	for r: Dictionary in res:
		if int(r["rarity"]) >= 4:
			has4 = true
	check("gacha x10 menjamin >= bintang 4", has4)
	await _open("gacha", {}, "p_gacha_after")
	# --- stage select & settings
	await _open("stage_select", {}, "p_stage")
	await _open("settings", {}, "p_settings")
	lobby.host.close()
	await _wait(0.3)
	# --- tombol HUD
	check("HUD hanya punya 4 tombol menu (Quest, Gacha, Shop, Menu)", ["quest", "gacha", "shop", "more"].all(func(i): return lobby.hud.menu_button(i) != null) and lobby.hud.menu_button("character") == null and lobby.hud.menu_button("settings") == null)
	var seen := {}
	lobby.host.opened.connect(func(id): seen[id] = true)
	for id in ["quest", "gacha", "shop", "more"]:
		lobby.hud.menu_button(id).pressed.emit()
		await _wait(0.2)
		lobby.host.close()
	# panel lain dibuka dari kartu di dalam Menu
	lobby.hud.menu_button("more").pressed.emit()
	await _wait(0.8)
	var tiles: Array = lobby.host.current._core_row.get_children()
	check("Menu punya 5 kartu inti (Karakter, Party, Inventori, Equipment, Peta)", tiles.size() == 5, str(tiles.size()))
	for ti in 5:
		var cur: Array = lobby.host.current._core_row.get_children()
		cur[ti].pressed.emit()
		await _wait(0.2)
		lobby.host.open("more")
		await _wait(0.5)
	lobby.host.close()
	lobby.hud.start_button().pressed.emit()
	await _wait(0.2)
	lobby.host.close()
	check("semua tombol HUD + kartu inti Menu + Start Adventure membuka panel", seen.size() == 10 and seen.has("stage_select") and seen.has("map"), str(seen.keys()))
	print("CHECK SUMMARY fails=", fails)
