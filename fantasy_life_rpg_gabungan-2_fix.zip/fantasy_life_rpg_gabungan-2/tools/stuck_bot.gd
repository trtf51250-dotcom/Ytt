extends RefCounted
## Bot ukur musuh macet: pemain diam (tak bisa mati), sampel posisi tiap musuh. Musuh darat berstatus "chase" yang bergeser < 0,6 m
## selama 3 dtk padahal masih > 4 m dari pemain dihitung MACET. Jalankan: -- --bot=1 --botscript=stuck_bot --stage=<id> --fresh
var fails := 0


func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1


func _arg_f(st: Node, k: String, d: float) -> float:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % k):
			return float(a.split("=")[1])
	return d


func run(st: Node3D) -> void:
	var tree := st.get_tree()
	st.autoplay = true
	await tree.create_timer(1.0).timeout
	var p: Player = st.player
	var hist := {}        # instance_id -> Array[Vector2] (tiap 0,25 dtk)
	var stuck_ids := {}
	var seen := {}
	var spawns := []
	var idle_state := {}
	var t := 0.0
	var ang := 0.0
	var orbit := _arg_f(st, "orbit", 0.0)
	while t < 70.0:
		await tree.create_timer(0.25).timeout
		t += 0.25
		p.hp = p.max_hp
		if orbit > 0.0:                               # pemain berjalan memutar dekat tepi arena (di antara rintangan) supaya musuh harus berputar menyusuri rintangan
			var rr: float = st.arena.radius * orbit
			ang += 0.25 * 3.5 / rr
			var q: Vector3 = Vector3(cos(ang), 0.1, sin(ang)) * rr
			p.global_position = q
			p.velocity = Vector3.ZERO
		for e in tree.get_nodes_in_group("enemies"):
			if not is_instance_valid(e) or e.dead or e.flying or e.is_boss:
				continue
			var id: int = e.get_instance_id()
			var pos := Vector2(e.global_position.x, e.global_position.z)
			if not seen.has(id):
				seen[id] = true
				spawns.append(pos)
			var h: Array = hist.get(id, [])
			h.append(pos)
			if h.size() > 13:
				h.pop_front()
			hist[id] = h
			var d := pos.distance_to(Vector2(p.global_position.x, p.global_position.z))
			if h.size() >= 13 and (h[0] as Vector2).distance_to(pos) < 0.6 and d > 4.0:
				idle_state[e.state] = int(idle_state.get(e.state, 0)) + 1
			if h.size() >= 13 and e.state == "chase" and d > 4.0 and (h[0] as Vector2).distance_to(pos) < 0.6:
				if not stuck_ids.has(id):
					var q := PhysicsShapeQueryParameters3D.new()
					var sp := SphereShape3D.new()
					sp.radius = 1.8
					q.shape = sp
					q.transform = Transform3D(Basis(), e.global_position + Vector3(0, 0.8, 0))
					q.collision_mask = 1 | 16
					var hits = st.get_world_3d().direct_space_state.intersect_shape(q, 8)
					print("  DEBUG-NOW ", e.kind, " t=", t, " state=", e.state, " hits=", hits.size(), " stuck_hits=", e._stuck_hits, " stuck_t=", e._stuck_t, " detour=", e._detour_t, " speed=", e.speed, " pos=", e.global_position, " target_d=", d)
					for hh in hits:
						var c: Object = hh["collider"]
						var shp: int = hh["shape"]
						var cs = (c as CollisionObject3D).shape_owner_get_owner((c as CollisionObject3D).shape_find_owner(shp))
						print("    collider ", c.name, " layer=", c.get("collision_layer"), " shape_pos=", (cs as Node3D).global_position, " shape=", (cs as CollisionShape3D).shape)
				stuck_ids[id] = [e.kind, pos, d]
	var n := seen.size()
	var rad: float = st.arena.radius
	var edge := 0
	print("IDLE_SAMPLES_BY_STATE ", idle_state)
	for id in stuck_ids:
		if (stuck_ids[id][1] as Vector2).length() > rad * 0.7:
			edge += 1
	print("STUCK spawned=", n, " stuck=", stuck_ids.size(), " at_edge=", edge, " R=", rad)
	for id in stuck_ids:
		print("  stuck ", stuck_ids[id][0], " pos=", stuck_ids[id][1], " dist_to_player=", snappedf(stuck_ids[id][2], 0.1))
	for id in stuck_ids:
		var en = instance_from_id(id)
		if en != null and is_instance_valid(en):
			var q := PhysicsShapeQueryParameters3D.new()
			var sp := SphereShape3D.new()
			sp.radius = 1.6
			q.shape = sp
			q.transform = Transform3D(Basis(), en.global_position + Vector3(0, 0.8, 0))
			q.collision_mask = 1 | 16
			var hits = st.get_world_3d().direct_space_state.intersect_shape(q, 8)
			print("  DEBUG ", en.kind, " state=", en.state, " hits=", hits.size(), " stuck_hits=", en._stuck_hits, " detour=", en._detour_t, " speed=", en.speed, " pos3=", en.global_position, " vel=", en.velocity)
			for h in hits:
				var c: Object = h["collider"]
				print("    collider ", c.name, " layer=", c.get("collision_layer"), " pos=", (c as Node3D).global_position if c is Node3D else "")
	check("jumlah musuh terukur", n >= 1, "n=%d" % n)
	check("tidak ada musuh macet (> 3 dtk)", stuck_ids.size() == 0, "macet=%d dari %d" % [stuck_ids.size(), n])
	print("CHECK SUMMARY fails=", fails)
	tree.quit()
