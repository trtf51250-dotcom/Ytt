extends RefCounted
## Bot uji profil/identitas offline: ID valid & stabil, ganti nama valid/tidak valid, panel terbuka.
var lobby: Node3D
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1
func run(l: Node3D) -> void:
	lobby = l
	await lobby.get_tree().create_timer(0.6).timeout
	var gs := GameState
	var r := RegEx.new(); r.compile("^FL-[A-Z2-9]{4}-[A-Z2-9]{4}$")
	check("ID berformat benar", r.search(gs.player_id) != null, gs.player_id)
	var id0 := gs.player_id
	check("rename valid", gs.rename_player("  Gt   Sang  Penyihir-Panjang "), "[" + gs.player_name + "]")
	check("nama dipotong maks %d" % gs.NAME_MAX, gs.player_name.length() <= gs.NAME_MAX)
	check("rename pendek ditolak", not gs.rename_player(" a "))
	check("ID tidak berubah setelah rename", gs.player_id == id0)
	gs.rename_player("Gt")
	lobby.host.open("profile")
	await lobby.get_tree().create_timer(0.6).timeout
	await lobby._shot("p_profile")
	check("panel profil terbuka", lobby.host.current_id == "profile")
	check("ID acak (bukan turunan perangkat): tiap pembuatan beda, ID dunia ini tetap", gs._make_id() != gs._make_id() and gs.player_id == id0)
	print("CHECK SUMMARY fails=", fails)
