extends RefCounted
## Diagnosis: kelompokkan MeshInstance3D/partikel/lampu/animasi di scene menurut sumber (anak langsung scene atau induk bernama).
func run(scene: Node) -> void:
	var t := scene.get_tree()
	if "autoplay" in scene: scene.autoplay = true
	await t.create_timer(2.0).timeout
	var groups := {}
	var mis := scene.find_children("*", "MeshInstance3D", true, false)
	var total_surf := 0
	for n in mis:
		var mi := n as MeshInstance3D
		if mi.mesh == null: continue
		var key := _key(scene, mi)
		var g: Dictionary = groups.get(key, {"mi": 0, "surf": 0, "tris": 0, "shadow": 0, "visible": 0, "trans": 0})
		g["mi"] += 1
		var ns := mi.mesh.get_surface_count()
		g["surf"] += ns
		total_surf += ns
		for s in ns:
			var arr := mi.mesh.surface_get_arrays(s)
			if arr.size() > 0 and arr[Mesh.ARRAY_INDEX] != null:
				g["tris"] += (arr[Mesh.ARRAY_INDEX] as PackedInt32Array).size() / 3
			elif arr.size() > 0 and arr[Mesh.ARRAY_VERTEX] != null:
				g["tris"] += (arr[Mesh.ARRAY_VERTEX] as PackedVector3Array).size() / 3
		if mi.cast_shadow != GeometryInstance3D.SHADOW_CASTING_SETTING_OFF: g["shadow"] += 1
		if mi.is_visible_in_tree(): g["visible"] += 1
		groups[key] = g
	print("SCAN meshinstances=%d surfaces=%d" % [mis.size(), total_surf])
	var keys := groups.keys()
	keys.sort_custom(func(a, b): return groups[a]["surf"] > groups[b]["surf"])
	for k in keys.slice(0, 22):
		var g: Dictionary = groups[k]
		print("SCAN %-34s mi=%4d surf=%4d tris=%7d shadow=%4d visible=%4d" % [k, g["mi"], g["surf"], g["tris"], g["shadow"], g["visible"]])
	print("SCAN gpu_particles=%d cpu_particles=%d omni=%d spot=%d anim_players=%d skeletons=%d sprite3d=%d label3d=%d" % [
		scene.find_children("*", "GPUParticles3D", true, false).size(), scene.find_children("*", "CPUParticles3D", true, false).size(),
		scene.find_children("*", "OmniLight3D", true, false).size(), scene.find_children("*", "SpotLight3D", true, false).size(),
		scene.find_children("*", "AnimationPlayer", true, false).size(), scene.find_children("*", "Skeleton3D", true, false).size(),
		scene.find_children("*", "Sprite3D", true, false).size(), scene.find_children("*", "Label3D", true, false).size()])
	print("SCAN physics_bodies=%d areas=%d collision_shapes=%d" % [scene.find_children("*", "PhysicsBody3D", true, false).size(), scene.find_children("*", "Area3D", true, false).size(), scene.find_children("*", "CollisionShape3D", true, false).size()])
	var tt := 0
	for k in groups: tt += groups[k]["tris"]
	print("SCAN total_tris_scene=%d" % tt)
	for l in scene.find_children("*", "OmniLight3D", true, false):
		var o := l as OmniLight3D
		print("SCAN omni %s range=%.1f energy=%.2f shadow=%s bake=%d path=%s" % [o.name, o.omni_range, o.light_energy, o.shadow_enabled, o.light_bake_mode, scene.get_path_to(o)])
	var npcs := 0
	for n in scene.find_children("Npc*", "Node3D", true, false):
		npcs += 1
	print("SCAN npc_nodes=%d label3d_samples=%s" % [npcs, str(scene.find_children("*", "Label3D", true, false).slice(0, 3).map(func(x): return str(x.text).substr(0, 14) + " bb=" + str(x.billboard) + " outline=" + str(x.outline_size)))])
	print("SUMMARY fails=0")

func _key(scene: Node, n: Node) -> String:
	var p := n
	var chain: Array = []
	while p != null and p != scene:
		chain.append(p)
		p = p.get_parent()
	chain.reverse()
	if chain.size() >= 2:
		var top: String = str(chain[0].name)
		if top.begins_with("@"): top = top.substr(1, 10)
		top = top.rstrip("0123456789")
		var sub: String = str(chain[1].name).rstrip("0123456789")
		return (top + "/" + sub).substr(0, 34)
	return str(n.name).substr(0, 34)
