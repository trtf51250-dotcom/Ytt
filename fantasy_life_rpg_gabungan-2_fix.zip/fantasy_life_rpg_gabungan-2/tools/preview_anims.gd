extends Node3D
## Alat pengembang: merender "lembar kontak" animasi karakter ke PNG (butuh layar, mis. xvfb-run).
##   xvfb-run -a godot --path . --rendering-driver opengl3 --resolution 1600x520 res://tools/preview_anims.tscn -- --sheet=loco --yaw=30 --out=/tmp/sheet.png
## Lembar: loco, attack, skill, misc, npc. Opsi: --skin=ren (nama file skin), --yaw=derajat.

const SHEETS := {
	"loco": [["idle", 0.0], ["walk", 0.12], ["walk", 0.62], ["run", 0.12], ["run", 0.62], ["turn_l", 0.5]],
	"attack": [["attack_sword1", 0.2], ["attack_sword1", 0.55], ["attack_sword2", 0.5], ["attack_staff", 0.5], ["attack_smash", 0.5], ["attack_bow", 0.55]],
	"skill": [["skill_sword", 0.5], ["skill_staff", 0.45], ["skill_guard", 0.3], ["skill_guard", 0.65], ["skill_bow", 0.55], ["dodge", 0.4]],
	"misc": [["hurt", 0.15], ["death", 1.0], ["death", 0.5], ["victory", 0.2], ["idle_hammer", 0.5], ["idle_wave", 0.4]],
	"sword": [["attack_sword1", 0.0], ["attack_sword1", 0.3], ["attack_sword1", 0.55], ["attack_sword1", 0.8], ["attack_sword2", 0.45], ["idle", 0.0]],
	"npc": [["idle_n", 0.0], ["idle_cross", 0.3], ["idle_gesture", 0.3], ["idle_attention", 0.3], ["idle_stir", 0.3], ["walk_n", 0.12]],
}


func _arg(key: String, default: String) -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % key):
			return a.substr(key.length() + 3)
	return default


func _ready() -> void:
	var sheet := _arg("sheet", "loco")
	var skin := _arg("skin", "ren")
	var yaw := float(_arg("yaw", "30"))
	var out := _arg("out", "/tmp/sheet.png")
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.45, 0.62, 0.85)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.75, 0.78, 0.9)
	e.ambient_light_energy = 0.8
	env.environment = e
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-45, -35, 0)
	sun.light_color = Color(1.0, 0.96, 0.88)
	add_child(sun)
	var ground := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(30, 6)
	ground.mesh = pm
	var gm := StandardMaterial3D.new()
	gm.albedo_color = Color(0.45, 0.62, 0.4)
	ground.material_override = gm
	add_child(ground)
	var list: Array = SHEETS[sheet]
	if _arg("anims", "") != "":
		list = []
		for a in _arg("anims", "").split(","):
			var kv := a.split(":")
			list.append([kv[0], float(kv[1])])
	var tex: Texture2D = load("res://assets/hero/skin_%s.png" % skin)
	var n := list.size()
	for i in n:
		var rig := CharacterRig.new()
		add_child(rig)
		rig.setup(1.8, tex, false, true)
		if _arg("hero", "") != "":
			CharacterLooks.apply_hero(rig, _arg("hero", ""))
		rig.position = Vector3((i - (n - 1) * 0.5) * float(_arg("space", "1.55")), 0, 0)
		rig.rotation.y = deg_to_rad(float(_arg("rigyaw", "0")))
		var d: Array = list[i]
		rig.player.play(d[0])
		var len: float = rig.player.get_animation(d[0]).length
		rig.player.seek(d[1] * len, true)
		rig.player.pause()
	var cam := Camera3D.new()
	cam.fov = 32
	var dist := float(_arg("dist", "9.5"))
	var fy := float(_arg("fy", "0.95"))
	cam.position = Vector3(float(_arg("fx", "0")) + sin(deg_to_rad(yaw)) * dist, fy + 0.55, cos(deg_to_rad(yaw)) * dist)
	add_child(cam)
	cam.look_at(Vector3(float(_arg("fx", "0")), float(_arg("fy", "0.95")), 0))
	for i in 4:
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png(out)
	print("saved ", out)
	get_tree().quit()
