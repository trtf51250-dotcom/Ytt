#!/usr/bin/env python3
"""Membuat atlas tekstur dunia (orisinal, digambar lewat kode) -> assets/textures/world_atlas.png

Atlas 8 x 4 petak, tiap petak 64 x 64 piksel (512 x 256). Indeks petak = baris * 8 + kolom
(harus sama dengan konstanta T_* di scripts/systems/mesh_kit.gd).
Petak abu-abu/netral sengaja dibuat agar bisa diwarnai lewat warna vertex (atap, dinding, batu, dll).

Pakai:  python3 tools/gen_textures.py        (butuh: pip install pillow numpy)
"""
import os
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "assets", "textures", "world_atlas.png")
os.makedirs(os.path.dirname(OUT), exist_ok=True)

T = 64
COLS, ROWS = 8, 4
RNG = np.random.default_rng(2026)


def smooth(t):
    return t * t * (3 - 2 * t)


def vnoise(cells, seed, size=T):
    """Value noise yang bisa disambung (tileable), nilai 0..1."""
    r = np.random.default_rng(seed)
    lat = r.random((cells, cells))
    xs = np.arange(size) / size * cells
    x0 = np.floor(xs).astype(int) % cells
    x1 = (x0 + 1) % cells
    fx = smooth(xs - np.floor(xs))
    a = lat[np.ix_(x0, x0)]
    b = lat[np.ix_(x0, x1)]
    c = lat[np.ix_(x1, x0)]
    d = lat[np.ix_(x1, x1)]
    top = a * (1 - fx)[None, :] + b * fx[None, :]
    bot = c * (1 - fx)[None, :] + d * fx[None, :]
    return top * (1 - fx)[:, None] + bot * fx[:, None]


def fbm(seed, base=4, octaves=3):
    out = np.zeros((T, T))
    amp, tot = 1.0, 0.0
    for o in range(octaves):
        out += vnoise(base * 2 ** o, seed + o * 31) * amp
        tot += amp
        amp *= 0.5
    return out / tot


def rgb(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)])


def tile_new(color):
    t = np.zeros((T, T, 4))
    t[..., :3] = color
    t[..., 3] = 1.0
    return t


def shade(t, f):
    t[..., :3] = np.clip(t[..., :3] * f[..., None], 0, 1)
    return t


def voronoi(n, seed, grid=0):
    """Voronoi tileable: kembalikan (id sel, jarak ke titik terdekat, jarak ke terdekat kedua).
    grid > 0: titik disebar pada kisi grid x grid dengan sedikit jitter (sel seragam, tanpa gumpalan)."""
    r = np.random.default_rng(seed)
    if grid > 0:
        gx, gy = np.meshgrid(np.arange(grid), np.arange(grid))
        base = np.stack([gx.ravel(), gy.ravel()], -1).astype(float)
        pts = (base + 0.5 + (r.random(base.shape) - 0.5) * 0.7) * (T / grid)
        n = len(pts)
    else:
        pts = r.random((n, 2)) * T
    yy, xx = np.mgrid[0:T, 0:T]
    best = np.full((T, T), 1e9)
    second = np.full((T, T), 1e9)
    bid = np.zeros((T, T), int)
    for i, (px, py) in enumerate(pts):
        for ox in (-T, 0, T):
            for oy in (-T, 0, T):
                d = np.hypot(xx - (px + ox), yy - (py + oy))
                m1 = d < best
                second = np.where(m1, best, np.minimum(second, d))
                bid = np.where(m1, i, bid)
                best = np.where(m1, d, best)
    return bid, best, second, pts


# ------------------------------------------------------------------ petak
def grass():
    t = tile_new(rgb("#5fa845"))
    n = fbm(11, 4, 3)
    t = shade(t, 0.82 + 0.34 * n)
    r = np.random.default_rng(5)
    for _ in range(170):
        x, y = r.integers(0, T), r.integers(0, T)
        L = r.integers(2, 5)
        lighter = r.random() < 0.5
        c = rgb("#8fd065") if lighter else rgb("#3f8a35")
        for k in range(L):
            t[(y - k) % T, x % T, :3] = c
    for _ in range(6):
        x, y = r.integers(0, T), r.integers(0, T)
        t[y, x, :3] = rgb("#fff3a8")
    return t


def cobble():
    bid, d1, d2, pts = voronoi(0, 21, grid=5)
    t = tile_new(rgb("#b8b0a2"))
    r = np.random.default_rng(22)
    tint = r.random(len(pts))
    base = np.stack([0.62 + 0.18 * tint[bid], 0.58 + 0.17 * tint[bid], 0.52 + 0.15 * tint[bid]], -1)
    t[..., :3] = base
    n = fbm(23, 8, 2)
    t = shade(t, 0.88 + 0.22 * n)
    edge = (d2 - d1)
    t = shade(t, np.where(edge < 2.2, 0.58, np.where(edge < 3.6, 0.9, 1.0)))
    # highlight kiri-atas tiap batu
    yy, xx = np.mgrid[0:T, 0:T]
    hl = ((edge > 2.2) & (edge < 4.2) & (((xx + yy) % 7) < 3)).astype(float)
    t[..., :3] = np.clip(t[..., :3] + hl[..., None] * 0.04, 0, 1)
    return t


def plaster():
    t = tile_new(rgb("#f0ece4"))
    n = fbm(31, 3, 3)
    t = shade(t, 0.90 + 0.14 * n)
    r = np.random.default_rng(32)
    for _ in range(40):
        x, y = r.integers(0, T), r.integers(0, T)
        t[y, x, :3] *= 0.9
    return t


def brick():
    t = tile_new(rgb("#cfcac0"))
    r = np.random.default_rng(41)
    bw, bh = 16, 8
    yy, xx = np.mgrid[0:T, 0:T]
    row = yy // bh
    off = (row % 2) * (bw // 2)
    col = ((xx + off) % T) // bw
    key = (row * 7 + col * 3) % 11
    tint = 0.84 + 0.04 * key
    t = shade(t, tint)
    n = fbm(42, 8, 2)
    t = shade(t, 0.9 + 0.2 * n)
    mortar = ((yy % bh) == 0) | (((xx + off) % bw) == 0)
    t[mortar, :3] = rgb("#8d887e")
    hl = ((yy % bh) == 1) & ~mortar
    t[hl, :3] = np.clip(t[hl, :3] + 0.06, 0, 1)
    return t


def wood():
    t = tile_new(rgb("#a8774c"))
    yy, xx = np.mgrid[0:T, 0:T]
    pw = 8
    plank = xx // pw
    r = np.random.default_rng(51)
    tint = 0.82 + 0.28 * r.random(T // pw)
    t = shade(t, tint[plank])
    grain = vnoise(16, 52) * 0.5 + np.sin((xx * 0.9 + vnoise(4, 53) * 8) * 1.3) * 0.08 + 0.5
    t = shade(t, 0.85 + 0.25 * (grain - 0.4))
    edge = (xx % pw) == 0
    t[edge, :3] *= 0.55
    for k in range(12):
        x, y = r.integers(0, T), r.integers(0, T)
        t[y:y + 2, x, :3] *= 0.6
    return t


def roof():
    t = tile_new(rgb("#d8d8d8"))
    yy, xx = np.mgrid[0:T, 0:T]
    sh = 8
    row = yy // sh
    off = (row % 2) * 8
    colx = ((xx + off) % T) // 16
    r = np.random.default_rng(61)
    tint = 0.85 + 0.2 * r.random((T // sh + 1, T // 16 + 1))
    t = shade(t, tint[row, colx])
    # lengkung bawah genteng
    fx = (xx + off) % 16
    curve = 6.5 + 1.2 * np.cos((fx / 16.0 - 0.5) * np.pi)
    ly = yy % sh
    t = shade(t, np.where(ly > curve, 0.6, 1.0))
    t = shade(t, np.where(ly == 0, 0.92, 1.0))
    t = shade(t, np.where(((xx + off) % 16) == 0, 0.7, 1.0))
    return t


def plaza():
    t = tile_new(rgb("#e4dfd3"))
    yy, xx = np.mgrid[0:T, 0:T]
    n = fbm(71, 4, 3)
    t = shade(t, 0.9 + 0.16 * n)
    line = ((xx % 32) == 0) | ((yy % 32) == 0)
    t[line, :3] *= 0.62
    bev = (((xx % 32) == 1) | ((yy % 32) == 1)) & ~line
    t[bev, :3] = np.clip(t[bev, :3] + 0.07, 0, 1)
    # ukiran kecil di tengah tiap petak
    for cx in (16, 48):
        for cy in (16, 48):
            d = np.abs(xx - cx) + np.abs(yy - cy)
            ring = (d == 7)
            t[ring, :3] *= 0.86
    return t


def dirt():
    t = tile_new(rgb("#a68a62"))
    n = fbm(81, 5, 3)
    t = shade(t, 0.75 + 0.5 * n)
    r = np.random.default_rng(82)
    for _ in range(90):
        x, y = r.integers(0, T), r.integers(0, T)
        t[y, x, :3] *= 0.7 if r.random() < 0.5 else 1.25
    t[..., :3] = np.clip(t[..., :3], 0, 1)
    return t


def leaves():
    t = tile_new(rgb("#6fbf4a"))
    n = fbm(91, 6, 3)
    t = shade(t, 0.62 + 0.7 * n)
    bid, d1, d2, pts = voronoi(26, 92)
    r = np.random.default_rng(93)
    tint = r.random(len(pts))
    t = shade(t, 0.82 + 0.3 * tint[bid])
    t = shade(t, np.where(d2 - d1 < 1.6, 0.72, 1.0))
    return t


def bark():
    t = tile_new(rgb("#8a6a4a"))
    yy, xx = np.mgrid[0:T, 0:T]
    n = vnoise(8, 101) * 0.5 + vnoise(16, 102) * 0.5
    streak = np.sin((xx + n * 10) * 0.8) * 0.5 + 0.5
    t = shade(t, 0.65 + 0.5 * streak * (0.6 + 0.4 * vnoise(4, 103)))
    return t


def timber():
    t = plaster()
    yy, xx = np.mgrid[0:T, 0:T]
    beam = rgb("#5a3d27")
    m = (xx < 6) | (xx >= T - 6) | (yy < 6) | (yy >= T - 6)
    diag = np.abs((xx - yy)) < 3
    diag2 = np.abs((xx - (T - 1 - yy))) < 3
    for mk in (m, diag, diag2):
        t[mk, :3] = beam * (0.85 + 0.3 * fbm(111, 8, 2)[mk])[..., None]
    edge = (xx == 6) | (yy == 6) | (xx == T - 7) | (yy == T - 7)
    t[edge & ~m, :3] *= 0.8
    return t


def water():
    t = tile_new(rgb("#4aa8e0"))
    n = fbm(121, 4, 3)
    t = shade(t, 0.8 + 0.4 * n)
    yy, xx = np.mgrid[0:T, 0:T]
    w = np.sin((xx * 0.5 + n * 9) + yy * 0.2) > 0.92
    t[w, :3] = np.clip(t[w, :3] + 0.35, 0, 1)
    return t


def metal():
    t = tile_new(rgb("#8f9aa8"))
    yy, xx = np.mgrid[0:T, 0:T]
    t = shade(t, 0.85 + 0.3 * fbm(131, 6, 2))
    line = ((xx % 32) == 0) | ((yy % 32) == 0)
    t[line, :3] *= 0.55
    for cx in (4, 28, 36, 60):
        for cy in (4, 28, 36, 60):
            t[cy:cy + 2, cx:cx + 2, :3] = rgb("#c9d2de")
    return t


def thatch():
    t = tile_new(rgb("#cfae66"))
    yy, xx = np.mgrid[0:T, 0:T]
    n = vnoise(16, 141) * 0.6 + vnoise(32, 142) * 0.4
    t = shade(t, 0.7 + 0.6 * n)
    streak = ((yy + (xx // 3) * 5) % 9) == 0
    t[streak, :3] *= 0.7
    return t


def window():
    t = tile_new(rgb("#f4efe4"))
    yy, xx = np.mgrid[0:T, 0:T]
    frame = (xx < 7) | (xx >= T - 7) | (yy < 7) | (yy >= T - 7) | (np.abs(xx - 32) < 2) | (np.abs(yy - 32) < 2)
    glass = ~frame
    g = np.stack([0.42 + 0.25 * (1 - yy / T), 0.66 + 0.2 * (1 - yy / T), 0.92 - 0.1 * yy / T], -1)
    t[glass, :3] = g[glass]
    hl = glass & (((xx + yy) % 22) < 3)
    t[hl, :3] = np.clip(t[hl, :3] + 0.3, 0, 1)
    t[frame, :3] *= (0.9 + 0.1 * fbm(151, 8, 2)[frame])[..., None]
    return t


def door():
    t = wood()
    yy, xx = np.mgrid[0:T, 0:T]
    iron = rgb("#38404c")
    for y0 in (10, 46):
        t[y0:y0 + 6, :, :3] = iron
        for x in (6, 22, 42, 58):
            t[y0 + 2:y0 + 4, x:x + 2, :3] = rgb("#8a96a6")
    t[34:38, 46:50, :3] = rgb("#e8c860")
    return t


def clear_tile():
    t = np.zeros((T, T, 4))
    return t


def grass_tuft():
    """Rumput cutout (alpha). Warna netral-hijau, diwarnai lewat vertex."""
    t = clear_tile()
    r = np.random.default_rng(161)
    for i in range(11):
        bx = int((i + 0.5) / 11 * T + r.integers(-2, 3))
        h = int(r.integers(26, 56))
        lean = r.uniform(-0.35, 0.35)
        for k in range(h):
            x = int(bx + lean * k + np.sin(k * 0.15 + i) * 1.2)
            y = T - 1 - k
            w = 2 if k < h * 0.6 else 1
            for dx in range(w):
                if 0 <= x + dx < T:
                    shade_v = 0.7 + 0.5 * (k / h)
                    t[y, x + dx, :3] = rgb("#6ec24a") * shade_v
                    t[y, x + dx, 3] = 1.0
    return t


def flower():
    """Bunga cutout: batang hijau + kelopak putih (diwarnai lewat vertex)."""
    t = clear_tile()
    yy, xx = np.mgrid[0:T, 0:T]
    t[40:T, 31:34, :3] = rgb("#4da040")
    t[40:T, 31:34, 3] = 1.0
    for ang in np.linspace(0, 2 * np.pi, 6, endpoint=False):
        cx, cy = 32 + 13 * np.cos(ang), 28 + 13 * np.sin(ang)
        m = ((xx - cx) ** 2 + (yy - cy) ** 2) < 49
        t[m, :3] = rgb("#ffffff")
        t[m, 3] = 1.0
    m = ((xx - 32) ** 2 + (yy - 28) ** 2) < 30
    t[m, :3] = rgb("#ffd84a")
    t[m, 3] = 1.0
    leaf = (np.abs(xx - 24) + np.abs(yy - 52) < 6) | (np.abs(xx - 40) + np.abs(yy - 56) < 6)
    t[leaf, :3] = rgb("#5db44a")
    t[leaf, 3] = 1.0
    return t


def cloth():
    """Kain spanduk: netral terang dengan serat halus."""
    t = tile_new(rgb("#f4f4f4"))
    yy, xx = np.mgrid[0:T, 0:T]
    t = shade(t, 0.92 + 0.1 * (((xx + yy) % 4) < 2) + 0.06 * fbm(171, 8, 2))
    return t


def emblem():
    """Lambang bintang fajar (kuning di atas netral) untuk spanduk guild."""
    t = tile_new(rgb("#f4f4f4"))
    yy, xx = np.mgrid[0:T, 0:T]
    cx = cy = 32
    # bintang 8 sudut dari dua kotak berputar + lingkaran
    dx, dy = xx - cx, yy - cy
    r = np.hypot(dx, dy)
    ang = np.arctan2(dy, dx)
    star = r < (10 + 20 * np.abs(np.cos(ang * 4)) ** 3)
    t[star, :3] = rgb("#f2c14e")
    t[r < 7, :3] = rgb("#3f73e6")
    ring = (r > 27) & (r < 30)
    t[ring, :3] = rgb("#f2c14e")
    return t


def crystal():
    """Kristal: faset gradasi (dipakai dengan warna vertex & emisi)."""
    t = tile_new(rgb("#cfe8ff"))
    yy, xx = np.mgrid[0:T, 0:T]
    f = 0.75 + 0.25 * np.sin(xx * 0.35) * np.cos(yy * 0.2 + xx * 0.1)
    t = shade(t, f)
    t = shade(t, np.where((xx % 16) < 2, 1.25, 1.0))
    return t


def banner_stripe():
    t = tile_new(rgb("#f4f4f4"))
    yy, xx = np.mgrid[0:T, 0:T]
    t = shade(t, np.where((yy % 16) < 4, 0.78, 1.0))
    return t


def marble():
    t = tile_new(rgb("#f2f4f8"))
    yy, xx = np.mgrid[0:T, 0:T]
    n = fbm(181, 3, 4)
    vein = np.abs(np.sin((xx * 0.12 + n * 6.0)) ) < 0.06
    t = shade(t, 0.92 + 0.12 * n)
    t[vein, :3] = rgb("#b9c4d8")
    return t


def sand():
    t = tile_new(rgb("#e8d9a8"))
    n = fbm(191, 6, 3)
    t = shade(t, 0.85 + 0.3 * n)
    return t


TILES = {
    0: grass, 1: cobble, 2: plaster, 3: brick, 4: wood, 5: roof, 6: plaza, 7: dirt,
    8: leaves, 9: bark, 10: timber, 11: water, 12: metal, 13: thatch, 14: window, 15: door,
    16: grass_tuft, 17: flower, 18: cloth, 19: emblem, 20: crystal, 21: banner_stripe, 22: marble, 23: sand,
}


def main():
    atlas = np.zeros((ROWS * T, COLS * T, 4))
    for idx in range(COLS * ROWS):
        fn = TILES.get(idx)
        tile = fn() if fn else tile_new(rgb("#ff00ff"))
        r, c = divmod(idx, COLS)
        atlas[r * T:(r + 1) * T, c * T:(c + 1) * T] = tile
    img = Image.fromarray((np.clip(atlas, 0, 1) * 255).astype(np.uint8), "RGBA")
    img.save(OUT)
    print("ok", OUT, img.size)


if __name__ == "__main__":
    main()
