extends RefCounted
## Ukur biaya panel Party (CPU, GDScript): refresh penuh, urut, 3 sinyal sekaligus, ketuk slot. Jalankan di lobi:
##   godot --path . scenes/lobby/lobby.tscn -- --bot=1 --botscript=party_perf_bot --fresh
## Cetak baris "PERF ...". Berguna membandingkan sebelum/sesudah perubahan (angka mutlak di HP lebih besar, rasio serupa).

var lobby: Node3D


func _wait(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout


func _count(n: Node) -> int:
	var c := 1
	for k in n.get_children():
		c += _count(k)
	return c


func run(l: Node3D) -> void:
	lobby = l
	await _wait(0.6)
	for id in ["hakuya", "sera", "zeya", "lucien", "wenyu"]:
		GameState.unlock_character(id)
	lobby.host.open("party", {})
	var waited := 0.0
	while waited < 60.0 and not (Portraits._cache.has("ren") and Portraits._cache.has("hakuya#full") and Portraits._cache.has("ember")):
		await _wait(0.5)
		waited += 0.5
	await _wait(1.0)
	var pn = lobby.host.current
	print("PERF potret siap: %.1f dtk, node panel: %d" % [waited, _count(pn)])
	for i in 5:
		pn.refresh()                                  # pemanasan
	await lobby.get_tree().process_frame
	var n := 60
	var t0 := Time.get_ticks_usec()
	for i in n:
		pn.refresh()
	print("PERF refresh() penuh: %.2f ms/panggilan" % ((Time.get_ticks_usec() - t0) / 1000.0 / n))
	t0 = Time.get_ticks_usec()
	for i in n:
		pn._sorted_ids()
	print("PERF _sorted_ids(): %.3f ms/panggilan" % ((Time.get_ticks_usec() - t0) / 1000.0 / n))
	# satu aksi yang memancarkan 3 sinyal (mis. membuka karakter baru) + tunggu frame
	t0 = Time.get_ticks_usec()
	for i in 20:
		GameState.changed.emit("roster")
		GameState.changed.emit("party")
		GameState.changed.emit("equipment")
		await lobby.get_tree().process_frame
	print("PERF 3 sinyal + 1 frame: %.2f ms/putaran" % ((Time.get_ticks_usec() - t0) / 1000.0 / 20))
	# ketuk slot lain
	t0 = Time.get_ticks_usec()
	for i in n:
		pn.sel_slot = i % 4
		if pn.has_method("_refresh_slots"):
			pn._refresh_slots()
			pn._refresh_bar()
		else:
			pn.refresh()
	print("PERF ketuk slot: %.2f ms/ketukan" % ((Time.get_ticks_usec() - t0) / 1000.0 / n))
	print("SUMMARY fails=0")
