extends RefCounted
## Uji tombol Back di stage: Back = jeda, Back lagi = lanjut. Jalankan:
##   godot --path . scenes/stages/stage.tscn -- --bot=1 --botscript=back_stage_bot --stage=s1_1 --fresh
var fails := 0


func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1


func run(st: Node3D) -> void:
	var t := st.get_tree()
	await t.create_timer(1.2).timeout
	t.root.propagate_notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)
	await t.create_timer(0.3).timeout
	check("Back di stage membuka menu jeda", st._paused and t.paused, "paused=%s" % st._paused)
	t.root.propagate_notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)
	await t.create_timer(0.3).timeout
	check("Back lagi melanjutkan permainan", not st._paused and not t.paused)
	check("stage belum berakhir/keluar", st.state != st.S.ENDED)
	print("SUMMARY fails=", fails)
