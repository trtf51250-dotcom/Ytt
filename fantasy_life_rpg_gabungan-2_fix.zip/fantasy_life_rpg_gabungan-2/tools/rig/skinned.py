import numpy as np
from prisma_loader import *

def skin_positions(nodes, nd, ms):
    hom = np.c_[ms.pos, np.ones(len(ms.pos))]
    if nd.skin_bones is not None and len(ms.invbind) > 0:
        pw = np.zeros_like(ms.pos)
        for k in range(4):
            bi = ms.bone_idx[:, k]; wk = ms.bone_w[:, k]
            for b in np.unique(bi[wk > 0]):
                sel = (bi == b) & (wk > 0)
                M = nodes[nd.skin_bones[b]].world @ ms.invbind[b]
                pw[sel] += wk[sel, None] * (hom[sel] @ M.T)[:, :3]
        return pw
    W = nd.world
    return (W[:3, :3] @ ms.pos.T).T + W[:3, 3]

def path(nodes, i):
    names = []
    while i in nodes:
        names.append(nodes[i].name); i = nodes[i].parent
    return ' < '.join(names[:5])
