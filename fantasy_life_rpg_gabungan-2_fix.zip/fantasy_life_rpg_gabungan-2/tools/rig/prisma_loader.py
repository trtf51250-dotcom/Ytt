"""Pembaca proyek Prisma 3D (.prisma = zip berisi .proj msgpack) -> node, mesh, matriks dunia."""
import glob, json, math, os, zipfile, io
import msgpack
import numpy as np


def load_project(prisma_path):
    z = zipfile.ZipFile(prisma_path)
    proj = [n for n in z.namelist() if n.endswith('.proj')][0]
    data = z.read(proj)
    pngs = {n: z.read(n) for n in z.namelist() if n.lower().endswith('.png') and '/res/' in n}
    u = msgpack.Unpacker(raw=False, strict_map_key=False)
    u.feed(data)
    objs = list(u)
    top = objs[4]
    return top, pngs


def euler_to_mat(ex, ey, ez, order='ZXY'):
    def rx(a):
        c, s = math.cos(a), math.sin(a)
        return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
    def ry(a):
        c, s = math.cos(a), math.sin(a)
        return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
    def rz(a):
        c, s = math.cos(a), math.sin(a)
        return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
    ex, ey, ez = map(math.radians, (ex, ey, ez))
    m = {'X': rx(ex), 'Y': ry(ey), 'Z': rz(ez)}
    # Unity: ZXY -> R = Ry * Rx * Rz  (Z dipakai pertama)
    r = np.eye(3)
    for ax in order:  # urutan tulisan = urutan aplikasi pertama..terakhir
        r = m[ax] @ r
    return r


class Node:
    pass


def build_nodes(top, order='ZXY'):
    nodes = {}
    for n in top[1]:
        nd = Node()
        nd.id, nd.name, comps, nd.parent, nd.active = n[0], n[1], n[2], n[3], n[4]
        nd.comps = {c[0]: {f[0]: f[1] for f in c[1]} for c in comps}
        t = nd.comps['PTransform']
        nd.pos = np.array([json.loads(t['localPosition'])[k] for k in 'xyz'])
        nd.euler = np.array([json.loads(t['localEulerAnglesHint'])[k] for k in 'xyz'])
        nd.scale = np.array([json.loads(t['localScale'])[k] for k in 'xyz'])
        nd.children = []
        nd.is_bone = 'PBone' in nd.comps
        nd.mesh_id = None
        nd.skin_bones = None
        if 'PMeshRenderer' in nd.comps:
            c = nd.comps['PMeshRenderer']
            nd.mesh_id = json.loads(c['pMesh'])['id']
            if c['isSkinned'] == 'True':
                nd.skin_bones = json.loads(c['skinBones'])['ids']
            nd.material = json.loads(c['materials'])['ids'][0]
        nodes[nd.id] = nd
    for nd in nodes.values():
        if nd.parent in nodes:
            nodes[nd.parent].children.append(nd.id)
    for nd in nodes.values():
        m = np.eye(4)
        m[:3, :3] = euler_to_mat(*nd.euler, order=order) @ np.diag(nd.scale)
        m[:3, 3] = nd.pos
        nd.local = m
    def world(i):
        nd = nodes[i]
        if not hasattr(nd, 'world'):
            nd.world = (world(nd.parent) @ nd.local) if nd.parent in nodes else nd.local.copy()
        return nd.world
    for i in nodes:
        world(i)
    return nodes


def effective_active(nodes, i):
    while i in nodes:
        if not nodes[i].active:
            return False
        i = nodes[i].parent
    return True


class Mesh:
    pass


def load_meshes(top):
    meshes = {}
    for m in top[3]:
        ms = Mesh()
        ms.id = m[0]
        counts = m[2]
        flat_idx = m[4]
        flat_uv = m[5]
        normals = m[3]
        tri_idx, tri_uv, tri_n = [], [], []
        o = 0
        for fi, c in enumerate(counts):
            ids = flat_idx[o:o + c]
            uvs = flat_uv[o:o + c]
            for k in range(1, c - 1):
                tri_idx += [ids[0], ids[k], ids[k + 1]]
                tri_uv += [uvs[0], uvs[k], uvs[k + 1]]
                tri_n.append(normals[fi])
            o += c
        ms.indices = np.array(tri_idx, dtype=np.int64)
        ms.tri_normals = np.array(tri_n, dtype=np.float64)
        ms.corner_uv = np.array(tri_uv, dtype=np.float64)
        ms.pos = np.array(m[6], dtype=np.float64)
        bw = m[7]
        ms.bone_idx = np.array([b[:4] for b in bw], dtype=np.int64)
        ms.bone_w = np.array([b[4:8] for b in bw], dtype=np.float64)
        ms.invbind = [np.array(x, dtype=np.float64).reshape(4, 4).T for x in (m[8] or [])]
        meshes[ms.id] = ms
    return meshes
