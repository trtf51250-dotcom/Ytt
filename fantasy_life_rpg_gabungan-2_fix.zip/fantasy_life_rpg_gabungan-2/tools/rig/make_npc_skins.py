"""Membuat varian kulit (skin) NPC dari skin.png hero dengan memutar warna per bagian.
Pakai: python3 make_npc_skins.py assets/hero/skin.png assets/hero
"""
import sys
import numpy as np
from PIL import Image
import colorsys

src, outdir = sys.argv[1], sys.argv[2]
im = Image.open(src).convert('RGBA')
a = np.array(im).astype(np.float64) / 255.0
H, W = 64, 64


def rgb_to_hsv(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    mx = rgb.max(-1); mn = rgb.min(-1); d = mx - mn
    h = np.zeros_like(mx)
    m = d > 1e-9
    rc = np.where(m, (mx - r) / np.where(m, d, 1), 0); gc = np.where(m, (mx - g) / np.where(m, d, 1), 0); bc = np.where(m, (mx - b) / np.where(m, d, 1), 0)
    h = np.where(mx == r, bc - gc, np.where(mx == g, 2.0 + rc - bc, 4.0 + gc - rc))
    h = (h / 6.0) % 1.0
    h = np.where(m, h, 0.0)
    s = np.where(mx > 1e-9, d / np.where(mx > 1e-9, mx, 1), 0)
    return np.stack([h, s, mx], -1)


def hsv_to_rgb(hsv):
    out = np.zeros_like(hsv)
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    i = np.floor(h * 6).astype(int) % 6
    f = h * 6 - np.floor(h * 6)
    p = v * (1 - s); q = v * (1 - f * s); t = v * (1 - (1 - f) * s)
    conds = [i == 0, i == 1, i == 2, i == 3, i == 4, i == 5]
    r = np.select(conds, [v, q, p, p, t, v]); g = np.select(conds, [t, v, v, q, p, p]); b = np.select(conds, [p, p, t, v, v, q])
    return np.stack([r, g, b], -1)


rgb = a[:H, :, :3]
alpha = a[:H, :, 3]
hsv = rgb_to_hsv(rgb)
h, s, v = hsv[..., 0] * 360, hsv[..., 1], hsv[..., 2]
yy = np.arange(H)[:, None] * np.ones((1, W))
head_zone = yy < 16
skin_like = (h > 10) & (h < 45) & (s > 0.08) & (v > 0.5)
blue_like = (h > 190) & (h < 270) & (s > 0.15)
dark_like = (v < 0.28) & ~blue_like
silver = (s < 0.22) & (v > 0.35) & ~skin_like
hair_mask = head_zone & silver & (alpha > 0.1)
vest_mask = blue_like & ~head_zone & (v >= 0.12)
pants_mask = (dark_like | (blue_like & (v < 0.2))) & ~head_zone
shirt_mask = silver & ~head_zone & (alpha > 0.1)
red_mask = ((h < 12) | (h > 340)) & (s > 0.35) & ~head_zone


def recolor(name, hair=None, vest=None, shirt=None, pants=None, tie=None):
    o = rgb.copy()
    def apply(mask, target, strength=1.0):
        if target is None: return
        th, ts, tv = target
        nh = hsv.copy()
        nh[..., 0] = th / 360.0
        nh[..., 1] = np.clip(ts, 0, 1) if np.isscalar(ts) else ts
        # pertahankan relief (kecerahan asli) dengan skala tv
        base = hsv[..., 2]
        nh[..., 2] = np.clip(base * tv, 0, 1)
        c = hsv_to_rgb(nh)
        o[mask] = c[mask]
    apply(hair_mask, hair)
    apply(vest_mask, vest)
    apply(shirt_mask, shirt)
    apply(pants_mask, pants)
    apply(red_mask, tie)
    out = np.concatenate([np.concatenate([o, alpha[..., None]], -1), a[H:, :, :]], 0)
    Image.fromarray((np.clip(out, 0, 1) * 255).astype(np.uint8), 'RGBA').save(f'{outdir}/skin_{name}.png')


# (hue, saturasi, pengali kecerahan)
recolor('elder', hair=(210, 0.04, 1.35), vest=(165, 0.55, 1.15), shirt=(200, 0.15, 0.95), pants=(165, 0.4, 1.1), tie=(45, 0.7, 1.2))
recolor('smith', hair=(22, 0.6, 0.48), vest=(24, 0.65, 1.0), shirt=(30, 0.12, 0.6), pants=(25, 0.3, 0.8), tie=(20, 0.2, 0.5))
recolor('rasi', hair=(25, 0.5, 0.35), vest=(38, 0.4, 1.9), shirt=(45, 0.12, 1.1), pants=(35, 0.45, 1.6), tie=(8, 0.65, 1.1))
print('ok')
