"""Konversi rig Prisma 3D (ZN RIG V2 FK) -> hero.glb (satu mesh, satu skin, 17 sendi) + skin PNG.
Pakai: python3 convert_hero.py rig.prisma out_dir [--list]
"""
import sys, io, json, struct
import numpy as np
from PIL import Image
sys.path.insert(0, '.')
from prisma_loader import *
from skinned import skin_positions
import pygltflib as g

path, outdir = sys.argv[1], sys.argv[2]
top, pngs = load_project(path)
nodes = build_nodes(top)
meshes = load_meshes(top)
skin_png0 = list(pngs.values())[0]
_im = Image.open(io.BytesIO(skin_png0)).convert('RGBA')
_atlas = Image.new('RGBA', (64, 66), (255, 255, 255, 255))
_atlas.paste(_im, (0, 0))
_buf = io.BytesIO(); _atlas.save(_buf, 'PNG'); skin_png = _buf.getvalue()

def under(i, root):
    while i in nodes:
        if i == root: return True
        i = nodes[i].parent
    return False

def find(name, root=None):
    return [n.id for n in nodes.values() if n.name == name and (root is None or under(n.id, root))]

# ---- penanda struktur (diambil lewat nama agar tahan variasi id) ----
HIPS = find('Bone', 1)[0] if False else 37
IDS = dict(hips=37, spine=38, chest=39, chest2=40, head=42)
ARM_ROOT = {'l': 265, 'r': 311}   # "Left Arm" / "Right Arm" di Slim Arms
SLIM = 263; WIDE = 357

def wpos(i):
    return nodes[i].world[:3, 3]

# ---- definisi sendi (nama, induk, posisi dunia asli) ----
J = []   # (name, parent_name, pos)
def addj(name, parent, pos): J.append((name, parent, np.array(pos, dtype=float)))
addj('root', None, [wpos(37)[0], 0.0, 0.0])
addj('hips', 'root', wpos(37))
addj('spine', 'hips', wpos(38))
addj('chest', 'spine', wpos(39))
addj('head', 'chest', wpos(42))
# lengan: cari bone atas per sisi: anak 'Bone' pertama dari mesh Left/Right Arm
def arm_bones(root_mesh_node):
    return [c for c in nodes[root_mesh_node].children if nodes[c].is_bone][0]
top_bone = {s: arm_bones(ARM_ROOT[s]) for s in 'lr'}
elbow_y = None
for s in 'lr':
    tb = top_bone[s]
    # tulang bernama 'Bone 64' dalam subtree = siku
    el = [n.id for n in nodes.values() if under(n.id, tb) and n.is_bone and n.name == 'Bone 64'][0]
    wr = [n.id for n in nodes.values() if under(n.id, tb) and n.is_bone and n.name == 'Bone 12'][0]
    addj(f'upperarm_{s}', 'chest', wpos(tb))
    addj(f'forearm_{s}', f'upperarm_{s}', wpos(el))
    addj(f'hand_{s}', f'forearm_{s}', wpos(wr))
    if s == 'l': ARM_Y = (wpos(el)[1], wpos(wr)[1])
# kaki: Bone 111 (id 4) -> Left Leg(5)/Right Leg(21)
for s, leg in (('l', 5), ('r', 21)):
    hip = [c for c in nodes[leg].children if nodes[c].is_bone][0]
    sub = [n for n in nodes.values() if under(n.id, hip) and n.is_bone]
    knee = [n.id for n in sub if n.name == 'Bone 64'][0]
    ankle = [n.id for n in sub if n.name == 'Bone 12'][0]
    addj(f'thigh_{s}', 'hips', wpos(hip))
    addj(f'shin_{s}', f'thigh_{s}', wpos(knee))
    addj(f'foot_{s}', f'shin_{s}', wpos(ankle))
JN = {j[0]: k for k, j in enumerate(J)}
KNEE_Y = wpos([n.id for n in nodes.values() if under(n.id, 4) and n.name == 'Bone 64'][0])[1]
ANKLE_Y = wpos([n.id for n in nodes.values() if under(n.id, 4) and n.name == 'Bone 12'][0])[1]
print('elbow/wrist y', ARM_Y, 'knee/ankle y', KNEE_Y, ANKLE_Y)
ELB, WRI = ARM_Y
HIPS_X = wpos(37)[0]

def side_of_x(x): return 'l' if x < HIPS_X else 'r'

def classify_bone(bid):
    """tulang asli -> nama sendi."""
    n = nodes[bid]
    if bid in (37,): return 'hips'
    if bid == 38: return 'spine'
    if bid in (39, 40): return 'chest'
    if under(bid, 42): return 'head'
    y = wpos(bid)[1]
    for s in 'lr':
        if under(bid, ARM_ROOT[s]):
            if y > ELB + 0.01: return f'upperarm_{s}'
            if y > WRI + 0.01: return f'forearm_{s}'
            return f'hand_{s}'
    if under(bid, 4):
        s = side_of_x(wpos(bid)[0])
        if y > KNEE_Y + 0.03: return f'thigh_{s}'
        if y > ANKLE_Y + 0.05: return f'shin_{s}'
        return f'foot_{s}'
    if under(bid, 1) and bid in (264,): return 'chest'
    # fallback: naik ke induk bertulang
    p = n.parent
    while p in nodes and not nodes[p].is_bone: p = nodes[p].parent
    if p in nodes and p != bid: return classify_bone(p)
    return 'chest'

def classify_static(nid):
    """mesh statis -> sendi lewat induk."""
    if under(nid, 42): return 'head'
    if under(nid, 41): return 'head'
    for s in 'lr':
        if under(nid, ARM_ROOT[s]):
            p = nid
            while p in nodes and not nodes[p].is_bone: p = nodes[p].parent
            return classify_bone(p)
    if under(nid, 451): return 'chest'
    return 'chest'

# ---- pilih mesh yang dipakai ----
EXCLUDE_NODES = {45, 63, 67}          # rambut cadangan, 4 kotak melayang, hiasan melayang
EXCLUDE_SUBTREES = [WIDE, 166]        # lengan lebar (alternatif), 'idk'
FACE_ROOT, EYES_ROOT, BROWS_ROOT = 68, 70, 150
mats = {m[0]: {f[0]: f[1] for f in m[2]} for m in top[2]}
def mat_color(mid):
    d = mats.get(mid)
    if not d or 'color' not in d: return (1.0, 1.0, 1.0, 1.0)
    c = json.loads(d['color'])
    a = float(d.get('alpha', 1))
    return (c['r'] ** 2.2, c['g'] ** 2.2, c['b'] ** 2.2, a)
def keep(nd):
    if nd.mesh_id is None or not effective_active(nodes, nd.id): return False
    if nd.id in EXCLUDE_NODES: return False
    for r in EXCLUDE_SUBTREES:
        if under(nd.id, r): return False
    if under(nd.id, FACE_ROOT):   # sistem wajah: hanya mata utama + alis
        if not (under(nd.id, EYES_ROOT) or under(nd.id, BROWS_ROOT)): return False
    if nd.material in mats and mat_color(nd.material)[3] < 0.5: return False
    return True

# ---- bangun geometri gabungan ----
P_all, N_all, UV_all, J_all, W_all, C_all, IDX = [], [], [], [], [], [], []
ATLAS_H = 66   # 64 baris skin + 2 baris putih untuk bagian warna polos
vcount = 0
stats = {'flip': 0, 'tot': 0}
def mirror(v):  # LH -> RH : balik sumbu x (dan geser agar simetris)
    v = np.array(v, dtype=float).copy()
    v[..., 0] = -(v[..., 0] - HIPS_X)
    return v
for nd in nodes.values():
    if not keep(nd): continue
    ms = meshes[nd.mesh_id]
    pw = skin_positions(nodes, nd, ms)
    idx = ms.indices.reshape(-1, 3)
    uv = ms.corner_uv.reshape(-1, 3, 2)
    W3 = nd.world[:3, :3]
    nrm_m = np.linalg.inv(W3).T
    skinned = nd.skin_bones is not None and len(ms.invbind) > 0
    if skinned:
        jn = [JN[classify_bone(b)] for b in nd.skin_bones]
    else:
        static_j = JN[classify_static(nd.id)]
    for t in range(len(idx)):
        tri = pw[idx[t]]
        n_st = nrm_m @ ms.tri_normals[t]
        n_st /= (np.linalg.norm(n_st) + 1e-12)
        e1, e2 = tri[1] - tri[0], tri[2] - tri[0]
        n_geo = np.cross(e1, e2)
        ln = np.linalg.norm(n_geo)
        if ln < 1e-12: continue
        n_geo /= ln
        order = [0, 1, 2]
        stats['tot'] += 1
        # orientasi: normal tersimpan dianggap benar (di sistem asli, putaran CCW/CW belum pasti) -> pakai dot
        if np.dot(n_geo, n_st) < 0:
            order = [0, 2, 1]; n_use = -n_geo; stats['flip'] += 1
        else:
            n_use = n_geo
        # cermin x -> urutan putaran dibalik
        order = [order[0], order[2], order[1]]
        n_use = mirror(n_use + np.array([HIPS_X, 0, 0]))  # arah saja
        n_use = n_use - mirror(np.array([HIPS_X, 0, 0]))   # (dikoreksi di bawah)
        for k in order:
            vi = idx[t][k]
            P_all.append(mirror(pw[vi]))
            n_dir = np.array([-n_geo[0] if np.dot(n_geo, n_st) >= 0 else n_geo[0], 0, 0])  # placeholder diganti di bawah
            if nd.material == 1:
                UV_all.append([uv[t][k][0], (1.0 - uv[t][k][1]) * 64.0 / ATLAS_H]); C_all.append((1, 1, 1, 1))
            else:
                UV_all.append([0.5, 65.0 / ATLAS_H]); C_all.append(mat_color(nd.material) if nd.material in mats else (1, 1, 1, 1))
            if skinned:
                bj, bw = ms.bone_idx[vi], ms.bone_w[vi]
                acc = {}
                for q in range(4):
                    if bw[q] > 1e-5:
                        jj = jn[bj[q]] if bj[q] < len(jn) else JN['chest']
                        acc[jj] = acc.get(jj, 0.0) + bw[q]
                items = sorted(acc.items(), key=lambda kv: -kv[1])[:4]
                s = sum(w for _, w in items) or 1.0
                ids4 = [it[0] for it in items] + [0] * (4 - len(items))
                w4 = [it[1] / s for it in items] + [0.0] * (4 - len(items))
            else:
                ids4 = [static_j, 0, 0, 0]; w4 = [1.0, 0, 0, 0]
            J_all.append(ids4); W_all.append(w4)
        # normal per segitiga (sudah dicerminkan & diorientasikan)
        flat_n = n_geo if np.dot(n_geo, n_st) >= 0 else -n_geo
        flat_n = np.array([-flat_n[0], flat_n[1], flat_n[2]])
        N_all.extend([flat_n] * 3)
print('segitiga', stats, 'verts', len(P_all))
P = np.array(P_all, dtype=np.float32); N = np.array(N_all, dtype=np.float32)
UV = np.array(UV_all, dtype=np.float32); CC = np.array(C_all, dtype=np.float32); JJ = np.array(J_all, dtype=np.uint16); WW = np.array(W_all, dtype=np.float32)
# las titik kembar (posisi+normal+uv+bobot sama) -> jauh lebih sedikit vertex
_key = np.concatenate([P, N, UV, JJ.astype(np.float32), WW, CC], axis=1)
_key = np.round(_key, 5)
_u, _first, _inv = np.unique(_key, axis=0, return_index=True, return_inverse=True)
_inv = _inv.reshape(-1)
P, N, UV, JJ, WW, CC = P[_first], N[_first], UV[_first], JJ[_first], WW[_first], CC[_first]
IDX = _inv.astype(np.uint32)
print('vertex setelah dilas', len(P), 'segitiga', len(IDX) // 3)
print('bbox', P.min(0), P.max(0))
np.savez(f'{outdir}/hero_raw.npz', P=P, N=N, UV=UV, JJ=JJ, WW=WW)

# ---- glTF ----
gl = g.GLTF2()
gl.asset = g.Asset(version='2.0', generator='kubus convert_hero')
blob = bytearray()
def add_view(arr, target=None):
    global blob
    while len(blob) % 4: blob += b'\0'
    off = len(blob); blob += arr.tobytes()
    gl.bufferViews.append(g.BufferView(buffer=0, byteOffset=off, byteLength=arr.nbytes, target=target))
    return len(gl.bufferViews) - 1
def add_acc(arr, ctype, atype, target=None, minmax=False):
    v = add_view(arr, target)
    a = g.Accessor(bufferView=v, componentType=ctype, count=len(arr), type=atype)
    if minmax:
        a.min = arr.min(0).astype(float).tolist(); a.max = arr.max(0).astype(float).tolist()
    gl.accessors.append(a)
    return len(gl.accessors) - 1
a_pos = add_acc(P, g.FLOAT, g.VEC3, g.ARRAY_BUFFER, True)
a_nrm = add_acc(N, g.FLOAT, g.VEC3, g.ARRAY_BUFFER)
a_uv = add_acc(UV, g.FLOAT, g.VEC2, g.ARRAY_BUFFER)
a_j = add_acc(JJ, g.UNSIGNED_SHORT, g.VEC4, g.ARRAY_BUFFER)
a_w = add_acc(WW, g.FLOAT, g.VEC4, g.ARRAY_BUFFER)
a_c = add_acc(CC, g.FLOAT, g.VEC4, g.ARRAY_BUFFER)
a_i = add_acc(IDX, g.UNSIGNED_INT, g.SCALAR, g.ELEMENT_ARRAY_BUFFER)
# sendi
jpos = [mirror(j[2]) for j in J]
pidx = [(-1 if j[1] is None else JN[j[1]]) for j in J]
for k, j in enumerate(J):
    t = jpos[k] - (jpos[pidx[k]] if pidx[k] >= 0 else 0)
    gl.nodes.append(g.Node(name=j[0], translation=[float(x) for x in t]))
for k in range(len(J)):
    if pidx[k] >= 0: gl.nodes[pidx[k]].children.append(k)
ibm = np.zeros((len(J), 4, 4), dtype=np.float32)
for k in range(len(J)):
    m = np.eye(4); m[:3, 3] = -jpos[k]
    ibm[k] = m.T   # glTF: kolom-mayor
a_ibm = add_acc(ibm.reshape(-1, 16), g.FLOAT, g.MAT4)
gl.accessors[a_ibm].count = len(J)
gl.skins.append(g.Skin(joints=list(range(len(J))), inverseBindMatrices=a_ibm, skeleton=0, name='Skin'))
# material + gambar
gl.images.append(g.Image(bufferView=add_view(np.frombuffer(skin_png, dtype=np.uint8)), mimeType='image/png', name='skin'))
gl.samplers.append(g.Sampler(magFilter=9728, minFilter=9728))
gl.textures.append(g.Texture(source=0, sampler=0))
gl.materials.append(g.Material(name='skin', pbrMetallicRoughness=g.PbrMetallicRoughness(baseColorTexture=g.TextureInfo(index=0), metallicFactor=0.0, roughnessFactor=1.0), alphaMode='MASK', alphaCutoff=0.5, doubleSided=False))
gl.meshes.append(g.Mesh(name='Hero', primitives=[g.Primitive(attributes=g.Attributes(POSITION=a_pos, NORMAL=a_nrm, TEXCOORD_0=a_uv, JOINTS_0=a_j, WEIGHTS_0=a_w, COLOR_0=a_c), indices=a_i, material=0)]))
gl.nodes.append(g.Node(name='Body', mesh=0, skin=0))
mesh_node = len(gl.nodes) - 1
gl.scenes.append(g.Scene(nodes=[0, mesh_node]))
gl.scene = 0
gl.buffers.append(g.Buffer(byteLength=len(blob)))
gl.set_binary_blob(bytes(blob))
gl.save_binary(f'{outdir}/hero.glb')
open(f'{outdir}/skin.png', 'wb').write(skin_png)
json.dump({'joints': [{'name': j[0], 'parent': j[1], 'pos': [float(x) for x in jpos[k]]} for k, j in enumerate(J)]}, open(f'{outdir}/hero_joints.json', 'w'), indent=1)
print('OK', f'{outdir}/hero.glb')
