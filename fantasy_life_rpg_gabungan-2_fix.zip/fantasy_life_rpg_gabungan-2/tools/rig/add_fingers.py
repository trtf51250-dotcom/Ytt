"""Pasca-proses hero.glb (17 sendi) -> hero.glb v2: tangan baru dengan jari bertulang + sendi mata.
Pakai: python3 tools/rig/add_fingers.py tools/rig/hero_v1_backup.glb assets/hero/hero.glb

Per tangan: telapak (menempel di sendi hand_*), 4 jari x 2 ruas (f0..f3 = telunjuk..kelingking, *_a pangkal, *_b ujung) + jempol 2 ruas (th_a, th_b).
Mata: sendi eye_l / eye_r (anak head) untuk kedip (skala Y) & melirik (rotasi) - tidak punya mesh, dipakai untuk menempel kuad mata.
Plat tangan lama (kotak kepalan) dibuang; cincin lengan (lapisan luar) tetap.
"""
import sys, json, struct
import numpy as np
import pygltflib as g

src, dst = sys.argv[1], sys.argv[2]
SKIN_REF = sys.argv[3] if len(sys.argv) > 3 else 'assets/hero/skin_ren.png'
gl = g.GLTF2().load_binary(src)
blob = gl.binary_blob()
def acc(i):
    a = gl.accessors[i]; bv = gl.bufferViews[a.bufferView]
    n = {'VEC3': 3, 'VEC2': 2, 'VEC4': 4, 'SCALAR': 1, 'MAT4': 16}[a.type]
    dt = {5126: np.float32, 5123: np.uint16, 5125: np.uint32}[a.componentType]
    return np.frombuffer(blob, dtype=dt, count=a.count * n, offset=(bv.byteOffset or 0) + (a.byteOffset or 0)).reshape(-1, n).copy()
prim = gl.meshes[0].primitives[0]
at = prim.attributes
P = acc(at.POSITION); N = acc(at.NORMAL); UV = acc(at.TEXCOORD_0); J = acc(at.JOINTS_0); W = acc(at.WEIGHTS_0); C = acc(at.COLOR_0)
IDX = acc(prim.indices).reshape(-1, 3)
names = [n.name for n in gl.nodes]
nidx = {n: i for i, n in enumerate(names)}
parent = {}
for i, n in enumerate(gl.nodes):
    for c in (n.children or []): parent[c] = i
def world(i):
    p = np.array(gl.nodes[i].translation or [0, 0, 0], dtype=float)
    while i in parent:
        i = parent[i]; p += np.array(gl.nodes[i].translation or [0, 0, 0])
    return p
skin = gl.skins[0]
joints = list(skin.joints)   # urutan sendi = indeks JOINTS_0

# ---- buang plat tangan lama ----
removed = 0
keep_tri = np.ones(len(IDX), dtype=bool)
sample_uv = {}
for s in 'lr':
    jn = joints.index(nidx['hand_' + s])
    hw = world(nidx['hand_' + s])
    dom = ((J == jn) & (W > 0.5)).any(1)
    narrow = dom & (abs(P[:, 0] - hw[0]) < 0.125) & (abs(P[:, 2]) < 0.15) & (P[:, 1] < hw[1] + 0.02)
    tri_sel = narrow[IDX].all(1)
    # UV kulit polos: texel (pada skin_ren) yang tidak transparan & berwarna kulit, paling sering muncul pada segitiga plat lama
    from collections import Counter
    from PIL import Image
    img = np.array(Image.open(SKIN_REF).convert('RGBA'))
    cnt = Counter()
    for t in np.where(tri_sel)[0]:
        uvc = UV[IDX[t]].mean(0)
        px, py = min(int(uvc[0] * 64), 63), min(int(uvc[1] * 66), 65)
        r_, g_, b_, a_ = [int(v) for v in img[py, px]]
        if a_ > 200 and r_ > g_ > b_ and r_ > 150 and (r_ - b_) > 25:
            cnt[(px, py)] += 1
    (px, py), _ = cnt.most_common(1)[0]
    sample_uv[s] = np.array([(px + 0.5) / 64.0, (py + 0.5) / 66.0], dtype=np.float32)
    keep_tri &= ~tri_sel
    removed += int(tri_sel.sum())
print('segitiga plat tangan dibuang:', removed, 'uv kulit', sample_uv)
IDX = IDX[keep_tri]

# ---- util geometri ----
newP, newN, newUV, newJ, newW, newC, newI = [], [], [], [], [], [], []
def add_box(center, size, jidx, uv, shade=1.0):
    cx, cy, cz = center; sx, sy, sz = [s / 2 for s in size]
    faces = [((1, 0, 0), [(1, -1, -1), (1, 1, -1), (1, 1, 1), (1, -1, 1)]),
             ((-1, 0, 0), [(-1, -1, 1), (-1, 1, 1), (-1, 1, -1), (-1, -1, -1)]),
             ((0, 1, 0), [(-1, 1, -1), (-1, 1, 1), (1, 1, 1), (1, 1, -1)]),
             ((0, -1, 0), [(-1, -1, 1), (-1, -1, -1), (1, -1, -1), (1, -1, 1)]),
             ((0, 0, 1), [(-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1)]),
             ((0, 0, -1), [(1, -1, -1), (-1, -1, -1), (-1, 1, -1), (1, 1, -1)])]
    base = len(newP) + len(P)
    for nrm, vs in faces:
        b0 = len(newP) + len(P)
        for v in vs:
            newP.append([cx + v[0] * sx, cy + v[1] * sy, cz + v[2] * sz]); newN.append(list(nrm)); newUV.append(list(uv))
            newJ.append([jidx, 0, 0, 0]); newW.append([1, 0, 0, 0]); k_ = shade * (0.8 if nrm[1] < 0 else (0.9 if abs(nrm[0]) > 0 else 1.0)); newC.append([k_, k_, k_, 1])
        newI.extend([[b0, b0 + 1, b0 + 2], [b0, b0 + 2, b0 + 3]])

new_nodes = []   # (name, parent_node_index, world_pos)
def add_joint(name, par, wpos):
    new_nodes.append((name, par, np.array(wpos, dtype=float)))
    return len(gl.nodes) + len(new_nodes) - 1
joint_of_new = {}   # nama -> indeks sendi (urutan skin)
def jindex(name):
    return len(joints) + [n[0] for n in new_nodes].index(name)

for s, sg in (('l', 1.0), ('r', -1.0)):     # sg: +1 kiri (x positif), -1 kanan
    hn = nidx['hand_' + s]
    hw = world(hn)
    uv = sample_uv[s]
    jh = joints.index(hn)
    # telapak: menempel di sendi hand_*
    add_box((hw[0], hw[1] - 0.04, hw[2]), (0.20, 0.09, 0.26), jh, uv)
    # 4 jari: z dari depan (telunjuk) ke belakang (kelingking)
    zs = [0.099, 0.033, -0.033, -0.099]
    lens = [(0.062, 0.050), (0.068, 0.054), (0.064, 0.052), (0.052, 0.042)]
    for fi, z in enumerate(zs):
        l1, l2 = lens[fi]
        kx = hw[0] - sg * 0.045                      # buku jari di sisi dalam telapak
        ky = hw[1] - 0.085
        ja = add_joint(f'f{fi}_{s}_a', hn, (kx, ky, hw[2] + z))
        jb = add_joint(f'f{fi}_{s}_b', ja, (kx, ky - l1, hw[2] + z))
        ia, ib = jindex(f'f{fi}_{s}_a'), jindex(f'f{fi}_{s}_b')
        add_box((kx, ky - l1 / 2, hw[2] + z), (0.062, l1 + 0.004, 0.056), ia, uv, 0.98)
        add_box((kx, ky - l1 - l2 / 2, hw[2] + z), (0.056, l2, 0.052), ib, uv, 0.9)
    # jempol: pangkal di sudut depan-dalam telapak, menunjuk ke depan (+z)
    tx, ty, tz = hw[0] - sg * 0.06, hw[1] - 0.045, hw[2] + 0.125
    ta = add_joint(f'th_{s}_a', hn, (tx, ty, tz))
    tb = add_joint(f'th_{s}_b', ta, (tx, ty, tz + 0.055))
    ita, itb = jindex(f'th_{s}_a'), jindex(f'th_{s}_b')
    add_box((tx, ty, tz + 0.0275), (0.07, 0.066, 0.059), ita, uv, 0.97)
    add_box((tx, ty, tz + 0.055 + 0.022), (0.06, 0.058, 0.046), itb, uv, 0.9)

# ---- sendi mata (anak head) ----
hd = nidx['head']; hdw = world(hd)
EYE_Z = 0.29
for s, sg in (('l', 1.0), ('r', -1.0)):
    # catatan: di glb kiri karakter = +x; _eyes() lama memakai side=-1 untuk sisi -x
    add_joint(f'eye_{s}', hd, (sg * 0.128, hdw[1] + 0.092, EYE_Z))

# ---- tulis ulang ----
P2 = np.vstack([P, np.array(newP, dtype=np.float32)])
N2 = np.vstack([N, np.array(newN, dtype=np.float32)])
UV2 = np.vstack([UV, np.array(newUV, dtype=np.float32)])
J2 = np.vstack([J, np.array(newJ, dtype=np.uint16)])
W2 = np.vstack([W, np.array(newW, dtype=np.float32)])
C2 = np.vstack([C, np.array(newC, dtype=np.float32)])
I2 = np.vstack([IDX, np.array(newI, dtype=np.uint32).reshape(-1, 3)]).astype(np.uint32)
print('vertex', len(P), '->', len(P2), 'segitiga', len(IDX) + len(newI))

# node baru
for (name, par, wpos) in new_nodes:
    pw = world(par) if par < len(gl.nodes) else None
for k, (name, par, wpos) in enumerate(new_nodes):
    gl.nodes.append(g.Node(name=name))
base_n = len(gl.nodes) - len(new_nodes)
wmap = {}
for k, (name, par, wpos) in enumerate(new_nodes):
    wmap[base_n + k] = wpos
def wpos_of(i):
    return wmap[i] if i in wmap else world(i)
for k, (name, par, wpos) in enumerate(new_nodes):
    ni = base_n + k
    gl.nodes[ni].translation = [float(x) for x in (wpos - wpos_of(par))]
    gl.nodes[par].children = (gl.nodes[par].children or []) + [ni]
joints2 = joints + [base_n + k for k in range(len(new_nodes))]
ibm_old = acc(skin.inverseBindMatrices).reshape(-1, 16)
ibm_new = []
for k, (name, par, wpos) in enumerate(new_nodes):
    m = np.eye(4); m[:3, 3] = -wpos
    ibm_new.append(m.T.reshape(16))
IBM2 = np.vstack([ibm_old, np.array(ibm_new, dtype=np.float32)]).astype(np.float32)

# bangun buffer baru (ganti semua accessor/bufferView mesh; gambar tetap)
img_views = [im.bufferView for im in gl.images]
img_data = {v: bytes(blob[(gl.bufferViews[v].byteOffset or 0):(gl.bufferViews[v].byteOffset or 0) + gl.bufferViews[v].byteLength]) for v in img_views}
gl.bufferViews = []; gl.accessors = []
nb = bytearray()
def add_view(arr_bytes, target=None):
    global nb
    while len(nb) % 4: nb += b'\0'
    off = len(nb); nb += arr_bytes
    gl.bufferViews.append(g.BufferView(buffer=0, byteOffset=off, byteLength=len(arr_bytes), target=target))
    return len(gl.bufferViews) - 1
def add_acc(arr, ctype, atype, target=None, minmax=False):
    v = add_view(arr.tobytes(), target)
    a = g.Accessor(bufferView=v, componentType=ctype, count=len(arr), type=atype)
    if minmax: a.min = arr.min(0).astype(float).tolist(); a.max = arr.max(0).astype(float).tolist()
    gl.accessors.append(a); return len(gl.accessors) - 1
prim.attributes.POSITION = add_acc(P2, g.FLOAT, g.VEC3, g.ARRAY_BUFFER, True)
prim.attributes.NORMAL = add_acc(N2, g.FLOAT, g.VEC3, g.ARRAY_BUFFER)
prim.attributes.TEXCOORD_0 = add_acc(UV2, g.FLOAT, g.VEC2, g.ARRAY_BUFFER)
prim.attributes.JOINTS_0 = add_acc(J2, g.UNSIGNED_SHORT, g.VEC4, g.ARRAY_BUFFER)
prim.attributes.WEIGHTS_0 = add_acc(W2, g.FLOAT, g.VEC4, g.ARRAY_BUFFER)
prim.attributes.COLOR_0 = add_acc(C2, g.FLOAT, g.VEC4, g.ARRAY_BUFFER)
prim.indices = add_acc(I2.reshape(-1), g.UNSIGNED_INT, g.SCALAR, g.ELEMENT_ARRAY_BUFFER)
skin.joints = joints2
skin.inverseBindMatrices = add_acc(IBM2.reshape(-1, 16), g.FLOAT, g.MAT4)
gl.accessors[skin.inverseBindMatrices].count = len(joints2)
for im, v in zip(gl.images, img_views):
    im.bufferView = add_view(img_data[v])
gl.buffers[0].byteLength = len(nb)
gl.set_binary_blob(bytes(nb))
gl.save_binary(dst)
print('OK', dst, 'sendi', len(joints2))
