extends RefCounted
## Bot uji stage: bermain otomatis (kejar musuh terdekat, serang, skill, hindar, ramuan, ganti karakter saat pingsan) sampai stage selesai.
## Jalankan: -- --bot=1 --botscript=stage_bot --stage=s1_1 --shots=/dir [--lose=1 supaya sengaja kalah]  . Mencetak "CHECK ..." dan ringkasan.

var st: Node3D
var fails := 0


func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1


func _enemies() -> Array:
	return st.get_tree().get_nodes_in_group("enemies").filter(func(e): return not e.dead and e.state != "spawn")


func _tick() -> void:
	var p: Player = st.player
	p.cam_yaw = st.cam.yaw
	var list := _enemies()
	if st.get_tree().paused or st.state == st.S.ENDED:
		return
	if list.is_empty() or p.dead:
		p.move_input = Vector2.ZERO
		return
	var best: Node3D = list[0]
	var bd := 1e9
	for e: Node3D in list:
		var d := e.global_position.distance_to(p.global_position)
		if d < bd:
			bd = d
			best = e
	var to := best.global_position - p.global_position
	to.y = 0.0
	var d3 := to.normalized()
	var rng: float = p.data.attack_range if p.data else 2.5
	var ranged: bool = p.data.attack_kind in ["bolt", "arrow"]
	var want := rng * 0.7 if not ranged else 7.0
	var v := Vector3(d3).rotated(Vector3.UP, -st.cam.yaw)
	var mv := Vector2(v.x, v.z)
	if bd > want:
		p.move_input = mv
	elif ranged and bd < 3.5:
		p.move_input = -mv
	else:
		p.move_input = Vector2.ZERO
	var dir := Vector3(sin(p.facing), 0, cos(p.facing))
	if bd < (rng + 0.8 if not ranged else 10.0):
		p.do_attack()
		if p.skill_cd <= 0.0 and (list.size() >= 2 or best.is_boss):
			p.do_skill()
	# hindari serangan (musuh sedang bersiap & dekat)
	if best.state == "windup" and bd < 3.5 and p.dodge_cd <= 0.0 and best.is_boss:
		p.do_dodge()
	if p.hp < p.max_hp * 0.4 and st._potion_choice() != "":
		st._use_potion()
	if p.dead:
		return


func run(s: Node3D) -> void:
	st = s
	var timer := 0.0
	var shot_at := {3.0: "stage_01_wave1", 10.0: "stage_02_fight"}
	var shots_done := {}
	var god := OS.get_cmdline_user_args().has("--god=1")
	var lose := OS.get_cmdline_user_args().has("--lose=1")
	st.autoplay = true
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--speed="):
			Engine.time_scale = float(a.substr(8))
	await st.get_tree().create_timer(0.5).timeout
	await st._shot("stage_00_start")
	var step := 0.05
	while st.state != st.S.ENDED and timer < 240.0:
		await st.get_tree().create_timer(step).timeout
		timer += step
		if lose:
			st.player.take_damage(3, st.player.global_position + Vector3(1, 0, 0))
			st.player.invuln = 0.0
		else:
			_tick()
		if god:
			st.player.hp = st.player.max_hp
		for k in shot_at:
			if timer >= k and not shots_done.has(k):
				shots_done[k] = true
				await st._shot(shot_at[k])
		if st.boss != null and is_instance_valid(st.boss) and not shots_done.has("boss") and st.boss.state == "windup":
			shots_done["boss"] = true
			await st._shot("stage_boss_windup")
	if st.state != st.S.ENDED:
		for e in st.get_tree().get_nodes_in_group("enemies"):
			if is_instance_valid(e) and not e.dead:
				print("STUCK enemy kind=", e.kind, " hp=", e.hp, "/", e.max_hp, " state=", e.state, " pos=", e.global_position, " player=", st.player.global_position, " boss=", e.is_boss, " arena_r=", st.arena.radius)
	print("stage ended: state=", st.state, " win=", st._ended_win, " time=%.1f" % st.time, " kills=", st.kills, " fainted=", st.fainted)
	await st.get_tree().create_timer(2.5).timeout
	await st._shot("stage_99_result")
	check("stage terminated within 240 s", st.state == st.S.ENDED)
	check("result matches expectation", st._ended_win == (not lose))
	var rec: Dictionary = GameState.stages.get(st.sd.id, {})
	check("record updated on win", (not st._ended_win) or rec.get("cleared", false), str(rec))
	print("CHECK SUMMARY fails=", fails)
