#!/usr/bin/env python3
"""Mata kotak SOLID per karakter (gaya & watak masing-masing) -> assets/hero/eyes/eye_<id>.png. Sudut luar di KIRI gambar.
Versi anime lama: tools/eyes_old/."""
from PIL import Image
GW, GH, S = 16, 10, 12
DARK = (22, 18, 40, 255); WHITE = (255, 255, 255, 255)
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
# col=iris, lid=baris kelopak atas tambahan (mata setengah tertutup), iw=lebar iris, tail=ekor bulu mata luar, pupil=round|slit|none,
# spark=std|star|soft, glow=pita terang bawah iris, scl=warna sklera, top=warna atas iris, lowlid=kelopak bawah gelap (mata tajam)
STY = {
 "ren":    dict(col=(64,153,255),  lid=0, iw=8, tail=2, pupil="round", spark="std",  glow=0.0, scl=(236,240,255), top=(14,20,70)),
 "lyra":   dict(col=(190,120,255), lid=0, iw=10, tail=1, pupil="none",  spark="star", glow=0.2, scl=(242,236,255), top=(60,20,110)),
 "brann":  dict(col=(242,153,51),  lid=2, iw=7, tail=1, pupil="round", spark="std",  glow=0.0, scl=(240,232,220), top=(70,30,10), lowlid=True),
 "sera":   dict(col=(89,217,115),  lid=0, iw=9, tail=2, pupil="round", spark="soft", glow=0.25, scl=(240,250,240), top=(10,60,40)),
 "ember":  dict(col=(255,120,40),  lid=1, iw=8, tail=3, pupil="slit",  spark="std",  glow=0.45, scl=(255,240,225), top=(120,20,10), lowlid=True),
 "zeya":   dict(col=(235,80,195),  lid=1, iw=8, tail=3, pupil="slit",  spark="std",  glow=0.15, scl=(248,230,244), top=(70,10,60), lowlid=True),
 "hakuya": dict(col=(120,200,255), lid=2, iw=8, tail=2, pupil="round", spark="soft", glow=0.5, scl=(236,244,255), top=(20,50,110)),
 "vael":   dict(col=(70,235,255),  lid=0, iw=9, tail=2, pupil="round", spark="std",  glow=0.6, scl=(232,248,255), top=(10,50,100)),
 "lucien": dict(col=(255,205,80),  lid=1, iw=7, tail=2, pupil="round", spark="std",  glow=0.1, scl=(250,246,230), top=(50,30,10), lowlid=True),
 "wenyu":  dict(col=(80,220,205),  lid=0, iw=10, tail=1, pupil="none", spark="soft", glow=0.3, scl=(238,250,248), top=(10,60,70)),
 "kuroha": dict(col=(225,50,80),   lid=2, iw=8, tail=3, pupil="slit",  spark="std",  glow=0.1, scl=(244,232,236), top=(60,6,20), lowlid=True),
 # Aion (pengendali waktu): mata beda warna - hijau (kiri karakter) & ungu (kanan karakter, file *_r)
 "aion":   dict(col=(110,225,150), lid=1, iw=8, tail=2, pupil="round", spark="soft", glow=0.35, scl=(240,244,250), top=(10,70,60)),
 "aion_r": dict(col=(170,110,255), lid=1, iw=8, tail=2, pupil="round", spark="soft", glow=0.35, scl=(240,244,250), top=(50,20,110)),
}

def make(st):
    col, lid, iw, tail = st["col"], st["lid"], st["iw"], st["tail"]
    g = [[st["scl"] + (255,) for _ in range(GW)] for _ in range(GH)]
    def P(x, y, c):
        if 0 <= x < GW and 0 <= y < GH: g[y][x] = tuple(c) if len(c) == 4 else tuple(c) + (255,)
    shade = mix(st["scl"], (150, 150, 200), 0.35)
    ix0 = (GW - iw) // 2 + 1; ix1 = ix0 + iw - 1
    top = 1 + lid; bot = GH - 2 - (1 if st.get("lowlid") else 0)
    n = bot - top + 1
    for y in range(top, bot + 1):                              # iris: gradasi gelap (atas) -> warna karakter -> terang (bawah)
        t = (y - top) / max(1, n - 1)
        c = mix(st["top"], col, min(1.0, t * 1.5))
        if t > 0.7: c = mix(c, (255, 255, 255), st["glow"] * (t - 0.7) / 0.3 * 0.9)
        for x in range(ix0, ix1 + 1): P(x, y, c)
    for x in range(ix0, ix1 + 1):                              # bingkai iris tipis gelap di tepi kiri-kanan
        pass
    P(ix0, top, DARK); P(ix1, top, DARK)
    cx = (ix0 + ix1) // 2
    if st["pupil"] == "round":
        for y in range(top + 1, top + 4):
            for x in (cx, cx + 1): P(x, y, DARK)
    elif st["pupil"] == "slit":
        for y in range(top, bot):
            P(cx, y, DARK); P(cx + 1, y, DARK)
    # kilau
    if st["spark"] == "std":
        P(ix0 + 1, top + 1, WHITE); P(ix0 + 2, top + 1, WHITE); P(ix0 + 1, top + 2, WHITE)
        P(ix1 - 1, bot - 1, WHITE)
    elif st["spark"] == "star":                                # kilau bintang (plus) + titik
        sx, sy = ix0 + 2, top + 2
        for dx, dy in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)): P(sx + dx, sy + dy, WHITE)
        P(ix1 - 1, bot - 1, WHITE); P(ix1 - 2, bot - 2, mix(col, (255, 255, 255), 0.7))
    else:                                                      # lembut: dua kilau besar
        P(ix0 + 1, top + 1, WHITE); P(ix0 + 2, top + 1, WHITE); P(ix0 + 1, top + 2, WHITE); P(ix0 + 2, top + 2, WHITE)
        P(ix1 - 1, bot, mix(col, (255, 255, 255), 0.75)); P(ix1 - 2, bot, mix(col, (255, 255, 255), 0.5))
    for x in range(GW):                                        # kelopak atas tebal
        for y in range(0, 1 + lid): P(x, y, DARK)
        P(x, 1 + lid, shade) if not (ix0 <= x <= ix1) else None
    for i in range(tail):                                      # ekor bulu mata luar (kiri)
        P(i, 1 + lid, DARK); P(i, 2 + lid, DARK) if i < tail - 1 else None
    P(GW - 1, 1 + lid, DARK)
    if st.get("lowlid"):                                       # kelopak bawah gelap (mata tajam)
        for x in range(ix0 - 1, ix1 + 2): P(x, GH - 2, mix(DARK[:3], st["scl"], 0.1))
    for x in range(GW): P(x, GH - 1, shade)
    im = Image.new("RGBA", (GW, GH))
    for y in range(GH):
        for x in range(GW): im.putpixel((x, y), g[y][x])
    return im.resize((GW * S, GH * S), Image.NEAREST)

for k, st in STY.items():
    make(st).save(f"assets/hero/eyes/eye_{k}.png")
print("ok")
