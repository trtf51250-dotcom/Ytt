extends RefCounted
## Uji tombol Back Android + logika party + refresh gabungan. Dijalankan di lobi:
##   godot --path . scenes/lobby/lobby.tscn -- --bot=1 --botscript=back_party_bot --fresh
## Tombol Back disimulasikan seperti engine asli: NOTIFICATION_WM_GO_BACK_REQUEST dirambatkan ke seluruh pohon node.

var lobby: Node3D
var fails := 0


func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1


func _wait(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout


func _back() -> void:
	lobby.get_tree().root.propagate_notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)
	await _wait(0.25)


func run(l: Node3D) -> void:
	lobby = l
	await _wait(0.6)
	var gs := GameState
	var host: PanelHost = lobby.host

	# --- pengaturan engine
	check("quit_on_go_back dimatikan di project.godot", ProjectSettings.get_setting("application/config/quit_on_go_back") == false)
	check("SceneTree.quit_on_go_back = false", lobby.get_tree().is_quit_on_go_back() == false)
	check("aksi menu_back terdaftar", InputMap.has_action("menu_back"))

	# --- Back menutup panel (dan hanya sekali)
	host.open("party", {})
	await _wait(0.4)
	check("panel party terbuka", host.is_open() and host.current_id == "party")
	await _back()
	check("Back menutup panel party (game tidak keluar)", not host.is_open())

	# --- panel dengan return_to: satu Back = kembali ke panel asal, bukan tertutup dua kali
	host.open("character", {"return_to": "more", "return_args": {}})
	await _wait(0.4)
	await _back()
	check("Back dari panel ber-return_to kembali ke panel asal (tidak tertutup ganda)", host.is_open() and host.current_id == "more", host.current_id)
	await _back()
	check("Back kedua menutup panel asal", not host.is_open(), host.current_id)

	# --- tanpa panel: Back pertama hanya memunculkan peringatan, belum keluar
	Flow._back_last = -10.0
	await _back()
	check("Back tanpa panel: hanya peringatan (belum keluar)", Flow._back_last > 0.0 and lobby.get_tree() != null)
	Flow._back_last = -10.0

	# --- party: set slot yang sama = tidak memancarkan sinyal / tidak menyimpan
	for id in ["hakuya", "sera", "zeya", "lucien", "wenyu"]:
		gs.unlock_character(id)
	await _wait(0.2)
	var emitted := [0]
	var cb := func(kind: String):
		if kind == "party":
			emitted[0] += 1
	gs.changed.connect(cb)
	var first: String = gs.party[0]
	gs.set_party_slot(0, first)
	check("set_party_slot ke slot yang sama tidak memancarkan sinyal", emitted[0] == 0, str(emitted[0]))
	gs.set_party_slot(0, gs.party[1])          # tukar 0 <-> 1
	check("tukar slot memancarkan tepat satu sinyal", emitted[0] == 1, str(emitted[0]))
	gs.changed.disconnect(cb)
	check("party tetap <= 4 dan unik", gs.party.size() <= 4 and gs.party.size() == _uniq(gs.party).size(), str(gs.party))

	# --- muat save dengan party > 4: dipotong ke PARTY_SIZE
	var real_path: String = gs.save_path
	var real_party: Array = gs.party.duplicate()
	var real_roster: Dictionary = gs.roster.duplicate(true)
	var tmp := "user://bot_party_cap.json"
	gs.save_path = tmp
	var roster := {}
	var plist: Array = []
	for id in Data.character_ids().slice(0, 6):
		roster[id] = {"stars": 1, "shards": 0}
		plist.append(id)
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	f.store_string(JSON.stringify({"version": GameState.SAVE_VERSION, "id": gs.player_id, "name": "Uji", "level": 3, "roster": roster, "party": plist, "inventory": {}, "equipment": {}}))
	f.close()
	var ok_load: bool = gs.load_game()
	check("save dengan 6 anggota party dimuat", ok_load)
	check("party hasil muat dipotong ke %d" % gs.PARTY_SIZE, gs.party.size() == gs.PARTY_SIZE, str(gs.party))
	DirAccess.remove_absolute(ProjectSettings.globalize_path(tmp))
	gs.save_path = real_path
	gs.roster = real_roster
	gs.party = real_party

	# --- refresh gabungan: 3 sinyal dalam satu frame = 1 refresh
	host.open("party", {})
	await _wait(0.5)
	var pn: BasePanel = host.current
	var before: int = pn.queued_refresh_runs
	gs.changed.emit("roster")
	gs.changed.emit("party")
	gs.changed.emit("equipment")
	await lobby.get_tree().process_frame
	await lobby.get_tree().process_frame
	check("3 sinyal dalam satu frame = tepat 1 refresh", pn.queued_refresh_runs - before == 1, str(pn.queued_refresh_runs - before))

	# --- urutan roster deterministik di semua mode
	var det := true
	for mode in 3:
		pn.sort_mode = mode
		var a: Array = pn._sorted_ids()
		var b: Array = pn._sorted_ids()
		if a != b:
			det = false
	check("urutan roster deterministik (3 mode)", det)

	# --- tunggu studio potret tenang (potret selesai = refresh gabungan; tanpa ini uji di bawah bisa kebetulan terkena)
	var waited := 0.0
	while waited < 60.0 and Portraits._inst != null and (Portraits._inst._busy or not Portraits._inst._queue.is_empty()):
		await _wait(0.3)
		waited += 0.3
	await _wait(1.0)

	# --- ketuk slot: roster tidak dibangun ulang
	var roster_first: Node = pn._roster.get_child(0)
	pn.sel_slot = 1
	pn._refresh_slots()
	pn._refresh_bar()
	await lobby.get_tree().process_frame
	check("ganti slot terpilih tidak membangun ulang roster", is_instance_valid(roster_first) and not roster_first.is_queued_for_deletion())
	host.close()
	print("SUMMARY fails=", fails)


func _uniq(a: Array) -> Dictionary:
	var d := {}
	for x in a:
		d[x] = true
	return d
