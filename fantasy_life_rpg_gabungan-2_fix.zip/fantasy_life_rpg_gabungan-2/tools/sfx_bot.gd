extends RefCounted
## Uji logika Sfx: tebasan beruntun tidak dibuang/dipotong, suara bos tidak saling memotong, pool tidak melebihi batas.
## Jalankan: -- --bot=1 --botscript=sfx_bot --stage=s1_1 --fresh
var fails := 0


func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1


func _playing(arr: Array) -> int:
	var n := 0
	for p in arr:
		if (p as AudioStreamPlayer).playing:
			n += 1
	return n


func run(st: Node) -> void:
	var tree := st.get_tree()
	await tree.create_timer(0.5).timeout
	# 1) tiga tebasan cepat (jeda 0,1 dtk, seperti Assassin) -> semuanya diputar di pemutar berbeda
	st.set("autoplay", false)
	for k in Sfx._ded:                            # hening dulu supaya hasil tidak tercampur suara serangan otomatis
		for q in Sfx._ded[k]:
			q.stop()
	for q in Sfx._pool:
		q.stop()
	var sw: Array = Sfx._ded["swing"]
	# bingkai render di software lambat, jadi waktu dibuat deterministik: kosongkan penyaring jeda lalu panggil beruntun dalam 1 bingkai
	for i in 3:
		Sfx._last_play.clear()
		Sfx.play("swing")
	check("3 tebasan beruntun semua terdengar bersamaan", _playing(sw) == 3, "playing=%d" % _playing(sw))
	for q in sw:
		q.stop()
	# 2) badai 'hit' (AoE kena banyak musuh) tidak memotong tebasan
	Sfx._last_play.clear()
	Sfx.play("swing")
	var swing_pl: AudioStreamPlayer = null
	for q in sw:
		if (q as AudioStreamPlayer).playing:
			swing_pl = q
	for i in 40:
		Sfx._last_play.clear()
		Sfx.play("hit")
	check("tebasan tidak terpotong oleh badai hit", swing_pl != null and swing_pl.playing, "")
	check("jumlah pemutar hit tidak melebihi batas", _playing(Sfx._pool) <= Sfx.POOL_SIZE, "pool=%d" % _playing(Sfx._pool))
	# 2b) penyaring jeda: 2 'hit' dalam 1 bingkai -> hanya 1 yang diputar (cegah suara pecah)
	for q in Sfx._pool:
		q.stop()
	Sfx._last_play.clear()
	Sfx.play("hit")
	Sfx.play("hit")
	check("salinan hit di bingkai yang sama disaring", _playing(Sfx._pool) == 1, "pool=%d" % _playing(Sfx._pool))
	# 3) dua suara bos berurutan tidak saling memotong
	Sfx.play("boss_roar")
	await tree.create_timer(0.05).timeout
	Sfx.play("boss_growl")
	check("boss_roar + boss_growl dua-duanya jalan", _playing(Sfx._voice) == 2, "voice=%d" % _playing(Sfx._voice))
	# 4) semua suara termuat
	var missing := []
	for n in Sfx.SFX_NAMES:
		if not Sfx._sounds.has(n):
			missing.append(n)
	check("semua efek suara termuat", missing.is_empty(), str(missing))
	print("CHECK SUMMARY fails=", fails)
	tree.quit()
