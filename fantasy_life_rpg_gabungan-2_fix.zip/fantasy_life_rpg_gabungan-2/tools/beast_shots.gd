extends RefCounted
## Bot: ambil gambar bos Penguasa Gua pada beberapa momen (muncul, jalan, tiap jenis serangan, kena pukul, mati). Pemain tidak mati (god mode via HP besar).
var st: Node3D
func _w(s: float) -> void:
	await st.get_tree().create_timer(s).timeout
func run(s: Node3D) -> void:
	st = s
	var guard := 0.0
	while st.boss == null and guard < 40.0:
		await _w(0.3)
		guard += 0.3
		for e in st.get_tree().get_nodes_in_group("enemies"):
			if not e.is_boss and e.state != "spawn":
				e.take_damage(99999, st.player.global_position, 0.0)
	await _w(1.5)
	await st._shot("b_01_spawn")
	var b: Enemy = st.boss
	print("CHECK boss exists ", b != null, " kind=", b.kind if b else "")
	st.player.hit_radius = 0.0
	var seen := {}
	var t := 0.0
	var n := 0
	while t < 40.0 and n < 8 and not b.dead:
		await _w(0.12)
		t += 0.12
		var key: String = b.state + "_" + b._attack
		if b.state in ["windup", "strike"] and not seen.has(key):
			seen[key] = true
			n += 1
			await st._shot("b_%s" % key)
			print("shot state ", key, " anim=", b._rig.anim_player.current_animation, " spd=", b._rig.anim_player.speed_scale)
		# lawan tidak mati: pulihkan HP party
		for ps in st.party_state:
			ps["hp"] = ps["max"]
	print("states seen: ", seen.keys())
	# kena pukul + mati
	b.take_damage(1, st.player.global_position, 3.0)
	await _w(0.2)
	await st._shot("b_hit")
	b.take_damage(b.hp - 1, st.player.global_position, 3.0)
	b._phase = 1
	b.take_damage(b.max_hp / 2, st.player.global_position, 3.0)
	await _w(0.6)
	await st._shot("b_phase2")
	b.take_damage(b.hp + 10, st.player.global_position, 3.0)
	await _w(1.2)
	await st._shot("b_death")
	print("CHECK boss dead ", b.dead)
