extends RefCounted
## Uji cerita: validasi data, prolog otomatis di lobi (jeda game, ketuk lanjut, lewati, status "dibaca"), putar ulang dari panel Cerita.
## Jalankan dengan:  -- --bot=1 --story=1 --botscript=story_bot --shots=/dir --fresh
var lobby: Node3D
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1
func _sp() -> StoryPlayer:
	for c in lobby.get_tree().root.get_children():
		if c is StoryPlayer: return c
	return null
func run(l: Node3D) -> void:
	lobby = l
	var t := lobby.get_tree()
	# --- validasi data
	var ids := {}
	var ok_ids := true; var ok_stage := true; var ok_lines := true; var ok_spk := true; var combos := {}
	for sc in Story.scenes():
		if ids.has(sc["id"]): ok_ids = false
		ids[sc["id"]] = true
		if sc.has("stage"):
			if Data.stage(sc["stage"]) == null: ok_stage = false
			var k: String = "%s/%s" % [sc["stage"], sc["when"]]
			if combos.has(k) or not (sc["when"] in ["intro", "outro"]): ok_stage = false
			combos[k] = true
		if (sc["lines"] as Array).is_empty(): ok_lines = false
		for ln in sc["lines"]:
			if str(ln["t"]).strip_edges() == "" or str(ln["s"]) == "": ok_lines = false
			if not StoryPlayer.COLORS.has(ln["s"]): ok_spk = false
	check("id adegan unik (%d adegan)" % Story.scenes().size(), ok_ids)
	check("adegan stage merujuk stage yang ada, tiap intro/outro unik", ok_stage)
	check("tiap adegan berisi dialog tidak kosong", ok_lines)
	check("semua pembicara punya warna", ok_spk)
	check("for_stage(s3_boss,outro) ada", Story.for_stage("s3_boss", "outro") == "s3_boss_outro" and Story.for_stage("s1_2", "intro") == "s1_2_intro")
	check("cerita Bab 4-5 lengkap (intro tiap stage, intro/outro bos)", Story.for_stage("s4_1", "intro") != "" and Story.for_stage("s4_boss", "intro") != "" and Story.for_stage("s4_boss", "outro") != "" and Story.for_stage("s5_1", "intro") != "" and Story.for_stage("s5_boss", "intro") != "" and Story.for_stage("s5_boss", "outro") != "")
	# --- prolog otomatis
	await t.create_timer(1.0).timeout
	var sp := _sp()
	check("prolog otomatis tampil di lobi baru", sp != null and sp._scene["id"] == "prolog")
	check("game dijeda selama cerita", t.paused)
	await lobby._shot("story_1")
	var n: int = (sp._scene["lines"] as Array).size()
	sp.advance()   # selesaikan ketikan baris 1
	check("ketuk pertama menyelesaikan ketikan, belum lanjut", sp._i == 0 and not sp._typing)
	sp.advance()
	check("ketuk kedua lanjut ke baris 2", sp._i == 1)
	for i in 3: sp.advance()
	await t.create_timer(0.3).timeout
	await lobby._shot("story_2")
	sp._finish()
	await t.create_timer(0.3).timeout
	check("setelah selesai: game jalan lagi", not t.paused)
	check("prolog tertandai dibaca", Story.seen("prolog") and GameState.flags.get("story_prolog", false))
	check("panel cerita/pemutar sudah dibuang", _sp() == null)
	# --- tidak diputar ulang otomatis
	var before := t.paused
	await StoryPlayer.play(lobby, "prolog")
	check("sudah dibaca: tidak diputar lagi (tanpa force)", _sp() == null and t.paused == before)
	# --- baca sampai habis lewat advance (adegan lain)
	StoryPlayer.play(lobby, "s1_boss_intro", true)
	await t.create_timer(0.3).timeout
	sp = _sp()
	check("putar ulang paksa berjalan", sp != null and sp._scene["id"] == "s1_boss_intro")
	var guard := 0
	while _sp() != null and guard < 100:
		sp.advance(); guard += 1
		await t.create_timer(0.02).timeout
	check("adegan selesai sendiri setelah semua baris", _sp() == null and not t.paused, "ketukan=%d" % guard)
	# --- panel Cerita
	lobby.host.open("story")
	await t.create_timer(0.6).timeout
	await lobby._shot("story_panel")
	check("panel Cerita terbuka", lobby.host.current_id == "story")
	lobby.host.open("more")
	await t.create_timer(0.5).timeout
	await lobby._shot("story_menu")
	print("CHECK SUMMARY fails=", fails)
