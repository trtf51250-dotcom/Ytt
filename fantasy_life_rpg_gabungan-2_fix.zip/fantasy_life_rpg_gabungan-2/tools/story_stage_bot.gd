extends RefCounted
## Uji cerita di stage: intro menjeda sebelum gelombang, lalu stage berjalan; outro tampil setelah menang sebelum hasil.
## Jalankan: -- --bot=1 --story=1 --botscript=story_stage_bot --stage=s1_boss --shots=/dir --fresh
var st: Node3D
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1
func _sp() -> StoryPlayer:
	for c in st.get_tree().root.get_children():
		if c is StoryPlayer: return c
	return null
func _drain(t: SceneTree) -> int:
	var n := 0
	while _sp() != null and n < 100:
		_sp().advance(); n += 1
		await t.create_timer(0.03).timeout
	return n
func run(s: Node3D) -> void:
	st = s
	var t := st.get_tree()
	await t.create_timer(0.8).timeout
	var sp := _sp()
	var id: String = Story.for_stage(st.sd.id, "intro")
	check("intro tampil (%s)" % id, sp != null and sp._scene["id"] == id)
	check("stage dijeda selama intro", t.paused)
	var time0: float = st.time
	await t.create_timer(0.5).timeout
	check("waktu stage tidak jalan saat dijeda", is_equal_approx(st.time, time0))
	await st._shot("ss_intro")
	await _drain(t)
	check("intro selesai: tidak dijeda lagi", not t.paused and Story.seen(id))
	await t.create_timer(4.0).timeout
	check("stage berjalan setelah intro (waktu maju, ada musuh)", st.time > time0 + 1.0 and t.get_nodes_in_group("enemies").size() > 0, "t=%.1f musuh=%d" % [st.time, t.get_nodes_in_group("enemies").size()])
	# menang -> outro -> hasil
	var oid: String = Story.for_stage(st.sd.id, "outro")
	st._finish(true)
	await t.create_timer(2.6).timeout
	sp = _sp()
	check("outro tampil setelah menang (%s)" % oid, sp != null and sp._scene["id"] == oid)
	var has_result := false
	for c in st.ui.get_children():
		if c is StageResult: has_result = true
	check("hasil belum muncul sebelum outro selesai", not has_result)
	await st._shot("ss_outro")
	await _drain(t)
	await t.create_timer(0.6).timeout
	has_result = false
	for c in st.ui.get_children():
		if c is StageResult: has_result = true
	check("setelah outro: layar hasil muncul", has_result and not t.paused)
	await st._shot("ss_result")
	print("CHECK SUMMARY fails=", fails)
