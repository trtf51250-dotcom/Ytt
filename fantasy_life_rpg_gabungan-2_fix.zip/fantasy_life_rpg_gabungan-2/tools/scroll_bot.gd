extends RefCounted
## Uji gulir sentuh (TouchScroll): seret DI ATAS kartu menggulir daftar tanpa memilih kartu, ketukan singkat memilih kartu tanpa
## melompatkan daftar ke atas, inersia setelah dilepas, tombol di dalam daftar tidak aktif saat seretan. Memakai InputEventMouse
## (di Android jari lewat emulate_mouse_from_touch). Tidak menggantikan uji di perangkat sungguhan.
var lobby: Node3D
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1

func _mouse(pos: Vector2, pressed: bool, rel := Vector2.ZERO, motion := false) -> void:
	if motion:
		var m := InputEventMouseMotion.new()
		m.position = pos; m.global_position = pos; m.relative = rel
		m.button_mask = MOUSE_BUTTON_MASK_LEFT
		Input.parse_input_event(m)
	else:
		var b := InputEventMouseButton.new()
		b.button_index = MOUSE_BUTTON_LEFT
		b.pressed = pressed
		b.position = pos; b.global_position = pos
		b.button_mask = MOUSE_BUTTON_MASK_LEFT if pressed else 0
		Input.parse_input_event(b)

func _drag(from: Vector2, dy: float, steps: int, fps_wait := 0.016) -> void:
	var t := lobby.get_tree()
	_mouse(from, true)
	await t.process_frame
	var p := from
	for i in steps:
		var step := Vector2(0, dy / steps)
		p += step
		_mouse(p, false, step, true)
		await t.create_timer(fps_wait).timeout
	_mouse(p, false)

func _find_scroll(n: Node) -> TouchScroll:
	for c in n.find_children("*", "TouchScroll", true, false):
		var ts := c as TouchScroll
		if ts.is_visible_in_tree() and ts.get_v_scroll_bar().max_value - ts.get_v_scroll_bar().page > 40.0:
			return ts
	return null

func run(l: Node3D) -> void:
	lobby = l
	var t := lobby.get_tree()
	await t.create_timer(0.8).timeout
	GameState.gold = 99999
	# --- Toko
	lobby.host.open("shop")
	await t.create_timer(0.6).timeout
	var panel = lobby.host.current
	var sc := _find_scroll(panel)
	check("toko: ada daftar bergulir (TouchScroll) yang melebihi layar", sc != null)
	if sc == null:
		print("FAILS=", fails)
		return
	var r := sc.get_global_rect()
	var center := r.position + Vector2(r.size.x * 0.5, r.size.y * 0.5)
	var v0 := sc.scroll_vertical
	var sel0: String = panel.selected
	await _drag(center, -260.0, 10)
	var v1 := sc.scroll_vertical
	check("seret ke atas di atas kartu menggulir daftar turun", v1 > v0 + 120, "%d -> %d" % [v0, v1])
	check("seretan tidak memilih/mengaktifkan kartu", panel.selected == sel0, "terpilih=%s" % panel.selected)
	await t.create_timer(0.35).timeout
	check("inersia: daftar masih meluncur sesudah jari dilepas (cepat)", sc.scroll_vertical > v1 or sc.scroll_vertical == int(sc._max_scroll()), "%d -> %d" % [v1, sc.scroll_vertical])
	var v2 := sc.scroll_vertical
	await _drag(center, 300.0, 10)
	await t.create_timer(0.5).timeout
	check("seret ke bawah menggulir kembali ke atas", sc.scroll_vertical < v2 - 100, "%d -> %d" % [v2, sc.scroll_vertical])
	await lobby._shot("scroll_shop")
	# ketukan singkat memilih kartu & posisi gulir tidak melompat ke atas
	await _drag(center, -200.0, 8)
	await t.create_timer(1.2).timeout
	var vk := sc.scroll_vertical
	check("(persiapan) daftar tergulir ke bawah", vk > 60, str(vk))
	var tap_at := sc.get_global_rect().position + Vector2(160, 80)
	_mouse(tap_at, true)
	await t.process_frame
	_mouse(tap_at, false)
	await t.create_timer(0.5).timeout
	if panel.selected == sel0:                 # ketukan kebetulan mendarat di kartu yang sudah terpilih: ketuk kartu di bawahnya
		var tap2 := tap_at + Vector2(0, 110)
		_mouse(tap2, true)
		await t.process_frame
		_mouse(tap2, false)
		await t.create_timer(0.5).timeout
	check("ketukan singkat memilih kartu", panel.selected != "" and panel.selected != sel0 or sel0 == "" and panel.selected != "", "terpilih=%s" % panel.selected)
	check("posisi gulir tidak melompat ke atas setelah memilih", absi(sc.scroll_vertical - vk) <= 6, "%d -> %d" % [vk, sc.scroll_vertical])
	# tombol di dalam daftar: seretan di atas tombol tidak menekan
	var gold0: int = GameState.gold
	lobby.host.close()
	await t.create_timer(0.4).timeout
	# --- Karakter
	lobby.host.open("character")
	await t.create_timer(0.6).timeout
	var ch = lobby.host.current
	var sc2 := _find_scroll(ch)
	print("  karakter: daftar bergulir ", "ada" if sc2 != null else "tidak melebihi layar (tidak perlu digulir)")
	lobby.host.close()
	await t.create_timer(0.4).timeout
	# --- Quest
	lobby.host.open("quest")
	await t.create_timer(0.6).timeout
	var sc3 := _find_scroll(lobby.host.current)
	print("  quest: daftar bergulir ", "ada" if sc3 != null else "tidak melebihi layar")
	if sc3 != null:
		var rr := sc3.get_global_rect()
		var cc := rr.position + rr.size * 0.5
		var q0 := sc3.scroll_vertical
		await _drag(cc, -240.0, 10)
		check("quest: seret menggulir", sc3.scroll_vertical > q0 + 100, "%d -> %d" % [q0, sc3.scroll_vertical])
	lobby.host.close()
	check("gold tidak berubah oleh seretan (tidak ada pembelian nyasar)", GameState.gold == gold0, "%d -> %d" % [gold0, GameState.gold])
	print("CHECK SUMMARY fails=", fails)
