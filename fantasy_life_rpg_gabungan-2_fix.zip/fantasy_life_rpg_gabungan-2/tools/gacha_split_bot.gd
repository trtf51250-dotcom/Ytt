extends RefCounted
## Uji dua gacha terpisah (karakter vs perlengkapan): isi hasil, peluang, pity terpisah, banner hanya untuk gacha karakter, tab di panel.
var lobby: Node3D
var fails := 0
func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1
func _w(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout
func run(l: Node3D) -> void:
	lobby = l
	await _w(0.6)
	var gs := GameState
	gs.diamonds = 10000000
	# --- gacha item: 1500 tarikan
	var kinds := {}
	var rar := {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
	var bad3 := 0
	var n_item := 1500
	gs.pity_item = 0
	for i in n_item:
		var r: Dictionary = Gacha.pull(1, "", "item")[0]
		kinds[r["kind"]] = int(kinds.get(r["kind"], 0)) + 1
		rar[int(r["rarity"])] += 1
		if int(r["rarity"]) == 3 and Data.item(r["id"]).type == "potion":
			bad3 += 1
	check("gacha item: hanya memberi item (tanpa karakter/pecahan)", kinds.keys() == ["item"], str(kinds))
	check("gacha item: ★3 = perlengkapan (bukan ramuan)", bad3 == 0 and rar[3] > 0, "★3=%d" % rar[3])
	check("gacha item: ★5 ≈ 2% + pity (1-5%)", rar[5] >= n_item * 0.01 and rar[5] <= n_item * 0.05, "★5=%d/%d" % [rar[5], n_item])
	check("gacha item: ★1/★2 ≈ 30% (±6 poin)", absf(rar[1] / float(n_item) - 0.30) < 0.06 and absf(rar[2] / float(n_item) - 0.30) < 0.06, "★1=%d ★2=%d" % [rar[1], rar[2]])
	# --- gacha karakter: 1500 tarikan
	var kc := {}
	var chars := {}
	var rc := {3: 0, 4: 0, 5: 0, 6: 0}
	gs.pity = 0
	var ember_leak := false
	for i in n_item:
		var r2: Dictionary = Gacha.pull(1, "", "char")[0]
		kc[r2["kind"]] = int(kc.get(r2["kind"], 0)) + 1
		rc[int(r2["rarity"])] += 1
		chars[r2["id"]] = true
		if r2["id"] == "ember":
			ember_leak = true
	check("gacha karakter: hanya karakter / pecahan (tanpa item)", not kc.has("item") and (kc.has("character") or kc.has("shards")), str(kc))
	check("gacha karakter: tidak pernah memberi Ember (khusus event)", not ember_leak)
	check("gacha karakter: Hakuya ★6, Sera/Zeya/Lyra ★4, Ren/Brann ★3 bisa keluar", gs.is_unlocked("hakuya") and gs.is_unlocked("sera") and gs.is_unlocked("zeya") and gs.is_unlocked("lyra"))
	check("gacha karakter: ★5 (Vael/Lucien) ≈ 3,5% (2-6%)", rc[5] >= n_item * 0.02 and rc[5] <= n_item * 0.06, "★5=%d/%d" % [rc[5], n_item])
	check("gacha karakter: Vael & Lucien bisa didapat", gs.is_unlocked("vael") or gs.is_unlocked("lucien"))
	check("gacha karakter: ★6 ≈ 1.5% + pity (1-5%)", rc[6] >= n_item * 0.01 and rc[6] <= n_item * 0.05, "★6=%d/%d" % [rc[6], n_item])
	check("gacha karakter: ★3 ≈ 82% (±6 poin)", absf(rc[3] / float(n_item) - 0.82) < 0.06, "★3=%d" % rc[3])
	# --- pity terpisah
	gs.pity = 79
	gs.pity_item = 5
	var rr: Dictionary = Gacha.pull(1, "", "char")[0]
	check("pity karakter 79 -> ★6 & pity item tidak berubah", int(rr["rarity"]) == 6 and gs.pity == 0 and gs.pity_item == 5, "pity=%d item=%d" % [gs.pity, gs.pity_item])
	gs.pity = 7
	gs.pity_item = 49
	rr = Gacha.pull(1, "", "item")[0]
	check("pity item 49 -> ★5 & pity karakter tidak berubah", int(rr["rarity"]) == 5 and gs.pity_item == 0 and gs.pity == 7, "pity=%d item=%d" % [gs.pity, gs.pity_item])
	var d0 := gs.diamonds
	check("banner event tidak bisa dipakai di gacha item (tanpa potong diamond)", Gacha.pull(1, "ev_ember_fest", "item").is_empty() and gs.diamonds == d0)
	# --- panel: dua tab
	lobby.host.open("gacha")
	await _w(0.5)
	var panel = lobby.host.current
	check("panel: dua tab gacha", panel._pool_tabs.get_child_count() == 2 and panel._pool == "char")
	await lobby._shot("gacha_tab_char")
	panel._pool_tabs.get_child(1).emit_signal("pressed")
	await _w(0.4)
	check("tab item: pool item & peluang 5 baris", panel._pool == "item")
	await lobby._shot("gacha_tab_item")
	var p0: int = gs.pity_item
	panel._do(1)
	await _w(0.3)
	var rv: GachaReveal = panel._reveal
	check("tarik di tab item menghasilkan item", rv != null and rv.results.size() == 1 and rv.results[0]["kind"] == "item", str(rv.results if rv else ""))
	check("pity item bertambah / reset (bukan pity karakter)", gs.pity_item != p0 or int(rv.results[0]["rarity"]) == 5)
	rv._skip = true
	await _w(2.0)
	rv._btn_row.get_children()[0].emit_signal("pressed")
	await _w(0.3)
	panel._pool_tabs.get_child(0).emit_signal("pressed")
	await _w(0.4)
	check("kembali ke tab karakter", panel._pool == "char")
	panel._do(1)
	await _w(0.3)
	rv = panel._reveal
	check("tarik di tab karakter menghasilkan karakter/pecahan", rv != null and rv.results[0]["kind"] in ["character", "shards"], str(rv.results if rv else ""))
	rv._skip = true
	await _w(2.0)
	print("BOT DONE fails=", fails)
	lobby.get_tree().quit(fails)
