extends RefCounted
## Uji misi harian & pencapaian: pembuatan per tanggal, progres lewat event nyata, klaim, bonus, reset hari baru, simpan/muat.
var lobby: Node3D
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1
func run(l: Node3D) -> void:
	lobby = l
	await lobby.get_tree().create_timer(0.6).timeout
	var gs := GameState
	gs._fake_date = "2026-11-04"
	gs.daily_refresh()
	var ms: Array = gs.daily["m"]
	check("3 misi dibuat", ms.size() == 3, str(ms))
	check("deterministik per tanggal", Missions.daily_for("2026-11-04") == Missions.daily_for("2026-11-04"))
	var diff := false
	for d in ["2026-11-05", "2026-11-06", "2026-11-07", "2026-11-08", "2026-11-09"]:
		if Missions.daily_for(d) != Missions.daily_for("2026-11-04"): diff = true
	check("tanggal lain bisa beda misi", diff)
	check("klaim sebelum selesai ditolak", not gs.daily_claim(0))
	# selesaikan lewat event nyata
	var need0: int = ms[0]["need"]
	gs.report_event("kill", "slime", need0)
	var g0 := gs.gold; var d0 := gs.diamonds
	check("misi kill selesai & bisa klaim", gs.daily_claim(0) and gs.gold == g0 + Missions.DAILY_GOLD and gs.diamonds == d0 + Missions.DAILY_DIAMOND)
	check("klaim dua kali ditolak", not gs.daily_claim(0))
	check("progres tidak lewat target", int(ms[0]["p"]) == need0)
	gs.report_event("clear_stage", "s1_1", int(ms[1]["need"]))
	check("klaim misi 2", gs.daily_claim(1))
	check("bonus belum bisa", not gs.daily_bonus_claim())
	match ms[2]["kind"]:
		"summon": gs.report_event("summon", "", 1)
		"upgrade": gs.report_event("upgrade", "", 1)
		"spend": gs.gold = 5000; gs.spend_gold(int(ms[2]["need"]))
	check("misi 3 (%s) bisa klaim" % ms[2]["kind"], gs.daily_claim(2))
	var dia := gs.diamonds
	check("bonus bisa & memberi diamond", gs.daily_bonus_claim() and gs.diamonds == dia + Missions.BONUS_DIAMOND)
	check("bonus dua kali ditolak", not gs.daily_bonus_claim())
	check("badge siap = 0", gs.daily_ready_count() == 0)
	# hari baru -> reset
	gs._fake_date = "2026-11-05"
	gs.daily_refresh()
	check("hari baru: misi di-reset", gs.daily["date"] == "2026-11-05" and not gs.daily["bonus"] and int(gs.daily["m"][0]["p"]) == 0)
	# pencapaian
	var a: Dictionary = Missions.ACH[0]
	gs.stats["kills"] = int(a["need"]) - 1
	check("pencapaian belum siap", gs.ach_state(a) == "active" and not gs.ach_claim(a["id"]))
	gs.stats["kills"] = int(a["need"])
	var dia2 := gs.diamonds
	check("pencapaian siap -> klaim", gs.ach_state(a) == "ready" and gs.ach_claim(a["id"]) and gs.diamonds == dia2 + int(a["dia"]))
	check("pencapaian tidak bisa dua kali", not gs.ach_claim(a["id"]) and gs.ach_state(a) == "claimed")
	# panel UI
	lobby.host.open("daily")
	await lobby.get_tree().create_timer(0.6).timeout
	await lobby._shot("p_daily")
	check("panel terbuka", lobby.host.current_id == "daily")
	lobby.host.current._tab = 1
	lobby.host.current.refresh()
	await lobby.get_tree().create_timer(0.4).timeout
	await lobby._shot("p_ach")
	print("CHECK SUMMARY fails=", fails)
