extends RefCounted
## Bangunan padat (tidak tembus pandang) dan tidak bisa ditembus pemain; tiap rumah punya penghuni di depan pintunya yang bisa diajak bicara.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func run(lb: Node3D) -> void:
	var t := lb.get_tree()
	await t.create_timer(1.5).timeout
	var faded := 0
	for x in lb.world.buildings:
		if x.can_fade or x.get("_target") != null and float(x._target) < 0.99:
			faded += 1
	check("tidak ada bangunan yang bisa tembus pandang", faded == 0, "n=%d" % faded)
	# pemain berjalan ke dinding rumah: tidak boleh menembus
	var h: Building = null
	for x in lb.world.buildings:
		if str(x.kind).begins_with("house_"):
			h = x
			break
	check("ada rumah", h != null)
	var box: AABB = h.world_aabb
	var fwd := Vector3(sin(h.rotation.y), 0, cos(h.rotation.y))
	var c := box.get_center()
	var half := absf(fwd.x) * box.size.x * 0.5 + absf(fwd.z) * box.size.z * 0.5
	# dinding rumah padat: sinar dari depan rumah ke pusatnya harus mengenai penghalang sebelum sampai di tengah
	var from := Vector3(c.x, 1.0, c.z) + fwd * (half + 3.0)
	var to_p := Vector3(c.x, 1.0, c.z)
	var q := PhysicsRayQueryParameters3D.create(from, to_p, 0xFFFFFFFF)
	var hit: Dictionary = lb.get_world_3d().direct_space_state.intersect_ray(q)
	check("rumah punya tabrakan (tidak bisa ditembus)", not hit.is_empty() and (hit["position"] as Vector3).distance_to(to_p) > 0.5, str(hit.get("position", "tak kena")))
	# penghuni
	var homes := 0
	var near_door := 0
	for v in lb.villagers:
		if v._def.get("home", false):
			homes += 1
			for b in lb.world.buildings:
				if str(b.kind).begins_with("house_") and v.global_position.distance_to(b.world_aabb.get_center()) < 14.0:
					near_door += 1
					break
	check("ada penghuni rumah", homes >= 3, "n=%d" % homes)
	check("penghuni berada di dekat rumahnya", near_door == homes, "%d/%d" % [near_door, homes])
	var hv: Villager = null
	for v in lb.villagers:
		if v._def.get("home", false):
			hv = v
			break
	var d: Dictionary = hv.dialogue()
	check("dialog penghuni menyapa soal rumah", d["start"]["lines"][0].contains("rumah"), d["start"]["lines"][0])
	print("CHECK SUMMARY fails=", fails)
	t.quit()
