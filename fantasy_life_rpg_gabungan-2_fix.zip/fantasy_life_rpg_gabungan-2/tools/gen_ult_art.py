#!/usr/bin/env python3
"""Membuat tekstur efek ULTI orisinal (lingkaran sihir & berkas cahaya) -> assets/fx/. Putih bercahaya di atas transparan; diwarnai lewat material di game."""
import math, random
from PIL import Image, ImageDraw, ImageFilter

S = 512
C = S / 2.0
random.seed(7)

def glow(layer, blur=(2, 6, 14), strengths=(1.0, 0.8, 0.55)):
    out = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    for b, k in zip(blur, strengths):
        g = layer.filter(ImageFilter.GaussianBlur(b))
        a = g.getchannel("A").point(lambda v: min(255, int(v * k * 1.6)))
        g.putalpha(a)
        out = Image.alpha_composite(out, g)
    return Image.alpha_composite(out, layer)

def ring(d, r, w, fill=(255, 255, 255, 255)):
    d.ellipse([C - r, C - r, C + r, C + r], outline=fill, width=w)

def poly(d, n, r, rot=0.0, w=3, step=1):
    pts = [(C + r * math.cos(rot + 2 * math.pi * i / n), C + r * math.sin(rot + 2 * math.pi * i / n)) for i in range(n)]
    for i in range(n):
        d.line([pts[i], pts[(i + step) % n]], fill=(255, 255, 255, 255), width=w)

def ticks(d, r0, r1, n, w=2, rot=0.0):
    for i in range(n):
        a = rot + 2 * math.pi * i / n
        d.line([(C + r0 * math.cos(a), C + r0 * math.sin(a)), (C + r1 * math.cos(a), C + r1 * math.sin(a))], fill=(255, 255, 255, 255), width=w)

def runes(d, r, n, size):
    for i in range(n):
        a = 2 * math.pi * i / n
        cx, cy = C + r * math.cos(a), C + r * math.sin(a)
        for _ in range(random.randint(2, 4)):
            ang = a + random.uniform(-1.4, 1.4)
            L = size * random.uniform(0.5, 1.0)
            x0, y0 = cx + random.uniform(-size, size) * 0.4, cy + random.uniform(-size, size) * 0.4
            d.line([(x0, y0), (x0 + L * math.cos(ang), y0 + L * math.sin(ang))], fill=(255, 255, 255, 255), width=2)

# ---- A: cincin berlapis + bintang segi-6 + rune
a = Image.new("RGBA", (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(a)
ring(d, 238, 4); ring(d, 226, 2); ring(d, 196, 3); ring(d, 150, 3); ring(d, 96, 3); ring(d, 40, 3)
ticks(d, 200, 224, 72, 2); ticks(d, 154, 192, 24, 2, 0.1)
runes(d, 211, 36, 12)
poly(d, 6, 150, -math.pi / 2, 3, 2); poly(d, 6, 150, math.pi / 2 * 0 + math.pi / 6, 3, 2)
poly(d, 3, 96, -math.pi / 2, 3); poly(d, 3, 96, math.pi / 2, 3)
poly(d, 8, 40, 0, 2, 3)
glow(a).save("assets/fx/sigil_a.png")

# ---- B: bunga 6 kelopak + 4 lingkaran satelit + cincin teks
b = Image.new("RGBA", (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(b)
ring(d, 232, 3); ring(d, 214, 2); ring(d, 132, 3)
runes(d, 223, 44, 11)
for i in range(6):
    ang = math.pi / 3 * i
    for k in (1.0, 0.7):
        tipx, tipy = C + 126 * k * math.cos(ang), C + 126 * k * math.sin(ang)
        for s in (-1, 1):
            mx, my = C + 70 * k * math.cos(ang + s * 0.42), C + 70 * k * math.sin(ang + s * 0.42)
            d.line([(C, C), (mx, my), (tipx, tipy)], fill=(255, 255, 255, 255), width=3)
ring(d, 22, 3); ring(d, 52, 2)
for sx, sy in ((92, 92), (S - 92, 92), (92, S - 92), (S - 92, S - 92)):
    for r in (60, 48, 26):
        d.ellipse([sx - r, sy - r, sx + r, sy + r], outline=(255, 255, 255, 255), width=2)
    for i in range(10):
        an = 2 * math.pi * i / 10
        d.line([(sx + 26 * math.cos(an), sy + 26 * math.sin(an)), (sx + 56 * math.cos(an + 0.5), sy + 56 * math.sin(an + 0.5))], fill=(255, 255, 255, 255), width=2)
glow(b).save("assets/fx/sigil_b.png")

# ---- C: berkas cahaya vertikal (putih di tengah, lembut ke sisi), dan silang
c = Image.new("RGBA", (64, 256), (0, 0, 0, 0))
px = c.load()
for y in range(256):
    for x in range(64):
        dx = abs(x - 31.5) / 32.0
        core = max(0.0, 1.0 - dx * 6.0)
        soft = max(0.0, 1.0 - dx) ** 2.2
        fade = min(1.0, y / 28.0) * 1.0
        v = min(1.0, core + soft * 0.65) * fade
        px[x, y] = (255, 255, 255, int(255 * v))
c.save("assets/fx/beam.png")
# ---- D: kilau bintang 4 titik (untuk ujung pilar / benturan)
f = Image.new("RGBA", (256, 256), (0, 0, 0, 0)); px = f.load()
for y in range(256):
    for x in range(256):
        dx, dy = (x - 127.5) / 127.5, (y - 127.5) / 127.5
        r = math.hypot(dx, dy)
        spike = max(math.exp(-abs(dx) * 38.0) * max(0.0, 1.0 - abs(dy)) ** 1.5, math.exp(-abs(dy) * 38.0) * max(0.0, 1.0 - abs(dx)) ** 1.5)
        core = math.exp(-r * r * 22.0)
        v = min(1.0, spike * 0.95 + core)
        px[x, y] = (255, 255, 255, int(255 * v))
f.save("assets/fx/flare.png")

# ---- nota musik (putih bercahaya, 128x128): note_a = not 1/8 (♪), note_b = dua not bersambung (♫), note_c = not 1/4 (♩), clef = kunci G sederhana
def note_img(kind):
    n = 128
    im = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    def head(cx, cy):
        d.ellipse([cx - 15, cy - 11, cx + 15, cy + 11], fill=(255, 255, 255, 255))
    if kind == "a":
        head(46, 96); d.rectangle([58, 20, 63, 94], fill=(255, 255, 255, 255))
        d.polygon([(63, 20), (96, 40), (98, 62), (86, 78), (90, 52), (63, 40)], fill=(255, 255, 255, 255))
    elif kind == "c":
        head(52, 96); d.rectangle([64, 18, 69, 94], fill=(255, 255, 255, 255))
    elif kind == "b":
        head(30, 98); head(84, 86)
        d.rectangle([42, 26, 47, 96], fill=(255, 255, 255, 255)); d.rectangle([96, 14, 101, 84], fill=(255, 255, 255, 255))
        d.polygon([(42, 26), (101, 12), (101, 30), (42, 44)], fill=(255, 255, 255, 255))
    else:
        pts = []
        for i in range(0, 200):
            t = i / 199.0
            a = t * 5.4 - 0.4
            r = 6 + 34 * (0.35 + 0.65 * math.sin(min(1.0, t * 1.15) * math.pi))
            pts.append((64 + r * 0.6 * math.cos(a * 1.3 + 1.2) , 108 - t * 92 + 8 * math.sin(a * 2.0)))
        d.line(pts, fill=(255, 255, 255, 255), width=7)
        d.ellipse([56, 100, 74, 118], fill=(255, 255, 255, 255))
    return glow(im, (1, 3, 7), (1.0, 0.8, 0.5))
for k in "abc":
    note_img(k).save(f"assets/fx/note_{k}.png")
note_img("x").save("assets/fx/clef.png")
print("ok")
