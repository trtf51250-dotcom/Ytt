extends RefCounted
## Memotret tiap fase animasi serang & skill semua kelas senjata (kamera samping, waktu diperlambat) + mengukur
## waktu sinyal `swing` (damage) terhadap waktu impak animasi. Hasil: lembar PNG per karakter di --shots.
var lobby: Node3D
var fails := 0
var swing_times: Array = []
func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1
func _w(s: float) -> void:
	await lobby.get_tree().create_timer(s, true, false, true).timeout
func run(l: Node3D) -> void:
	lobby = l
	await _w(0.5)
	var pl: Player = lobby.player
	var t0 := [0.0]
	pl.swing.connect(func(kind, _o, _d): swing_times.append([kind, t0[0]]))
	for cid in ["ren", "zeya", "lyra", "brann", "sera"]:
		GameState.unlock_character(cid)
		GameState.set_party_slot(0, cid)
		await _w(0.8)
		lobby.cam.distance = 4.2
		lobby.cam.pitch = deg_to_rad(12.0)
		lobby.cam.yaw = PI * 0.5
		await _w(0.8)
		for act in (["attack", "attack2", "attack3", "skill"] if cid == "zeya" else ["attack", "attack2", "skill"]):
			pl._act_t = 0.0
			pl.attack_cd = 0.0
			pl.skill_cd = 0.0
			pl.dead = false
			var an := "attack1" if act == "attack" else ("attack2" if act == "attack2" else ("attack3" if act == "attack3" else "skill"))
			var len := pl.rig.action_length(an)
			var imp := pl.rig.action_impact(an)
			var imgs: Array = []
			swing_times.clear()
			Engine.time_scale = 0.12
			t0[0] = 0.0
			if act == "skill":
				pl.do_skill()
			else:
				pl._combo = 0 if act == "attack" else (1 if act == "attack2" else 2)
				pl.do_attack()
			var elapsed := 0.0
			var marks := [0.04, 0.17, imp * 0.8, imp + 0.02, imp + 0.12, len * 0.75, len * 0.95]
			var mi := 0
			while elapsed < len + 0.05:
				await lobby.get_tree().process_frame
				elapsed += lobby.get_process_delta_time()
				t0[0] = elapsed
				if mi < marks.size() and elapsed >= marks[mi]:
					imgs.append(lobby.get_viewport().get_texture().get_image())
					mi += 1
			Engine.time_scale = 1.0
			var kind := "skill" if act == "skill" else "attack"
			var got := -1.0
			for s in swing_times:
				if s[0] == kind:
					got = s[1]
			check("%s %s: damage jatuh di waktu impak" % [cid, act], got >= 0.0 and absf(got - imp) < 0.08, "damage t=%.2f impak=%.2f panjang=%.2f" % [got, imp, len])
			# lembar kontak
			var w := 360
			var h := 280
			var sheet := Image.create(w * 4, h * 2, false, Image.FORMAT_RGBA8)
			for i in imgs.size():
				var im: Image = imgs[i]
				var cx := (im.get_width() - 560) / 2
				var r := im.get_region(Rect2i(cx, 90, 560, 440))
				r.convert(Image.FORMAT_RGBA8)
				r.resize(w, h, Image.INTERPOLATE_BILINEAR)
				sheet.blit_rect(r, Rect2i(0, 0, w, h), Vector2i((i % 4) * w, (i / 4) * h))
			sheet.save_png("%s/atk_%s_%s.png" % [lobby._arg("shots", "/tmp"), cid, act])
			await _w(0.9)
	print("BOT DONE fails=", fails)
	lobby.get_tree().quit(fails)
