#!/usr/bin/env bash
# Paket uji regresi: jalankan semua bot dan cetak ringkasan LULUS/GAGAL. Pemakaian: GODOT=/path/godot tools/run_all.sh
# Butuh xvfb-run bila tanpa layar. Tiap bot memakai --fresh (tidak menulis save), kecuali save_test yang menulis lalu membersihkan user://.
set -u
G="${GODOT:-godot}"
cd "$(dirname "$0")/.."
OUT="${TMPDIR:-/tmp}/fl_run_all"; mkdir -p "$OUT"
X=""; command -v xvfb-run >/dev/null && X="xvfb-run -a -s '-screen 0 1280x720x24'"
fails=0
run() {  # nama  perintah...
  local name="$1"; shift
  local log="$OUT/$name.log"
  if timeout 600 bash -c "$*" >"$log" 2>&1 && ! grep -qE "CHECK FAIL|SCRIPT ERROR|Parse Error|HASIL: GAGAL" "$log" && grep -qE "SUMMARY fails=0|HASIL: LULUS|CHECK PASS" "$log"; then
    echo "LULUS  $name"
  else
    echo "GAGAL  $name  (lihat $log)"; fails=$((fails+1))
  fi
}
$G --headless --path . --import >/dev/null 2>&1
run data      "$G --headless --path . res://tools/test_data.tscn"
run unit      "$G --headless --path . res://tools/unit_test.tscn"
run save      "$G --headless --path . res://tools/save_test.tscn"
run perf      "$G --headless --path . res://tools/perf_test.tscn"
GL="$X $G --path . --rendering-driver opengl3 --audio-driver Dummy"
run judul     "$GL res://tools/title_bot.tscn -- --shots=$OUT"
run oklusi "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=occlusion_bot --fresh"
run gerak "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=gerak_bot --stage=s1_1 --fresh"
run layar_muat "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=flow_bot --fresh"
run eksplorasi "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=explore_bot --shots=$OUT --fresh"
run peti_stage "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=stage_chest_bot --stage=s1_1 --fresh"
run wilayah_padang "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=field_bot --stage=f_plains --fresh"
run wilayah_hutan "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=field_bot --stage=f_forest --fresh"
run wilayah_gua "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=field_bot --stage=f_cave --fresh"
run biaya_model "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=looks_cost_bot --stage=s1_1 --fresh"
run profil    "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=profile_bot --shots=$OUT --fresh"
run misi      "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=daily_bot --shots=$OUT --fresh"
run menu      "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=menu_bot --shots=$OUT --fresh"
run panel     "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=panel_bot --shots=$OUT --fresh"
run stage_1_1 "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=stage_bot --stage=s1_1 --shots=$OUT --speed=3 --fresh"
run peta_s1_1 "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=map_bot --stage=s1_1 --speed=2 --fresh"
run cerita_lobi "$GL scenes/lobby/lobby.tscn -- --bot=1 --story=1 --botscript=story_bot --shots=$OUT --fresh"
run cerita_stage "$GL scenes/stages/stage.tscn -- --bot=1 --story=1 --botscript=story_stage_bot --stage=s1_boss --shots=$OUT --fresh"
run efek      "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=fx_bot --stage=s1_1 --shots=$OUT --fresh"
run gaya_serang "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=combat_bot --stage=s1_1 --shots=$OUT --fresh"
run audit_serang "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=serang_bot --stage=s1_1 --shots=$OUT --fresh"
run arah_tebasan "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=fx_dir_bot --stage=s1_1 --shots=$OUT --fresh"
run pose "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=pose_bot --shots=$OUT --fresh"
run ult "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=ult_bot --stage=s1_1 --shots=$OUT --fresh"
run efek_karakter "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=charfx_bot --stage=s1_1 --shots=$OUT --fresh"
run gacha_dua  "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=gacha_split_bot --shots=$OUT --fresh"
run scroll "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=scroll_bot --shots=$OUT --fresh"
run party "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=party_bot --shots=$OUT --fresh"
run gacha_event "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=event_bot --shots=$OUT --fresh"
run bos_wither "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=wither_shots --stage=s3_boss --shots=$OUT --fresh"
run musuh_humanoid "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=humanoid_bot --stage=s4_1 --shots=$OUT --fresh"
run bos_uranos "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=humanoid_boss_bot --stage=s4_boss --shots=$OUT --fresh"
run bos_rantai "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=humanoid_boss_bot --stage=s5_boss --shots=$OUT --fresh"
run langit "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=sky_bot --shots=$OUT --fresh"
run pengaturan "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=settings_bot --shots=$OUT --fresh"
run back_party "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=back_party_bot --fresh"
run back_stage "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=back_stage_bot --stage=s1_1 --fresh"
run musuh_macet "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=stuck_bot --stage=s2_1 --orbit=0.7 --speed=4 --fresh"
run sfx "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=sfx_bot --stage=s1_1 --fresh"
run adventure_alur "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=adventure_flow_bot --shots=$OUT --fresh"
run wilayah_target "$GL scenes/stages/stage.tscn -- --bot=1 --botscript=field_goal_bot --stage=f_cave --fresh"
run warga_bicara "$GL scenes/lobby/lobby.tscn -- --bot=1 --botscript=villager_talk_bot --fresh"
echo "Selesai. Gagal: $fails"
exit $fails
