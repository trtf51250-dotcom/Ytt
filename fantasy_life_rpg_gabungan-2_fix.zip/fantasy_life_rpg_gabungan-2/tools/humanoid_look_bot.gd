extends RefCounted
## Bot: potret dekat semua musuh humanoid (kroco + bos) untuk memeriksa tampilan. Musuh dibekukan setelah muncul.
var st: Node3D
func _w(s: float) -> void:
	await st.get_tree().create_timer(s).timeout
func run(s: Node3D) -> void:
	st = s
	await _w(0.8)
	for e in st.get_tree().get_nodes_in_group("enemies"):
		e.queue_free()
	st._pending = 0
	st.state = 2 if false else st.state
	var base: Vector3 = st.player.global_position
	var i := 0
	for kind in ["cultist", "shadow_mage", "chain_knight", "ronin", "uranos", "chain_king"]:
		var e: Enemy = st._spawn_enemy(kind, base + Vector3(0, 0, -5.0))
		await _w(1.0)
		e.set_physics_process(false)
		e.global_position = base + Vector3(0, 0.05, -5.0)
		e.rotation.y = PI          # menghadap kamera (kamera di +Z)
		st.cam.focus_node = e
		st.cam.focus_bias = 0.0
		st.cam.focus_lift = 1.2 if not e.is_boss else 1.6
		create_tween_distance(8.0 if not e.is_boss else 11.0)
		await _w(1.6)
		await st._shot("look_%s" % kind)
		e.queue_free()
		i += 1
	print("CHECK PASS potret selesai")
func create_tween_distance(d: float) -> void:
	st.cam.distance = d
