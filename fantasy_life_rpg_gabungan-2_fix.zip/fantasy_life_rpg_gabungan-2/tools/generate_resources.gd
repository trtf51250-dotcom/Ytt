extends SceneTree
## Membuat semua file .tres di res://resources/ (karakter, item, quest, stage).
## Jalankan dari folder proyek:
##   godot --headless --path . --script tools/generate_resources.gd
## Ubah angka/teks di sini lalu jalankan ulang, atau edit file .tres langsung di editor.

const OUT := "res://resources"


func _init() -> void:
	_characters()
	_items()
	_quests()
	_stages()
	print("generate_resources: selesai")
	quit()


func _save(res: Resource, folder: String, id: String) -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("%s/%s" % [OUT, folder]))
	var path := "%s/%s/%s.tres" % [OUT, folder, id]
	var err := ResourceSaver.save(res, path)
	if err != OK:
		push_error("Gagal menyimpan %s (%d)" % [path, err])


# ------------------------------------------------------------------ karakter
func _char(d: Dictionary) -> void:
	var c := CharacterData.new()
	for k in d:
		c.set(k, d[k])
	_save(c, "characters", c.id)


func _characters() -> void:
	_char({
		"id": "ren", "display_name": "Ren", "title": "Penjaga Fajar Beku", "role": "Swordsman",
		"weapon_class": "sword", "skin_path": "res://assets/hero/skin_ren.png",
		"accent": Color(0.55, 0.8, 1.0), "unlocked_at_start": true,
		"description": "Pemuda berambut putih-biru dari Aurelia. Ahli pedang yang lincah dan seimbang.",
		"base_hp": 120, "base_atk": 12, "base_def": 5, "move_speed": 5.8,
		"hp_growth": 15.0, "atk_growth": 2.2, "def_growth": 0.9,
		"attack_kind": "arc", "attack_range": 2.7, "attack_cooldown": 0.55, "attack_mult": 1.1, "combo_hits": 2, "combo_recovery": 0.15,
		"skill_name": "Tebasan Fajar", "skill_kind": "cone", "skill_cooldown": 6.0, "skill_mult": 2.6, "skill_range": 4.6,
	})
	_char({
		"id": "lyra", "display_name": "Lyra", "title": "Penyihir Bintang", "role": "Mage",
		"weapon_class": "staff", "skin_path": "res://assets/hero/skin_lyra.png",
		"accent": Color(0.78, 0.5, 1.0), "unlocked_at_start": true,
		"description": "Murid Menara Bintang. Menembakkan bola sihir dari jauh dan meledakkan area dengan Nova.",
		"base_hp": 90, "base_atk": 15, "base_def": 3, "move_speed": 5.4,
		"hp_growth": 11.0, "atk_growth": 2.6, "def_growth": 0.5,
		"attack_kind": "bolt", "attack_range": 9.0, "attack_cooldown": 0.6, "attack_mult": 0.95,
		"skill_name": "Nova Bintang", "skill_kind": "nova", "skill_cooldown": 7.0, "skill_mult": 2.3, "skill_range": 5.2,
	})
	_char({
		"id": "brann", "display_name": "Brann", "title": "Perisai Hutan Besi", "role": "Guardian",
		"weapon_class": "guard", "skin_path": "res://assets/hero/skin_brann.png",
		"accent": Color(1.0, 0.6, 0.3), "unlocked_at_start": true,
		"description": "Prajurit bertubuh kekar yang menahan serangan. Lambat, tapi pukulannya menghantam area lebar.",
		"base_hp": 175, "base_atk": 9, "base_def": 9, "move_speed": 5.0,
		"hp_growth": 22.0, "atk_growth": 1.6, "def_growth": 1.5,
		"attack_kind": "smash", "attack_range": 2.5, "attack_cooldown": 0.7, "attack_mult": 1.55,
		"skill_name": "Guncangan Bumi", "skill_kind": "shockwave", "skill_cooldown": 8.0, "skill_mult": 2.0, "skill_range": 5.5,
	})
	_char({
		"id": "sera", "display_name": "Sera", "title": "Pemanah Dedaunan", "role": "Ranger",
		"weapon_class": "bow", "skin_path": "res://assets/hero/skin_sera.png",
		"accent": Color(0.55, 0.9, 0.5), "unlocked_at_start": false,
		"description": "Pemanah gesit dari hutan Aurelia. Menembak cepat dari jauh dan menghujani musuh dengan panah.",
		"base_hp": 100, "base_atk": 13, "base_def": 4, "move_speed": 6.0,
		"hp_growth": 12.5, "atk_growth": 2.3, "def_growth": 0.7,
		"attack_kind": "arrow", "attack_range": 11.0, "attack_cooldown": 0.5, "attack_mult": 0.88,
		"skill_name": "Hujan Panah", "skill_kind": "volley", "skill_cooldown": 7.0, "skill_mult": 2.4, "skill_range": 8.0,
	})


# ------------------------------------------------------------------ item
func _item(id: String, nm: String, desc: String, type: String, rarity: int, cls: String, atk: int, df: int,
		hp: int, heal: int, price: int, shop: String, gacha: bool, col: Color) -> void:
	var it := ItemData.new()
	it.id = id
	it.display_name = nm
	it.description = desc
	it.type = type
	it.rarity = rarity
	it.weapon_class = cls
	it.atk = atk
	it.def = df
	it.hp = hp
	it.heal = heal
	it.buy_price = price
	it.shop = shop
	it.in_gacha = gacha
	it.color = col
	_save(it, "items", id)


func _items() -> void:
	var steel := Color(0.78, 0.82, 0.9)
	var gold := Color(1.0, 0.8, 0.3)
	var ice := Color(0.6, 0.85, 1.0)
	var vio := Color(0.75, 0.55, 1.0)
	var grn := Color(0.5, 0.9, 0.5)
	var red := Color(1.0, 0.5, 0.4)
	# --- pedang (Ren)
	_item("w_sword_train", "Pedang Latihan", "Pedang kayu berlapis besi untuk pemula.", "weapon", 1, "sword", 8, 0, 0, 0, 0, "", false, steel)
	_item("w_sword_steel", "Pedang Baja", "Pedang baja tempaan pandai besi Aurelia.", "weapon", 2, "sword", 16, 0, 0, 0, 400, "weapon", false, steel)
	_item("w_sword_dew", "Bilah Embun", "Bilahnya selalu dingin berembun, seringan bulu.", "weapon", 3, "sword", 27, 0, 0, 0, 1300, "weapon", false, ice)
	_item("w_sword_frost", "Bilah Fajar Beku", "Dilapisi kristal es yang berpendar saat fajar.", "weapon", 4, "sword", 41, 0, 10, 0, 0, "", true, ice)
	_item("w_sword_aurora", "Aurora Sang Penjaga", "Pedang legenda penjaga Aurelia. Bersinar tujuh warna.", "weapon", 5, "sword", 60, 0, 30, 0, 0, "", true, gold)
	# --- tongkat (Lyra)
	_item("w_staff_oak", "Tongkat Ek", "Tongkat pemula dari kayu ek tua.", "weapon", 1, "staff", 9, 0, 0, 0, 0, "", false, grn)
	_item("w_staff_amber", "Tongkat Ambar", "Getah ambar di ujungnya menyimpan sihir kecil.", "weapon", 2, "staff", 17, 0, 0, 0, 400, "weapon", false, gold)
	_item("w_staff_crystal", "Tongkat Kristal", "Kristal biru menguatkan setiap mantra.", "weapon", 3, "staff", 29, 0, 0, 0, 1300, "weapon", false, ice)
	_item("w_staff_moon", "Tongkat Rembulan", "Bulan sabit perak di puncaknya menyerap cahaya malam.", "weapon", 4, "staff", 43, 0, 0, 0, 0, "", true, vio)
	_item("w_staff_star", "Tongkat Bintang Jatuh", "Dibuat dari serpihan bintang yang jatuh ke Aurelia.", "weapon", 5, "staff", 62, 0, 20, 0, 0, "", true, gold)
	# --- kapak/palu (Brann)
	_item("w_axe_iron", "Kapak Besi", "Kapak tebang yang diasah menjadi senjata.", "weapon", 1, "guard", 8, 1, 0, 0, 0, "", false, steel)
	_item("w_axe_war", "Kapak Perang", "Kapak bermata lebar milik pengawal gerbang.", "weapon", 2, "guard", 15, 2, 0, 0, 400, "weapon", false, steel)
	_item("w_axe_giant", "Kapak Raksasa", "Terlalu berat untuk kebanyakan orang.", "weapon", 3, "guard", 26, 4, 0, 0, 1300, "weapon", false, red)
	_item("w_hammer_titan", "Palu Titan", "Palu dua tangan, getarannya terasa sampai ke guild.", "weapon", 4, "guard", 40, 6, 20, 0, 0, "", true, red)
	_item("w_hammer_earth", "Palu Pemecah Bumi", "Sekali ayun, tanah retak membentuk bintang.", "weapon", 5, "guard", 58, 10, 50, 0, 0, "", true, gold)
	# --- busur (Sera)
	_item("w_bow_short", "Busur Pendek", "Busur berburu yang ringan.", "weapon", 1, "bow", 8, 0, 0, 0, 0, "", false, grn)
	_item("w_bow_hunter", "Busur Pemburu", "Busur pilihan para pemburu Hutan Berbisik.", "weapon", 2, "bow", 16, 0, 0, 0, 400, "weapon", false, grn)
	_item("w_bow_wind", "Busur Angin", "Panahnya melesat membelah angin.", "weapon", 3, "bow", 28, 0, 0, 0, 1300, "weapon", false, ice)
	_item("w_bow_falcon", "Busur Rajawali", "Bidikannya setajam mata rajawali.", "weapon", 4, "bow", 42, 0, 10, 0, 0, "", true, gold)
	_item("w_bow_sky", "Busur Langit Malam", "Talinya dipintal dari cahaya bintang.", "weapon", 5, "bow", 61, 0, 25, 0, 0, "", true, vio)
	# --- armor
	_item("a_cloth", "Jubah Kain", "Pakaian petualang paling dasar.", "armor", 1, "", 0, 4, 20, 0, 120, "weapon", false, steel)
	_item("a_leather", "Zirah Kulit", "Kulit tebal yang dijahit rapi.", "armor", 2, "", 0, 9, 40, 0, 400, "weapon", false, Color(0.75, 0.55, 0.35))
	_item("a_chain", "Zirah Rantai", "Ribuan cincin besi dirangkai jadi satu.", "armor", 3, "", 0, 15, 70, 0, 1200, "weapon", false, steel)
	_item("a_mythril", "Zirah Mitril", "Ringan, berkilau, dan hampir tak tertembus.", "armor", 4, "", 0, 24, 110, 0, 0, "", true, ice)
	_item("a_dragon", "Zirah Sisik Naga", "Sisik naga api yang sudah tidak panas lagi.", "armor", 5, "", 0, 34, 160, 0, 0, "", true, red)
	# --- aksesori
	_item("acc_copper", "Cincin Tembaga", "Cincin sederhana pembawa sedikit keberuntungan.", "accessory", 1, "", 2, 0, 10, 0, 150, "weapon", false, Color(0.85, 0.55, 0.3))
	_item("acc_silver", "Cincin Perak", "Perak murni dari tambang utara.", "accessory", 2, "", 5, 0, 25, 0, 450, "weapon", false, steel)
	_item("acc_dawn", "Liontin Fajar", "Liontin kecil yang hangat seperti matahari pagi.", "accessory", 3, "", 8, 3, 50, 0, 1400, "weapon", false, gold)
	_item("acc_moon", "Anting Rembulan", "Berbisik lembut saat malam tiba.", "accessory", 4, "", 14, 0, 80, 0, 0, "", true, vio)
	_item("acc_star", "Mahkota Bintang", "Mahkota tipis dengan lima bintang kecil.", "accessory", 5, "", 22, 8, 120, 0, 0, "", true, gold)
	# --- ramuan
	_item("p_small", "Ramuan Kecil", "Memulihkan 50 HP.", "potion", 1, "", 0, 0, 0, 50, 40, "item", true, Color(1.0, 0.45, 0.5))
	_item("p_big", "Ramuan Besar", "Memulihkan 150 HP.", "potion", 2, "", 0, 0, 0, 150, 120, "item", true, Color(1.0, 0.35, 0.6))
	_item("p_elixir", "Elixir Fajar", "Memulihkan 400 HP.", "potion", 3, "", 0, 0, 0, 400, 350, "item", true, Color(0.7, 0.9, 1.0))


# ------------------------------------------------------------------ quest
func _quest(d: Dictionary) -> void:
	var q := QuestData.new()
	for k in d:
		q.set(k, d[k])
	_save(q, "quests", q.id)


func _quests() -> void:
	_quest({"id": "q_welcome", "order": 1, "title": "Selamat Datang di Aurelia", "type": "talk", "target": "guild_master", "amount": 1,
		"description": "Perkenalkan dirimu kepada Master Orwen, pemimpin Serikat Bintang Fajar.",
		"hint": "Master Orwen berdiri di depan Guild (utara plaza).",
		"reward_gold": 200, "reward_diamond": 100, "reward_exp": 30})
	_quest({"id": "q_shop_potion", "order": 2, "title": "Bekal Pertama", "type": "buy", "target": "potion", "amount": 1,
		"prerequisite": "q_welcome",
		"description": "Beli satu ramuan di Toko Item. Petualang yang baik selalu membawa bekal.",
		"hint": "Toko 'Ramuan Fajar' ada di sisi timur plaza. Pedagangnya Mira.",
		"reward_gold": 150, "reward_exp": 30, "reward_items": PackedStringArray(["p_small:2"])})
	_quest({"id": "q_smith", "order": 3, "title": "Tempa Pertama", "type": "upgrade", "target": "", "amount": 1,
		"prerequisite": "q_welcome",
		"description": "Minta Tobias menempa (upgrade) senjata andalanmu satu kali.",
		"hint": "Pandai besi Tobias ada di toko 'Dentang Besi' (barat laut plaza, dekat Toko Senjata).",
		"reward_gold": 200, "reward_exp": 40, "reward_diamond": 30})
	_quest({"id": "q_slime", "order": 4, "title": "Pembasmi Slime", "type": "kill", "target": "slime", "amount": 8,
		"prerequisite": "q_welcome",
		"description": "Slime mulai mengganggu jalan perdagangan. Kalahkan 8 slime di luar kota.",
		"hint": "Masuk Portal Petualangan (sisi timur plaza) atau tekan Start Adventure, lalu pilih stage 1-1.",
		"reward_gold": 250, "reward_exp": 60, "reward_diamond": 50})
	_quest({"id": "q_clear_11", "order": 5, "title": "Langkah Pertama", "type": "clear_stage", "target": "s1_1", "amount": 1,
		"prerequisite": "q_welcome",
		"description": "Selesaikan stage 1-1: Padang Gerbang. Seorang pemanah akan bergabung jika kamu berhasil.",
		"hint": "Tekan Start Adventure atau masuk Portal Petualangan.",
		"reward_gold": 300, "reward_exp": 80, "reward_diamond": 60, "reward_character": "sera"})
	_quest({"id": "q_summon", "order": 6, "title": "Panggilan Bintang", "type": "summon", "target": "", "amount": 1,
		"prerequisite": "q_clear_11",
		"description": "Lakukan satu kali Gacha di Altar Pemanggilan.",
		"hint": "Tombol Gacha di menu, atau Altar Bintang di taman barat daya.",
		"reward_gold": 200, "reward_diamond": 50})
	_quest({"id": "q_party", "order": 7, "title": "Empat Sekawan", "type": "party", "target": "", "amount": 4,
		"prerequisite": "q_clear_11",
		"description": "Susun party berisi empat karakter agar bisa berganti peran saat bertarung.",
		"hint": "Buka menu Party atau Tenda Persiapan (Area Persiapan) di sisi barat plaza.",
		"reward_gold": 300, "reward_items": PackedStringArray(["p_big:3"])})
	_quest({"id": "q_level5", "order": 8, "title": "Petualang Sejati", "type": "level", "target": "", "amount": 5,
		"prerequisite": "q_clear_11",
		"description": "Capai level akun 5 dengan menyelesaikan stage.",
		"hint": "Kalahkan monster dan selesaikan stage untuk mendapat EXP.",
		"reward_gold": 400, "reward_diamond": 150})
	_quest({"id": "q_clear_12", "order": 9, "title": "Hutan Berbisik", "type": "clear_stage", "target": "s1_2", "amount": 1,
		"prerequisite": "q_clear_11",
		"description": "Hutan di timur kota dipenuhi jamur penyembur spora. Bersihkan stage 1-2.",
		"hint": "Pilih stage 1-2 di Portal Petualangan.",
		"reward_gold": 400, "reward_exp": 120, "reward_diamond": 60})
	_quest({"id": "q_kill_30", "order": 10, "title": "Pemburu Gigih", "type": "kill", "target": "", "amount": 30,
		"prerequisite": "q_slime",
		"description": "Kalahkan total 30 monster jenis apa pun.",
		"hint": "Setiap stage mengandung banyak monster.",
		"reward_gold": 500, "reward_exp": 100, "reward_diamond": 80})
	_quest({"id": "q_clear_13", "order": 11, "title": "Gua Kristal", "type": "clear_stage", "target": "s1_3", "amount": 1,
		"prerequisite": "q_clear_12",
		"description": "Kristal di dalam gua mulai retak. Selidiki dan bersihkan stage 1-3.",
		"hint": "Pilih stage 1-3 di Portal Petualangan.",
		"reward_gold": 500, "reward_exp": 150, "reward_diamond": 80, "reward_items": PackedStringArray(["acc_dawn:1"])})
	_quest({"id": "q_boss", "order": 12, "title": "Sang Penjaga Kristal", "type": "clear_stage", "target": "s1_boss", "amount": 1,
		"prerequisite": "q_clear_13",
		"description": "Golem Kristal mengamuk di kedalaman gua. Kalahkan dia di arena bos.",
		"hint": "Stage 1-B terbuka setelah 1-3 selesai.",
		"reward_gold": 1000, "reward_exp": 300, "reward_diamond": 200, "reward_items": PackedStringArray(["a_mythril:1"])})


# ------------------------------------------------------------------ stage
func _stage(d: Dictionary) -> void:
	var s := StageData.new()
	for k in d:
		s.set(k, d[k])
	_save(s, "stages", s.id)


func _stages() -> void:
	_stage({"id": "s1_1", "display_name": "1-1  Padang Gerbang", "chapter": "Bab 1: Fajar di Aurelia", "theme": "meadow",
		"description": "Padang rumput di luar gerbang kota. Slime dan kelelawar kecil berkeliaran.",
		"recommended_level": 1, "waves": [{"slime": 4}, {"slime": 5, "bat": 1}],
		"reward_gold": 120, "reward_exp": 70, "reward_diamond": 0, "first_clear_diamond": 40, "music": "music_desert"})
	_stage({"id": "s1_2", "display_name": "1-2  Hutan Berbisik", "chapter": "Bab 1: Fajar di Aurelia", "theme": "forest",
		"description": "Hutan lebat dengan jamur penyembur spora. Hati-hati dengan tembakannya.",
		"recommended_level": 3, "unlock_after": "s1_1",
		"waves": [{"slime": 4, "mushroom": 2}, {"bat": 4, "mushroom": 2}, {"slime": 4, "bat": 3, "mushroom": 3}],
		"reward_gold": 200, "reward_exp": 110, "reward_diamond": 0, "first_clear_diamond": 50, "music": "music_castle"})
	_stage({"id": "s1_3", "display_name": "1-3  Gua Kristal", "chapter": "Bab 1: Fajar di Aurelia", "theme": "cave",
		"description": "Gua gelap bertabur kristal biru. Kelelawar bersarang di langit-langitnya.",
		"recommended_level": 5, "unlock_after": "s1_2",
		"waves": [{"bat": 5, "mushroom": 3}, {"slime": 6, "bat": 4}, {"mushroom": 5, "bat": 5}],
		"reward_gold": 300, "reward_exp": 160, "reward_diamond": 0, "first_clear_diamond": 60, "music": "music_cave"})
	_stage({"id": "s1_boss", "display_name": "1-B  Arena Golem Kristal", "chapter": "Bab 1: Fajar di Aurelia", "theme": "boss",
		"description": "Arena bos. Golem Kristal menjaga inti gua dan memanggil slime saat marah.",
		"recommended_level": 7, "unlock_after": "s1_3", "boss": "golem", "waves": [{"slime": 3}],
		"reward_gold": 600, "reward_exp": 300, "reward_diamond": 50, "first_clear_diamond": 120, "music": "music_boss"})
