extends RefCounted
## Memeriksa sinkronisasi animasi bos: saat serangan MULAI mengenai (windup -> strike), posisi klip harus di puncak gerakan.
## Mencatat posisi animasi pada pergantian windup->strike, dan memastikan klip tidak dimulai ulang saat strike.
var st: Node3D
func _w(s: float) -> void:
	await st.get_tree().create_timer(s).timeout
func run(s: Node3D) -> void:
	st = s
	var guard := 0.0
	while st.boss == null and guard < 40.0:
		await _w(0.3)
		guard += 0.3
		for e in st.get_tree().get_nodes_in_group("enemies"):
			if not e.is_boss and e.state != "spawn":
				e.take_damage(99999, st.player.global_position, 0.0)
	var b: Enemy = st.boss
	var ap: AnimationPlayer = b._rig.anim_player
	var prev := ""
	var restarts := 0
	var last_pos := 0.0
	var wpos := 0.0
	var wspd := 1.0
	var seen := {}
	var t := 0.0
	while t < 50.0 and seen.size() < 3:
		await st.get_tree().process_frame
		t += st.get_process_delta_time()
		for ps in st.party_state:
			ps["hp"] = ps["max"]
		var cur := b.state + ":" + b._attack
		var pos := ap.current_animation_position
		if prev.begins_with("windup") and b.state == "strike":
			print("ANIMCHK attack=", b._attack, " strike-start anim=", ap.current_animation, " pos=%.2f speed=%.2f" % [pos, ap.speed_scale])
			seen[b._attack] = true
			if b._attack == "claw" or b._attack == "wave":
				var expect := Enemy.ANIM_CLAW_IMPACT if b._attack == "claw" else Enemy.ANIM_ROAR_PEAK
				print("CHECK ", "PASS " if absf(pos - expect) < 0.2 else "FAIL ", b._attack, " impact sync pos=%.2f expect=%.2f" % [pos, expect])
			if b._attack == "charge":
				print("CHECK ", "PASS " if absf(wpos - Enemy.ANIM_REAR_HOLD) < 0.12 and wspd == 0.0 else "FAIL ", "charge rear-hold (last windup frame) pos=%.2f speed=%.2f" % [wpos, wspd])
		if b.state == "strike" and (b._attack == "claw" or b._attack == "wave") and pos + 0.05 < last_pos and ap.current_animation in ["Attack", "Roar"]:
			restarts += 1
		last_pos = pos
		if b.state == "windup":
			wpos = pos
			wspd = ap.speed_scale
		prev = b.state if b.state != "windup" else "windup"
		if b.state == "windup": prev = "windup"
	print("CHECK ", "PASS " if restarts == 0 else "FAIL ", "no clip restart during strike restarts=", restarts)
	print("attacks seen: ", seen.keys())
