extends RefCounted
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func run(lobby: Node) -> void:
	var t := lobby.get_tree()
	await t.create_timer(1.0).timeout
	var A = t.root.get_node_or_null("Admin")
	check("Admin ada di lobi", A != null)
	A._toggle()
	await t.create_timer(0.3).timeout
	check("jendela terbuka di lobi", A._win != null)
	A.unlock_all_characters()
	var ok := true
	for id in Data.character_ids():
		A.swap_character(id)
		await t.create_timer(0.1).timeout
		if lobby.player.data == null or lobby.player.data.id != id or GameState.party[0] != id:
			ok = false
			print("   gagal: ", id)
	check("ganti ke semua karakter di lobi (pemain & slot 1 party)", ok)
	A.spawn_enemy("slime")
	check("spawn di lobi ditolak tanpa crash", true)
	print("SUMMARY fails=", fails)
