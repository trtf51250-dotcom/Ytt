extends RefCounted
## Uji build ADMIN di dalam stage: setiap fungsi alat admin benar-benar bekerja (bukan cuma tombol tampil).
var fails := 0
var st: Node3D
var t: SceneTree

func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1

func _wait(s: float) -> void:
	await t.create_timer(s).timeout

func _clear() -> void:
	for e in t.get_nodes_in_group("enemies"):
		e.queue_free()
	await _wait(0.2)

func run(s: Node3D) -> void:
	st = s
	t = st.get_tree()
	st.autoplay = true
	await _wait(1.0)
	var A = t.root.get_node_or_null("Admin")
	check("autoload Admin ada", A != null)
	if A == null:
		print("SUMMARY fails=", fails)
		return
	var p: Player = st.player
	A._toggle()
	await _wait(0.4)
	check("jendela admin terbuka", A._win != null and is_instance_valid(A._win))
	var nb: int = A._win.find_children("*", "Button", true, false).size()
	check("jendela punya banyak tombol", nb > 30, str(nb))
	t.root.get_viewport().get_texture().get_image().save_png(OS.get_environment("TMPDIR") + "/admin_win.png")
	A.unlock_all_characters()
	check("semua karakter terbuka", GameState.roster.size() == Data.character_ids().size(), str(GameState.roster.size()))
	A.max_stars_all()
	var allmax := true
	for id in GameState.roster.keys():
		if GameState.stars(id) != GameState.MAX_STARS:
			allmax = false
	check("semua ★ maks", allmax)
	A.set_level(50)
	check("level 50", GameState.level == 50)
	var g0: int = GameState.gold
	GameState.add_gold(1000000)
	check("gold bertambah", GameState.gold >= g0 + 1000000)
	A.unlock_all_stages()
	var sok := true
	for sid in Data.stage_order:
		if not GameState.stages.get(sid, {}).get("cleared", false):
			sok = false
	check("semua stage selesai", sok)
	A.give_all_items()
	var ik := Data.items.keys()
	check("item ada", ik.size() > 0)
	var swapped_all := true
	for id in Data.character_ids():
		A.swap_character(id)
		await _wait(0.15)
		if p.data == null or p.data.id != id:
			swapped_all = false
			print("   swap gagal: ", id)
	check("ganti ke semua %d karakter di stage" % Data.character_ids().size(), swapped_all)
	await _clear()
	var kinds: Array = Enemy.KINDS.keys()
	var before := t.get_nodes_in_group("enemies").size()
	A.spawn_enemy(kinds[0])
	await _wait(0.3)
	check("spawn musuh", t.get_nodes_in_group("enemies").size() > before)
	p.revive(true)
	p.invuln = 0.0
	var hp0 := p.hp
	A.god = true
	p.take_damage(50, Vector3.ZERO)
	check("god mode: HP tidak berkurang", p.hp == hp0, "%d -> %d" % [hp0, p.hp])
	A.god = false
	p.invuln = 0.0
	p.take_damage(5, Vector3.ZERO)
	check("god off: HP berkurang", p.hp < hp0, "%d -> %d" % [hp0, p.hp])
	p.skill_cd = 5.0
	p.attack_cd = 1.0
	A.no_cd = true
	await _wait(0.3)
	check("tanpa cooldown", p.skill_cd == 0.0 and p.attack_cd == 0.0)
	A.no_cd = false
	# one-hit: musuh 5000 HP harus mati oleh serangan pertama
	await _clear()
	A.swap_character("ren")
	p.revive(true)
	p.invuln = 99.0
	p.control_enabled = true
	p.global_position = Vector3(0, 0.1, 0)
	var d: Enemy = st._spawn_enemy("slime", Vector3(0, 0, 1.4))
	await _wait(1.0)
	d.set_physics_process(false)
	d.global_position = Vector3(0, 0, 1.4)
	d.hp = 5000
	d.max_hp = 5000
	A.one_hit = true
	for e in t.get_nodes_in_group("enemies"):            # hanya satu target; musuh gelombang lain dibuang
		if e != d:
			e.queue_free()
	p.global_position = Vector3(0, 0.1, 0)               # kunci posisi TEPAT sebelum menyerang (pemain bisa bergeser saat menunggu)
	p.velocity = Vector3.ZERO
	await t.process_frame
	p.attack_cd = 0.0
	p.do_attack()
	await _wait(1.0)
	var gone := not is_instance_valid(d) or d.dead or d.hp <= 0
	check("one-hit: musuh 5000 HP mati dlm 1 serangan", gone, "hp=%s" % (str(d.hp) if is_instance_valid(d) else "freed"))
	A.one_hit = false
	await _clear()
	A.spawn_enemy(kinds[0])
	A.spawn_enemy(kinds[0])
	await _wait(0.3)
	A.kill_all()
	await _wait(1.5)
	var alive := 0
	for e in t.get_nodes_in_group("enemies"):
		if is_instance_valid(e) and not e.dead:
			alive += 1
	check("bunuh semua musuh (termasuk yang baru spawn)", alive == 0, str(alive))
	A._speed(2.0)
	check("kecepatan 2x", Engine.time_scale == 2.0)
	A._speed(1.0)
	A._toggle()
	await _wait(0.2)
	check("jendela tertutup", A._win == null)
	print("SUMMARY fails=", fails)
