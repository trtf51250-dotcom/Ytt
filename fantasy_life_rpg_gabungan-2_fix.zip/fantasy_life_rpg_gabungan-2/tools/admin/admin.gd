extends Node
## ADMIN (hanya ada di build admin). Tombol melayang "ADMIN" di semua layar -> jendela alat uji:
## buka semua karakter, ★ maks, level 50, uang, semua stage & item, god mode, one-hit, tanpa cooldown,
## ganti karakter langsung (lobi & stage), spawn musuh/bos, bunuh semua, kecepatan game.

var god := false
var one_hit := false
var no_cd := false

var _layer: CanvasLayer
var _btn: Button
var _win: PanelContainer
var _info: Label
var _toggles: Dictionary = {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_layer = CanvasLayer.new()
	_layer.layer = 100
	_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_layer)
	_btn = Button.new()
	_btn.text = "ADMIN"
	_btn.custom_minimum_size = Vector2(120, 44)
	_btn.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_btn.position.y = 4
	_btn.add_theme_font_size_override("font_size", 20)
	_btn.add_theme_color_override("font_color", Color(1, 0.9, 0.4))
	_btn.add_theme_stylebox_override("normal", _box(Color(0.5, 0.08, 0.12, 0.92), Color(1, 0.8, 0.3)))
	_btn.add_theme_stylebox_override("pressed", _box(Color(0.7, 0.12, 0.16, 0.95), Color(1, 1, 0.5)))
	_btn.add_theme_stylebox_override("hover", _box(Color(0.6, 0.1, 0.14, 0.95), Color(1, 0.8, 0.3)))
	_btn.pressed.connect(_toggle)
	_layer.add_child(_btn)


func _box(bg: Color, border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.set_corner_radius_all(10)
	s.content_margin_left = 10
	s.content_margin_right = 10
	s.content_margin_top = 4
	s.content_margin_bottom = 4
	return s


func _toggle() -> void:
	if _win and is_instance_valid(_win):
		_win.queue_free()
		_win = null
		return
	_build_window()


func _scene() -> Node:
	return get_tree().current_scene


func _player() -> Player:
	var sc := _scene()
	if sc != null and "player" in sc and sc.player is Player:
		return sc.player
	return null


func _stage() -> Node:
	var sc := _scene()
	return sc if sc != null and sc.has_method("_spawn_enemy") else null


# ------------------------------------------------------------------ jendela
func _build_window() -> void:
	_win = PanelContainer.new()
	_win.add_theme_stylebox_override("panel", _box(Color(0.06, 0.08, 0.18, 0.97), Color(1, 0.8, 0.3)))
	_win.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_win.offset_left = 150
	_win.offset_right = -150
	_win.offset_top = 56
	_win.offset_bottom = -16
	_layer.add_child(_win)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 6)
	_win.add_child(root)
	var head := Label.new()
	head.text = "ADMIN — alat uji karakter"
	head.add_theme_font_size_override("font_size", 24)
	head.add_theme_color_override("font_color", Color(1, 0.85, 0.35))
	root.add_child(head)
	_info = Label.new()
	_info.add_theme_font_size_override("font_size", 15)
	_info.add_theme_color_override("font_color", Color(0.75, 0.85, 1))
	_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(_info)
	var sc := TouchScroll.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(sc)
	var body := VBoxContainer.new()
	body.add_theme_constant_override("separation", 8)
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var mg := MarginContainer.new()
	mg.add_theme_constant_override("margin_right", 14)
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mg.add_child(body)
	sc.add_child(mg)

	_section(body, "AKUN")
	var g1 := _grid(body, 3)
	_add_btn(g1, "Buka SEMUA karakter", unlock_all_characters)
	_add_btn(g1, "★ Maks semua karakter", max_stars_all)
	_add_btn(g1, "Level 50", func(): set_level(GameState.MAX_LEVEL))
	_add_btn(g1, "+1.000.000 Gold", func(): GameState.add_gold(1000000); _say("Gold +1.000.000"))
	_add_btn(g1, "+100.000 Diamond", func(): GameState.add_diamonds(100000); _say("Diamond +100.000"))
	_add_btn(g1, "Buka semua stage", unlock_all_stages)
	_add_btn(g1, "Semua item ×99", give_all_items)
	_add_btn(g1, "Senjata +10 semua", max_weapons)
	_add_btn(g1, "Pity gacha hampir penuh", func():
		GameState.pity = 79
		GameState.pity_item = 49
		_say("Pity karakter 79/80, item 49/50 — tarik 1x untuk bintang tertinggi"))

	_section(body, "MODE UJI (aktif selama permainan berjalan)")
	var g2 := _grid(body, 3)
	_add_toggle(g2, "God Mode (kebal)", "god")
	_add_toggle(g2, "One-hit kill", "one_hit")
	_add_toggle(g2, "Tanpa cooldown", "no_cd")
	_add_btn(g2, "Pulihkan HP penuh", heal_full)
	_add_btn(g2, "Bunuh semua musuh", kill_all)
	_add_btn(g2, "Kecepatan: 1x", func(): _speed(1.0))
	_add_btn(g2, "Kecepatan: 0.4x (lambat)", func(): _speed(0.4))
	_add_btn(g2, "Kecepatan: 2x", func(): _speed(2.0))

	_section(body, "GANTI KARAKTER LANGSUNG (lobi & stage)")
	var g3 := _grid(body, 4)
	for id in Data.character_ids():
		var cd := Data.character(id)
		_add_btn(g3, "%s ★%d" % [cd.display_name, cd.rarity], func(): swap_character(id))

	_section(body, "STAGE & MUSUH")
	var g4 := _grid(body, 3)
	for sid in Data.stage_order:
		var sd := Data.stage(sid)
		_add_btn(g4, "Mulai: %s" % sd.display_name, func(): _start_stage(sid))
	_add_btn(g4, "Ke lobi", func(): _toggle(); Flow.go_lobby())
	var g5 := _grid(body, 4)
	for k in Enemy.KINDS.keys():
		_add_btn(g5, "Spawn %s" % k, func(): spawn_enemy(k))
	_say("Siap. Pilih alat di bawah. Mode uji aktif: %s" % _modes())


func _section(parent: Control, text: String) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 18)
	l.add_theme_color_override("font_color", Color(1, 0.8, 0.3))
	parent.add_child(l)


func _grid(parent: Control, cols: int) -> GridContainer:
	var g := GridContainer.new()
	g.columns = cols
	g.add_theme_constant_override("h_separation", 6)
	g.add_theme_constant_override("v_separation", 6)
	g.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(g)
	return g


func _add_btn(parent: Control, text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.custom_minimum_size = Vector2(0, 48)
	b.add_theme_font_size_override("font_size", 16)
	b.clip_text = true
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func _add_toggle(parent: Control, text: String, prop: String) -> void:
	var b := _add_btn(parent, "", func(): pass)
	b.toggle_mode = true
	b.button_pressed = bool(get(prop))
	var refresh := func():
		b.text = "%s: %s" % [text, "AKTIF" if bool(get(prop)) else "mati"]
	refresh.call()
	b.toggled.connect(func(on: bool):
		set(prop, on)
		refresh.call()
		_say("%s %s" % [text, "diaktifkan" if on else "dimatikan"]))
	_toggles[prop] = b


func _modes() -> String:
	var m: Array = []
	if god:
		m.append("God")
	if one_hit:
		m.append("One-hit")
	if no_cd:
		m.append("Tanpa CD")
	return ", ".join(m) if not m.is_empty() else "tidak ada"


func _say(text: String) -> void:
	if _info:
		_info.text = text
	print("ADMIN: ", text)


# ------------------------------------------------------------------ aksi
func unlock_all_characters() -> void:
	var n := 0
	for id in Data.character_ids():
		if GameState.unlock_character(id):
			n += 1
	GameState.changed.emit("roster")
	_say("%d karakter baru dibuka (total %d)." % [n, GameState.roster.size()])


func max_stars_all() -> void:
	unlock_all_characters()
	for id in GameState.roster.keys():
		GameState.roster[id]["stars"] = GameState.MAX_STARS
	GameState.changed.emit("roster")
	GameState.queue_save()
	_say("Semua karakter ★ awakening maks (%d)." % GameState.MAX_STARS)


func set_level(lv: int) -> void:
	GameState.level = lv
	GameState.exp = 0
	GameState.changed.emit("profile")
	GameState.queue_save()
	_say("Level pemain = %d." % lv)


func unlock_all_stages() -> void:
	for sid in Data.stage_order:
		GameState.stages[sid] = {"cleared": true, "stars": 3}
	GameState.changed.emit("stage")
	GameState.queue_save()
	_say("%d stage terbuka & selesai ★3." % Data.stage_order.size())


func give_all_items() -> void:
	for id in Data.items.keys():
		GameState.add_item(id, 99)
	_say("Semua item ×99 ditambahkan.")


func max_weapons() -> void:
	for id in GameState.roster.keys():
		if GameState.equipment.has(id):
			GameState.equipment[id]["weapon_plus"] = 10
	GameState.changed.emit("equipment")
	GameState.queue_save()
	_say("Senjata semua karakter +10.")


func heal_full() -> void:
	var p := _player()
	if p == null:
		_say("Tidak ada pemain di layar ini.")
		return
	p.hp = p.max_hp
	p.revive(true) if p.dead else null
	_say("HP dipulihkan.")


func kill_all() -> void:
	var n := 0
	for e in get_tree().get_nodes_in_group("enemies"):
		if e.has_method("take_damage") and not ("dead" in e and e.dead):
			if "state" in e and e.state == "spawn":      # musuh yang baru muncul kebal; paksa keluar dari status itu
				e.state = "chase"
			e.take_damage(99999999, Vector3.ZERO, 0.0)
			n += 1
	_say("%d musuh dibunuh." % n)


func spawn_enemy(kind: String) -> void:
	var st := _stage()
	var p := _player()
	if st == null or p == null:
		_say("Spawn musuh hanya di dalam stage (pakai 'Mulai: ...').")
		return
	var pos: Vector3 = p.global_position + p.forward_dir() * 5.0
	st._spawn_enemy(kind, pos)
	_say("Musuh %s muncul di depan pemain." % kind)


func _start_stage(sid: String) -> void:
	_toggle()
	Flow.start_stage(sid)


func _speed(s: float) -> void:
	Engine.time_scale = s
	_say("Kecepatan game %.1fx" % s)


func swap_character(id: String) -> void:
	var p := _player()
	if p == null:
		_say("Tidak ada pemain di layar ini.")
		return
	GameState.unlock_character(id)
	var sc := _scene()
	if sc.has_method("_spawn_enemy"):                          # di stage: ganti karakter aktif tanpa mengubah slot party
		p.set_character(id)
		var st: Dictionary = GameState.char_stats(id)
		p.max_hp = st["hp"]
		p.hp = st["hp"]
		p.skill_cd = 0.0
		if "party_state" in sc and "active" in sc:
			var ps: Dictionary = sc.party_state[sc.active]
			ps["id"] = id
			ps["max"] = st["hp"]
			ps["hp"] = st["hp"]
			ps["dead"] = false
			if "hud" in sc and sc.hud != null:
				sc.hud.setup_party(sc.party_state.map(func(q): return q["id"]))
				sc.hud.update_party(sc.party_state, sc.active)
	else:                                                        # di lobi: jadikan pemimpin
		GameState.set_party_slot(0, id)
		p.set_character(id)
	_say("Karakter aktif: %s (★%d, %s)." % [Data.character(id).display_name, Data.character(id).rarity, Data.character(id).role])


func _process(_d: float) -> void:
	if _btn:
		_btn.visible = true
