extends Node
## Uji co-op dua proses di satu mesin (loopback). Jalankan dua instans:
##   host  : godot ... tools/coop_test.tscn -- --role=host --stage=s1_1 --shots=DIR --fresh
##   client: godot ... tools/coop_test.tscn -- --role=client --stage=s1_1 --shots=DIR --fresh
## Menguji: penemuan room (UDP), password salah ditolak, password benar masuk, mulai bersama, musuh puppet, damage client -> host,
## ghost pemain, selesai bersamaan. Mencetak "CHECK PASS/FAIL" + "CHECK SUMMARY fails=N".

var role := "host"
var stage_id := "s1_1"
var shots := "/tmp"
var fails := 0
const PW := "rahasia"


func _arg(k: String, d: String = "") -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % k):
			return a.substr(k.length() + 3)
	return d


func check(name: String, ok: bool, detail: String = "") -> void:
	print("[", role, "] CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1


func _ready() -> void:
	role = _arg("role", "host")
	stage_id = _arg("stage", "s1_1")
	shots = _arg("shots", "/tmp")
	call_deferred("_start")


func _start() -> void:
	var holder := Node.new()          # scene sementara; test sendiri tidak ikut terhapus saat scene berganti
	get_tree().root.add_child(holder)
	get_tree().current_scene = holder
	GameState.settings["sky_life"] = false          # ringankan render software (llvmpipe) saat dua proses jalan bersamaan
	GameState.settings["cloud_shadows"] = false
	GameState.player_name = "Host" if role == "host" else "Tamu"
	if role == "client":
		GameState.unlock_character("wenyu")
		GameState.party = ["wenyu"]
	await _run()
	print("[", role, "] CHECK SUMMARY fails=", fails)
	await get_tree().create_timer(1.0).timeout
	get_tree().quit()


func _wait(cond: Callable, timeout: float) -> bool:
	var t := 0.0
	while t < timeout:
		if cond.call():
			return true
		if int(t * 10) % 50 == 0:
			print("[", role, "] wait t=%.0f fps=%d scene=%s" % [t, Engine.get_frames_per_second(), get_tree().current_scene])
		await get_tree().create_timer(0.1).timeout
		t += 0.1
	return cond.call()


func _run() -> void:
	if role == "host":
		var err := Net.host_room("RoomTes", PW, stage_id)
		check("host_room ok", err == "", err)
		var solo := _arg("solo", "") != ""
		var ok := solo or await _wait(func(): return Net.members.size() >= 2, 60.0)
		check("tamu bergabung", ok, str(Net.members))
		if not ok:
			return
		await get_tree().create_timer(1.0).timeout
		check("start_game ok", Net.start_game() == "")
	else:
		Net.start_search()
		var found := await _wait(func(): return not Net.rooms.is_empty(), 30.0)
		check("room ditemukan lewat broadcast", found, str(Net.rooms.keys()))
		if not found:
			return
		var r: Dictionary = Net.rooms[Net.rooms.keys()[0]]
		check("info room benar", r["room"] == "RoomTes" and r["lock"] == true and r["host"] == "Host", str(r))
		Net.stop_search()
		var failed := [""]
		Net.join_failed.connect(func(m: String): failed[0] = m)
		check("join_room(salah) dimulai", Net.join_room(r["ip"], r["port"], "salah") == "")
		var rej := await _wait(func(): return failed[0] != "", 10.0)
		check("password salah ditolak", rej and failed[0] == "Password salah", failed[0])
		check("state kembali none", Net.mode == "none")
		await get_tree().create_timer(0.5).timeout
		check("join_room(benar) dimulai", Net.join_room(r["ip"], r["port"], PW) == "")
		var ok := await _wait(func(): return Net.connected_ok and Net.members.size() >= 2, 15.0)
		check("auth sukses & anggota sinkron", ok, str(Net.members))
		if not ok:
			return
	# tunggu pindah ke stage
	print("[", role, "] waiting stage; scene=", get_tree().current_scene)
	var in_stage := await _wait(func(): return get_tree().current_scene is Stage and (get_tree().current_scene as Stage).coop != null, 40.0)
	check("masuk stage co-op", in_stage)
	if not in_stage:
		return
	var st: Stage = get_tree().current_scene
	check("stage sama", st.sd.id == stage_id, st.sd.id)
	var ghost_ok := await _wait(func(): return st.coop.ghosts.size() >= 1 and (st.coop.ghosts.values()[0] as CoopGhost)._has, 15.0)
	check("ghost rekan muncul", ghost_ok)
	if stage_id.begins_with("pvp_"):
		await _pvp_phase(st)
		return
	st.autoplay = true
	var bot: RefCounted = (load("res://tools/stage_bot.gd") as GDScript).new()
	bot.st = st
	var t := 0.0
	var shot := false
	var max_puppets := 0
	var saw_boss_hp := false
	while st.state != Stage.S.ENDED and t < 240.0:
		await get_tree().create_timer(0.05).timeout
		t += 0.05
		bot._tick()
		if role == "client":
			max_puppets = maxi(max_puppets, st.coop.enemies.size())
		if t > 8.0 and not shot:
			shot = true
			await st._shot("coop_%s_fight" % role)
	check("stage selesai < 240 dtk", st.state == Stage.S.ENDED, "t=%.1f" % t)
	check("hasil kemenangan", st._ended_win)
	if role == "host":
		check("host menerima damage dari client (RPC)", st.coop.stat_client_hits > 0, str(st.coop.stat_client_hits))
		check("host punya kill", st.kills > 0, str(st.kills))
	else:
		check("client membuat puppet", st.coop.stat_spawns > 0 and max_puppets > 0, "spawns=%d max=%d" % [st.coop.stat_spawns, max_puppets])
		check("client menerima snapshot", st.coop.stat_snaps > 20, str(st.coop.stat_snaps))
		check("client dapat kill dari event kematian", st.kills > 0, str(st.kills))
	await get_tree().create_timer(2.0).timeout
	await st._shot("coop_%s_result" % role)


## PVP: tiap bot mendekati lawan (teleport dekat supaya uji fokus ke rute damage), menghadap, lalu menyerang.
func _pvp_phase(st: Stage) -> void:
	var live := await _wait(func(): return st.coop.pvp_live, 20.0)
	check("pvp dimulai (hitung mundur selesai)", live)
	if not live:
		return
	st.autoplay = true
	var t := 0.0
	var skill_t := 0.0
	while st.state != Stage.S.ENDED and t < 200.0:
		await get_tree().create_timer(0.05).timeout
		t += 0.05
		skill_t += 0.05
		if st.player.dead or st.all_down:
			continue
		var tgt: CoopGhost = null
		var bd := 1e9
		for g: CoopGhost in st.coop.ghosts.values():
			if is_instance_valid(g) and not g.all_down and not g.dead:
				var d := st.player.global_position.distance_to(g.global_position)
				if d < bd:
					bd = d
					tgt = g
		if tgt == null:
			continue
		var to := tgt.global_position - st.player.global_position
		to.y = 0.0
		if to.length() > 1.8:
			st.player.global_position += to.normalized() * (to.length() - 1.5)
		st.player.facing = atan2(to.x, to.z)
		st.player.do_attack()
		if skill_t > 3.0:
			skill_t = 0.0
			st.player.do_skill()
	check("pvp selesai", st.state == Stage.S.ENDED, "t=%.1f" % t)
	check("serangan terkirim ke lawan", st.coop.stat_pvp_hits_sent > 0, str(st.coop.stat_pvp_hits_sent))
	check("luka dari lawan diterima", st.coop.stat_pvp_hurt > 0, str(st.coop.stat_pvp_hurt))
	if role == "host":
		var total := 0
		for k in st.coop.pvp_kills.values():
			total += int(k)
		check("ada kill tercatat", total >= 1 or st.coop.pvp_left <= 0.5, str(st.coop.pvp_kills))
	await get_tree().create_timer(2.5).timeout
	await st._shot("pvp_%s_result" % role)
