extends RefCounted
## Foto dekat Hakuya: katana menyala, tebasan runcing, skill (kamera tambahan dekat karakter, waktu diperlambat).
var st: Node3D
func run(s: Node3D) -> void:
	st = s
	var t := st.get_tree()
	await t.create_timer(0.8).timeout
	for e in t.get_nodes_in_group("enemies"): e.queue_free()
	var p: Player = st.player
	GameState.unlock_character("hakuya")
	p.set_character("hakuya")
	p.invuln = 999.0
	p.global_position = Vector3(0, 0.1, 0)
	p.facing = 0.0
	st.cam.snap_to_target()
	var cam := Camera3D.new()
	st.add_child(cam)
	cam.global_position = Vector3(3.2, 2.6, -3.8)
	cam.look_at(Vector3(0, 1.0, 1.6), Vector3.UP)
	cam.fov = 60.0
	cam.current = true
	await t.create_timer(1.5).timeout
	await st._shot("hk_idle")
	for e in t.get_nodes_in_group("enemies"): e.queue_free()
	var d: Enemy = st._spawn_enemy("slime", Vector3(0, 0, 2.6))
	await t.create_timer(1.0).timeout
	d.hp = 99999999; d.max_hp = 99999999
	d.set_physics_process(false)
	d.global_position = Vector3(0, 0, 2.6)
	for act in ["atk1", "atk2", "skill"]:
		p.attack_cd = 0.0; p.skill_cd = 0.0; p._act_t = 0.0
		p.global_position = Vector3(0, 0.1, 0)
		Engine.time_scale = 0.15
		if act == "skill": p.do_skill()
		else:
			if act == "atk2": p._combo = 1
			p.do_attack()
		var imp: float = p.rig.action_impact("skill" if act == "skill" else "attack1")
		var el := 0.0
		var marks := [imp + 0.03, imp + 0.1, imp + 0.2]
		var mi := 0
		while el < imp + 0.3:
			await t.process_frame
			el += st.get_process_delta_time()
			if mi < marks.size() and el >= marks[mi]:
				var trn = p.find_child("BladeTrail", true, false)
				print("  trail ", act, " ", mi, ": titik=", (trn._pts.size() if trn != null else -1), " player=", (trn.player != null if trn != null else false), " visible=", (trn._mi.is_visible_in_tree() if trn != null else false))
				await st._shot("hk_%s_%d" % [act, mi])
				mi += 1
		Engine.time_scale = 1.0
		await t.create_timer(2.5).timeout
	print("CHECK PASS foto diambil")
