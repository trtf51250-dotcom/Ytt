extends RefCounted
## ULT: 1× per karakter per match; melukai musuh; karakter lain punya jatah sendiri; foto efek tiap karakter.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1

func _hp(t: SceneTree) -> int:
	var s := 0
	for e in t.get_nodes_in_group("enemies"): s += int(e.hp)
	return s

func run(st: Node3D) -> void:
	var t := st.get_tree()
	st.autoplay = false
	await t.create_timer(0.8).timeout
	var p: Player = st.player
	p.invuln = 0.0
	var base: Vector3 = p.global_position
	var only := OS.get_environment("ULT_ONLY")
	var first := true
	for id in Data.character_ids():
		if only != "" and id != only: continue
		GameState.unlock_character(id)
		p.set_character(id)
		p.control_enabled = true
		p.global_position = base
		p.facing = 0.0
		p.velocity = Vector3.ZERO
		for e in t.get_nodes_in_group("enemies"): e.queue_free()
		await t.create_timer(0.3).timeout
		var mons: Array = []
		for i in 4:
			var e: Enemy = st._spawn_enemy("slime", base + Vector3(-3 + i * 2.0, 0, 4.0 + (i % 2) * 2.0))
			mons.append(e)
		await t.create_timer(0.8).timeout
		for e in mons:
			e.hp = 100000; e.max_hp = 100000
			e.set_physics_process(false)
		st.cam.pitch = deg_to_rad(62.0); st.cam.distance = 15.0
		st.cam.snap_to_target()
		check(id + " ult tersedia", st.ult_available())
		p.global_position = base; p.velocity = Vector3.ZERO; p.facing = 0.0
		var ok: bool = st.try_ult()
		check(id + " ult jalan", ok)
		await t.create_timer(0.35).timeout
		await st._shot("ult_%s_a" % id)
		await t.create_timer(0.75).timeout
		await st._shot("ult_%s_b" % id)
		await t.create_timer(0.7).timeout
		await st._shot("ult_%s_c" % id)
		await t.create_timer(1.2).timeout
		var lost := 0
		for e in mons: lost += 100000 - (int(e.hp) if is_instance_valid(e) else 0)
		check(id + " ult melukai musuh", lost > 0, "hp hilang=%d" % lost)
		p._act_t = 0.0
		check(id + " ult kedua ditolak", not st.try_ult() and not st.ult_available())
		await t.create_timer(0.4).timeout
	if only == "":
		# karakter lain di match yang sama masih punya jatah
		p.set_character("ren")
		check("ren sudah pakai -> ditolak", not st.ult_available())
	print("SUMMARY fails=", fails)
