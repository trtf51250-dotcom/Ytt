class_name WorldMats
extends RefCounted
## Pabrik material dunia: atlas tekstur + shader world*.gdshader. Dibagi di seluruh lobi agar draw call sedikit.
## `set_glow()` dipanggil DayNight untuk menaikkan cahaya emisi (lampu, jendela, kristal) saat malam.

const ATLAS_PATH := "res://assets/textures/world_atlas.png"

static var _atlas: Texture2D
static var _opaque: ShaderMaterial
static var _cutout: ShaderMaterial
static var _fades: Array = []
static var _glow := 0.4
static var _wind := 1.0


static func atlas() -> Texture2D:
	if _atlas == null:
		_atlas = load(ATLAS_PATH)
	return _atlas


static func _make(shader_path: String) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = load(shader_path)
	m.set_shader_parameter("atlas", atlas())
	m.set_shader_parameter("glow", _glow)
	m.set_shader_parameter("wind", _wind)
	return m


static func opaque() -> ShaderMaterial:
	if _opaque == null:
		_opaque = _make("res://shaders/world.gdshader")
	return _opaque


static func cutout() -> ShaderMaterial:
	if _cutout == null:
		_cutout = _make("res://shaders/world_cutout.gdshader")
	return _cutout


## Material yang bisa memudar (dither) - satu per bangunan, dipakai saat bangunan menutupi pemain.
static func fade_material() -> ShaderMaterial:
	var m := _make("res://shaders/world_fade.gdshader")
	_fades.append(m)
	return m


static func set_glow(v: float) -> void:
	_glow = v
	for m in [_opaque, _cutout]:
		if m != null:
			m.set_shader_parameter("glow", v)
	for m in _fades:
		(m as ShaderMaterial).set_shader_parameter("glow", v)


static func set_wind(v: float) -> void:
	_wind = v
	for m in [_opaque, _cutout]:
		if m != null:
			m.set_shader_parameter("wind", v)
	for m in _fades:
		(m as ShaderMaterial).set_shader_parameter("wind", v)


## Dipanggil saat scene lobi dibuang agar tidak menyimpan material lama.
static func reset() -> void:
	_fades.clear()
	_opaque = null
	_cutout = null
