class_name Pal
extends RefCounted
## Palet warna dunia: pastel hangat bergaya anime fantasi. Putih-biru-emas = identitas guild & MC.

const WHITE := Color(1.0, 1.0, 1.0)
const CREAM := Color(1.0, 0.96, 0.88)
const IVORY := Color(0.98, 0.95, 0.9)
const STONE := Color(0.88, 0.87, 0.86)
const STONE_DARK := Color(0.66, 0.66, 0.7)
const WOOD := Color(0.95, 0.82, 0.68)
const WOOD_DARK := Color(0.68, 0.5, 0.36)
const GOLD := Color(1.0, 0.84, 0.35)
const BLUE := Color(0.32, 0.55, 0.95)
const BLUE_DEEP := Color(0.2, 0.34, 0.72)
const SKY_BLUE := Color(0.62, 0.8, 1.0)
const TEAL := Color(0.22, 0.72, 0.7)
const RED := Color(0.92, 0.36, 0.32)
const ORANGE := Color(0.98, 0.64, 0.28)
const PURPLE := Color(0.64, 0.46, 0.9)
const PINK := Color(1.0, 0.6, 0.72)
const GREEN := Color(0.42, 0.78, 0.4)
const SLATE := Color(0.42, 0.48, 0.6)
const IRON := Color(0.55, 0.6, 0.68)
const WINDOW_GLOW := Color(1.0, 0.95, 0.8)

const ROOFS := [RED, BLUE, TEAL, ORANGE, PURPLE, Color(0.85, 0.45, 0.55), Color(0.35, 0.6, 0.45)]
const FLOWER_COLORS := [Color(1.0, 0.55, 0.65), Color(0.62, 0.72, 1.0), Color(1.0, 0.9, 0.45), Color(1.0, 1.0, 1.0), Color(0.85, 0.6, 1.0)]


static func roof(i: int) -> Color:
	return ROOFS[posmod(i, ROOFS.size())]
