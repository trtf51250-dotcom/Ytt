class_name ColliderSink
extends RefCounted
## Penampung bentuk tabrakan statis. Pembangun mesh mendaftarkan kotak/silinder (sudah dalam koordinat akar),
## lalu `apply_to()` mengubahnya menjadi CollisionShape3D pada sebuah StaticBody3D (layer 1 = dunia).

var items: Array = []     # {"t": "box"|"cyl", "xf": Transform3D, "size": Vector3, "r": float, "h": float}


## Kotak: xf = transformasi induk (mis. MeshKit.xf), center = pusat lokal, size = ukuran.
func box(xf: Transform3D, center: Vector3, size: Vector3) -> void:
	items.append({"t": "box", "xf": xf * Transform3D(Basis.IDENTITY, center), "size": size})


## Silinder tegak: base = titik pusat alas lokal.
func cyl(xf: Transform3D, base: Vector3, radius: float, height: float) -> void:
	items.append({"t": "cyl", "xf": xf * Transform3D(Basis.IDENTITY, base + Vector3(0, height * 0.5, 0)), "r": radius, "h": height})


func merge(other: ColliderSink, offset: Transform3D) -> void:
	for it in other.items:
		var c: Dictionary = it.duplicate()
		c["xf"] = offset * it["xf"]
		items.append(c)


## Rintangan RENDAH (puncak < LOW_TOP: batu kecil, bangku, peti, planter...) masuk layer 16 sehingga musuh TERBANG bisa melintas di atasnya
## dan peluru tidak tertahan; rintangan tinggi (pilar, pohon, dinding, bangunan) tetap di layer dunia (1) dan menghalangi semuanya.
const LOW_TOP := 1.25
const LOW_LAYER := 16


func _top(it: Dictionary) -> float:
	var xf: Transform3D = it["xf"]
	return xf.origin.y + (float(it["h"]) if it["t"] == "cyl" else float(it["size"].y)) * 0.5


func apply_to(body: StaticBody3D) -> void:
	var low: StaticBody3D = null
	for it in items:
		var cs := CollisionShape3D.new()
		if it["t"] == "box":
			var s := BoxShape3D.new()
			s.size = it["size"]
			cs.shape = s
		else:
			var s := CylinderShape3D.new()
			s.radius = it["r"]
			s.height = it["h"]
			cs.shape = s
		cs.transform = it["xf"]
		if _top(it) < LOW_TOP:
			if low == null:
				low = StaticBody3D.new()
				low.name = "LowBody"
				low.collision_layer = LOW_LAYER
				low.collision_mask = 0
				body.add_child(low)
			low.add_child(cs)
		else:
			body.add_child(cs)
