class_name Story
extends RefCounted
## Data cerita (data/story.json): adegan prolog, pembuka & penutup stage. Status "sudah dibaca" disimpan di GameState.flags["story_<id>"].

const PATH := "res://data/story.json"
static var _scenes: Array = []
static var _loaded := false


static func scenes() -> Array:
	if not _loaded:
		_loaded = true
		var d = JSON.parse_string(FileAccess.get_file_as_string(PATH))
		if d is Dictionary and d.get("scenes") is Array:
			_scenes = d["scenes"]
	return _scenes


static func get_scene(id: String) -> Dictionary:
	for s in scenes():
		if s["id"] == id:
			return s
	return {}


## Id adegan untuk stage + saat ("intro"/"outro"); "" bila tidak ada.
static func for_stage(stage_id: String, when: String) -> String:
	for s in scenes():
		if s.get("stage", "") == stage_id and s.get("when", "") == when:
			return s["id"]
	return ""


static func seen(id: String) -> bool:
	return bool(GameState.flags.get("story_" + id, false))


static func mark_seen(id: String) -> void:
	GameState.flags["story_" + id] = true
	GameState.changed.emit("story")
	GameState.queue_save()
