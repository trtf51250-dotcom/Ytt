class_name Missions
extends RefCounted
## Data misi harian (3 misi per hari, dipilih deterministik dari tanggal) dan pencapaian (sekali seumur hidup).
## Status disimpan di GameState (daily, ach).

const DAILY_GOLD := 300
const DAILY_DIAMOND := 20
const BONUS_DIAMOND := 100
const BONUS_ITEM := "p_small"
const BONUS_ITEM_N := 2

# jenis -> teks. Jenis cocok dengan report_event / pengeluaran gold.
const KIND_TEXT := {
	"kill": "Kalahkan %d monster",
	"clear_stage": "Selesaikan %d stage",
	"summon": "Lakukan %d kali summon di Altar Bintang",
	"upgrade": "Tempa/upgrade senjata %d kali",
	"spend": "Habiskan %d gold",
}

# tingkat ketiga: pilih satu
const THIRD := [["summon", 1], ["upgrade", 1], ["spend", 500]]

# pencapaian: id, judul, sumber, target, hadiah diamond (+gold)
const ACH := [
	{"id": "kill_50", "title": "Pemburu Pemula", "src": "kills", "need": 50, "dia": 50, "gold": 300},
	{"id": "kill_300", "title": "Pemburu Berpengalaman", "src": "kills", "need": 300, "dia": 150, "gold": 1000},
	{"id": "kill_1000", "title": "Penakluk Monster", "src": "kills", "need": 1000, "dia": 400, "gold": 3000},
	{"id": "clear_3", "title": "Penjelajah", "src": "stages_cleared", "need": 3, "dia": 60, "gold": 400},
	{"id": "clear_9", "title": "Penakluk Peta", "src": "stages_cleared", "need": 9, "dia": 250, "gold": 2000},
	{"id": "pull_10", "title": "Pemanggil Bintang", "src": "pulls", "need": 10, "dia": 60, "gold": 0},
	{"id": "pull_50", "title": "Kolektor Bintang", "src": "pulls", "need": 50, "dia": 200, "gold": 0},
	{"id": "lv_5", "title": "Petualang Lv 5", "src": "level", "need": 5, "dia": 60, "gold": 300},
	{"id": "lv_15", "title": "Petualang Lv 15", "src": "level", "need": 15, "dia": 200, "gold": 1500},
	{"id": "chars_4", "title": "Satu Tim Penuh", "src": "chars", "need": 4, "dia": 100, "gold": 500},
	{"id": "chars_6", "title": "Kolektor Pahlawan", "src": "chars", "need": 6, "dia": 300, "gold": 1500},
	{"id": "smith_5", "title": "Pandai Besi", "src": "upgrades", "need": 5, "dia": 80, "gold": 500},
]


## 3 misi untuk tanggal tertentu: [{kind, need}] — urutan & jumlah sama untuk tanggal yang sama.
static func daily_for(date: String) -> Array:
	var h := date.hash()
	var kills := [20, 30, 40]
	var clears := [1, 2]
	var third: Array = THIRD[(h >> 3) % THIRD.size()]
	return [
		{"kind": "kill", "need": kills[h % kills.size()]},
		{"kind": "clear_stage", "need": clears[(h >> 1) % clears.size()]},
		{"kind": third[0], "need": third[1]},
	]


static func text_for(kind: String, need: int) -> String:
	return KIND_TEXT[kind] % need
