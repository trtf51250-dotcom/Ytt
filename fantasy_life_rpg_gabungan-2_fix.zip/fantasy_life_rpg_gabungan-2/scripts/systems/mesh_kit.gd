class_name MeshKit
extends RefCounted
## Pembangun mesh prosedural untuk dunia lobi: kotak, silinder/kerucut, bola, atap pelana, pita jalan, cincin, dll.
## Semua primitif ditulis ke satu set array (satu surface) dengan konvensi shader world*.gdshader:
##   UV = satuan ulangan petak, UV2.x = nomor petak atlas, UV2.y = bobot angin, COLOR.rgb = pewarna, COLOR.a = 1 - emisi.
## Koordinat dilokalkan lewat tumpukan transformasi (push/pop/move/yaw) sehingga bangunan mudah dirakit.

# Nomor petak atlas (sama dengan tools/gen_textures.py)
const T_GRASS := 0
const T_COBBLE := 1
const T_PLASTER := 2
const T_BRICK := 3
const T_WOOD := 4
const T_ROOF := 5
const T_PLAZA := 6
const T_DIRT := 7
const T_LEAVES := 8
const T_BARK := 9
const T_TIMBER := 10
const T_WATER := 11
const T_METAL := 12
const T_THATCH := 13
const T_WINDOW := 14
const T_DOOR := 15
const T_TUFT := 16
const T_FLOWER := 17
const T_CLOTH := 18
const T_EMBLEM := 19
const T_CRYSTAL := 20
const T_STRIPE := 21
const T_MARBLE := 22
const T_SAND := 23

var verts := PackedVector3Array()
var norms := PackedVector3Array()
var uvs := PackedVector2Array()
var uv2s := PackedVector2Array()
var cols := PackedColorArray()
# Surface kedua: cutout (rumput, bunga, daun kartu, spanduk) - dipakai bila `cut` = true
var cverts := PackedVector3Array()
var cnorms := PackedVector3Array()
var cuvs := PackedVector2Array()
var cuv2s := PackedVector2Array()
var ccols := PackedColorArray()
var cut := false            # true = primitif berikutnya masuk ke surface cutout
var surface_opaque := -1    # indeks surface setelah build()
var surface_cut := -1

var xf := Transform3D.IDENTITY
var uv_size := 2.0          # satu ulangan tekstur = uv_size meter
var sway := 0.0             # bobot angin tambahan untuk semua titik berikutnya
var rng := RandomNumberGenerator.new()
var _stack: Array = []


func _init(seed_value: int = 1) -> void:
	rng.seed = seed_value


# =====================================================================
#  Transformasi lokal
# =====================================================================
func push() -> MeshKit:
	_stack.append(xf)
	return self


func pop() -> MeshKit:
	xf = _stack.pop_back()
	return self


func move(x: float, y: float, z: float) -> MeshKit:
	xf = xf.translated_local(Vector3(x, y, z))
	return self


func yaw(deg: float) -> MeshKit:
	xf = xf.rotated_local(Vector3.UP, deg_to_rad(deg))
	return self


func pitch(deg: float) -> MeshKit:
	xf = xf.rotated_local(Vector3.RIGHT, deg_to_rad(deg))
	return self


func roll(deg: float) -> MeshKit:
	xf = xf.rotated_local(Vector3.BACK, deg_to_rad(deg))
	return self


func vertex_count() -> int:
	return verts.size() + cverts.size()


# =====================================================================
#  Util warna
# =====================================================================
## Warna bercahaya: emit 0..1 (0 = tidak menyala).
static func glow(c: Color, emit: float = 1.0) -> Color:
	return Color(c.r, c.g, c.b, 1.0 - emit)


func jitter(c: Color, amount: float = 0.06) -> Color:
	var f := 1.0 + rng.randf_range(-amount, amount)
	var h := rng.randf_range(-amount, amount) * 0.25
	return Color(clampf(c.r * f + h, 0, 1), clampf(c.g * f, 0, 1), clampf(c.b * f - h, 0, 1), c.a)


static func _shade(c: Color, f: float) -> Color:
	return Color(c.r * f, c.g * f, c.b * f, c.a)


# =====================================================================
#  Emisi titik
# =====================================================================
func _vtx(p: Vector3, n: Vector3, uv: Vector2, tile: int, col: Color, sw: float) -> void:
	if cut:
		cverts.append(xf * p)
		cnorms.append((xf.basis * n).normalized())
		cuvs.append(uv)
		cuv2s.append(Vector2(float(tile), sw + sway))
		ccols.append(col)
		return
	verts.append(xf * p)
	norms.append((xf.basis * n).normalized())
	uvs.append(uv)
	uv2s.append(Vector2(float(tile), sw + sway))
	cols.append(col)


## Segitiga berurutan berlawanan jarum jam dilihat dari sisi depan (a,b,c).
func tri(a: Vector3, b: Vector3, c: Vector3, tile: int, col: Color, uva: Vector2, uvb: Vector2, uvc: Vector2,
		sw_a: float = 0.0, sw_b: float = 0.0, sw_c: float = 0.0) -> void:
	var n := (b - a).cross(c - a).normalized()
	# Godot memakai urutan searah jarum jam untuk sisi depan
	_vtx(a, n, uva, tile, col, sw_a)
	_vtx(c, n, uvc, tile, col, sw_c)
	_vtx(b, n, uvb, tile, col, sw_b)


func tri_n(a: Vector3, b: Vector3, c: Vector3, na: Vector3, nb: Vector3, nc: Vector3, tile: int, col_a: Color, col_b: Color,
		col_c: Color, uva: Vector2, uvb: Vector2, uvc: Vector2) -> void:
	_vtx(a, na, uva, tile, col_a, 0.0)
	_vtx(c, nc, uvc, tile, col_c, 0.0)
	_vtx(b, nb, uvb, tile, col_b, 0.0)


## Segiempat p0 (kiri-bawah), p1 (kanan-bawah), p2 (kanan-atas), p3 (kiri-atas), berlawanan jarum jam dari sisi depan.
## UV otomatis berdasarkan ukuran dunia (uv_size). shade_bottom menggelapkan sisi bawah (AO palsu). sw: bobot angin atas.
func quad(p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, tile: int, col: Color, shade_bottom: float = 1.0,
		sw_top: float = 0.0, uv_mul: float = 1.0) -> void:
	var e1 := p1 - p0
	var e2 := p3 - p0
	var n := e1.cross(e2).normalized()
	var u1 := e1.length() / uv_size * uv_mul
	var v1 := e2.length() / uv_size * uv_mul
	var cb := _shade(col, shade_bottom)
	_vtx(p0, n, Vector2(0, v1), tile, cb, 0.0)
	_vtx(p2, n, Vector2(u1, 0), tile, col, sw_top)
	_vtx(p1, n, Vector2(u1, v1), tile, cb, 0.0)
	_vtx(p0, n, Vector2(0, v1), tile, cb, 0.0)
	_vtx(p3, n, Vector2(0, 0), tile, col, sw_top)
	_vtx(p2, n, Vector2(u1, 0), tile, col, sw_top)


## Segiempat dengan UV eksplisit & warna per sudut. Urutan titik bebas; sisi depan ditentukan oleh `hint` (arah normal keluar).
func quad_free(p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, hint: Vector3, tile: int, c0: Color, c1: Color, c2: Color,
		c3: Color, uv0: Vector2, uv1: Vector2, uv2: Vector2, uv3: Vector2, n0 := Vector3.ZERO, n1 := Vector3.ZERO,
		n2 := Vector3.ZERO, n3 := Vector3.ZERO, sw: float = 0.0) -> void:
	var n := (p1 - p0).cross(p3 - p0)
	if n.length() < 0.000001:
		n = (p2 - p1).cross(p3 - p1)
	var flat := n.normalized()
	if flat.dot(hint) < 0.0:
		# balik: tukar sehingga searah hint
		var t := p1
		p1 = p3
		p3 = t
		var tc := c1
		c1 = c3
		c3 = tc
		var tu := uv1
		uv1 = uv3
		uv3 = tu
		var tn := n1
		n1 = n3
		n3 = tn
		flat = -flat
	if n0 == Vector3.ZERO:
		n0 = flat
	if n1 == Vector3.ZERO:
		n1 = flat
	if n2 == Vector3.ZERO:
		n2 = flat
	if n3 == Vector3.ZERO:
		n3 = flat
	_vtx(p0, n0, uv0, tile, c0, sw)
	_vtx(p2, n2, uv2, tile, c2, sw)
	_vtx(p1, n1, uv1, tile, c1, sw)
	_vtx(p0, n0, uv0, tile, c0, sw)
	_vtx(p3, n3, uv3, tile, c3, sw)
	_vtx(p2, n2, uv2, tile, c2, sw)


# =====================================================================
#  Primitif
# =====================================================================
## Kotak. center = titik tengah. tile_top < 0 berarti sama dengan sisi. bottom = gambar alas juga.
func box(center: Vector3, size: Vector3, tile_side: int, col: Color, tile_top: int = -1, col_top: Color = Color(0, 0, 0, 0),
		shade_bottom: float = 0.8, bottom: bool = false) -> void:
	var h := size * 0.5
	var ct := col if col_top.a == 0.0 and col_top.r == 0.0 and col_top.g == 0.0 and col_top.b == 0.0 else col_top
	var tt := tile_top if tile_top >= 0 else tile_side
	var c := center
	# +Z
	quad(c + Vector3(-h.x, -h.y, h.z), c + Vector3(h.x, -h.y, h.z), c + Vector3(h.x, h.y, h.z), c + Vector3(-h.x, h.y, h.z), tile_side, _shade(col, 1.0), shade_bottom)
	# -Z
	quad(c + Vector3(h.x, -h.y, -h.z), c + Vector3(-h.x, -h.y, -h.z), c + Vector3(-h.x, h.y, -h.z), c + Vector3(h.x, h.y, -h.z), tile_side, _shade(col, 0.92), shade_bottom)
	# +X
	quad(c + Vector3(h.x, -h.y, h.z), c + Vector3(h.x, -h.y, -h.z), c + Vector3(h.x, h.y, -h.z), c + Vector3(h.x, h.y, h.z), tile_side, _shade(col, 0.96), shade_bottom)
	# -X
	quad(c + Vector3(-h.x, -h.y, -h.z), c + Vector3(-h.x, -h.y, h.z), c + Vector3(-h.x, h.y, h.z), c + Vector3(-h.x, h.y, -h.z), tile_side, _shade(col, 0.9), shade_bottom)
	# atas
	quad(c + Vector3(-h.x, h.y, h.z), c + Vector3(h.x, h.y, h.z), c + Vector3(h.x, h.y, -h.z), c + Vector3(-h.x, h.y, -h.z), tt, ct)
	if bottom:
		quad(c + Vector3(-h.x, -h.y, -h.z), c + Vector3(h.x, -h.y, -h.z), c + Vector3(h.x, -h.y, h.z), c + Vector3(-h.x, -h.y, h.z), tile_side, _shade(col, 0.6))


## Kotak dengan titik pusat di dasar (lebih mudah untuk bangunan).
func box_b(base: Vector3, size: Vector3, tile_side: int, col: Color, tile_top: int = -1, col_top: Color = Color(0, 0, 0, 0),
		shade_bottom: float = 0.8) -> void:
	box(base + Vector3(0, size.y * 0.5, 0), size, tile_side, col, tile_top, col_top, shade_bottom)


## Silinder / kerucut terpancung. base = titik tengah alas. r_top = 0 menjadi kerucut.
func cylinder(base: Vector3, r_bottom: float, r_top: float, h: float, seg: int, tile: int, col: Color, cap_top: bool = true,
		tile_cap: int = -1, smooth: bool = true, shade_bottom: float = 0.8, cap_bottom: bool = false, sw_top: float = 0.0) -> void:
	var da := TAU / seg
	var slope := (r_bottom - r_top) / maxf(h, 0.0001)
	var cb := _shade(col, shade_bottom)
	var tc := tile_cap if tile_cap >= 0 else tile
	for i in seg:
		var a0 := i * da
		var a1 := (i + 1) * da
		var d0 := Vector3(cos(a0), 0, sin(a0))
		var d1 := Vector3(cos(a1), 0, sin(a1))
		var b0 := base + d0 * r_bottom
		var b1 := base + d1 * r_bottom
		var t0 := base + Vector3(0, h, 0) + d0 * r_top
		var t1 := base + Vector3(0, h, 0) + d1 * r_top
		var n0 := (d0 + Vector3(0, slope, 0)).normalized()
		var n1 := (d1 + Vector3(0, slope, 0)).normalized()
		var nm := ((d0 + d1) * 0.5 + Vector3(0, slope, 0)).normalized()
		if not smooth:
			n0 = nm
			n1 = nm
		var u0 := a0 * r_bottom / uv_size
		var u1 := a1 * r_bottom / uv_size
		var v := h / uv_size
		if r_top < 0.001:
			# kerucut: segitiga
			var uvm := Vector2((u0 + u1) * 0.5, 0)
			quad_free(b0, b1, t0, t0, nm, tile, cb, cb, col, col, Vector2(u0, v), Vector2(u1, v), uvm, uvm, n0, n1, nm, nm, sw_top)
		else:
			quad_free(b0, b1, t1, t0, nm, tile, cb, cb, col, col, Vector2(u0, v), Vector2(u1, v), Vector2(u1 * r_top / maxf(r_bottom, 0.001), 0), Vector2(u0 * r_top / maxf(r_bottom, 0.001), 0), n0, n1, n1, n0, sw_top)
	if cap_top and r_top > 0.001:
		var c := base + Vector3(0, h, 0)
		for i in seg:
			var d0 := Vector3(cos(i * da), 0, sin(i * da))
			var d1 := Vector3(cos((i + 1) * da), 0, sin((i + 1) * da))
			quad_free(c, c + d0 * r_top, c + d1 * r_top, c + d1 * r_top, Vector3.UP, tc, col, col, col, col,
				Vector2(c.x, c.z) / uv_size, Vector2(c.x + d0.x * r_top, c.z + d0.z * r_top) / uv_size,
				Vector2(c.x + d1.x * r_top, c.z + d1.z * r_top) / uv_size, Vector2(c.x + d1.x * r_top, c.z + d1.z * r_top) / uv_size)
	if cap_bottom and r_bottom > 0.001:
		for i in seg:
			var d0 := Vector3(cos(i * da), 0, sin(i * da))
			var d1 := Vector3(cos((i + 1) * da), 0, sin((i + 1) * da))
			quad_free(base, base + d0 * r_bottom, base + d1 * r_bottom, base + d1 * r_bottom, Vector3.DOWN, tc, cb, cb, cb, cb,
				Vector2.ZERO, Vector2(d0.x, d0.z) * r_bottom / uv_size, Vector2(d1.x, d1.z) * r_bottom / uv_size, Vector2(d1.x, d1.z) * r_bottom / uv_size)


## Dinding silinder yang menghadap ke dalam (sisi dalam bak air / kolam).
func tube_inner(base: Vector3, r: float, h: float, seg: int, tile: int, col: Color, shade_bottom: float = 0.8) -> void:
	var da := TAU / seg
	var cb := _shade(col, shade_bottom)
	for i in seg:
		var a0 := i * da
		var a1 := (i + 1) * da
		var d0 := Vector3(cos(a0), 0, sin(a0))
		var d1 := Vector3(cos(a1), 0, sin(a1))
		var b0 := base + d0 * r
		var b1 := base + d1 * r
		var up := Vector3(0, h, 0)
		var nm := -((d0 + d1) * 0.5).normalized()
		quad_free(b0, b1, b1 + up, b0 + up, nm, tile, cb, cb, col, col,
			Vector2(a0 * r / uv_size, h / uv_size), Vector2(a1 * r / uv_size, h / uv_size), Vector2(a1 * r / uv_size, 0), Vector2(a0 * r / uv_size, 0),
			-d0, -d1, -d1, -d0)


## Bola/blob berhalus (daun pohon, semak, kubah). sx/sy/sz = peregangan sumbu. grad = kekuatan gradasi terang-atas.
func blob(center: Vector3, r: float, tile: int, col: Color, rings: int = 5, seg: int = 8, sy: float = 1.0, grad: float = 0.35,
		sw: float = 0.0, sx: float = 1.0, sz: float = 1.0) -> void:
	var da := TAU / seg
	var dt := PI / rings
	var cache: Array = []
	for j in rings + 1:
		var row: Array = []
		var th := j * dt
		for i in seg + 1:
			var ph := i * da
			var d := Vector3(sin(th) * cos(ph), cos(th), sin(th) * sin(ph))
			var p := center + Vector3(d.x * r * sx, d.y * r * sy, d.z * r * sz)
			var f := 1.0 - grad + grad * (0.5 + 0.5 * d.y) * 1.6
			row.append([p, d, Color(col.r * f, col.g * f, col.b * f, col.a), Vector2(float(i) / seg * r * 2.5 / uv_size, float(j) / rings * r * 2.0 / uv_size)])
		cache.append(row)
	for j in rings:
		for i in seg:
			var a: Array = cache[j][i]
			var b: Array = cache[j][i + 1]
			var c: Array = cache[j + 1][i + 1]
			var d: Array = cache[j + 1][i]
			var hint: Vector3 = (a[1] + b[1] + c[1] + d[1])
			var sww: float = sw * (0.5 + 0.5 * (a[1].y + 1.0) * 0.5)
			quad_free(a[0], b[0], c[0], d[0], hint, tile, a[2], b[2], c[2], d[2], a[3], b[3], c[3], d[3], a[1], b[1], c[1], d[1], sww)


## Atap pelana. base = titik tengah bawah (tepi dinding atas), w sepanjang X, d sepanjang Z, h tinggi bubungan.
## Punggung atap sejajar sumbu X. Dinding gable ditambahkan di kedua ujung.
func gable_roof(base: Vector3, w: float, d: float, h: float, overhang: float, tile_roof: int, col_roof: Color, tile_wall: int,
		col_wall: Color, ridge_cap: bool = true, col_under: Color = Color(0.55, 0.45, 0.38)) -> void:
	var hw := w * 0.5
	var hd := d * 0.5
	var o := overhang
	var b := base
	var cf := col_roof
	# lereng depan (+Z) dan belakang (-Z)
	quad(b + Vector3(-hw - o, 0, hd + o), b + Vector3(hw + o, 0, hd + o), b + Vector3(hw + o, h, 0), b + Vector3(-hw - o, h, 0), tile_roof, cf, 0.8, 0.0, 1.0)
	quad(b + Vector3(hw + o, 0, -hd - o), b + Vector3(-hw - o, 0, -hd - o), b + Vector3(-hw - o, h, 0), b + Vector3(hw + o, h, 0), tile_roof, _shade(cf, 0.9), 0.8, 0.0, 1.0)
	# sisi bawah atap (terlihat dari bawah pada tritisan)
	quad(b + Vector3(hw + o, 0, hd + o), b + Vector3(-hw - o, 0, hd + o), b + Vector3(-hw - o, h, 0), b + Vector3(hw + o, h, 0), T_WOOD, col_under, 0.8)
	quad(b + Vector3(-hw - o, 0, -hd - o), b + Vector3(hw + o, 0, -hd - o), b + Vector3(hw + o, h, 0), b + Vector3(-hw - o, h, 0), T_WOOD, col_under, 0.8)
	# dinding gable (segitiga) di kedua ujung
	var zc := hd + o
	_gable_tri(b + Vector3(hw, 0, 0), zc, h, 1.0, tile_wall, col_wall)
	_gable_tri(b + Vector3(-hw, 0, 0), zc, h, -1.0, tile_wall, col_wall)
	if ridge_cap:
		box(b + Vector3(0, h + 0.04, 0), Vector3(w + 2.0 * o + 0.1, 0.16, 0.34), T_WOOD, _shade(cf, 0.6), T_WOOD, _shade(cf, 0.6))


func _gable_tri(c: Vector3, zc: float, h: float, side: float, tile: int, col: Color) -> void:
	# segitiga di bidang X = c.x, normal = side * X
	var n := Vector3(side, 0, 0)
	var a := c + Vector3(0, 0, zc * side)
	var b := c + Vector3(0, 0, -zc * side)
	var t := c + Vector3(0, h, 0)
	var uh := h / uv_size
	var uw := zc * 2.0 / uv_size
	_vtx(a, n, Vector2(0, uh), tile, _shade(col, 0.82), 0.0)
	_vtx(t, n, Vector2(uw * 0.5, 0), tile, col, 0.0)
	_vtx(b, n, Vector2(uw, uh), tile, _shade(col, 0.82), 0.0)


## Atap limas/kerucut bersegmen (menara). Bisa melebar sedikit di bawah (flare) untuk bentuk fantasi.
func spire(base: Vector3, r: float, h: float, seg: int, tile: int, col: Color, flare: float = 0.0) -> void:
	if flare > 0.0:
		cylinder(base, r + flare, r, h * 0.28, seg, tile, col, false, -1, false, 0.85)
		cylinder(base + Vector3(0, h * 0.28, 0), r, 0.0, h * 0.72, seg, tile, col, false, -1, false, 0.9)
	else:
		cylinder(base, r, 0.0, h, seg, tile, col, false, -1, false, 0.85)


## Permukaan datar horizontal (UV planar dunia): persegi panjang pusat c, ukuran sx x sz.
func plane(c: Vector3, sx: float, sz: float, tile: int, col: Color, uv_mul: float = 1.0) -> void:
	var hx := sx * 0.5
	var hz := sz * 0.5
	var u0 := Vector2(c.x - hx, c.z - hz) / uv_size * uv_mul
	var u1 := Vector2(c.x + hx, c.z + hz) / uv_size * uv_mul
	quad_free(c + Vector3(-hx, 0, hz), c + Vector3(hx, 0, hz), c + Vector3(hx, 0, -hz), c + Vector3(-hx, 0, -hz), Vector3.UP, tile,
		col, col, col, col, Vector2(u0.x, u1.y), Vector2(u1.x, u1.y), Vector2(u1.x, u0.y), Vector2(u0.x, u0.y))


## Cakram datar horizontal (alun-alun, lantai portal).
func disc(c: Vector3, r: float, seg: int, tile: int, col: Color, uv_mul: float = 1.0) -> void:
	var da := TAU / seg
	for i in seg:
		var d0 := Vector3(cos(i * da), 0, sin(i * da)) * r
		var d1 := Vector3(cos((i + 1) * da), 0, sin((i + 1) * da)) * r
		var uc := Vector2(c.x, c.z) / uv_size * uv_mul
		var u0 := Vector2(c.x + d0.x, c.z + d0.z) / uv_size * uv_mul
		var u1 := Vector2(c.x + d1.x, c.z + d1.z) / uv_size * uv_mul
		quad_free(c, c + d0, c + d1, c + d1, Vector3.UP, tile, col, col, col, col, uc, u0, u1, u1)


## Cincin datar horizontal (jalan melingkar di sekeliling plaza).
func ring(c: Vector3, r_in: float, r_out: float, seg: int, tile: int, col: Color, uv_mul: float = 1.0) -> void:
	var da := TAU / seg
	for i in seg:
		var d0 := Vector3(cos(i * da), 0, sin(i * da))
		var d1 := Vector3(cos((i + 1) * da), 0, sin((i + 1) * da))
		var a := c + d0 * r_in
		var b := c + d1 * r_in
		var cc := c + d1 * r_out
		var d := c + d0 * r_out
		quad_free(a, b, cc, d, Vector3.UP, tile, col, col, col, col,
			Vector2(a.x, a.z) / uv_size * uv_mul, Vector2(b.x, b.z) / uv_size * uv_mul,
			Vector2(cc.x, cc.z) / uv_size * uv_mul, Vector2(d.x, d.z) / uv_size * uv_mul)


## Pita jalan mengikuti polyline (titik di bidang XZ). width = lebar total. y_off = tinggi dari titik.
func ribbon(points: PackedVector3Array, width: float, tile: int, col: Color, y_off: float = 0.0, edge_dark: float = 1.0) -> void:
	var dist := 0.0
	var hw := width * 0.5
	for i in points.size() - 1:
		var a := points[i]
		var b := points[i + 1]
		var t := (b - a)
		t.y = 0.0
		var seglen := t.length()
		if seglen < 0.001:
			continue
		t = t / seglen
		var ta: Vector3 = t
		var tb: Vector3 = t
		if i > 0:
			ta = ((points[i] - points[i - 1]) * Vector3(1, 0, 1)).normalized()
			ta = (ta + t).normalized()
		if i < points.size() - 2:
			tb = ((points[i + 2] - points[i + 1]) * Vector3(1, 0, 1)).normalized()
			tb = (tb + t).normalized()
		var sa := Vector3(ta.z, 0, -ta.x)
		var sb := Vector3(tb.z, 0, -tb.x)
		var up := Vector3(0, y_off, 0)
		var l0 := a + sa * hw + up
		var r0 := a - sa * hw + up
		var l1 := b + sb * hw + up
		var r1 := b - sb * hw + up
		var v0 := dist / uv_size
		var v1 := (dist + seglen) / uv_size
		var uw := width / uv_size
		var cd := _shade(col, edge_dark)
		quad_free(l0, r0, r1, l1, Vector3.UP, tile, cd, cd, cd, cd, Vector2(0, v0), Vector2(uw, v0), Vector2(uw, v1), Vector2(0, v1))
		dist += seglen


## Cincin 3D (torus) berdiri: lingkaran di bidang XY (menghadap +Z), pusat c. R = jari-jari besar, r = tebal tabung.
func torus_xy(c: Vector3, R: float, r: float, seg_major: int, seg_minor: int, tile: int, col: Color, arc_from: float = 0.0,
		arc_to: float = TAU) -> void:
	var step := (arc_to - arc_from) / seg_major
	var dm := TAU / seg_minor
	for i in seg_major:
		var a0 := arc_from + i * step
		var a1 := a0 + step
		var o0 := Vector3(cos(a0), sin(a0), 0)
		var o1 := Vector3(cos(a1), sin(a1), 0)
		for j in seg_minor:
			var b0 := j * dm
			var b1 := b0 + dm
			var n00 := o0 * cos(b0) + Vector3(0, 0, sin(b0))
			var n10 := o1 * cos(b0) + Vector3(0, 0, sin(b0))
			var n11 := o1 * cos(b1) + Vector3(0, 0, sin(b1))
			var n01 := o0 * cos(b1) + Vector3(0, 0, sin(b1))
			var p00 := c + o0 * R + n00 * r
			var p10 := c + o1 * R + n10 * r
			var p11 := c + o1 * R + n11 * r
			var p01 := c + o0 * R + n01 * r
			var hint := n00 + n10 + n11 + n01
			var uu0 := float(i) / seg_major * R * TAU / uv_size
			var uu1 := float(i + 1) / seg_major * R * TAU / uv_size
			quad_free(p00, p10, p11, p01, hint, tile, col, col, col, col, Vector2(uu0, float(j) / seg_minor), Vector2(uu1, float(j) / seg_minor),
				Vector2(uu1, float(j + 1) / seg_minor), Vector2(uu0, float(j + 1) / seg_minor), n00, n10, n11, n01)


## Dua bidang menyilang (rumput, bunga) dua sisi; tinggi h dari dasar `base`. sw = bobot angin ujung atas.
func cross_quads(base: Vector3, w: float, h: float, tile: int, col: Color, sw: float = 1.0, yaw_deg: float = 0.0) -> void:
	for k in 2:
		var ang := deg_to_rad(yaw_deg + 90.0 * k)
		var dx := Vector3(cos(ang), 0, sin(ang)) * (w * 0.5)
		var n := Vector3(-sin(ang), 0, cos(ang))
		var p0 := base - dx
		var p1 := base + dx
		var p2 := base + dx + Vector3(0, h, 0)
		var p3 := base - dx + Vector3(0, h, 0)
		var cb := _shade(col, 0.75)
		_vtx(p0, n, Vector2(0, 1), tile, cb, 0.0)
		_vtx(p2, n, Vector2(1, 0), tile, col, sw)
		_vtx(p1, n, Vector2(1, 1), tile, cb, 0.0)
		_vtx(p0, n, Vector2(0, 1), tile, cb, 0.0)
		_vtx(p3, n, Vector2(0, 0), tile, col, sw)
		_vtx(p2, n, Vector2(1, 0), tile, col, sw)


## Kristal runcing (dua piramida bersambung) dengan warna bercahaya.
func crystal(base: Vector3, r: float, h: float, col: Color, emit: float = 0.8, seg: int = 5, tilt_deg: float = 0.0) -> void:
	push()
	move(base.x, base.y, base.z)
	pitch(tilt_deg)
	var c := glow(col, emit)
	cylinder(Vector3.ZERO, r, 0.0, h, seg, T_CRYSTAL, c, false, -1, false, 1.0)
	cylinder(Vector3.ZERO, r, 0.0, -h * 0.35, seg, T_CRYSTAL, c, false, -1, false, 1.0)
	pop()


## Tangga (balok bertingkat) menuju +Z dari base, naik sebesar rise ke arah -Z. width sepanjang X.
func stairs(base: Vector3, width: float, run_total: float, rise: float, steps: int, tile: int, col: Color) -> void:
	var sh := rise / steps
	var sd := run_total / steps
	for i in steps:
		var h := sh * (i + 1)
		box(base + Vector3(0, h * 0.5, -sd * (i + 0.5)), Vector3(width, h, sd), tile, col, tile, col, 0.85)


# =====================================================================
#  Hasil
# =====================================================================
func build() -> ArrayMesh:
	var mesh := ArrayMesh.new()
	surface_opaque = -1
	surface_cut = -1
	if not verts.is_empty():
		var arrays := []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = verts
		arrays[Mesh.ARRAY_NORMAL] = norms
		arrays[Mesh.ARRAY_TEX_UV] = uvs
		arrays[Mesh.ARRAY_TEX_UV2] = uv2s
		arrays[Mesh.ARRAY_COLOR] = cols
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
		surface_opaque = mesh.get_surface_count() - 1
	if not cverts.is_empty():
		var arrays2 := []
		arrays2.resize(Mesh.ARRAY_MAX)
		arrays2[Mesh.ARRAY_VERTEX] = cverts
		arrays2[Mesh.ARRAY_NORMAL] = cnorms
		arrays2[Mesh.ARRAY_TEX_UV] = cuvs
		arrays2[Mesh.ARRAY_TEX_UV2] = cuv2s
		arrays2[Mesh.ARRAY_COLOR] = ccols
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays2)
		surface_cut = mesh.get_surface_count() - 1
	return mesh


## Pasang material standar dunia (opaque + cutout) pada mesh hasil build().
func apply_materials(mesh: ArrayMesh) -> void:
	if surface_opaque >= 0:
		mesh.surface_set_material(surface_opaque, WorldMats.opaque())
	if surface_cut >= 0:
		mesh.surface_set_material(surface_cut, WorldMats.cutout())


func clear() -> void:
	verts = PackedVector3Array()
	norms = PackedVector3Array()
	uvs = PackedVector2Array()
	uv2s = PackedVector2Array()
	cols = PackedColorArray()
	cverts = PackedVector3Array()
	cnorms = PackedVector3Array()
	cuvs = PackedVector2Array()
	cuv2s = PackedVector2Array()
	ccols = PackedColorArray()
	cut = false
	_stack.clear()
	xf = Transform3D.IDENTITY
