class_name CameraRig
extends Node3D
## Kamera pengikut gaya RPG/Guardian Tales: sudut miring dari atas-belakang, bisa diputar (seret layar / Q-R), zoom (cubit / roda mouse).
## Struktur: CameraRig(posisi mengikuti target) > Yaw > Pitch > Camera3D.

signal changed

var target: Node3D
var cam: Camera3D
var yaw := 0.0                           # radian; 0 = kamera di sisi +Z target, memandang ke -Z
var pitch := deg_to_rad(42.0)
var distance := 12.5
var min_distance := 6.0
var max_distance := 22.0
var min_pitch := deg_to_rad(8.0)
var max_pitch := deg_to_rad(72.0)
var height_offset := 1.5
var focus_node: Node3D = null            # opsional: kamera condong ke node ini (mis. bos tinggi)
var focus_bias := 0.0                    # 0..1 porsi jarak target->focus_node
var focus_lift := 0.0
var follow_speed := 9.0
var rim_radius := 0.0                    # >0: bila kamera melewati jarak ini dari pusat arena, kamera naik (pitch lebih tinggi) agar tidak menembus tajuk pohon tepi arena
var _rim_t := 0.0
var sensitivity := 0.005
var invert_y := false
var auto_center := false

var _yaw_node: Node3D
var _pitch_node: Node3D
var _drag_touch := -1
var _touches := {}
var _pinch_start := 0.0
var _pinch_dist0 := 0.0
var _shake := 0.0
var enabled := true
var blocked_rects: Array = []              # Rect2 layar (sentuhan di sini tidak memutar kamera, mis. joystick/tombol)


func _ready() -> void:
	_yaw_node = Node3D.new()
	_yaw_node.name = "Yaw"
	add_child(_yaw_node)
	_pitch_node = Node3D.new()
	_pitch_node.name = "Pitch"
	_yaw_node.add_child(_pitch_node)
	cam = Camera3D.new()
	cam.name = "Camera"
	cam.fov = 50.0
	cam.near = 0.3
	cam.far = 520.0
	_pitch_node.add_child(cam)
	cam.current = true
	apply_settings()
	_apply_transform()


func apply_settings() -> void:
	distance = 12.5 * float(GameState.setting("cam_zoom"))
	pitch = deg_to_rad(float(GameState.setting("cam_pitch")))
	sensitivity = 0.0035 + 0.0045 * float(GameState.setting("cam_sens"))
	invert_y = bool(GameState.setting("cam_invert_y"))
	cam.fov = float(GameState.setting("cam_fov"))
	changed.emit()


func snap_to_target() -> void:
	if target:
		global_position = target.global_position + Vector3(0, height_offset, 0)


func _apply_transform(delta: float = 0.0) -> void:
	var eff_pitch := pitch
	if rim_radius > 0.0:
		var off := Vector3(sin(yaw), 0, cos(yaw)) * distance * cos(pitch)
		var cp := global_position + off
		var over := Vector2(cp.x, cp.z).length() - rim_radius
		var goal := clampf(over / 5.0, 0.0, 1.0)
		_rim_t = lerpf(_rim_t, goal, 1.0 - exp(-6.0 * delta)) if delta > 0.0 else goal
		eff_pitch = lerpf(pitch, maxf(pitch, deg_to_rad(74.0)), _rim_t)
	_yaw_node.rotation.y = yaw
	_pitch_node.rotation.x = -eff_pitch
	cam.position = Vector3(0, 0, distance)


func shake(amount: float = 0.25) -> void:
	_shake = maxf(_shake, amount)


func _process(delta: float) -> void:
	if target:
		var goal := target.global_position + Vector3(0, height_offset, 0)
		if focus_node != null and is_instance_valid(focus_node) and focus_bias > 0.0:
			var d := focus_node.global_position - target.global_position
			d.y = 0.0
			goal += d * focus_bias + Vector3(0, focus_lift, 0)
		global_position = global_position.lerp(goal, 1.0 - exp(-follow_speed * delta))
	distance = clampf(distance, min_distance, max_distance)
	pitch = clampf(pitch, min_pitch, max_pitch)
	if enabled:
		var rot := Input.get_axis("cam_left", "cam_right")
		if rot != 0.0:
			yaw -= rot * 1.8 * delta
	_apply_transform(delta)
	if _shake > 0.0:
		_shake = maxf(_shake - delta * 1.5, 0.0)
		cam.h_offset = randf_range(-_shake, _shake) * 0.4
		cam.v_offset = randf_range(-_shake, _shake) * 0.4
	elif cam.h_offset != 0.0:
		cam.h_offset = 0.0
		cam.v_offset = 0.0


func _blocked(p: Vector2) -> bool:
	for r in blocked_rects:
		if (r as Rect2).has_point(p):
			return true
	return false


func _unhandled_input(event: InputEvent) -> void:
	if not enabled:
		return
	if event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			if _blocked(st.position):
				return
			_touches[st.index] = st.position
			if _touches.size() == 1:
				_drag_touch = st.index
			elif _touches.size() == 2:
				_drag_touch = -1
				var pts := _touches.values()
				_pinch_dist0 = (pts[0] as Vector2).distance_to(pts[1])
				_pinch_start = distance
		else:
			_touches.erase(st.index)
			if st.index == _drag_touch:
				_drag_touch = -1
	elif event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		if not _touches.has(sd.index):
			return
		_touches[sd.index] = sd.position
		if _touches.size() >= 2:
			var pts2 := _touches.values()
			var d := (pts2[0] as Vector2).distance_to(pts2[1])
			if _pinch_dist0 > 10.0:
				distance = clampf(_pinch_start * _pinch_dist0 / maxf(d, 10.0), min_distance, max_distance)
		elif sd.index == _drag_touch:
			yaw -= sd.relative.x * sensitivity
			pitch += sd.relative.y * sensitivity * (-1.0 if invert_y else 1.0)
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		var mm := event as InputEventMouseMotion
		yaw -= mm.relative.x * sensitivity
		pitch += mm.relative.y * sensitivity * (-1.0 if invert_y else 1.0)
	elif event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			distance = clampf(distance - 1.0, min_distance, max_distance)
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			distance = clampf(distance + 1.0, min_distance, max_distance)


## Apakah segmen dari kamera ke titik p memotong AABB dunia (untuk memudarkan bangunan penghalang)?
## end_margin: kotak harus sudah ditembus minimal sekian meter SEBELUM titik p. Dengan begitu pemain yang cuma berdiri di dekat dinding
## (tidak ada bangunan di antara kamera dan pemain) tidak membuat bangunan menjadi tembus pandang.
func segment_hits_aabb(p: Vector3, box: AABB, end_margin: float = 0.0) -> bool:
	var a := cam.global_position
	var d := p - a
	var tmin := 0.0
	var tmax := 1.0 - end_margin / maxf(d.length(), 0.01)
	if tmax <= 0.0:
		return false
	for i in 3:
		var da := d[i]
		var lo := box.position[i]
		var hi := box.position[i] + box.size[i]
		if absf(da) < 0.00001:
			if a[i] < lo or a[i] > hi:
				return false
		else:
			var t1 := (lo - a[i]) / da
			var t2 := (hi - a[i]) / da
			if t1 > t2:
				var tmp := t1
				t1 = t2
				t2 = tmp
			tmin = maxf(tmin, t1)
			tmax = minf(tmax, t2)
			if tmin > tmax:
				return false
	return true
