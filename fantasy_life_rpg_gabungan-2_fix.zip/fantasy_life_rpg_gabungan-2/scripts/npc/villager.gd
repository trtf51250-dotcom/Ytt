class_name Villager
extends CharacterBody3D
## Penduduk hiasan: berjalan mengitari alun-alun (jalur melingkar di sekeliling air mancur) dengan animasi jalan, sesekali berhenti.
## Bisa diajak bicara (tombol Interaksi saat dekat): berhenti dan menghadap pemain selama obrolan. Punya kapsul tabrakan agar pemain tidak menembusnya.

var rig: CharacterRig
var npc_id := ""
var display_name := ""
var title := ""
var talk_radius := 2.6
var look_at_node: Node3D:
	set(v):
		look_at_node = v
		_pause = 1.0e6 if v != null else 1.2          # selama bicara berhenti total; sesudahnya lanjut berjalan
var _def: Dictionary
var ring := 10.0
var dir_sign := 1
var angle := 0.0
var speed := 1.3
var route: Array = []            # bila terisi: patroli bolak-balik antar titik (jalan kota) alih-alih memutari alun-alun
var _ri := 1
var _pause := 0.0
var _next_pause := 6.0


func setup(def: Dictionary) -> void:
	name = "Villager"
	collision_layer = 4
	collision_mask = 0
	ring = def.get("ring", 10.0)
	dir_sign = def.get("dir", 1)
	angle = def.get("phase", 0.0)
	speed = def["speed"]
	route = def.get("route", [])
	_def = def
	display_name = str(def.get("name", "Warga"))
	title = str(def.get("title", "Penduduk"))
	npc_id = "warga_" + display_name.to_lower().replace(" ", "_")
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.42
	cap.height = 1.7
	cs.shape = cap
	cs.position = Vector3(0, 0.85, 0)
	add_child(cs)
	rig = CharacterRig.new()
	add_child(rig)
	Quality.blob(self, 0.6, 0.0)
	var skin: Texture2D = load("res://assets/hero/%s.png" % def["skin"])
	rig.setup(float(def["height"]), skin, false, false)
	rig.play_loop("walk_n", 0.0, 1.0)
	var lab := Label3D.new()
	lab.text = "%s\n%s" % [display_name, title]
	lab.font_size = 34
	lab.outline_size = 12
	lab.pixel_size = 0.0042
	lab.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lab.no_depth_test = true
	lab.modulate = Color(0.92, 0.97, 1.0)
	lab.outline_modulate = Color(0.05, 0.08, 0.2, 0.95)
	lab.position = Vector3(0, float(def["height"]) + 0.5, 0)
	lab.visibility_range_end = 11.0
	lab.render_priority = 5
	add_child(lab)
	_place()


func _place() -> void:
	if not route.is_empty():
		var p0: Vector2 = route[0].lerp(route[1], randf())        # titik awal acak di sepanjang rute
		position = Vector3(p0.x, 0.04, p0.y)
		_ri = 1
		return
	position = Vector3(cos(angle) * ring, 0.04, sin(angle) * ring)
	var tangent := Vector3(-sin(angle), 0, cos(angle)) * dir_sign
	rig.rotation.y = atan2(tangent.x, tangent.z)


var _cull_t := 0.0


func _physics_process(delta: float) -> void:
	_cull_t -= delta
	if _cull_t <= 0.0:
		_cull_t = 0.4
		var cam := get_viewport().get_camera_3d()
		if cam != null:       # jauh dari kamera: sembunyikan rig dan hentikan animasinya (hemat gambar + CPU rangka)
			var show := cam.global_position.distance_to(global_position) < Quality.rig_cull_dist()
			if rig.visible != show:
				rig.visible = show
				rig.process_mode = Node.PROCESS_MODE_INHERIT if show else Node.PROCESS_MODE_DISABLED
	if _pause > 0.0:
		_pause -= delta
		if look_at_node != null:
			var to_p := look_at_node.global_position - global_position
			rig.rotation.y = lerp_angle(rig.rotation.y, atan2(to_p.x, to_p.z), 1.0 - exp(-8.0 * delta))
		if rig.visible:
			rig.play_loop("idle_n", 0.25, 1.0)
		return
	_next_pause -= delta
	if _next_pause <= 0.0:
		_pause = randf_range(2.0, 4.5)
		_next_pause = randf_range(8.0, 16.0)
		return
	if rig.visible:
		rig.play_loop("walk_n", 0.25, speed / 1.3)
	if not route.is_empty():
		var tgt: Vector2 = route[_ri]
		var to := Vector3(tgt.x - position.x, 0.0, tgt.y - position.z)
		if to.length() < 0.5:
			_ri = 1 - _ri
			_pause = randf_range(3.0, 7.0)
			return
		var d3 := to.normalized()
		position += d3 * speed * delta
		rig.rotation.y = lerp_angle(rig.rotation.y, atan2(d3.x, d3.z), 1.0 - exp(-8.0 * delta))
		return
	angle += dir_sign * speed / ring * delta
	var tangent := Vector3(-sin(angle), 0, cos(angle)) * dir_sign
	position = Vector3(cos(angle) * ring, 0.04, sin(angle) * ring)
	rig.rotation.y = lerp_angle(rig.rotation.y, atan2(tangent.x, tangent.z), 1.0 - exp(-8.0 * delta))



func dialogue() -> Dictionary:
	return NpcDefs.villager_dialogue(npc_id, _def)
