class_name NpcDefs
extends RefCounted
## Data NPC + dialog. Dialog = Dictionary simpul:
##   { "start": {"lines": ["...", "..."], "choices": [ {"text": "...", "action": "shop:weapon"}, {"text": "...", "goto": "simpul_lain"} ]}, "simpul_lain": {...} }
## Aksi yang dikenali Lobby: close, quests, adventure, party, gacha, smith, shop:weapon, shop:item, shop:sell, character, equipment.
## Menambah NPC baru = tambah satu entri di DEFS (+ tempat di LobbyLayout.NPC_SPOTS) dan satu cabang di dialogue().

const DEFS := {
	"guild_master": {"name": "Orwen", "title": "Master Serikat Bintang Fajar", "skin": "skin_orwen", "look": "guild_master", "height": 1.86, "idle": "idle_cross"},
	"merchant": {"name": "Rowan", "title": "Pedagang Senjata", "skin": "skin_rowan", "look": "merchant", "height": 1.72, "idle": "idle_gesture"},
	"potion_seller": {"name": "Mira", "title": "Peracik Ramuan", "skin": "skin_mira", "look": "potion_seller", "height": 1.62, "idle": "idle_stir"},
	"blacksmith": {"name": "Tobias", "title": "Pandai Besi", "skin": "skin_tobias", "look": "blacksmith", "height": 1.9, "idle": "idle_hammer"},
	"info": {"name": "Selin", "title": "Pemandu Kota", "skin": "skin_selin", "look": "info", "height": 1.66, "idle": "idle_gesture"},
	"party_leader": {"name": "Kael", "title": "Pemimpin Regu", "skin": "skin_kael", "look": "party_leader", "height": 1.8, "idle": "idle_wave"},
	"gate_guard": {"name": "Elio", "title": "Penjaga Gerbang", "skin": "skin_elio", "look": "gate_guard", "height": 1.95, "idle": "idle_attention"},
	"priestess": {"name": "Pip", "title": "Penjaga Altar Bintang", "skin": "skin_pip", "look": "priestess", "height": 1.55, "idle": "idle_n"},
}

## Penduduk yang berjalan-jalan; bisa diajak bicara (nama, gelar, dan "say" = kalimat khas masing-masing; sisanya dari VILLAGER_RUMORS dan petunjuk sesuai kemajuan pemain).
const VILLAGER_PRIORITY := [0, 4, 2, 6, 1, 5, 3, 7, 8, 9, 10, 11]   # urutan dibuat saat anggaran warga terbatas (campur alun-alun dan jalan)
const VILLAGERS := [
	{"skin": "skin_town1", "height": 1.7, "ring": 13.5, "dir": 1, "phase": 0.0, "speed": 1.35, "name": "Bu Lestari", "title": "Penjual Roti", "say": ["Roti hangat, baru dari tungku! Sayang tokoku tak muat di alun-alun, jadi aku keliling saja.", "Kalau perutmu kosong, pedangmu pun jadi lamban. Ingat itu."]},
	{"skin": "skin_town2", "height": 1.62, "ring": 16.0, "dir": -1, "phase": 2.0, "speed": 1.2, "name": "Pak Darma", "title": "Tukang Kebun Kota", "say": ["Pohon-pohon di taman ini kutanam sendiri. Sakura itu yang paling manja.", "Kalau kau lihat kelopak berguguran, itu tandanya musim sedang baik."]},
	{"skin": "skin_town1", "height": 1.55, "ring": 14.8, "dir": 1, "phase": 4.1, "speed": 1.5, "name": "Nia", "title": "Pelukis Jalanan", "say": ["Aku melukis air mancur setiap pagi. Tak pernah sama, cahayanya selalu berubah.", "Kota ini indah kalau dilihat dari atas bukit. Sayang tembok menghalangi."]},
	{"skin": "skin_town2", "height": 1.78, "ring": 17.0, "dir": -1, "phase": 5.3, "speed": 1.25, "name": "Mbah Surya", "title": "Sesepuh Kota", "say": ["Dulu Aurelia hanya sebuah pondok di lereng bukit. Sekarang lihat, sudah punya tembok dan gerbang.", "Anak muda zaman sekarang kuat-kuat. Dulu kami cuma bawa tongkat."]},
	# penjaga jalan: bolak-balik menyusuri jalan kota (sisi jalan, jadi tidak bertabrakan), sesekali berhenti
	{"skin": "skin_town1", "height": 1.68, "route": [Vector2(3, 100), Vector2(3, 34)], "speed": 1.3, "name": "Dimas", "title": "Kurir Surat", "say": ["Aku mengantar surat dari gerbang selatan sampai ke guild. Kakiku sudah hafal tiap batu jalan.", "Cepat atau lambat, semua kabar lewat jalan ini."]},
	{"skin": "skin_town2", "height": 1.6, "route": [Vector2(-3, 36), Vector2(-3, 98)], "speed": 1.15, "name": "Wulan", "title": "Penyiram Bunga", "say": ["Bunga-bunga di pinggir jalan butuh air tiap hari. Jangan injak yang kecil-kecil, ya.", "Kupu-kupu suka sekali taman kota kita."]},
	{"skin": "skin_town2", "height": 1.72, "route": [Vector2(-32, 3), Vector2(-66, 3)], "speed": 1.2, "name": "Hadi", "title": "Pemanggul Barang", "say": ["Peti, karung, tong, semua aku pikul. Bahuku lebih kuat dari baja Tobias, katanya sendiri iri.", "Kalau ada barang berat, bilang saja. Upahnya murah."]},
	{"skin": "skin_town1", "height": 1.58, "route": [Vector2(34, -3), Vector2(66, -3)], "speed": 1.4, "name": "Rani", "title": "Pembawa Kabar", "say": ["Aku selalu tahu kabar terbaru sebelum orang lain. Itu pekerjaanku.", "Kalau kau dengar sesuatu yang menarik, ceritakan padaku ya."]},
	{"skin": "skin_town1", "height": 1.65, "route": [Vector2(-58.5, -60), Vector2(-58.5, 80)], "speed": 1.25, "name": "Joko", "title": "Peronda Kota", "say": ["Aku keliling sepanjang jalan samping tiap hari, memastikan semua aman.", "Sejak ada serikat, kota jadi tenang. Tapi tetap, mata harus terbuka."]},
	{"skin": "skin_town2", "height": 1.75, "route": [Vector2(61.5, 80), Vector2(61.5, -60)], "speed": 1.3, "name": "Sari", "title": "Penenun Kain", "say": ["Kain tenunanku dipakai separuh warga kota. Jubah petualang pun kadang pesan padaku.", "Warna biru fajar itu paling sulit dibuat."]},
	{"skin": "skin_town1", "height": 1.6, "route": [Vector2(4, -30), Vector2(4, -46)], "speed": 1.1, "name": "Bagas", "title": "Murid Serikat", "say": ["Aku baru tiga bulan di serikat. Orwen galak, tapi adil.", "Suatu hari aku akan jadi petualang hebat, seperti kamu."]},
	{"skin": "skin_town2", "height": 1.55, "route": [Vector2(-12, 58), Vector2(-36, 58)], "speed": 1.2, "name": "Ayu", "title": "Pengumpul Herbal", "say": ["Daun dan embun yang kuambil dari taman dibeli Mira untuk ramuannya.", "Jangan petik tanaman sembarangan, ada yang beracun."]},
]


## Penghuni rumah: satu per rumah, berjaga/mondar-mandir di depan pintu rumahnya (nama, gelar, kalimat khas).
const RESIDENTS := [
	["Bu Marni", "Penghuni Rumah", "Rumah ini warisan nenekku. Atapnya sering bocor, tapi hatiku selalu hangat."],
	["Pak Ujang", "Penghuni Rumah", "Tiap pagi aku menyapu halaman. Tamu yang datang harus disambut halaman bersih."],
	["Lilis", "Penghuni Rumah", "Suamiku petualang. Katanya tiap pulang dia selalu rindu masakanku."],
	["Pak Bima", "Penghuni Rumah", "Rumahku kecil tapi pintunya selalu terbuka untuk petualang yang kelelahan."],
	["Tika", "Penghuni Rumah", "Aku suka duduk di depan rumah, menonton orang lalu-lalang di jalan."],
	["Mang Eman", "Penghuni Rumah", "Dulu aku petualang juga. Sekarang lututku yang jadi lawan terberat."],
	["Rina", "Penghuni Rumah", "Kata ibuku, rumah yang baik itu yang ada kucingnya. Sayang kucingku suka kabur."],
	["Pak Slamet", "Penghuni Rumah", "Tembok rumah ini kubangun sendiri. Kokoh, tak ada yang bisa menembusnya."],
	["Yuni", "Penghuni Rumah", "Aku menjemur kain di sini tiap hari. Matahari kota ini memang murah hati."],
	["Pak Anto", "Penghuni Rumah", "Malam hari lampu kota menyala, rumahku jadi tampak seperti di dalam lukisan."],
	["Fitri", "Penghuni Rumah", "Tetangga sebelah suka berisik, tapi kalau mereka pergi malah sepi."],
	["Mas Rudi", "Penghuni Rumah", "Aku baru pindah kemari. Kotanya ramah, warganya baik semua."],
	["Bu Hesti", "Penghuni Rumah", "Kalau kau lapar, mampir saja. Ada sup hangat di dapur."],
	["Pak Gilang", "Penghuni Rumah", "Rumah ini menghadap jalan, jadi aku selalu tahu siapa yang lewat."],
	["Dewi", "Penghuni Rumah", "Taman di depan rumahku kurawat sendiri. Jangan diinjak ya, petualang."],
]

## Kabar/obrolan umum antarwarga (semuanya sesuai isi game).
const VILLAGER_RUMORS := [
	"Tobias si pandai besi bisa menempa senjatamu sampai +10. Biayanya naik tiap tingkat, tapi tambahan ATK-nya terasa.",
	"Kata Pip, Altar Bintang pasti memberi bintang lima setiap lima puluh panggilan tanpa hasil. Jujur sekali altarnya.",
	"Di wilayah di luar gerbang, kalahkan dua belas monster dan daerah itu ditaklukkan. Ada peti dan area rahasia juga di sana.",
	"Orwen selalu menaruh quest baru di papan serikat. Jangan lupa klaim hadiahnya.",
	"Dalam satu regu ada empat orang. Ketuk portret rekanmu untuk bertukar karakter di tengah pertempuran. Kael yang mengajariku.",
	"Mira meracik ramuan dari embun fajar. Rasanya aneh, tapi bawa beberapa sebelum menghadapi bos.",
	"Elio menjaga gerbang selatan sejak sebelum aku lahir. Katanya belum ada monster yang berhasil lewat.",
	"Air mancur di alun-alun katanya tak pernah kering sejak kota ini berdiri.",
	"Portal di timur menuju tempat yang jauh. Aku sendiri tak pernah berani melangkah masuk.",
	"Kalau bingung soal kontrol atau cara bermain, tanya Selin si pemandu kota.",
	"Barang yang tak terpakai bisa kau jual ke Rowan atau Mira, lumayan buat modal menempa.",
	"Serikat memberi bonus masuk harian selama tiga hari pertama. Jangan sampai terlewat.",
	"Kalau malam tiba, lampu-lampu kota menyala dan kunang-kunang muncul di sekitar taman. Indah sekali.",
	"Ada peti tersembunyi di luar kota. Yang berkilau perak biasanya isinya lumayan.",
]

static var _talk_n := {}


static func villager_dialogue(key: String, d: Dictionary) -> Dictionary:
	var n: int = int(_talk_n.get(key, 0))
	_talk_n[key] = n + 1
	var say: Array = d.get("say", ["Halo!"])
	var bye := _c("Sampai nanti.", "close")
	var pool: Array = VILLAGER_RUMORS.duplicate()
	var seed_off: int = key.hash() % pool.size()
	var r1: String = pool[(seed_off + n * 3) % pool.size()]
	var r2: String = pool[(seed_off + n * 3 + 1) % pool.size()]
	var r3: String = pool[(seed_off + n * 3 + 2) % pool.size()]
	var greet := "Halo, petualang! Aku %s, %s." % [d["name"], str(d["title"]).to_lower()] if n == 0 else "Oh, kamu lagi! Ada perlu apa?"
	if d.get("home", false):
		greet = "Selamat datang! Aku %s, tinggal di rumah ini." % d["name"] if n == 0 else "Mampir lagi? Senang melihatmu."
	return {
		"start": {"lines": [greet, say[n % say.size()]], "choices": [
			_c("Ada kabar apa?", "", "rumor"), _c("Apa yang sebaiknya kulakukan?", "", "hint"), bye]},
		"rumor": {"lines": [r1, r2], "choices": [_c("Ada lagi?", "", "rumor2"), _c("Kembali", "", "start"), bye]},
		"rumor2": {"lines": [r3], "choices": [_c("Kembali", "", "start"), bye]},
		"hint": {"lines": [_hint_line()], "choices": [_c("Kembali", "", "start"), bye]},
	}


static func _hint_line() -> String:
	if GameState.ready_quest_count() > 0:
		return "Kudengar Orwen menunggumu di guild: ada quest yang sudah selesai dan hadiahnya belum kau ambil."
	var nxt := GameState.adventure_next()
	if nxt != "":
		var sd: StageData = Data.stage(nxt)
		if sd != null:
			if Data.field_ids.has(nxt):
				return "Petualanganmu berikutnya: menjelajahi %s. Kalahkan dua belas monster di sana untuk menaklukkannya. Tekan Start Adventure atau keluar lewat gerbang." % sd.display_name
			return "Petualanganmu berikutnya: %s. Tekan Start Adventure atau keluar lewat gerbang selatan." % sd.display_name
	return "Semua petualangan sudah kau tamatkan! Ulangi stage mana pun lewat Start Adventure untuk mencari emas dan EXP."


static func ids() -> Array:
	return DEFS.keys()


static func display_name(id: String) -> String:
	return str(DEFS.get(id, {}).get("name", id))


static func _c(text: String, action: String = "", goto: String = "") -> Dictionary:
	var d := {"text": text}
	if action != "":
		d["action"] = action
	if goto != "":
		d["goto"] = goto
	return d


static func dialogue(id: String) -> Dictionary:
	var bye := _c("Sampai nanti.", "close")
	match id:
		"guild_master":
			var lines: Array = []
			if GameState.quest_state("q_welcome") != "claimed":
				lines = ["Ah, pendatang baru! Aku Orwen, Master Serikat Bintang Fajar.",
					"Aurelia adalah kota perbatasan. Di luar gerbang selatan, padang rumput dan hutan dipenuhi monster, dan serikat kami menjaga warga dari mereka.",
					"Namamu sudah tercatat di buku anggota. Buka menu Quest untuk mengambil hadiah sambutan, lalu cobalah petualangan pertamamu."]
			elif GameState.ready_quest_count() > 0:
				lines = ["Ada quest yang sudah kau selesaikan. Buka menu Quest dan klaim hadiahnya, itu hakmu."]
			else:
				lines = ["Kerja bagus, petualang. Papan quest di sebelahku selalu terbuka; stage berikutnya menunggu di balik gerbang selatan."]
			return {"start": {"lines": lines, "choices": [
				_c("Lihat daftar Quest", "quests"), _c("Mulai Petualangan", "adventure"), bye]}}
		"merchant":
			return {"start": {"lines": ["Selamat datang di Toko Senjata Aurelia! Besi terbaik, harga jujur, dan tidak ada yang kuberi gratis."],
				"choices": [_c("Beli senjata & armor", "shop:weapon"), _c("Jual barang", "shop:sell"), bye]}}
		"potion_seller":
			return {"start": {"lines": ["Ramuanku diseduh dari embun fajar dan daun yang dipetik sebelum matahari terbit. Rasanya... yah, sembuh itu lebih penting dari rasa."],
				"choices": [_c("Beli ramuan", "shop:item"), _c("Jual barang", "shop:sell"), bye]}}
		"blacksmith":
			return {"start": {"lines": ["Senjata bagus bukan hanya soal baja, tapi sabar dan palu. Bawa senjata yang sedang kau pakai, akan kutempa sampai +10.",
				"Biayanya naik tiap tingkat, tapi setiap tempaan menambah ATK senjatamu."],
				"choices": [_c("Tempa senjata", "smith"), bye]}}
		"info":
			return {
				"start": {"lines": ["Halo! Aku Selin, pemandu kota. Mau tahu apa?"], "choices": [
					_c("Cara bermain", "", "how"), _c("Kontrol", "", "controls"), _c("Tentang Aurelia", "", "lore"), bye]},
				"how": {"lines": ["Tekan Start Adventure atau lewati gerbang selatan: petualangan langsung lanjut ke langkah berikutnya (stage cerita, wilayah jelajah, lalu bos). Bersihkan semua gelombang monster, lalu kembali ke lobi.",
					"Hadiah gold, EXP, dan diamond dipakai di toko, Blacksmith, dan Altar Bintang. Atur party empat orang di menu Party atau lewat Kael."],
					"choices": [_c("Kembali", "", "start"), bye]},
				"controls": {"lines": ["Joystick kiri untuk bergerak. Tombol kanan: Serang, Skill, Hindar, dan Interaksi (menyala bila ada NPC atau objek di dekatmu).",
					"Seret layar di area kosong untuk memutar kamera, cubit dua jari untuk zoom. Di komputer: WASD, J/Spasi serang, K skill, L/Shift hindar, E interaksi, Q/R putar kamera."],
					"choices": [_c("Kembali", "", "start"), bye]},
				"lore": {"lines": ["Aurelia dibangun di lereng bukit tempat cahaya fajar pertama jatuh. Air mancur di alun-alun katanya tak pernah kering sejak hari kota ini didirikan.",
					"Portal di timur membawa para petualang ke tempat yang jauh. Cerita lengkapnya? Itu tugasmu menulisnya."],
					"choices": [_c("Kembali", "", "start"), bye]},
			}
		"party_leader":
			return {"start": {"lines": ["Petualang sejati tak pernah sendirian. Empat orang dalam satu regu, dan kau bisa berganti pemimpin kapan saja.",
				"Di stage nanti, ketuk portret rekanmu untuk bertukar karakter di tengah pertempuran."],
				"choices": [_c("Atur Party", "party"), _c("Lihat Karakter", "character"), _c("Mulai Petualangan", "adventure"), bye]}}
		"gate_guard":
			return {"start": {"lines": ["Berhenti, petualang! ... Oh, kau anggota serikat. Silakan lewat.",
				"Di luar sana padang Fajar, hutan Remang, dan gua-gua tua. Bawa ramuan, dan jangan sok jagoan."],
				"choices": [_c("Keluar gerbang (lanjut Adventure)", "adventure"), bye]}}
		"priestess":
			return {"start": {"lines": ["Altar Bintang menjawab mereka yang berani memanggil. Perlengkapan, ramuan, atau pecahan jiwa sahabatmu. Tak ada yang tahu apa yang akan turun.",
				"Peluang ditampilkan jujur di dalam altar, dan setiap lima puluh kali tanpa bintang lima, altar pasti memberi satu."],
				"choices": [_c("Panggil di Altar", "gacha"), bye]}}
	return {"start": {"lines": ["..."], "choices": [bye]}}
