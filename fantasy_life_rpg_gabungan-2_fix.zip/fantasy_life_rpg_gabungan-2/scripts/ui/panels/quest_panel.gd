extends BasePanel
## Quest: daftar quest aktif / siap-klaim / selesai dengan bar kemajuan dan hadiah. Klaim memberi gold, diamond, EXP, item, atau karakter.

var _list: VBoxContainer


func _init() -> void:
	refresh_on = ["quest", "profile", "roster", "party"]


func build() -> void:
	var sl := scroll_list()
	content.add_child(sl[0])
	_list = sl[1]


func _reward_text(qd: QuestData) -> String:
	var parts: PackedStringArray = []
	if qd.reward_gold > 0:
		parts.append("%d gold" % qd.reward_gold)
	if qd.reward_diamond > 0:
		parts.append("%d diamond" % qd.reward_diamond)
	if qd.reward_exp > 0:
		parts.append("%d EXP" % qd.reward_exp)
	for e in qd.reward_items:
		var p := e.split(":")
		var it := Data.item(p[0])
		parts.append("%s ×%s" % [it.display_name if it else p[0], p[1] if p.size() > 1 else "1"])
	if qd.reward_character != "":
		parts.append("Karakter: %s" % Data.character(qd.reward_character).display_name)
	return "Hadiah: " + ", ".join(parts)


func refresh() -> void:
	clear(_list)
	var order := {"ready": 0, "active": 1, "claimed": 2}
	var ids: Array = []
	for id in Data.quest_order:
		if GameState.quest_state(id) != "locked":
			ids.append(id)
	ids.sort_custom(func(a, b): return order[GameState.quest_state(a)] < order[GameState.quest_state(b)])
	var heads := {"ready": "Siap diklaim", "active": "Sedang dikerjakan", "claimed": "Selesai"}
	var last := ""
	for id in ids:
		var stt := GameState.quest_state(id)
		if stt != last:
			last = stt
			section(_list, heads.get(stt, stt))
		_list.add_child(_quest_card(id))
	if ids.is_empty():
		_list.add_child(lbl("Belum ada quest.", 22, UiTheme.TEXT_DIM))


func _quest_card(id: String) -> Control:
	var qd: QuestData = Data.quest(id)
	var state := GameState.quest_state(id)
	var border := UiTheme.GOLD if state == "ready" else (Color(0.3, 0.33, 0.45) if state == "claimed" else UiTheme.GOLD_DARK)
	var c := card(border, Color(0.18, 0.24, 0.3) if state == "ready" else Color(0.13, 0.17, 0.36))
	var row := hbox(12)
	c.add_child(row)
	row.add_child(UiIcon.make("check" if state == "claimed" else ("star" if state == "ready" else "scroll"), UiTheme.GOOD if state == "claimed" else UiTheme.GOLD, 42))
	var col := vbox(2)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(col)
	col.add_child(lbl(qd.title, 24, UiTheme.TEXT if state != "claimed" else UiTheme.TEXT_DIM))
	col.add_child(wrap_lbl(qd.description, 17, UiTheme.TEXT_DIM))
	if state != "claimed" and qd.hint != "":
		col.add_child(wrap_lbl("Petunjuk: " + qd.hint, 16, UiTheme.SKY))
	col.add_child(lbl(_reward_text(qd), 17, UiTheme.GOLD))
	if state != "claimed":
		var pb := UiTheme.bar(UiTheme.GOOD if state == "ready" else UiTheme.BLUE, float(GameState.quest_progress(id)) / float(maxi(qd.amount, 1)), 14.0)
		col.add_child(pb)
		col.add_child(lbl("%d / %d" % [GameState.quest_progress(id), qd.amount], 15, UiTheme.TEXT_DIM))
	if state == "ready":
		row.add_child(btn("Klaim", func(): _claim(id), Vector2(130, 66), UiTheme.GOLD))
	elif state == "claimed":
		row.add_child(lbl("Selesai", 20, UiTheme.GOOD))
	return c


func _claim(id: String) -> void:
	var got := GameState.claim_quest(id)
	if got.is_empty():
		return
	Sfx.play("chest")
	var parts: PackedStringArray = []
	if got["gold"] > 0:
		parts.append("+%d gold" % got["gold"])
	if got["diamond"] > 0:
		parts.append("+%d diamond" % got["diamond"])
	if got["exp"] > 0:
		parts.append("+%d EXP" % got["exp"])
	for e: Array in got["items"]:
		parts.append("%s ×%d" % [Data.item(e[0]).display_name, e[1]])
	if got["character"] != "":
		parts.append("%s bergabung!" % Data.character(got["character"]).display_name)
	if got["levels"] > 0:
		parts.append("Naik level! Lv %d" % GameState.level)
	toast(", ".join(parts))
