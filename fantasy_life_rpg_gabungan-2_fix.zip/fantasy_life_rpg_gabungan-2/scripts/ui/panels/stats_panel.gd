extends BasePanel
## Statistik petualangan: kartu ringkas (waktu main, kemenangan, koleksi). Semua dari data nyata di save.

func _init() -> void:
	refresh_on = ["profile", "roster", "inventory", "currency", "stages", "story", "login", "daily"]


func build() -> void:
	pass


func _tile(parent: GridContainer, title: String, value: String, col: Color = UiTheme.GOLD, sub: String = "") -> void:
	var c := card()
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var v := vbox(2)
	c.add_child(v)
	v.add_child(lbl(title, 17, UiTheme.TEXT_DIM))
	v.add_child(lbl(value, 32, col))
	if sub != "":
		v.add_child(lbl(sub, 15, UiTheme.SKY))
	parent.add_child(c)


func refresh() -> void:
	clear(content)
	var gs := GameState
	var head := hbox(12)
	head.add_child(lbl(gs.player_name, 30, UiTheme.GOLD))
	head.add_child(lbl("Lv %d  ·  ID %s" % [gs.level, gs.player_id], 20, UiTheme.SKY))
	content.add_child(head)
	var sl := scroll_list()
	var scroll: ScrollContainer = sl[0]
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(scroll)
	var mc := MarginContainer.new()
	mc.add_theme_constant_override("margin_right", 22)
	mc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sl[1].add_child(mc)
	var body := vbox(8)
	mc.add_child(body)
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	body.add_child(grid)
	var cleared := 0
	var stars := 0
	for sid in gs.stages:
		var st: Dictionary = gs.stages[sid]
		if bool(st.get("cleared", false)):
			cleared += 1
		stars += int(st.get("stars", 0))
	var total_stages := Data.stage_order.size()
	var owned := 0
	for id in Data.character_ids():
		if gs.is_unlocked(id):
			owned += 1
	_tile(grid, "Waktu bermain", gs.time_string(), UiTheme.GOLD)
	_tile(grid, "Musuh dikalahkan", str(gs.stats["kills"]), Color(1.0, 0.55, 0.45))
	_tile(grid, "Stage selesai", "%d / %d" % [cleared, total_stages], UiTheme.SKY, "%d bintang terkumpul" % stars)
	_tile(grid, "Karakter dimiliki", "%d / %d" % [owned, Data.character_ids().size()], Color(0.75, 0.6, 1.0))
	_tile(grid, "Panggilan gacha", str(gs.stats["pulls"]), UiTheme.GOLD)
	_tile(grid, "Gold dibelanjakan", str(gs.stats["gold_spent"]), UiTheme.GOLD)
	_tile(grid, "Tempa senjata", str(gs.stats["upgrades"]), Color(0.6, 0.85, 0.7))
	_tile(grid, "Duel PVP", "%d - %d" % [int(gs.stats["pvp_win"]), int(gs.stats["pvp_loss"])], Color(1.0, 0.45, 0.45), "menang - kalah · %d seri · %d kill" % [int(gs.stats["pvp_draw"]), int(gs.stats["pvp_kills"])])
	var seen := 0
	for sc in Story.scenes():
		if Story.seen(sc["id"]):
			seen += 1
	_tile(grid, "Cerita dibaca", "%d / %d" % [seen, Story.scenes().size()], Color(0.66, 0.5, 1.0))
	_tile(grid, "Hadiah siap diambil", str(gs.daily_ready_count() + gs.ach_ready_count()), Color(1.0, 0.72, 0.2))
	section(body, "Kemajuan stage")
	for sid in Data.stage_order:
		var sd = Data.stages[sid]
		var st2: Dictionary = gs.stages.get(sid, {})
		var done := bool(st2.get("cleared", false))
		var r := hbox(10)
		r.add_child(lbl(("✔ " if done else "• ") + str(sd.display_name), 19, UiTheme.TEXT if done else UiTheme.TEXT_DIM))
		var sp := Control.new()
		sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		r.add_child(sp)
		r.add_child(lbl(stars_text(int(st2.get("stars", 0)), 3) if done else "belum", 19, UiTheme.GOLD if done else UiTheme.TEXT_DIM))
		body.add_child(r)
	body.add_child(wrap_lbl("Semua angka disimpan di perangkat ini saja (game offline).", 16, UiTheme.TEXT_DIM))
