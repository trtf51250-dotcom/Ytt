extends BasePanel
## Karakter: daftar (kiri) + detail (kanan): statistik, skill, bintang (naikkan dengan pecahan), equipment ringkas, jadikan pemimpin.

const SKILL_TEXT := {
	"cone": "Tebasan kerucut ke depan, menghantam semua musuh dalam jangkauan.",
	"iai": "Cabut pedang: tebasan lurus sangat panjang lalu tebasan lebar yang dibalut api biru.",
	"dash_cut": "Menerjang ke depan (kebal sesaat) dan menyilang dua tebasan beruntun.",
	"nova": "Ledakan sihir di sekitar karakter.",
	"shockwave": "Hantaman keras yang memancarkan gelombang kejut lebar.",
	"volley": "Hujan panah ke arah depan.",
}
const ATTACK_TEXT := {"arc": "Tebasan melengkung", "dagger": "Kombo belati 3 pukulan cepat", "bolt": "Bola sihir jarak jauh", "smash": "Hantaman lebar", "arrow": "Panah jarak jauh"}
var selected := ""
var _list: VBoxContainer
var _detail: VBoxContainer
var _pic: TextureRect




func _init() -> void:
	refresh_on = ["roster", "party", "equipment", "profile", "inventory"]


func build() -> void:
	selected = str(args.get("char", GameState.leader()))
	var row := hbox(14)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(row)
	var sl := scroll_list(340)
	row.add_child(sl[0])
	_list = sl[1]
	var right := PanelContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_stylebox_override("panel", UiTheme.box(Color(0.08, 0.11, 0.25), UiTheme.GOLD_DARK, 2, 14, 14))
	row.add_child(right)
	var inner := hbox(12)
	right.add_child(inner)
	_detail = vbox(6)
	_detail.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_child(_detail)
	_pic = TextureRect.new()                              # potret 3D seluruh badan di sisi kanan
	_pic.custom_minimum_size = Vector2(230, 0)
	_pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_pic.clip_contents = true
	inner.add_child(_pic)
	Portraits.changed_signal(self).connect(_set_pic)


func refresh() -> void:
	clear(_list)
	for id in Data.character_ids():
		var cid: String = id
		_list.add_child(char_row(cid, func():
			selected = cid
			refresh(), cid == selected, "♛" if cid == GameState.leader() else ""))
	_fill()


func _stat_line(name: String, val: String, col: Color = UiTheme.TEXT) -> Control:
	var h := hbox(8)
	var a := lbl(name, 20, UiTheme.TEXT_DIM)
	a.custom_minimum_size = Vector2(70, 0)
	h.add_child(a)
	h.add_child(lbl(val, 22, col))
	return h


func _set_pic() -> void:
	if _pic == null or not is_instance_valid(_pic):
		return
	_pic.texture = Portraits.texture(self, selected + "#full")
	_pic.modulate = Color(1, 1, 1) if GameState.is_unlocked(selected) else Color(0.1, 0.1, 0.16, 0.85)


func _fill() -> void:
	_set_pic()
	clear(_detail)
	var cd := Data.character(selected)
	if cd == null:
		return
	var owned := GameState.is_unlocked(selected)
	var head := hbox(12)
	head.add_child(lbl(cd.display_name, 32, UiTheme.GOLD))
	var t := lbl("%s · %s" % [cd.title, cd.role], 18, UiTheme.SKY)
	t.size_flags_vertical = Control.SIZE_SHRINK_END
	head.add_child(t)
	head.add_child(lbl("Langka " + stars_text(cd.rarity, cd.rarity), 18, rarity_color(cd.rarity)))
	_detail.add_child(head)
	if not owned:
		_detail.add_child(wrap_lbl(cd.description, 20, UiTheme.TEXT_DIM))
		var hint := ""
		for qid in Data.quest_order:
			if Data.quest(qid).reward_character == selected:
				hint = "Cara mendapatkan: selesaikan quest \"%s\"." % Data.quest(qid).title
		if hint == "":
			for rr: Array in Gacha.CHAR_POOL.values():
				if selected in rr:
					hint = "Cara mendapatkan: Panggilan Jiwa di Altar Bintang (gacha karakter)."
		_detail.add_child(lbl(hint if hint != "" else "Karakter ini belum bisa didapat.", 20, UiTheme.GOLD))
		return
	var st := GameState.char_stats(selected)
	var sr := hbox(14)
	sr.add_child(lbl(stars_text(GameState.stars(selected)), 28, UiTheme.GOLD))
	if GameState.stars(selected) < GameState.MAX_STARS:
		sr.add_child(lbl("Pecahan %d/%d" % [GameState.shards(selected), GameState.star_up_cost(selected)], 18, UiTheme.SKY))
		var up := btn("Naikkan ★", func():
			if GameState.star_up(selected):
				Sfx.play("shard")
				toast("%s naik ke %d★ (+12%% statistik)" % [cd.display_name, GameState.stars(selected)])
			else:
				toast("Pecahan jiwa belum cukup."), Vector2(150, 44))
		up.disabled = GameState.shards(selected) < GameState.star_up_cost(selected)
		sr.add_child(up)
	else:
		sr.add_child(lbl("Bintang maksimum", 18, UiTheme.SKY))
	_detail.add_child(sr)
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 26)
	_detail.add_child(grid)
	for e in [["HP", str(st["hp"])], ["ATK", str(st["atk"])], ["DEF", str(st["def"])], ["Lv", str(GameState.level)], ["Gerak", "%.1f" % st["spd"]], ["Kekuatan", str(st["power"])]]:
		grid.add_child(_stat_line(e[0], e[1], UiTheme.GOLD if e[0] == "Kekuatan" else UiTheme.TEXT))
	_detail.add_child(HSeparator.new())
	_detail.add_child(lbl("Serangan: %s (jangkauan %.1f m)" % [ATTACK_TEXT.get(cd.attack_kind, cd.attack_kind), cd.attack_range], 19, UiTheme.TEXT))
	_detail.add_child(lbl("Skill: %s  (×%.1f, jeda %.0f dtk)" % [cd.skill_name, cd.skill_mult, cd.skill_cooldown], 20, UiTheme.SKY))
	_detail.add_child(wrap_lbl(SKILL_TEXT.get(cd.skill_kind, ""), 18, UiTheme.TEXT_DIM))
	if cd.ult_name != "":
		_detail.add_child(lbl("ULT: %s  (×%.1f, 1× per match)" % [cd.ult_name, cd.ult_mult], 20, Color(1.0, 0.6, 0.9)))
	var eq := []
	for slot in GameState.SLOTS:
		var iid := GameState.equipped(selected, slot)
		eq.append(Data.item(iid).display_name if iid != "" else "-")
	var plus := GameState.weapon_plus(selected)
	_detail.add_child(lbl("Perlengkapan: %s%s · %s · %s" % [eq[0], (" +%d" % plus) if plus > 0 else "", eq[1], eq[2]], 17, UiTheme.TEXT_DIM))
	_detail.add_child(wrap_lbl(cd.description, 17, UiTheme.TEXT_DIM))
	var sp := Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_detail.add_child(sp)
	var br := hbox(10)
	var lead := btn("Pemimpin" if selected == GameState.leader() else "Jadikan Pemimpin", func():
		GameState.make_leader(selected)
		toast("%s sekarang memimpin regu." % cd.display_name), Vector2(0, 54))
	lead.disabled = selected == GameState.leader() or not GameState.party.has(selected)
	lead.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	br.add_child(lead)
	var eqb := btn("Ganti Equipment", func(): host.open("equipment", {"char": selected}), Vector2(0, 54))
	eqb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	br.add_child(eqb)
	_detail.add_child(br)
	if not GameState.party.has(selected):
		_detail.add_child(lbl("Karakter ini belum ada di party. Atur di menu Party.", 16, UiTheme.TEXT_DIM))
