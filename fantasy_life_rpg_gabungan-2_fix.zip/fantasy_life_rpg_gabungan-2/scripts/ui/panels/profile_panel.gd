extends BasePanel
## Profil pemain (offline): ID unik tetap, nama bisa diganti, rekor duel, pintasan. Gaya kartu seperti Pengaturan.

var _edit: LineEdit
var _msg: Label


func _init() -> void:
	refresh_on = ["profile"]


func build() -> void:
	var sl := scroll_list()
	content.add_child(sl[0])
	var p: VBoxContainer = sl[1]
	section(p, "Identitas")
	var r1 := info_row(p, "ID Pemain", "Dibuat acak saat dunia baru dimulai, tidak bisa diubah. Menghapus data = ID baru.")
	r1.add_child(lbl(GameState.player_id, 34, UiTheme.GOLD))
	var r2 := info_row(p, "Nama", "2-%d huruf, boleh diganti kapan saja" % GameState.NAME_MAX)
	_edit = LineEdit.new()
	_edit.text = GameState.player_name
	_edit.max_length = GameState.NAME_MAX
	_edit.custom_minimum_size = Vector2(250, 54)
	_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_edit.add_theme_font_size_override("font_size", 24)
	r2.add_child(_edit)
	r2.add_child(btn("Simpan", _save, Vector2(150, 54), UiTheme.GOLD))
	_msg = lbl("", 18, UiTheme.SKY)
	p.add_child(_msg)
	section(p, "Perjalanan")
	var r3 := info_row(p, "Level & waktu main", "Semua data tersimpan di perangkat ini (game offline).")
	r3.add_child(lbl("Lv %d  ·  %s" % [GameState.level, GameState.time_string()], 26, UiTheme.SKY))
	var st: Dictionary = GameState.stats
	var r4 := info_row(p, "Rekor duel PVP", "Menang - kalah, seri, dan total kill di duel.")
	r4.add_child(lbl("%d - %d" % [int(st.get("pvp_win", 0)), int(st.get("pvp_loss", 0))], 32, Color(1.0, 0.5, 0.45)))
	r4.add_child(lbl("%d seri · %d kill" % [int(st.get("pvp_draw", 0)), int(st.get("pvp_kills", 0))], 18, UiTheme.TEXT_DIM))
	section(p, "Pintasan")
	var r5 := info_row(p, "Karakter & Statistik", "Buka panel lain dengan cepat.")
	r5.add_child(btn("Karakter", func(): host.open("character"), Vector2(170, 54)))
	r5.add_child(btn("Statistik", func(): host.open("stats"), Vector2(170, 54)))


func _save() -> void:
	if GameState.rename_player(_edit.text):
		_msg.text = "Nama diubah menjadi %s." % GameState.player_name
	else:
		_msg.text = "Nama terlalu pendek (minimal 2 huruf)."
