extends BasePanel
## Equipment: pilih karakter, lihat 3 slot (senjata/armor/aksesori), pasang item dari inventori atau lepas.

var char_id := ""
var slot := "weapon"
var _tabs: HBoxContainer
var _slots: VBoxContainer
var _items: VBoxContainer
var _stats: Label


func _init() -> void:
	refresh_on = ["equipment", "inventory", "roster", "profile"]


func build() -> void:
	char_id = str(args.get("char", GameState.leader()))
	_tabs = hbox(8)
	content.add_child(_tabs)
	var row := hbox(14)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(row)
	var left := vbox(10)
	left.custom_minimum_size = Vector2(420, 0)
	row.add_child(left)
	_slots = vbox(8)
	left.add_child(_slots)
	_stats = wrap_lbl("", 20, UiTheme.TEXT)
	left.add_child(_stats)
	var sl := scroll_list()
	sl[0].size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(sl[0])
	_items = sl[1]


func refresh() -> void:
	clear(_tabs)
	for id in Data.character_ids():
		if not GameState.is_unlocked(id):
			continue
		var cid: String = id
		var b := btn(Data.character(cid).display_name, func():
			char_id = cid
			refresh(), Vector2(130, 48), UiTheme.GOLD if cid == char_id else Color(0, 0, 0, 0))
		_tabs.add_child(b)
	if not GameState.is_unlocked(char_id):
		return
	clear(_slots)
	for s in GameState.SLOTS:
		var sname: String = s
		var iid := GameState.equipped(char_id, sname)
		var row := hbox(8)
		var holder := PanelContainer.new()
		holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		holder.add_theme_stylebox_override("panel", UiTheme.box(Color(0.2, 0.26, 0.5) if sname == slot else Color(0.13, 0.17, 0.36), UiTheme.GOLD if sname == slot else UiTheme.GOLD_DARK, 2, 12, 8))
		tap_on(holder, func():
			slot = sname
			refresh())
		var v := vbox(0)
		v.mouse_filter = Control.MOUSE_FILTER_IGNORE
		v.add_child(lbl({"weapon": "Senjata", "armor": "Armor", "accessory": "Aksesori"}[sname], 15, UiTheme.TEXT_DIM))
		if iid != "":
			var it := Data.item(iid)
			var nm := it.display_name + ((" +%d" % GameState.weapon_plus(char_id)) if sname == "weapon" and GameState.weapon_plus(char_id) > 0 else "")
			v.add_child(lbl(nm, 22, rarity_color(it.rarity).lightened(0.3)))
			v.add_child(lbl(item_stats(it), 16, UiTheme.TEXT_DIM))
		else:
			v.add_child(lbl("(kosong)", 22, UiTheme.TEXT_DIM))
		holder.add_child(v)
		row.add_child(holder)
		if iid != "":
			row.add_child(btn("Lepas", func(): GameState.unequip(char_id, sname), Vector2(90, 60)))
		_slots.add_child(row)
	var st := GameState.char_stats(char_id)
	_stats.text = "HP %d   ATK %d   DEF %d   Kekuatan %d" % [st["hp"], st["atk"], st["def"], st["power"]]
	clear(_items)
	_items.add_child(lbl("Di inventori (%s) — ketuk untuk memasang" % {"weapon": "senjata", "armor": "armor", "accessory": "aksesori"}[slot], 18, UiTheme.TEXT_DIM))
	var any := false
	var ids: Array = GameState.inventory.keys()
	ids.sort_custom(func(a, b): return Data.item(a).rarity > Data.item(b).rarity)
	for iid2 in ids:
		var it2 := Data.item(iid2)
		if it2 == null or it2.type != slot or not GameState.can_equip(char_id, iid2):
			continue
		any = true
		var cur := Data.item(GameState.equipped(char_id, slot))
		var diff := ""
		if cur != null:
			var da := it2.atk - cur.atk
			var dd := it2.def - cur.def
			var dh := it2.hp - cur.hp
			diff = "ATK %+d  DEF %+d  HP %+d" % [da, dd, dh]
		var id2: String = iid2
		_items.add_child(item_row(it2, "×%d" % GameState.item_count(id2), func():
			if GameState.equip(char_id, id2):
				Sfx.play("pickup")
				toast("%s dipasang. %s" % [it2.display_name, diff]), false))
	if not any:
		_items.add_child(wrap_lbl("Tidak ada item yang cocok. Beli di Toko Senjata (Rowan) atau panggil di Altar Bintang.", 18, UiTheme.TEXT_DIM))
