extends BasePanel
## Atur party 4 karakter. Kiri: 4 kartu slot tinggi berpotret; kanan: daftar karakter (grid, bisa diurutkan);
## bawah: bar info + aksi untuk slot terpilih. Slot 1 = pemimpin yang tampil di lobi / dimainkan.

const SORTS := ["Rarity", "Kekuatan", "Nama"]

# PERF: tekstur gradien & StyleBox dipakai bersama semua kartu (tak pernah diubah setelah dibuat), sehingga membangun ulang
# panel tidak lagi membuat puluhan Resource baru tiap ketukan.
static var _grad_cache: Dictionary = {}
static var _box_cache: Dictionary = {}

var sel_slot := 0
var sort_mode := 0
var _slots: HBoxContainer
var _roster: GridContainer
var _power: Label
var _hint: Label
var _actions: HBoxContainer
var _sort_btn: Button
var _waiting: Array = []                 # [kotak, kunci, owned, head_only, full_body] yang menunggu potretnya selesai
var refresh_calls := 0                  # berapa kali refresh() penuh dipanggil (dipakai uji/ukur)
var _powers: Dictionary = {}          # id -> kekuatan; dihitung SEKALI per refresh (dulu di tiap perbandingan urut)


func _init() -> void:
	refresh_on = ["party", "roster", "equipment", "profile"]


func build() -> void:
	var body := hbox(14)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(body)
	# kiri: slot
	var left := vbox(6)
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.size_flags_stretch_ratio = 1.15
	left.add_child(lbl("REGU  (%d slot)" % GameState.PARTY_SIZE, 20, UiTheme.GOLD))
	_slots = hbox(8)
	_slots.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left.add_child(_slots)
	body.add_child(left)
	# kanan: roster
	var right := vbox(6)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var head := hbox(8)
	head.add_child(lbl("KARAKTER", 20, UiTheme.GOLD))
	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(sp)
	_sort_btn = UiTheme.button("", Vector2(190, 44))
	_sort_btn.pressed.connect(func():
		Sfx.play("select")
		sort_mode = (sort_mode + 1) % SORTS.size()
		_refresh_roster())
	head.add_child(_sort_btn)
	right.add_child(head)
	_roster = GridContainer.new()
	_roster.columns = 3
	_roster.add_theme_constant_override("h_separation", 8)
	_roster.add_theme_constant_override("v_separation", 8)
	_roster.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var sc := TouchScroll.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var mg := MarginContainer.new()
	mg.add_theme_constant_override("margin_right", 12)
	mg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mg.add_child(_roster)
	sc.add_child(mg)
	right.add_child(sc)
	body.add_child(right)
	# bar bawah
	var bar := PanelContainer.new()
	bar.add_theme_stylebox_override("panel", UiTheme.box(Color(0.08, 0.1, 0.24), UiTheme.GOLD_DARK, 2, 12, 8))
	var bh := hbox(12)
	bar.add_child(bh)
	_power = lbl("", 24, UiTheme.GOLD)
	bh.add_child(_power)
	_hint = lbl("", 16, UiTheme.TEXT_DIM)
	_hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_hint.clip_text = true
	bh.add_child(_hint)
	_actions = hbox(8)
	bh.add_child(_actions)
	content.add_child(bar)
	Portraits.changed_signal(self).connect(_on_portrait_ready)


## PERF: tiap potret yang selesai memancarkan "changed"; dulu tiap kali SELURUH panel dibangun ulang (17x saat pertama dibuka, terukur).
## Kini hanya kartu yang menunggu potret itu yang diisi di tempat; refresh() penuh tidak dipanggil.
func _on_portrait_ready() -> void:
	if not is_inside_tree():
		return
	var still: Array = []
	for w in _waiting:
		var box: Control = w[0]
		if not is_instance_valid(box) or not box.is_inside_tree():
			continue                                  # kartunya sudah dibangun ulang/dibuang
		var tex: Texture2D = Portraits.cached(w[1])
		if tex == null:
			still.append(w)
			continue
		for c in box.get_children():
			box.remove_child(c)
			c.queue_free()
		_fill_portrait(box, tex, w[2], w[3], w[4])
	_waiting = still


func _portrait(id: String, size: Vector2, owned: bool = true, head_only: bool = false, full_body: bool = false) -> Control:
	var cd := Data.character(id)
	var box := PanelContainer.new()
	box.custom_minimum_size = size
	box.clip_contents = true
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_stylebox_override("panel", _sb(Color(0, 0, 0, 0.0) if full_body else cd.accent.darkened(0.55), Color(0, 0, 0, 0), 0, 8, 0))
	var key := id + "#full" if full_body else id
	var tex: Texture2D = Portraits.texture(self, key)
	if tex != null:                                   # potret 3D karakter
		_fill_portrait(box, tex, owned, head_only, full_body)
	else:
		var ic := UiIcon.make("character" if owned else "lock", Color(1, 1, 1, 0.5), 40)
		ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		box.add_child(ic)
		_waiting.append([box, key, owned, head_only, full_body])
	return box


static func _fill_portrait(box: Control, tex: Texture2D, owned: bool, head_only: bool, full_body: bool) -> void:
	var tr := TextureRect.new()
	if head_only:
		var at := AtlasTexture.new()
		at.atlas = tex
		at.region = Rect2(0, 0, tex.get_width(), tex.get_height() * 0.62)
		tr.texture = at
	else:
		tr.texture = tex
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED if full_body else TextureRect.STRETCH_KEEP_ASPECT_COVERED
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if not owned:
		tr.modulate = Color(0.12, 0.13, 0.2)
	box.add_child(tr)


func _center(l: Label) -> Label:
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _power_of(id: String) -> int:
	if not _powers.has(id):
		_powers[id] = int(GameState.char_stats(id)["power"])
	return _powers[id]


func _sorted_ids() -> Array:
	var ids: Array = Data.character_ids().duplicate()
	ids.sort_custom(func(a, b):
		var oa := GameState.is_unlocked(a)
		var ob := GameState.is_unlocked(b)
		if oa != ob:
			return oa
		var pa := _power_of(a)
		var pb := _power_of(b)
		match sort_mode:
			0:
				var ra: int = Data.character(a).rarity
				var rb: int = Data.character(b).rarity
				if ra != rb:
					return ra > rb
				if pa != pb:
					return pa > pb
			1:
				if pa != pb:
					return pa > pb
		var na: String = Data.character(a).display_name
		var nb: String = Data.character(b).display_name
		if na != nb:
			return na < nb
		return String(a) < String(b))          # seri total: urut menurut id supaya hasilnya selalu sama
	return ids


func refresh() -> void:
	refresh_calls += 1
	_waiting.clear()                      # semua kartu dibangun ulang di bawah
	sel_slot = clampi(sel_slot, 0, mini(GameState.party.size(), GameState.PARTY_SIZE - 1))
	_powers.clear()
	for id in Data.character_ids():
		_powers[id] = int(GameState.char_stats(id)["power"])
	var total := 0
	for id in GameState.party:
		total += _power_of(id)
	_power.text = "⚔ %d" % total
	_refresh_slots()
	_refresh_roster()
	_refresh_bar()


## Hanya 4 kartu slot (mis. saat mengetuk slot lain): roster tidak ikut dibangun ulang.
func _refresh_slots() -> void:
	clear(_slots)
	for i in GameState.PARTY_SIZE:
		_slots.add_child(_slot_card(i))


func _refresh_roster() -> void:
	_sort_btn.text = "Urut: %s ▾" % SORTS[sort_mode]
	clear(_roster)
	for id in _sorted_ids():
		_roster.add_child(_roster_card(id))


func _refresh_bar() -> void:
	clear(_actions)
	var filled := sel_slot < GameState.party.size()
	if filled:
		var cid: String = GameState.party[sel_slot]
		_hint.text = "Slot %d: %s. Ketuk karakter di kanan untuk mengganti (jika sudah di slot lain, posisinya ditukar)." % [sel_slot + 1, Data.character(cid).display_name]
		if sel_slot > 0:
			_actions.add_child(btn("♛ Jadikan pemimpin", func(): GameState.make_leader(cid), Vector2(0, 46)))
		_actions.add_child(btn("Lepas", func():
			if not GameState.remove_from_party(cid):
				toast("Party minimal berisi 1 karakter."), Vector2(110, 46)))
	else:
		_hint.text = "Slot %d kosong. Ketuk karakter di kanan untuk mengisinya." % (sel_slot + 1)


func _unlock_hint(id: String) -> String:
	for qid in Data.quest_order:
		if Data.quest(qid).reward_character == id:
			return "Quest: %s" % Data.quest(qid).title
	return "Terkunci"


func _slot_card(i: int) -> Control:
	var filled := i < GameState.party.size()
	var sel := i == sel_slot
	var cid: String = GameState.party[i] if filled else ""
	var rc: Color = UiTheme.GOLD_DARK
	if filled:
		rc = rarity_color(Data.character(cid).rarity)
	var c := PanelContainer.new()
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.size_flags_vertical = Control.SIZE_EXPAND_FILL
	c.custom_minimum_size = Vector2(1, 0)
	c.add_theme_stylebox_override("panel", _sb(Color(0.2, 0.27, 0.52) if sel else Color(0.12, 0.15, 0.32), UiTheme.GOLD if sel else rc.darkened(0.3), 4 if sel else 2, 12, 6))
	c.clip_contents = true
	c.add_child(_gradient(Color(0.14, 0.2, 0.44), rc.darkened(0.35).lerp(Color(0.3, 0.55, 0.85), 0.4) if filled else Color(0.12, 0.16, 0.3)))
	var v := vbox(3)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.add_child(v)
	var head := _center(lbl("♛ PEMIMPIN" if i == 0 else "SLOT %d" % (i + 1), 15, UiTheme.GOLD if i == 0 else UiTheme.TEXT_DIM))
	v.add_child(head)
	if filled:
		var cd := Data.character(cid)
		var p := _portrait(cid, Vector2(0, 150), true, false, true)
		p.size_flags_vertical = Control.SIZE_EXPAND_FILL
		v.add_child(p)
		v.add_child(_center(lbl(cd.display_name, 22, UiTheme.TEXT)))
		v.add_child(_center(lbl("★".repeat(cd.rarity), 16, rc)))
		var rl := _center(lbl("%s · ⚔ %d" % [cd.role, _power_of(cid)], 14, UiTheme.TEXT_DIM))
		rl.clip_text = true
		rl.custom_minimum_size = Vector2(0, 0)
		v.add_child(rl)
	else:
		var e := _center(lbl("+", 64, UiTheme.TEXT_DIM))
		e.size_flags_vertical = Control.SIZE_EXPAND_FILL
		e.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		v.add_child(e)
		v.add_child(_center(lbl("Kosong", 18, UiTheme.TEXT_DIM)))
	tap_on(c, func():
		sel_slot = i
		_refresh_slots()
		_refresh_bar())
	return c


static func _gradient(top: Color, bottom: Color) -> TextureRect:
	var key := top.to_html() + bottom.to_html()
	var gt: GradientTexture2D = _grad_cache.get(key)
	if gt == null:
		var g := Gradient.new()
		g.set_color(0, top)
		g.set_color(1, bottom)
		gt = GradientTexture2D.new()
		gt.gradient = g
		gt.fill_from = Vector2(0.5, 0.0)
		gt.fill_to = Vector2(0.5, 1.0)
		gt.width = 8
		gt.height = 96
		_grad_cache[key] = gt
	var tr := TextureRect.new()
	tr.texture = gt
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return tr


static func _sb(bg: Color, border: Color = Color(0, 0, 0, 0), bw: int = 0, radius: int = 12, margin: int = 10) -> StyleBoxFlat:
	var key := "%s|%s|%d|%d|%d" % [bg.to_html(), border.to_html(), bw, radius, margin]
	var sb: StyleBoxFlat = _box_cache.get(key)
	if sb == null:
		sb = UiTheme.box(bg, border, bw, radius, margin)
		_box_cache[key] = sb
	return sb


static func _weapon_icon(cd: CharacterData) -> String:
	match cd.weapon_class:
		"bow": return "arrow_up"
		"staff": return "skill"
		"guard": return "shield"
	return "sword"


func _badge(text: String, col: Color) -> Control:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", _sb(Color(0.1, 0.12, 0.2, 0.85), col, 1, 6, 5))
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	p.add_child(_center(lbl(text, 15, col)))
	return p


func _roster_card(id: String) -> Control:
	var cd := Data.character(id)
	var owned := GameState.is_unlocked(id)
	var si := GameState.party.find(id)
	var rc := rarity_color(cd.rarity) if owned else Color(0.35, 0.38, 0.5)
	var c := PanelContainer.new()
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.custom_minimum_size = Vector2(0, 200)
	c.clip_contents = true
	var border := UiTheme.GOLD if si >= 0 else rc.darkened(0.15)
	c.add_theme_stylebox_override("panel", _sb(Color(0.1, 0.16, 0.34), border, 4 if si >= 0 else 2, 10, 0))
	c.add_child(_gradient(Color(0.16, 0.22, 0.46), Color(0.32, 0.62, 0.9) if owned else Color(0.2, 0.26, 0.42)))
	var v := vbox(0)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.add_child(v)
	var top := hbox(0)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(_badge("Slot %d" % (si + 1) if si >= 0 else ("Lv %d" % GameState.level if owned else "🔒"), UiTheme.GOLD if si >= 0 else UiTheme.TEXT))
	v.add_child(top)
	var p := _portrait(id, Vector2(0, 100), owned, true)
	p.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var pm := MarginContainer.new()
	pm.add_theme_constant_override("margin_left", 4)
	pm.add_theme_constant_override("margin_right", 4)
	pm.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pm.size_flags_vertical = Control.SIZE_EXPAND_FILL
	pm.add_child(p)
	v.add_child(pm)
	var nm := _center(lbl(cd.display_name if owned else "???", 17, UiTheme.TEXT))
	v.add_child(nm)
	# baris bawah ala daftar karakter: ikon senjata | bintang | ikon peran/status
	var bottom := PanelContainer.new()
	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_theme_stylebox_override("panel", _sb(Color(0.04, 0.08, 0.2, 0.55), Color(0, 0, 0, 0), 0, 0, 5))
	var bh := hbox(4)
	bh.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_child(bh)
	bh.add_child(UiIcon.make(_weapon_icon(cd), Color(0.85, 0.93, 1.0), 20))
	var stl := _center(lbl("★".repeat(cd.rarity), 14, rc.lightened(0.1)))
	stl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bh.add_child(stl)
	if owned:
		bh.add_child(_center(lbl("⚔%d" % _power_of(id), 13, UiTheme.SKY)))
	else:
		var tl := _center(lbl(_unlock_hint(id), 12, UiTheme.TEXT_DIM))
		tl.clip_text = true
		tl.custom_minimum_size = Vector2(70, 0)
		bh.add_child(tl)
	v.add_child(bottom)
	if owned:
		tap_on(c, func(): _assign(id))
	return c


func _assign(id: String) -> void:
	var slot := mini(sel_slot, GameState.party.size())
	GameState.set_party_slot(slot, id)
	if GameState.party.size() < GameState.PARTY_SIZE and sel_slot >= GameState.party.size():
		sel_slot = GameState.party.size()
