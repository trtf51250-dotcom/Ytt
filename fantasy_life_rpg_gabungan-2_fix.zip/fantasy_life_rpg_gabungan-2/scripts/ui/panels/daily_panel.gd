extends BasePanel
## Misi harian (3 misi, reset tiap tanggal baru + bonus bila semua selesai) dan Pencapaian (sekali seumur hidup).

var _tab := 0
var _body: VBoxContainer
var _tabs: HBoxContainer


func _init() -> void:
	refresh_on = ["daily", "currency", "roster", "profile"]


func build() -> void:
	_tabs = hbox(10)
	content.add_child(_tabs)
	var sl := scroll_list(0)
	sl[0].size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(sl[0])
	_body = sl[1]


func refresh() -> void:
	GameState.daily_refresh()
	clear(_tabs)
	var d := GameState.daily_ready_count()
	var a := GameState.ach_ready_count()
	_tabs.add_child(btn("Misi Harian%s" % (" (%d)" % d if d > 0 else ""), func(): _tab = 0; refresh(), Vector2(260, 52), UiTheme.GOLD if _tab == 0 else Color(0, 0, 0, 0)))
	_tabs.add_child(btn("Pencapaian%s" % (" (%d)" % a if a > 0 else ""), func(): _tab = 1; refresh(), Vector2(260, 52), UiTheme.GOLD if _tab == 1 else Color(0, 0, 0, 0)))
	clear(_body)
	if _tab == 0:
		_daily()
	else:
		_ach()


func _row(title: String, prog: int, need: int, reward: String, state: String, on_claim: Callable) -> Control:
	var c := card(UiTheme.GOLD if state == "ready" else (Color(0.4, 0.75, 0.5) if state == "claimed" else UiTheme.GOLD_DARK), Color(0.13, 0.2, 0.3) if state == "claimed" else Color(0.13, 0.17, 0.36))
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var r := hbox(12)
	c.add_child(r)
	var col := vbox(4)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	r.add_child(col)
	col.add_child(lbl(title, 22, UiTheme.TEXT))
	var bar := UiTheme.bar(UiTheme.SKY if state != "claimed" else Color(0.4, 0.75, 0.5), clampf(float(prog) / maxf(1.0, need), 0.0, 1.0), 12.0)
	col.add_child(bar)
	col.add_child(lbl("%d / %d   ·   Hadiah: %s" % [mini(prog, need), need, reward], 16, UiTheme.TEXT_DIM))
	if state == "ready":
		r.add_child(btn("Ambil", on_claim, Vector2(140, 54), UiTheme.GOLD))
	elif state == "claimed":
		r.add_child(lbl("Selesai", 20, Color(0.5, 0.85, 0.6)))
	return c


func _daily() -> void:
	_body.add_child(wrap_lbl("Tiga misi baru muncul setiap hari (tanggal %s). Selesaikan semuanya untuk hadiah bonus." % GameState.today(), 18, UiTheme.TEXT_DIM))
	var ms: Array = GameState.daily["m"]
	var all_c := true
	for i in ms.size():
		var m: Dictionary = ms[i]
		var st := "claimed" if m["c"] else ("ready" if int(m["p"]) >= int(m["need"]) else "active")
		if not m["c"]:
			all_c = false
		var idx := i
		_body.add_child(_row(Missions.text_for(m["kind"], int(m["need"])), int(m["p"]), int(m["need"]),
			"%d gold + %d diamond" % [Missions.DAILY_GOLD, Missions.DAILY_DIAMOND], st, func(): _claim(GameState.daily_claim(idx))))
	var bst := "claimed" if GameState.daily["bonus"] else ("ready" if all_c else "active")
	var done := ms.filter(func(m): return m["c"]).size()
	_body.add_child(_row("Bonus: selesaikan 3 misi hari ini", done, 3,
		"%d diamond + %d Ramuan Kecil" % [Missions.BONUS_DIAMOND, Missions.BONUS_ITEM_N], bst, func(): _claim(GameState.daily_bonus_claim())))


func _ach() -> void:
	for a in Missions.ACH:
		var st := GameState.ach_state(a)
		var rw := "%d diamond" % int(a["dia"]) + (" + %d gold" % int(a["gold"]) if int(a["gold"]) > 0 else "")
		var id: String = a["id"]
		_body.add_child(_row(str(a["title"]), GameState.ach_value(a["src"]), int(a["need"]), rw, st, func(): _claim(GameState.ach_claim(id))))


func _claim(ok: bool) -> void:
	if ok:
		toast("Hadiah diambil!")
		Sfx.play("pickup")
