extends BasePanel
## Toko: tab Senjata & Armor (Rowan), Ramuan (Mira), Jual. Membeli mengurangi gold, menambah item, dan melaporkan event quest "buy".

var tab := "weapon"
var selected := ""
var _tabs: HBoxContainer
var _list: VBoxContainer
var _detail: VBoxContainer


func _init() -> void:
	refresh_on = ["inventory", "currency", "equipment"]


func build() -> void:
	tab = str(args.get("tab", "weapon"))
	_tabs = hbox(8)
	content.add_child(_tabs)
	var row := hbox(14)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(row)
	var sl := scroll_list(480)
	row.add_child(sl[0])
	_list = sl[1]
	var right := PanelContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_stylebox_override("panel", UiTheme.box(Color(0.08, 0.11, 0.25), UiTheme.GOLD_DARK, 2, 14, 14))
	row.add_child(right)
	_detail = vbox(8)
	right.add_child(_detail)


func refresh() -> void:
	clear(_tabs)
	for t in [["weapon", "Senjata & Armor"], ["item", "Ramuan"], ["sell", "Jual"]]:
		var key: String = t[0]
		_tabs.add_child(btn(t[1], func():
			tab = key
			selected = ""
			refresh(), Vector2(190, 48), UiTheme.GOLD if key == tab else Color(0, 0, 0, 0)))
	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tabs.add_child(sp)
	var gl := hbox(6)
	gl.add_child(UiIcon.make("gold", Color(1, 1, 1), 30))
	gl.add_child(lbl("%d" % GameState.gold, 24, UiTheme.GOLD))
	_tabs.add_child(gl)
	clear(_list)
	var items: Array = []
	if tab == "sell":
		for id in GameState.inventory:
			items.append(Data.item(id))
		items = items.filter(func(it): return it != null)
		items.sort_custom(func(a, b): return a.rarity > b.rarity)
	else:
		items = Data.shop_items(tab)
	if selected == "" and not items.is_empty():
		selected = (items[0] as ItemData).id          # detail langsung terisi, tidak kosong
	for it: ItemData in items:
		var price := it.sell_price() if tab == "sell" else it.buy_price
		var right_text := "%dg" % price
		if tab == "sell":
			right_text = "×%d  %dg" % [GameState.item_count(it.id), price]
		var iid := it.id
		_list.add_child(item_row(it, right_text, func():
			selected = iid
			refresh(), iid == selected))
	if items.is_empty():
		_list.add_child(lbl("Tidak ada barang.", 22, UiTheme.TEXT_DIM))
	_fill_detail()


func _fill_detail() -> void:
	clear(_detail)
	if selected == "" or Data.item(selected) == null:
		_detail.add_child(lbl("Pilih barang di sebelah kiri.", 22, UiTheme.TEXT_DIM))
		return
	var it := Data.item(selected)
	_detail.add_child(lbl(it.display_name, 28, rarity_color(it.rarity).lightened(0.3)))
	_detail.add_child(lbl("%s · %s · Dimiliki %d" % [type_name(it.type), stars_text(it.rarity), GameState.item_count(selected)], 18, UiTheme.SKY))
	_detail.add_child(wrap_lbl(it.description, 19, UiTheme.TEXT_DIM))
	_detail.add_child(lbl(item_stats(it), 22, UiTheme.GOLD))
	var sp := Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_detail.add_child(sp)
	if tab == "sell":
		var cnt := GameState.item_count(selected)
		var price := it.sell_price()
		_detail.add_child(btn("Jual 1  (+%d gold)" % price, func(): _sell(it, 1), Vector2(0, 56)))
		if cnt > 1:
			_detail.add_child(btn("Jual semua ×%d  (+%d gold)" % [cnt, price * cnt], func(): _sell(it, cnt), Vector2(0, 56)))
	else:
		var b1 := btn("Beli 1  (%d gold)" % it.buy_price, func(): _buy(it, 1), Vector2(0, 56), UiTheme.GOLD)
		b1.disabled = GameState.gold < it.buy_price
		_detail.add_child(b1)
		if it.type == "potion":
			var b5 := btn("Beli 5  (%d gold)" % (it.buy_price * 5), func(): _buy(it, 5), Vector2(0, 56))
			b5.disabled = GameState.gold < it.buy_price * 5
			_detail.add_child(b5)
		if GameState.gold < it.buy_price:
			_detail.add_child(lbl("Gold tidak cukup.", 17, UiTheme.BAD))


func _buy(it: ItemData, n: int) -> void:
	if GameState.buy_item(it.id, n):
		Sfx.play("pickup")
		toast("Dibeli: %s ×%d" % [it.display_name, n])
	else:
		toast("Gold tidak cukup.")


func _sell(it: ItemData, n: int) -> void:
	if GameState.sell_item(it.id, n):
		Sfx.play("pickup")
		toast("Terjual: %s ×%d" % [it.display_name, n])
