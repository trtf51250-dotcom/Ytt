class_name TouchScroll
extends ScrollContainer
## Daftar bergulir yang ramah jari (Android): menyeret di MANA PUN di dalam daftar (juga di atas tombol/kartu) menggulir,
## dengan ambang geser kecil, inersia (meluncur pelan setelah dilepas), dan posisi gulir dipertahankan saat isi daftar dibangun ulang.
## Ketukan singkat tetap menekan tombol/kartu; begitu seretan dimulai, tekanan tombol dibatalkan (tidak ada aksi nyasar).
## Mouse/jari sama-sama lewat InputEventMouse (di Android lewat emulate_mouse_from_touch). Roda mouse tetap jalan (bawaan).

const DEADZONE := 12.0            # px sebelum dianggap menyeret
const FRICTION := 4.2             # peluruhan inersia per detik
const MIN_COAST := 30.0           # px/dtk, di bawah ini inersia berhenti
const FAR := Vector2(-9000, -9000)

var _down := false
var _dragging := false
var _start := Vector2.ZERO
var _fy := 0.0
var _vel := 0.0
var _coast := 0.0
var _last_t := 0
var _saved := -1
var _restore := 0


func _ready() -> void:
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll_deadzone = 100000          # penggulir sentuh bawaan dimatikan: kita pakai milik sendiri (tidak bentrok)
	get_v_scroll_bar().custom_minimum_size.x = 10.0
	set_process(true)


## Panggil sebelum isi daftar dibangun ulang: posisi gulir dipulihkan setelah tata letak selesai.
func remember() -> void:
	if _saved < 0 or _restore <= 0:
		_saved = scroll_vertical
	_restore = 4


func _max_scroll() -> float:
	var bar := get_v_scroll_bar()
	return maxf(bar.max_value - bar.page, 0.0)


func _input(ev: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if ev is InputEventMouseButton and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
		var mb := ev as InputEventMouseButton
		if mb.position.x < -1000.0:
			return                      # peristiwa pembatal buatan sendiri
		if mb.pressed:
			_down = get_global_rect().has_point(mb.position) and _max_scroll() > 0.0
			_dragging = false
			_vel = 0.0
			_coast = 0.0
			_start = mb.position
			_fy = float(scroll_vertical)
			_last_t = Time.get_ticks_msec()
		else:
			if _dragging:
				get_viewport().set_input_as_handled()
				_coast = _vel if absf(_vel) > MIN_COAST * 4.0 else 0.0
			_dragging = false
			_down = false
	elif ev is InputEventMouseMotion and _down:
		var mm := ev as InputEventMouseMotion
		if mm.position.x < -1000.0:
			return
		if not _dragging:
			if absf(mm.position.y - _start.y) < DEADZONE and (mm.position - _start).length() < DEADZONE * 1.6:
				return
			if absf(mm.position.x - _start.x) > absf(mm.position.y - _start.y) * 2.0:
				_down = false           # geseran mendatar: bukan menggulir
				return
			_dragging = true
			_cancel_press()
			_start = mm.position
			_fy = float(scroll_vertical)
			_last_t = Time.get_ticks_msec()
			return
		var now := Time.get_ticks_msec()
		var dt := maxf(float(now - _last_t) / 1000.0, 0.001)
		_last_t = now
		_fy = clampf(_fy - mm.relative.y, 0.0, _max_scroll())
		scroll_vertical = int(round(_fy))
		_vel = lerpf(_vel, mm.relative.y / dt, 0.35)
		get_viewport().set_input_as_handled()
	elif _dragging and (ev is InputEventScreenDrag or ev is InputEventScreenTouch):
		get_viewport().set_input_as_handled()


## Batalkan tekanan tombol/kartu yang sedang tertahan: geser penunjuk jauh ke luar layar lalu lepas di sana.
func _cancel_press() -> void:
	var m := InputEventMouseMotion.new()
	m.position = FAR
	m.global_position = FAR
	m.button_mask = MOUSE_BUTTON_MASK_LEFT
	Input.parse_input_event(m)
	var b := InputEventMouseButton.new()
	b.button_index = MOUSE_BUTTON_LEFT
	b.pressed = false
	b.position = FAR
	b.global_position = FAR
	Input.parse_input_event(b)


func _process(delta: float) -> void:
	if _restore > 0:
		_restore -= 1
		if _saved >= 0:
			scroll_vertical = mini(_saved, int(_max_scroll()))
		if _restore == 0:
			_saved = -1
	if _dragging or absf(_coast) < MIN_COAST:
		_coast = 0.0 if not _dragging else _coast
		return
	_fy = clampf(_fy + _coast * delta * -1.0, 0.0, _max_scroll())
	scroll_vertical = int(round(_fy))
	_coast *= exp(-FRICTION * delta)
	if _fy <= 0.0 or _fy >= _max_scroll():
		_coast = 0.0
