class_name GachaReveal
extends Control
## Upacara pemanggilan: lingkaran sihir berputar mengumpulkan cahaya (warna mengikuti rarity terbaik), kilatan, lalu kartu hasil
## dibuka satu per satu (kartu terbalik -> membalik). Rarity ★4+ mendapat kilau & suara khusus, ★5 ledakan emas + layar bergetar.
## Ketuk di mana saja untuk mempercepat / melewati. Hasil sudah diterapkan ke GameState sebelum overlay ini muncul (melewati aman).

signal finished

const BACK_COL := Color(0.16, 0.2, 0.46)

var results: Array = []
var _best := 1
var _skip := false
var _cards: Array = []
var _revealed := 0
var _done := false
var _tint: Color
var _circle: Control
var _flash: ColorRect
var _hint: Label
var _grid: GridContainer
var _btn_row: HBoxContainer
var _alive := true


static func tint_for(r: int) -> Color:
	match r:
		6: return Color(1.0, 0.5, 0.65)
		5: return Color(1.0, 0.8, 0.3)
		4: return Color(0.75, 0.5, 1.0)
		3: return Color(0.45, 0.8, 1.0)
		_: return Color(0.6, 0.85, 1.0)


func setup(res: Array) -> void:
	results = res
	for r: Dictionary in res:
		_best = maxi(_best, int(r["rarity"]))
	_tint = tint_for(_best)


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color(0.015, 0.025, 0.09, 0.95)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	_circle = Control.new()
	_circle.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_circle.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_circle)
	var sz := 520.0
	for i in 2:
		var tr := TextureRect.new()
		tr.texture = load("res://assets/fx/magic_outer.png" if i == 0 else "res://assets/fx/magic_inner.png")
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_SCALE
		tr.custom_minimum_size = Vector2(sz, sz)
		tr.size = Vector2(sz, sz)
		tr.position = Vector2(-sz / 2.0, -sz / 2.0)
		tr.pivot_offset = Vector2(sz / 2.0, sz / 2.0)
		tr.modulate = Color(_tint.r, _tint.g, _tint.b, 0.0)
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tr.name = "L%d" % i
		_circle.add_child(tr)
	_circle.scale = Vector2(0.45, 0.45)
	_grid = GridContainer.new()
	_grid.columns = 5 if results.size() > 1 else 1
	_grid.add_theme_constant_override("h_separation", 14)
	_grid.add_theme_constant_override("v_separation", 14)
	_grid.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_grid.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_grid.grow_vertical = Control.GROW_DIRECTION_BOTH
	_grid.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_grid)
	_flash = ColorRect.new()
	_flash.color = Color(1, 1, 1, 0.0)
	_flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_flash)
	_hint = UiTheme.label("Ketuk untuk melewati", 18, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER)
	_hint.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_hint.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_hint.offset_top = -52
	_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_hint)
	_btn_row = HBoxContainer.new()
	_btn_row.add_theme_constant_override("separation", 16)
	_btn_row.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_btn_row.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_btn_row.offset_top = -86
	_btn_row.visible = false
	add_child(_btn_row)
	gui_input.connect(_on_input)
	_play()


func _on_input(ev: InputEvent) -> void:
	if _done:
		return
	if (ev is InputEventMouseButton and ev.pressed) or (ev is InputEventScreenTouch and ev.pressed):
		_skip = true


func _wait(t: float) -> void:
	if _skip or not _alive:
		return
	var tm := get_tree().create_timer(t)
	var elapsed := 0.0
	while elapsed < t and not _skip and _alive and is_inside_tree():
		await get_tree().process_frame
		elapsed += get_process_delta_time()


func _process(delta: float) -> void:
	if _grid:
		_grid.position = (size - _grid.size) / 2.0 - Vector2(0, 26)
	if _circle and _circle.visible:
		_circle.position = size / 2.0 - Vector2(0, 20)
		_circle.get_node("L0").rotation += delta * (0.5 + (0.9 if _revealed == 0 else 0.0))
		_circle.get_node("L1").rotation -= delta * (0.8 + (1.4 if _revealed == 0 else 0.0))


func _play() -> void:
	# --- 1) pengumpulan cahaya
	Sfx.play("portal", 0.8, -4.0)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(_circle, "scale", Vector2(1.0, 1.0), 1.3).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	for i in 2:
		tw.tween_property(_circle.get_node("L%d" % i), "modulate:a", 0.95, 0.8)
	await _wait(1.35)
	if not _alive:
		return
	# --- 2) kilatan
	_flash.color = Color(_tint.r, _tint.g, _tint.b, 0.0).lerp(Color(1, 1, 1), 0.5)
	_flash.color.a = 0.95 if _best >= 4 else 0.6
	var ft := create_tween()
	ft.tween_property(_flash, "color:a", 0.0, 0.5)
	Sfx.play("chest" if _best >= 4 else "pickup")
	if _best >= 4:
		Sfx.play("boom", 1.3, -6.0)
	var shrink := create_tween()
	shrink.set_parallel(true)
	shrink.tween_property(_circle, "scale", Vector2(1.35, 1.35), 0.5).set_ease(Tween.EASE_OUT)
	for i in 2:
		shrink.tween_property(_circle.get_node("L%d" % i), "modulate:a", 0.28, 0.5)
	# --- 3) kartu
	for r: Dictionary in results:
		var c := _make_card(r)
		_grid.add_child(c)
		_cards.append(c)
	await get_tree().process_frame
	for c: Control in _cards:
		c.pivot_offset = c.size / 2.0
		c.scale = Vector2(0.01, 1.0) if false else Vector2(1, 1)
	for i in _cards.size():
		var c: Control = _cards[i]
		var face: Control = c.get_node("Face")
		var back: Control = c.get_node("Back")
		face.visible = false
		back.visible = true
		c.modulate.a = 0.0
		c.scale = Vector2(0.6, 0.6)
		var ap := create_tween()
		ap.set_parallel(true)
		ap.tween_property(c, "modulate:a", 1.0, 0.25).set_delay(0.04 * i)
		ap.tween_property(c, "scale", Vector2(1, 1), 0.3).set_delay(0.04 * i).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	await _wait(0.6)
	for i in _cards.size():
		await _reveal(i)
		await _wait(0.34 if int(results[i]["rarity"]) < 4 else 0.7)
	_finish()


func _reveal(i: int) -> void:
	var c: Control = _cards[i]
	var r: Dictionary = results[i]
	var rar := int(r["rarity"])
	var face: Control = c.get_node("Face")
	var back: Control = c.get_node("Back")
	c.pivot_offset = c.size / 2.0
	if _skip:
		back.visible = false
		face.visible = true
		_revealed += 1
		return
	var t1 := create_tween()
	t1.tween_property(c, "scale:x", 0.0, 0.1)
	await t1.finished
	back.visible = false
	face.visible = true
	var t2 := create_tween()
	t2.tween_property(c, "scale:x", 1.0, 0.14).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_revealed += 1
	var col := tint_for(rar)
	if rar >= 4:
		Sfx.play("chest", 1.0 + (rar - 4) * 0.2)
		var pop := create_tween()
		pop.tween_property(c, "scale", Vector2(1.14, 1.14), 0.12)
		pop.tween_property(c, "scale", Vector2(1, 1), 0.2)
		_sparkle(c, col, 22 if rar == 4 else (46 if rar == 5 else 80))
	if rar >= 5:
		Sfx.play("portal", 1.4 if rar == 5 else 1.2, -3.0)
		_flash.color = Color(1.0, 0.9, 0.5, 0.55) if rar == 5 else Color(1.0, 0.7, 0.85, 0.75)
		create_tween().tween_property(_flash, "color:a", 0.0, 0.6)
		var sh := create_tween()
		for k in 6:
			sh.tween_property(self, "position", Vector2(randf_range(-8, 8), randf_range(-6, 6)), 0.04)
		sh.tween_property(self, "position", Vector2.ZERO, 0.04)
	else:
		Sfx.play("select", 1.0 + rar * 0.08, -8.0)


func _sparkle(c: Control, col: Color, count: int) -> void:
	var p := CPUParticles2D.new()
	p.position = c.size / 2.0
	p.one_shot = true
	p.emitting = true
	p.amount = count
	p.lifetime = 0.9
	p.explosiveness = 1.0
	p.direction = Vector2(0, -1)
	p.spread = 180.0
	p.initial_velocity_min = 120.0
	p.initial_velocity_max = 300.0
	p.gravity = Vector2(0, 160)
	p.scale_amount_min = 3.0
	p.scale_amount_max = 7.0
	p.color = col.lightened(0.4)
	c.add_child(p)
	get_tree().create_timer(1.2).timeout.connect(p.queue_free)


func _make_card(r: Dictionary) -> Control:
	var rar := int(r["rarity"])
	var col: Color = UiTheme.RARITY[rar - 1]
	var single := results.size() == 1
	var size := Vector2(300, 330) if single else Vector2(188, 214)
	var root := Control.new()
	root.custom_minimum_size = size
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# punggung kartu
	var back := PanelContainer.new()
	back.name = "Back"
	back.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	back.add_theme_stylebox_override("panel", UiTheme.box(BACK_COL, Color(0.6, 0.7, 1.0, 0.8), 3, 16, 10))
	back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bi := UiIcon.make("star", Color(0.7, 0.8, 1.0, 0.7), int(size.x * 0.4))
	bi.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	bi.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	back.add_child(bi)
	root.add_child(back)
	# muka kartu
	var face := PanelContainer.new()
	face.name = "Face"
	face.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := Color(0.12, 0.15, 0.34).lerp(col, 0.18 + 0.06 * rar)
	face.add_theme_stylebox_override("panel", UiTheme.box(bg, col.lightened(0.15), (4 if rar >= 4 else 2), 16, 10))
	face.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var v := VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 4)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	face.add_child(v)
	var kind := "diamond"
	if r["kind"] == "character":
		kind = "character"
	elif r["kind"] == "item":
		kind = BasePanel.item_icon_kind(Data.item(r["id"]))
	var ic := UiIcon.make(kind, col.lightened(0.1), int(size.x * (0.34 if not single else 0.4)))
	ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(ic)
	var nm := UiTheme.label(str(r["name"]), 16 if not single else 24, UiTheme.TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	nm.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	nm.custom_minimum_size = Vector2(size.x - 28, 0)
	nm.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(nm)
	var st := UiTheme.label("%s  ×%d" % [BasePanel.stars_text(rar, rar), int(r["count"])], 15 if not single else 22, col.lightened(0.2), HORIZONTAL_ALIGNMENT_CENTER)
	st.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(st)
	root.add_child(face)
	return root


func _finish() -> void:
	_done = true
	_skip = true
	_hint.visible = false
	_btn_row.visible = true
	_circle.visible = false
	for i in _cards.size():
		var c: Control = _cards[i]
		c.get_node("Back").visible = false
		c.get_node("Face").visible = true
		c.scale = Vector2.ONE
	var ok := Button.new()
	ok.text = "OK"
	ok.custom_minimum_size = Vector2(220, 60)
	ok.pressed.connect(func():
		Sfx.play("select")
		_close())
	_btn_row.add_child(ok)
	var again := Button.new()
	again.text = "Tarik lagi"
	again.custom_minimum_size = Vector2(220, 60)
	again.pressed.connect(func():
		Sfx.play("select")
		_close(true))
	_btn_row.add_child(again)


var wants_again := false


func _close(again: bool = false) -> void:
	wants_again = again
	_alive = false
	finished.emit()
	queue_free()
