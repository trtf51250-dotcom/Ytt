class_name BasePanel
extends Control
## Dasar semua panel menu: latar redup, jendela bertema, judul + ikon, tombol tutup (X) besar, area isi, dan helper pembuat UI.
## Subclass menimpa build() (sekali, membuat widget) dan refresh() (dipanggil saat data berubah).
## Panel yang belum punya subclass tampil sebagai "belum tersedia" (build() bawaan).

signal close_requested

var host: PanelHost
var args: Dictionary = {}
var title_text := "Menu"
var title_icon := "star"
var refresh_on: Array = []             # jenis sinyal GameState.changed yang memicu refresh()
var window: PanelContainer
var content: VBoxContainer
var _title_lbl: Label
var _built := false
var _refresh_pending := false
var queued_refresh_runs := 0            # berapa kali refresh() lewat jalur gabungan (dipakai uji)


func _ready() -> void:
	theme = UiTheme.get_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.1, 0.62)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(dim)
	var m := UiTheme.safe_insets()                    # jendela tidak tertutup notch / sudut layar membulat
	window = PanelContainer.new()
	window.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	window.offset_left = 48.0 + float(m["left"])
	window.offset_right = -(48.0 + float(m["right"]))
	window.offset_top = 26.0 + float(m["top"])
	window.offset_bottom = -(26.0 + float(m["bottom"]))
	window.add_theme_stylebox_override("panel", UiTheme.box(Color(0.045, 0.07, 0.18, 0.985), UiTheme.GOLD_DARK, 2, 12, 16))
	add_child(window)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	window.add_child(v)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 12)
	v.add_child(head)
	head.add_child(UiIcon.make(title_icon, UiTheme.GOLD, 44))
	_title_lbl = UiTheme.label(title_text, 34, UiTheme.GOLD)
	var tf := FontVariation.new()                     # judul berhuruf agak renggang & tebal, selaras dengan logo layar judul
	tf.base_font = ThemeDB.fallback_font
	tf.spacing_glyph = 2
	tf.variation_embolden = 0.3
	_title_lbl.add_theme_font_override("font", tf)
	_title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_title_lbl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	head.add_child(_title_lbl)
	var x := Button.new()
	x.custom_minimum_size = Vector2(64, 56)
	x.focus_mode = Control.FOCUS_NONE
	x.add_theme_stylebox_override("normal", UiTheme.plate(Color(0.45, 0.13, 0.19, 0.96), Color(0.95, 0.5, 0.55), 4, 8, 4, 4))
	x.add_theme_stylebox_override("hover", UiTheme.plate(Color(0.62, 0.19, 0.25), Color(1, 0.7, 0.7), 6, 8, 4, 4))
	x.add_theme_stylebox_override("pressed", UiTheme.plate(Color(0.32, 0.09, 0.13), Color(1, 0.6, 0.6), 6, 8, 4, 4))
	x.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cc.add_child(UiIcon.make("close", Color(1, 1, 1), 28))
	x.add_child(cc)
	x.pressed.connect(func():
		Sfx.play("select")
		close_requested.emit())
	head.add_child(x)
	v.add_child(UiTheme.gold_rule(3.0))
	content = VBoxContainer.new()
	content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 10)
	v.add_child(content)
	build()
	_built = true
	GameState.changed.connect(_on_state_changed)
	refresh()


func set_title(t: String) -> void:
	title_text = t
	if _title_lbl:
		_title_lbl.text = t


func _on_state_changed(kind: String) -> void:
	if _built and (refresh_on.is_empty() or kind in refresh_on):
		queue_refresh()


## Segarkan SEKALI per frame: satu aksi sering memancarkan beberapa sinyal (mis. roster + party + equipment); dulu tiap sinyal
## membangun ulang seluruh panel. Panggil refresh() langsung bila butuh hasil seketika.
func queue_refresh() -> void:
	if _refresh_pending:
		return
	_refresh_pending = true
	_run_queued_refresh.call_deferred()


func _run_queued_refresh() -> void:
	_refresh_pending = false
	if is_inside_tree() and not is_queued_for_deletion():
		queued_refresh_runs += 1
		refresh()


## Menimpa: buat widget ke dalam `content`.
func build() -> void:
	content.add_child(UiTheme.label("Fitur ini belum tersedia.", 28, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER))
	content.add_child(UiTheme.label("Akan hadir di pembaruan berikutnya.", 22, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER))


func refresh() -> void:
	pass


# ---------------------------------------------------------------- helper UI
static func lbl(text: String, size: int = 22, col: Color = UiTheme.TEXT) -> Label:
	var l := UiTheme.label(text, size, col)
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	return l


static func wrap_lbl(text: String, size: int = 20, col: Color = UiTheme.TEXT_DIM) -> Label:
	var l := UiTheme.label(text, size, col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(120, 0)
	return l


static func hbox(sep: int = 10) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", sep)
	return h


static func vbox(sep: int = 8) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	return v


static func btn(text: String, cb: Callable, min_size: Vector2 = Vector2(0, 54), accent: Color = Color(0, 0, 0, 0)) -> Button:
	var b := UiTheme.button(text, min_size) if accent.a == 0.0 else UiTheme.accent_button(text, accent, min_size)
	b.pressed.connect(func():
		Sfx.play("select")
		cb.call())
	return b


static func clear(n: Node) -> void:
	var up: Node = n
	while up != null:
		if up is TouchScroll:
			(up as TouchScroll).remember()
			break
		up = up.get_parent()
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()


## Daftar bergulir (sentuh-seret). Mengembalikan [ScrollContainer, VBox isi].
static func scroll_list(min_w: float = 0.0) -> Array:
	var sc := TouchScroll.new()
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.custom_minimum_size = Vector2(min_w, 0)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 8)
	var m := MarginContainer.new()                    # ruang di kanan supaya batang gulir tidak menutupi isi kartu
	m.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	m.add_theme_constant_override("margin_right", 16)
	m.add_child(v)
	sc.add_child(m)
	return [sc, v]


## Judul bagian bergaya Pengaturan: teks emas + garis tipis di bawahnya.
static func section(parent: Control, text: String) -> void:
	if parent.get_child_count() > 0:
		var gap := Control.new()
		gap.custom_minimum_size = Vector2(0, 6)
		parent.add_child(gap)
	var v := vbox(4)
	v.add_child(lbl(text, 24, UiTheme.GOLD))
	v.add_child(UiTheme.gold_rule(2.0))
	parent.add_child(v)


## Baris kartu bergaya Pengaturan: kiri nama + petunjuk, kanan kontrol/nilai. Mengembalikan wadah kanan.
static func info_row(parent: Control, text: String, hint: String = "") -> HBoxContainer:
	var c := card(Color(UiTheme.GOLD_DARK, 0.8), Color(0.1, 0.13, 0.3, 0.95))
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var h := hbox(18)
	c.add_child(h)
	var left := vbox(2)
	left.custom_minimum_size = Vector2(300, 0)
	left.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	left.add_child(lbl(text, 23, UiTheme.TEXT))
	if hint != "":
		var hl := wrap_lbl(hint, 16, UiTheme.TEXT_DIM)
		hl.custom_minimum_size = Vector2(290, 0)
		left.add_child(hl)
	h.add_child(left)
	var right := hbox(12)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.alignment = BoxContainer.ALIGNMENT_END
	h.add_child(right)
	parent.add_child(c)
	return right


## Ketukan pada kartu: aksi dijalankan saat jari DILEPAS di dalam kartu (menyeret untuk menggulir tidak memicu aksi).
static func tap_on(c: Control, action: Callable) -> void:
	c.mouse_filter = Control.MOUSE_FILTER_STOP
	c.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and not ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT and Rect2(Vector2.ZERO, c.size).has_point(ev.position):
			Sfx.play("select")
			action.call())


static func card(border: Color = UiTheme.GOLD_DARK, bg: Color = Color(0.13, 0.17, 0.36, 1.0)) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiTheme.plate(bg, border, 5, 9, 10, 8))
	return p


static func item_icon_kind(it: ItemData) -> String:
	match it.type:
		"weapon": return "sword"
		"armor": return "shield"
		"accessory": return "star"
		"potion": return "potion"
	return "bag"


static func rarity_color(r: int) -> Color:
	return UiTheme.RARITY[clampi(r - 1, 0, 5)]


static func stars_text(n: int, total: int = 5) -> String:
	return "★".repeat(n) + "☆".repeat(maxi(total - n, 0))


static func item_stats(it: ItemData) -> String:
	var parts: PackedStringArray = []
	if it.atk != 0:
		parts.append("ATK +%d" % it.atk)
	if it.def != 0:
		parts.append("DEF +%d" % it.def)
	if it.hp != 0:
		parts.append("HP +%d" % it.hp)
	if it.heal != 0:
		parts.append("Pulih %d HP" % it.heal)
	return "  ".join(parts)


static func type_name(t: String) -> String:
	return {"weapon": "Senjata", "armor": "Armor", "accessory": "Aksesori", "potion": "Ramuan"}.get(t, t)


## Kartu item ringkas (ikon berwarna kelangkaan + nama + statistik). Bisa diketuk bila `on_tap` diberikan.
func item_row(it: ItemData, right_text: String = "", on_tap: Callable = Callable(), selected: bool = false) -> Control:
	var c := card(UiTheme.GOLD if selected else rarity_color(it.rarity).darkened(0.25), Color(0.2, 0.26, 0.5) if selected else Color(0.13, 0.17, 0.36))
	var r := hbox(10)
	c.add_child(r)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var ic := UiIcon.make(item_icon_kind(it), rarity_color(it.rarity), 44)
	r.add_child(ic)
	var col := vbox(0)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var nm := lbl(it.display_name, 22, rarity_color(it.rarity).lightened(0.3))
	nm.clip_text = true
	nm.custom_minimum_size = Vector2(150, 0)
	col.add_child(nm)
	var st := lbl("%s · %s" % [type_name(it.type), item_stats(it)], 16, UiTheme.TEXT_DIM)
	st.clip_text = true
	st.custom_minimum_size = Vector2(150, 0)
	col.add_child(st)
	r.add_child(col)
	if right_text != "":
		var rl := lbl(right_text, 22, UiTheme.GOLD)
		rl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		r.add_child(rl)
	if on_tap.is_valid():
		tap_on(c, on_tap)
	return c


## Baris karakter (potret warna aksen + nama + peran + bintang).
func char_row(id: String, on_tap: Callable = Callable(), selected: bool = false, extra: String = "") -> Control:
	var cd := Data.character(id)
	var owned := GameState.is_unlocked(id)
	var c := card(UiTheme.GOLD if selected else (cd.accent.darkened(0.2) if owned else Color(0.3, 0.33, 0.45)), Color(0.2, 0.26, 0.5) if selected else Color(0.13, 0.17, 0.36))
	var r := hbox(10)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.add_child(r)
	var av := PanelContainer.new()
	av.custom_minimum_size = Vector2(54, 54)
	av.mouse_filter = Control.MOUSE_FILTER_IGNORE
	av.add_theme_stylebox_override("panel", UiTheme.box(cd.accent.darkened(0.15) if owned else Color(0.25, 0.28, 0.38), Color(1, 1, 1, 0.8), 2, 27, 4))
	var ic := UiIcon.make("character" if owned else "lock", Color(1, 1, 1), 34)
	ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	av.add_child(ic)
	r.add_child(av)
	var col := vbox(0)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(lbl(cd.display_name, 24, UiTheme.TEXT if owned else UiTheme.TEXT_DIM))
	var sub := "%s · %s" % [cd.role, stars_text(GameState.stars(id))] if owned else "%s · Terkunci" % cd.role
	col.add_child(lbl(sub, 16, UiTheme.GOLD if owned else UiTheme.TEXT_DIM))
	r.add_child(col)
	if extra != "":
		var el := lbl(extra, 18, UiTheme.SKY)
		el.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		r.add_child(el)
	if on_tap.is_valid():
		tap_on(c, on_tap)
	return c


func toast(msg: String) -> void:
	Flow.toast(msg)
