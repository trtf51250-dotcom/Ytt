class_name Minimap
extends Control
## Peta digambar langsung (tanpa tekstur): dipakai sebagai minimap HUD (mengikuti pemain, berputar sesuai kamera) dan sebagai peta penuh
## (seluruh kota, bisa diketuk memilih titik teleport). Mode "stage" menggambar arena dan musuh.

signal waypoint_picked(id: String)
signal tapped

var mode := "lobby"                    # "lobby" | "stage"
var follow := true                     # true: pusat = pemain, zoom tetap; false: seluruh peta
var zoom := 1.0                        # hanya saat follow: >1 lebih dekat
var rotate_with_cam := true
var player: Node3D
var cam: Node
var lobby: Node3D
var stage: Node3D
var selected_wp := ""
var _t := 0.0
var _tap_start := Vector2.ZERO
var _view_r := 52.0                    # radius pandang (meter) saat follow
var _redraw_t := 0.0

const BG := Color(0.07, 0.1, 0.2, 0.82)
const EDGE := Color(0.96, 0.78, 0.3, 0.9)
const ROAD_C := Color(0.55, 0.6, 0.72, 0.55)
const BLD_C := Color(0.3, 0.42, 0.7, 0.85)
const GRASS_C := Color(0.2, 0.42, 0.3, 0.5)


func _ready() -> void:
	clip_contents = true
	mouse_filter = Control.MOUSE_FILTER_STOP


func _process(delta: float) -> void:
	_t += delta
	_redraw_t -= delta
	if _redraw_t <= 0.0:
		_redraw_t = 0.1 if follow else 0.25
		queue_redraw()


# ---------------------------------------------------------------- transformasi
func _world_rect() -> Rect2:
	if mode == "stage" and stage != null:
		var r: float = stage.arena.radius + 2.0
		return Rect2(-r, -r, r * 2.0, r * 2.0)
	return Rect2(LobbyLayout.WALL_MIN - Vector2(4, 4), (LobbyLayout.WALL_MAX - LobbyLayout.WALL_MIN) + Vector2(8, 8))


## dunia (x,z) -> piksel kontrol
func w2s(w: Vector2) -> Vector2:
	var c := size * 0.5
	if follow and player != null:
		var pp := Vector2(player.global_position.x, player.global_position.z)
		var sc := minf(size.x, size.y) * 0.5 / (_view_r / zoom)
		var d := (w - pp) * sc
		if rotate_with_cam and cam != null:
			d = d.rotated(_cam_yaw())
		return c + d
	var wr := _world_rect()
	var sc2 := minf(size.x / wr.size.x, size.y / wr.size.y)
	return c + (w - wr.get_center()) * sc2


func _scale() -> float:
	if follow:
		return minf(size.x, size.y) * 0.5 / (_view_r / zoom)
	var wr := _world_rect()
	return minf(size.x / wr.size.x, size.y / wr.size.y)


func _cam_yaw() -> float:
	# kamera melihat ke utara (-Z) saat yaw = 0 -> peta tidak berputar; yaw positif memutar balik
	var y: float = float(cam.get("yaw")) if cam != null and cam.get("yaw") != null else 0.0
	return y


func s2w(s: Vector2) -> Vector2:
	# kebalikan w2s untuk mode peta penuh
	var wr := _world_rect()
	var sc := minf(size.x / wr.size.x, size.y / wr.size.y)
	return wr.get_center() + (s - size * 0.5) / sc


# ---------------------------------------------------------------- input
func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton or e is InputEventScreenTouch:
		var pressed: bool = e.pressed
		if pressed:
			_tap_start = e.position
		else:
			if _tap_start.distance_to(e.position) < 24.0:
				if follow:
					tapped.emit()
				else:
					_pick(e.position)
			accept_event()


func _pick(pos: Vector2) -> void:
	var best := ""
	var bd := 38.0
	for w: Dictionary in Explore.WAYPOINTS:
		if not Explore.is_discovered(w["id"]):
			continue
		var d := w2s(w["pos"]).distance_to(pos)
		if d < bd:
			bd = d
			best = w["id"]
	if best != "":
		selected_wp = best
		waypoint_picked.emit(best)
		queue_redraw()


# ---------------------------------------------------------------- gambar
func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), BG)
	if mode == "stage":
		_draw_stage()
	else:
		_draw_lobby()
	draw_rect(Rect2(Vector2.ZERO, size), EDGE, false, 3.0)


func _poly_rect(a: Vector2, b: Vector2, col: Color) -> void:
	# kotak sejajar sumbu dunia -> poligon terputar bila perlu
	var pts := PackedVector2Array([w2s(Vector2(a.x, a.y)), w2s(Vector2(b.x, a.y)), w2s(Vector2(b.x, b.y)), w2s(Vector2(a.x, b.y))])
	draw_colored_polygon(pts, col)


func _draw_lobby() -> void:
	if lobby == null:
		return
	_poly_rect(LobbyLayout.WALL_MIN, LobbyLayout.WALL_MAX, GRASS_C)
	for r: Dictionary in LobbyLayout.ROADS:
		var pts: Array = r["pts"]
		for i in range(pts.size() - 1):
			draw_line(w2s(pts[i]), w2s(pts[i + 1]), ROAD_C, maxf(2.0, float(r["w"]) * _scale()))
	var world = lobby.get("world")
	if world != null:
		for b in world.buildings:
			var bb: AABB = b.world_aabb
			if bb.size.x > 60.0:
				continue
			_poly_rect(Vector2(bb.position.x, bb.position.z), Vector2(bb.end.x, bb.end.z), BLD_C)
	draw_arc(w2s(Vector2.ZERO), LobbyLayout.PLAZA_R * _scale(), 0, TAU, 28, Color(0.8, 0.85, 1.0, 0.35), 1.5)
	_draw_markers()
	_draw_player()
	if not follow:
		return


func _draw_markers() -> void:
	var f := ThemeDB.fallback_font
	for z: Dictionary in Explore.ZONES:
		if Explore.is_discovered(z["id"]):
			var c := w2s(z["pos"])
			draw_arc(c, float(z["r"]) * _scale(), 0, TAU, 24, Color(0.5, 0.8, 1.0, 0.8), 2.0)
			if not follow:
				draw_string(f, c + Vector2(-70, -float(z["r"]) * _scale() - 4), z["name"], HORIZONTAL_ALIGNMENT_CENTER, 140, 13, Color(0.75, 0.9, 1.0))
	for c: Dictionary in Explore.CHESTS:
		if not Explore.is_discovered(c["id"]):
			continue
		var p := w2s(c["pos"])
		if Explore.is_opened(c["id"]):
			draw_rect(Rect2(p - Vector2(3, 3), Vector2(6, 6)), Color(0.5, 0.5, 0.55, 0.8))
		else:
			var col: Color = Explore.TIERS[c["tier"]]["col"]
			var pulse := 1.0 + 0.25 * sin(_t * 5.0)
			draw_rect(Rect2(p - Vector2(5, 4) * pulse, Vector2(10, 8) * pulse), col)
			draw_rect(Rect2(p - Vector2(5, 4) * pulse, Vector2(10, 8) * pulse), Color(0.1, 0.07, 0.03), false, 1.5)
	for w: Dictionary in Explore.WAYPOINTS:
		var known := Explore.is_discovered(w["id"])
		var p2 := w2s(w["pos"])
		var col2 := Color(0.55, 0.9, 1.0) if known else Color(0.45, 0.48, 0.55, 0.6)
		var rr := 8.0 if w["id"] != selected_wp else 11.0
		draw_colored_polygon(PackedVector2Array([p2 + Vector2(0, -rr), p2 + Vector2(rr, 0), p2 + Vector2(0, rr), p2 + Vector2(-rr, 0)]), col2)
		draw_polyline(PackedVector2Array([p2 + Vector2(0, -rr), p2 + Vector2(rr, 0), p2 + Vector2(0, rr), p2 + Vector2(-rr, 0), p2 + Vector2(0, -rr)]), Color(0.05, 0.1, 0.25), 1.5)
		if not follow and known:
			if not _is_zone_name(w["name"]):
				draw_string(f, p2 + Vector2(-70, 22), w["name"], HORIZONTAL_ALIGNMENT_CENTER, 140, 13, Color(0.9, 0.97, 1.0))
		elif not follow:
			draw_string(f, p2 + Vector2(-6, 5), "?", HORIZONTAL_ALIGNMENT_CENTER, 12, 14, Color(0.9, 0.9, 0.95))


func _is_zone_name(n: String) -> bool:
	for z: Dictionary in Explore.ZONES:
		if z["name"] == n and Explore.is_discovered(z["id"]):
			return true
	return false


func _draw_player() -> void:
	if player == null:
		return
	var p := w2s(Vector2(player.global_position.x, player.global_position.z))
	var face: float = float(player.get("facing")) if player.get("facing") != null else 0.0
	# arah hadap dunia (sin f, cos f) pada (x,z); putar sesuai peta bila follow & rotate
	var dir := Vector2(sin(face), cos(face))
	if follow and rotate_with_cam and cam != null:
		dir = dir.rotated(_cam_yaw())
	var ang := dir.angle()
	var s := 9.0
	var pts := PackedVector2Array([p + Vector2(s, 0).rotated(ang), p + Vector2(-s * 0.7, s * 0.7).rotated(ang), p + Vector2(-s * 0.3, 0).rotated(ang), p + Vector2(-s * 0.7, -s * 0.7).rotated(ang)])
	draw_colored_polygon(pts, Color(1, 0.95, 0.4))
	draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), Color(0.2, 0.1, 0.0), 1.5)


func _draw_stage() -> void:
	if stage == null:
		return
	var R: float = stage.arena.radius
	draw_arc(w2s(Vector2.ZERO), R * _scale(), 0, TAU, 40, Color(0.8, 0.85, 1.0, 0.5), 2.0)
	draw_circle(w2s(Vector2.ZERO), R * _scale(), Color(0.2, 0.35, 0.3, 0.35))
	for e in stage.get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(e) or e.dead:
			continue
		var p := w2s(Vector2(e.global_position.x, e.global_position.z))
		if e.is_boss:
			draw_circle(p, 7.0, Color(1, 0.25, 0.3))
			draw_arc(p, 9.0, 0, TAU, 12, Color(1, 0.8, 0.3), 2.0)
		else:
			draw_circle(p, 3.5, Color(1, 0.5, 0.4) if not e.get("elite") else Color(1, 0.85, 0.3))
	if bool(stage.get("field")):
		for z: Dictionary in stage.field_zones:
			if Explore.is_discovered(z["id"]):
				draw_arc(w2s(z["pos"]), float(z["r"]) * _scale(), 0, TAU, 20, Color(0.5, 0.8, 1.0, 0.8), 2.0)
		for c: Dictionary in stage.field_chests:
			if not Explore.is_discovered(c["id"]):
				continue
			var pc := w2s(c["pos"])
			if Explore.is_opened(c["id"]):
				draw_rect(Rect2(pc - Vector2(3, 3), Vector2(6, 6)), Color(0.5, 0.5, 0.55, 0.8))
			else:
				var col: Color = Explore.TIERS[c["tier"]]["col"]
				draw_rect(Rect2(pc - Vector2(5, 4), Vector2(10, 8)), col)
				draw_rect(Rect2(pc - Vector2(5, 4), Vector2(10, 8)), Color(0.1, 0.07, 0.03), false, 1.5)
		var pg := w2s(stage.field_gate)
		draw_colored_polygon(PackedVector2Array([pg + Vector2(0, -8), pg + Vector2(8, 0), pg + Vector2(0, 8), pg + Vector2(-8, 0)]), Color(0.55, 0.9, 1.0))
	for c in stage.get_tree().get_nodes_in_group("stage_chests"):
		if is_instance_valid(c) and c.visible:
			var p2 := w2s(Vector2(c.global_position.x, c.global_position.z))
			draw_rect(Rect2(p2 - Vector2(5, 4), Vector2(10, 8)), Color(1, 0.8, 0.28))
	_draw_player()
