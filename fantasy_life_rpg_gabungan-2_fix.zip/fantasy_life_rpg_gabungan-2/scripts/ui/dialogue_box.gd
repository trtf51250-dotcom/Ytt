class_name DialogueBox
extends Control
## Kotak dialog di bawah layar: nama + gelar pembicara, teks mengetik huruf demi huruf, ketuk untuk lanjut,
## di akhir muncul pilihan. Mendukung simpul dialog (lihat NpcDefs): "goto" pindah simpul, "action" dikirim ke pemanggil.

signal action_chosen(action: String)
signal closed

var _panel: PanelContainer
var _name_lbl: Label
var _title_lbl: Label
var _text: RichTextLabel
var _more: Label
var _choices: VBoxContainer
var _nodes: Dictionary = {}
var _lines: Array = []
var _line_i := 0
var _cur_choices: Array = []
var _typing := false
var _tween: Tween
var _speaker := ""
var _speaker_title := ""
var is_open := false


func _ready() -> void:
	theme = UiTheme.get_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = false
	_panel = PanelContainer.new()
	_panel.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_panel.offset_left = 70
	_panel.offset_right = -70
	_panel.offset_bottom = -16
	_panel.custom_minimum_size = Vector2(0, 190)
	_panel.add_theme_stylebox_override("panel", UiTheme.box(Color(0.06, 0.09, 0.22, 0.95), UiTheme.GOLD, 3, 20, 20))
	add_child(_panel)
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_panel.gui_input.connect(_on_gui_input)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 22)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(row)
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(left)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 12)
	head.mouse_filter = Control.MOUSE_FILTER_IGNORE
	left.add_child(head)
	_name_lbl = UiTheme.label("", 28, UiTheme.GOLD)
	head.add_child(_name_lbl)
	_title_lbl = UiTheme.label("", 19, UiTheme.TEXT_DIM)
	_title_lbl.size_flags_vertical = Control.SIZE_SHRINK_END
	head.add_child(_title_lbl)
	_text = RichTextLabel.new()
	_text.bbcode_enabled = false
	_text.fit_content = false
	_text.scroll_active = false
	_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_text.custom_minimum_size = Vector2(0, 100)
	_text.add_theme_font_size_override("normal_font_size", 24)
	_text.add_theme_color_override("default_color", UiTheme.TEXT)
	_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
	left.add_child(_text)
	_more = UiTheme.label("ketuk untuk lanjut  ▼", 16, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_RIGHT)
	left.add_child(_more)
	_choices = VBoxContainer.new()
	_choices.add_theme_constant_override("separation", 8)
	_choices.custom_minimum_size = Vector2(320, 0)
	_choices.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(_choices)


func start(speaker: String, speaker_title: String, nodes: Dictionary, node_id: String = "start") -> void:
	_nodes = nodes
	_speaker = speaker
	_speaker_title = speaker_title
	_name_lbl.text = speaker
	_title_lbl.text = speaker_title
	is_open = true
	visible = true
	Sfx.play("dialog")
	_goto(node_id)


func _goto(node_id: String) -> void:
	var n: Dictionary = _nodes.get(node_id, _nodes.get("start", {}))
	_lines = n.get("lines", ["..."])
	_cur_choices = n.get("choices", [])
	_line_i = 0
	_show_line()


func _clear_choices() -> void:
	for c in _choices.get_children():
		c.queue_free()


func _show_line() -> void:
	_clear_choices()
	_text.text = _lines[_line_i]
	_text.visible_characters = 0
	_typing = true
	_more.visible = false
	if _tween:
		_tween.kill()
	var count := _text.get_total_character_count()
	_tween = create_tween()
	_tween.tween_property(_text, "visible_characters", count, maxf(count * 0.022, 0.05))
	_tween.finished.connect(_on_typed)


func _on_typed() -> void:
	_typing = false
	_text.visible_characters = -1
	if _line_i < _lines.size() - 1:
		_more.visible = true
	else:
		_more.visible = false
		_show_choices()


func _show_choices() -> void:
	_clear_choices()
	var cs: Array = _cur_choices
	if cs.is_empty():
		cs = [{"text": "Tutup", "action": "close"}]
	for ch: Dictionary in cs:
		var b := UiTheme.button(str(ch["text"]), Vector2(0, 52))
		b.pressed.connect(func(): _choose(ch))
		_choices.add_child(b)


func _choose(ch: Dictionary) -> void:
	Sfx.play("select")
	if ch.has("goto"):
		_goto(ch["goto"])
	elif ch.has("action") and ch["action"] != "close":
		var act: String = ch["action"]
		close()
		action_chosen.emit(act)
	else:
		close()


## Maju: selesaikan ketikan, atau pindah ke baris berikutnya.
func advance() -> void:
	if not is_open:
		return
	if _typing:
		if _tween:
			_tween.kill()
		_on_typed()
	elif _line_i < _lines.size() - 1:
		_line_i += 1
		_show_line()


func close() -> void:
	if not is_open:
		return
	is_open = false
	visible = false
	if _tween:
		_tween.kill()
	closed.emit()


func _on_gui_input(ev: InputEvent) -> void:
	if ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT:
		advance()


func blocked_rects() -> Array:
	if is_open:
		return [get_viewport_rect()]
	return []
