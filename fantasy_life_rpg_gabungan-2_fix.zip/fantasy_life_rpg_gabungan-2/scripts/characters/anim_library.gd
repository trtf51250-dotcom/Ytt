class_name AnimLibrary
extends RefCounted
## Perpustakaan animasi karakter (rig "ZN RIG V2", 17 tulang). Semua animasi dibuat lewat kode menjadi
## resource `Animation` asli (track rotasi tulang), lalu dimainkan oleh AnimationPlayer / AnimationTree.
## Dengan begini animasi bisa disetel dari kode, dan tetap berupa Animation Godot biasa (bisa dilihat di editor).
##
## Konvensi sudut (euler, radian): untuk lengan x negatif = ayun ke depan/atas; untuk paha x positif = kaki ke belakang.

const MODEL_NODE := "Model/Skeleton3D"        # path skeleton relatif terhadap CharacterRig
const BONES := ["root", "hips", "spine", "chest", "head", "upperarm_l", "forearm_l", "hand_l",
	"upperarm_r", "forearm_r", "hand_r", "thigh_l", "shin_l", "foot_l", "thigh_r", "shin_r", "foot_r"]
const HIPS_REST := Vector3(0, 0.9048, 0)
const FPS := 24.0

static var _lib: AnimationLibrary = null


## Daftar animasi: nama -> [panjang detik, loop?, fungsi pose(u) dengan u dari 0..1]
static func _defs() -> Dictionary:
	return {
		# ---- gerak dasar (bersenjata, dipakai pemain)
		"idle": [2.4, true, func(u): return _p_idle(u, true)],
		"walk": [1.0, true, func(u): return _p_loco(u, 0.5, true)],
		"run": [0.7, true, func(u): return _p_loco(u, 1.0, true)],
		# ---- gerak dasar (tanpa senjata, NPC & monster humanoid)
		"idle_n": [2.4, true, func(u): return _p_idle(u, false)],
		"walk_n": [1.0, true, func(u): return _p_loco(u, 0.42, false)],
		# ---- aksi
		"turn_l": [0.32, false, func(u): return _p_turn(u, 1.0)],
		"turn_r": [0.32, false, func(u): return _p_turn(u, -1.0)],
		"dodge": [0.45, false, func(u): return _p_dodge(u)],
		"attack_sword1": [0.55, false, func(u): return _p_sword(u, 0)],
		"attack_sword2": [0.55, false, func(u): return _p_sword(u, 1)],
		"attack_dagger1": [0.3, false, func(u): return _p_dagger(u, 0)],
		"attack_dagger2": [0.3, false, func(u): return _p_dagger(u, 1)],
		"attack_dagger3": [0.52, false, func(u): return _p_dagger(u, 2)],
		"skill_dagger": [0.62, false, func(u): return _p_skill_dagger(u)],
		"attack_staff": [0.6, false, func(u): return _p_staff(u)],
		"attack_smash": [0.95, false, func(u): return _p_smash(u)],
		"attack_bow": [0.65, false, func(u): return _p_bow(u, false)],
		"skill_sword": [0.95, false, func(u): return _p_skill_sword(u)],
		"skill_staff": [1.05, false, func(u): return _p_skill_staff(u)],
		"skill_guard": [1.1, false, func(u): return _p_skill_guard(u)],
		"skill_bow": [0.95, false, func(u): return _p_bow(u, true)],
		"hurt": [0.4, false, func(u): return _p_hurt(u)],
		"death": [1.0, false, func(u): return _p_death(u)],
		"victory": [1.4, true, func(u): return _p_victory(u)],
		# ---- variasi diam NPC
		"idle_cross": [3.0, true, func(u): return _p_cross(u)],
		"idle_hammer": [1.2, true, func(u): return _p_hammer(u)],
		"idle_wave": [2.4, true, func(u): return _p_wave(u)],
		"idle_gesture": [3.0, true, func(u): return _p_gesture(u)],
		"idle_attention": [3.0, true, func(u): return _p_attention(u)],
		"idle_stir": [3.0, true, func(u): return _p_stir(u)],
	}


static func get_library() -> AnimationLibrary:
	if _lib != null:
		return _lib
	_lib = AnimationLibrary.new()
	var defs := _defs()
	for name in defs:
		var d: Array = defs[name]
		_lib.add_animation(name, _make(d[0], d[1], d[2]))
	return _lib


static func names() -> Array:
	return _defs().keys()


static func _make(length: float, loop: bool, fn: Callable) -> Animation:
	var anim := Animation.new()
	anim.length = length
	anim.loop_mode = Animation.LOOP_LINEAR if loop else Animation.LOOP_NONE
	var tracks := {}
	for b in BONES:
		var ti := anim.add_track(Animation.TYPE_ROTATION_3D)
		anim.track_set_path(ti, NodePath("%s:%s" % [MODEL_NODE, b]))
		tracks[b] = ti
	var hip_t := anim.add_track(Animation.TYPE_POSITION_3D)
	anim.track_set_path(hip_t, NodePath("%s:hips" % MODEL_NODE))
	var n := maxi(2, int(ceil(length * FPS)))
	for i in n + 1:
		var u := float(i) / n
		var pose: Dictionary = fn.call(u)
		var tm := u * length
		for b in BONES:
			anim.rotation_track_insert_key(tracks[b], tm, Quaternion.from_euler(pose[b]))
		anim.position_track_insert_key(hip_t, tm, HIPS_REST + Vector3(pose["hx"], pose["bob"], pose["hz"]))
	return anim


# =====================================================================
#  Util pose
# =====================================================================
static func _base() -> Dictionary:
	var d := {}
	for b in BONES:
		d[b] = Vector3.ZERO
	d["bob"] = 0.0
	d["hx"] = 0.0
	d["hz"] = 0.0
	return d


static func _mix(a: Dictionary, b: Dictionary, w: float) -> Dictionary:
	var o := {}
	for k in a:
		if a[k] is Vector3:
			o[k] = (a[k] as Vector3).lerp(b[k], w)
		else:
			o[k] = lerpf(a[k], b[k], w)
	return o


static func _ease_out(k: float) -> float:
	return 1.0 - pow(1.0 - clampf(k, 0.0, 1.0), 3.0)


static func _ease_io(k: float) -> float:
	k = clampf(k, 0.0, 1.0)
	return k * k * (3.0 - 2.0 * k)


## Pulihkan ke pose siaga di bagian akhir animasi aksi supaya sambungan ke gerak dasar mulus.
static func _recover(strike: Dictionary, u: float, from_u: float = 0.74, armed: bool = true) -> Dictionary:
	if u <= from_u:
		return strike
	return _mix(strike, _p_idle(0.0, armed), _ease_io((u - from_u) / (1.0 - from_u)))


# =====================================================================
#  Gerak dasar
# =====================================================================
static func _p_idle(u: float, armed: bool) -> Dictionary:
	var d := _base()
	var br := sin(u * TAU)
	d["spine"] = Vector3(0.02 * br, 0, 0)
	d["chest"] = Vector3(0.025 * br, 0, 0)
	d["head"] = Vector3(-0.03 + 0.02 * br, 0.12 * sin(u * TAU) - 0.05 * sin(u * TAU * 2.0), 0)
	d["upperarm_l"] = Vector3(0, 0, 0.08 + 0.02 * br)
	d["forearm_l"] = Vector3(-0.15, 0, 0)
	if armed:
		d["upperarm_r"] = Vector3(-0.3, 0, -0.1 - 0.02 * br)
		d["forearm_r"] = Vector3(-0.6, 0, 0)
		d["hand_r"] = Vector3(-0.1, 0, 0)
	else:
		d["upperarm_r"] = Vector3(0, 0, -0.08 - 0.02 * br)
		d["forearm_r"] = Vector3(-0.15, 0, 0)
	d["thigh_l"] = Vector3(0, 0, 0.03)
	d["thigh_r"] = Vector3(0, 0, -0.03)
	d["hips"] = Vector3(0, 0.03 * br, 0.035 * br)
	d["bob"] = -0.012 * (0.5 + 0.5 * br)
	return d


## Siklus jalan/lari. run: 0..1 (0.5 jalan santai, 1.0 lari penuh).
static func _p_loco(u: float, run: float, armed: bool) -> Dictionary:
	var d := _base()
	var ph := u * TAU
	var s := sin(ph)
	var c := cos(ph)
	var stride := 0.62 * run
	d["thigh_l"] = Vector3(-stride * s, 0, 0.02)
	d["thigh_r"] = Vector3(stride * s, 0, -0.02)
	d["shin_l"] = Vector3(run * (0.1 + 1.0 * maxf(0.0, c)), 0, 0)
	d["shin_r"] = Vector3(run * (0.1 + 1.0 * maxf(0.0, -c)), 0, 0)
	d["foot_l"] = Vector3(-(d["thigh_l"].x + d["shin_l"].x) * 0.55, 0, 0)
	d["foot_r"] = Vector3(-(d["thigh_r"].x + d["shin_r"].x) * 0.55, 0, 0)
	d["upperarm_l"] = Vector3(0.55 * run * s, 0, 0.07)
	d["forearm_l"] = Vector3(-(0.14 + run * (0.3 + 0.35 * maxf(0.0, -s))), 0, 0)
	if armed:
		d["upperarm_r"] = Vector3(-0.3 - 0.16 * run * s, 0, -0.1)
		d["forearm_r"] = Vector3(-(0.6 + 0.1 * run * maxf(0.0, s)), 0, 0)
		d["hand_r"] = Vector3(-0.1, 0, 0)
	else:
		d["upperarm_r"] = Vector3(-0.55 * run * s, 0, -0.07)
		d["forearm_r"] = Vector3(-(0.14 + run * (0.3 + 0.35 * maxf(0.0, s))), 0, 0)
	d["spine"] = Vector3(0.05 + 0.2 * run, 0.22 * run * s, 0.05 * run * c)
	d["chest"] = Vector3(0, 0.1 * run * s, 0)
	d["head"] = Vector3(-0.06 - 0.12 * run, -0.3 * run * s, -0.04 * run * c)
	d["hips"] = Vector3(0, -0.1 * run * s, -0.04 * run * c)
	d["bob"] = 0.065 * run * cos(2.0 * ph) - 0.01
	d["hz"] = 0.03 * run
	return d


## Berbelok tajam (rem + condong): dipakai saat arah gerak berbalik / NPC menoleh. dir: +1 kiri, -1 kanan.
static func _p_turn(u: float, dir: float) -> Dictionary:
	var d := _p_idle(0.0, true)
	var e := sin(u * PI)
	d["spine"] = Vector3(-0.2 * e, 0.55 * dir * e, 0.12 * dir * e)
	d["chest"] = Vector3(0, 0.25 * dir * e, 0)
	d["head"] = Vector3(-0.05, 0.7 * dir * e, 0)
	d["upperarm_l"] = Vector3(0.1, 0, 0.55 + 0.35 * e)
	d["upperarm_r"] = Vector3(-0.3, 0, -0.5 - 0.3 * e)
	d["forearm_r"] = Vector3(-0.5, 0, 0)
	d["thigh_l"] = Vector3(0.25 * e, 0, 0.1 + 0.12 * e)
	d["thigh_r"] = Vector3(-0.2 * e, 0, -0.1 - 0.12 * e)
	d["shin_l"] = Vector3(0.15 * e, 0, 0)
	d["shin_r"] = Vector3(0.25 * e, 0, 0)
	d["bob"] = -0.05 * e
	return d


## Menghindar / dash: tubuh condong jauh ke depan, tangan ke belakang.
static func _p_dodge(u: float) -> Dictionary:
	var d := _base()
	var e := minf(1.0, _ease_out(u * 3.0)) * (1.0 - _ease_io((u - 0.7) / 0.3))
	var ph := u * TAU * 2.0
	d["spine"] = Vector3(0.75 * e, 0, 0)
	d["chest"] = Vector3(0.1 * e, 0, 0)
	d["head"] = Vector3(-0.6 * e, 0, 0)
	d["upperarm_l"] = Vector3(1.3 * e, 0, 0.2 * e)
	d["upperarm_r"] = Vector3(1.3 * e, 0, -0.2 * e)
	d["forearm_l"] = Vector3(-0.5 * e, 0, 0)
	d["forearm_r"] = Vector3(-0.5 * e, 0, 0)
	d["thigh_l"] = Vector3(-0.9 * e * sin(ph), 0, 0.02)
	d["thigh_r"] = Vector3(0.9 * e * sin(ph), 0, -0.02)
	d["shin_l"] = Vector3(e * (0.3 + 0.9 * maxf(0.0, cos(ph))), 0, 0)
	d["shin_r"] = Vector3(e * (0.3 + 0.9 * maxf(0.0, -cos(ph))), 0, 0)
	d["bob"] = -0.14 * e
	return d


# =====================================================================
#  Serangan & skill — berfase: 1) antisipasi (menarik/menyiapkan)  2) ayunan cepat (snap + overshoot)
#  3) tahan / follow-through  4) pemulihan ke siaga. Tiap animasi = daftar keyframe pose [waktu 0..1, pose, mode].
#  Mode ease: "io" halus, "out" melambat di akhir, "back" cepat lalu melewati target sedikit (kesan tenaga).
# =====================================================================
## Waktu (fraksi panjang animasi) saat serangan benar-benar mengenai. Dipakai pemain untuk menyinkronkan damage & efek.
const IMPACT := {
	"attack_dagger1": 0.36, "attack_dagger2": 0.36, "attack_dagger3": 0.42, "skill_dagger": 0.40,
	"attack_sword1": 0.36, "attack_sword2": 0.36, "attack_staff": 0.40, "attack_smash": 0.52, "attack_bow": 0.46,
	"skill_sword": 0.52, "skill_staff": 0.58, "skill_guard": 0.62, "skill_bow": 0.50,
}


static func impact_time(anim: String) -> float:
	var d: Array = _defs().get(anim, [0.5])
	return float(d[0]) * float(IMPACT.get(anim, 0.4))


static func _ease_back(k: float) -> float:
	k = clampf(k, 0.0, 1.0)
	var c1 := 1.9
	var c3 := c1 + 1.0
	return 1.0 + c3 * pow(k - 1.0, 3.0) + c1 * pow(k - 1.0, 2.0)


static func _seq(u: float, frames: Array) -> Dictionary:
	if u <= frames[0][0]:
		return frames[0][1]
	for i in range(1, frames.size()):
		var f: Array = frames[i]
		if u <= f[0]:
			var prev: Array = frames[i - 1]
			var k: float = (u - prev[0]) / maxf(f[0] - prev[0], 0.0001)
			var w := k
			match f[2]:
				"io": w = _ease_io(k)
				"out": w = _ease_out(k)
				"back": w = _ease_back(k)
			return _mix(prev[1], f[1], w)
	return frames[frames.size() - 1][1]


## Pose dasar bersenjata dengan penimpaan (kunci -> nilai); legs menjaga kaki tetap menapak.
static func _pz(o: Dictionary, armed: bool = true) -> Dictionary:
	var d := _p_idle(0.0, armed)
	for k in o:
		d[k] = o[k]
	d["foot_l"] = Vector3(-(d["thigh_l"].x + d["shin_l"].x) * 0.6, 0, 0)
	d["foot_r"] = Vector3(-(d["thigh_r"].x + d["shin_r"].x) * 0.6, 0, 0)
	# torsi pinggul: pinggul ikut memutar (seperempat putaran tulang punggung, arah sama) -> gerak tidak kaku, tenaga dari kaki-pinggul-bahu
	if not o.has("hips"):
		var sp: Vector3 = d["spine"]
		d["hips"] = Vector3(0.0, sp.y * 0.25, sp.z * 0.2)
	return d


## Tebasan pedang. combo 0: tebasan atas ke bawah; combo 1: sapuan menyilang kanan ke kiri.
static func _p_sword(u: float, combo: int) -> Dictionary:
	var ready := _pz({})
	var ant: Dictionary
	var hit: Dictionary
	if combo == 0:
		ant = _pz({"upperarm_r": Vector3(-0.81, 0.05, 0.11), "forearm_r": Vector3(-0.96, 0, 0), "hand_r": Vector3(0.01, 0, 0),
			"spine": Vector3(-0.28, -0.3, 0), "chest": Vector3(-0.15, -0.15, 0), "head": Vector3(0.12, 0.1, 0),
			"upperarm_l": Vector3(0.3, 0, 0.7), "forearm_l": Vector3(-0.5, 0, 0),
			"thigh_l": Vector3(0.3, 0, 0.08), "thigh_r": Vector3(-0.2, 0, -0.08), "shin_r": Vector3(0.45, 0, 0), "shin_l": Vector3(0.1, 0, 0),
			"bob": -0.06, "hz": -0.05})
		hit = _pz({"upperarm_r": Vector3(-0.51, -0.41, 0.15), "forearm_r": Vector3(-0.63, 0, 0), "hand_r": Vector3(0.3, 0, 0),
			"spine": Vector3(0.55, 0.25, 0), "chest": Vector3(0.15, 0.1, 0), "head": Vector3(-0.4, -0.1, 0),
			"upperarm_l": Vector3(-0.2, 0, 0.5), "forearm_l": Vector3(-0.4, 0, 0),
			"thigh_l": Vector3(-0.6, 0, 0.1), "thigh_r": Vector3(0.3, 0, -0.08), "shin_l": Vector3(0.35, 0, 0), "shin_r": Vector3(0.3, 0, 0),
			"bob": -0.15, "hz": 0.14})
	else:
		ant = _pz({"upperarm_r": Vector3(-0.01, -0.66, 0.5), "forearm_r": Vector3(-0.56, 0, 0), "hand_r": Vector3(0.21, 0, 0),
			"spine": Vector3(0.12, -0.85, 0), "chest": Vector3(0, -0.35, 0), "head": Vector3(-0.1, 0.55, 0),
			"upperarm_l": Vector3(0.2, 0, 0.8), "forearm_l": Vector3(-0.5, 0, 0),
			"thigh_l": Vector3(0.25, 0, 0.1), "thigh_r": Vector3(-0.15, 0, -0.1), "shin_r": Vector3(0.3, 0, 0),
			"bob": -0.07, "hz": -0.04})
		hit = _pz({"upperarm_r": Vector3(-0.34, -0.57, 0.25), "forearm_r": Vector3(-0.63, 0, 0), "hand_r": Vector3(0.3, 0, 0),
			"spine": Vector3(0.3, 0.9, 0), "chest": Vector3(0, 0.38, 0), "head": Vector3(-0.1, -0.55, 0),
			"upperarm_l": Vector3(-0.4, 0, 0.9), "forearm_l": Vector3(-0.4, 0, 0),
			"thigh_r": Vector3(-0.55, 0, -0.1), "thigh_l": Vector3(0.3, 0, 0.1), "shin_r": Vector3(0.3, 0, 0), "shin_l": Vector3(0.3, 0, 0),
			"bob": -0.12, "hz": 0.12})
	var follow := _mix(hit, ready, 0.35)
	# kunci tengah busur: tangan tetap di depan badan & bilah di atas tanah (hasil FK/optimasi: tak menembus badan/kaki)
	var mid := _mix(ant, hit, 0.5)
	if combo == 0:
		mid["upperarm_r"] = Vector3(-0.76, 0.02, 0.2)
		mid["forearm_r"] = Vector3(-0.76, 0, 0)
		mid["hand_r"] = Vector3(0.5, 0, 0)
		follow["upperarm_r"] = Vector3(-0.32, -0.56, 0.44)
		follow["forearm_r"] = Vector3(-0.5, 0, 0)
		follow["hand_r"] = Vector3(0.25, 0, 0)
	else:
		mid["upperarm_r"] = Vector3(-0.46, -0.17, 0.47)
		mid["forearm_r"] = Vector3(-0.51, 0, 0)
		mid["hand_r"] = Vector3(0.67, 0, 0)
		follow["upperarm_r"] = Vector3(-0.3, -0.45, 0.35)
		follow["forearm_r"] = Vector3(-0.6, 0, 0)
		follow["hand_r"] = Vector3(0.3, 0, 0)
	return _seq(u, [[0.0, ready, ""], [0.26, ant, "io"], [0.32, mid, ""], [0.38, hit, "out"], [0.64, follow, "out"], [1.0, ready, "io"]])


## Serangan tongkat: tarik ke belakang lalu hentakkan ke depan (melepas bola sihir).
static func _p_staff(u: float) -> Dictionary:
	var ready := _pz({})
	var ant := _pz({"upperarm_r": Vector3(-0.8, 0.25, -0.3), "forearm_r": Vector3(-1.9, 0, 0), "hand_r": Vector3(-0.5, 0, 0),
		"upperarm_l": Vector3(-0.7, 0, 0.5), "forearm_l": Vector3(-0.6, 0, 0),
		"spine": Vector3(-0.12, -0.4, 0), "chest": Vector3(-0.06, -0.15, 0), "head": Vector3(0.06, 0.2, 0),
		"thigh_l": Vector3(0.15, 0, 0.06), "thigh_r": Vector3(-0.1, 0, -0.06), "bob": -0.04, "hz": -0.05})
	var hit := _pz({"upperarm_r": Vector3(-1.6, -0.05, -0.1), "forearm_r": Vector3(-0.2, 0, 0), "hand_r": Vector3(0.15, 0, 0),
		"upperarm_l": Vector3(-1.2, 0, 0.3), "forearm_l": Vector3(-0.3, 0, 0),
		"spine": Vector3(0.3, 0.22, 0), "chest": Vector3(0.1, 0.1, 0), "head": Vector3(-0.2, -0.1, 0),
		"thigh_l": Vector3(-0.35, 0, 0.06), "thigh_r": Vector3(0.25, 0, -0.06), "shin_r": Vector3(0.25, 0, 0), "bob": -0.08, "hz": 0.08})
	var follow := _mix(hit, ready, 0.3)
	return _seq(u, [[0.0, ready, ""], [0.3, ant, "io"], [0.46, hit, "back"], [0.68, follow, "out"], [1.0, ready, "io"]])


## Hantaman berat dua tangan (Guardian): angkat tinggi (berjinjit), banting, tahan menekan tanah, bangkit.
static func _p_smash(u: float) -> Dictionary:
	var ready := _pz({})
	# 1) mengumpulkan tenaga: berjongkok, palu ditarik ke samping-belakang
	var load_ := _pz({"upperarm_r": Vector3(-1.0, 0.5, -0.5), "upperarm_l": Vector3(-0.9, 0.4, 0.1),
		"forearm_r": Vector3(-0.8, 0, 0), "forearm_l": Vector3(-0.8, 0, 0),
		"spine": Vector3(-0.08, -0.35, 0), "chest": Vector3(0, -0.2, 0), "head": Vector3(0.2, 0.15, 0),
		"thigh_l": Vector3(0.35, 0, 0.18), "thigh_r": Vector3(-0.15, 0, -0.18), "shin_l": Vector3(0.55, 0, 0), "shin_r": Vector3(0.4, 0, 0),
		"bob": -0.14, "hz": -0.04})
	# 2) angkat tinggi, punggung melengkung, berjinjit
	var ant := _pz({"upperarm_r": Vector3(-3.1, 0.1, -0.2), "upperarm_l": Vector3(-2.9, -0.1, 0.25),
		"forearm_r": Vector3(-0.8, 0, 0), "forearm_l": Vector3(-0.8, 0, 0),
		"spine": Vector3(-0.42, 0, 0), "chest": Vector3(-0.15, 0, 0), "head": Vector3(0.35, 0, 0),
		"thigh_l": Vector3(0.1, 0, 0.18), "thigh_r": Vector3(-0.1, 0, -0.18), "bob": 0.05, "hz": -0.1})
	# 3) membanting: badan menukik, satu kaki maju menahan beban
	var hit := _pz({"upperarm_r": Vector3(-0.4, 0.1, -0.2), "upperarm_l": Vector3(-0.38, -0.1, 0.25),
		"forearm_r": Vector3(-0.1, 0, 0), "forearm_l": Vector3(-0.1, 0, 0),
		"spine": Vector3(1.05, 0, 0), "chest": Vector3(0.12, 0, 0), "head": Vector3(-0.65, 0, 0),
		"thigh_l": Vector3(-0.55, 0, 0.16), "thigh_r": Vector3(0.2, 0, -0.16), "shin_l": Vector3(0.45, 0, 0), "shin_r": Vector3(0.7, 0, 0),
		"bob": -0.22, "hz": 0.16})
	# 4) tahan menekan tanah (bergetar sedikit), lalu tarik palu dan bangkit
	var press := _mix(hit, _pz({"spine": Vector3(1.0, 0, 0.04), "head": Vector3(-0.6, 0, 0), "bob": -0.24, "hz": 0.16,
		"upperarm_r": Vector3(-0.45, 0.1, -0.2), "upperarm_l": Vector3(-0.42, -0.1, 0.25), "thigh_l": Vector3(-0.55, 0, 0.16), "thigh_r": Vector3(0.2, 0, -0.16),
		"shin_l": Vector3(0.45, 0, 0), "shin_r": Vector3(0.7, 0, 0)}), 0.6)
	var lift := _mix(hit, ready, 0.55)
	return _seq(u, [[0.0, ready, ""], [0.16, load_, "io"], [0.42, ant, "io"], [0.52, hit, "back"], [0.7, press, "out"],
		[0.86, lift, "io"], [1.0, ready, "io"]])


## Belati ganda (Assassin): cepat dan lincah. Kuda-kuda rendah; 0 = tebas kanan, 1 = tebas kiri, 2 = penutup (putaran silang + lompat kecil).
static func _dagger_ready() -> Dictionary:
	return _pz({"upperarm_r": Vector3(-0.55, 0.1, -0.15), "forearm_r": Vector3(-1.1, 0, 0), "hand_r": Vector3(-0.1, 0, 0),
		"upperarm_l": Vector3(-0.55, -0.1, 0.15), "forearm_l": Vector3(-1.1, 0, 0),
		"spine": Vector3(0.18, 0, 0), "chest": Vector3(0.04, 0, 0), "head": Vector3(-0.1, 0, 0),
		"thigh_l": Vector3(0.28, 0, 0.12), "thigh_r": Vector3(-0.22, 0, -0.12), "shin_l": Vector3(0.35, 0, 0), "shin_r": Vector3(0.4, 0, 0),
		"bob": -0.09, "hz": 0.0})


static func _p_dagger(u: float, idx: int) -> Dictionary:
	var ready := _dagger_ready()
	if idx == 0:
		var ant := _pz({"upperarm_r": Vector3(-1.3, 0.0, -1.15), "forearm_r": Vector3(-0.6, 0, 0),
			"upperarm_l": Vector3(-0.7, 0, 0.45), "forearm_l": Vector3(-1.0, 0, 0),
			"spine": Vector3(0.22, -0.75, 0), "chest": Vector3(0.04, -0.3, 0), "head": Vector3(-0.08, 0.5, 0),
			"thigh_l": Vector3(0.3, 0, 0.14), "thigh_r": Vector3(-0.25, 0, -0.12), "shin_l": Vector3(0.4, 0, 0), "shin_r": Vector3(0.45, 0, 0),
			"bob": -0.11, "hz": -0.05})
		var hit := _pz({"upperarm_r": Vector3(-1.0, 0.55, 0.2), "forearm_r": Vector3(-0.15, 0, 0),
			"upperarm_l": Vector3(-0.3, 0, 0.85), "forearm_l": Vector3(-0.9, 0, 0),
			"spine": Vector3(0.35, 0.8, 0), "chest": Vector3(0.04, 0.32, 0), "head": Vector3(-0.08, -0.5, 0),
			"thigh_l": Vector3(0.3, 0, 0.14), "thigh_r": Vector3(-0.55, 0, -0.1), "shin_l": Vector3(0.3, 0, 0), "shin_r": Vector3(0.35, 0, 0),
			"bob": -0.12, "hz": 0.16})
		return _seq(u, [[0.0, ready, ""], [0.2, ant, "io"], [0.38, hit, "back"], [0.62, _mix(hit, ready, 0.4), "out"], [1.0, ready, "io"]])
	if idx == 1:
		var ant2 := _pz({"upperarm_l": Vector3(-1.3, 0.0, 1.15), "forearm_l": Vector3(-0.6, 0, 0),
			"upperarm_r": Vector3(-0.7, 0, -0.45), "forearm_r": Vector3(-1.0, 0, 0),
			"spine": Vector3(0.22, 0.75, 0), "chest": Vector3(0.04, 0.3, 0), "head": Vector3(-0.08, -0.5, 0),
			"thigh_r": Vector3(0.3, 0, -0.14), "thigh_l": Vector3(-0.25, 0, 0.12), "shin_r": Vector3(0.4, 0, 0), "shin_l": Vector3(0.45, 0, 0),
			"bob": -0.11, "hz": -0.05})
		var hit2 := _pz({"upperarm_l": Vector3(-1.0, -0.55, -0.2), "forearm_l": Vector3(-0.15, 0, 0),
			"upperarm_r": Vector3(-0.3, 0, -0.85), "forearm_r": Vector3(-0.9, 0, 0),
			"spine": Vector3(0.35, -0.8, 0), "chest": Vector3(0.04, -0.32, 0), "head": Vector3(-0.08, 0.5, 0),
			"thigh_r": Vector3(0.3, 0, -0.14), "thigh_l": Vector3(-0.55, 0, 0.1), "shin_r": Vector3(0.3, 0, 0), "shin_l": Vector3(0.35, 0, 0),
			"bob": -0.12, "hz": 0.16})
		return _seq(u, [[0.0, ready, ""], [0.2, ant2, "io"], [0.38, hit2, "back"], [0.62, _mix(hit2, ready, 0.4), "out"], [1.0, ready, "io"]])
	# penutup: menggulung, lalu putaran silang dua belati sambil melompat kecil
	var coil := _pz({"upperarm_r": Vector3(-1.2, 0, -1.7), "forearm_r": Vector3(-0.5, 0, 0),
		"upperarm_l": Vector3(-1.2, 0, 1.7), "forearm_l": Vector3(-0.5, 0, 0),
		"spine": Vector3(0.35, -1.25, 0), "chest": Vector3(0.05, -0.5, 0), "head": Vector3(-0.1, 0.9, 0),
		"thigh_l": Vector3(0.4, 0, 0.2), "thigh_r": Vector3(-0.3, 0, -0.2), "shin_l": Vector3(0.7, 0, 0), "shin_r": Vector3(0.7, 0, 0),
		"bob": -0.2, "hz": -0.06})
	var spin := _pz({"upperarm_r": Vector3(-1.5, 0.5, 0.3), "forearm_r": Vector3(-0.2, 0, 0),
		"upperarm_l": Vector3(-1.5, -0.5, -0.3), "forearm_l": Vector3(-0.2, 0, 0),
		"spine": Vector3(0.1, 1.3, 0), "chest": Vector3(0, 0.55, 0), "head": Vector3(-0.1, -0.9, 0),
		"thigh_l": Vector3(-0.35, 0, 0.18), "thigh_r": Vector3(0.45, 0, -0.18), "shin_l": Vector3(0.55, 0, 0), "shin_r": Vector3(0.8, 0, 0),
		"bob": 0.12, "hz": 0.2})
	var land := _pz({"upperarm_r": Vector3(-0.9, 0.4, 0.2), "forearm_r": Vector3(-0.4, 0, 0),
		"upperarm_l": Vector3(-0.9, -0.4, -0.2), "forearm_l": Vector3(-0.4, 0, 0),
		"spine": Vector3(0.3, 0.9, 0), "chest": Vector3(0, 0.4, 0), "head": Vector3(-0.1, -0.6, 0),
		"thigh_l": Vector3(-0.5, 0, 0.16), "thigh_r": Vector3(0.3, 0, -0.16), "shin_l": Vector3(0.9, 0, 0), "shin_r": Vector3(0.9, 0, 0),
		"bob": -0.22, "hz": 0.12})
	return _seq(u, [[0.0, ready, ""], [0.26, coil, "io"], [0.4, spin, "back"], [0.6, land, "out"], [0.78, _mix(land, ready, 0.5), "io"], [1.0, ready, "io"]])


## Skill Assassin: merunduk, menerjang (badan sejajar tanah), menyilang dua belati, lalu berhenti dengan kuda-kuda.
static func _p_skill_dagger(u: float) -> Dictionary:
	var ready := _dagger_ready()
	var crouch := _pz({"upperarm_r": Vector3(0.4, 0, -0.5), "forearm_r": Vector3(-0.6, 0, 0),
		"upperarm_l": Vector3(0.4, 0, 0.5), "forearm_l": Vector3(-0.6, 0, 0),
		"spine": Vector3(0.6, -0.2, 0), "chest": Vector3(0.1, 0, 0), "head": Vector3(-0.5, 0, 0),
		"thigh_l": Vector3(-0.9, 0, 0.14), "thigh_r": Vector3(-0.9, 0, -0.14), "shin_l": Vector3(1.3, 0, 0), "shin_r": Vector3(1.3, 0, 0),
		"bob": -0.3, "hz": -0.1})
	var dash := _pz({"upperarm_r": Vector3(1.1, 0, -0.35), "forearm_r": Vector3(-0.2, 0, 0),
		"upperarm_l": Vector3(1.1, 0, 0.35), "forearm_l": Vector3(-0.2, 0, 0),
		"spine": Vector3(1.0, 0, 0), "chest": Vector3(0.15, 0, 0), "head": Vector3(-0.8, 0, 0),
		"thigh_l": Vector3(0.8, 0, 0.1), "thigh_r": Vector3(-0.9, 0, -0.1), "shin_l": Vector3(0.7, 0, 0), "shin_r": Vector3(0.9, 0, 0),
		"bob": -0.12, "hz": 0.28})
	var cross := _pz({"upperarm_r": Vector3(-1.45, 0.65, 0.5), "forearm_r": Vector3(-0.25, 0, 0),
		"upperarm_l": Vector3(-1.45, -0.65, -0.5), "forearm_l": Vector3(-0.25, 0, 0),
		"spine": Vector3(0.1, 0.0, 0), "chest": Vector3(-0.1, 0, 0), "head": Vector3(0.05, 0, 0),
		"thigh_l": Vector3(-0.6, 0, 0.16), "thigh_r": Vector3(0.45, 0, -0.16), "shin_l": Vector3(0.4, 0, 0), "shin_r": Vector3(0.6, 0, 0),
		"bob": -0.14, "hz": 0.2})
	return _seq(u, [[0.0, ready, ""], [0.22, crouch, "io"], [0.38, dash, "back"], [0.5, cross, "back"], [0.72, _mix(cross, ready, 0.4), "out"], [1.0, ready, "io"]])


## Panah: tarik tali (antisipasi + bidik), lepas (tangan kanan menyentak), turunkan busur.
static func _p_bow(u: float, skill: bool) -> Dictionary:
	var ready := _pz({}, false)
	var draw := _pz({"upperarm_l": Vector3(-1.45, -0.15, 0.12), "forearm_l": Vector3(-0.1, 0, 0),
		"upperarm_r": Vector3(-1.5, 0.55, -0.7), "forearm_r": Vector3(-2.0, 0, 0),
		"spine": Vector3(0, 0.45, 0), "chest": Vector3(0, 0.15, 0), "head": Vector3(-0.05, -0.55, 0),
		"thigh_l": Vector3(0.15, 0, 0.1), "thigh_r": Vector3(-0.15, 0, -0.1), "bob": -0.05, "hz": -0.03}, false)
	var rel := _pz({"upperarm_l": Vector3(-1.5, -0.15, 0.12), "forearm_l": Vector3(-0.1, 0, 0),
		"upperarm_r": Vector3(-1.45, 0.35, -1.05), "forearm_r": Vector3(-0.4, 0, 0),
		"spine": Vector3(0, 0.38, 0), "chest": Vector3(0, 0.12, 0), "head": Vector3(-0.05, -0.5, 0),
		"thigh_l": Vector3(0.1, 0, 0.1), "thigh_r": Vector3(-0.1, 0, -0.1), "bob": -0.03, "hz": -0.08}, false)
	if skill:
		draw["spine"] = Vector3(-0.3, 0.45, 0)
		draw["upperarm_l"] = Vector3(-1.85, -0.15, 0.12)
		draw["bob"] = -0.1
		rel["spine"] = Vector3(-0.2, 0.38, 0)
		rel["upperarm_l"] = Vector3(-1.9, -0.15, 0.12)
		rel["bob"] = 0.06
	var follow := _mix(rel, ready, 0.45)
	return _seq(u, [[0.0, ready, ""], [0.4, draw, "io"], [0.48 if not skill else 0.46, draw, "io"], [0.58, rel, "back"], [0.78, follow, "out"], [1.0, ready, "io"]])


## Skill pedang: menggulung badan (antisipasi dalam), putaran sapuan lebar, melewati sedikit, lalu menahan dengan kuda-kuda.
static func _p_skill_sword(u: float) -> Dictionary:
	var ready := _pz({})
	var coil := _pz({"upperarm_r": Vector3(-1.25, 0.0, -1.65), "forearm_r": Vector3(-0.5, 0, 0), "hand_r": Vector3(-0.2, 0, 0),
		"spine": Vector3(0.2, -1.35, 0), "chest": Vector3(0, -0.55, 0), "head": Vector3(-0.1, 0.95, 0),
		"upperarm_l": Vector3(-0.3, 0, 0.9), "forearm_l": Vector3(-0.4, 0, 0),
		"thigh_l": Vector3(-0.35, 0, 0.2), "thigh_r": Vector3(0.35, 0, -0.2), "shin_l": Vector3(0.45, 0, 0), "shin_r": Vector3(0.5, 0, 0),
		"bob": -0.17, "hz": -0.05})
	var sweep := _pz({"upperarm_r": Vector3(-1.5, 0.6, 0.25), "forearm_r": Vector3(-0.15, 0, 0), "hand_r": Vector3(0.1, 0, 0),
		"spine": Vector3(0.12, 1.3, 0), "chest": Vector3(0, 0.55, 0), "head": Vector3(-0.1, -0.95, 0),
		"upperarm_l": Vector3(-0.4, 0, 0.95), "forearm_l": Vector3(-0.4, 0, 0),
		"thigh_l": Vector3(-0.45, 0, 0.18), "thigh_r": Vector3(0.4, 0, -0.18), "shin_l": Vector3(0.3, 0, 0), "shin_r": Vector3(0.5, 0, 0),
		"bob": -0.12, "hz": 0.1})
	var settle := _pz({"upperarm_r": Vector3(-1.0, 0.45, 0.1), "forearm_r": Vector3(-0.3, 0, 0),
		"spine": Vector3(0.18, 1.0, 0), "chest": Vector3(0, 0.4, 0), "head": Vector3(-0.1, -0.7, 0),
		"upperarm_l": Vector3(-0.3, 0, 0.8), "forearm_l": Vector3(-0.4, 0, 0),
		"thigh_l": Vector3(-0.4, 0, 0.16), "thigh_r": Vector3(0.35, 0, -0.16), "shin_l": Vector3(0.3, 0, 0), "shin_r": Vector3(0.45, 0, 0),
		"bob": -0.1, "hz": 0.08})
	return _seq(u, [[0.0, ready, ""], [0.34, coil, "io"], [0.42, coil, "io"], [0.62, sweep, "back"], [0.78, settle, "out"], [1.0, ready, "io"]])


## Skill penyihir: mengangkat tongkat ke langit sambil mengumpulkan tenaga (tubuh naik), tahan sesaat, lalu hunjam.
static func _p_skill_staff(u: float) -> Dictionary:
	var ready := _pz({})
	var gather := _pz({"upperarm_r": Vector3(-3.0, 0, -0.25), "forearm_r": Vector3(-0.35, 0, 0),
		"upperarm_l": Vector3(-2.85, 0, 0.35), "forearm_l": Vector3(-0.3, 0, 0),
		"spine": Vector3(-0.24, 0, 0), "chest": Vector3(-0.1, 0, 0), "head": Vector3(-0.38, 0, 0),
		"thigh_l": Vector3(0.05, 0, 0.1), "thigh_r": Vector3(-0.05, 0, -0.1), "bob": 0.1, "hz": -0.03})
	var peak := _mix(gather, _pz({"bob": 0.13, "spine": Vector3(-0.3, 0, 0), "head": Vector3(-0.45, 0, 0),
		"upperarm_r": Vector3(-3.05, 0, -0.3), "upperarm_l": Vector3(-2.9, 0, 0.4), "forearm_r": Vector3(-0.35, 0, 0), "forearm_l": Vector3(-0.3, 0, 0)}), 1.0)
	var slam := _pz({"upperarm_r": Vector3(-1.2, 0, -0.25), "forearm_r": Vector3(-0.65, 0, 0),
		"upperarm_l": Vector3(-1.15, 0, 0.35), "forearm_l": Vector3(-0.3, 0, 0),
		"spine": Vector3(0.55, 0, 0), "chest": Vector3(0.1, 0, 0), "head": Vector3(0.3, 0, 0),
		"thigh_l": Vector3(-0.3, 0, 0.12), "thigh_r": Vector3(0.2, 0, -0.12), "shin_r": Vector3(0.3, 0, 0), "bob": -0.08, "hz": 0.07})
	var follow := _mix(slam, ready, 0.3)
	return _seq(u, [[0.0, ready, ""], [0.36, gather, "io"], [0.5, peak, "io"], [0.64, slam, "back"], [0.82, follow, "out"], [1.0, ready, "io"]])


## Skill Guardian: berjongkok menyimpan tenaga, melompat dengan tangan di atas, jatuh membanting tanah, tahan, bangkit.
static func _p_skill_guard(u: float) -> Dictionary:
	var ready := _pz({})
	var crouch := _pz({"upperarm_r": Vector3(-1.2, 0, -0.3), "upperarm_l": Vector3(-1.2, 0, 0.3),
		"forearm_r": Vector3(-0.8, 0, 0), "forearm_l": Vector3(-0.8, 0, 0),
		"spine": Vector3(0.35, 0, 0), "head": Vector3(-0.15, 0, 0),
		"thigh_l": Vector3(-0.75, 0, 0.12), "thigh_r": Vector3(-0.75, 0, -0.12), "shin_l": Vector3(1.05, 0, 0), "shin_r": Vector3(1.05, 0, 0),
		"bob": -0.3, "hz": -0.04})
	var air := _pz({"upperarm_r": Vector3(-3.0, 0, -0.2), "upperarm_l": Vector3(-3.0, 0, 0.2),
		"forearm_r": Vector3(-0.5, 0, 0), "forearm_l": Vector3(-0.5, 0, 0),
		"spine": Vector3(-0.22, 0, 0), "head": Vector3(0.1, 0, 0),
		"thigh_l": Vector3(-0.15, 0, 0.1), "thigh_r": Vector3(0.2, 0, -0.1), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.6, 0, 0),
		"bob": 0.4, "hz": 0.05})
	var slam := _pz({"upperarm_r": Vector3(-0.25, 0, -0.2), "upperarm_l": Vector3(-0.25, 0, 0.2),
		"forearm_r": Vector3(-0.1, 0, 0), "forearm_l": Vector3(-0.1, 0, 0),
		"spine": Vector3(0.9, 0, 0), "head": Vector3(-0.4, 0, 0),
		"thigh_l": Vector3(-0.85, 0, 0.12), "thigh_r": Vector3(-0.85, 0, -0.12), "shin_l": Vector3(1.2, 0, 0), "shin_r": Vector3(1.2, 0, 0),
		"bob": -0.3, "hz": 0.1})
	var rise := _mix(slam, ready, 0.5)
	return _seq(u, [[0.0, ready, ""], [0.24, crouch, "io"], [0.36, crouch, "io"], [0.5, air, "out"], [0.64, slam, "back"], [0.82, slam, "out"], [0.92, rise, "io"], [1.0, ready, "io"]])


## Terkena serangan: badan tersentak ke belakang lalu pulih.
static func _p_hurt(u: float) -> Dictionary:
	var d := _p_idle(0.0, true)
	var h := _ease_out(u / 0.2) * pow(1.0 - u, 1.6)
	d["spine"] = Vector3(-0.38 * h, 0.0, 0.1 * h)
	d["head"] = Vector3(-0.4 * h, 0.0, 0)
	d["upperarm_l"] = Vector3(-0.5 * h, 0, 0.18 + 0.7 * h)
	d["upperarm_r"] = Vector3(-0.3 - 0.5 * h, 0, -0.18 - 0.7 * h)
	d["forearm_l"] = Vector3(-0.15 - 0.5 * h, 0, 0)
	d["forearm_r"] = Vector3(-0.6 - 0.2 * h, 0, 0)
	d["thigh_l"] = Vector3(0.2 * h, 0, 0.03)
	d["thigh_r"] = Vector3(-0.15 * h, 0, -0.03)
	d["bob"] = -0.05 * h
	return d


## Kalah: rebah ke belakang dan tetap di lantai (tidak berulang).
static func _p_death(u: float) -> Dictionary:
	var d := _p_idle(0.0, true)
	var stagger := _ease_out(u / 0.25)
	var fall := _ease_io((u - 0.2) / 0.6)
	d["hips"] = Vector3(-1.5 * fall, 0, 0)
	d["spine"] = Vector3(-0.3 * stagger + 0.15 * fall, 0, 0)
	d["head"] = Vector3(-0.35 * stagger, 0, 0.1 * fall)
	d["upperarm_l"] = Vector3(-0.5 * stagger, 0, 0.25 + 0.9 * fall)
	d["upperarm_r"] = Vector3(-0.3 - 0.5 * stagger, 0, -0.25 - 0.9 * fall)
	d["forearm_l"] = Vector3(-0.3, 0, 0)
	d["forearm_r"] = Vector3(-0.4, 0, 0)
	d["thigh_l"] = Vector3(0.3 * fall, 0, 0.08 * fall)
	d["thigh_r"] = Vector3(0.15 * fall, 0, -0.1 * fall)
	d["shin_l"] = Vector3(0.4 * fall, 0, 0)
	d["shin_r"] = Vector3(0.7 * fall, 0, 0)
	d["bob"] = -0.05 * stagger - 0.66 * fall
	d["hz"] = -0.08 * fall
	return d


## Menang: satu tangan terangkat melambai, tubuh melonjak kecil.
static func _p_victory(u: float) -> Dictionary:
	var d := _p_idle(0.0, false)
	var ph := u * TAU
	d["upperarm_r"] = Vector3(-2.75, 0, -0.35 + 0.1 * sin(ph * 2.0))
	d["forearm_r"] = Vector3(-0.35 + 0.4 * sin(ph * 2.0), 0, 0)
	d["upperarm_l"] = Vector3(-0.2, 0, 0.7)
	d["forearm_l"] = Vector3(-1.5, 0, 0)
	d["spine"] = Vector3(-0.05, 0.12 * sin(ph), 0)
	d["head"] = Vector3(-0.12, 0.2 * sin(ph), 0.05 * sin(ph))
	d["bob"] = absf(sin(ph)) * 0.09
	d["thigh_l"] = Vector3(0, 0, 0.1)
	d["thigh_r"] = Vector3(0, 0, -0.1)
	return d


# =====================================================================
#  Variasi diam NPC
# =====================================================================
static func _p_cross(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var br := sin(u * TAU)
	d["upperarm_l"] = Vector3(-0.35, 0.65, 0.5)
	d["forearm_l"] = Vector3(-1.9, 0, 0)
	d["upperarm_r"] = Vector3(-0.35, -0.65, -0.5)
	d["forearm_r"] = Vector3(-1.9, 0, 0)
	d["head"] = Vector3(-0.02 + 0.02 * br, 0.3 * sin(u * TAU), 0)
	d["thigh_l"] = Vector3(0, 0, 0.07)
	d["thigh_r"] = Vector3(0, 0, -0.07)
	return d


static func _p_hammer(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var k := fmod(u, 1.0)
	var up := _ease_io(k / 0.6)
	var hit := _ease_out((k - 0.6) / 0.15)
	var a := lerpf(-0.9, -2.2, up)
	a = lerpf(a, -0.7, hit)
	d["upperarm_r"] = Vector3(a, 0, -0.15)
	d["forearm_r"] = Vector3(lerpf(-1.3, -1.0, up) * (1.0 - hit) - 0.5 * hit, 0, 0)
	d["hand_r"] = Vector3(-0.2 * hit, 0, 0)
	d["upperarm_l"] = Vector3(-0.8, 0, 0.3)
	d["forearm_l"] = Vector3(-0.9, 0, 0)
	d["spine"] = Vector3(0.15 + 0.18 * hit - 0.08 * up, 0, 0)
	d["head"] = Vector3(0.2 + 0.1 * hit, 0, 0)
	d["bob"] = -0.03 * hit
	return d


static func _p_wave(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var ph := u * TAU
	var lift := _ease_io(minf(u / 0.15, 1.0)) * (1.0 - _ease_io((u - 0.75) / 0.25))
	d["upperarm_r"] = Vector3(lerpf(0.0, -2.6, lift), 0, lerpf(-0.08, -0.55, lift))
	d["forearm_r"] = Vector3(lerpf(-0.15, -0.5, lift) + 0.45 * lift * sin(ph * 5.0), 0, 0)
	d["head"] = Vector3(-0.03, 0.15 * sin(ph) * (1.0 - lift), 0.05 * lift)
	return d


static func _p_gesture(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var ph := u * TAU
	d["upperarm_r"] = Vector3(-0.8 - 0.25 * sin(ph * 2.0), 0.3, -0.35)
	d["forearm_r"] = Vector3(-1.1 + 0.35 * sin(ph * 2.0 + 1.0), 0, 0)
	d["hand_r"] = Vector3(0.2 * sin(ph * 2.0), 0, 0)
	d["upperarm_l"] = Vector3(-0.15, 0, 0.12)
	d["head"] = Vector3(-0.03 + 0.05 * sin(ph * 2.0), 0.25 * sin(ph), 0)
	d["spine"] = Vector3(0.02, 0.08 * sin(ph), 0)
	return d


static func _p_attention(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var br := sin(u * TAU)
	d["upperarm_l"] = Vector3(0, 0, 0.04)
	d["forearm_l"] = Vector3(-0.05, 0, 0)
	d["upperarm_r"] = Vector3(-0.15, 0, -0.04)
	d["forearm_r"] = Vector3(-0.05, 0, 0)
	d["spine"] = Vector3(-0.04 + 0.01 * br, 0, 0)
	d["chest"] = Vector3(-0.03 + 0.015 * br, 0, 0)
	d["head"] = Vector3(0.0, 0.18 * sin(u * TAU), 0)
	d["thigh_l"] = Vector3(0, 0, 0.05)
	d["thigh_r"] = Vector3(0, 0, -0.05)
	return d


## Peramal: kedua tangan melingkar di atas bola kristal.
static func _p_stir(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var ph := u * TAU
	d["upperarm_l"] = Vector3(-0.85 + 0.1 * sin(ph * 2.0), -0.2, 0.25)
	d["forearm_l"] = Vector3(-1.15 + 0.2 * cos(ph * 2.0), 0, 0)
	d["upperarm_r"] = Vector3(-0.85 + 0.1 * cos(ph * 2.0), 0.2, -0.25)
	d["forearm_r"] = Vector3(-1.15 + 0.2 * sin(ph * 2.0), 0, 0)
	d["head"] = Vector3(0.25, 0.1 * sin(ph), 0)
	d["spine"] = Vector3(0.1, 0, 0)
	return d


# =====================================================================
#  Gaya gerak PER KARAKTER: diam (idle@id), jalan (walk@id), lari (run@id), siaga setelah serangan (ready@id).
#  Dibuat lazy lewat ensure_style(id) agar tidak membebani HP saat game dibuka.
#  hold = tulang yang dipaksa ke pose tertentu (mis. Wenyu memegang seruling di bibir), add = offset tambahan,
#  sway/beat = goyangan pinggul, stride/bounce = pengali langkah & loncatan saat jalan.
# =====================================================================
const READY_BASE := {
	"sword": {"upperarm_r": Vector3(-1.1, 0.2, -0.35), "forearm_r": Vector3(-1.0, 0, 0), "hand_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-0.5, 0, 0.7),
		"forearm_l": Vector3(-0.7, 0, 0), "spine": Vector3(0.12, -0.25, 0), "head": Vector3(0.0, 0.15, 0), "thigh_l": Vector3(0.28, 0, 0.1),
		"thigh_r": Vector3(-0.2, 0, -0.1), "shin_r": Vector3(0.35, 0, 0), "shin_l": Vector3(0.12, 0, 0), "bob": -0.05},
	"staff": {"upperarm_r": Vector3(-0.9, 0.1, -0.3), "forearm_r": Vector3(-1.2, 0, 0), "upperarm_l": Vector3(-0.9, 0, 0.4), "forearm_l": Vector3(-0.9, 0, 0),
		"spine": Vector3(0.05, -0.15, 0), "thigh_l": Vector3(0.18, 0, 0.08), "thigh_r": Vector3(-0.12, 0, -0.08), "shin_r": Vector3(0.2, 0, 0), "bob": -0.03},
	"guard": {"upperarm_l": Vector3(-1.3, 0, 0.2), "forearm_l": Vector3(-1.5, 0, 0), "upperarm_r": Vector3(-0.9, 0, -0.3), "forearm_r": Vector3(-1.0, 0, 0),
		"spine": Vector3(0.2, 0, 0), "head": Vector3(0.1, 0, 0), "thigh_l": Vector3(0.3, 0, 0.2), "thigh_r": Vector3(-0.3, 0, -0.2),
		"shin_r": Vector3(0.5, 0, 0), "shin_l": Vector3(0.2, 0, 0), "bob": -0.1},
	"bow": {"upperarm_l": Vector3(-1.5, 0, 0.1), "forearm_l": Vector3(-0.1, 0, 0), "upperarm_r": Vector3(-1.3, 0.3, -0.6), "forearm_r": Vector3(-1.9, 0, 0),
		"spine": Vector3(0, -0.5, 0), "head": Vector3(0, 0.5, 0), "thigh_l": Vector3(0.1, 0, 0.14), "thigh_r": Vector3(-0.1, 0, -0.14), "bob": -0.04},
	"dagger": {"upperarm_r": Vector3(-0.9, 0.3, -0.4), "forearm_r": Vector3(-1.3, 0, 0), "upperarm_l": Vector3(-0.7, -0.3, 0.5), "forearm_l": Vector3(-1.3, 0, 0),
		"spine": Vector3(0.35, -0.2, 0), "thigh_l": Vector3(0.5, 0, 0.12), "thigh_r": Vector3(-0.35, 0, -0.12), "shin_r": Vector3(0.8, 0, 0), "shin_l": Vector3(0.4, 0, 0), "bob": -0.14},
}
const STYLE_IDS := ["ren", "lyra", "brann", "sera", "ember", "zeya", "hakuya", "vael", "lucien", "wenyu", "kuroha", "aion"]
const STYLES := {
	# Swordsman: santai percaya diri, pedang rendah di depan, bobot berpindah kaki
	"ren": {"wc": "sword", "len": 2.6, "sway": 0.06, "bob": -0.01, "beat": 1.0, "stride": 1.0, "bounce": 1.0, "lean": 0.04,
		"hold": {"upperarm_r": Vector3(-0.55, 0.0, -0.15), "forearm_r": Vector3(-0.75, 0, 0)}, "add": {"spine": Vector3(0.03, 0.05, 0)}},
	# Mage: tongkat tegak dua tangan, melayang pelan, kepala menengadah
	"lyra": {"wc": "staff", "len": 3.0, "sway": 0.035, "bob": 0.02, "beat": 1.0, "stride": 0.8, "bounce": 1.3, "lean": -0.02,
		"hold": {"upperarm_r": Vector3(-0.75, 0.0, -0.25), "forearm_r": Vector3(-1.0, 0, 0), "upperarm_l": Vector3(-0.55, 0.0, 0.3), "forearm_l": Vector3(-0.85, 0, 0)},
		"add": {"head": Vector3(-0.1, 0, 0)}},
	# Guardian (tank): kuda-kuda lebar, perisai/lengan depan, napas berat, langkah pendek menghentak
	"brann": {"wc": "guard", "len": 3.4, "sway": 0.02, "bob": -0.05, "beat": 1.0, "stride": 0.72, "bounce": 1.7, "lean": -0.06,
		"hold": {"upperarm_l": Vector3(-0.95, 0.0, 0.25), "forearm_l": Vector3(-1.3, 0, 0), "upperarm_r": Vector3(-0.5, 0.0, -0.3), "forearm_r": Vector3(-0.8, 0, 0)},
		"add": {"thigh_l": Vector3(0, 0, 0.12), "thigh_r": Vector3(0, 0, -0.12), "spine": Vector3(0.06, 0, 0), "head": Vector3(0.05, 0, 0)}},
	# Ranger: berdiri menyamping, tangan busur sedikit terangkat, kepala mengawasi, langkah ringan melenting
	"sera": {"wc": "bow", "len": 2.2, "sway": 0.05, "bob": 0.0, "beat": 1.0, "stride": 1.05, "bounce": 1.2, "lean": 0.05,
		"hold": {"upperarm_l": Vector3(-0.7, 0.0, 0.35), "forearm_l": Vector3(-0.5, 0, 0)},
		"add": {"spine": Vector3(0, -0.2, 0), "head": Vector3(0, 0.25, 0)}},
	# Pyromancer: telapak kiri terbuka memegang api, gelisah bergoyang
	"ember": {"wc": "staff", "len": 1.9, "sway": 0.08, "bob": 0.0, "beat": 2.0, "stride": 1.0, "bounce": 1.1, "lean": 0.02,
		"hold": {"upperarm_l": Vector3(-0.9, 0.0, 0.5), "forearm_l": Vector3(-1.1, 0, 0), "hand_l": Vector3(-0.6, 0, 0)},
		"add": {"head": Vector3(0.0, 0.1, 0.05)}},
	# Assassin: merunduk rendah, lengan rendah siap, langkah cepat dan senyap
	"zeya": {"wc": "dagger", "len": 1.8, "sway": 0.07, "bob": -0.09, "beat": 1.0, "stride": 1.15, "bounce": 0.7, "lean": 0.18,
		"hold": {"upperarm_r": Vector3(-0.5, 0.2, -0.3), "forearm_r": Vector3(-1.0, 0, 0), "upperarm_l": Vector3(-0.4, -0.2, 0.4), "forearm_l": Vector3(-1.0, 0, 0)},
		"add": {"thigh_l": Vector3(0.3, 0, 0.06), "thigh_r": Vector3(-0.2, 0, -0.06), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.4, 0, 0), "spine": Vector3(0.22, 0, 0)}},
	# Samurai putih: tegak tenang, tangan kiri di sarung, langkah meluncur
	"hakuya": {"wc": "sword", "len": 3.2, "sway": 0.015, "bob": 0.0, "beat": 1.0, "stride": 0.95, "bounce": 0.45, "lean": 0.0,
		"hold": {"upperarm_l": Vector3(-0.35, 0.0, 0.2), "forearm_l": Vector3(-1.1, 0, 0), "upperarm_r": Vector3(-0.5, 0.0, -0.1), "forearm_r": Vector3(-1.0, 0, 0)},
		"add": {"head": Vector3(0, 0.06, 0)}},
	# Pendekar cahaya: pedang tegak di depan dada, bangsawan, napas panjang
	"vael": {"wc": "sword", "len": 3.0, "sway": 0.03, "bob": 0.01, "beat": 1.0, "stride": 0.9, "bounce": 0.8, "lean": -0.02,
		"hold": {"upperarm_r": Vector3(-0.95, 0.15, -0.2), "forearm_r": Vector3(-1.3, 0, 0), "upperarm_l": Vector3(-0.2, 0.0, 0.3), "forearm_l": Vector3(-0.5, 0, 0)},
		"add": {"spine": Vector3(-0.03, 0, 0), "head": Vector3(-0.05, 0, 0)}},
	# Bangsawan bertongkat: tongkat menapak, tangan kiri di punggung, langkah rapi berirama
	"lucien": {"wc": "staff", "len": 3.4, "sway": 0.02, "bob": 0.0, "beat": 1.0, "stride": 0.85, "bounce": 0.9, "lean": -0.03,
		"hold": {"upperarm_r": Vector3(-0.35, 0.0, -0.15), "forearm_r": Vector3(-0.45, 0, 0), "upperarm_l": Vector3(0.45, 0.0, 0.15), "forearm_l": Vector3(-0.9, 0, 0)},
		"add": {"spine": Vector3(-0.04, 0, 0), "head": Vector3(0, 0.1, 0)}},
	# Peniup seruling: seruling di bibir, badan meliuk mengikuti irama lagu, langkah seperti menari
	"wenyu": {"wc": "staff", "len": 2.0, "sway": 0.13, "bob": 0.01, "beat": 2.0, "stride": 0.75, "bounce": 1.5, "lean": 0.0,
		"hold": {"upperarm_r": Vector3(-1.25, 0.35, -0.45), "forearm_r": Vector3(-1.95, 0, 0), "upperarm_l": Vector3(-1.15, -0.2, 0.55), "forearm_l": Vector3(-1.85, 0, 0)},
		"add": {"head": Vector3(0.12, 0.0, 0.1), "spine": Vector3(0.0, 0.0, 0.05)}},
	# Pengendali waktu: tongkat jam di tangan kanan, tangan kiri terbuka seperti menahan detik, langkah anggun melayang
	"aion": {"wc": "staff", "len": 2.6, "sway": 0.05, "bob": 0.015, "beat": 1.0, "stride": 0.85, "bounce": 1.1, "lean": -0.02,
		"hold": {"upperarm_r": Vector3(-0.6, 0.0, -0.2), "forearm_r": Vector3(-0.8, 0, 0), "upperarm_l": Vector3(-0.5, 0.0, 0.45), "forearm_l": Vector3(-0.9, 0, 0), "hand_l": Vector3(-0.4, 0, 0)},
		"add": {"head": Vector3(-0.04, 0.05, 0), "spine": Vector3(-0.02, 0, 0)}},
	# Samurai kelam: condong ke depan, tangan di gagang, menekan
	"kuroha": {"wc": "sword", "len": 2.8, "sway": 0.03, "bob": -0.04, "beat": 1.0, "stride": 1.05, "bounce": 0.6, "lean": 0.14,
		"hold": {"upperarm_r": Vector3(-0.6, 0.1, -0.2), "forearm_r": Vector3(-1.1, 0, 0), "upperarm_l": Vector3(-0.3, 0.0, 0.25), "forearm_l": Vector3(-1.0, 0, 0)},
		"add": {"spine": Vector3(0.2, 0, 0), "head": Vector3(0.12, 0, 0), "thigh_l": Vector3(0, 0, 0.07), "thigh_r": Vector3(0, 0, -0.07)}},
}


static func _fix_feet(d: Dictionary) -> void:
	d["foot_l"] = Vector3(-(d["thigh_l"].x + d["shin_l"].x) * 0.6, 0, 0)
	d["foot_r"] = Vector3(-(d["thigh_r"].x + d["shin_r"].x) * 0.6, 0, 0)


static func _style_apply(d: Dictionary, s: Dictionary, hold: bool = true) -> void:
	if hold:
		for b in s["hold"]:
			d[b] = s["hold"][b]
	for b in s["add"]:
		d[b] = (d[b] as Vector3) + (s["add"][b] as Vector3)


static func _p_idle_s(u: float, id: String) -> Dictionary:
	var s: Dictionary = STYLES[id]
	var d := _p_idle(u, true)
	_style_apply(d, s)
	var ph := u * TAU * float(s["beat"])
	d["hips"] = (d["hips"] as Vector3) + Vector3(0, 0.3 * float(s["sway"]) * sin(ph), float(s["sway"]) * sin(ph))
	d["spine"] = (d["spine"] as Vector3) + Vector3(0, 0.0, -0.6 * float(s["sway"]) * sin(ph))
	d["head"] = (d["head"] as Vector3) + Vector3(0, 0.0, 0.5 * float(s["sway"]) * sin(ph + 0.8))
	d["bob"] = float(d["bob"]) + float(s["bob"]) + 0.012 * sin(ph)
	_fix_feet(d)
	return d


static func _p_loco_s(u: float, run: float, id: String) -> Dictionary:
	var s: Dictionary = STYLES[id]
	var d := _p_loco(u, run, true)
	var st := float(s["stride"])
	for b in ["thigh_l", "thigh_r", "shin_l", "shin_r"]:
		d[b] = Vector3(d[b].x * st, d[b].y, d[b].z)
	d["bob"] = float(d["bob"]) * float(s["bounce"]) + float(s["bob"]) * 0.6
	var ph := u * TAU
	_style_apply(d, s)
	for b in s["hold"]:                           # tangan yang ditahan tetap sedikit mengayun mengikuti langkah
		if b.begins_with("upperarm"):
			d[b] = (d[b] as Vector3) + Vector3(0.12 * run * sin(ph) * (1.0 if b.ends_with("l") else -1.0), 0, 0)
	d["spine"] = (d["spine"] as Vector3) + Vector3(float(s["lean"]) * run, 0, 0)
	d["hips"] = (d["hips"] as Vector3) + Vector3(0, 0, float(s["sway"]) * 0.8 * sin(ph))
	_fix_feet(d)
	return d


static func _p_ready_s(u: float, id: String) -> Dictionary:
	var s: Dictionary = STYLES[id]
	var d := _p_idle_s(u, id)
	var r: Dictionary = READY_BASE[s["wc"]]
	for b in r:
		d[b] = r[b]
	var br := sin(u * TAU)
	d["spine"] = (d["spine"] as Vector3) + Vector3(0.02 * br, 0.03 * br, 0)
	d["bob"] = float(d["bob"]) + 0.01 * br
	if id == "wenyu":                                  # tetap memegang seruling meski siaga
		for b in s["hold"]:
			d[b] = s["hold"][b]
	_fix_feet(d)
	return d


static func ensure_style(id: String) -> bool:
	if not STYLES.has(id):
		return false
	var lib := get_library()
	if lib.has_animation("idle@" + id):
		return true
	var s: Dictionary = STYLES[id]
	lib.add_animation("idle@" + id, _make(float(s["len"]), true, func(u): return _p_idle_s(u, id)))
	lib.add_animation("walk@" + id, _make(1.0, true, func(u): return _p_loco_s(u, 0.5, id)))
	lib.add_animation("run@" + id, _make(0.7, true, func(u): return _p_loco_s(u, 1.0, id)))
	lib.add_animation("ready@" + id, _make(2.2, true, func(u): return _p_ready_s(u, id)))
	return true
