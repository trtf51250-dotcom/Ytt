class_name CharacterRig
extends Node3D
## Model karakter 3D beranimasi dari rig "ZN RIG V2" (assets/hero/hero.glb): satu mesh berkulit, 17 tulang.
## - Animasi: Animation asli dari AnimLibrary, dimainkan AnimationPlayer.
##   Pemain memakai AnimationTree (state machine + BlendSpace1D) untuk Idle/Walk/Run + Turn/Attack/Skill/Dodge/Damage/Death.
##   NPC & monster humanoid memakai AnimationPlayer saja (lebih ringan).
## - Tampilan: ShaderMaterial toon (shaders/toon_character.gdshader), kulit (skin) berbeda tiap karakter.
## Model menghadap +Z. Titik pusat rig = telapak kaki.

signal action_finished(action: String)

const MODEL_PATH := "res://assets/hero/hero.glb"
const MODEL_HEIGHT := 2.43
const FOOT_OFFSET := 0.0337
const TOON_SHADER := preload("res://shaders/toon_character.gdshader")
const ACTION_NODES := {"attack1": "Attack1", "attack2": "Attack2", "attack3": "Attack3", "skill": "Skill", "hurt": "Hurt",
	"dodge": "Dodge", "turn_l": "TurnL", "turn_r": "TurnR", "death": "Death"}

const GRIP_X := 0.095           # pusat genggaman relatif sendi tangan (satuan model): bergeser ke sisi dalam telapak
const GRIP_Y := -0.10
const GRIP_Z := 0.0
const READY_POS := 0.14           # posisi blend pose siaga (antara diam dan jalan)
const READY_TIME := 3.5           # detik tetap siaga setelah menyerang

static var _mat_cache: Dictionary = {}

var _space: AnimationNodeBlendSpace1D
var style_id := ""
var _ready_t := 0.0
var _bp := 0.0
var _bp_target := 0.0

var height := 1.8
var model_scale := 1.0
var model: Node3D
var skel: Skeleton3D
var mesh: MeshInstance3D
var player: AnimationPlayer
var tree: AnimationTree
var playback: AnimationNodeStateMachinePlayback
var material: ShaderMaterial
var armed := true
var use_tree := true
var weapon_class := "sword"

var hand_r: BoneAttachment3D
var hand_l: BoneAttachment3D
var head_att: BoneAttachment3D
var chest_att: BoneAttachment3D
var hips_att: BoneAttachment3D
var weapon_holder: Node3D          # di tangan kanan; 1 satuan = 1 meter dunia
var weapon_holder_l: Node3D        # di tangan kiri (busur)

const FINGER_CURL := [Vector2(1.15, 1.45), Vector2(1.2, 1.5), Vector2(1.25, 1.55), Vector2(1.3, 1.6)]   # rad: pangkal, ujung (genggam penuh)
var _finger_bones := {"l": [], "r": []}   # tiap sisi: [[a,b] x4, [th_a, th_b]]
var _grip := {"l": -1.0, "r": -1.0}
var eye_bones := {}                       # "l"/"r" -> indeks tulang mata (kedip/lirik)
var _anim_nodes: Dictionary = {}   # "Attack1" -> AnimationNodeAnimation
var _flash_left := 0.0
var _flash_color := Color(1, 1, 1)
var _last_action := ""
var _was_busy := false
var _dead := false


## p_height: tinggi karakter di dunia (meter). skin: tekstur kulit. with_tree: pakai AnimationTree (pemain).
var skin_texture: Texture2D


func setup(p_height: float, skin: Texture2D, with_tree: bool = false, p_armed: bool = true) -> void:
	skin_texture = skin
	height = p_height
	use_tree = with_tree
	armed = p_armed
	model_scale = p_height / MODEL_HEIGHT
	var ps: PackedScene = load(MODEL_PATH)
	model = ps.instantiate()
	model.name = "Model"
	model.scale = Vector3.ONE * model_scale
	model.position.y = FOOT_OFFSET * model_scale
	add_child(model)
	skel = _find_skel(model)
	skel.name = "Skeleton3D"
	for c in skel.get_children():
		if c is MeshInstance3D:
			mesh = c
	_find_finger_bones()
	material = _material_for(skin)
	mesh.material_override = material
	mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	mesh.extra_cull_margin = 1.5

	hand_r = _attach("hand_r")
	hand_l = _attach("hand_l")
	head_att = _attach("head")
	chest_att = _attach("chest")
	hips_att = _attach("hips")
	# pegangan senjata: bilah (sumbu +Y senjata) menunjuk ke depan saat tangan menggantung
	weapon_holder = Node3D.new()
	weapon_holder.name = "WeaponHolder"
	weapon_holder.position = Vector3(GRIP_X, GRIP_Y, GRIP_Z)       # pusat kepalan kanan (inward = +x)
	weapon_holder.rotation_degrees = Vector3(90, 0, 0)
	weapon_holder.scale = Vector3.ONE / model_scale
	hand_r.add_child(weapon_holder)
	weapon_holder_l = Node3D.new()
	weapon_holder_l.name = "WeaponHolderL"
	weapon_holder_l.position = Vector3(-GRIP_X, GRIP_Y, GRIP_Z)
	weapon_holder_l.rotation_degrees = Vector3(90, 0, 0)
	weapon_holder_l.scale = Vector3.ONE / model_scale
	hand_l.add_child(weapon_holder_l)

	_build_animation()
	set_grip("r", 1.0 if armed else 0.35)
	set_grip("l", 0.35)


func _find_finger_bones() -> void:
	for sd in ["l", "r"]:
		var arr: Array = []
		for i in 4:
			arr.append([skel.find_bone("f%d_%s_a" % [i, sd]), skel.find_bone("f%d_%s_b" % [i, sd])])
		arr.append([skel.find_bone("th_%s_a" % sd), skel.find_bone("th_%s_b" % sd)])
		_finger_bones[sd] = arr
		eye_bones[sd] = skel.find_bone("eye_%s" % sd)


## Mata (tulang eye_l / eye_r): closed 0 = terbuka, 1 = menutup (skala Y); gaze (-1..1) menggeser kuad mata untuk melirik.
func set_eye_state(closed: float, gaze: Vector2 = Vector2.ZERO) -> void:
	for sd in ["l", "r"]:
		var bi: int = eye_bones.get(sd, -1)
		if bi < 0:
			continue
		var rest := skel.get_bone_rest(bi)
		skel.set_bone_pose_position(bi, rest.origin + Vector3(gaze.x * 0.014, gaze.y * 0.01, 0.0))
		skel.set_bone_pose_scale(bi, Vector3(1.0, lerpf(1.0, 0.08, clampf(closed, 0.0, 1.0)), 1.0))


## Genggaman tangan: 0 = terbuka santai, 1 = kepalan penuh (jari melingkar ke arah telapak, jempol menutup). side: "l" / "r".
func set_grip(side: String, amount: float) -> void:
	amount = clampf(amount, 0.0, 1.0)
	if absf(float(_grip[side]) - amount) < 0.001:
		return
	_grip[side] = amount
	var sg := 1.0 if side == "l" else -1.0
	var fb: Array = _finger_bones[side]
	if fb.is_empty() or int(fb[0][0]) < 0:
		return
	for i in 4:
		var c: Vector2 = FINGER_CURL[i]
		var open_a := 0.12 + 0.05 * i                      # jari santai sedikit menekuk, makin ke kelingking makin menekuk
		skel.set_bone_pose_rotation(fb[i][0], Quaternion(Vector3(0, 0, 1), -sg * lerpf(open_a, c.x, amount)))
		skel.set_bone_pose_rotation(fb[i][1], Quaternion(Vector3(0, 0, 1), -sg * lerpf(open_a * 1.3, c.y, amount)))
	skel.set_bone_pose_rotation(fb[4][0], Quaternion(Vector3(0, 1, 0), -sg * lerpf(0.15, 0.75, amount)))
	skel.set_bone_pose_rotation(fb[4][1], Quaternion(Vector3(0, 1, 0), -sg * lerpf(0.1, 0.55, amount)))


func _find_skel(n: Node) -> Skeleton3D:
	if n is Skeleton3D:
		return n
	for c in n.get_children():
		var r := _find_skel(c)
		if r:
			return r
	return null


## Tempelkan BoneAttachment3D pada tulang mana pun (anak-anaknya memakai satuan rig, bukan meter).
func attach_bone(bone: String) -> BoneAttachment3D:
	var nm := "Att_" + bone
	if skel.has_node(nm):
		return skel.get_node(nm)
	return _attach(bone)


func _attach(bone: String) -> BoneAttachment3D:
	var a := BoneAttachment3D.new()
	a.name = "Att_" + bone
	a.bone_name = bone
	skel.add_child(a)
	return a


func _material_for(skin: Texture2D) -> ShaderMaterial:
	var key := skin.resource_path if skin.resource_path != "" else str(skin.get_instance_id())
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := ShaderMaterial.new()
	m.shader = TOON_SHADER
	m.set_shader_parameter("skin", skin)
	_mat_cache[key] = m
	return m


# =====================================================================
#  Animasi
# =====================================================================
func _build_animation() -> void:
	player = AnimationPlayer.new()
	player.name = "AnimationPlayer"
	add_child(player)
	player.add_animation_library("", AnimLibrary.get_library())
	if not use_tree:
		player.play("idle" if armed else "idle_n")
		return
	tree = AnimationTree.new()
	tree.name = "AnimationTree"
	add_child(tree)
	tree.anim_player = tree.get_path_to(player)

	var sm := AnimationNodeStateMachine.new()
	# --- state Move: BlendSpace1D (idle 0 - walk 0.5 - run 1) dibungkus TimeScale
	var bt := AnimationNodeBlendTree.new()
	var space := AnimationNodeBlendSpace1D.new()
	space.min_space = 0.0
	space.max_space = 1.0
	space.sync = true
	space.add_blend_point(_anim_node("idle"), 0.0)
	space.add_blend_point(_anim_node("idle"), READY_POS)     # indeks 1: pose siaga (diganti set_style)
	space.add_blend_point(_anim_node("walk"), 0.5)
	space.add_blend_point(_anim_node("run"), 1.0)
	_space = space
	bt.add_node("Space", space, Vector2(0, 0))
	var scale_node := AnimationNodeTimeScale.new()
	bt.add_node("Scale", scale_node, Vector2(300, 0))
	bt.connect_node("Scale", 0, "Space")
	bt.connect_node("output", 0, "Scale")
	sm.add_node("Move", bt, Vector2(200, 100))
	# --- state aksi sekali jalan
	var y := 0.0
	for a in ACTION_NODES.values():
		var n := _anim_node(_default_anim_for(a))
		_anim_nodes[a] = n
		sm.add_node(a, n, Vector2(500, y))
		y += 80.0
	sm.add_transition("Start", "Move", _tr(AnimationNodeStateMachineTransition.ADVANCE_MODE_AUTO))
	for a in ACTION_NODES.values():
		sm.add_transition("Move", a, _tr(AnimationNodeStateMachineTransition.ADVANCE_MODE_ENABLED, AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, 0.05))
		if a == "Death":
			sm.add_transition(a, "Move", _tr(AnimationNodeStateMachineTransition.ADVANCE_MODE_ENABLED, AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, 0.2))
		else:
			sm.add_transition(a, "Move", _tr(AnimationNodeStateMachineTransition.ADVANCE_MODE_AUTO, AnimationNodeStateMachineTransition.SWITCH_MODE_AT_END, 0.12))
		for b in ACTION_NODES.values():
			if a != b:
				sm.add_transition(a, b, _tr(AnimationNodeStateMachineTransition.ADVANCE_MODE_ENABLED, AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, 0.04))
	tree.tree_root = sm
	tree.active = true
	playback = tree.get("parameters/playback")
	set_weapon_class(weapon_class)


func _anim_node(anim: StringName) -> AnimationNodeAnimation:
	var n := AnimationNodeAnimation.new()
	n.animation = anim
	return n


func _tr(adv: int, sw: int = AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, xf: float = 0.08) -> AnimationNodeStateMachineTransition:
	var t := AnimationNodeStateMachineTransition.new()
	t.advance_mode = adv
	t.switch_mode = sw
	t.xfade_time = xf
	return t


func _default_anim_for(node_name: String) -> String:
	match node_name:
		"Attack1": return "attack_sword1"
		"Attack2": return "attack_sword2"
		"Attack3": return "attack_sword1"
		"Skill": return "skill_sword"
		"Hurt": return "hurt"
		"Dodge": return "dodge"
		"TurnL": return "turn_l"
		"TurnR": return "turn_r"
		"Death": return "death"
	return "idle"


## Pilih animasi serang/skill sesuai kelas senjata (sword / staff / guard / bow).
func set_weapon_class(wc: String) -> void:
	weapon_class = wc
	if _anim_nodes.is_empty():
		return
	var a1 := "attack_sword1"
	var a2 := "attack_sword2"
	var a3 := "attack_sword1"
	var sk := "skill_sword"
	match wc:
		"dagger":
			a1 = "attack_dagger1"; a2 = "attack_dagger2"; a3 = "attack_dagger3"; sk = "skill_dagger"
		"staff":
			a1 = "attack_staff"; a2 = "attack_staff"; a3 = "attack_staff"; sk = "skill_staff"
		"guard":
			a1 = "attack_smash"; a2 = "attack_smash"; a3 = "attack_smash"; sk = "skill_guard"
		"bow":
			a1 = "attack_bow"; a2 = "attack_bow"; a3 = "attack_bow"; sk = "skill_bow"
	_anim_nodes["Attack1"].animation = a1
	_anim_nodes["Attack2"].animation = a2
	_anim_nodes["Attack3"].animation = a3
	_anim_nodes["Skill"].animation = sk


## Pasang animasi diam/jalan/lari/siaga khas karakter (lihat AnimLibrary.STYLES).
func set_style(id: String) -> void:
	if not AnimLibrary.ensure_style(id):
		return
	style_id = id
	if _space != null:
		_space.set_blend_point_node(0, _anim_node("idle@" + id))
		_space.set_blend_point_node(1, _anim_node("ready@" + id))
		_space.set_blend_point_node(2, _anim_node("walk@" + id))
		_space.set_blend_point_node(3, _anim_node("run@" + id))
	elif player != null and not use_tree:
		player.play("idle@" + id)


## Gerak dasar: speed01 0..1 (0 diam, 0.5 jalan, 1 lari), speed_scale = pengali kecepatan putar animasi.
func set_move(speed01: float, speed_scale: float = 1.0) -> void:
	if tree == null:
		return
	var tgt := clampf(speed01, 0.0, 1.0)
	if tgt < 0.04 and _ready_t > 0.0 and style_id != "":
		tgt = READY_POS
	_bp_target = tgt
	tree.set("parameters/Move/Scale/scale", maxf(speed_scale, 0.05))


## Jalankan aksi: attack1, attack2, skill, hurt, dodge, turn_l, turn_r, death.
func play_action(action: String) -> void:
	if playback == null or not ACTION_NODES.has(action):
		return
	var node: String = ACTION_NODES[action]
	if action == "death":
		_dead = true
	_last_action = action
	if action in ["attack1", "attack2", "attack3", "skill"]:
		_ready_t = READY_TIME
	if action == "skill" and has_meta("eye_glow"):
		(get_meta("eye_glow") as Callable).call(0.8, 0.9)        # mata bersinar saat skill/ULT
	if playback.get_current_node() == node:
		playback.start(node, true)
	else:
		playback.travel(node)


func revive() -> void:
	_dead = false
	if playback:
		playback.travel("Move")


func current_state() -> String:
	if playback == null:
		return ""
	return str(playback.get_current_node())


## Sedang menjalankan aksi (bukan Move)?
func is_busy() -> bool:
	if playback == null:
		return false
	return playback.get_current_node() != &"Move"


## Panjang animasi aksi saat ini dalam detik (untuk menyinkronkan serangan).
func action_length(action: String) -> float:
	if not _anim_nodes.has(ACTION_NODES.get(action, "")):
		return 0.4
	var a: Animation = player.get_animation(_anim_nodes[ACTION_NODES[action]].animation)
	return a.length if a else 0.4


## Detik sejak aksi mulai sampai momen serangan benar-benar mengenai (fase ayunan puncak pada animasi).
func action_impact(action: String) -> float:
	if not _anim_nodes.has(ACTION_NODES.get(action, "")):
		return 0.2
	var nm := String(_anim_nodes[ACTION_NODES[action]].animation)
	return AnimLibrary.impact_time(nm)


## Putar animasi berulang tanpa AnimationTree (NPC): idle, idle_cross, idle_hammer, walk_n, dst.
func play_loop(anim: String, blend: float = 0.25, speed: float = 1.0) -> void:
	if player == null or tree != null:
		return
	if player.current_animation == anim:
		player.speed_scale = speed
		return
	player.play(anim, blend, speed)


func stop_animation() -> void:
	if player:
		player.pause()


# =====================================================================
#  Efek
# =====================================================================
func flash(color: Color = Color(1, 1, 1), seconds: float = 0.14) -> void:
	_flash_color = color
	_flash_left = seconds
	set_flash_amount(1.0)


## Catatan: material dibagi antar rig dengan kulit yang sama, jadi kilatan memakai material tiruan per-rig.
func set_flash_amount(a: float) -> void:
	if material == null:
		return
	if not mesh.material_override.has_meta("own"):
		var own := material.duplicate() as ShaderMaterial
		own.set_meta("own", true)
		material = own
		mesh.material_override = own
	material.set_shader_parameter("flash", Color(_flash_color.r, _flash_color.g, _flash_color.b, a))


func set_tint(c: Color) -> void:
	if not mesh.material_override.has_meta("own"):
		var own := material.duplicate() as ShaderMaterial
		own.set_meta("own", true)
		material = own
		mesh.material_override = own
	material.set_shader_parameter("tint", c)


func _process(delta: float) -> void:
	if _ready_t > 0.0:
		_ready_t -= delta
		if _ready_t <= 0.0 and _bp_target == READY_POS:
			_bp_target = 0.0
	if tree != null:
		_bp = move_toward(_bp, _bp_target, delta * (2.2 if _bp_target < 0.2 else 6.0))
		tree.set("parameters/Move/Space/blend_position", _bp)
	if _flash_left > 0.0:
		_flash_left -= delta
		set_flash_amount(clampf(_flash_left / 0.14, 0.0, 1.0))
	if tree != null and playback != null:
		var busy := is_busy()
		if _was_busy and not busy and not _dead:
			action_finished.emit(_last_action)
		_was_busy = busy


# =====================================================================
#  Benda pada tubuh (koordinat benda = satuan dunia, bukan satuan rig)
# =====================================================================
func add_in_right_hand(n: Node3D, pos: Vector3 = Vector3.ZERO, rot_deg: Vector3 = Vector3.ZERO) -> void:
	n.position = pos
	n.rotation_degrees = rot_deg
	weapon_holder.add_child(n)
	set_grip("r", 1.0)


func add_in_left_hand(n: Node3D, pos: Vector3 = Vector3.ZERO, rot_deg: Vector3 = Vector3.ZERO) -> void:
	n.position = pos
	n.rotation_degrees = rot_deg
	weapon_holder_l.add_child(n)
	set_grip("l", 1.0)


## Pasang di kepala: pos dalam meter dunia relatif ke sendi leher.
func add_on_head(n: Node3D, pos: Vector3 = Vector3.ZERO, rot_deg: Vector3 = Vector3.ZERO) -> void:
	_add_scaled(head_att, n, pos, rot_deg)


func add_on_chest(n: Node3D, pos: Vector3 = Vector3.ZERO, rot_deg: Vector3 = Vector3.ZERO) -> void:
	_add_scaled(chest_att, n, pos, rot_deg)


func add_on_hips(n: Node3D, pos: Vector3 = Vector3.ZERO, rot_deg: Vector3 = Vector3.ZERO) -> void:
	_add_scaled(hips_att, n, pos, rot_deg)


func _add_scaled(att: BoneAttachment3D, n: Node3D, pos: Vector3, rot_deg: Vector3) -> void:
	var h := Node3D.new()
	h.position = pos / model_scale
	h.rotation_degrees = rot_deg
	h.scale = Vector3.ONE / model_scale
	att.add_child(h)
	h.add_child(n)


func clear_holder(h: Node3D) -> void:
	for c in h.get_children():
		c.queue_free()


func bone_world_position(bone: String) -> Vector3:
	var i := skel.find_bone(bone)
	return skel.to_global(skel.get_bone_global_pose(i).origin)
