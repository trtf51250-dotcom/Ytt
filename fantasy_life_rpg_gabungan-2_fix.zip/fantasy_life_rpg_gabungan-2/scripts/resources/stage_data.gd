class_name StageData
extends Resource
## Data satu stage petualangan. File .tres ada di res://resources/stages/.
## waves: Array of Dictionary, contoh [{"slime": 4}, {"slime": 3, "bat": 2}]. boss: "" atau id bos ("golem").

@export var id: String = ""
@export var display_name: String = ""
@export var chapter: String = "Bab 1"
@export_multiline var description: String = ""
@export var theme: String = "meadow"          # meadow / forest / cave / boss
@export var recommended_level: int = 1
@export var waves: Array = []
@export var boss: String = ""
@export var reward_gold: int = 100
@export var reward_exp: int = 80
@export var reward_diamond: int = 0
@export var first_clear_diamond: int = 0      # bonus diamond untuk kemenangan pertama
@export var unlock_after: String = ""         # id stage yang harus dibersihkan dulu
@export var music: String = "music_desert"
