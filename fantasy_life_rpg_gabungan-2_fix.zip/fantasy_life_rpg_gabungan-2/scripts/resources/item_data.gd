class_name ItemData
extends Resource
## Data satu item (senjata, armor, aksesori, ramuan). File .tres ada di res://resources/items/.

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""
@export var type: String = "weapon"           # weapon / armor / accessory / potion
@export var rarity: int = 1                   # 1..5
@export var weapon_class: String = ""         # sword / staff / guard / bow (kosong = semua karakter)
@export var atk: int = 0
@export var def: int = 0
@export var hp: int = 0
@export var heal: int = 0                     # pemulihan HP untuk ramuan
@export var buy_price: int = 0                # 0 = tidak dijual di toko
@export var shop: String = ""                 # "weapon" (toko senjata/armor) / "item" (toko ramuan) / ""
@export var in_gacha: bool = false
@export var color: Color = Color(0.8, 0.8, 0.9)


## Harga jual ke toko: setengah harga beli, atau nilai tetap menurut rarity bila tidak dijual di toko.
func sell_price() -> int:
	if buy_price > 0:
		return maxi(1, buy_price / 2)
	var by_rarity := [50, 200, 650, 1800, 4500]   # sama dengan separuh harga toko tingkat itu (2★=200, 3★=650)
	return by_rarity[clampi(rarity - 1, 0, 4)]
