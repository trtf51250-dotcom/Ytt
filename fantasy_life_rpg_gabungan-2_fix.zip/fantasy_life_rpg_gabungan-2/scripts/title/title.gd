extends Control
## Layar judul: Lanjutkan / Permainan Baru / Pengaturan. Semua UI & latar dibuat lewat kode (tanpa aset gambar).
## Tampilan: kota kastil di tebing saat malam (air terjun, lampu desa, kunang-kunang), logo emas di kiri, menu berpelat emas.
## Latar statis digambar SEKALI (_bg), hanya lapisan efek (_fx) yang digambar ulang ~30 fps agar hemat baterai.

const WARM := Color(1.0, 0.78, 0.38)
const COL_W := 580.0

var host: PanelHost
var _box: VBoxContainer
var _col: VBoxContainer
var _msg: Label
var _bg: Control
var _fx: Control
var _confirm_del := false
var _confirm_new := false
var _intro_done := false
var _t := 0.0
var _fx_acc := 0.0
var _menu_w := 400.0
var _stars: Array = []
var _embers: Array = []
var _windows: Array = []   # jendela yang berkedip: [Vector2 posisi, lebar, tinggi, fase]
var _falls: Array = []     # air terjun: [x, y0, y1, lebar]
var _shoot_t := -1.0
var _next_shoot := 3.5
var _shoot_from := Vector2(0.5, 0.1)
var _sky_tex: GradientTexture2D
var _vig_tex: GradientTexture2D
var _top_tex: GradientTexture2D
var _mist_tex: GradientTexture2D


func _ready() -> void:
	InputSetup.ensure()
	theme = UiTheme.get_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	Sfx.music("music_main")
	for i in 55:
		_stars.append([Vector2(randf(), randf() * 0.5), randf_range(1.0, 2.8), randf() * TAU])
	for i in 26:
		_embers.append([randf_range(0.35, 1.0), randf_range(0.05, 0.14), randf(), randf_range(1.2, 2.2)])

	_sky_tex = _grad(PackedFloat32Array([0.0, 0.45, 0.78, 1.0]), PackedColorArray([Color(0.02, 0.03, 0.12), Color(0.07, 0.10, 0.30), Color(0.30, 0.20, 0.42), Color(0.58, 0.34, 0.36)]), true)
	_vig_tex = _grad(PackedFloat32Array([0.0, 0.55, 1.0]), PackedColorArray([Color(0.01, 0.015, 0.06, 0.86), Color(0.01, 0.015, 0.06, 0.5), Color(0.01, 0.015, 0.06, 0.0)]), false)
	_top_tex = _grad(PackedFloat32Array([0.0, 1.0]), PackedColorArray([Color(0, 0, 0.04, 0.5), Color(0, 0, 0.04, 0.0)]), true)
	_mist_tex = _grad(PackedFloat32Array([0.0, 0.5, 1.0]), PackedColorArray([Color(0.7, 0.75, 1.0, 0.0), Color(0.7, 0.75, 1.0, 0.13), Color(0.7, 0.75, 1.0, 0.0)]), true)

	_bg = Control.new()
	_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_bg.draw.connect(_draw_bg)
	_bg.resized.connect(_bg.queue_redraw)
	add_child(_bg)
	_fx = Control.new()
	_fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fx.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fx.draw.connect(_draw_fx)
	add_child(_fx)

	_build_layout()

	var ver := UiTheme.label("Prototipe • Godot 4.3", 15, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_RIGHT)
	ver.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	ver.offset_left -= 28.0
	ver.offset_right -= 28.0
	ver.offset_top -= 18.0
	ver.offset_bottom -= 18.0
	add_child(ver)

	host = PanelHost.new()
	add_child(host)
	_build_menu()

	# Muncul perlahan
	_col.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(_col, "modulate:a", 1.0, 0.45)
	_intro_done = true

	var a := OS.get_cmdline_user_args()
	if a.has("--bot=1"):
		call_deferred("_bot")


func _process(d: float) -> void:
	_t += d
	_fx_acc += d
	if _fx_acc >= 1.0 / 30.0:
		_fx_acc = 0.0
		_fx.queue_redraw()
	if _shoot_t >= 0.0:
		_shoot_t += d
		if _shoot_t > 0.9:
			_shoot_t = -1.0
			_next_shoot = _t + randf_range(5.0, 11.0)
	elif _t >= _next_shoot:
		_shoot_t = 0.0
		_shoot_from = Vector2(randf_range(0.35, 0.8), randf_range(0.04, 0.2))


# ---------------------------------------------------------------- tata letak kiri (logo + menu)

func _font(spacing: int, embolden: float = 0.0) -> FontVariation:
	var f := FontVariation.new()
	f.base_font = ThemeDB.fallback_font
	f.spacing_glyph = spacing
	f.variation_embolden = embolden
	return f


func _grad(offs: PackedFloat32Array, cols: PackedColorArray, vertical: bool) -> GradientTexture2D:
	var g := Gradient.new()
	g.offsets = offs
	g.colors = cols
	var t := GradientTexture2D.new()
	t.gradient = g
	t.fill_from = Vector2(0, 0)
	t.fill_to = Vector2(0, 1) if vertical else Vector2(1, 0)
	t.width = 4 if vertical else 256
	t.height = 256 if vertical else 4
	return t


func _logo_line(text: String, size: int, spacing: int) -> Control:
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(0, size * 1.3)
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var f := _font(spacing, 0.6)
	for i in 2:
		var l := Label.new()
		l.text = text
		l.add_theme_font_override("font", f)
		l.add_theme_font_size_override("font_size", size)
		l.add_theme_color_override("font_color", Color(1.0, 0.88, 0.45) if i == 1 else Color(0.5, 0.28, 0.05))
		l.add_theme_color_override("font_outline_color", Color(0.12, 0.05, 0.0, 0.95))
		l.add_theme_constant_override("outline_size", 3 if i == 1 else 8)
		l.position = Vector2(0.0, 0.0 if i == 1 else 4.0)
		holder.add_child(l)
	return holder


func _fade_line(fade_in: bool) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(30, 22)
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.draw.connect(func():
		var w := c.size.x
		var y := c.size.y * 0.5
		var n := 24
		for i in n:
			var f0 := float(i) / n
			var f1 := float(i + 1) / n
			var a := f0 if fade_in else 1.0 - f0
			c.draw_line(Vector2(w * f0, y), Vector2(w * f1, y), Color(UiTheme.GOLD, a * 0.95), 2.0)
			c.draw_line(Vector2(w * f0, y + 5.0), Vector2(w * f1, y + 5.0), Color(UiTheme.GOLD_DARK, a * 0.5), 1.0))
	return c


func _build_layout() -> void:
	var m := UiTheme.safe_insets()
	_col = VBoxContainer.new()
	_col.add_theme_constant_override("separation", 4)
	_col.alignment = BoxContainer.ALIGNMENT_CENTER
	_col.set_anchors_and_offsets_preset(Control.PRESET_LEFT_WIDE)
	_col.offset_left = 72.0 + float(m["left"])
	_col.offset_right = 72.0 + float(m["left"]) + COL_W
	_col.offset_top = 16.0
	_col.offset_bottom = -16.0
	add_child(_col)

	var logo_font := _font(4, 0.6)
	var logo_w := logo_font.get_string_size("FANTASY LIFE", HORIZONTAL_ALIGNMENT_LEFT, -1, 58).x + 12.0
	_menu_w = clampf(logo_w, 380.0, 460.0)

	var header := VBoxContainer.new()
	header.add_theme_constant_override("separation", 0)
	header.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	header.custom_minimum_size = Vector2(logo_w, 0)
	_col.add_child(header)
	header.add_child(_logo_line("FANTASY LIFE", 58, 4))

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row.add_child(_fade_line(true))
	var rpg := UiTheme.label("RPG", 26, Color(0.78, 0.9, 1.0), HORIZONTAL_ALIGNMENT_CENTER)
	rpg.add_theme_font_override("font", _font(14, 0.3))
	row.add_child(rpg)
	row.add_child(_fade_line(false))
	header.add_child(row)

	var sub := UiTheme.label("Kota Aurelia menunggumu", 21, Color(0.72, 0.86, 1.0), HORIZONTAL_ALIGNMENT_CENTER)
	sub.add_theme_font_override("font", _font(2))
	header.add_child(sub)

	var sp := Control.new()
	sp.custom_minimum_size = Vector2(0, 26)
	_col.add_child(sp)

	_box = VBoxContainer.new()
	_box.add_theme_constant_override("separation", 10)
	_box.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_box.custom_minimum_size = Vector2(_menu_w, 0)
	_col.add_child(_box)

	_msg = UiTheme.label("", 17, UiTheme.SKY, HORIZONTAL_ALIGNMENT_LEFT)
	_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_msg.custom_minimum_size = Vector2(_menu_w + 40.0, 44)
	_col.add_child(_msg)


# ---------------------------------------------------------------- tombol bergaya pelat emas

func _plate(bg: Color, edge: Color, left_w: int, glow: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = edge
	s.border_width_left = left_w
	s.border_width_top = 1
	s.border_width_right = 1
	s.border_width_bottom = 1
	s.set_corner_radius_all(5)
	s.content_margin_left = 26
	s.content_margin_right = 18
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	if glow > 0:
		s.shadow_color = Color(edge, 0.35)
		s.shadow_size = glow
	s.anti_aliasing = true
	return s


## kind: 0 biasa, 1 utama (emas, berdenyut), 2 berbahaya (merah)
func _menu_button(text: String, kind: int = 0, h: float = 52.0) -> Button:
	var b := UiTheme.button(text, Vector2(0, h))
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_font_override("font", _font(2, 0.15))
	var bg := Color(0.04, 0.07, 0.19, 0.74)
	var edge := UiTheme.GOLD_DARK
	var hov_bg := Color(0.13, 0.17, 0.37, 0.92)
	var hov_edge := UiTheme.GOLD
	var txt := Color(0.9, 0.94, 1.0)
	b.add_theme_font_size_override("font_size", 22)
	if kind == 1:
		bg = Color(0.52, 0.36, 0.08, 0.95)
		edge = Color(1.0, 0.84, 0.42)
		hov_bg = Color(0.66, 0.47, 0.12, 1.0)
		hov_edge = Color(1.0, 0.92, 0.6)
		txt = Color(1, 1, 1)
		b.add_theme_font_size_override("font_size", 25)
	elif kind == 2:
		edge = Color(0.62, 0.26, 0.32)
		hov_edge = Color(1.0, 0.5, 0.5)
		txt = UiTheme.BAD
	b.add_theme_stylebox_override("normal", _plate(bg, edge, 4 if kind == 1 else 3, 8 if kind == 1 else 0))
	b.add_theme_stylebox_override("hover", _plate(hov_bg, hov_edge, 8, 12))
	b.add_theme_stylebox_override("pressed", _plate(bg.darkened(0.3), hov_edge, 8, 4))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", txt)
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1) if kind != 2 else Color(1.0, 0.7, 0.7))
	b.add_theme_color_override("font_pressed_color", UiTheme.GOLD)
	return b


func _add_btn(text: String, kind: int, h: float, cb: Callable) -> Button:
	var b := _menu_button(text, kind, h)
	b.pressed.connect(cb)
	_box.add_child(b)
	if kind == 1:
		var sb := b.get_theme_stylebox("normal") as StyleBoxFlat
		var tw := b.create_tween().set_loops()
		tw.tween_property(sb, "shadow_size", 18, 1.1)
		tw.tween_property(sb, "shadow_size", 5, 1.1)
	return b


func _build_menu() -> void:
	for c in _box.get_children():
		c.queue_free()
	if GameState.banned:
		_box.add_child(UiTheme.label("AKUN DIBLOKIR", 38, UiTheme.BAD))
		var why := UiTheme.label(str(GameState.ban_info.get("reason", "")), 18, UiTheme.TEXT)
		why.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_box.add_child(why)
		_box.add_child(UiTheme.label("ID: %s" % str(GameState.ban_info.get("id", "?")), 20, UiTheme.GOLD))
		_box.add_child(UiTheme.label("Pada %s" % str(GameState.ban_info.get("at", "")).replace("T", " "), 15, UiTheme.TEXT_DIM))
		# banding: pulihkan hanya dengan ID (hanya ID yang sudah disetujui yang berhasil)
		var id_edit := LineEdit.new()
		id_edit.text = str(GameState.ban_info.get("id", ""))
		id_edit.placeholder_text = "FL-XXXX-XXXX"
		id_edit.custom_minimum_size = Vector2(0, 48)
		id_edit.add_theme_font_size_override("font_size", 22)
		_box.add_child(id_edit)
		_add_btn("Pulihkan dengan ID", 1, 56.0, func():
			var r := GameState.recover_by_id(id_edit.text)
			_msg.text = str(r["msg"])
			_build_menu())
		return
	var info := GameState.save_info()
	var has: bool = not info.is_empty() and not bool(info.get("corrupt", false))
	if has:
		var secs := int(info["play_time"])
		_box.add_child(UiTheme.label("%s · Lv %d · Stage selesai %d · %d j %d m" % [info["name"], info["level"], info["stages"], secs / 3600, (secs % 3600) / 60], 17, UiTheme.SKY))
		_add_btn("Lanjutkan", 1, 64.0, _continue)
		_add_btn("Mulai Baru" if not _confirm_new else "Yakin? Data lama HILANG", 0, 52.0, func():
			if _confirm_new:
				_new_game()
			else:
				_confirm_new = true
				_build_menu())
	else:
		if info.get("corrupt", false):
			_box.add_child(UiTheme.label("Data permainan rusak.", 18, UiTheme.BAD))
		_add_btn("Mulai Bermain", 1, 64.0, _new_game)
		_add_btn("Pulihkan dari Kode Cadangan", 0, 52.0, _import)
	_add_btn("Pengaturan", 0, 52.0, func(): host.open("settings"))
	if not info.is_empty():
		_add_btn("Hapus Data" if not _confirm_del else "Yakin? Hilang selamanya", 2, 46.0, func():
			if _confirm_del:
				_confirm_del = false
				GameState.delete_save()
				_msg.text = "Data dihapus dari perangkat ini."
			else:
				_confirm_del = true
			_build_menu())


# ---------------------------------------------------------------- latar statis (digambar sekali)

func _win(c: Control, x: float, y: float, w: float, h: float, rng: RandomNumberGenerator, arch: bool) -> void:
	c.draw_circle(Vector2(x, y + h * 0.5), maxf(w, h) * 1.15, Color(WARM, 0.09))
	c.draw_rect(Rect2(x - w * 0.5, y, w, h), Color(WARM, 0.82))
	if arch:
		c.draw_circle(Vector2(x, y), w * 0.5, Color(WARM, 0.82))
	if rng.randf() < 0.3:
		_windows.append([Vector2(x, y), w, h, rng.randf() * TAU])


func _pine(c: Control, x: float, base: float, h: float, col: Color) -> void:
	var w := h * 0.42
	c.draw_rect(Rect2(x - w * 0.04, base - h * 0.1, w * 0.08, h * 0.12), col)
	for i in 4:
		var top := base - h + float(i) * h * 0.2
		var bot := top + h * 0.38
		var hw := w * (0.35 + float(i) * 0.22) * 0.5
		c.draw_colored_polygon(PackedVector2Array([Vector2(x, top), Vector2(x + hw, bot), Vector2(x - hw, bot)]), col)


func _ridge(c: Control, s: Vector2, base: float, amp: float, seed_v: float, col: Color) -> void:
	var pts := PackedVector2Array()
	pts.append(Vector2(0, s.y))
	var n := 48
	for i in n + 1:
		var f := float(i) / n
		var h := sin(f * 5.1 + seed_v) * 0.5 + sin(f * 11.3 + seed_v * 2.1) * 0.3 + sin(f * 23.7 + seed_v * 3.7) * 0.2
		pts.append(Vector2(f * s.x, s.y * base - h * amp * s.y))
	pts.append(Vector2(s.x, s.y))
	c.draw_colored_polygon(pts, col)


func _house(c: Control, x: float, base: float, w: float, h: float, col: Color, rng: RandomNumberGenerator) -> void:
	c.draw_rect(Rect2(x, base - h, w, h + 1.0), col)
	var rh := h * rng.randf_range(0.45, 0.8)
	c.draw_colored_polygon(PackedVector2Array([Vector2(x - w * 0.08, base - h), Vector2(x + w * 1.08, base - h), Vector2(x + w * 0.5, base - h - rh)]), col.lightened(0.07))
	var n := 1 + rng.randi() % 3
	for i in n:
		if rng.randf() < 0.78:
			_win(c, x + w * (float(i) + 0.5) / float(n), base - h * 0.78, w * 0.13, h * 0.3, rng, false)
	if rng.randf() < 0.22:
		var lx := x + w + w * 0.12
		c.draw_circle(Vector2(lx, base - h * 0.35), 7.0, Color(WARM, 0.12))
		c.draw_circle(Vector2(lx, base - h * 0.35), 2.2, Color(1.0, 0.88, 0.55, 0.95))


func _draw_castle(c: Control, cx: float, by: float, u: float, rng: RandomNumberGenerator) -> void:
	var body := Color(0.15, 0.13, 0.24)
	var lit := Color(0.62, 0.4, 0.2, 0.30)
	var roof := Color(0.08, 0.10, 0.25)
	# aula besar + tembok berpagar
	var hall := Rect2(cx - 0.30 * u, by - 0.17 * u, 0.60 * u, 0.17 * u)
	c.draw_rect(hall, body.darkened(0.15))
	var n := 20
	var cw := hall.size.x / (float(n) * 2.0 - 1.0)
	for i in n:
		c.draw_rect(Rect2(hall.position.x + float(i) * 2.0 * cw, hall.position.y - cw * 1.1, cw, cw * 1.1 + 1.0), body.darkened(0.15))
	for i in 9:
		_win(c, hall.position.x + hall.size.x * (float(i) + 0.5) / 9.0, hall.position.y + 0.045 * u, 0.013 * u, 0.034 * u, rng, true)
	# menara: [dx, lebar, tinggi, tinggi atap]  (urutan: belakang -> depan)
	var towers := [[-0.34, 0.07, 0.15, 0.08], [0.34, 0.075, 0.18, 0.09], [-0.21, 0.10, 0.22, 0.11], [0.21, 0.11, 0.26, 0.12], [-0.09, 0.05, 0.38, 0.12], [0.10, 0.05, 0.33, 0.11], [0.0, 0.16, 0.30, 0.15]]
	for t in towers:
		var x := cx + float(t[0]) * u
		var w := float(t[1]) * u
		var h := float(t[2]) * u
		var rh := float(t[3]) * u
		var top := by - h
		c.draw_rect(Rect2(x - w * 0.5, top, w, h + 0.02 * u), body)
		c.draw_rect(Rect2(x - w * 0.5, top, w * 0.3, h), lit)
		c.draw_rect(Rect2(x - w * 0.62, top - 0.012 * u, w * 1.24, 0.016 * u), body.lightened(0.06))
		var rb := top - 0.01 * u
		c.draw_colored_polygon(PackedVector2Array([Vector2(x - w * 0.68, rb), Vector2(x + w * 0.68, rb), Vector2(x, rb - rh)]), roof)
		c.draw_line(Vector2(x - w * 0.68, rb), Vector2(x, rb - rh), Color(WARM, 0.55), 1.5)
		var rows := int(h / (0.075 * u))
		for r in rows:
			var wy := top + 0.03 * u + float(r) * 0.075 * u
			if w < 0.06 * u:
				if rng.randf() < 0.85:
					_win(c, x, wy, 0.011 * u, 0.028 * u, rng, true)
			else:
				for k in 2:
					if rng.randf() < 0.85:
						_win(c, x + (float(k) - 0.5) * w * 0.48, wy, 0.012 * u, 0.03 * u, rng, true)
		if float(t[0]) == -0.09:   # bendera di menara tertinggi
			var tip := Vector2(x, rb - rh)
			c.draw_line(tip, tip + Vector2(0, -0.04 * u), Color(0.9, 0.8, 0.5), 1.5)
			c.draw_colored_polygon(PackedVector2Array([tip + Vector2(0, -0.04 * u), tip + Vector2(0.03 * u, -0.032 * u), tip + Vector2(0, -0.024 * u)]), Color(1.0, 0.55, 0.3))


func _draw_bg() -> void:
	var c := _bg
	var s := c.size
	if s.x < 8.0 or s.y < 8.0:
		return
	var u := s.y
	var rng := RandomNumberGenerator.new()
	rng.seed = 20240
	_windows.clear()
	_falls.clear()
	var cx := maxf(s.x * 0.72, s.x - 0.62 * u)
	var by := 0.62 * u

	c.draw_texture_rect(_sky_tex, Rect2(Vector2.ZERO, s), false)

	# bulan + cahaya
	var mp := Vector2(minf(s.x * 0.93, cx + 0.62 * u), 0.14 * u)
	for i in 9:
		c.draw_circle(mp, u * 0.045 * (1.0 + float(i) * 0.55), Color(0.75, 0.82, 1.0, 0.03))
	c.draw_circle(mp, u * 0.045, Color(0.96, 0.95, 0.86))
	c.draw_circle(mp + Vector2(-0.012, 0.008) * u, u * 0.012, Color(0.85, 0.84, 0.75))
	c.draw_circle(mp + Vector2(0.014, -0.012) * u, u * 0.008, Color(0.86, 0.85, 0.77))

	# pegunungan jauh
	_ridge(c, s, 0.60, 0.07, 1.3, Color(0.16, 0.16, 0.38))
	_ridge(c, s, 0.70, 0.06, 4.1, Color(0.10, 0.11, 0.28))

	# pendar hangat di belakang kastil
	for i in 9:
		c.draw_circle(Vector2(cx, by - 0.2 * u), u * (0.75 - float(i) * 0.07), Color(1.0, 0.6, 0.25, 0.028))

	# tebing
	var cliff := PackedVector2Array([
		Vector2(cx - 0.95 * u, s.y), Vector2(cx - 0.70 * u, by + 0.28 * u), Vector2(cx - 0.52 * u, by + 0.07 * u),
		Vector2(cx - 0.46 * u, by + 0.01 * u), Vector2(cx - 0.40 * u, by), Vector2(cx + 0.42 * u, by),
		Vector2(cx + 0.60 * u, by + 0.08 * u), Vector2(cx + 0.95 * u, by + 0.2 * u), Vector2(cx + 1.5 * u, by + 0.3 * u),
		Vector2(maxf(s.x, cx + 1.5 * u) + 20.0, s.y)])
	c.draw_colored_polygon(cliff, Color(0.085, 0.095, 0.21))
	for i in 16:
		var rx := lerpf(cx - 0.40 * u, cx + 0.42 * u, float(i) / 15.0)
		c.draw_line(Vector2(rx, by + 0.004 * u), Vector2(rx + rng.randf_range(-0.04, 0.04) * u, by + rng.randf_range(0.08, 0.3) * u), Color(0.2, 0.22, 0.4, 0.28), 2.0)
	c.draw_line(Vector2(cx - 0.40 * u, by), Vector2(cx + 0.42 * u, by), Color(1.0, 0.7, 0.35, 0.4), 2.0)

	# air terjun (aliran tambahan dianimasikan di _fx)
	var fx0 := cx - 0.44 * u
	var fy1 := 0.86 * u
	for f in [[0.0, 0.014], [0.03, 0.009]]:
		var fxx := fx0 + float(f[0]) * u
		c.draw_rect(Rect2(fxx - float(f[1]) * u * 0.5, by + 0.02 * u, float(f[1]) * u, fy1 - by - 0.02 * u), Color(0.72, 0.86, 1.0, 0.42))
		_falls.append([fxx, by + 0.02 * u, fy1, float(f[1]) * u])

	_draw_castle(c, cx, by, u, rng)

	# desa di bawah kastil (dua baris rumah)
	var rows := [[0.84, Color(0.05, 0.06, 0.145)], [0.945, Color(0.03, 0.035, 0.10)]]
	for row in rows:
		var base_y: float = s.y * float(row[0])
		var col: Color = row[1]
		var x0 := cx - 0.62 * u + (0.0 if float(row[0]) < 0.9 else 0.2 * u)
		c.draw_rect(Rect2(x0, base_y, s.x - x0 + 30.0, s.y - base_y + 2.0), col)
		var x := x0
		while x < s.x + 20.0:
			var w := rng.randf_range(0.05, 0.09) * u
			var h := rng.randf_range(0.04, 0.085) * u
			_house(c, x, base_y + rng.randf_range(-0.008, 0.008) * u, w, h, col, rng)
			x += w * rng.randf_range(0.9, 1.2)

	# pohon latar depan
	var tcol := Color(0.025, 0.03, 0.07)
	for i in 5:
		_pine(c, rng.randf_range(-0.01, 0.2) * s.x, s.y + 0.02 * u, rng.randf_range(0.2, 0.34) * u, tcol)
	for i in 4:
		_pine(c, rng.randf_range(0.9, 1.02) * s.x, s.y + 0.02 * u, rng.randf_range(0.22, 0.36) * u, tcol)

	# vinyet: kiri (agar menu terbaca), atas, bawah
	c.draw_texture_rect(_vig_tex, Rect2(0, 0, s.x * 0.62, s.y), false)
	c.draw_texture_rect(_top_tex, Rect2(0, 0, s.x, u * 0.22), false)
	c.draw_texture_rect(_top_tex, Rect2(0, s.y, s.x, -u * 0.16), false)


# ---------------------------------------------------------------- efek bergerak (~30 fps)

func _draw_fx() -> void:
	var s := _fx.size
	if s.x < 8.0 or s.y < 8.0:
		return
	var u := s.y
	var t := _t

	# kabut tipis yang melintas
	var mw := s.x * 1.3
	for i in 3:
		var off := fposmod(t * (8.0 + 4.0 * float(i)) + float(i) * 300.0, mw)
		var my := s.y * (0.56 + 0.1 * float(i))
		_fx.draw_texture_rect(_mist_tex, Rect2(off - mw, my, mw, 0.14 * u), false)
		_fx.draw_texture_rect(_mist_tex, Rect2(off, my, mw, 0.14 * u), false)

	# bintang berkelip
	for st in _stars:
		var p: Vector2 = st[0]
		var sz: float = st[1]
		var ph: float = st[2]
		var tw := 0.5 + 0.5 * sin(t * (1.2 + sz * 0.5) + ph)
		var pos := Vector2(p.x * s.x, p.y * s.y)
		var col := Color(1.0, 0.97, 0.88, 0.25 + 0.7 * tw)
		_fx.draw_circle(pos, sz, col)
		if sz > 2.3:
			var l := sz * (3.0 + 3.0 * tw)
			_fx.draw_line(pos - Vector2(l, 0), pos + Vector2(l, 0), Color(col, col.a * 0.5), 1.0)
			_fx.draw_line(pos - Vector2(0, l), pos + Vector2(0, l), Color(col, col.a * 0.5), 1.0)

	# bintang jatuh
	if _shoot_t >= 0.0:
		var pr := _shoot_t / 0.9
		var dir := Vector2(-0.82, 0.57)
		var head := Vector2(_shoot_from.x * s.x, _shoot_from.y * s.y) + dir * (0.7 * u) * pr
		var tail_len := 0.2 * u * minf(pr * 3.0, 1.0)
		var fade := 1.0 - pr
		for i in 6:
			var a0 := head - dir * tail_len * float(i) / 6.0
			var a1 := head - dir * tail_len * float(i + 1) / 6.0
			_fx.draw_line(a0, a1, Color(1, 1, 0.95, fade * (1.0 - float(i) / 6.0)), 2.2)

	# jendela berkedip
	for w in _windows:
		var wp: Vector2 = w[0]
		var ww: float = w[1]
		var wh: float = w[2]
		var f := 0.5 + 0.5 * sin(t * 3.0 + float(w[3]))
		_fx.draw_rect(Rect2(wp.x - ww * 0.5, wp.y, ww, wh), Color(1.0, 0.95, 0.7, 0.45 * f))

	# air terjun mengalir + percikan
	for fl in _falls:
		var fx := float(fl[0])
		var y0 := float(fl[1])
		var y1 := float(fl[2])
		var fw := float(fl[3])
		for i in 5:
			var p := fposmod(t * 0.7 + float(i) * 0.2 + fx * 0.01, 1.0)
			_fx.draw_rect(Rect2(fx - fw * 0.5, lerpf(y0, y1, p), fw, 0.035 * u), Color(0.92, 0.98, 1.0, 0.55 * (1.0 - p * 0.5)))
		_fx.draw_circle(Vector2(fx, y1), 0.03 * u * (1.0 + 0.15 * sin(t * 2.0 + fx)), Color(0.85, 0.93, 1.0, 0.09))

	# kunang-kunang / bara naik
	for e in _embers:
		var ep := fposmod(t * float(e[1]) + float(e[2]), 1.0)
		var epos := Vector2(float(e[0]) * s.x + sin(t * 0.9 + float(e[2]) * 6.28) * 0.02 * u, lerpf(s.y * 0.97, s.y * 0.3, ep))
		var ea := sin(ep * PI) * (0.6 + 0.4 * sin(t * 4.0 + float(e[2]) * 20.0))
		_fx.draw_circle(epos, float(e[3]) * 3.2, Color(1.0, 0.7, 0.3, ea * 0.12))
		_fx.draw_circle(epos, float(e[3]), Color(1.0, 0.85, 0.5, ea * 0.9))


func _new_game() -> void:
	GameState.start_new_game()
	Flow.goto(Flow.SCENE_LOBBY, "Memasuki %s..." % GameState.WORLD_NAME)


func _continue() -> void:
	if GameState.continue_game():
		Flow.goto(Flow.SCENE_LOBBY, "Memasuki %s..." % GameState.WORLD_NAME)
	else:
		_msg.text = "Data tidak bisa dimuat."


func _import() -> void:
	var r := GameState.import_code(DisplayServer.clipboard_get())
	if r.get("banned", false):
		_msg.text = str(r["msg"])
	elif r["ok"]:
		_msg.text = str(r["msg"])
	else:
		_msg.text = "Gagal: %s (salin dulu kode cadangan, lalu ketuk Pulihkan)" % r["msg"]
	_build_menu()


func _bot() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	var dir := ""
	for x in OS.get_cmdline_user_args():
		if x.begins_with("--shots="):
			dir = x.substr(8)
	if dir != "":
		get_viewport().get_texture().get_image().save_png(dir + "/title.png")
	await Flow.goto(Flow.SCENE_LOBBY)
	print("CHECK title->lobby: ", get_tree().current_scene.name)
	get_tree().quit()
