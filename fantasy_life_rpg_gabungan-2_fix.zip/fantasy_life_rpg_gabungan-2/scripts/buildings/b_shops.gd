extends RefCounted
## Toko senjata & toko ramuan. Tidak bisa dimasuki; NPC pedagang berdiri di depan toko.

const FH := BCommon.FOUND_H
const T_PLASTER := MeshKit.T_PLASTER
const T_TIMBER := MeshKit.T_TIMBER
const T_WOOD := MeshKit.T_WOOD
const T_ROOF := MeshKit.T_ROOF
const T_METAL := MeshKit.T_METAL


static func build(b: Building) -> void:
	match b.kind:
		"weapon_shop":
			_weapon_shop(b)
		"item_shop":
			_item_shop(b)


# ---------------------------------------------------------------------
static func _weapon_shop(b: Building) -> void:
	var k := b.kit
	var w := 11.0
	var d := 8.0
	var h := 3.9
	var top := BCommon.shell(b, w, d, h, T_PLASTER, b.wall_color, 1, Pal.STONE_DARK)
	BCommon.gable(b, w, d, top, 2.9, b.roof_color, b.wall_color, 0.8)
	BCommon.front_door(b, -3.6, d, 1.5, 2.4)
	BCommon.front_windows(b, [-0.2], FH + 1.9, d, 1.6, 1.4, 0.75, Pal.RED, false)
	BCommon.sign_board(b, Vector3(-1.8, top - 0.85, d * 0.5 + 0.06), 5.2, 0.9, "TOKO SENJATA", Pal.WOOD, Color(1.0, 0.9, 0.62), 0.0125)
	# pedang bersilang di atas pintu
	Decor.sword(k, Vector3(-3.6 - 0.25, FH + 2.7, d * 0.5 + 0.12), 0.95, Color(0.86, 0.92, 1.0), Pal.GOLD, -38.0)
	Decor.sword(k, Vector3(-3.6 + 0.25, FH + 2.7, d * 0.5 + 0.12), 0.95, Color(0.86, 0.92, 1.0), Pal.GOLD, 38.0)
	# perisai di dinding
	Decor.shield(k, Vector3(4.4, FH + 1.9, d * 0.5 + 0.12), 0.55, Pal.BLUE)
	# bracket + papan gantung di kanan
	k.box(Vector3(w * 0.5 + 0.6, 3.0, d * 0.5 - 0.7), Vector3(1.4, 0.1, 0.1), T_WOOD, Pal.WOOD_DARK)
	k.box(Vector3(w * 0.5 + 0.9, 2.1, d * 0.5 - 0.7), Vector3(0.1, 1.9, 0.1), T_WOOD, Pal.WOOD_DARK)
	Decor.sword(k, Vector3(w * 0.5 + 1.15, 1.2, d * 0.5 - 0.5), 1.0, Color(0.9, 0.95, 1.0), Pal.GOLD, 0.0)
	# lapak depan + rak senjata
	Decor.stall(k, b.sink, Vector3(3.0, 0, d * 0.5 + 1.9), 0.0, Pal.RED, [Pal.BLUE, Pal.GOLD, Pal.RED, Pal.PURPLE])
	Decor.weapon_rack(k, b.sink, Vector3(-5.4, 0, d * 0.5 + 1.5), -20.0)
	Decor.training_dummy(k, b.sink, Vector3(-8.2, 0, d * 0.5 + 0.4), 20.0)
	BCommon.chimney_on(b, 3.6, -1.6, top, 3.2, true)
	Decor.barrel(k, b.sink, Vector3(w * 0.5 + 0.7, 0, 0.5))
	Decor.barrel(k, b.sink, Vector3(w * 0.5 + 0.7, 0, -0.5), Pal.WOOD_DARK)
	Decor.crate(k, b.sink, Vector3(w * 0.5 + 0.8, 0, -1.6), 0.8, 8.0)
	Decor.lantern(k, Vector3(-2.6, FH + 2.6, d * 0.5 + 0.3))
	Decor.lantern(k, Vector3(2.0 - 0.2, FH + 3.0, d * 0.5 + 0.3))
	b.footprint = 9.0
	b.height = top + 2.9


# ---------------------------------------------------------------------
static func _item_shop(b: Building) -> void:
	var k := b.kit
	var w := 10.0
	var d := 8.0
	var h := 3.6
	var top := BCommon.shell(b, w, d, h, T_PLASTER, b.wall_color, 1, Pal.STONE)
	BCommon.gable(b, w, d, top, 2.8, b.roof_color, b.wall_color, 0.8)
	BCommon.front_door(b, 3.2, d, 1.4, 2.3)
	BCommon.front_windows(b, [-0.2], FH + 1.9, d, 1.5, 1.4, 0.8, Pal.TEAL, true)
	BCommon.sign_board(b, Vector3(0.9, top - 0.85, d * 0.5 + 0.06), 5.0, 0.9, "RAMUAN FAJAR", Pal.WOOD, Color(0.82, 1.0, 0.9), 0.0125)
	# labu raksasa sebagai papan gantung
	k.box(Vector3(-w * 0.5 - 0.65, 3.4, d * 0.5 - 0.6), Vector3(1.3, 0.1, 0.1), T_WOOD, Pal.WOOD_DARK)
	k.box(Vector3(-w * 0.5 - 0.15, 2.3, d * 0.5 - 0.6), Vector3(0.1, 2.2, 0.1), T_WOOD, Pal.WOOD_DARK)
	k.blob(Vector3(-w * 0.5 - 1.05, 2.45, d * 0.5 - 0.6), 0.55, MeshKit.T_CRYSTAL, MeshKit.glow(Pal.TEAL, 0.8), 5, 10)
	k.cylinder(Vector3(-w * 0.5 - 1.05, 2.9, d * 0.5 - 0.6), 0.17, 0.15, 0.35, 8, MeshKit.T_CRYSTAL, MeshKit.glow(Pal.TEAL, 0.6), false, -1, true, 1.0)
	k.box(Vector3(-w * 0.5 - 1.05, 3.32, d * 0.5 - 0.6), Vector3(0.28, 0.2, 0.28), T_WOOD, Pal.WOOD_DARK)
	# lapak ramuan & rak
	Decor.stall(k, b.sink, Vector3(-2.2, 0, d * 0.5 + 1.9), 0.0, Pal.TEAL, [Pal.RED, Pal.BLUE, Pal.GREEN, Pal.GOLD])
	Decor.potion_shelf(k, b.sink, Vector3(-6.7, 0, d * 0.5 + 0.8), -90.0)
	Decor.barrel(k, b.sink, Vector3(w * 0.5 + 0.7, 0, 0.6), Pal.TEAL)
	Decor.crate(k, b.sink, Vector3(w * 0.5 + 0.7, 0, -0.4), 0.8, 14.0)
	Decor.sack(k, Vector3(w * 0.5 + 0.7, 0, -1.4), Color(0.8, 0.95, 0.7))
	Decor.flower_patch(k, Vector3(6.2, 0, d * 0.5 + 2.0), 1.4, 16)
	BCommon.chimney_on(b, -3.4, -1.6, top, 3.0)
	Decor.lantern(k, Vector3(2.0, FH + 2.3, d * 0.5 + 0.3))
	b.footprint = 8.5
	b.height = top + 2.8
