extends RefCounted
## Balai Serikat Bintang Fajar: aula utama + menara gerbang + dua sayap, papan quest di halaman depan.
## Asal lokal = tengah aula; depan menghadap +Z.

const FH := BCommon.FOUND_H
const T_PLASTER := MeshKit.T_PLASTER
const T_TIMBER := MeshKit.T_TIMBER
const T_WOOD := MeshKit.T_WOOD
const T_ROOF := MeshKit.T_ROOF
const T_METAL := MeshKit.T_METAL
const T_CLOTH := MeshKit.T_CLOTH
const T_EMBLEM := MeshKit.T_EMBLEM


static func build(b: Building) -> void:
	var k := b.kit
	var rc := b.roof_color
	var wc := b.wall_color
	# ---- aula utama
	k.push()
	k.move(0, 0, -2.5)
	var hall_top := BCommon.shell(b, 18.0, 10.0, 6.2, T_TIMBER, wc, 1, Pal.STONE_DARK)
	BCommon.gable(b, 18.0, 10.0, hall_top, 4.0, rc, wc, 0.9, T_TIMBER)
	BCommon.chimney_on(b, -5.0, -1.5, hall_top, 3.4)
	BCommon.chimney_on(b, 5.5, -1.0, hall_top, 3.0)
	k.pop()
	for sx in [-6.2, 6.2]:
		for wy in [FH + 1.8, FH + 4.3]:
			Decor.window(k, sx, wy, 2.5, 1.3, 1.5, 0.8, Pal.BLUE_DEEP, true)
	# ---- menara gerbang
	k.push()
	k.move(0, 0, 3.0)
	var tw := 7.0
	var ttop := BCommon.shell(b, tw, tw, 9.0, T_PLASTER, wc, 3, Pal.STONE_DARK)
	k.push()
	k.yaw(45.0)
	k.spire(Vector3(0, ttop + 0.1, 0), tw * 0.5 * 1.4142 + 0.55, 6.5, 4, T_ROOF, rc, 0.0)
	k.pop()
	# ring emas di bawah atap + bola puncak
	k.box(Vector3(0, ttop + 0.12, 0), Vector3(tw + 0.9, 0.3, tw + 0.9), T_WOOD, Pal.GOLD, T_WOOD, Pal.GOLD, 0.9)
	k.cylinder(Vector3(0, ttop + 6.4, 0), 0.07, 0.05, 1.3, 5, T_METAL, Pal.GOLD, true)
	k.blob(Vector3(0, ttop + 7.7, 0), 0.3, T_METAL, Pal.GOLD, 3, 6)
	# pintu besar berlengkung emas
	k.push()
	k.move(0, FH, 0)
	Decor.door(k, 0.0, tw * 0.5, 3.4, 4.2, false)
	k.pop()
	k.box(Vector3(0, FH + 4.55, tw * 0.5 + 0.16), Vector3(4.6, 0.4, 0.4), MeshKit.T_MARBLE, Color(0.82, 0.85, 0.93), MeshKit.T_MARBLE, Color(0.82, 0.85, 0.93), 0.9)
	for sx in [-1.0, 1.0]:
		k.box(Vector3(sx * 2.0, FH + 2.2, tw * 0.5 + 0.14), Vector3(0.4, 4.4, 0.36), MeshKit.T_MARBLE, Color(0.82, 0.85, 0.93), MeshKit.T_MARBLE, Color(0.82, 0.85, 0.93), 0.9)
	# lambang bintang fajar (bundar) di atas pintu
	k.quad_free(Vector3(-1.3, FH + 5.0, tw * 0.5 + 0.1), Vector3(1.3, FH + 5.0, tw * 0.5 + 0.1), Vector3(1.3, FH + 7.6, tw * 0.5 + 0.1), Vector3(-1.3, FH + 7.6, tw * 0.5 + 0.1),
		Vector3(0, 0, 1), T_EMBLEM, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE, Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0))
	# jendela tinggi di sisi menara
	for yy in [FH + 5.2, FH + 7.4]:
		for sx in [-2.4, 2.4]:
			Decor.window(k, sx, yy, tw * 0.5, 0.9, 1.3, 0.85, Pal.BLUE_DEEP, false)
	for sd in [-1.0, 1.0]:
		k.push()
		k.yaw(90.0 * sd)
		for yy in [FH + 2.2, FH + 5.6]:
			Decor.window(k, 0.0, yy, tw * 0.5, 1.0, 1.4, 0.8, Pal.BLUE_DEEP, true)
		k.pop()
	k.pop()
	# papan nama di bawah lambang? -> di atas pintu bawah, melintang
	var board := Vector3(0, FH + 8.3, 3.0 + tw * 0.5 + 0.12)
	k.box(board, Vector3(6.2, 0.9, 0.12), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	var lbl := b.add_label("SERIKAT BINTANG FAJAR", board + Vector3(0, 0, 0.09), 0.0105, Color(1.0, 0.9, 0.55))
	lbl.outline_size = 12
	# spanduk guild di kiri & kanan pintu (cutout, bergoyang)
	k.cut = true
	k.sway = 0.35
	for sx in [-3.0, 3.0]:
		var zf := 3.0 + tw * 0.5 + 0.1
		var bc := Pal.BLUE
		k.quad_free(Vector3(sx - 0.55, FH + 3.3, zf), Vector3(sx + 0.55, FH + 3.3, zf), Vector3(sx + 0.55, FH + 7.6, zf), Vector3(sx - 0.55, FH + 7.6, zf),
			Vector3(0, 0, 1), T_CLOTH, bc, bc, bc, bc, Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0))
		k.quad_free(Vector3(sx - 0.4, FH + 5.7, zf + 0.02), Vector3(sx + 0.4, FH + 5.7, zf + 0.02), Vector3(sx + 0.4, FH + 6.8, zf + 0.02), Vector3(sx - 0.4, FH + 6.8, zf + 0.02),
			Vector3(0, 0, 1), T_EMBLEM, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE, Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0))
	k.sway = 0.0
	k.cut = false
	# tangga lebar di depan menara
	k.stairs(Vector3(0, 0, 3.0 + tw * 0.5 + BCommon.FOUND_OUT + 1.6), 5.2, 1.6, FH, 4, MeshKit.T_MARBLE, Color(0.82, 0.85, 0.93))
	# ---- sayap kiri & kanan (atap tegak lurus)
	for side: float in [-1.0, 1.0]:
		var cx: float = side * 12.5
		k.push()
		k.move(cx, 0, -0.8)
		k.yaw(-90.0)
		var wtop := BCommon.shell(b, 8.5, 8.0, 4.6, T_PLASTER, wc, 1, Pal.STONE_DARK)
		BCommon.gable(b, 8.5, 8.0, wtop, 3.0, rc, wc, 0.7)
		k.pop()
		var fz := -0.8 + 4.25
		k.push()
		k.move(cx, 0, fz)
		Decor.window(k, 0.0, FH + 2.0, 0.0, 1.5, 1.6, 0.8, Pal.BLUE_DEEP, true)
		Decor.flower_box(k, 0.0, FH + 0.95, 0.0, 2.0)
		BCommon.round_window(k, Vector3(0, wtop + 1.1, 0.04), 0.5, 0.9)
		k.pop()
		k.push()
		k.move(cx, 0, -0.8)
		k.yaw(90.0 * side)
		Decor.window(k, -1.8, FH + 2.0, 4.0, 1.1, 1.4, 0.7)
		Decor.window(k, 1.8, FH + 2.0, 4.0, 1.1, 1.4, 0.7)
		k.pop()
		Decor.lamp_post(k, b.sink, Vector3(side * 5.4, 0, 8.8))
		Decor.banner_pole(k, b.sink, Vector3(side * 8.6, 0, 7.8), Pal.BLUE, 4.6)
		Decor.bush(k, b.sink, Vector3(side * 4.0, 0, 7.9), 0.8, Pal.GREEN)
		Decor.flower_patch(k, Vector3(side * 6.8, 0, 6.6), 1.2, 12)
	BCommon.chimney_on(b, 12.5, -3.0, 4.2, 3.0, true)
	# ---- papan quest di halaman depan (kanan)
	_quest_board(b, Vector3(10.5, 0, 9.6))
	Decor.barrel(k, b.sink, Vector3(-9.4, 0, 6.0))
	Decor.crate(k, b.sink, Vector3(-9.8, 0, 7.0), 0.8, 15.0)
	Decor.bench(k, b.sink, Vector3(-11.0, 0, 9.0), 0.0)
	b.footprint = 20.0
	b.height = ttop + 7.0


static func _quest_board(b: Building, pos: Vector3) -> void:
	var k := b.kit
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(-12.0)
	for sx in [-1.5, 1.5]:
		k.box_b(Vector3(sx, 0, 0), Vector3(0.2, 2.9, 0.2), T_WOOD, Pal.WOOD_DARK)
	k.box(Vector3(0, 1.85, 0.0), Vector3(3.5, 1.9, 0.14), T_WOOD, Pal.WOOD, T_WOOD, Pal.WOOD, 0.9)
	k.box(Vector3(0, 1.85, 0.0), Vector3(3.7, 2.1, 0.08), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	k.gable_roof(Vector3(0, 2.95, 0), 4.1, 1.0, 0.7, 0.2, T_ROOF, Pal.BLUE, T_PLASTER, Pal.CREAM, false)
	# kertas pengumuman
	var papers := [Vector3(-1.1, 2.1, 0), Vector3(-0.3, 1.5, 0), Vector3(0.6, 2.15, 0), Vector3(1.25, 1.45, 0), Vector3(-1.2, 1.25, 0), Vector3(0.1, 2.5, 0)]
	var i := 0
	for p in papers:
		var pc := Color(1.0, 0.96, 0.82) if i % 2 == 0 else Color(0.95, 0.9, 0.75)
		k.box(p, Vector3(0.6, 0.78, 0.02), T_CLOTH, pc, T_CLOTH, pc, 1.0)
		k.box(p + Vector3(0, 0.34, 0.02), Vector3(0.07, 0.07, 0.02), T_METAL, Pal.RED)
		i += 1
	b.sink.box(k.xf, Vector3(0, 1.5, 0), Vector3(3.7, 3.0, 0.5))
	k.box(Vector3(0, 0.62, 0.02), Vector3(2.5, 0.42, 0.12), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	var l := b.add_label("PAPAN QUEST", k.xf * Vector3(0, 0.62, 0.1), 0.008, Color(1.0, 0.92, 0.65))
	l.rotation_degrees = Vector3(0, -12.0, 0)
	l.outline_size = 8
	k.pop()
	b.add_interaction("quest_board", pos + Vector3(0.6, 0, 1.5), "quests", "Papan Quest", 2.8)
