extends RefCounted
## Landmark kota Aurelia: air mancur, portal petualangan, gerbang, tenda persiapan, altar cahaya, menara, bengkel, perpustakaan, kolam.
## Asal lokal = pusat jejak, depan menghadap +Z (kecuali dinyatakan lain).

const FH := BCommon.FOUND_H
const T_PLASTER := MeshKit.T_PLASTER
const T_TIMBER := MeshKit.T_TIMBER
const T_WOOD := MeshKit.T_WOOD
const T_ROOF := MeshKit.T_ROOF
const T_METAL := MeshKit.T_METAL
const T_BRICK := MeshKit.T_BRICK
const T_MARBLE := MeshKit.T_MARBLE
const T_WATER := MeshKit.T_WATER
const T_CRYSTAL := MeshKit.T_CRYSTAL
const T_STRIPE := MeshKit.T_STRIPE
const T_CLOTH := MeshKit.T_CLOTH
const T_EMBLEM := MeshKit.T_EMBLEM
const WHITE := Color(1, 1, 1)
const MARB := Color(0.82, 0.85, 0.93)


static func build(b: Building) -> void:
	match b.kind:
		"fountain":
			_fountain(b)
		"portal":
			_portal(b)
		"gate":
			_gate(b)
		"tent":
			_tent(b)
		"altar":
			_altar(b)
		"tower":
			_tower(b)
		"forge":
			_forge(b)
		"library":
			_library(b)
		"pond":
			_pond(b)


# =====================================================================
#  Efek sederhana (partikel CPU & cahaya)
# =====================================================================
static func _spray(b: Building, pos: Vector3, col: Color, amount: int, vel_min: float, vel_max: float, spread: float, grav: Vector3,
		life: float, size: float = 0.05, emission_r: float = 0.0) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.amount = amount
	p.lifetime = life
	p.position = pos
	p.direction = Vector3.UP
	p.spread = spread
	p.initial_velocity_min = vel_min
	p.initial_velocity_max = vel_max
	p.gravity = grav
	if emission_r > 0.0:
		p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
		p.emission_sphere_radius = emission_r
	var sm := SphereMesh.new()
	sm.radius = size
	sm.height = size * 2.0
	sm.radial_segments = 4
	sm.rings = 2
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = col
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.material = mat
	p.mesh = sm
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	b.extras.append(p)
	return p


static func _glow_light(b: Building, pos: Vector3, col: Color, energy: float, rng_m: float) -> OmniLight3D:
	var l := OmniLight3D.new()
	l.position = pos
	l.light_color = col
	l.light_energy = energy
	l.omni_range = rng_m
	l.shadow_enabled = false
	l.add_to_group("deco_light")
	b.extras.append(l)
	return l


static func _billboard_label(b: Building, text: String, pos: Vector3, col: Color, size: float = 0.012) -> Label3D:
	var l := b.add_label(text, pos, size, col)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = false
	l.fixed_size = false
	return l


# =====================================================================
#  Air mancur plaza (pusat kota)
# =====================================================================
static func _fountain(b: Building) -> void:
	var k := b.kit
	var seg := 20
	# bak luar: dinding luar + bibir + dinding dalam + air
	k.cylinder(Vector3.ZERO, 4.7, 4.6, 0.95, seg, T_MARBLE, MARB, false, -1, false, 0.8)
	k.ring(Vector3(0, 0.95, 0), 3.85, 4.6, seg, T_MARBLE, MARB)
	k.tube_inner(Vector3(0, 0.0, 0), 3.85, 0.95, seg, T_MARBLE, Color(0.85, 0.9, 1.0))
	k.disc(Vector3(0, 0.62, 0), 3.88, seg, T_WATER, Color(0.75, 0.92, 1.0))
	# hiasan batu emas pada bibir
	for i in 8:
		var a := i * TAU / 8.0
		k.box(Vector3(cos(a) * 4.25, 1.05, sin(a) * 4.25), Vector3(0.5, 0.22, 0.5), T_MARBLE, Pal.GOLD, T_MARBLE, Pal.GOLD, 0.9)
	# tingkat tengah
	k.cylinder(Vector3(0, 0.0, 0), 1.5, 1.1, 1.8, 12, T_MARBLE, MARB, true, T_MARBLE, false, 0.85)
	k.cylinder(Vector3(0, 1.75, 0), 0.65, 2.1, 0.55, 14, T_MARBLE, MARB, false, -1, true, 0.9)
	k.disc(Vector3(0, 2.28, 0), 2.05, 14, T_WATER, Color(0.75, 0.92, 1.0))
	k.cylinder(Vector3(0, 2.2, 0), 0.38, 0.3, 1.35, 8, T_MARBLE, MARB, true, T_MARBLE, true, 0.9)
	k.cylinder(Vector3(0, 3.5, 0), 0.32, 0.9, 0.35, 10, T_MARBLE, Pal.GOLD, false, -1, true, 0.9)
	k.crystal(Vector3(0, 3.85, 0), 0.48, 1.35, Color(0.55, 0.88, 1.0), 0.9, 6)
	# air pancur
	_spray(b, Vector3(0, 4.5, 0), Color(0.8, 0.95, 1.0, 0.75), 60, 1.6, 2.6, 28.0, Vector3(0, -7.0, 0), 1.7, 0.05)
	_spray(b, Vector3(0, 2.4, 0), Color(0.8, 0.95, 1.0, 0.65), 40, 1.2, 1.8, 70.0, Vector3(0, -6.0, 0), 1.3, 0.045, 1.4)
	_glow_light(b, Vector3(0, 4.6, 0), Color(0.6, 0.85, 1.0), 0.9, 10.0)
	b.sink.cyl(k.xf, Vector3.ZERO, 4.75, 1.1)
	b.footprint = 6.0
	b.height = 5.0
	b.can_fade = false


# =====================================================================
#  Portal petualangan
# =====================================================================
static func _portal(b: Building) -> void:
	var k := b.kit
	# panggung marmer bertingkat
	k.cylinder(Vector3.ZERO, 7.2, 7.0, 0.35, 20, T_MARBLE, Color(0.9, 0.93, 1.0), true, T_MARBLE, false, 0.85)
	k.cylinder(Vector3(0, 0.35, 0), 6.3, 6.1, 0.3, 20, T_MARBLE, MARB, true, T_MARBLE, false, 0.9)
	k.ring(Vector3(0, 0.66, 0), 2.0, 5.6, 20, MeshKit.T_PLAZA, Color(0.9, 0.95, 1.0))
	# lingkaran sihir di lantai (cincin emas tipis)
	k.ring(Vector3(0, 0.68, 0), 4.35, 4.55, 28, T_METAL, MeshKit.glow(Pal.GOLD, 0.9))
	k.ring(Vector3(0, 0.68, 0), 2.45, 2.6, 24, T_METAL, MeshKit.glow(Pal.SKY_BLUE, 0.9))
	# dua tiang pedestal penopang cincin
	for sx in [-1.0, 1.0]:
		k.cylinder(Vector3(sx * 3.6, 0.66, 0), 0.8, 0.6, 1.6, 8, T_MARBLE, MARB, true, T_MARBLE, false, 0.85)
		k.box(Vector3(sx * 3.6, 2.35, 0), Vector3(1.3, 0.3, 1.3), T_MARBLE, Pal.GOLD, T_MARBLE, Pal.GOLD, 0.9)
		b.sink.cyl(k.xf, Vector3(sx * 3.6, 0, 0), 0.9, 2.5)
	# cincin raksasa (emas) + cincin dalam bercahaya
	k.torus_xy(Vector3(0, 4.25, 0), 3.6, 0.34, 32, 8, T_METAL, Color(1.0, 0.86, 0.45))
	k.torus_xy(Vector3(0, 4.25, 0), 3.15, 0.14, 32, 6, T_CRYSTAL, MeshKit.glow(Pal.SKY_BLUE, 0.95))
	# rune pada cincin (kristal kecil di 8 titik)
	for i in 8:
		var a := i * TAU / 8.0 + PI / 8.0
		k.crystal(Vector3(cos(a) * 3.6, 4.25 + sin(a) * 3.6, 0.0), 0.16, 0.42, Pal.PURPLE if i % 2 == 0 else Pal.SKY_BLUE, 0.95, 5, rad_to_deg(a) - 90.0)
	# kristal puncak
	k.crystal(Vector3(0, 7.85, 0), 0.3, 0.9, Pal.SKY_BLUE, 0.95, 5)
	# enam pilar pendek berkristal di sekeliling panggung
	for i in 6:
		var a := i * TAU / 6.0 + PI / 6.0
		var p := Vector3(cos(a) * 6.0, 0.0, sin(a) * 6.0)
		if true:
			k.cylinder(p + Vector3(0, 0.62, 0), 0.34, 0.28, 1.4, 6, T_MARBLE, MARB, true, T_MARBLE, false, 0.85)
			k.crystal(p + Vector3(0, 2.2, 0), 0.16, 0.55, Pal.SKY_BLUE if i % 2 == 0 else Pal.PURPLE, 0.95, 5)
			b.sink.cyl(k.xf, p + Vector3(0, 0.0, 0), 0.4, 2.0)
	# pusaran portal (QuadMesh + shader)
	var q := QuadMesh.new()
	q.size = Vector2(7.1, 7.1)
	var mi := MeshInstance3D.new()
	mi.mesh = q
	var m := ShaderMaterial.new()
	m.shader = load("res://shaders/portal.gdshader")
	mi.material_override = m
	mi.position = Vector3(0, 4.25, 0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	b.extras.append(mi)
	_glow_light(b, Vector3(0, 4.25, 1.2), Color(0.55, 0.65, 1.0), 1.1, 11.0)
	_spray(b, Vector3(0, 0.9, 0), Color(0.7, 0.85, 1.0, 0.8), 40, 0.6, 1.4, 40.0, Vector3(0, 0.3, 0), 2.4, 0.045, 3.0)
	_billboard_label(b, "PORTAL PETUALANGAN", Vector3(0, 8.9, 0), Color(0.85, 0.92, 1.0), 0.013)
	b.add_interaction("portal", Vector3(0, 0, 3.6), "adventure", "Masuk Portal Petualangan", 4.0)
	b.footprint = 9.0
	b.height = 9.0
	b.can_fade = false


# =====================================================================
#  Gerbang kota (selatan). Local +Z = sisi luar kota.
# =====================================================================
static func _gate(b: Building) -> void:
	var k := b.kit
	var tx := 6.6
	var tw := 5.2
	for sx in [-1.0, 1.0]:
		k.push()
		k.move(sx * tx, 0, 0)
		# menara persegi dari batu
		k.box_b(Vector3.ZERO, Vector3(tw + 0.7, 0.8, tw + 0.7), T_BRICK, Pal.STONE_DARK, T_BRICK, Pal.STONE, 0.85)
		k.box_b(Vector3(0, 0.8, 0), Vector3(tw, 8.0, tw), T_BRICK, Pal.STONE, T_BRICK, Pal.STONE, 0.8)
		k.box(Vector3(0, 8.9, 0), Vector3(tw + 0.9, 0.55, tw + 0.9), T_BRICK, Pal.STONE_DARK, T_BRICK, Pal.STONE, 0.9)
		# gerigi
		for i in 4:
			for j in [-1.0, 1.0]:
				k.box(Vector3(-1.8 + i * 1.2, 9.4, j * (tw + 0.9) * 0.5 - j * 0.15), Vector3(0.7, 0.55, 0.45), T_BRICK, Pal.STONE, T_BRICK, Pal.STONE, 0.9)
				k.box(Vector3(j * (tw + 0.9) * 0.5 - j * 0.15, 9.4, -1.8 + i * 1.2), Vector3(0.45, 0.55, 0.7), T_BRICK, Pal.STONE, T_BRICK, Pal.STONE, 0.9)
		k.push()
		k.yaw(45.0)
		k.spire(Vector3(0, 9.1, 0), tw * 0.5 * 1.4142 + 0.2, 4.6, 4, T_ROOF, Pal.BLUE, 0.0)
		k.pop()
		k.blob(Vector3(0, 13.8, 0), 0.25, T_METAL, Pal.GOLD, 3, 6)
		# celah panah + jendela
		for face in [0, 1, 2, 3]:
			k.push()
			k.yaw(90.0 * face)
			Decor.window(k, 0.0, 5.4, tw * 0.5, 0.7, 1.4, 0.7, Pal.BLUE_DEEP, false)
			k.pop()
		b.sink.box(k.xf, Vector3(0, 4.5, 0), Vector3(tw + 0.7, 9.0, tw + 0.7))
		k.pop()
	# lengkung penghubung (atas jalan masuk)
	var gap := tx * 2.0 - tw
	k.box(Vector3(0, 7.2, 0), Vector3(gap + 0.4, 1.8, tw * 0.9), T_BRICK, Pal.STONE, T_BRICK, Pal.STONE, 0.85)
	k.box(Vector3(0, 6.2, tw * 0.45), Vector3(gap + 0.4, 0.5, 0.5), T_BRICK, Pal.STONE_DARK, T_BRICK, Pal.STONE, 0.9)
	k.box(Vector3(0, 6.2, -tw * 0.45), Vector3(gap + 0.4, 0.5, 0.5), T_BRICK, Pal.STONE_DARK, T_BRICK, Pal.STONE, 0.9)
	for i in 5:
		k.box(Vector3(-2.2 + i * 1.1, 8.5, 0), Vector3(0.7, 0.55, 0.5), T_BRICK, Pal.STONE, T_BRICK, Pal.STONE, 0.9)
	k.box(Vector3(0, 6.7, tw * 0.45 + 0.28), Vector3(5.0, 0.8, 0.1), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	var l := b.add_label("GERBANG AURELIA", Vector3(0, 6.7, tw * 0.45 + 0.36), 0.0105, Color(1.0, 0.9, 0.55))
	l.outline_size = 10
	var l2 := b.add_label("GERBANG AURELIA", Vector3(0, 6.7, -tw * 0.45 - 0.36), 0.0105, Color(1.0, 0.9, 0.55), Vector3(0, 180, 0))
	l2.outline_size = 10
	# kisi besi terangkat di bawah lengkung (jeruji)
	for i in 9:
		k.box(Vector3(-3.2 + i * 0.8, 5.75, 0.0), Vector3(0.07, 0.9, 0.07), T_METAL, Pal.IRON, T_METAL, Pal.IRON, 1.0)
	# daun pintu kayu terbuka ke sisi dalam
	for sx in [-1.0, 1.0]:
		k.push()
		k.move(sx * (gap * 0.5), 0, -0.6)
		k.yaw(-sx * 72.0)
		k.box(Vector3(sx * -1.9, 2.5, 0), Vector3(3.8, 5.0, 0.28), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD, 0.9)
		for yy in [1.0, 4.0]:
			k.box(Vector3(sx * -1.9, yy, 0.02), Vector3(3.9, 0.22, 0.34), T_METAL, Pal.IRON, T_METAL, Pal.IRON, 1.0)
		k.pop()
	# spanduk dua sisi
	for sx in [-1.0, 1.0]:
		Decor.banner_pole(k, b.sink, Vector3(sx * 3.2, 0, 3.6), Pal.BLUE, 4.6, 0.0)
		Decor.lamp_post(k, b.sink, Vector3(sx * 3.0, 0, -3.4), 3.6)
		Decor.banner_pole(k, b.sink, Vector3(sx * 3.2, 0, -3.8), Pal.BLUE, 4.6, 180.0)
	b.add_interaction("gate", Vector3(0, 0, -1.5), "adventure", "Keluar Gerbang (Petualangan)", 4.2)
	b.footprint = 11.0
	b.height = 14.0
	b.can_fade = false


# =====================================================================
#  Tenda / paviliun persiapan party
# =====================================================================
static func _tent(b: Building) -> void:
	var k := b.kit
	# lantai papan
	k.cylinder(Vector3.ZERO, 6.4, 6.3, 0.2, 16, T_WOOD, Pal.WOOD, true, T_WOOD, false, 0.85)
	# 6 tiang + kanopi kerucut belang biru-putih
	var n := 6
	for i in n:
		var a := i * TAU / n
		var p := Vector3(cos(a) * 5.2, 0, sin(a) * 5.2)
		k.box_b(p + Vector3(0, 0.2, 0), Vector3(0.22, 3.6, 0.22), T_WOOD, Pal.WOOD_DARK)
		Decor.lantern(k, p + Vector3(0, 3.3, 0) + Vector3(cos(a), 0, sin(a)) * -0.35)
		b.sink.cyl(k.xf, p, 0.22, 3.6)
	k.cylinder(Vector3(0, 3.7, 0), 6.0, 0.9, 1.5, 12, T_STRIPE, Color(0.55, 0.75, 1.0), false, -1, false, 0.9)
	k.cylinder(Vector3(0, 5.15, 0), 0.9, 0.0, 1.5, 12, T_STRIPE, Color(0.75, 0.88, 1.0), false, -1, false, 0.95)
	k.cylinder(Vector3(0, 6.6, 0), 0.06, 0.04, 1.0, 5, T_METAL, Pal.GOLD, true)
	# penutup bawah kanopi (agar tidak tembus pandang dari bawah)
	k.disc(Vector3(0, 3.68, 0), 5.9, 12, T_CLOTH, Color(0.85, 0.92, 1.0))
	# jumbai kain di tepi kanopi (cutout bergoyang)
	k.cut = true
	k.sway = 0.4
	for i in 12:
		var a := (i + 0.5) * TAU / 12.0
		var p := Vector3(cos(a) * 5.9, 3.7, sin(a) * 5.9)
		var tangent := Vector3(-sin(a), 0, cos(a)) * 0.85
		var cc := Pal.GOLD if i % 2 == 0 else Pal.BLUE
		k.quad_free(p - tangent, p + tangent, p + tangent + Vector3(0, -0.7, 0), p - tangent + Vector3(0, -0.7, 0), Vector3(cos(a), 0, sin(a)), T_CLOTH, cc, cc, cc, cc,
			Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0))
	k.sway = 0.0
	k.cut = false
	# meja strategi bundar + peta
	k.cylinder(Vector3(0, 0.2, 0), 1.7, 1.5, 0.95, 12, T_WOOD, Pal.WOOD, true, T_WOOD, false, 0.85)
	k.disc(Vector3(0, 1.17, 0), 1.45, 12, T_CLOTH, Color(1.0, 0.95, 0.78))
	k.ring(Vector3(0, 1.18, 0), 0.5, 0.58, 14, T_EMBLEM, Color(1.0, 0.9, 0.6))
	k.blob(Vector3(0.4, 1.35, 0.1), 0.18, T_METAL, Pal.RED, 3, 6)
	k.blob(Vector3(-0.5, 1.35, -0.2), 0.18, T_METAL, Pal.BLUE, 3, 6)
	b.sink.cyl(k.xf, Vector3(0, 0.2, 0), 1.75, 1.0)
	# bangku bundar di sekitar meja
	for i in 4:
		var a := i * TAU / 4.0 + PI / 4.0
		k.cylinder(Vector3(cos(a) * 2.6, 0.2, sin(a) * 2.6), 0.4, 0.36, 0.5, 8, T_WOOD, Pal.WOOD_DARK, true, T_WOOD, false, 0.85)
	# rak senjata + perlengkapan
	Decor.weapon_rack(k, b.sink, Vector3(-3.6, 0.2, -3.2), 35.0)
	Decor.weapon_rack(k, b.sink, Vector3(3.6, 0.2, -3.2), -35.0)
	Decor.crate(k, b.sink, Vector3(0.0, 0.2, -4.4), 0.9, 10.0)
	Decor.barrel(k, b.sink, Vector3(1.2, 0.2, -4.5))
	Decor.banner_pole(k, b.sink, Vector3(-6.8, 0, 2.0), Pal.BLUE, 4.6, 0.0)
	Decor.banner_pole(k, b.sink, Vector3(6.8, 0, 2.0), Pal.BLUE, 4.6, 0.0)
	_billboard_label(b, "AREA PERSIAPAN", Vector3(0, 7.8, 0), Color(0.85, 0.95, 1.0), 0.013)
	b.add_interaction("party_table", Vector3(0, 0, 2.7), "party", "Meja Strategi - Atur Party", 3.2)
	b.footprint = 8.0
	b.height = 7.0
	b.can_fade = false


# =====================================================================
#  Altar Bintang (pemanggilan / gacha)
# =====================================================================
static func _altar(b: Building) -> void:
	var k := b.kit
	k.cylinder(Vector3.ZERO, 4.0, 3.8, 0.3, 14, T_MARBLE, MARB, true, T_MARBLE, false, 0.85)
	k.cylinder(Vector3(0, 0.3, 0), 3.2, 3.0, 0.3, 14, T_MARBLE, MARB, true, T_MARBLE, false, 0.9)
	k.ring(Vector3(0, 0.62, 0), 2.1, 2.3, 24, T_METAL, MeshKit.glow(Pal.GOLD, 0.9))
	# empat pilar dengan lengkung kecil
	for i in 4:
		var a := i * TAU / 4.0 + PI / 4.0
		var p := Vector3(cos(a) * 2.7, 0.0, sin(a) * 2.7)
		k.cylinder(p + Vector3(0, 0.6, 0), 0.3, 0.26, 3.2, 8, T_MARBLE, MARB, true, T_MARBLE, false, 0.85)
		k.box(p + Vector3(0, 3.9, 0), Vector3(0.7, 0.25, 0.7), T_MARBLE, Pal.GOLD, T_MARBLE, Pal.GOLD, 0.9)
		k.crystal(p + Vector3(0, 4.05, 0), 0.14, 0.42, Pal.GOLD, 0.9, 5)
		b.sink.cyl(k.xf, p, 0.36, 3.8)
	# lengkung emas di atas
	k.torus_xy(Vector3(0, 3.95, 0), 2.7, 0.07, 24, 5, T_METAL, Pal.GOLD, 0.0, PI)
	k.push()
	k.yaw(90.0)
	k.torus_xy(Vector3(0, 3.95, 0), 2.7, 0.07, 24, 5, T_METAL, Pal.GOLD, 0.0, PI)
	k.pop()
	# mimbar + kristal melayang
	k.cylinder(Vector3(0, 0.6, 0), 0.9, 0.6, 1.0, 8, T_MARBLE, MARB, true, T_MARBLE, false, 0.85)
	k.cylinder(Vector3(0, 1.6, 0), 0.7, 0.8, 0.12, 8, T_METAL, Pal.GOLD, true, T_METAL, false, 0.9)
	k.crystal(Vector3(0, 2.5, 0), 0.5, 1.3, Color(1.0, 0.95, 0.65), 1.0, 6)
	b.sink.cyl(k.xf, Vector3(0, 0.0, 0), 1.0, 1.7)
	_spray(b, Vector3(0, 1.0, 0), Color(1.0, 0.92, 0.55, 0.85), 36, 0.3, 0.8, 30.0, Vector3(0, 0.5, 0), 3.0, 0.04, 2.2)
	_glow_light(b, Vector3(0, 2.8, 0), Color(1.0, 0.92, 0.6), 1.1, 9.0)
	_billboard_label(b, "ALTAR BINTANG", Vector3(0, 5.6, 0), Color(1.0, 0.95, 0.7), 0.012)
	b.add_interaction("altar", Vector3(0, 0, 2.4), "gacha", "Panggil di Altar Bintang", 3.2)
	b.footprint = 5.5
	b.height = 5.0
	b.can_fade = false


# =====================================================================
#  Menara penyihir (landmark tinggi)
# =====================================================================
static func _tower(b: Building) -> void:
	var k := b.kit
	var r := 4.2
	var h1 := 8.0
	var apothem := r * cos(PI / 8.0)
	k.push()
	k.yaw(22.5)
	k.cylinder(Vector3.ZERO, r + 0.5, r + 0.45, 0.9, 8, T_BRICK, Pal.STONE_DARK, true, T_BRICK, false, 0.85)
	k.cylinder(Vector3(0, 0.9, 0), r, r * 0.86, h1, 8, T_PLASTER, Color(0.92, 0.9, 1.0), true, T_PLASTER, false, 0.8)
	# balkon + lantai atas lebih lebar
	k.cylinder(Vector3(0, 0.9 + h1, 0), r * 0.86, r * 1.2, 0.5, 8, T_WOOD, Pal.WOOD_DARK, true, T_WOOD, false, 0.9)
	k.cylinder(Vector3(0, 1.4 + h1, 0), r * 1.1, r * 1.1, 3.6, 8, T_TIMBER, Color(0.95, 0.93, 1.0), true, T_PLASTER, false, 0.8)
	k.cylinder(Vector3(0, 1.4 + h1 + 3.6, 0), r * 1.1, r * 1.3, 0.3, 8, T_WOOD, Pal.WOOD_DARK, true, T_WOOD, false, 0.9)
	k.spire(Vector3(0, 1.7 + h1 + 3.6, 0), r * 1.25, 6.0, 8, T_ROOF, Pal.PURPLE, 0.9)
	k.pop()
	var topy := 1.7 + h1 + 3.6
	k.cylinder(Vector3(0, topy + 5.9, 0), 0.07, 0.05, 1.2, 5, T_METAL, Pal.GOLD, true)
	k.crystal(Vector3(0, topy + 7.1, 0), 0.4, 1.2, Color(0.8, 0.6, 1.0), 1.0, 6)
	b.sink.cyl(k.xf, Vector3.ZERO, r + 0.6, 12.0)
	# pintu + jendela
	k.push()
	k.move(0, 0.9, 0)
	Decor.door(k, 0.0, apothem, 1.5, 2.5, false)
	k.pop()
	k.box(Vector3(0, 0.1, apothem + 0.7), Vector3(2.8, 0.2, 1.2), T_BRICK, Pal.STONE_DARK, T_BRICK, Pal.STONE, 0.85)
	for j in range(1, 8):
		k.push()
		k.yaw(-45.0 * j)
		Decor.window(k, 0.0, 4.6, apothem * 0.93, 0.9, 1.4, 0.85, Pal.PURPLE, false)
		Decor.window(k, 0.0, 9.6, apothem * 1.1 - 0.0, 1.0, 1.5, 0.95, Pal.PURPLE, true)
		k.pop()
	Decor.window(k, 0.0, 4.6, apothem * 0.93, 0.9, 1.4, 0.85, Pal.PURPLE, false)
	Decor.window(k, 0.0, 9.6, apothem * 1.1, 1.0, 1.5, 0.95, Pal.PURPLE, true)
	# jam bulat besar di depan atas pintu
	k.quad_free(Vector3(-1.1, 6.2, apothem * 0.93 + 0.12), Vector3(1.1, 6.2, apothem * 0.93 + 0.12), Vector3(1.1, 8.4, apothem * 0.93 + 0.12), Vector3(-1.1, 8.4, apothem * 0.93 + 0.12),
		Vector3(0, 0, 1), T_EMBLEM, WHITE, WHITE, WHITE, WHITE, Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0))
	_glow_light(b, Vector3(0, topy + 7.0, 0), Color(0.8, 0.6, 1.0), 0.8, 12.0)
	Decor.lamp_post(k, b.sink, Vector3(2.8, 0, apothem + 1.6))
	Decor.lamp_post(k, b.sink, Vector3(-2.8, 0, apothem + 1.6))
	b.footprint = 7.0
	b.height = topy + 7.0


# =====================================================================
#  Bengkel pandai besi (setengah terbuka)
# =====================================================================
static func _forge(b: Building) -> void:
	var k := b.kit
	var w := 10.0
	var d := 7.5
	# lantai batu + dinding belakang & samping
	k.box_b(Vector3.ZERO, Vector3(w + 0.4, 0.3, d + 0.4), T_BRICK, Pal.STONE_DARK, T_BRICK, Pal.STONE, 0.85)
	k.box_b(Vector3(0, 0.3, -d * 0.5 + 0.3), Vector3(w, 4.0, 0.6), T_BRICK, Pal.STONE, T_BRICK, Pal.STONE, 0.8)
	for sx in [-1.0, 1.0]:
		k.box_b(Vector3(sx * (w * 0.5 - 0.3), 0.3, 0), Vector3(0.6, 4.0, d), T_BRICK, Pal.STONE, T_BRICK, Pal.STONE, 0.8)
	b.sink.box(k.xf, Vector3(0, 2.3, -d * 0.5 + 0.3), Vector3(w, 4.6, 0.7))
	for sx in [-1.0, 1.0]:
		b.sink.box(k.xf, Vector3(sx * (w * 0.5 - 0.3), 2.3, 0), Vector3(0.7, 4.6, d))
	# tiang depan + atap pelana kayu
	for sx in [-1.0, 1.0]:
		k.box_b(Vector3(sx * (w * 0.5 - 0.2), 0.3, d * 0.5 - 0.3), Vector3(0.34, 4.3, 0.34), T_WOOD, Pal.WOOD_DARK)
		b.sink.cyl(k.xf, Vector3(sx * (w * 0.5 - 0.2), 0, d * 0.5 - 0.3), 0.3, 4.4)
	k.box(Vector3(0, 4.45, d * 0.5 - 0.3), Vector3(w + 0.2, 0.3, 0.4), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	k.gable_roof(Vector3(0, 4.55, 0), w, d, 2.4, 0.8, T_ROOF, b.roof_color.darkened(0.15), T_BRICK, Pal.STONE)
	# tungku dengan cerobong besar
	k.box_b(Vector3(-2.6, 0.3, -d * 0.5 + 1.6), Vector3(2.6, 1.5, 2.0), T_BRICK, Pal.STONE_DARK, T_BRICK, Pal.STONE_DARK, 0.85)
	k.box(Vector3(-2.6, 1.0, -d * 0.5 + 2.62), Vector3(1.4, 0.8, 0.06), T_METAL, MeshKit.glow(Color(1.0, 0.5, 0.15), 1.0))
	k.box_b(Vector3(-2.6, 1.8, -d * 0.5 + 1.2), Vector3(1.5, 6.6, 1.4), T_BRICK, Pal.STONE, T_BRICK, Pal.STONE, 0.85)
	k.box(Vector3(-2.6, 8.5, -d * 0.5 + 1.2), Vector3(1.9, 0.3, 1.9), T_BRICK, Pal.STONE_DARK, T_BRICK, Pal.STONE_DARK, 0.9)
	b.sink.box(k.xf, Vector3(-2.6, 0.9, -d * 0.5 + 1.6), Vector3(2.7, 1.8, 2.1))
	_spray(b, Vector3(-2.6, 8.7, -d * 0.5 + 1.2), Color(0.85, 0.85, 0.9, 0.4), 18, 0.8, 1.4, 14.0, Vector3(0.1, 0.4, 0), 3.0, 0.14)
	_glow_light(b, Vector3(-2.6, 1.3, -d * 0.5 + 2.8), Color(1.0, 0.6, 0.25), 0.9, 6.5)
	# landasan, batu asah, palung air, rak
	Decor.anvil(k, b.sink, Vector3(1.0, 0.3, 0.6), 90.0)
	k.cylinder(Vector3(3.4, 0.3, -1.0), 0.55, 0.5, 0.15, 8, T_METAL, Pal.IRON, true)
	k.push()
	k.move(3.4, 0.9, -1.0)
	k.roll(90.0)
	k.cylinder(Vector3(0, -0.12, 0), 0.5, 0.5, 0.24, 12, MeshKit.T_BRICK, Pal.STONE_DARK, true)
	k.pop()
	k.box(Vector3(3.4, 0.55, -1.0), Vector3(0.9, 0.5, 0.35), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	b.sink.cyl(k.xf, Vector3(3.4, 0.3, -1.0), 0.8, 1.2)
	k.box_b(Vector3(0.6, 0.3, -2.4), Vector3(2.2, 0.7, 0.9), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.85)
	k.disc(Vector3(0.6, 1.01, -2.4), 0.9, 8, T_WATER, Color(0.7, 0.88, 1.0))
	b.sink.box(k.xf, Vector3(0.6, 0.65, -2.4), Vector3(2.2, 0.7, 0.9))
	Decor.weapon_rack(k, b.sink, Vector3(3.6, 0.3, -d * 0.5 + 1.0), 0.0)
	Decor.barrel(k, b.sink, Vector3(-w * 0.5 + 1.2, 0.3, 0.6))
	Decor.sack(k, Vector3(-w * 0.5 + 1.2, 0.3, 1.6), Color(0.35, 0.32, 0.36))
	Decor.sack(k, Vector3(-w * 0.5 + 1.9, 0.3, 1.9), Color(0.35, 0.32, 0.36))
	# papan nama di bibir atap
	k.box(Vector3(0, 3.9, d * 0.5 - 0.3), Vector3(5.6, 0.8, 0.12), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	var l := b.add_label("DENTANG BESI", Vector3(0, 3.9, d * 0.5 - 0.2), 0.0105, Color(1.0, 0.85, 0.55))
	l.outline_size = 10
	Decor.lantern(k, Vector3(-3.6, 3.4, d * 0.5 - 0.2))
	Decor.lantern(k, Vector3(3.6, 3.4, d * 0.5 - 0.2))
	b.footprint = 8.0
	b.height = 8.6


# =====================================================================
#  Perpustakaan (pustakawan = NPC info)
# =====================================================================
static func _library(b: Building) -> void:
	var k := b.kit
	var w := 13.0
	var d := 9.0
	var h := 5.4
	var top := BCommon.shell(b, w, d, h, MeshKit.T_PLASTER, Color(0.95, 0.93, 1.0), 1, Pal.STONE_DARK)
	BCommon.gable(b, w, d, top, 3.4, Pal.PURPLE, Color(0.95, 0.93, 1.0), 0.9)
	# serambi pilar di depan
	for i in 4:
		var x := -4.5 + i * 3.0
		k.cylinder(Vector3(x, FH, d * 0.5 + 1.2), 0.38, 0.34, h - 0.3, 8, T_MARBLE, MARB, true, T_MARBLE, false, 0.85)
		b.sink.cyl(k.xf, Vector3(x, 0, d * 0.5 + 1.2), 0.42, h)
	k.box(Vector3(0, top - 0.15, d * 0.5 + 1.2), Vector3(w - 1.4, 0.45, 1.0), T_MARBLE, MARB, T_MARBLE, MARB, 0.9)
	k.box(Vector3(0, top - 0.7, d * 0.5 + 0.7), Vector3(w - 1.4, 0.25, 0.6), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	k.stairs(Vector3(0, 0, d * 0.5 + 1.2 + FH + 2.0), 6.0, 1.4, FH, 3, T_MARBLE, MARB)
	BCommon.front_door(b, 0.0, d, 1.8, 2.8)
	BCommon.front_windows(b, [-3.8, 3.8], FH + 2.1, d, 1.5, 2.0, 0.8, Pal.PURPLE, false)
	BCommon.side_windows(b, w, 1.0, [-2.0, 2.0], FH + 2.1, 1.2, 1.8)
	BCommon.side_windows(b, w, -1.0, [-2.0, 2.0], FH + 2.1, 1.2, 1.8)
	# kubah kecil di atas bubungan
	k.blob(Vector3(0, top + 3.6, 0), 1.9, T_METAL, Pal.PURPLE, 5, 10, 0.8, 0.4)
	k.cylinder(Vector3(0, top + 3.1, 0), 1.6, 1.6, 0.8, 10, T_PLASTER, Color(0.95, 0.93, 1.0), false, -1, false, 0.9)
	k.blob(Vector3(0, top + 5.2, 0), 0.22, T_METAL, Pal.GOLD, 3, 6)
	var board_c := Vector3(0, top + 0.1, d * 0.5 + 1.75)
	k.box(board_c, Vector3(6.0, 0.8, 0.12), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	var l := b.add_label("PERPUSTAKAAN AURELIA", board_c + Vector3(0, 0, 0.09), 0.0105, Color(0.9, 0.85, 1.0))
	l.outline_size = 10
	# tumpukan buku & bangku
	for i in 5:
		k.box(Vector3(w * 0.5 + 0.8, 0.12 + i * 0.2, 0.5 + 0.05 * (i % 2)), Vector3(0.9, 0.2, 0.6), T_CLOTH, [Pal.RED, Pal.BLUE, Pal.GREEN, Pal.GOLD, Pal.PURPLE][i], T_CLOTH, [Pal.RED, Pal.BLUE, Pal.GREEN, Pal.GOLD, Pal.PURPLE][i], 0.9)
	Decor.bench(k, b.sink, Vector3(-w * 0.5 - 0.7, 0, 1.0), 90.0)
	Decor.lantern(k, Vector3(-1.4, FH + 2.6, d * 0.5 + 0.3))
	Decor.lantern(k, Vector3(1.4, FH + 2.6, d * 0.5 + 0.3))
	Decor.flower_patch(k, Vector3(-6.0, 0, d * 0.5 + 3.0), 1.5, 14)
	b.footprint = 9.5
	b.height = top + 5.0


# =====================================================================
#  Kolam taman
# =====================================================================
static func _pond(b: Building) -> void:
	var k := b.kit
	var seg := 18
	k.cylinder(Vector3.ZERO, 5.4, 5.2, 0.5, seg, T_BRICK, Pal.STONE, false, -1, false, 0.85)
	k.ring(Vector3(0, 0.5, 0), 4.7, 5.4, seg, T_BRICK, Pal.STONE)
	k.tube_inner(Vector3.ZERO, 4.7, 0.5, seg, T_BRICK, Pal.STONE_DARK)
	k.disc(Vector3(0, 0.34, 0), 4.72, seg, T_WATER, Color(0.65, 0.88, 0.95))
	b.sink.cyl(k.xf, Vector3.ZERO, 5.45, 0.6)
	# teratai (cutout) + batu + alang
	k.cut = true
	for i in 9:
		var a := k.rng.randf() * TAU
		var dd := sqrt(k.rng.randf()) * 3.6
		var p := Vector3(cos(a) * dd, 0.36, sin(a) * dd)
		# daun datar teratai
		var s := 0.7 + k.rng.randf() * 0.4
		k.quad_free(p + Vector3(-s, 0, s), p + Vector3(s, 0, s), p + Vector3(s, 0, -s), p + Vector3(-s, 0, -s), Vector3.UP, MeshKit.T_LEAVES,
			Color(0.55, 0.95, 0.55), Color(0.55, 0.95, 0.55), Color(0.55, 0.95, 0.55), Color(0.55, 0.95, 0.55), Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0))
		if i % 3 == 0:
			k.cross_quads(p + Vector3(0, 0.02, 0), 0.4, 0.4, MeshKit.T_FLOWER, Pal.PINK, 0.0, k.rng.randf() * 90.0)
	for i in 14:
		var a := i * TAU / 14.0 + k.rng.randf() * 0.2
		k.cross_quads(Vector3(cos(a) * 5.7, 0, sin(a) * 5.7), 0.9, 1.0, MeshKit.T_TUFT, Color(0.75, 1.0, 0.75), 0.9, k.rng.randf() * 90.0)
	k.cut = false
	Decor.rock(k, b.sink, Vector3(4.2, 0.2, -2.2), 0.8)
	Decor.rock(k, b.sink, Vector3(-3.6, 0.2, 3.4), 0.6)
	# batu hias + kristal kecil di tengah kolam
	k.blob(Vector3(0, 0.55, 0), 0.9, MeshKit.T_BRICK, Pal.STONE_DARK, 3, 6, 0.7, 0.4)
	k.crystal(Vector3(0, 1.0, 0), 0.22, 0.8, Color(0.6, 0.9, 1.0), 0.9, 5)
	b.footprint = 6.6
	b.height = 1.5
	b.can_fade = false
