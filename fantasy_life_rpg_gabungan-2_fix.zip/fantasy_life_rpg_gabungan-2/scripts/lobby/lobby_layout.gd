class_name LobbyLayout
extends RefCounted
## Kota diperbesar 50%: semua jarak/posisi ×1,5 (MAP_SCALE) sedangkan ukuran bangunan hanya naik 1,1→1,2, jadi ruangnya lebih lega.
## Data tata letak kota Aurelia (sumbu X = timur, Z = selatan/ke arah kamera). Satuan meter.
## Dipakai oleh LobbyWorld (membangun dunia), Lobby (NPC, spawn) dan alat uji.

const MAP_SCALE := 1.5                          # pengali ukuran peta dibanding versi awal (dipakai LobbyWorld/Explore untuk angka tetap)
const SPAWN := Vector3(0.0, 0.1, 75.0)          # titik muncul pemain (di dalam gerbang)
const SPAWN_YAW := 180.0                        # menghadap ke utara (-Z)
const WALL_MIN := Vector2(-96.0, -78.0)         # sudut tembok kota
const WALL_MAX := Vector2(96.0, 93.0)
const GATE_X := 9.2                             # setengah lebar bukaan gerbang pada tembok
const PLAZA_R := 22.5
const BUILDING_SCALE := 1.2                     # pembesaran semua bangunan (kecuali yang terikat ukuran tetap)
const NO_SCALE := ["fountain", "gate"]          # air mancur & gerbang terikat pada plaza/tembok
const BOUNDS_MIN := Vector2(-120.0, -99.0)       # batas tak terlihat tempat pemain bisa berjalan
const BOUNDS_MAX := Vector2(120.0, 117.0)

## Kota ditata seperti papan catur: sumbu utara-selatan (gerbang -> plaza -> guild), bulevar timur-barat
## (kamp party di ujung barat, portal di ujung timur), dua jalan samping di x = +-40 dan deretan bangunan yang SELALU menghadap jalan.
## Konvensi arah (yaw): 0 = muka menghadap +Z (selatan), 90 = menghadap +X (timur), 180 = menghadap -Z (utara), -90 = menghadap -X (barat).
## Rumah ditata seragam: di jalan utama jarak ke jalan 18 m, di jalan samping x = +-71,25; jarak antar rumah tetap 21 m dan simetris kiri-kanan.
## kind, pos (x,z), yaw (derajat), warna atap/dinding.
const BUILDINGS: Array = [
	{"kind": "fountain", "pos": Vector2(0, 0), "yaw": 0.0},
	{"kind": "gate", "pos": Vector2(0, 93), "yaw": 0.0, "seed": 11},
	# --- utara: guild menghadap plaza, bengkel & perpustakaan mengapit jalan guild
	{"kind": "guild", "pos": Vector2(0, -58.8), "yaw": 0.0, "roof": Color(0.32, 0.55, 0.95), "wall": Color(1.0, 0.96, 0.88), "seed": 1},
	{"kind": "forge", "pos": Vector2(-39, -49.5), "yaw": 90.0, "roof": Color(0.5, 0.52, 0.62), "seed": 4},
	{"kind": "library", "pos": Vector2(39, -49.5), "yaw": -90.0, "seed": 5},
	# --- bulevar timur-barat: toko di sisi utara menghadap jalan
	{"kind": "weapon_shop", "pos": Vector2(-45, -19.5), "yaw": 0.0, "roof": Color(0.92, 0.36, 0.32), "wall": Color(1.0, 0.94, 0.84), "seed": 2},
	{"kind": "item_shop", "pos": Vector2(45, -19.5), "yaw": 0.0, "roof": Color(0.22, 0.72, 0.7), "wall": Color(0.95, 1.0, 0.94), "seed": 3},
	# --- ujung bulevar: kamp party (barat) dan portal petualangan (timur)
	{"kind": "tent", "pos": Vector2(-81, 0), "yaw": 90.0, "seed": 8},
	{"kind": "portal", "pos": Vector2(79.5, 0), "yaw": -90.0, "seed": 7},
	# --- selatan: altar bintang & kolam taman di ujung jalan samping jalan utama
	{"kind": "altar", "pos": Vector2(-46.5, 57), "yaw": 90.0, "seed": 9},
	{"kind": "pond", "pos": Vector2(46.5, 57), "yaw": 0.0, "seed": 10},
	# --- rumah di sepanjang jalan utama selatan (menghadap jalan)
	{"kind": "house_d", "pos": Vector2(-18, 36), "yaw": 90.0, "roof": Color(0.64, 0.46, 0.9), "wall": Color(0.98, 0.95, 0.9), "seed": 21},
	{"kind": "house_b", "pos": Vector2(18, 36), "yaw": -90.0, "roof": Color(0.98, 0.64, 0.28), "wall": Color(1.0, 0.92, 0.84), "seed": 22},
	{"kind": "house_a", "pos": Vector2(-18, 78), "yaw": 90.0, "roof": Color(0.92, 0.36, 0.32), "wall": Color(0.96, 0.98, 1.0), "seed": 23},
	{"kind": "house_c", "pos": Vector2(18, 78), "yaw": -90.0, "roof": Color(0.32, 0.55, 0.95), "wall": Color(1.0, 0.94, 0.86), "seed": 24},
	# --- rumah di jalan samping barat (menghadap timur) dan timur (menghadap barat)
	{"kind": "house_a", "pos": Vector2(-71.25, -63), "yaw": 90.0, "roof": Color(0.35, 0.6, 0.45), "wall": Color(1.0, 0.94, 0.84), "seed": 31},
	{"kind": "house_b", "pos": Vector2(-71.25, -42), "yaw": 90.0, "roof": Color(0.35, 0.6, 0.45), "wall": Color(1.0, 0.96, 0.88), "seed": 32},
	{"kind": "house_c", "pos": Vector2(-71.25, -21), "yaw": 90.0, "roof": Color(0.85, 0.45, 0.55), "wall": Color(1.0, 0.96, 0.88), "seed": 33},
	{"kind": "house_a", "pos": Vector2(-71.25, 27), "yaw": 90.0, "roof": Color(0.22, 0.72, 0.7), "wall": Color(1.0, 0.96, 0.88), "seed": 34},
	{"kind": "house_b", "pos": Vector2(-71.25, 48), "yaw": 90.0, "roof": Color(0.98, 0.64, 0.28), "wall": Color(1.0, 0.92, 0.84), "seed": 35},
	{"kind": "house_c", "pos": Vector2(-71.25, 69), "yaw": 90.0, "roof": Color(0.64, 0.46, 0.9), "wall": Color(0.98, 0.95, 0.9), "seed": 36},
	{"kind": "tower", "pos": Vector2(75, -63), "yaw": -90.0, "seed": 6},
	{"kind": "house_b", "pos": Vector2(71.25, -42), "yaw": -90.0, "roof": Color(0.98, 0.64, 0.28), "wall": Color(1.0, 0.96, 0.88), "seed": 41},
	{"kind": "house_a", "pos": Vector2(71.25, -21), "yaw": -90.0, "roof": Color(0.32, 0.55, 0.95), "wall": Color(1.0, 0.95, 0.85), "seed": 42},
	{"kind": "house_a", "pos": Vector2(71.25, 27), "yaw": -90.0, "roof": Color(0.92, 0.36, 0.32), "wall": Color(0.97, 0.97, 1.0), "seed": 43},
	{"kind": "house_c", "pos": Vector2(71.25, 48), "yaw": -90.0, "roof": Color(0.35, 0.6, 0.45), "wall": Color(1.0, 0.96, 0.88), "seed": 44},
	{"kind": "house_b", "pos": Vector2(71.25, 69), "yaw": -90.0, "roof": Color(0.64, 0.46, 0.9), "wall": Color(1.0, 0.96, 0.9), "seed": 45},
]

## Jalan batu: titik kendali (garis lurus), lebar. Urutan penting: indeks 0-5 mendapat lampu jalan.
const ROADS: Array = [
	{"pts": [Vector2(0, 120), Vector2(0, 93), Vector2(0, 60), Vector2(0, 22.5)], "w": 9.0},        # 0 jalan utama selatan (gerbang -> plaza)
	{"pts": [Vector2(0, -22.5), Vector2(0, -36), Vector2(0, -49.5)], "w": 11.5},                      # 1 jalan menuju guild
	{"pts": [Vector2(-22.5, 0), Vector2(-45, 0), Vector2(-70.5, 0)], "w": 9.0},                       # 2 bulevar barat (ke kamp party)
	{"pts": [Vector2(22.5, 0), Vector2(45, 0), Vector2(69, 0)], "w": 9.0},                          # 3 bulevar timur (ke portal)
	{"pts": [Vector2(-60, -72), Vector2(-60, 0), Vector2(-60, 87)], "w": 6.0},                    # 4 jalan samping barat
	{"pts": [Vector2(60, -72), Vector2(60, 0), Vector2(60, 87)], "w": 6.0},                       # 5 jalan samping timur
	{"pts": [Vector2(-7.5, 57), Vector2(-22.5, 57), Vector2(-39, 57)], "w": 4.5},                     # 6 lorong ke altar
	{"pts": [Vector2(7.5, 57), Vector2(22.5, 57), Vector2(39, 57)], "w": 4.5},                        # 7 lorong ke kolam
	{"pts": [Vector2(-13.5, -49.5), Vector2(-21, -49.5), Vector2(-28.5, -49.5)], "w": 4.5},                  # 8 lorong ke bengkel
	{"pts": [Vector2(13.5, -49.5), Vector2(21, -49.5), Vector2(28.5, -49.5)], "w": 4.5},                     # 9 lorong ke perpustakaan
]

## Zona sebaran pohon (taman teratur): {"rect": Rect2, "count": n, "blossom": peluang bunga sakura}
const TREE_ZONES: Array = [
	{"rect": Rect2(30, 21, 24, 69), "count": 27, "blossom": 0.35},       # taman timur
	{"rect": Rect2(-54, 21, 24, 69), "count": 21, "blossom": 0.2},       # taman barat
	{"rect": Rect2(-57, -39, 27, 33), "count": 9, "blossom": 0.25},     # blok utara-barat & timur (di sela toko)
	{"rect": Rect2(30, -39, 27, 33), "count": 9, "blossom": 0.25},
	{"rect": Rect2(-57, -75, 15, 18), "count": 9, "blossom": 0.15},
	{"rect": Rect2(45, -78, 12, 15), "count": 8, "blossom": 0.15},
	{"rect": Rect2(85.5, -75, 9, 162), "count": 18, "blossom": 0.1},       # jajar pohon di sisi tembok
	{"rect": Rect2(-94.5, -75, 9, 162), "count": 18, "blossom": 0.1},
	{"rect": Rect2(-84, 84, 60, 9), "count": 12, "blossom": 0.1},
	{"rect": Rect2(24, 84, 60, 9), "count": 12, "blossom": 0.1},
]

## Titik tetap NPC (x, z): di depan bangunan masing-masing, menghadap jalan.
const NPC_SPOTS := {
	"guild_master": Vector2(-3.85, -45.93),
	"merchant": Vector2(-41.7, -10.26),
	"potion_seller": Vector2(41.7, -10.26),
	"blacksmith": Vector2(-29.65, -45.65),
	"info": Vector2(29.65, -45.65),
	"party_leader": Vector2(-72.2, 4.4),
	"gate_guard": Vector2(-6.6, 85.3),
	"priestess": Vector2(-42.1, 53.7),
}

## Arah hadap NPC (radian, atan2(dx, dz)): menghadap jalan tempat pemain datang.
const NPC_FACE := {
	"guild_master": 0.0,
	"merchant": 0.0,
	"potion_seller": 0.0,
	"blacksmith": PI / 2.0,
	"info": -PI / 2.0,
	"party_leader": PI / 2.0,
	"gate_guard": PI,
	"priestess": PI / 2.0,
}
