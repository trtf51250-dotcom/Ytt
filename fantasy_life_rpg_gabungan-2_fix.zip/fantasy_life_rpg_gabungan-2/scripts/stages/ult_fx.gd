class_name UltFx
extends RefCounted
## Efek visual ULTI (semua prosedural/orisinal, tanpa aset luar selain tekstur buatan tools/gen_ult_art.py):
## lingkaran sihir bercahaya, pilar & berkas cahaya, pedang cahaya jatuh, kolom api, naga tinta, retakan tanah.
## Semua hemat: mesh sederhana, material tak berbayang, CPUParticles sekali jalan; jumlah partikel mengikuti kualitas (CharFx._n).

static var _tex := {}


static func tex(name: String) -> Texture2D:
	if not _tex.has(name):
		_tex[name] = load("res://assets/fx/%s.png" % name)
	return _tex[name]


static func _mat(col: Color, texture: Texture2D = null, additive: bool = true, billboard: int = 0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD if additive else BaseMaterial3D.BLEND_MODE_MIX
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.albedo_color = col
	if texture != null:
		m.albedo_texture = texture
	if billboard == 1:
		m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	elif billboard == 2:
		m.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
	return m


static func _mi(mesh: Mesh, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi


static func _fade_free(node: Node, mat: StandardMaterial3D, delay: float, dur: float) -> void:
	var t := node.create_tween()
	t.tween_interval(delay)
	t.tween_property(mat, "albedo_color:a", 0.0, dur)
	t.tween_callback(node.queue_free)


## Lingkaran sihir di tanah. which: "a" (cincin berlapis + bintang) / "b" (bunga + 4 satelit). Muncul, berputar, memudar.
static func sigil(parent: Node, pos: Vector3, radius: float, col: Color, life: float = 2.0, which: String = "a", spin: float = 1.2, y: float = 0.1) -> Node3D:
	var root := Node3D.new()
	parent.add_child(root)
	root.global_position = Vector3(pos.x, y, pos.z)
	var pm := PlaneMesh.new()
	pm.size = Vector2(2, 2)
	var m := _mat(Color(col.r, col.g, col.b, 0.0), tex("sigil_" + which))
	var mi := _mi(pm, m)
	root.add_child(mi)
	var m2 := _mat(Color(col.r, col.g, col.b, 0.0), tex("sigil_" + ("b" if which == "a" else "a")))
	var mi2 := _mi(pm, m2)
	mi2.position.y = 0.02
	mi2.scale = Vector3(0.62, 1, 0.62)
	root.add_child(mi2)
	root.scale = Vector3(radius * 0.35, 1, radius * 0.35)
	var t := root.create_tween()
	t.set_parallel(true)
	t.tween_property(root, "scale", Vector3(radius, 1, radius), life * 0.3).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	t.tween_property(m, "albedo_color:a", 1.0, life * 0.25)
	t.tween_property(m2, "albedo_color:a", 0.85, life * 0.25)
	t.tween_property(m, "albedo_color:a", 0.0, life * 0.35).set_delay(life * 0.65)
	t.tween_property(m2, "albedo_color:a", 0.0, life * 0.35).set_delay(life * 0.65)
	t.tween_property(mi, "rotation:y", spin * life, life)
	t.tween_property(mi2, "rotation:y", -spin * 1.6 * life, life)
	t.chain().tween_callback(root.queue_free)
	return root


## Pilar cahaya setinggi `h` yang muncul cepat lalu menipis, dengan kilau bintang 4 titik di dasar.
static func pillar(parent: Node, pos: Vector3, col: Color, h: float = 14.0, w: float = 1.6, life: float = 0.7) -> void:
	var qm := QuadMesh.new()
	qm.size = Vector2(w, h)
	var m := _mat(Color(col.r, col.g, col.b, 0.95), tex("beam"), true, 2)
	var mi := _mi(qm, m)
	parent.add_child(mi)
	mi.global_position = Vector3(pos.x, h * 0.5, pos.z)
	mi.scale = Vector3(0.15, 0.4, 1)
	var core := _mat(Color(1, 1, 1, 0.9), tex("beam"), true, 2)
	var qc := QuadMesh.new()
	qc.size = Vector2(w * 0.35, h)
	var mic := _mi(qc, core)
	mi.add_child(mic)
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale", Vector3(1, 1, 1), 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.tween_property(m, "albedo_color:a", 0.0, life * 0.55).set_delay(life * 0.45)
	t.tween_property(core, "albedo_color:a", 0.0, life * 0.5).set_delay(life * 0.35)
	t.tween_property(mi, "scale:x", 0.2, life * 0.5).set_delay(life * 0.5)
	t.chain().tween_callback(mi.queue_free)
	flare(parent, pos + Vector3(0, 0.6, 0), col, w * 3.2, life * 0.8)


static func flare(parent: Node, pos: Vector3, col: Color, size: float, life: float = 0.4) -> void:
	var qm := QuadMesh.new()
	qm.size = Vector2(size, size)
	var m := _mat(Color(col.r, col.g, col.b, 1.0), tex("flare"), true, 1)
	var mi := _mi(qm, m)
	parent.add_child(mi)
	mi.global_position = pos
	mi.scale = Vector3(0.3, 0.3, 0.3)
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale", Vector3(1, 1, 1), life * 0.35).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	t.tween_property(m, "albedo_color:a", 0.0, life).set_delay(life * 0.2)
	t.chain().tween_callback(mi.queue_free)


## Pedang cahaya jatuh dari langit menusuk titik `pos`, lalu pecah jadi kilau & cincin.
static func blade(parent: Node, pos: Vector3, col: Color, h: float = 11.0, fall: float = 0.22, w: float = 1.0) -> void:
	var root := Node3D.new()
	parent.add_child(root)
	root.scale = Vector3(w, 1.0, w)
	root.global_position = Vector3(pos.x, h, pos.z)
	var cone := CylinderMesh.new()
	cone.top_radius = 0.16
	cone.bottom_radius = 0.0
	cone.height = 2.6
	cone.radial_segments = 4
	cone.rings = 1
	var m := _mat(Color(col.r, col.g, col.b, 0.95))
	var bl := _mi(cone, m)
	bl.position.y = 1.3
	bl.rotation_degrees.y = 45
	root.add_child(bl)
	var guard := BoxMesh.new()
	guard.size = Vector3(0.7, 0.07, 0.12)
	var g := _mi(guard, _mat(Color(1, 1, 1, 0.95)))
	g.position.y = 2.7
	root.add_child(g)
	var trail := QuadMesh.new()
	trail.size = Vector2(0.9, 5.0)
	var tm := _mat(Color(col.r, col.g, col.b, 0.55), tex("beam"), true, 2)
	var tr := _mi(trail, tm)
	tr.position.y = 5.0
	root.add_child(tr)
	var t := root.create_tween()
	t.tween_property(root, "global_position:y", 0.0, fall).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	t.tween_callback(func():
		Fx.ring(parent, pos, 2.2, col, 0.4)
		flare(parent, pos + Vector3(0, 0.5, 0), col, 3.0, 0.35)
		Fx.burst(parent, pos + Vector3(0, 0.3, 0), col, 8, 5.0, 0.14))
	t.tween_property(m, "albedo_color:a", 0.0, 0.35)
	t.parallel().tween_property(tm, "albedo_color:a", 0.0, 0.2)
	t.tween_callback(root.queue_free)


## Kolom api yang menyembur dari tanah (dua lapis: badan + inti terang).
static func flame_column(parent: Node, pos: Vector3, body: Color, core: Color, scale: float = 1.0) -> void:
	CharFx.puff(parent, pos + Vector3(0, 0.1, 0), body, 9, 3.2 * scale, 1.0 * scale, Vector3.UP, 14.0, 2.0, 1.0, "flame", false)
	CharFx.puff(parent, pos + Vector3(0, 0.15, 0), core, 6, 4.2 * scale, 0.6 * scale, Vector3.UP, 10.0, 3.0, 0.85, "flame", true)
	Fx.ring(parent, pos, 1.8 * scale, core, 0.4)


## Naga tinta/bayangan yang menyapu lurus dari `from` ke arah `dir` sejauh `length` (rantai bola berkelok + kepala bertanduk bermata terang).
static func dragon(parent: Node, from: Vector3, dir: Vector3, length: float, ink: Color, eye: Color, dur: float = 1.15) -> void:
	var root := Node3D.new()
	parent.add_child(root)
	root.global_position = from
	var d := Vector3(dir.x, 0, dir.z).normalized()
	var side := Vector3(-d.z, 0, d.x)
	var n := 26
	var segs: Array = []
	var body_m := _mat(Color(ink.r, ink.g, ink.b, 0.96), null, false)
	var rim_m := _mat(Color(eye.r, eye.g, eye.b, 0.22))
	for i in n:
		var r := lerpf(0.9, 0.22, float(i) / float(n - 1)) if i > 0 else 1.15
		var sm := SphereMesh.new()
		sm.radius = r
		sm.height = r * 2.0
		sm.radial_segments = 12
		sm.rings = 6
		var mi := _mi(sm, body_m)
		mi.visible = false
		root.add_child(mi)
		var rim := _mi(sm, rim_m)
		rim.scale = Vector3(1.3, 1.3, 1.3)
		mi.add_child(rim)
		segs.append(mi)
	var head: MeshInstance3D = segs[0]
	for s in [-1.0, 1.0]:                                   # tanduk & mata
		var hc := CylinderMesh.new()
		hc.top_radius = 0.0
		hc.bottom_radius = 0.22
		hc.height = 1.2
		hc.radial_segments = 5
		var horn := _mi(hc, body_m)
		horn.position = Vector3(0.5 * s, 0.9, -0.3)
		horn.rotation_degrees = Vector3(-30, 0, -25 * s)
		head.add_child(horn)
		var em := SphereMesh.new()
		em.radius = 0.16
		em.height = 0.32
		em.radial_segments = 6
		em.rings = 3
		var eyem := _mi(em, _mat(Color(eye.r, eye.g, eye.b, 1.0)))
		eyem.position = Vector3(0.42 * s, 0.25, 0.85)
		head.add_child(eyem)
	var total := length + 15.0
	var tw := root.create_tween()
	tw.tween_method(func(t: float):
		var head_s := t * total
		for i in n:
			var s := head_s - float(i) * 0.55
			var mi: MeshInstance3D = segs[i]
			if s < 0.0 or s > length + 1.0:
				mi.visible = false
				continue
			mi.visible = true
			var wob := sin(s * 0.9 + t * 7.0) * 1.35
			var lift := 1.1 + sin(s * 0.55 + t * 5.0) * 0.55
			mi.position = d * s + side * wob + Vector3(0, lift, 0)
			if i == 0:
				mi.look_at(mi.global_position + d, Vector3.UP, true)
		, 0.0, 1.0, dur)
	tw.tween_callback(root.queue_free)
	CharFx.puff(parent, from + d * length * 0.5 + Vector3(0, 1.2, 0), ink, 18, 5.0, 0.35, Vector3.UP, 180.0, -2.0, 0.9, "sphere", false)


## Tanah retak + tonjolan kristal/batu yang naik dari bawah.
static func quake(parent: Node, pos: Vector3, radius: float, glow: Color, rock: Color) -> void:
	CharFx.cracks(parent, pos, radius, glow, 0.9, 9)
	Fx.ring(parent, pos, radius, glow, 0.6)
	for i in 7:
		var a := TAU * float(i) / 7.0 + randf() * 0.5
		var r := radius * randf_range(0.25, 0.85)
		var p := pos + Vector3(sin(a) * r, 0, cos(a) * r)
		var cone := CylinderMesh.new()
		cone.top_radius = 0.0
		cone.bottom_radius = randf_range(0.35, 0.6)
		cone.height = randf_range(1.8, 3.2)
		cone.radial_segments = 5
		var mm := _mat(Color(rock.r, rock.g, rock.b, 0.95), null, false)
		var mi := _mi(cone, mm)
		parent.add_child(mi)
		mi.global_position = p + Vector3(0, -cone.height * 0.5, 0)
		var t := mi.create_tween()
		t.tween_property(mi, "global_position:y", cone.height * 0.4, 0.14).set_delay(randf() * 0.15).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		t.tween_interval(0.5)
		t.tween_property(mm, "albedo_color:a", 0.0, 0.3)
		t.tween_callback(mi.queue_free)
	CharFx.puff(parent, pos + Vector3(0, 0.2, 0), rock.lightened(0.2), 16, 7.0, 0.3, Vector3.UP, 70.0, -12.0, 0.8, "chip", false)


## Paranada: 5 garis cahaya sejajar di tanah (pentagram musik) yang melebar lalu memudar; nota naik dari garisnya.
static func staff_lines(parent: Node, pos: Vector3, radius: float, col: Color, life: float = 1.0, yaw: float = 0.0) -> void:
	var root := Node3D.new()
	parent.add_child(root)
	root.global_position = pos + Vector3(0, 0.07, 0)
	root.rotation.y = yaw
	var mats: Array = []
	for i in 5:
		var qm := QuadMesh.new()
		qm.size = Vector2(radius * 2.2, 0.09)
		var mat := _mat(Color(col.r, col.g, col.b, 0.9))
		mats.append(mat)
		var mi := _mi(qm, mat)
		mi.rotation_degrees = Vector3(-90, 0, 0)
		mi.position = Vector3(0, 0, (float(i) - 2.0) * radius * 0.22)
		mi.scale = Vector3(0.05, 1, 1)
		root.add_child(mi)
		var tw := mi.create_tween()
		tw.tween_property(mi, "scale:x", 1.0, 0.22 + 0.03 * i).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	var tf := root.create_tween()
	tf.tween_interval(life * 0.6)
	tf.tween_callback(func():
		for m in mats:
			var t2 := root.create_tween()
			t2.tween_property(m, "albedo_color:a", 0.0, life * 0.4))
	tf.tween_interval(life * 0.45)
	tf.tween_callback(root.queue_free)
	for i in 3:
		CharFx.notes(root, root.global_position + Vector3((randf() - 0.5) * radius * 1.4, 0.2, (float(i) - 2.0) * radius * 0.22), col, 3, 3.0, 0.55, Vector3.UP, 20.0, 1.2, 1.0)
