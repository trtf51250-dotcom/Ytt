class_name ChronoFx
extends RefCounted
## Efek manipulasi waktu (Aion): wajah jam raksasa di tanah dengan jarum berputar, cipratan tinta biru, gagak bersayap tinta,
## serpihan jarum jam. Semua prosedural + dua tekstur buatan sendiri (tools/gen_clock_art.py). Hemat: quad/box sederhana, tween, bebas sendiri.

const BLUE := Color(0.42, 0.62, 1.0)
const VIOLET := Color(0.62, 0.4, 1.0)
const GOLD := Color(1.0, 0.84, 0.45)
const INK := Color(0.1, 0.16, 0.5)


static func _q() -> int:
	return CharFx._q()


## Wajah jam di tanah: berputar pelan, jarum jam & menit menyapu, memudar. Mengembalikan root.
static func clock(parent: Node, pos: Vector3, radius: float, col: Color, life: float = 1.6, spin: float = 0.8, y: float = 0.1) -> Node3D:
	var root := Node3D.new()
	parent.add_child(root)
	root.global_position = Vector3(pos.x, y, pos.z)
	var pm := PlaneMesh.new()
	pm.size = Vector2(radius * 2.0, radius * 2.0)
	var m := UltFx._mat(Color(col.r, col.g, col.b, 0.0), UltFx.tex("clock_face"))
	var face := UltFx._mi(pm, m)
	root.add_child(face)
	var hands := Node3D.new()
	hands.position.y = 0.03
	root.add_child(hands)
	var mats: Array = [m]
	var lens := [radius * 0.78, radius * 0.5]
	var wids := [0.1, 0.16]
	var hand_nodes: Array = []
	for i in 2:
		var h := Node3D.new()
		hands.add_child(h)
		var bm := BoxMesh.new()
		bm.size = Vector3(wids[i], 0.03, lens[i])
		var hm := UltFx._mat(Color(1.0, 0.96, 0.8, 0.0) if i == 0 else Color(col.r, col.g, col.b, 0.0))
		var hmi := UltFx._mi(bm, hm)
		hmi.position.z = lens[i] * 0.5
		h.add_child(hmi)
		mats.append(hm)
		hand_nodes.append(h)
	var t := root.create_tween()
	t.set_parallel(true)
	t.tween_method(func(v: float):
		for mm in mats:
			var c2: Color = (mm as StandardMaterial3D).albedo_color
			c2.a = v
			(mm as StandardMaterial3D).albedo_color = c2, 0.0, 0.9, life * 0.2)
	t.tween_property(face, "rotation:y", spin * life, life)
	t.tween_property(hand_nodes[0], "rotation:y", -TAU * 1.2, life).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	t.tween_property(hand_nodes[1], "rotation:y", -TAU * 0.3, life).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	t.chain().tween_method(func(v: float):
		for mm in mats:
			var c3: Color = (mm as StandardMaterial3D).albedo_color
			c3.a = v
			(mm as StandardMaterial3D).albedo_color = c3, 0.9, 0.0, 0.35)
	t.chain().tween_callback(root.queue_free)
	return root


## Cipratan tinta (billboard): membesar cepat lalu memudar.
static func ink_burst(parent: Node, pos: Vector3, col: Color, size: float = 3.0, life: float = 0.6) -> void:
	var qm := QuadMesh.new()
	qm.size = Vector2(size, size)
	var m := UltFx._mat(Color(col.r, col.g, col.b, 0.7), UltFx.tex("ink_splash"), false, 1)
	var mi := UltFx._mi(qm, m)
	parent.add_child(mi)
	mi.global_position = pos
	mi.scale = Vector3.ONE * 0.25
	mi.rotation.z = randf() * TAU
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale", Vector3.ONE, life * 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.tween_property(m, "albedo_color:a", 0.0, life).set_delay(life * 0.25)
	t.chain().tween_callback(mi.queue_free)


## Gagak: dua sayap segitiga berkepak melintas lalu pecah jadi tinta. Siluet gelap dengan tepi biru.
static func crow(parent: Node, from: Vector3, to: Vector3, life: float = 0.9) -> void:
	var root := Node3D.new()
	parent.add_child(root)
	root.global_position = from
	root.look_at_from_position(from, to, Vector3.UP)
	var body := UltFx._mi(PrismMesh.new(), UltFx._mat(Color(0.04, 0.05, 0.12, 0.95), null, false))
	(body.mesh as PrismMesh).size = Vector3(0.22, 0.2, 0.7)
	body.rotation_degrees.x = 90
	root.add_child(body)
	var wings: Array = []
	for s in [-1.0, 1.0]:
		var piv := Node3D.new()
		root.add_child(piv)
		var pr := PrismMesh.new()
		pr.size = Vector3(0.9, 0.04, 0.55)
		var wm := UltFx._mi(pr, UltFx._mat(Color(0.05, 0.07, 0.18, 0.95), null, false))
		wm.position.x = s * 0.45
		wm.rotation_degrees.y = 90 if s > 0 else -90
		piv.add_child(wm)
		wings.append([piv, s])
	var glow := UltFx._mi(QuadMesh.new(), UltFx._mat(Color(BLUE.r, BLUE.g, BLUE.b, 0.5), UltFx.tex("flare"), true, 1))
	(glow.mesh as QuadMesh).size = Vector2(1.4, 1.4)
	root.add_child(glow)
	var t := root.create_tween()
	t.set_parallel(true)
	t.tween_property(root, "global_position", to, life).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	t.tween_method(func(v: float):
		var ang := sin(v * 38.0) * 0.5
		for w in wings:
			(w[0] as Node3D).rotation.z = float(w[1]) * ang, 0.0, life, life)
	t.chain().tween_callback(func():
		ink_burst(parent, to, INK.lightened(0.2), 1.8, 0.4)
		root.queue_free())


## Serpihan jarum jam (peluru bolt Aion): batang panjang emas dengan ujung biru, berputar pelan.
static func shard_visual() -> Node3D:
	var n := Node3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.08, 0.04, 0.9)
	n.add_child(UltFx._mi(bm, UltFx._mat(Color(1.0, 0.92, 0.62, 1.0))))
	var cm := CylinderMesh.new()
	cm.top_radius = 0.0
	cm.bottom_radius = 0.1
	cm.height = 0.35
	cm.radial_segments = 4
	cm.rings = 1
	var tip := UltFx._mi(cm, UltFx._mat(Color(0.45, 0.7, 1.0, 0.95)))
	tip.rotation_degrees.x = -90
	tip.position.z = -0.6
	n.add_child(tip)
	var gm := QuadMesh.new()
	gm.size = Vector2(0.9, 0.9)
	var glow := UltFx._mi(gm, UltFx._mat(Color(0.45, 0.65, 1.0, 0.55), UltFx.tex("flare"), true, 1))
	n.add_child(glow)
	return n


## Tanda slow di kaki musuh: cincin jam kecil berputar, hilang saat efek habis.
static func slow_mark(enemy: Node3D, dur: float) -> void:
	var old := enemy.get_node_or_null("SlowMark")
	if old != null:
		old.queue_free()
	var qm := PlaneMesh.new()
	qm.size = Vector2(2.2, 2.2)
	var m := UltFx._mat(Color(BLUE.r, BLUE.g, BLUE.b, 0.75), UltFx.tex("clock_face"))
	var mi := UltFx._mi(qm, m)
	mi.name = "SlowMark"
	enemy.add_child(mi)
	mi.position = Vector3(0, 0.08, 0)
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "rotation:y", -TAU * 0.5 * dur, dur)
	t.tween_property(m, "albedo_color:a", 0.0, 0.4).set_delay(maxf(dur - 0.4, 0.0))
	t.chain().tween_callback(mi.queue_free)


# ---------------------------------------------------------------- skill: Jeda Waktu
## Jam terbentang di bawah kaki, jarum menyapu, tinta memercik, dua gagak berputar mengitari.
static func skill(parent: Node, pos: Vector3, rng: float, col: Color) -> void:
	clock(parent, pos, rng, BLUE.lerp(col, 0.3), 1.5, 0.7)
	if _q() > 0:
		clock(parent, pos, rng * 0.55, VIOLET, 1.3, -1.1, 0.14)
	Fx.ring(parent, pos, rng, Color(0.75, 0.88, 1.0), 0.45)
	ink_burst(parent, pos + Vector3(0, 0.6, 0), INK.lightened(0.15), rng * 0.6, 0.55)
	UltFx.flare(parent, pos + Vector3(0, 1.0, 0), BLUE, 3.5, 0.4)
	CharFx.puff(parent, pos + Vector3(0, 0.5, 0), Color(0.7, 0.85, 1.0), 12, 5.0, 0.12, Vector3.UP, 85.0, -1.0, 1.0)
	if _q() > 0:
		for i in 2:
			var a := randf() * TAU
			var f := pos + Vector3(sin(a), 0.9, cos(a)) * rng * 0.9
			crow(parent, f, pos + Vector3(-sin(a), 2.2, -cos(a)) * rng * 0.5, 0.7)


# ---------------------------------------------------------------- ULT: Putaran Jam Raya
static func ult_charge(parent: Node, c: Vector3, r: float) -> void:
	clock(parent, c, r * 0.55, BLUE, 2.4, 0.5)
	clock(parent, c, r * 0.32, GOLD, 2.2, -0.9, 0.16)
	UltFx.flare(parent, c + Vector3(0, 1.2, 0), BLUE, 4.0, 0.7)
	CharFx.spark_lines(parent, c + Vector3(0, 1.0, 0), Vector3.UP, Color(0.8, 0.9, 1.0), 12, 8.0, 40.0, 0.5, 0.9)


static func ult_strike(parent: Node, p: Vector3, tint: Color) -> void:
	# serpihan jarum jam raksasa jatuh + cipratan tinta + riak waktu
	UltFx.blade(parent, p, BLUE.lerp(tint, 0.2), 10.0, 0.2, 1.6)
	ink_burst(parent, p + Vector3(0, 0.6, 0), INK.lightened(0.2), 3.2, 0.55)
	clock(parent, p, 2.2, GOLD, 0.7, 1.5, 0.14)
	CharFx.x_flash(parent, p + Vector3(0, 0.8, 0), Color(0.85, 0.93, 1.0), 1.4, 0.2)


static func ult_finale(parent: Node, c: Vector3, r: float, tint: Color) -> void:
	clock(parent, c, r, BLUE, 1.4, 0.6, 0.12)
	clock(parent, c, r * 0.6, VIOLET, 1.2, -1.0, 0.18)
	Fx.ring(parent, c, r, tint, 0.8)
	ink_burst(parent, c + Vector3(0, 2.0, 0), INK.lightened(0.2), r * 0.9, 0.9)
	UltFx.flare(parent, c + Vector3(0, 1.5, 0), Color(0.9, 0.95, 1.0), 9.0, 0.8)
	var n := 3 if _q() == 0 else 6
	for i in n:
		var a := float(i) / n * TAU
		crow(parent, c + Vector3(sin(a), 0.8, cos(a)) * r * 0.9, c + Vector3(-sin(a), 3.0, -cos(a)) * r * 0.3, 0.9)
