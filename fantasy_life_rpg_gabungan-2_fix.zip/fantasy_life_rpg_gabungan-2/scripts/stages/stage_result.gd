class_name StageResult
extends Control
## Layar hasil stage: KEMENANGAN / KALAH, bintang (muncul satu-satu), kartu statistik, hadiah,
## dan tombol Lobi / Ulangi / Lanjut ke stage berikutnya.

signal lobby_pressed
signal retry_pressed
signal next_pressed


func show_result(res: Dictionary, sd: StageData, extra: Dictionary, next_sd: StageData = null) -> void:
	theme = UiTheme.get_theme()
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var win: bool = res["win"]
	var accent: Color = UiTheme.GOLD if win else UiTheme.BAD

	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.1, 0.78)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var p := PanelContainer.new()
	p.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	p.grow_horizontal = Control.GROW_DIRECTION_BOTH
	p.grow_vertical = Control.GROW_DIRECTION_BOTH
	p.custom_minimum_size = Vector2(720, 0)
	p.add_theme_stylebox_override("panel", UiTheme.box(Color(0.06, 0.09, 0.21, 0.98), accent, 3, 14, 22))
	add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	p.add_child(v)

	# --- judul
	v.add_child(UiTheme.label("KEMENANGAN" if win else "KALAH", 50, accent, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(UiTheme.label(sd.display_name, 24, UiTheme.SKY, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(UiTheme.gold_rule(3.0))

	# --- bintang
	if win:
		var stars := int(res["stars"])
		var sr := HBoxContainer.new()
		sr.alignment = BoxContainer.ALIGNMENT_CENTER
		sr.add_theme_constant_override("separation", 10)
		v.add_child(sr)
		for i in 3:
			var lit := i < stars
			var sl := UiTheme.label("★" if lit else "☆", 60, UiTheme.GOLD if lit else UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER)
			sl.custom_minimum_size = Vector2(66, 72)
			sl.pivot_offset = Vector2(33, 36)
			sl.modulate.a = 0.0
			sl.scale = Vector2(0.3, 0.3)
			sr.add_child(sl)
			var tw := create_tween()
			tw.tween_interval(0.25 + 0.28 * i)
			tw.tween_property(sl, "modulate:a", 1.0, 0.12)
			tw.parallel().tween_property(sl, "scale", Vector2.ONE, 0.32).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		var why := PackedStringArray(["Stage selesai"])
		if extra.get("no_faint", false):
			why.append("tidak ada yang pingsan")
		if extra.get("hp_ok", false):
			why.append("sisa HP party ≥ 50%")
		v.add_child(UiTheme.label(" · ".join(why), 16, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER))
	else:
		v.add_child(UiTheme.label("Seluruh party pingsan. Hadiah hiburan tetap diberikan.", 18, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER))

	# --- kartu statistik & hadiah
	var t := int(res["time"])
	var tiles := HBoxContainer.new()
	tiles.add_theme_constant_override("separation", 8)
	v.add_child(tiles)
	tiles.add_child(_tile("Waktu", "%d:%02d" % [t / 60, t % 60], UiTheme.SKY))
	tiles.add_child(_tile("Monster", str(int(res["kills"])), UiTheme.TEXT))
	tiles.add_child(_tile("Gold", "+%d" % int(res["gold"]), UiTheme.GOLD))
	tiles.add_child(_tile("EXP", "+%d" % int(res["exp"]), UiTheme.GOOD))
	if int(res["diamond"]) > 0:
		tiles.add_child(_tile("Diamond", "+%d" % int(res["diamond"]), Color(0.55, 0.85, 1.0)))
	if res["first_clear"]:
		v.add_child(UiTheme.label("★ Bonus clear pertama sudah termasuk!", 18, UiTheme.GOOD, HORIZONTAL_ALIGNMENT_CENTER))
	if int(res["levels"]) > 0:
		v.add_child(UiTheme.label("NAIK LEVEL!  Sekarang Lv %d" % GameState.level, 28, UiTheme.GOOD, HORIZONTAL_ALIGNMENT_CENTER))
	var qn := GameState.ready_quest_count()
	if qn > 0:
		v.add_child(UiTheme.label("%d quest siap diklaim di lobi." % qn, 18, UiTheme.SKY, HORIZONTAL_ALIGNMENT_CENTER))

	# --- stage berikutnya
	if next_sd != null:
		v.add_child(UiTheme.label("Berikutnya: %s" % next_sd.display_name, 20, UiTheme.SKY, HORIZONTAL_ALIGNMENT_CENTER))

	# --- tombol
	var br := HBoxContainer.new()
	br.add_theme_constant_override("separation", 12)
	v.add_child(br)
	var b_lobby := UiTheme.button("Lobi", Vector2(0, 64))
	b_lobby.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b_lobby.pressed.connect(func(): lobby_pressed.emit())
	br.add_child(b_lobby)
	var b_retry := UiTheme.button("Ulangi" if win else "Coba lagi", Vector2(0, 64))
	b_retry.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b_retry.pressed.connect(func(): retry_pressed.emit())
	br.add_child(b_retry)
	if next_sd != null:
		var b_next := UiTheme.accent_button("Lanjut  ▶", UiTheme.GOLD, Vector2(0, 64))
		b_next.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b_next.size_flags_stretch_ratio = 1.4
		b_next.pressed.connect(func(): next_pressed.emit())
		br.add_child(b_next)
	elif win:
		# tidak ada stage berikutnya: Lobi jadi tombol utama
		b_lobby.add_theme_stylebox_override("normal", UiTheme.plate(UiTheme.GOLD.darkened(0.35), UiTheme.GOLD, 6, 8, 18, 10))
		b_lobby.add_theme_font_size_override("font_size", 24)

	# --- animasi masuk panel
	await get_tree().process_frame
	if not is_inside_tree():
		return
	p.pivot_offset = p.size * 0.5
	p.scale = Vector2(0.92, 0.92)
	p.modulate.a = 0.0
	var pt := create_tween()
	pt.tween_property(p, "modulate:a", 1.0, 0.18)
	pt.parallel().tween_property(p, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _tile(title: String, value: String, col: Color) -> PanelContainer:
	var pc := PanelContainer.new()
	pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pc.add_theme_stylebox_override("panel", UiTheme.plate(Color(0.12, 0.16, 0.34, 0.95), col, 4, 8, 10, 6))
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 0)
	pc.add_child(vb)
	vb.add_child(UiTheme.label(title, 15, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER))
	vb.add_child(UiTheme.label(value, 26, col, HORIZONTAL_ALIGNMENT_CENTER))
	return pc
