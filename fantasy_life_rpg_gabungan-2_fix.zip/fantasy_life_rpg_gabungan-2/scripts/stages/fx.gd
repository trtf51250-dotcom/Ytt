class_name Fx
extends RefCounted
## Efek visual ringan (tanpa aset luar): sapuan tebasan, cincin gelombang, ledakan partikel, angka damage, bayangan blob, telegraf serangan musuh.

static var _sector_cache: Dictionary = {}
static var _burst_mesh_cache: Dictionary = {}
static var _live_bursts := 0
const MAX_LIVE_BURSTS := 14


static func _unshaded(col: Color, additive: bool = true) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD if additive else BaseMaterial3D.BLEND_MODE_MIX
	m.albedo_color = col
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.no_depth_test = false
	return m


## Juring datar (kipas segitiga) menghadap +Z, jari-jari 1, sudut setengah half_deg. Di-cache.
static func sector_mesh(half_deg: float, seg: int = 16) -> ArrayMesh:
	var key := "%d_%d" % [int(half_deg), seg]
	if _sector_cache.has(key):
		return _sector_cache[key]
	var pts := PackedVector3Array()
	var norms := PackedVector3Array()
	var h := deg_to_rad(half_deg)
	for i in seg:
		var a0 := -h + 2.0 * h * float(i) / seg
		var a1 := -h + 2.0 * h * float(i + 1) / seg
		pts.append(Vector3.ZERO)
		pts.append(Vector3(sin(a0), 0, cos(a0)))
		pts.append(Vector3(sin(a1), 0, cos(a1)))
		for j in 3:
			norms.append(Vector3.UP)
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = pts
	arrays[Mesh.ARRAY_NORMAL] = norms
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_sector_cache[key] = m
	return m


## Pita busur (cincin tipis) menghadap +Z, jari-jari luar 1, lebar sudut band_deg (total). Dipakai sebagai "ujung tebasan" yang menyapu.
static func arc_band_mesh(band_deg: float, inner: float = 0.78, seg: int = 8) -> ArrayMesh:
	var key := "band_%d_%d" % [int(band_deg), int(inner * 100)]
	if _sector_cache.has(key):
		return _sector_cache[key]
	var pts := PackedVector3Array()
	var norms := PackedVector3Array()
	var h := deg_to_rad(band_deg * 0.5)
	for i in seg:
		var a0 := -h + 2.0 * h * float(i) / seg
		var a1 := -h + 2.0 * h * float(i + 1) / seg
		var o0 := Vector3(sin(a0), 0, cos(a0))
		var o1 := Vector3(sin(a1), 0, cos(a1))
		pts.append_array([o0 * inner, o0, o1, o0 * inner, o1, o1 * inner])
		for j in 6:
			norms.append(Vector3.UP)
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = pts
	arrays[Mesh.ARRAY_NORMAL] = norms
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_sector_cache[key] = m
	return m


## Sapuan juring pada tanah + "ujung tebasan" terang yang menyapu dari satu sisi ke sisi lain (flip = arah sapuan dibalik,
## dipakai bergantian untuk kombo). yaw = arah hadap (0 = +Z).
static func slash(parent: Node, pos: Vector3, yaw: float, radius: float, half_deg: float, color: Color, life: float = 0.22, flip: bool = false, ground_alpha: float = 0.5) -> void:
	if half_deg < 179.0:
		var pivot := Node3D.new()
		parent.add_child(pivot)
		pivot.global_position = Vector3(pos.x, 0.1, pos.z)
		var sgn := -1.0 if flip else 1.0
		var half := deg_to_rad(half_deg)
		pivot.rotation.y = yaw - half * sgn
		var edge := MeshInstance3D.new()
		edge.mesh = arc_band_mesh(minf(half_deg * 0.7, 48.0), 0.82)
		edge.material_override = _unshaded(Color(minf(color.r + 0.3, 1.0), minf(color.g + 0.3, 1.0), minf(color.b + 0.3, 1.0), 0.6), false)
		edge.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		edge.scale = Vector3.ONE * radius
		pivot.add_child(edge)
		var te := pivot.create_tween()
		te.set_parallel(true)
		te.tween_property(pivot, "rotation:y", yaw + half * sgn, life * 0.8).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		te.tween_property(edge.material_override, "albedo_color:a", 0.0, life * 1.1).set_delay(life * 0.25)
		te.chain().tween_callback(pivot.queue_free)
	var mi := MeshInstance3D.new()
	mi.mesh = sector_mesh(half_deg)
	mi.material_override = _unshaded(Color(color.r, color.g, color.b, ground_alpha), false)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	mi.global_position = Vector3(pos.x, 0.08, pos.z)
	mi.rotation.y = yaw
	mi.scale = Vector3.ONE * radius * 0.55
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale", Vector3.ONE * radius, life).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	t.tween_property(mi.material_override, "albedo_color:a", 0.0, life)
	t.chain().tween_callback(mi.queue_free)


## Cincin yang melebar (gelombang kejut / nova).
static func ring(parent: Node, pos: Vector3, radius: float, color: Color, life: float = 0.45) -> void:
	var mi := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.88
	tm.outer_radius = 1.0
	tm.rings = 24
	tm.ring_segments = 4
	mi.mesh = tm
	mi.material_override = _unshaded(Color(color.r, color.g, color.b, 0.85))
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	mi.global_position = Vector3(pos.x, 0.12, pos.z)
	mi.scale = Vector3(0.3, 0.3, 0.3)
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale", Vector3(radius, 1.0, radius), life).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	t.tween_property(mi.material_override, "albedo_color:a", 0.0, life)
	t.chain().tween_callback(mi.queue_free)


## Lingkaran sihir bintang di tanah (skill "Nova Bintang"): 1) muncul & berputar saat mengumpulkan tenaga selama `charge` detik
## (lapisan luar dan dalam berputar berlawanan arah, bintang-bintang kecil naik), 2) berdenyut terang & meledak di momen impak,
## 3) memudar. `charge` sebaiknya = waktu impak animasi supaya denyutnya selaras dengan damage.
static func magic_circle(parent: Node, pos: Vector3, radius: float, color: Color, charge: float = 0.5) -> Node3D:
	var root := Node3D.new()
	parent.add_child(root)
	root.global_position = Vector3(pos.x, 0.07, pos.z)
	var mats: Array = []
	var layers: Array = []
	for i in 2:
		var mi := MeshInstance3D.new()
		var pm := PlaneMesh.new()
		pm.size = Vector2(2.0, 2.0)
		mi.mesh = pm
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.blend_mode = BaseMaterial3D.BLEND_MODE_MIX      # alpha biasa: tetap terlihat jelas di atas rumput terang
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
		m.no_depth_test = false
		m.albedo_texture = load("res://assets/fx/magic_outer.png" if i == 0 else "res://assets/fx/magic_inner.png")
		m.albedo_color = Color(color.r, color.g, color.b, 0.0)
		mi.material_override = m
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.position.y = 0.01 * i
		root.add_child(mi)
		mats.append(m)
		layers.append(mi)
	# piringan gelap-biru lembut di bawah lingkaran (kontras seperti latar gelap pada lingkaran sihir)
	var disc := MeshInstance3D.new()
	var dm := PlaneMesh.new()
	dm.size = Vector2(2.0, 2.0)
	disc.mesh = dm
	var gt := GradientTexture2D.new()
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 128
	var gr := Gradient.new()
	gr.colors = PackedColorArray([Color(0.02, 0.06, 0.22, 0.62), Color(0.02, 0.06, 0.22, 0.5), Color(0.02, 0.06, 0.22, 0.0)])
	gr.offsets = PackedFloat32Array([0.0, 0.78, 1.0])
	gt.gradient = gr
	var dmat := StandardMaterial3D.new()
	dmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	dmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	dmat.cull_mode = BaseMaterial3D.CULL_DISABLED
	dmat.albedo_texture = gt
	dmat.albedo_color = Color(1, 1, 1, 0.0)
	disc.material_override = dmat
	disc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	disc.position.y = -0.01
	root.add_child(disc)
	root.scale = Vector3(radius * 0.55, 1.0, radius * 0.55)
	var total := charge + 0.75
	var tw := root.create_tween()
	tw.set_parallel(true)
	# muncul + membesar selama pengumpulan, lalu sedikit melebar saat ledakan
	tw.tween_property(root, "scale", Vector3(radius, 1.0, radius), charge).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(root, "scale", Vector3(radius * 1.12, 1.0, radius * 1.12), 0.75).set_delay(charge).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	for m in mats:
		tw.tween_property(m, "albedo_color:a", 0.95, charge * 0.6)
		tw.tween_property(m, "albedo_color", Color(minf(color.r + 0.5, 1.0), minf(color.g + 0.4, 1.0), 1.0, 1.0), 0.06).set_delay(charge)   # denyut terang saat impak
		tw.tween_property(m, "albedo_color", Color(color.r, color.g, color.b, 0.0), 0.65).set_delay(charge + 0.1)
	tw.tween_property(dmat, "albedo_color:a", 1.0, charge * 0.6)
	tw.tween_property(dmat, "albedo_color:a", 0.0, 0.65).set_delay(charge + 0.1)
	# rotasi berlawanan arah
	tw.tween_property(layers[0], "rotation:y", 2.2, total)
	tw.tween_property(layers[1], "rotation:y", -3.4, total)
	tw.chain().tween_callback(root.queue_free)
	# bintang kecil naik selama pengumpulan
	var sp := CPUParticles3D.new()
	sp.amount = 24
	sp.lifetime = 0.7
	sp.one_shot = false
	sp.emitting = true
	sp.direction = Vector3.UP
	sp.spread = 12.0
	sp.initial_velocity_min = 1.5
	sp.initial_velocity_max = 3.2
	sp.gravity = Vector3(0, 0.5, 0)
	sp.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	sp.emission_sphere_radius = 0.85
	sp.scale_amount_min = 0.06
	sp.scale_amount_max = 0.12
	var sm := SphereMesh.new()
	sm.radius = 0.5
	sm.height = 1.0
	sm.radial_segments = 6
	sm.rings = 3
	sm.material = _unshaded(Color(0.75, 0.92, 1.0, 1.0), true)
	sp.mesh = sm
	root.add_child(sp)
	root.get_tree().create_timer(charge).timeout.connect(func():
		if is_instance_valid(sp):
			sp.emitting = false)
	return root


## Ledakan partikel kecil (CPUParticles3D sekali jalan).
static func burst(parent: Node, pos: Vector3, color: Color, count: int = 10, speed: float = 4.0, size: float = 0.12, dir: Vector3 = Vector3.UP, spread: float = 180.0) -> void:
	# PERF: batasi jumlah ledakan hidup bersamaan & pakai mesh/material yang di-cache (dulu bikin mesh+material baru tiap pukulan -> patah-patah di HP).
	if _live_bursts >= MAX_LIVE_BURSTS:
		return
	var q := Quality.level()
	var cnt := maxi(2, int(count * (0.6 if q == 0 else 1.0)))
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.emitting = false
	p.amount = cnt
	p.lifetime = 0.5
	p.explosiveness = 1.0
	p.direction = dir
	p.spread = spread
	p.initial_velocity_min = speed * 0.5
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, -9.0, 0)
	p.scale_amount_min = size
	p.scale_amount_max = size * 1.6
	var key := color.to_html(false)
	var sm: SphereMesh = _burst_mesh_cache.get(key)
	if sm == null:
		sm = SphereMesh.new()
		sm.radius = 0.5
		sm.height = 1.0
		sm.radial_segments = 6
		sm.rings = 3
		sm.material = _unshaded(Color(color.r, color.g, color.b, 1.0), false)
		if _burst_mesh_cache.size() > 48:
			_burst_mesh_cache.clear()
		_burst_mesh_cache[key] = sm
	p.mesh = sm
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	_live_bursts += 1
	p.get_tree().create_timer(1.0).timeout.connect(func():
		_live_bursts = maxi(_live_bursts - 1, 0)
		if is_instance_valid(p):
			p.queue_free())


## Teks melayang (angka damage / penyembuhan).
static func float_text(parent: Node, pos: Vector3, text: String, color: Color, size: float = 1.0) -> void:
	var l := Label3D.new()
	l.text = text
	l.font_size = 56
	l.outline_size = 14
	l.pixel_size = 0.0075 * size
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.modulate = color
	l.outline_modulate = Color(0.05, 0.05, 0.12, 0.95)
	l.render_priority = 10
	parent.add_child(l)
	l.global_position = pos + Vector3(randf_range(-0.25, 0.25), 0, randf_range(-0.1, 0.1))
	if size > 1.1:                                  # kritikal: angka "meletup" lalu mengendap
		l.scale = Vector3.ONE * 0.4
		var pop := l.create_tween()
		pop.tween_property(l, "scale", Vector3.ONE * 1.25, 0.09).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		pop.tween_property(l, "scale", Vector3.ONE, 0.12)
	var t := l.create_tween()
	t.set_parallel(true)
	t.tween_property(l, "position:y", l.position.y + 1.3, 0.8).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	t.tween_property(l, "modulate:a", 0.0, 0.35).set_delay(0.5)
	t.chain().tween_callback(l.queue_free)


## Bayangan blob bundar di tanah.
static func shadow(size: float = 1.5) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	q.orientation = PlaneMesh.FACE_Y
	m.mesh = q
	var g := Gradient.new()
	g.colors = PackedColorArray([Color(0, 0, 0, 0.5), Color(0, 0, 0, 0.0)])
	g.offsets = PackedFloat32Array([0.0, 1.0])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 64
	gt.height = 64
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_texture = gt
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.material_override = mat
	m.position = Vector3(0, 0.05, 0)
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return m


## Piringan telegraf (merah) di tanah yang membesar/menebal saat serangan musuh bersiap. Mengembalikan node (dibuang oleh pemanggil).
static func telegraph(parent: Node, pos: Vector3, radius: float, duration: float, color: Color = Color(1.0, 0.25, 0.2)) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.0
	cm.bottom_radius = 1.0
	cm.height = 0.04
	cm.radial_segments = 28
	cm.rings = 1
	mi.mesh = cm
	var mat := _unshaded(Color(color.r, color.g, color.b, 0.12), false)
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	mi.global_position = Vector3(pos.x, 0.07, pos.z)
	mi.scale = Vector3(radius, 1.0, radius)
	var t := mi.create_tween()
	t.tween_property(mat, "albedo_color:a", 0.55, duration)
	return mi
