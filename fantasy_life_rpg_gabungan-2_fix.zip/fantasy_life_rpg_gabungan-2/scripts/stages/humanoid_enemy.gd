class_name HumanoidEnemy
extends Enemy
## Musuh berwujud manusia (Bab 4-5): memakai rig karakter (hero.glb) + skin sendiri + aksesori CharacterLooks.apply_enemy.
## Kroco: Pengikut Berkerudung (cultist), Penyihir Bayangan (shadow_mage, jarak jauh), Ksatria Rantai (chain_knight), Ronin Bayangan (ronin).
## Bos: Uranos (uranos), Raja Rantai Merah (chain_king).
## Memakai mesin status Enemy (spawn/chase/windup/strike/recover/stagger); semua serangan punya telegraf merah agar bisa dihindari.

const LOOKS := {
	"cultist": {"skin": "e_cultist", "h": 1.7, "style": "zeya", "wc": "sword", "col": Color(0.9, 0.15, 0.25)},
	"shadow_mage": {"skin": "e_mage", "h": 1.75, "style": "lyra", "wc": "staff", "col": Color(0.7, 0.3, 1.0)},
	"chain_knight": {"skin": "e_knight", "h": 2.0, "style": "kuroha", "wc": "sword", "col": Color(0.9, 0.15, 0.2)},
	"ronin": {"skin": "e_ronin", "h": 1.85, "style": "hakuya", "wc": "sword", "col": Color(1.0, 0.3, 0.2)},
	"uranos": {"skin": "e_uranos", "h": 2.3, "style": "lucien", "wc": "staff", "col": Color(0.8, 0.45, 1.0)},
	"chain_king": {"skin": "e_chainking", "h": 2.7, "style": "kuroha", "wc": "sword", "col": Color(1.0, 0.15, 0.2)},
}

# {serangan: [windup, animasi, jeda_setelah]}
const ATK := {
	"cultist": {"lunge": [0.55, "attack1", 0.9]},
	"shadow_mage": {"bolt": [0.9, "attack1", 1.1], "fan": [1.2, "skill", 1.4]},
	"chain_knight": {"slash": [0.85, "attack1", 1.0], "lash": [1.15, "skill", 1.2]},
	"ronin": {"slash": [0.5, "attack1", 0.8], "dash": [0.85, "skill", 1.0]},
	"uranos": {"volley": [1.0, "attack1", 1.0], "meteor": [1.5, "skill", 1.0], "nova": [1.4, "skill", 1.0], "blink": [0.45, "dodge", 0.4]},
	"chain_king": {"slam": [1.1, "attack1", 1.1], "sweep": [1.4, "skill", 1.1], "cage": [1.5, "skill", 1.1], "charge": [1.1, "skill", 1.2]},
}

var rig: CharacterRig
var look: Dictionary
var _cape: Node3D
var _prev_pos := Vector3.ZERO
var _wu_len := 0.5
var _impact := 0.2
var _anim_done := false
var _post_cd := 1.0
var _rec_len := 1.0
var _blink_cd := 3.0
var _summon_cd := 9.0
var _cast_n := 0
var _spots: Array = []
var _from_pos := Vector3.ZERO


func setup(p_kind: String, level: int, p_target: Node3D, p_fx: Node3D) -> void:
	super.setup(p_kind, level, p_target, p_fx)
	look = LOOKS[kind]
	rig = CharacterRig.new()
	rig.name = "Rig"
	_visual.add_child(rig)
	rig.setup(float(look["h"]), load("res://assets/hero/skin_%s.png" % look["skin"]), true, true)
	rig.set_weapon_class(String(look["wc"]))
	var out := CharacterLooks.apply_enemy(rig, kind)
	_cape = out.get("cape", null)
	rig.set_style(String(look["style"]))
	rig.set_move(0.0)
	if _bar_bg:
		_bar_bg.position.y = float(look["h"]) + 0.55
		_bar_fg.position.y = float(look["h"]) + 0.55
	if is_boss:
		var aura := OmniLight3D.new()
		aura.light_color = look["col"]
		aura.light_energy = 1.3
		aura.omni_range = 9.0
		aura.position = Vector3(0, float(look["h"]) * 0.8, 0)
		aura.shadow_enabled = false
		aura.add_to_group("deco_light")
		_visual.add_child(aura)
	_prev_pos = global_position
	_cooldown = randf_range(0.8, 1.8)
	_summon_cd = randf_range(7.0, 10.0)


# ---------------------------------------------------------------- umum
func _col() -> Color:
	return look["col"]


func _footsteps(delta: float) -> void:
	if kind == "chain_king":
		super._footsteps(delta)


func _puppet_on_state(st: String) -> void:
	if st == "windup" and rig != null:
		if _attack == "blink":
			rig.play_action("dodge")
		else:
			var a: Array = ATK[kind].get(_attack, [0.0, "skill", 0.0])
			rig.play_action(String(a[1]))


func _death_color() -> Color:
	return _col()


func _chest() -> Vector3:
	return global_position + Vector3(0, float(look["h"]) * 0.62, 0)


func take_damage(amount: int, from: Vector3, knock: float = 3.0) -> void:
	if dead or state == "spawn":
		return
	super.take_damage(amount, from, knock)
	if dead:
		return
	rig.flash(Color(1, 1, 1), 0.12)
	if not is_boss:
		if state == "stagger":
			rig.play_action("hurt")
	elif _hit_cd <= 0.0 and state in ["chase", "recover"]:
		_hit_cd = 3.0
		rig.play_action("hurt")


func _die() -> void:
	dead = true
	state = "dead"
	_wave_active = false
	_clear_telegraph()
	collision_layer = 0
	collision_mask = 0
	remove_from_group("enemies")
	if _bar_bg:
		_bar_bg.visible = false
		_bar_fg.visible = false
	Fx.burst(fx_parent, global_position + Vector3(0, float(look["h"]) * 0.5, 0), _col(), 22 if is_boss else 10, 5.0, 0.16)
	Sfx.play("die" if not is_boss else "boss_death", 1.0 if not is_boss else 0.9, 0.0 if not is_boss else 2.0)
	if is_boss:
		request_shake.emit(0.7)
		Fx.ring(fx_parent, global_position, 9.0, _col(), 0.9)
	died.emit(self)
	rig.play_action("death")
	var tw := create_tween()
	tw.tween_interval(2.4 if is_boss else 1.1)
	tw.tween_property(_visual, "scale", Vector3(0.05, 0.05, 0.05), 0.5).set_ease(Tween.EASE_IN)
	tw.tween_callback(queue_free)


func _enter_phase2() -> void:
	_phase = 2
	speed *= 1.2
	phase_changed.emit(2)
	request_shake.emit(0.5)
	Sfx.play("boss_roar", 0.9, 2.0)
	Fx.ring(fx_parent, global_position, 8.0, _col(), 0.6)
	Fx.burst(fx_parent, _chest(), _col().lightened(0.3), 24, 6.0, 0.18)
	_clear_telegraph()
	rig.play_action("skill")
	_set_state("recover", 1.2)
	_spawn_adds()


func _spawn_adds() -> void:
	var list: Array = ["cultist", "shadow_mage"] if kind == "uranos" else ["chain_knight", "chain_knight"]
	for i in list.size():
		var a := randf() * TAU
		request_spawn.emit(list[i], global_position + Vector3(cos(a), 0, sin(a)) * 4.5)


# ---------------------------------------------------------------- status
func _st_recover(_delta: float) -> void:
	if _t <= 0.0:
		_cooldown = _post_cd
		_set_state("chase")


func _st_chase(delta: float) -> void:
	var to := _flat_to_target()
	var dist := to.length()
	var dir := to.normalized() if dist > 0.01 else Vector3.ZERO
	if not is_boss and dist > 3.0:
		dir = _pursuit_dir(to, dist)
	_blink_cd -= delta
	_summon_cd -= delta
	match kind:
		"shadow_mage", "uranos":
			# menjaga jarak: mendekat bila jauh, mundur menyamping bila terlalu dekat
			var far := 9.0 if kind == "shadow_mage" else 7.5
			var near := 5.0 if kind == "shadow_mage" else 4.2
			_face(dir, delta, 6.0)
			if dist > far:
				_move_dir(dir, speed)
			elif dist < near:
				var side := dir.rotated(Vector3.UP, PI * 0.5 * _orbit_dir)
				_move_dir((-dir * 0.7 + side * 0.6).normalized(), speed * 0.9)
			else:
				_move_dir(dir.rotated(Vector3.UP, PI * 0.5 * _orbit_dir), speed * 0.35)
			if kind == "uranos" and dist < 3.2 and _blink_cd <= 0.0:
				_begin_attack("blink")
			elif _cooldown <= 0.0 and dist < 14.0:
				_begin_attack(_pick(dist))
		_:
			var stop := 1.2 if not is_boss else 2.0
			if dist > stop + radius:
				_move_dir(dir, speed)
			_face(dir, delta, 6.0)
			if _cooldown <= 0.0:
				var a := _pick(dist)
				if a != "":
					_begin_attack(a)


func _pick(dist: float) -> String:
	var opts: Array = []
	match kind:
		"cultist":
			if dist < 3.6:
				opts = ["lunge"]
		"shadow_mage":
			opts = ["bolt", "bolt", "fan"]
		"chain_knight":
			if dist < 3.2:
				opts = ["slash", "slash", "lash"]
		"ronin":
			if dist < 2.6:
				opts = ["slash"]
			elif dist > 4.0 and dist < 10.0:
				opts = ["dash", "dash", "slash"] if dist < 3.0 else ["dash"]
		"uranos":
			opts = ["volley", "volley", "nova", "meteor"] if dist < 8.0 else ["volley", "meteor", "meteor"]
			if _phase == 2 and _summon_cd <= 0.0:
				opts = ["summon"]
		"chain_king":
			if dist < 5.0:
				opts = ["slam", "slam", "sweep"]
			else:
				opts = ["charge", "cage", "cage"] if dist > 7.0 else ["slam", "cage"]
			if _phase == 2 and _summon_cd <= 0.0:
				opts = ["summon"]
	if opts.is_empty():
		return ""
	var f: Array = opts.filter(func(a): return a != _last_attack or opts.size() == 1)
	return f[randi() % f.size()]


func _begin_attack(which: String) -> void:
	_attack = which
	_last_attack = which
	_move_dir(Vector3.ZERO, 0.0)
	_strike_dir = _flat_to_target().normalized()
	_anim_done = false
	var data: Array
	if which == "summon":
		data = [1.2, "skill", 1.0]
	else:
		data = ATK[kind][which]
	var wu := float(data[0])
	if is_boss and _phase == 2:
		wu *= 0.8
	elif not is_boss:
		wu *= 0.95
	_wu_len = wu
	_post_cd = float(data[2]) * (0.8 if _phase == 2 else 1.0)
	_rec_len = 0.6 if is_boss else float(info["recover"])
	_impact = minf(rig.action_impact(String(data[1])), wu * 0.9)
	_set_state("windup", wu)
	var fwd := Vector3(sin(rotation.y), 0, cos(rotation.y))
	var c := _col()
	match kind:
		"cultist":
			_telegraph = Fx.telegraph(fx_parent, global_position + fwd * 1.5, 1.7, wu, c)
		"shadow_mage":
			_telegraph = Fx.telegraph(fx_parent, global_position, 1.3 if which == "bolt" else 2.0, wu, c)
		"chain_knight":
			if which == "slash":
				_telegraph = Fx.telegraph(fx_parent, global_position + fwd * 1.9, 2.3, wu)
			else:
				_telegraph = Fx.telegraph(fx_parent, global_position, 3.7, wu, Color(1.0, 0.5, 0.2))
		"ronin":
			if which == "slash":
				_telegraph = Fx.telegraph(fx_parent, global_position + fwd * 1.7, 2.2, wu)
			else:
				_telegraph = Fx.telegraph(fx_parent, global_position + _strike_dir * 5.5, 1.8, wu, Color(1.0, 0.8, 0.2))
		"uranos":
			match which:
				"volley":
					_telegraph = Fx.telegraph(fx_parent, global_position + _strike_dir * 5.0, 2.4, wu, c)
				"nova":
					_telegraph = Fx.telegraph(fx_parent, global_position, 9.0, wu, c)
				"meteor":
					_spots.clear()
					var n := 8 if _phase == 2 else 5
					var tp := target.global_position
					for i in n:
						var off := Vector3.ZERO if i == 0 else Vector3(randf_range(-6.0, 6.0), 0, randf_range(-6.0, 6.0))
						var pos := Vector3(tp.x, 0.0, tp.z) + off
						_spots.append(pos)
						_extra_tele.append(Fx.telegraph(fx_parent, pos, 2.2, wu, c))
				"blink":
					Fx.burst(fx_parent, _chest(), c, 14, 4.0, 0.14)
				"summon":
					_telegraph = Fx.telegraph(fx_parent, global_position, 4.0, wu, c)
		"chain_king":
			match which:
				"slam":
					_telegraph = Fx.telegraph(fx_parent, global_position + fwd * 3.2, 3.6, wu)
				"sweep":
					_telegraph = Fx.telegraph(fx_parent, global_position, 6.2, wu, Color(1.0, 0.5, 0.2))
				"cage":
					_spots.clear()
					var n2 := 7 if _phase == 2 else 5
					var tp2 := target.global_position
					for i in n2:
						var off2 := Vector3.ZERO if i == 0 else Vector3(randf_range(-5.5, 5.5), 0, randf_range(-5.5, 5.5))
						var pos2 := Vector3(tp2.x, 0.0, tp2.z) + off2
						_spots.append(pos2)
						_extra_tele.append(Fx.telegraph(fx_parent, pos2, 2.1, wu, c))
				"charge":
					_telegraph = Fx.telegraph(fx_parent, global_position + _strike_dir * 9.0, 2.6, wu, Color(1.0, 0.8, 0.2))
				"summon":
					_telegraph = Fx.telegraph(fx_parent, global_position, 4.0, wu, c)
	if is_boss:
		_sfx("boss_growl", 0.8 if kind == "chain_king" else 0.9, 0.0)


func _st_windup(delta: float) -> void:
	_move_dir(Vector3.ZERO, 0.0)
	if _attack != "dash" and _attack != "charge":
		_face(_flat_to_target(), delta, 5.0)
		_strike_dir = _flat_to_target().normalized()
	elif _t > _wu_len * 0.5:
		_face(_flat_to_target(), delta, 5.0)
		_strike_dir = _flat_to_target().normalized()
	# animasi mulai tepat supaya momen ayunan jatuh bersamaan dengan serangan
	if not _anim_done and _t <= _impact + 0.02 and _attack != "blink":
		_anim_done = true
		var a: Array = ATK[kind].get(_attack, [0.0, "skill", 0.0])
		rig.play_action(String(a[1]))
	elif _attack == "blink" and not _anim_done:
		_anim_done = true
		rig.play_action("dodge")
	if int(_anim_t * 6.0) % 3 == 0 and _wu_len - _t > 0.1:
		rig.flash(Color(1, 0.25, 0.2), 0.09)
	if _t > 0.0:
		return
	_clear_telegraph()
	_strike_now()


func _in(center: Vector3, r: float) -> bool:
	var tp := target.global_position
	return Vector2(tp.x - center.x, tp.z - center.z).length() < r + 0.4


func _strike_now() -> void:
	var c := _col()
	var fwd := Vector3(sin(rotation.y), 0, cos(rotation.y))
	var dur := 0.35
	match _attack:
		"lunge":
			dur = 0.28
		"slash":
			dur = 0.3
			var ctr := global_position + fwd * (1.9 if kind == "chain_knight" else 1.7)
			var r := 2.3 if kind == "chain_knight" else 2.2
			Fx.ring(fx_parent, ctr, r, c, 0.25)
			Fx.burst(fx_parent, ctr + Vector3(0, 1.0, 0), c.lightened(0.3), 8, 4.5, 0.12)
			if _in(ctr, r):
				_deal(1.0)
			_did_hit = true
			Sfx.play("boss_swipe", 1.3, -6.0)
		"lash":
			dur = 0.45
			Fx.ring(fx_parent, global_position, 3.7, Color(1.0, 0.5, 0.2), 0.4)
			Fx.burst(fx_parent, global_position + Vector3(0, 0.6, 0), Color(0.7, 0.7, 0.8), 14, 5.0, 0.12)
			if _in(global_position, 3.7):
				_deal(1.15)
			_did_hit = true
			_sfx("boss_swipe", 1.0, -2.0)
		"dash", "charge":
			dur = 0.38 if _attack == "dash" else 0.65
			_from_pos = global_position
		"bolt", "fan":
			dur = 0.4
			var n := 1 if _attack == "bolt" else 3
			for i in n:
				var ang := (i - (n - 1) * 0.5) * 0.3
				var d := _strike_dir.rotated(Vector3.UP, ang)
				var p := Projectile.make("bolt", c)
				p.target_group = "player"
				fx_parent.add_child(p)
				p.launch(_chest() + d * 0.8, d, 9.5, 22.0)
				p.on_hit = func(t2): _deal(0.9, t2)
			Fx.burst(fx_parent, _chest() + _strike_dir * 0.8, c.lightened(0.3), 8, 4.0, 0.12)
			Sfx.play("shoot", 0.7, -4.0)
		"volley":
			dur = 0.5
			var n2 := 7 if _phase == 2 else 5
			for i in n2:
				var ang2 := (i - (n2 - 1) * 0.5) * 0.24
				var d2 := _strike_dir.rotated(Vector3.UP, ang2)
				var p2 := Projectile.make("bolt", c)
				p2.target_group = "player"
				fx_parent.add_child(p2)
				p2.launch(_chest() + d2 * 1.2, d2, 11.0, 26.0)
				p2.on_hit = func(t3): _deal(0.85, t3)
			Fx.burst(fx_parent, _chest() + _strike_dir * 1.2, c.lightened(0.3), 14, 5.0, 0.14)
			_sfx("boss_swipe", 0.8, 2.0)
			Sfx.play("shoot", 0.55, -2.0)
			request_shake.emit(0.2)
		"nova":
			dur = 0.9
			_wave_active = true
			_wave_r = 1.0
			_wave_hit = false
			_wave_center = global_position
			Fx.ring(fx_parent, global_position, 9.0, c, 0.9)
			Fx.ring(fx_parent, global_position, 5.5, Color(1, 1, 1), 0.6)
			Fx.burst(fx_parent, global_position + Vector3(0, 1.2, 0), c.lightened(0.4), 22, 7.0, 0.18)
			_sfx("boss_wave", 1.0, 3.0)
			request_shake.emit(0.4)
		"meteor", "cage":
			dur = 0.6
			var hit := false
			for pos: Vector3 in _spots:
				Fx.ring(fx_parent, pos, 2.2, c, 0.45)
				Fx.burst(fx_parent, pos + Vector3(0, 0.5, 0), c.lightened(0.4), 14, 6.0, 0.16)
				if not hit and _in(pos, 2.2):
					hit = true
					_deal(1.2)
			_did_hit = true
			_spots.clear()
			_sfx("boss_claw_hit", 0.9, 0.0)
			request_shake.emit(0.4)
		"slam":
			dur = 0.5
			var sc := global_position + fwd * 3.2
			Fx.ring(fx_parent, sc, 3.6, c, 0.5)
			Fx.burst(fx_parent, sc + Vector3(0, 0.4, 0), Color(0.8, 0.8, 0.9), 16, 6.0, 0.16)
			if _in(sc, 3.6):
				_deal(1.3)
			_did_hit = true
			_sfx("boss_crash", 1.0, 0.0)
			request_shake.emit(0.45)
		"sweep":
			dur = 0.6
			Fx.ring(fx_parent, global_position, 6.2, Color(1.0, 0.5, 0.2), 0.5)
			Fx.ring(fx_parent, global_position, 3.4, c, 0.4)
			Fx.burst(fx_parent, global_position + Vector3(0, 0.6, 0), Color(0.75, 0.75, 0.85), 22, 7.0, 0.14)
			if _in(global_position, 6.2):
				_deal(1.2)
			_did_hit = true
			_sfx("boss_wave", 1.1, 1.0)
			request_shake.emit(0.4)
		"blink":
			dur = 0.25
			_blink()
		"summon":
			dur = 0.7
			_summon_cd = 14.0
			Fx.ring(fx_parent, global_position, 4.0, c, 0.6)
			Fx.burst(fx_parent, global_position + Vector3(0, 1.0, 0), c.lightened(0.3), 20, 5.0, 0.16)
			_sfx("boss_roar", 1.1, 0.0)
			_spawn_adds()
	_set_state("strike", dur)


func _blink() -> void:
	Fx.burst(fx_parent, _chest(), _col(), 16, 5.0, 0.16)
	var tp := target.global_position
	var c := (Vector3.ZERO - tp)
	c.y = 0.0
	c = c.normalized() if c.length() > 1.0 else Vector3(randf() - 0.5, 0, randf() - 0.5).normalized()
	global_position = Vector3(tp.x, 0.05, tp.z) + c * 7.5
	_blink_cd = randf_range(4.0, 6.0)
	Fx.burst(fx_parent, _chest(), _col(), 16, 5.0, 0.16)
	Fx.ring(fx_parent, global_position, 2.0, _col(), 0.3)
	Sfx.play("boom", 1.8, -8.0)


func _st_strike(_delta: float) -> void:
	match _attack:
		"lunge":
			_move_dir(_strike_dir, 7.0)
			if not _did_hit and _flat_to_target().length() < radius + 1.2:
				_did_hit = true
				_deal()
				Fx.burst(fx_parent, _chest() + _strike_dir, _col(), 8, 4.0, 0.12)
		"dash":
			_move_dir(_strike_dir, 16.0)
			if not _did_hit and _flat_to_target().length() < radius + 1.1:
				_did_hit = true
				_deal(1.3)
				Fx.burst(fx_parent, _chest(), Color(1, 0.9, 0.9), 12, 5.0, 0.12)
		"charge":
			_move_dir(_strike_dir, 15.0)
			if not _did_hit and _flat_to_target().length() < radius + 1.3:
				_did_hit = true
				_deal(1.5)
				request_shake.emit(0.5)
				_sfx("boss_crash", 1.0, 1.0)
		_:
			_move_dir(Vector3.ZERO, 0.0)
	if _t <= 0.0:
		var rec := _rec_len
		if _attack == "charge":
			rec += 0.6                     # terengah setelah menyeruduk: celah untuk membalas
			request_shake.emit(0.3)
		_cooldown = 0.3
		_set_state("recover", rec)


# ---------------------------------------------------------------- animasi
func _animate(delta: float) -> void:
	if state == "spawn" or rig == null:
		return
	var moved := (global_position - _prev_pos)
	moved.y = 0.0
	var spd := moved.length() / maxf(delta, 0.001)
	_prev_pos = global_position
	var s01 := 0.0
	if state == "strike" and _attack in ["lunge", "dash", "charge"]:
		s01 = 1.0
	elif state in ["chase", "recover"] and spd > 0.3:
		s01 = clampf(spd / 4.6, 0.0, 1.0)
	rig.set_move(s01, clampf(0.7 + spd * 0.12, 0.7, 1.4))
	if kind == "uranos":
		_visual.position.y = 0.12 + sin(_anim_t * 2.2) * 0.1       # melayang tipis
