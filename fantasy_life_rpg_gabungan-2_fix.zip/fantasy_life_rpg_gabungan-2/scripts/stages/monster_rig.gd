class_name MonsterRig
extends Node3D
## Pembungkus cave_monster_rigged.glb (Godot 4.x). Animasi diimpor dari GLB ke AnimationPlayer.
## Animasi: Idle, Walking, Attack, HitReaction, Death, Roar.

signal animation_finished_state(state: StringName)

const STATES := {
	&"idle": &"Idle", &"walk": &"Walking", &"attack": &"Attack",
	&"hit": &"HitReaction", &"death": &"Death", &"roar": &"Roar",
}
const LOOPING := [&"Idle", &"Walking"]

var skeleton: Skeleton3D
var anim_player: AnimationPlayer
var state: StringName = &"idle"

func _ready() -> void:
	skeleton = _find(self, "Skeleton3D") as Skeleton3D
	anim_player = _find(self, "AnimationPlayer") as AnimationPlayer
	if skeleton == null or anim_player == null:
		push_error("MonsterRig: Skeleton3D/AnimationPlayer tidak ditemukan. Cek import cave_monster_rigged.glb")
		return
	for lib_name in anim_player.get_animation_library_list():
		var lib := anim_player.get_animation_library(lib_name)
		for a in lib.get_animation_list():
			lib.get_animation(a).loop_mode = Animation.LOOP_LINEAR if a in LOOPING else Animation.LOOP_NONE
	anim_player.animation_finished.connect(_on_finished)
	play_state(&"idle")

func play_state(s: StringName, blend: float = 0.15) -> void:
	if anim_player == null or not STATES.has(s):
		return
	state = s
	anim_player.play(_resolve(STATES[s]), blend)

## Simpan semua animasi sebagai satu AnimationLibrary (.res) untuk dipakai ulang.
func save_library(path: String = "res://assets/boss/monster_animations.res") -> Error:
	var out := AnimationLibrary.new()
	for lib_name in anim_player.get_animation_library_list():
		var lib := anim_player.get_animation_library(lib_name)
		for a in lib.get_animation_list():
			out.add_animation(a, lib.get_animation(a).duplicate())
	return ResourceSaver.save(out, path)

func _on_finished(anim_name: StringName) -> void:
	var short := StringName(String(anim_name).get_file())
	if short in [&"Attack", &"HitReaction", &"Roar"]:
		play_state(&"idle", 0.25)
	animation_finished_state.emit(short)

func _resolve(n: StringName) -> StringName:
	for lib_name in anim_player.get_animation_library_list():
		var full := StringName(n if lib_name == &"" else "%s/%s" % [lib_name, n])
		if anim_player.has_animation(full):
			return full
	return n

func _find(root: Node, cls: String) -> Node:
	if root.get_class() == cls:
		return root
	for c in root.get_children():
		var r := _find(c, cls)
		if r:
			return r
	return null
