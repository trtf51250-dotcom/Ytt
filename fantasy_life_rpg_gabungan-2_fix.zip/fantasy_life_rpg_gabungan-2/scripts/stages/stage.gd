class_name Stage
extends Node3D
## Stage petualangan: arena bertema, gelombang monster (dari StageData.waves), bos opsional, party 4 karakter (ganti lewat portret / tombol 1-4),
## ramuan, jeda, hasil (GameState.finish_stage) dan kembali ke lobi. Semua monster dikalahkan -> menang; seluruh party pingsan -> kalah.

enum S { INTRO, FIGHT, ENDED }

var sd: StageData
var arena: StageArena
var daynight: DayNight
var player: Player
var cam: CameraRig
var fx_root: Node3D
var enemies_root: Node3D
var ui: CanvasLayer
var hud: StageHud
var touch: TouchControls
var party_state: Array = []
var active := 0
var state := S.INTRO
var wave_idx := -1
var boss_spawned := false
const WAVE_COUNT_MULT := 1.3        # pengali jumlah musuh per gelombang (mode SUSAH)
var boss: Enemy
var kills := 0
var time := 0.0
var fainted := 0
var autoplay := false
var _switch_cd := 0.0
var _potion_cd := 0.0
var _wave_timer := -1.0
var _pending := 0
var _hud_timer := 0.0
var _paused := false
var _ended_win := false
var coop: CoopSync                  # non-null saat main co-op (host / client)
var _stage_chest: Node3D
## --- mode wilayah jelajah (stage berawalan f_): tanpa gelombang, monster muncul terus, peti & area rahasia, gerbang pulang ke lobi
const FIELD_SCALE := 2.3
var field := false
var field_chests: Array = []          # {id,pos,tier,name,hidden,node}
var field_zones: Array = []           # {id,name,pos,r,diamonds}
var field_gate := Vector2.ZERO
var _field_t := 3.0
const FIELD_GOAL := 12              # monster yang harus dikalahkan agar wilayah jelajah dianggap selesai (langkah Adventure)
var _field_kills := 0
var _field_node: Node3D
var _gate_armed := false
var _gate_hold := 0.0
var _field_scan_t := 0.0
var pvp := false                    # arena PVP (id stage berawalan "pvp_")
var all_down := false               # seluruh party kita pingsan (co-op: menunggu / menonton rekan)


func _ready() -> void:
	InputSetup.ensure()
	WorldMats.reset()
	if _arg("stage") != "":
		GameState.current_stage_id = _arg("stage")
	sd = Data.stage(GameState.current_stage_id)
	if sd == null:
		sd = Data.stage(Data.stage_order[0])
		GameState.current_stage_id = sd.id
	field = sd.id.begins_with("f_")
	arena = StageArena.new()
	arena.name = "Arena"
	if field:
		arena.R_SCALE = FIELD_SCALE            # wilayah jelajah jauh lebih luas dari arena stage
	add_child(arena)
	arena.build(sd.theme)
	daynight = DayNight.new()
	daynight.fixed_hour = arena.hour
	add_child(daynight)
	daynight.env.fog_density = arena.fog
	Sfx.music(sd.music if sd.theme != "boss" else "music_boss")
	fx_root = Node3D.new()
	fx_root.name = "Fx"
	add_child(fx_root)
	enemies_root = Node3D.new()
	enemies_root.name = "Enemies"
	add_child(enemies_root)
	_spawn_player()
	cam = CameraRig.new()
	cam.name = "CameraRig"
	add_child(cam)
	cam.rim_radius = arena.radius + 0.5      # dekat tepi arena kamera naik supaya tidak tertutup tajuk pohon
	cam.target = player
	cam.snap_to_target()
	cam.yaw = 0.0
	_build_ui()
	_build_minimap_and_chest()
	Quality.apply(get_viewport(), daynight.sun, cam.cam, daynight.env)
	if sd.theme in ["meadow", "forest"]:
		SkyLife.make(self, daynight, cam.cam, Vector3.ZERO, 100.0, 0.0, arena.radius * 3.0, false)     # awan & bayangan awan hanya di stage luar ruangan
	_check_bot()
	if Net.coop_active():
		pvp = sd.id.begins_with("pvp_")
		coop = CoopSync.new()
		coop.name = "Coop"
		add_child(coop)
		coop.setup(self)
		coop.announce_ready()
		hud.banner(sd.display_name, UiTheme.GOLD, 1.6)
		if coop.host:
			await coop.wait_ready(30.0 if pvp else 12.0)
			if pvp:
				coop.pvp_start()
			else:
				_wave_timer = 2.2
		return
	if field:
		hud.banner(sd.display_name, UiTheme.GOLD, 2.0)
		return
	await StoryPlayer.play(self, Story.for_stage(sd.id, "intro"))
	hud.banner(sd.display_name, UiTheme.GOLD, 1.6)
	_wave_timer = 2.2


## Minimap arena (musuh/bos/peti) dan satu peti medan tersembunyi di tepi arena (bukan di arena PVP).
func _build_minimap_and_chest() -> void:
	if sd.id.begins_with("pvp_"):
		return
	var mm := Minimap.new()
	mm.name = "Minimap"
	mm.mode = "stage"
	mm.follow = false
	mm.stage = self
	mm.player = player
	mm.cam = cam
	mm.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	mm.offset_left = -152
	mm.offset_right = -10
	mm.offset_top = 92
	mm.offset_bottom = 234
	mm.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(mm)
	hud.stage_minimap = mm
	if field:
		mm.follow = true               # arena luas: minimap mengikuti pemain
		mm.rotate_with_cam = false
		mm.zoom = 1.0
		mm.offset_top = 92
		mm.offset_bottom = 244
		mm.offset_left = -162
		_build_field()
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(sd.id)
	var a := rng.randf() * TAU
	var spot := free_spot(Vector3(cos(a) * arena.radius * 0.62, 0.0, sin(a) * arena.radius * 0.62), 0.9)
	var ch := ExploreWorld.build_chest("silver")
	ch.name = "StageChest"
	ch.position = spot
	ch.add_to_group("stage_chests")
	add_child(ch)
	_stage_chest = ch


# ---------------------------------------------------------------- wilayah jelajah
func _build_field() -> void:
	_field_node = Node3D.new()
	_field_node.name = "FieldObjects"
	add_child(_field_node)
	var R: float = arena.radius
	for c: Dictionary in Explore.field_chests(sd.id, R):
		var want: Vector2 = c["pos"]
		var spot := free_spot(Vector3(want.x, 0, want.y), 0.9)
		c["pos"] = Vector2(spot.x, spot.z)
		var n := ExploreWorld.build_chest(str(c["tier"]))
		n.name = "FChest_" + str(c["id"])
		n.position = spot
		_field_node.add_child(n)
		c["node"] = n
		field_chests.append(c)
		if Explore.is_opened(c["id"]):
			(n.get_node("LidPivot") as Node3D).rotation.x = -1.2
			(n.get_node("Spark") as Node3D).visible = false
	for z: Dictionary in Explore.field_zones(sd.id, R):
		field_zones.append(z)
	# gerbang pulang ke lobi
	var gp := Explore.gate_pos(R)
	var gs := free_spot(Vector3(gp.x, 0, gp.y), 1.6)
	field_gate = Vector2(gs.x, gs.z)
	var k := MeshKit.new(21)
	k.ring(Vector3(0, 0.05, 0), 1.0, 1.9, 24, MeshKit.T_CRYSTAL, MeshKit.glow(Color(0.5, 0.85, 1.0), 0.95))
	k.disc(Vector3(0, 0.04, 0), 1.0, 20, MeshKit.T_MARBLE, MeshKit.glow(Color(0.35, 0.6, 1.0), 0.6))
	for sx in [-2.2, 2.2]:
		k.cylinder(Vector3(sx, 0, 0), 0.4, 0.32, 3.6, 8, MeshKit.T_MARBLE, Color(0.78, 0.82, 0.95))
		k.crystal(Vector3(sx, 3.6, 0), 0.3, 1.1, Color(0.5, 0.85, 1.0), 0.9, 5, 0.0)
	var gm := MeshInstance3D.new()
	gm.name = "Gate"
	var m := k.build()
	k.apply_materials(m)
	gm.mesh = m
	gm.position = gs
	_field_node.add_child(gm)
	var lb := Label3D.new()
	lb.text = "Gerbang Lobi"
	lb.font_size = 44
	lb.pixel_size = 0.01
	lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lb.shaded = false
	lb.modulate = Color(0.8, 0.93, 1.0)
	lb.outline_size = 10
	lb.outline_modulate = Color(0.05, 0.08, 0.2, 0.95)
	lb.position = gs + Vector3(0, 4.6, 0)
	_field_node.add_child(lb)


func _field_target() -> int:
	return [5, 7, 9][clampi(Quality.level(), 0, 2)]


func _field_spawn() -> void:
	var kinds: Array = []
	if not sd.waves.is_empty():
		kinds = (sd.waves[0] as Dictionary).keys()
	if kinds.is_empty():
		return
	var kind: String = kinds[randi() % kinds.size()]
	for attempt in 16:
		var a := randf() * TAU
		var r := arena.radius * randf_range(0.18, 0.88)
		var p := Vector3(cos(a) * r, 0.05, sin(a) * r)
		var d := Vector2(p.x - player.global_position.x, p.z - player.global_position.z).length()
		if d < 14.0 or Vector2(p.x - field_gate.x, p.z - field_gate.y).length() < 9.0 or spot_blocked(p, 0.6):
			continue
		var e := _spawn_enemy(kind, p)
		if randf() < 0.12 and kind != "slime_mini":
			e.make_elite()
		return


func _update_field(delta: float) -> void:
	if state == S.ENDED or player.dead:
		return
	_field_t -= delta
	if _field_t <= 0.0:
		_field_t = 3.5
		if get_tree().get_nodes_in_group("enemies").size() < _field_target():
			_field_spawn()
	var pp := player.global_position
	var p2 := Vector2(pp.x, pp.z)
	# penemuan area rahasia / peti
	_field_scan_t -= delta
	if _field_scan_t <= 0.0:
		_field_scan_t = 0.25
		for m in Explore.scan_defs(p2, field_chests, field_zones, []):
			hud.banner(m, Color(0.7, 0.9, 1.0), 2.6)
			Sfx.play("pickup")
	# buka peti saat didekati
	for c: Dictionary in field_chests:
		if Explore.is_opened(c["id"]):
			continue
		if p2.distance_to(c["pos"]) <= 2.0:
			var r := Explore.open_chest(c["id"])
			if r.is_empty():
				continue
			var n: Node3D = c["node"]
			(n.get_node("LidPivot") as Node3D).rotation.x = -1.2
			(n.get_node("Spark") as Node3D).visible = false
			Sfx.play("chest")
			hud.banner("%s dibuka! %s" % [c["name"], Explore.reward_text(r)], Color(1, 0.85, 0.4), 3.0)
	# gerbang: harus menjauh dulu setelah muncul, lalu berdiri di gerbang ~1 detik
	var dg := p2.distance_to(field_gate)
	if dg > 6.0:
		_gate_armed = true
	if _gate_armed and dg < 2.2:
		_gate_hold += delta
		if _gate_hold > 1.0:
			_gate_armed = false
			hud.banner("Kembali ke lobi...", Color(0.7, 0.9, 1.0), 1.2)
			_quit_to_lobby()
	else:
		_gate_hold = 0.0


func _field_revive() -> void:
	if state == S.ENDED:
		return
	for ps: Dictionary in party_state:
		ps["dead"] = false
		ps["hp"] = float(ps["max"]) * 0.5
	var ps_a: Dictionary = party_state[active]
	player.revive(false)
	player.max_hp = ps_a["max"]
	player.hp = ps_a["hp"]
	player.global_position = Vector3(0, 0.1, arena.radius * 0.72)
	player.velocity = Vector3.ZERO
	player.control_enabled = true
	_gate_armed = false
	cam.snap_to_target()
	hud.banner("Bangkit kembali (HP 50%)", Color(0.6, 1.0, 0.7), 1.6)


func _update_stage_chest() -> void:
	if _stage_chest == null or not is_instance_valid(_stage_chest) or player.dead or state == S.ENDED:
		return
	var pp := player.global_position
	if Vector2(pp.x - _stage_chest.global_position.x, pp.z - _stage_chest.global_position.z).length() > 2.0:
		return
	var r := Explore.open_stage_chest(sd.id, sd.recommended_level)
	(_stage_chest.get_node("LidPivot") as Node3D).rotation.x = -1.2
	(_stage_chest.get_node("Spark") as Node3D).visible = false
	_stage_chest.remove_from_group("stage_chests")
	_stage_chest = null
	Sfx.play("chest")
	hud.banner("Peti medan! " + Explore.reward_text(r), Color(1, 0.85, 0.4), 2.4)


func _spawn_player() -> void:
	var ids: Array = GameState.party.duplicate()
	if ids.is_empty():
		ids = ["ren"]
	for id in ids:
		var st: Dictionary = GameState.char_stats(id)
		party_state.append({"id": id, "hp": st["hp"], "max": st["hp"], "dead": false, "skill_cd": 0.0})
	player = Player.new()
	player.name = "Player"
	add_child(player)
	player.set_character(ids[0])
	player.global_position = Vector3(0, 0.1, arena.radius * (0.72 if field else 0.35))
	player.facing = PI
	player.add_to_group("player")
	player.swing.connect(_on_swing)
	player.action_started.connect(_on_player_action)
	player.died.connect(_on_player_died)


func _build_ui() -> void:
	ui = CanvasLayer.new()
	ui.layer = 10
	ui.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(ui)
	hud = StageHud.new()
	ui.add_child(hud)
	hud.setup_party(party_state.map(func(p): return p["id"]))
	touch = TouchControls.new()
	touch.ult_visible = true
	ui.add_child(touch)
	touch.interact_visible = false
	touch.touch_enabled = DisplayServer.is_touchscreen_available() or bool(GameState.setting("force_touch")) or _arg("touch") != ""
	hud.switch_requested.connect(func(i): _switch_to(i))
	hud.potion_requested.connect(_use_potion)
	hud.pause_requested.connect(_toggle_pause)
	hud.resume_requested.connect(_toggle_pause)
	hud.retry_requested.connect(_retry)
	hud.quit_requested.connect(_quit_to_lobby)
	GameState.changed.connect(func(kind: String):
		if kind == "settings":
			cam.apply_settings()
			Quality.apply(get_viewport(), daynight.sun, cam.cam, daynight.env)
			touch.layout())


# ---------------------------------------------------------------- loop
func _physics_process(delta: float) -> void:
	_update_stage_chest()
	if field:
		_update_field(delta)
	_switch_cd = maxf(_switch_cd - delta, 0.0)
	_potion_cd = maxf(_potion_cd - delta, 0.0)
	player.cam_yaw = cam.yaw
	if state != S.ENDED:
		time += delta
	if player.control_enabled and not player.dead and state != S.ENDED and not autoplay:
		player.move_input = InputSetup.keyboard_vector()
		if Input.is_action_pressed("attack"):
			player.do_attack()
		if Input.is_action_just_pressed("skill"):
			player.do_skill()
		if Input.is_action_just_pressed("ult"):
			try_ult()
		if Input.is_action_just_pressed("dodge"):
			player.do_dodge()
		for i in 4:
			if Input.is_action_just_pressed("switch_%d" % (i + 1)):
				_switch_to(i)
	elif player.dead or state == S.ENDED:
		if not autoplay:
			player.move_input = Vector2.ZERO
	# alur gelombang
	if state != S.ENDED and _wave_timer >= 0.0:
		_wave_timer -= delta
		if _wave_timer < 0.0:
			_advance_wave()
	_hud_timer -= delta
	if _hud_timer <= 0.0:
		_hud_timer = 0.1
		_update_hud()


func _update_hud() -> void:
	_save_active()
	hud.update_party(party_state, active)
	var remaining := get_tree().get_nodes_in_group("enemies").size() + _pending
	if field:
		var c := Explore.counts()
		hud.set_field(sd.display_name, "Musuh sekitar: %d   Peti: %d/%d" % [remaining, c["chests"], c["chests_total"]])
	elif not pvp:
		hud.set_wave(clampi(wave_idx + 1, 1, maxi(sd.waves.size(), 1)), sd.waves.size(), remaining, boss_spawned and wave_idx >= sd.waves.size())
	if boss != null and is_instance_valid(boss) and not boss.dead:
		hud.set_boss(Enemy.KINDS[boss.kind]["name"], boss.hp, boss.max_hp, true)
	else:
		hud.set_boss("", 0, 1, false)
	var choice := _potion_choice()
	var total := 0
	for id in GameState.inventory:
		var it := Data.item(id)
		if it != null and it.type == "potion":
			total += GameState.item_count(id)
	hud.set_potion(total, Data.item(choice).display_name if choice != "" else "Ramuan", _potion_cd)
	touch.set_cooldown("skill", player.skill_cd, player.skill_cd_max)
	touch.set_cooldown("ult", 1.0 if _ult_used.has(player.char_id) else 0.0, 1.0)
	touch.set_cooldown("dodge", player.dodge_cd, 0.75)
	touch.interact_ready = false
	cam.blocked_rects = hud.blocked_rects() + touch.blocked_rects()
	cam.enabled = not _paused and state != S.ENDED


func _save_active() -> void:
	var ps: Dictionary = party_state[active]
	ps["hp"] = player.hp
	ps["max"] = player.max_hp
	ps["skill_cd"] = player.skill_cd


# ---------------------------------------------------------------- gelombang
func _advance_wave() -> void:
	_wave_timer = -1.0
	if wave_idx + 1 < sd.waves.size():
		_start_wave(wave_idx + 1)
	elif sd.boss != "" and not boss_spawned:
		_start_boss()
	else:
		_finish(true)


func _start_wave(i: int) -> void:
	wave_idx = i
	state = S.FIGHT
	var w: Dictionary = sd.waves[i]
	var list: Array = []
	for k in w:
		for n in ceili(float(int(w[k])) * WAVE_COUNT_MULT):      # mode SUSAH: lebih banyak musuh per gelombang
			list.append(str(k))
	list.shuffle()
	hud.banner("Gelombang %d / %d" % [i + 1, sd.waves.size()], UiTheme.GOLD, 1.2)
	if coop != null:
		coop.event("wave", [i])
	_pending += list.size()
	for j in list.size():
		_spawn_delayed(list[j], j * 0.22 + 0.4)


func _spawn_delayed(kind: String, delay: float) -> void:
	await get_tree().create_timer(delay).timeout
	if coop == null and kind != "slime_mini":
		while state != S.ENDED and get_tree().get_nodes_in_group("enemies").size() >= Quality.enemy_alive_cap():
			await get_tree().create_timer(0.35).timeout       # HP kentang/menengah: tunggu giliran (monster terhitung _pending sehingga gelombang tidak selesai lebih awal)
	_pending = maxi(_pending - 1, 0)
	if state == S.ENDED:
		return
	var ne := _spawn_enemy(kind, _spawn_pos())
	# sebagian musuh gelombang menjadi ELIT (peluang naik tiap gelombang); bos & musuh kecil tidak
	if coop == null or coop.host:
		var chance := 0.2 + 0.07 * float(wave_idx)
		if not ne.is_boss and kind != "slime_mini" and randf() < minf(chance, 0.5):
			ne.make_elite()


## true bila bola (jari-jari r) di titik p menabrak benda padat (pohon, batu, tiang, bangunan). Dipakai agar musuh tak muncul di dalam benda.
func spot_blocked(p: Vector3, r: float = 0.5) -> bool:
	var space := get_world_3d().direct_space_state
	if space == null:
		return false
	var q := PhysicsShapeQueryParameters3D.new()
	var sp := SphereShape3D.new()
	sp.radius = r
	q.shape = sp
	q.transform = Transform3D(Basis(), p + Vector3(0, r + 0.3, 0))
	q.collision_mask = 1
	return not space.intersect_shape(q, 1).is_empty()


## Cari titik bebas terdekat dari `want` (spiral keluar); bila gagal kembalikan `want`.
func free_spot(want: Vector3, r: float = 0.5) -> Vector3:
	if not spot_blocked(want, r):
		return want
	for ring in range(1, 9):
		for k in 8:
			var a := k * TAU / 8.0 + ring * 0.4
			var c := want + Vector3(cos(a), 0, sin(a)) * ring * 0.9
			if Vector2(c.x, c.z).length() < arena.radius * 0.92 and not spot_blocked(c, r):
				return c
	return want


## Titik muncul musuh acak di sabuk 55-88% radius (bukan 6 titik tetap): jauh dari pemain, tidak di dalam benda padat.
## Cadangan: titik tetap di tepi (StageArena.spawn_points) yang dipastikan bebas lewat free_spot.
func _spawn_pos() -> Vector3:
	var pp := Vector2(player.global_position.x, player.global_position.z)
	for attempt in 24:
		var a := randf() * TAU
		var r := arena.radius * randf_range(0.55, 0.88)
		var p := Vector3(cos(a) * r, 0.05, sin(a) * r)
		var far := 11.0 if attempt < 16 else 8.0
		if pp.distance_to(Vector2(p.x, p.z)) > far and not spot_blocked(p, 0.6):
			return p
	var pts: Array = arena.spawn_points()
	pts.shuffle()
	var best: Vector3 = pts[0]
	var best_d := -1.0
	for g: Vector3 in pts:
		var d := pp.distance_to(Vector2(g.x, g.z))
		if d > best_d:
			best_d = d
			best = g
	return free_spot(_jitter_gate(best), 0.55)


func _jitter_gate(g: Vector3) -> Vector3:
	var tang := Vector3(-g.z, 0.0, g.x).normalized()
	return g + tang * randf_range(-1.5, 1.5)


func _spawn_enemy(kind: String, pos: Vector3, puppet: bool = false) -> Enemy:
	var e: Enemy = HumanoidEnemy.new() if bool(Enemy.KINDS[kind].get("humanoid", false)) else Enemy.new()
	e.puppet = puppet
	enemies_root.add_child(e)
	e.setup(kind, sd.recommended_level, player, fx_root)
	e.arena_radius = arena.radius
	e.global_position = Vector3(pos.x, 1.7 if e.flying else 0.05, pos.z)
	e.died.connect(_on_enemy_died)
	e.hit_player.connect(_on_enemy_hit)
	e.request_spawn.connect(func(k: String, p: Vector3): _spawn_enemy(k, p))
	e.request_shake.connect(func(a: float): cam.shake(a))
	if coop != null:
		e.hit_ghost.connect(coop.on_ghost_hit)
		if coop.host and not puppet:
			coop.on_enemy_spawned(e)
	return e


func _start_boss() -> void:
	boss_spawned = true
	wave_idx = sd.waves.size()
	state = S.FIGHT
	hud.banner("BOS!", Color(1, 0.45, 0.4), 1.8)
	boss = _spawn_enemy(sd.boss, free_spot(Vector3(0, 0, -arena.radius * (0.3 if sd.boss in ["wither_god", "uranos", "chain_king"] else 0.55)), 1.0))
	_boss_intro(boss)
	if coop != null:
		coop.event("banner", ["BOS!", "ff7366"])


## Efek pembuka bos (suara, kamera, banner fase) — dipakai host & client co-op.
func _boss_intro(b: Enemy) -> void:
	cam.shake(0.5)
	Sfx.play("boss_roar" if b.kind in ["cave_beast", "wither_god", "uranos", "chain_king"] else "roar", 1.0 if b.kind == "cave_beast" else (0.75 if b.kind == "wither_god" else 0.7), 2.0)
	if b.kind in ["uranos", "chain_king"]:
		# bos humanoid: kamera sedikit mundur & ikut memfokuskan bos agar serangan jarak jauhnya selalu terlihat
		create_tween().tween_property(cam, "distance", maxf(cam.distance, 16.0), 1.0)
		cam.focus_node = b
		cam.focus_bias = 0.28
		cam.focus_lift = 1.6
	if b.kind == "wither_god":
		# bos melayang & tinggi: mundurkan kamera sedikit agar seluruh badannya terlihat
		create_tween().tween_property(cam, "distance", maxf(cam.distance, 17.5), 1.0)
		cam.focus_node = b
		cam.focus_bias = 0.3
		cam.focus_lift = 3.4
	b.phase_changed.connect(func(_p: int): hud.banner(str(Enemy.KINDS[b.kind].get("phase_text", "Bos mengamuk!")), Color(1, 0.6, 0.3), 1.4))


func _on_enemy_died(e: Enemy) -> void:
	kills += 1
	GameState.add_kills(e.kind, 1)
	if field:
		GameState.add_gold(2 + sd.recommended_level)
		GameState.add_exp(4 + sd.recommended_level * 2)
		_field_progress()
		return
	# Musuh sudah keluar dari grup "enemies" sebelum sinyal dikirim (lihat Enemy._die).
	if coop != null and not coop.host:
		return         # client co-op: alur gelombang diatur host
	if get_tree().get_nodes_in_group("enemies").is_empty() and _pending == 0 and state != S.ENDED:
		_wave_timer = 1.5


# ---------------------------------------------------------------- pertarungan pemain
func _hit_enemy(e: Enemy, dmg: float, knock: float, col: Color) -> void:
	var cdat: CharacterData = player.data
	var crit := randf() < (cdat.crit_chance if cdat else 0.12)
	var pen := cdat.armor_pen if cdat else 0.0
	var final := int(dmg * randf_range(0.9, 1.1) * (1.5 if crit else 1.0)) - int(e.defense * (1.0 - pen))
	final = maxi(final, 1)
	e.take_damage(final, player.global_position, knock)
	if coop != null and not coop.host and e.puppet:
		Net._hit.rpc_id(1, e.net_id, final, player.global_position, knock, crit)
	var away := e.global_position - player.global_position
	away.y = 0.0
	var adir := (away.normalized() + Vector3(0, 0.35, 0)).normalized() if away.length() > 0.01 else Vector3.UP
	var h := 3.8 if e.is_boss else (2.2 if e.flying else e.radius * 2.0 + 0.7)
	Fx.float_text(fx_root, e.global_position + Vector3(0, h, 0), ("%d!" % final) if crit else str(final), Color(1, 0.9, 0.3) if crit else Color(1, 1, 1), 1.25 if crit else 1.0)
	var hp_ := e.global_position + Vector3(0, h * 0.5, 0)
	CharFx.hit(fx_root, player.char_id, hp_, adir, col, crit)      # percikan khas karakter, searah pukulan
	if crit:
		Fx.ring(fx_root, e.global_position + Vector3(0, 0.1, 0), 1.3, Color(1, 0.9, 0.4), 0.22)
		cam.shake(0.05)
	if e.is_boss:
		cam.shake(0.06)
	# hit-stop: jeda sepersekian detik saat benturan kuat (kritikal / skill / bos) -> pukulan terasa berbobot
	if crit:
		_hit_stop(0.075)
	elif knock >= 6.0:
		_hit_stop(0.055)
	elif e.is_boss:
		_hit_stop(0.03)


var _hs_active := false
var _hs_base := 1.0


## Perlambat waktu sangat singkat (tidak terpengaruh time_scale). Bisa dimatikan di Pengaturan (hit_stop).
func _hit_stop(dur: float) -> void:
	if _hs_active or not bool(GameState.setting("hit_stop")) or Engine.time_scale <= 0.0 or get_tree().paused:
		return
	_hs_active = true
	_hs_base = Engine.time_scale
	Engine.time_scale = _hs_base * 0.06
	await get_tree().create_timer(dur, true, false, true).timeout
	_restore_time()


func _restore_time() -> void:
	if _hs_active:
		Engine.time_scale = _hs_base
		_hs_active = false


func _exit_tree() -> void:
	_restore_time()


func _melee(origin: Vector3, dir: Vector3, rng: float, half_deg: float, dmg: float, knock: float, col: Color) -> void:
	var half := deg_to_rad(half_deg)
	for e: Node in get_tree().get_nodes_in_group("enemies"):
		var en := e as Enemy
		if en == null or en.dead:
			continue
		var to := en.global_position - player.global_position
		to.y = 0.0
		var dist := to.length()
		if dist > rng + en.radius:
			continue
		if half_deg < 179.0:
			var ang := absf(dir.signed_angle_to(to, Vector3.UP))
			if ang > half + atan2(en.radius, maxf(dist, 0.2)):
				continue
		_hit_enemy(en, dmg, knock, col)
	if pvp:
		for g: Node in get_tree().get_nodes_in_group("ghost"):
			var gh := g as CoopGhost
			if gh == null or gh.dead or gh.all_down:
				continue
			var to2 := gh.global_position - player.global_position
			to2.y = 0.0
			var dist2 := to2.length()
			if dist2 > rng + gh.hit_radius:
				continue
			if half_deg < 179.0:
				var ang2 := absf(dir.signed_angle_to(to2, Vector3.UP))
				if ang2 > half + atan2(gh.hit_radius, maxf(dist2, 0.2)):
					continue
			_hit_ghost(gh, dmg, knock, col)


const PVP_SCALE := 0.5          # damage antar pemain = damage ke musuh x skala ini


## Serangan mengenai pemain lain (PVP). Damage dihitung di penyerang, lalu dikirim ke korban lewat host.
func _hit_ghost(g: CoopGhost, dmg: float, knock: float, col: Color) -> void:
	if coop == null or not coop.pvp_live or g.dead or g.all_down:
		return
	var cdat: CharacterData = player.data
	var crit := randf() < (cdat.crit_chance if cdat else 0.12)
	var final := maxi(int(dmg * PVP_SCALE * randf_range(0.9, 1.1) * (1.5 if crit else 1.0)), 1)
	coop.send_pvp_hit(g.peer_id, final, player.global_position)
	g.play("hurt")
	var away := g.global_position - player.global_position
	away.y = 0.0
	var adir := (away.normalized() + Vector3(0, 0.35, 0)).normalized() if away.length() > 0.01 else Vector3.UP
	Fx.float_text(fx_root, g.global_position + Vector3(0, 2.4, 0), ("%d!" % final) if crit else str(final), Color(1, 0.9, 0.3) if crit else Color(1, 0.7, 0.4), 1.25 if crit else 1.0)
	CharFx.hit(fx_root, player.char_id, g.global_position + Vector3(0, 1.0, 0), adir, col, crit)
	if crit:
		_hit_stop(0.06)


func _hit_any(t: Node, dmg: float, knock: float, col: Color) -> void:
	if t is Enemy:
		_hit_enemy(t as Enemy, dmg, knock, col)
	elif t is CoopGhost and pvp:
		_hit_ghost(t as CoopGhost, dmg, knock, col)


func _shoot(kind: String, origin: Vector3, dir: Vector3, dmg: float, speed: float, rng: float, col: Color) -> void:
	var p := Projectile.make(kind, col)
	p.target_group = "enemies"
	CharFx.decorate_projectile(p, kind, player.char_id, col)
	fx_root.add_child(p)
	p.launch(Vector3(origin.x, 1.0, origin.z) + dir * 0.7, dir, speed, rng)
	p.include_ghosts = pvp
	p.on_hit = func(t): _hit_any(t, dmg, 3.0, col)
	Sfx.play("shoot", 1.2 if kind == "arrow" else 0.9, -4.0)


## Awal skill: efek persiapan (antisipasi). Nova Bintang = lingkaran sihir bintang di bawah pemain.
func _on_player_action(kind: String) -> void:
	if kind != "skill" or player == null or player.data == null:
		return
	var cd: CharacterData = player.data
	if cd.skill_kind == "nova" and cd.id != "wenyu":
		var col := cd.accent.lerp(Color(0.4, 0.8, 1.0), 0.65)
		Fx.magic_circle(fx_root, player.global_position, cd.skill_range * 1.05, col, player.rig.action_impact("skill"))


func _on_swing(kind: String, origin: Vector3, dir: Vector3) -> void:
	if player.dead or state == S.ENDED or player.data == null:
		return
	var cd: CharacterData = player.data
	var atk := float(GameState.char_stats(player.char_id)["atk"])
	var col := cd.accent.lightened(0.35)
	var yaw := atan2(dir.x, dir.z)
	var pos := player.global_position
	if kind == "attack":
		var dmg := atk * cd.attack_mult
		match cd.attack_kind:
			"arc":
				CharFx.attack_slash(fx_root, cd.id, pos, yaw, cd.attack_range, col, player.swing_idx, false)
				_melee(origin, dir, cd.attack_range, 75.0, dmg, 3.5, col)
			"dagger":
				# belati: pukulan 1-2 cepat & sempit, penutup kombo lebar + dorongan keras
				if player.swing_final:
					var fd := dmg * cd.finisher_mult
					CharFx.attack_slash(fx_root, cd.id, pos, yaw, cd.attack_range, col, player.swing_idx, true)
					_melee(origin, dir, cd.attack_range * 1.15, 120.0, fd, 7.0, col)
					cam.shake(0.07)
				else:
					CharFx.attack_slash(fx_root, cd.id, pos, yaw, cd.attack_range, col, player.swing_idx, false)
					_melee(origin, dir, cd.attack_range, 55.0, dmg, 2.0, col)
			"smash":
				CharFx.attack_smash(fx_root, cd.id, pos, yaw, cd.attack_range, col, player.swing_idx)
				_melee(origin, dir, cd.attack_range, 100.0, dmg, 6.0, col)
				cam.shake(0.08)
			"bolt":
				_shoot("bolt", origin, dir, dmg, 15.0, 13.0, col)
			"arrow":
				_shoot("arrow", origin, dir, dmg, 24.0, 17.0, col)
	else:
		var dmg2 := atk * cd.skill_mult
		match cd.skill_kind:
			"cone":
				CharFx.skill_cone(fx_root, cd.id, pos, yaw, cd.skill_range, col)
				_melee(origin, dir, cd.skill_range, 85.0, dmg2, 7.0, col)
			"dash_cut":
				# menerjang menembus musuh: dua tebasan silang beruntun (total = skill_mult)
				CharFx.skill_dash(fx_root, cd.id, pos, yaw, cd.skill_range, col, 0)
				_melee(origin, dir, cd.skill_range, 70.0, dmg2 * 0.45, 3.0, col)
				await get_tree().create_timer(0.1).timeout
				if state != S.ENDED and is_instance_valid(player) and not player.dead:
					var p2 := player.global_position
					CharFx.skill_dash(fx_root, cd.id, p2, yaw, cd.skill_range, col, 1)
					_melee(p2 + Vector3(0, 0.9, 0), dir, cd.skill_range, 70.0, dmg2 * 0.55, 8.0, col)
					cam.shake(0.12)
			"iai":
				# cabut pedang: tebasan lurus sangat panjang, lalu tebasan lebar penutup (total = skill_mult)
				CharFx.skill_iai(fx_root, cd.id, pos, yaw, cd.skill_range, col, 0)
				_melee(origin, dir, cd.skill_range, 40.0, dmg2 * 0.55, 5.0, col)
				await get_tree().create_timer(0.12).timeout
				if state != S.ENDED and is_instance_valid(player) and not player.dead:
					var p3 := player.global_position
					CharFx.skill_iai(fx_root, cd.id, p3, yaw, cd.skill_range, col, 1)
					_melee(p3 + Vector3(0, 0.9, 0), dir, cd.skill_range * 0.7, 120.0, dmg2 * 0.45, 9.0, col)
					cam.shake(0.14)
			"nova":
				var nc := cd.accent.lerp(Color(0.4, 0.8, 1.0), 0.65)
				CharFx.skill_nova(fx_root, cd.id, pos, cd.skill_range, nc)
				_melee(origin, dir, cd.skill_range, 180.0, dmg2, 6.0, col)
			"shockwave":
				CharFx.skill_shockwave(fx_root, cd.id, pos, yaw, cd.skill_range, col)
				_melee(origin, dir, cd.skill_range, 180.0, dmg2, 9.0, col)
				cam.shake(0.3)
			"chrono":
				# Jeda Waktu: damage sedang + semua musuh di jangkauan melambat 50% selama 3,5 dtk (tidak menumpuk, bos lebih kebal)
				ChronoFx.skill(fx_root, pos, cd.skill_range, col)
				_melee(origin, dir, cd.skill_range, 180.0, dmg2, 2.0, col)
				for e in _ult_targets(pos, cd.skill_range):
					if e is Enemy:
						(e as Enemy).apply_slow(0.5, 3.5)
				cam.shake(0.12)
			"volley":
				CharFx.skill_volley_start(fx_root, cd.id, pos, col)
				for i in 7:
					var d := dir.rotated(Vector3.UP, deg_to_rad(-24.0 + i * 8.0))
					_shoot("arrow", origin, d, dmg2 / 3.2, 25.0, 15.0, col)
		cam.shake(0.1)


## Efek serangan pemain LAIN (visual saja, tanpa damage): dipanggil CoopGhost.play agar lawan/rekan melihat tebasan, skill & proyektil.
func ghost_fx(g: CoopGhost, kind: String) -> void:
	if state == S.ENDED or fx_root == null or not is_instance_valid(g):
		return
	var cd: CharacterData = Data.character(g.char_id)
	if cd == null:
		return
	var col := cd.accent.lightened(0.35)
	var yaw := g.rig.rotation.y
	var dir := Vector3(sin(yaw), 0, cos(yaw))
	var pos := g.global_position
	var origin := pos + Vector3(0, 0.9, 0)
	var idx := g._atk
	if kind == "attack":
		match cd.attack_kind:
			"arc":
				CharFx.attack_slash(fx_root, cd.id, pos, yaw, cd.attack_range, col, idx, false)
			"dagger":
				CharFx.attack_slash(fx_root, cd.id, pos, yaw, cd.attack_range, col, idx, idx == 2)
			"smash":
				CharFx.attack_smash(fx_root, cd.id, pos, yaw, cd.attack_range, col, idx)
			"bolt", "arrow":
				var pr := Projectile.make(cd.attack_kind, col)
				pr.target_group = "none_visual"
				CharFx.decorate_projectile(pr, cd.attack_kind, cd.id, col)
				fx_root.add_child(pr)
				pr.launch(Vector3(origin.x, 1.0, origin.z) + dir * 0.7, dir, 15.0 if cd.attack_kind == "bolt" else 24.0, 13.0 if cd.attack_kind == "bolt" else 17.0)
	elif kind == "skill":
		match cd.skill_kind:
			"cone":
				CharFx.skill_cone(fx_root, cd.id, pos, yaw, cd.skill_range, col)
			"dash_cut":
				CharFx.skill_dash(fx_root, cd.id, pos, yaw, cd.skill_range, col, 0)
			"iai":
				CharFx.skill_iai(fx_root, cd.id, pos, yaw, cd.skill_range, col, 0)
			"nova":
				CharFx.skill_nova(fx_root, cd.id, pos, cd.skill_range, cd.accent.lerp(Color(0.4, 0.8, 1.0), 0.65))
			"shockwave":
				CharFx.skill_shockwave(fx_root, cd.id, pos, yaw, cd.skill_range, col)
			"volley":
				CharFx.skill_volley_start(fx_root, cd.id, pos, col)
			"chrono":
				ChronoFx.skill(fx_root, pos, cd.skill_range, col)
	elif kind == "ult":
		Fx.ring(fx_root, pos, 3.0, col, 0.5)
		Fx.float_text(fx_root, pos + Vector3(0, 3.2, 0), "ULT! " + cd.ult_name, col.lightened(0.3), 1.4)


# ---------------------------------------------------------------- pemain terkena / mati
func _on_enemy_hit(damage: int, from: Vector3) -> void:
	if state == S.ENDED or player.dead:
		return
	var def := int(GameState.char_stats(player.char_id)["def"])
	var dmg := maxi(damage - int(def * 0.5), 1)
	if player.take_damage(dmg, from):
		Fx.float_text(fx_root, player.global_position + Vector3(0, 2.2, 0), str(dmg), Color(1, 0.45, 0.45), 1.1)
		cam.shake(0.14)
		if bool(GameState.setting("vibrate")):
			Input.vibrate_handheld(40)
	else:
		Fx.float_text(fx_root, player.global_position + Vector3(0, 2.2, 0), "Luput!", Color(0.6, 0.95, 1.0), 0.9)


func _on_player_died() -> void:
	var ps: Dictionary = party_state[active]
	ps["hp"] = 0
	ps["dead"] = true
	fainted += 1
	var next := -1
	for i in party_state.size():
		if not party_state[i]["dead"]:
			next = i
			break
	if next >= 0:
		hud.banner("%s pingsan!" % Data.character(ps["id"]).display_name, UiTheme.BAD, 1.0)
		await get_tree().create_timer(1.3).timeout
		if state != S.ENDED:
			_switch_to(next, true)
	elif coop != null and pvp:
		all_down = true
		hud.banner("Kamu tersingkir!", UiTheme.BAD, 2.0)
		coop.pvp_report_down()
	elif coop != null:
		all_down = true
		hud.banner("Semua pingsan - menunggu rekan...", UiTheme.BAD, 2.0)
	elif field:
		hud.banner("Semua pingsan! Kembali ke gerbang...", UiTheme.BAD, 2.0)
		await get_tree().create_timer(2.0).timeout
		_field_revive()
	else:
		await get_tree().create_timer(1.6).timeout
		_finish(false)


## Wilayah jelajah = satu langkah Adventure: kalahkan FIELD_GOAL monster untuk menaklukkannya (sekali; hadiah tercatat lewat finish_stage).
func _field_progress() -> void:
	if GameState.stage_cleared(sd.id) or state == S.ENDED:
		return
	_field_kills += 1
	if _field_kills >= FIELD_GOAL:
		var res := GameState.finish_stage(sd.id, {"win": true, "kills": kills, "time": time, "stars": 3})
		Sfx.play("chest")
		hud.banner("Wilayah ditaklukkan! +%d emas, +%d EXP%s" % [res["gold"], res["exp"], (", +%d berlian" % res["diamond"]) if res["diamond"] > 0 else ""], UiTheme.GOLD, 3.2)
		var nxt := GameState.adventure_next()
		if nxt != "":
			await get_tree().create_timer(3.4).timeout
			hud.banner("Kembali ke gerbang untuk lanjut Adventure", Color(0.7, 0.9, 1.0), 2.8)
	elif _field_kills % 4 == 0:
		hud.banner("Penjelajahan %d/%d" % [_field_kills, FIELD_GOAL], Color(0.7, 0.9, 1.0), 1.4)


func _switch_to(idx: int, force: bool = false) -> bool:
	if idx == active or idx < 0 or idx >= party_state.size():
		return false
	if party_state[idx]["dead"]:
		return false
	if not force and (_switch_cd > 0.0 or state == S.ENDED or player.dead or _paused):
		return false
	_save_active()
	active = idx
	var ps: Dictionary = party_state[idx]
	player.set_character(ps["id"])
	player.max_hp = ps["max"]
	player.hp = ps["hp"]
	player.skill_cd = ps["skill_cd"]
	player.invuln = 0.8
	player.control_enabled = true
	_switch_cd = 1.0
	Fx.burst(fx_root, player.global_position + Vector3(0, 1.0, 0), Data.character(ps["id"]).accent, 16, 5.0, 0.14)
	Fx.ring(fx_root, player.global_position, 2.0, Data.character(ps["id"]).accent, 0.35)
	Sfx.play("portal", 1.5, -8.0)
	return true


# ---------------------------------------------------------------- ramuan
func _potion_choice() -> String:
	var missing := player.max_hp - player.hp
	var best := ""
	var best_heal := 0
	var fit := ""
	var fit_heal := 99999
	for id in GameState.inventory:
		var it := Data.item(id)
		if it == null or it.type != "potion" or GameState.item_count(id) <= 0:
			continue
		if it.heal > best_heal:
			best_heal = it.heal
			best = id
		if it.heal >= missing and it.heal < fit_heal:
			fit_heal = it.heal
			fit = id
	return fit if fit != "" else best


func _use_potion() -> void:
	if _potion_cd > 0.0 or player.dead or state == S.ENDED:
		return
	var id := _potion_choice()
	if id == "":
		Flow.toast("Tidak ada ramuan. Beli di Toko Ramuan Mira.")
		return
	if player.hp >= player.max_hp:
		Flow.toast("HP sudah penuh.")
		return
	var it := Data.item(id)
	if GameState.remove_item(id, 1):
		var before := player.hp
		player.heal(it.heal)
		Fx.float_text(fx_root, player.global_position + Vector3(0, 2.2, 0), "+%d" % (player.hp - before), Color(0.5, 1, 0.65), 1.1)
		Fx.burst(fx_root, player.global_position + Vector3(0, 1.0, 0), Color(0.5, 1, 0.65), 10, 3.0, 0.1)
		Sfx.play("heal")
		_potion_cd = 2.5


# ---------------------------------------------------------------- jeda / akhir
func _toggle_pause() -> void:
	if state == S.ENDED:
		return
	_paused = not _paused
	get_tree().paused = _paused and coop == null       # co-op: dunia tidak berhenti (rekan tetap bermain)
	hud.show_pause(_paused)
	if _paused:
		touch.release_all()
	touch.visible = touch.touch_enabled and not _paused


func _retry() -> void:
	get_tree().paused = false
	if coop != null:
		_quit_to_lobby()
		return
	Flow.start_stage(sd.id)


func _quit_to_lobby() -> void:
	get_tree().paused = false
	if coop != null:
		Net.close_room("")         # keluar di tengah co-op = meninggalkan room
	Flow.go_lobby()


func _finish(win: bool) -> void:
	if state == S.ENDED:
		return
	state = S.ENDED
	_ended_win = win
	if coop != null:
		coop.event("finish", [win])
	player.control_enabled = false
	player.move_input = Vector2.ZERO
	touch.release_all()
	touch.visible = false
	_save_active()
	var total_max := 0.0
	var total_hp := 0.0
	for ps in party_state:
		total_max += float(ps["max"])
		total_hp += 0.0 if ps["dead"] else float(ps["hp"])
	var extra := {"no_faint": fainted == 0, "hp_ok": total_hp >= total_max * 0.5}
	var stars := 0
	if win:
		stars = 1 + (1 if extra["no_faint"] else 0) + (1 if extra["hp_ok"] else 0)
	var res := GameState.finish_stage(sd.id, {"win": win, "kills": kills, "time": time, "stars": stars})
	hud.banner("KEMENANGAN!" if win else "KALAH...", UiTheme.GOLD if win else UiTheme.BAD, 1.4)
	if win:
		Sfx.play("chest")
		Sfx.music("music_ending", 0.4)
	else:
		Sfx.stop_music(0.6)
	await get_tree().create_timer(1.8).timeout
	if win and coop == null:
		await StoryPlayer.play(self, Story.for_stage(sd.id, "outro"))
	# stage berikutnya (hanya solo + menang + sudah terbuka)
	var next_sd: StageData = null
	if win and coop == null:
		var nid := GameState.adventure_next()          # langkah Adventure berikutnya (bisa wilayah jelajah)
		if nid != "" and nid != sd.id:
			next_sd = Data.stage(nid)
	var ru := StageResult.new()
	ui.add_child(ru)
	ru.show_result(res, sd, extra, next_sd)
	if next_sd != null:
		ru.next_pressed.connect(func(): Flow.start_stage(next_sd.id))
	ru.lobby_pressed.connect(func():
		Net.back_to_lobby()
		Flow.go_lobby())
	ru.retry_pressed.connect(func():
		if coop != null:
			Net.back_to_lobby()
			Flow.go_lobby()
		else:
			Flow.start_stage(sd.id))
	GameState.save_game()


## Akhir pertandingan PVP: papan skor + tombol kembali ke lobi (tanpa hadiah stage).
func pvp_finish(winner: int, kills_by: Dictionary) -> void:
	if state == S.ENDED:
		return
	state = S.ENDED
	player.control_enabled = false
	player.move_input = Vector2.ZERO
	touch.release_all()
	touch.visible = false
	var me := Net.my_id()
	var title := "SERI" if winner == 0 else ("KAMU MENANG!" if winner == me else "KALAH...")
	var wcol := UiTheme.TEXT if winner == 0 else (UiTheme.GOLD if winner == me else UiTheme.BAD)
	var rec := GameState.record_pvp("draw" if winner == 0 else ("win" if winner == me else "loss"), int(kills_by.get(me, 0)))
	hud.banner(title, wcol, 1.6)
	if winner == me:
		Sfx.play("chest")
	await get_tree().create_timer(1.8).timeout
	var dim := ColorRect.new()
	dim.color = Color(0, 0.02, 0.08, 0.72)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.add_child(dim)
	var box := PanelContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.custom_minimum_size = Vector2(520, 0)
	box.position = Vector2(-260, -190)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.08, 0.11, 0.26, 0.97)
	sb.border_color = UiTheme.GOLD
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(18)
	box.add_theme_stylebox_override("panel", sb)
	dim.add_child(box)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	box.add_child(v)
	var t := Label.new()
	t.text = title
	t.add_theme_font_size_override("font_size", 38)
	t.add_theme_color_override("font_color", wcol)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	var ids: Array = Net.members.keys()
	ids.sort_custom(func(a, b): return int(kills_by.get(a, 0)) > int(kills_by.get(b, 0)))
	for id in ids:
		var l := Label.new()
		l.text = "%s%s   %d kill" % ["[MENANG] " if int(id) == winner else "", str(Net.members[id].get("name", "?")), int(kills_by.get(id, 0))]
		l.add_theme_font_size_override("font_size", 24)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(l)
	var rl := Label.new()
	rl.text = "Rekor duelmu: %d menang · %d kalah · %d seri" % [int(rec["win"]), int(rec["loss"]), int(rec["draw"])]
	rl.add_theme_font_size_override("font_size", 20)
	rl.add_theme_color_override("font_color", UiTheme.SKY)
	rl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(rl)
	var b := Button.new()
	b.text = "Kembali ke Lobi"
	b.custom_minimum_size = Vector2(0, 60)
	b.add_theme_font_size_override("font_size", 24)
	b.pressed.connect(func():
		Net.back_to_lobby()
		Flow.go_lobby())
	v.add_child(b)


# ---------------------------------------------------------------- bot uji
func _arg(key: String, default: String = "") -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % key):
			return a.substr(key.length() + 3)
	return default


func _shot(shot_name: String) -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png("%s/%s.png" % [_arg("shots", "/tmp"), shot_name])
	print("shot ", shot_name)


func _check_bot() -> void:
	if _arg("bot") == "":
		return
	call_deferred("_bot_run")


func _bot_run() -> void:
	var script_path := "res://tools/" + _arg("botscript", "stage_bot") + ".gd"
	if ResourceLoader.exists(script_path):
		var bot: Object = (load(script_path) as GDScript).new()
		await bot.run(self)
	get_tree().quit()


# ───────────── ULT: 1× per karakter per match ─────────────
var _ult_used: Dictionary = {}          # char_id -> true (reset tiap stage/match karena Stage baru)


func ult_available() -> bool:
	return player != null and player.data != null and not _ult_used.has(player.char_id)


func try_ult() -> bool:
	if state == S.ENDED or player == null or player.dead or player.data == null or _ult_used.has(player.char_id):
		return false
	if not player.do_ult():
		return false
	_ult_used[player.char_id] = true
	_ult_cast(player.data)
	return true


func _ult_targets(center: Vector3, rng: float) -> Array:
	var out: Array = []
	for e in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(e) and e is Enemy and e.global_position.distance_to(center) <= rng:
			out.append(e)
	if pvp:
		for g in get_tree().get_nodes_in_group("ghost"):
			if is_instance_valid(g) and g is CoopGhost and not g.dead and not g.all_down and g.global_position.distance_to(center) <= rng:
				out.append(g)
	return out


func _ult_aoe(pos: Vector3, radius: float, dmg: float, knock: float, col: Color) -> void:
	for e in _ult_targets(pos, radius):
		_hit_any(e, dmg, knock, col)


func _ult_cast(cd: CharacterData) -> void:
	var atk := float(GameState.char_stats(player.char_id)["atk"])
	var col := cd.accent.lightened(0.3)
	var total := atk * cd.ult_mult
	var center := player.global_position
	var kind := cd.ult_kind
	var tint := col
	match kind:
		"inferno": tint = Color(1.0, 0.5, 0.15)
		"inferno_blue": tint = Color(0.3, 0.65, 1.0)
		"shadow_blades", "shadow_dragon": tint = Color(0.55, 0.2, 0.85)
		"symphony": tint = Color(0.7, 1.0, 0.86)
		"starfall": tint = Color(0.75, 1.0, 0.6)
		"quake": tint = Color(1.0, 0.7, 0.35)
		"sigil_gold": tint = Color(1.0, 0.82, 0.3)
		"chrono": tint = Color(0.5, 0.7, 1.0)
	Fx.float_text(fx_root, center + Vector3(0, 3.2, 0), "ULT! " + cd.ult_name, tint.lightened(0.3), 1.6)
	cam.shake(0.1)
	_ult_charge(kind, center, cd, tint)
	if kind == "chrono":                           # waktu hampir berhenti: musuh di jangkauan melambat 80% selama 3 dtk
		for e in _ult_targets(center, cd.ult_range):
			if e is Enemy:
				(e as Enemy).apply_slow(0.2, 3.0)
	await get_tree().create_timer(0.6).timeout
	if state == S.ENDED or not is_instance_valid(player):
		return
	var yaw := player.facing
	var fwd := Vector3(sin(yaw), 0, cos(yaw))
	if kind == "shadow_dragon":
		UltFx.dragon(fx_root, center + Vector3(0, 1.0, 0), fwd, cd.ult_range, tint.darkened(0.55), Color(1.0, 0.2, 0.25), 1.15)
	var strikes := 7
	for i in strikes:
		if state == S.ENDED or not is_instance_valid(player):
			return
		var ts := _ult_targets(center, cd.ult_range)
		var p: Vector3
		if ts.is_empty():
			var a := randf() * TAU
			p = center + Vector3(sin(a), 0, cos(a)) * randf_range(2.0, cd.ult_range * 0.7)
		else:
			p = (ts[i % ts.size()] as Node3D).global_position
		p.y = center.y
		_ult_strike(kind, p, tint)
		await get_tree().create_timer(0.18).timeout
		_ult_aoe(p, 3.4, total * 0.25, 5.0, tint)
		cam.shake(0.06)
		_hit_stop(0.04)
	# penutup: ledakan besar menghantam semua musuh dalam jangkauan
	await get_tree().create_timer(0.15).timeout
	if state == S.ENDED or not is_instance_valid(player):
		return
	_ult_finale(kind, center, cd.ult_range, tint)
	_ult_aoe(center, cd.ult_range, total * 0.8, 9.0, tint)
	cam.shake(0.25)
	_hit_stop(0.12)


# Tiap ULT punya "bahasa visual" sendiri sesuai karakter (lingkaran sihir HANYA untuk penyihir Lyra & Lucien).
func _ult_charge(kind: String, c: Vector3, cd: CharacterData, tint: Color) -> void:
	var r := cd.ult_range
	match kind:
		"sigil":
			UltFx.sigil(fx_root, c, r * 0.55, tint, 2.6, "b")
			UltFx.flare(fx_root, c + Vector3(0, 1.2, 0), tint, 4.0, 0.7)
		"sigil_gold":
			UltFx.sigil(fx_root, c, r * 0.5, tint, 2.6, "a")
			UltFx.sigil(fx_root, c, r * 0.3, tint.lightened(0.3), 2.4, "b")
		"sword_rain":
			UltFx.pillar(fx_root, c, tint, 9.0, 0.5, 0.7)
			UltFx.flare(fx_root, c + Vector3(0, 3.2, 0), tint, 6.0, 0.7)
			CharFx.spark_lines(fx_root, c + Vector3(0, 1.0, 0), Vector3.UP, Color(0.9, 0.97, 1.0), 14, 9.0, 40.0, 0.5, 0.9)
		"quake":
			CharFx.cracks(fx_root, c, r * 0.35, Color(1.0, 0.55, 0.2), 0.9, 8)
			CharFx.puff(fx_root, c + Vector3(0, 0.2, 0), Color(0.72, 0.62, 0.48), 10, 3.5, 0.6, Vector3.UP, 85.0, -0.8, 0.8, "sphere", false)
			Fx.ring(fx_root, c, r * 0.3, Color(1.0, 0.7, 0.4), 0.5)
		"starfall":
			CharFx.puff(fx_root, c + Vector3(0, 0.3, 0), Color(0.5, 0.85, 0.4), 14, 6.0, 0.2, Vector3.UP, 180.0, -1.5, 0.9, "leaf", false)
			UltFx.flare(fx_root, c + Vector3(0, 2.4, 0), tint, 5.0, 0.6)
			Fx.ring(fx_root, c, r * 0.35, tint, 0.5)
		"inferno", "inferno_blue":
			for pt in CharFx._ring_pts(c, 2.2, 8):
				CharFx.puff(fx_root, pt + Vector3(0, 0.1, 0), tint, 3, 2.5, 0.5, Vector3.UP, 20.0, 3.0, 0.7, "flame", false)
			CharFx.puff(fx_root, c + Vector3(0, 0.5, 0), tint.lightened(0.4), 10, 5.0, 0.2, Vector3.UP, 80.0, 2.0, 0.7)
		"shadow_blades", "shadow_dragon":
			CharFx.puff(fx_root, c + Vector3(0, 0.6, 0), Color(0.14, 0.1, 0.28), 10, 3.5, 0.6, Vector3.UP, 180.0, 1.0, 0.8, "sphere", false)
			CharFx.puff(fx_root, c + Vector3(0, 0.6, 0), tint, 8, 5.0, 0.15, Vector3.UP, 180.0, 1.0, 0.6)
		"pillars":
			UltFx.flare(fx_root, c + Vector3(0, 1.6, 0), tint, 6.5, 0.7)
			UltFx.pillar(fx_root, c, tint, 12.0, 0.7, 0.7)
		"chrono":
			ChronoFx.ult_charge(fx_root, c, r)
		"symphony":
			UltFx.staff_lines(fx_root, c, r * 0.5, tint, 1.2)
			CharFx.notes(fx_root, c + Vector3(0, 1.0, 0), tint, 12, 4.0, 0.6, Vector3.UP, 180.0, 1.0, 1.1)
		_:
			UltFx.flare(fx_root, c + Vector3(0, 1.2, 0), tint, 4.0, 0.7)


func _ult_strike(kind: String, p: Vector3, tint: Color) -> void:
	match kind:
		"sword_rain":
			UltFx.blade(fx_root, p, tint, 11.0, 0.22, 2.0)
			CharFx.x_flash(fx_root, p + Vector3(0, 0.8, 0), Color(0.9, 0.97, 1.0), 1.4, 0.2)
		"starfall":
			UltFx.blade(fx_root, p, tint, 12.0, 0.14, 1.3)
			CharFx.puff(fx_root, p + Vector3(0, 0.3, 0), Color(0.5, 0.85, 0.4), 5, 3.0, 0.15, Vector3.UP, 180.0, -1.5, 0.7, "leaf", false)
		"shadow_blades":                       # tebasan silang kilat + kabut bayangan, bukan jatuh dari langit
			var dir := Vector3(randf() - 0.5, 0, randf() - 0.5).normalized()
			CharFx.streak(fx_root, p - dir * 2.2 + Vector3(0, 1.0, 0), p + dir * 2.2 + Vector3(0, 1.0, 0), Color(0.92, 0.85, 1.0), 0.18, 0.18)
			CharFx.streak(fx_root, p - dir.rotated(Vector3.UP, 1.6) * 2.2 + Vector3(0, 1.0, 0), p + dir.rotated(Vector3.UP, 1.6) * 2.2 + Vector3(0, 1.0, 0), tint, 0.18, 0.2)
			CharFx.x_flash(fx_root, p + Vector3(0, 1.0, 0), tint.lightened(0.4), 1.5, 0.2)
			CharFx.puff(fx_root, p + Vector3(0, 0.6, 0), Color(0.14, 0.1, 0.28), 4, 3.0, 0.5, Vector3.UP, 180.0, 1.0, 0.6, "sphere", false)
		"inferno", "inferno_blue":
			UltFx.flame_column(fx_root, p, tint, tint.lightened(0.6), 1.2)
			if kind == "inferno_blue":
				CharFx.x_flash(fx_root, p + Vector3(0, 1.0, 0), Color(0.85, 0.95, 1.0), 1.2, 0.16)
		"quake":
			UltFx.quake(fx_root, p, 3.2, tint, Color(0.45, 0.35, 0.28))
		"pillars":
			UltFx.pillar(fx_root, p, tint, 14.0, 1.8, 0.7)
			UltFx.flare(fx_root, p + Vector3(0, 2.5, 0), Color(0.9, 0.98, 1.0), 3.5, 0.4)
		"sigil", "sigil_gold":
			UltFx.pillar(fx_root, p, tint, 12.0, 1.4, 0.6)
			UltFx.sigil(fx_root, p, 2.4, tint, 0.8, "b" if kind == "sigil" else "a", 3.0)
		"chrono":
			ChronoFx.ult_strike(fx_root, p, tint)
		"symphony":                            # tiap serangan = ledakan nota + paranada di bawah musuh
			CharFx.notes(fx_root, p + Vector3(0, 0.6, 0), tint, 14, 6.0, 0.8, Vector3.UP, 80.0, 1.5, 1.0)
			CharFx.notes(fx_root, p + Vector3(0, 0.6, 0), Color(1.0, 0.8, 0.95), 8, 4.0, 0.7, Vector3.UP, 80.0, 1.2, 1.0)
			UltFx.staff_lines(fx_root, p, 2.2, tint, 0.7, randf() * PI)
			Fx.ring(fx_root, p, 2.6, tint, 0.35)
		_:
			Fx.ring(fx_root, p, 3.0, tint, 0.5)
			Fx.burst(fx_root, p + Vector3(0, 0.5, 0), tint, 12, 5.0, 0.14)


func _ult_finale(kind: String, c: Vector3, r: float, tint: Color) -> void:
	match kind:
		"sword_rain":
			UltFx.blade(fx_root, c + Vector3(0, 0, 3.0), tint.lightened(0.3), 20.0, 0.35, 5.0)       # satu pedang raksasa menancap di depan
			UltFx.flare(fx_root, c + Vector3(0, 1.5, 3.0), Color(0.95, 0.98, 1.0), 9.0, 0.8)
			Fx.ring(fx_root, c + Vector3(0, 0, 3.0), r * 0.9, tint, 0.8)
		"quake":
			UltFx.quake(fx_root, c, r * 0.8, tint, Color(0.45, 0.35, 0.28))
			Fx.ring(fx_root, c, r, Color(1.0, 0.8, 0.5), 0.8)
			CharFx.puff(fx_root, c + Vector3(0, 0.3, 0), Color(0.45, 0.4, 0.36), 24, 12.0, 0.3, Vector3.UP, 70.0, -20.0, 1.0, "chip", false)
		"starfall":
			UltFx.flare(fx_root, c + Vector3(0, 2.0, 0), Color(1, 1, 0.9), 9.0, 0.8)
			Fx.ring(fx_root, c, r, tint, 0.8)
			CharFx.puff(fx_root, c + Vector3(0, 1.0, 0), Color(0.6, 0.95, 0.5), 20, 9.0, 0.2, Vector3.UP, 180.0, -2.0, 1.0, "leaf", false)
		"inferno", "inferno_blue":
			UltFx.flame_column(fx_root, c, tint, tint.lightened(0.6), 3.0)
			Fx.ring(fx_root, c, r, tint, 0.8)
		"shadow_blades":
			CharFx.x_flash(fx_root, c + Vector3(0, 1.2, 0), tint.lightened(0.5), 5.0, 0.35)
			Fx.ring(fx_root, c, r, tint, 0.7)
			CharFx.puff(fx_root, c + Vector3(0, 0.8, 0), Color(0.14, 0.1, 0.28), 20, 9.0, 0.6, Vector3.UP, 180.0, 0.5, 1.0, "sphere", false)
		"chrono":
			ChronoFx.ult_finale(fx_root, c, r, tint)
		"symphony":
			UltFx.staff_lines(fx_root, c, r * 0.9, tint, 1.2)
			CharFx.notes(fx_root, c + Vector3(0, 1.0, 0), tint, 36, 12.0, 1.0, Vector3.UP, 180.0, 1.0, 1.4)
			CharFx.notes(fx_root, c + Vector3(0, 1.0, 0), Color(1.0, 0.8, 0.95), 24, 9.0, 0.9, Vector3.UP, 180.0, 1.0, 1.4)
			Fx.ring(fx_root, c, r, tint, 0.9)
		"sigil", "sigil_gold":
			UltFx.pillar(fx_root, c, tint, 18.0, 3.2, 0.9)
			UltFx.flare(fx_root, c + Vector3(0, 1.5, 0), tint.lightened(0.4), 8.0, 0.8)
			Fx.ring(fx_root, c, r, tint, 0.8)
		"shadow_dragon":
			Fx.ring(fx_root, c, r, tint, 0.8)
			CharFx.puff(fx_root, c + Vector3(0, 0.8, 0), Color(0.14, 0.1, 0.28), 20, 10.0, 0.7, Vector3.UP, 180.0, 0.5, 1.0, "sphere", false)
		_:
			UltFx.pillar(fx_root, c, tint, 18.0, 3.2, 0.9)
			UltFx.flare(fx_root, c + Vector3(0, 1.5, 0), tint.lightened(0.4), 8.0, 0.8)
			Fx.ring(fx_root, c, r, tint, 0.8)
