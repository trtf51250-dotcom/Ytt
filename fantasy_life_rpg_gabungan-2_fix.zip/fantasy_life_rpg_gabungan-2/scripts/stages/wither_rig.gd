class_name WitherRig
extends Node3D
## Pembungkus wither_god_rigged.glb. GLB hanya membawa animasi "Idle" (tubuh + kubus tengkorak melayang), jadi klip aksi dibuat di sini dari kode:
## tiap klip = salinan Idle (kubus tetap melayang) dengan track badan/tangan/kepala diganti keyframe aksi. Rotasi = rotasi istirahat tulang x delta (euler).
## Klip: idle, cast (angkat tangan, kumpul tenaga), slam (hentak ke depan), roar (rentang tangan lebar), hit (tersentak), death (runtuh).

const BODY := ["Spine", "Chest", "Head", "UpperArm_L", "UpperArm_R", "Forearm_L", "Forearm_R"]
## Waktu puncak pose (detik) tiap klip — dipakai Enemy untuk menyelaraskan puncak gerak dengan akhir fase aba-aba.
const PEAK := {"cast": 0.8, "slam": 0.55, "roar": 0.9}

var skeleton: Skeleton3D
var anim_player: AnimationPlayer
var state: StringName = &"idle"
var _prefix := ""


func _ready() -> void:
	skeleton = _find(self, "Skeleton3D") as Skeleton3D
	anim_player = _find(self, "AnimationPlayer") as AnimationPlayer
	if skeleton == null or anim_player == null:
		push_error("WitherRig: Skeleton3D/AnimationPlayer tidak ditemukan")
		return
	_prefix = str(anim_player.get_node(anim_player.root_node).get_path_to(skeleton))
	var lib := anim_player.get_animation_library(&"")
	var idle_name := lib.get_animation_list()[0]
	var idle := lib.get_animation(idle_name)
	idle.loop_mode = Animation.LOOP_LINEAR
	if idle_name != "idle":
		lib.add_animation(&"idle", idle)
	_build_clips(lib, idle)
	play_state(&"idle", 0.0)


func play_state(s: StringName, blend: float = 0.2) -> void:
	if anim_player == null or not anim_player.has_animation(s):
		return
	state = s
	anim_player.play(s, blend)


func _rest_q(bone: String) -> Quaternion:
	var i := skeleton.find_bone(bone)
	return skeleton.get_bone_rest(i).basis.get_rotation_quaternion() if i >= 0 else Quaternion.IDENTITY


## pose: {bone: Vector3 euler delta}; keys: [[t, pose], ...]
func _clip(lib: AnimationLibrary, idle: Animation, name: String, keys: Array, length: float) -> void:
	var a: Animation = idle.duplicate()
	a.length = length
	a.loop_mode = Animation.LOOP_NONE
	# potong key idle yang melewati panjang klip
	for ti in a.get_track_count():
		var kc := a.track_get_key_count(ti)
		for ki in range(kc - 1, -1, -1):
			if a.track_get_key_time(ti, ki) > length:
				a.track_remove_key(ti, ki)
	for b in BODY:
		var path := NodePath("%s:%s" % [_prefix, b])
		var ti := a.find_track(path, Animation.TYPE_ROTATION_3D)
		if ti < 0:
			ti = a.add_track(Animation.TYPE_ROTATION_3D)
			a.track_set_path(ti, path)
		while a.track_get_key_count(ti) > 0:
			a.track_remove_key(ti, 0)
		var rq := _rest_q(b)
		for k in keys:
			var pose: Dictionary = k[1]
			var d: Vector3 = pose.get(b, Vector3.ZERO)
			a.rotation_track_insert_key(ti, float(k[0]), rq * Quaternion.from_euler(d))
	lib.add_animation(StringName(name), a)


func _build_clips(lib: AnimationLibrary, idle: Animation) -> void:
	var z := {}
	# cast: angkat kedua tangan tinggi ke samping-atas, dada membusung ke belakang, kepala menengadah, lalu turun
	var cast_pose := {
		"Spine": Vector3(-0.18, 0, 0), "Chest": Vector3(-0.2, 0, 0), "Head": Vector3(-0.35, 0, 0),
		"UpperArm_L": Vector3(-0.3, 0, 2.0), "UpperArm_R": Vector3(-0.3, 0, -2.0),
		"Forearm_L": Vector3(-0.5, 0, 0.4), "Forearm_R": Vector3(-0.5, 0, -0.4)}
	var cast_hold := {
		"Spine": Vector3(0.12, 0, 0), "Chest": Vector3(0.18, 0, 0), "Head": Vector3(0.18, 0, 0),
		"UpperArm_L": Vector3(-1.5, 0, 0.5), "UpperArm_R": Vector3(-1.5, 0, -0.5),
		"Forearm_L": Vector3(-0.2, 0, 0), "Forearm_R": Vector3(-0.2, 0, 0)}
	_clip(lib, idle, "cast", [[0.0, z], [PEAK["cast"], cast_pose], [PEAK["cast"] + 0.12, cast_hold], [PEAK["cast"] + 0.6, cast_hold], [PEAK["cast"] + 1.1, z]], PEAK["cast"] + 1.2)
	# slam: tangan terangkat di atas kepala lalu dihentakkan ke depan-bawah
	var slam_up := {
		"Spine": Vector3(-0.25, 0, 0), "Chest": Vector3(-0.22, 0, 0), "Head": Vector3(-0.25, 0, 0),
		"UpperArm_L": Vector3(-0.2, 0, 2.5), "UpperArm_R": Vector3(-0.2, 0, -2.5),
		"Forearm_L": Vector3(-0.4, 0, 0), "Forearm_R": Vector3(-0.4, 0, 0)}
	var slam_down := {
		"Spine": Vector3(0.4, 0, 0), "Chest": Vector3(0.3, 0, 0), "Head": Vector3(0.35, 0, 0),
		"UpperArm_L": Vector3(-1.7, 0, 0.3), "UpperArm_R": Vector3(-1.7, 0, -0.3),
		"Forearm_L": Vector3(-0.25, 0, 0), "Forearm_R": Vector3(-0.25, 0, 0)}
	_clip(lib, idle, "slam", [[0.0, z], [PEAK["slam"], slam_up], [PEAK["slam"] + 0.1, slam_down], [PEAK["slam"] + 0.55, slam_down], [PEAK["slam"] + 1.0, z]], PEAK["slam"] + 1.1)
	# roar: kepala menengadah, tangan direntang lebar
	var roar_pose := {
		"Spine": Vector3(-0.22, 0, 0), "Chest": Vector3(-0.3, 0, 0), "Head": Vector3(-0.55, 0, 0),
		"UpperArm_L": Vector3(0, 0, 1.0), "UpperArm_R": Vector3(0, 0, -1.0),
		"Forearm_L": Vector3(0, 0, 0.2), "Forearm_R": Vector3(0, 0, -0.2)}
	var roar_shake := roar_pose.duplicate(true)
	roar_shake["Chest"] = Vector3(-0.36, 0, 0)
	roar_shake["UpperArm_L"] = Vector3(0, 0, 1.2)
	roar_shake["UpperArm_R"] = Vector3(0, 0, -1.2)
	_clip(lib, idle, "roar", [[0.0, z], [PEAK["roar"], roar_pose], [PEAK["roar"] + 0.25, roar_shake], [PEAK["roar"] + 0.5, roar_pose], [PEAK["roar"] + 1.1, z]], PEAK["roar"] + 1.2)
	# hit: tersentak ke belakang sebentar
	var hit_pose := {"Spine": Vector3(-0.3, 0.1, 0), "Chest": Vector3(-0.3, 0, 0), "Head": Vector3(-0.45, 0.15, 0),
		"UpperArm_L": Vector3(0.2, 0, 0.7), "UpperArm_R": Vector3(0.2, 0, -0.7)}
	_clip(lib, idle, "hit", [[0.0, z], [0.12, hit_pose], [0.5, z]], 0.6)
	# death: membungkuk dan tangan terkulai, tertahan
	var dead_pose := {"Spine": Vector3(0.7, 0, 0.1), "Chest": Vector3(0.5, 0, 0), "Head": Vector3(0.8, 0, 0),
		"UpperArm_L": Vector3(0.4, 0, -0.5), "UpperArm_R": Vector3(0.4, 0, 0.5),
		"Forearm_L": Vector3(-0.3, 0, 0), "Forearm_R": Vector3(-0.3, 0, 0)}
	_clip(lib, idle, "death", [[0.0, z], [0.9, dead_pose], [3.0, dead_pose]], 3.0)


func _find(root: Node, cls: String) -> Node:
	if root.get_class() == cls:
		return root
	for c in root.get_children():
		var r := _find(c, cls)
		if r:
			return r
	return null
