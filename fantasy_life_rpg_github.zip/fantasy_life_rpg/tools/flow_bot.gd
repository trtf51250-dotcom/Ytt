extends RefCounted
## Uji alur: lobi -> panel Pilih Stage -> Mulai -> stage -> kalah -> tombol "Kembali ke Lobi" -> lobi lagi.
## Jalankan:  -- --bot=1 --botscript=flow_bot --fresh --stage=s1_1
## Bot ini dipanggil lagi oleh scene stage/lobi berikutnya; pemanggilan ulang hanya menunggu (alur dikendalikan pemanggil pertama).

var fails := 0


func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1


func _wait_scene(tree: SceneTree, nm: String, timeout: float) -> bool:
	var t := 0.0
	while t < timeout:
		await tree.create_timer(0.25).timeout
		t += 0.25
		if tree.current_scene and tree.current_scene.name == nm and not Flow.is_busy():
			return true
	return false


func run(node: Node) -> void:
	var tree := node.get_tree()
	if GameState.flags.has("_flow_bot"):
		while true:
			await tree.create_timer(1.0).timeout
	GameState.flags["_flow_bot"] = true
	await tree.create_timer(0.6).timeout
	var lobby: Node3D = node
	check("start in lobby", tree.current_scene.name == "Lobby")
	lobby.host.open("stage_select")
	await tree.create_timer(0.5).timeout
	check("stage panel open", lobby.host.current_id == "stage_select")
	lobby.host.current.call("_start")
	check("reached stage scene", await _wait_scene(tree, "Stage", 10.0))
	var st: Node3D = tree.current_scene
	check("stage id", GameState.current_stage_id != "" and st.sd != null and st.sd.id == GameState.current_stage_id, GameState.current_stage_id)
	await tree.create_timer(1.0).timeout
	st._finish(false)
	await tree.create_timer(2.6).timeout
	var ru: Node = null
	for c in st.ui.get_children():
		if c is StageResult:
			ru = c
	check("result screen shown", ru != null)
	if ru:
		ru.lobby_pressed.emit()
	check("back in lobby", await _wait_scene(tree, "Lobby", 10.0))
	check("player exists in lobby", tree.current_scene.get("player") != null)
	print("CHECK SUMMARY fails=", fails)
	tree.quit()
	while true:
		await tree.create_timer(1.0).timeout
