extends CanvasLayer
## Autoload "Flow": perpindahan scene dengan fade + layar "Memuat...", dan notifikasi singkat (toast).

const SCENE_TITLE := "res://scenes/title.tscn"
const SCENE_LOBBY := "res://scenes/lobby/lobby.tscn"
const SCENE_STAGE := "res://scenes/stages/stage.tscn"

var _fade: ColorRect
var _label: Label
var _busy := false
var _toast_box: PanelContainer
var _toast_label: Label
var _toast_tween: Tween
var _back_last := -10.0               # waktu (detik) Back terakhir yang tidak ditangani siapa pun
const BACK_EXIT_WINDOW := 2.0


func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	_fade = ColorRect.new()
	_fade.color = Color(0.05, 0.07, 0.16, 1.0)
	_fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.modulate.a = 0.0
	add_child(_fade)
	_label = Label.new()
	_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_label.add_theme_font_size_override("font_size", 28)
	_label.add_theme_color_override("font_color", Color(0.85, 0.93, 1.0))
	_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.add_child(_label)

	_toast_box = PanelContainer.new()
	_toast_box.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_toast_box.position = Vector2(0, 86)
	_toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.08, 0.11, 0.24, 0.92)
	sb.border_color = Color(0.95, 0.76, 0.3)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(14)
	sb.content_margin_left = 22
	sb.content_margin_right = 22
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10
	_toast_box.add_theme_stylebox_override("panel", sb)
	_toast_label = Label.new()
	_toast_label.add_theme_font_size_override("font_size", 22)
	_toast_label.add_theme_color_override("font_color", Color(1, 1, 1))
	_toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_box.add_child(_toast_label)
	_toast_box.modulate.a = 0.0
	add_child(_toast_box)


func is_busy() -> bool:
	return _busy


## Tombol Back Android TIDAK menghasilkan tombol keyboard: hanya notifikasi. Diubah jadi aksi "menu_back" supaya panel,
## menu jeda, dan semua penangan Esc memakai satu jalur. (project.godot: quit_on_go_back=false, jadi app tidak langsung tertutup.)
func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		InputSetup.ensure()
		for pressed in [true, false]:
			var ev := InputEventAction.new()
			ev.action = &"menu_back"
			ev.pressed = pressed
			Input.parse_input_event(ev)


## Sampai sini hanya bila tak ada panel/menu jeda yang menangani Back: tekan dua kali dalam 2 detik untuk keluar.
func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventAction) or not event.is_action_pressed(&"menu_back"):
		return
	get_viewport().set_input_as_handled()
	if _busy:
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now - _back_last <= BACK_EXIT_WINDOW:
		GameState.save_game()
		get_tree().quit()
		return
	_back_last = now
	toast("Tekan Back sekali lagi untuk keluar")


## Pindah scene dengan fade. Mengembalikan setelah scene baru dimuat.
func goto(path: String, text: String = "Memuat...") -> void:
	if _busy:
		return
	if GameState.banned and path != SCENE_TITLE:      # akun diblokir: hanya layar judul yang boleh dibuka
		path = SCENE_TITLE
	_busy = true
	_fade.mouse_filter = Control.MOUSE_FILTER_STOP
	_label.text = text
	var t := create_tween()
	t.tween_property(_fade, "modulate:a", 1.0, 0.25)
	await t.finished
	await get_tree().process_frame
	await get_tree().process_frame
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	var t2 := create_tween()
	t2.tween_property(_fade, "modulate:a", 0.0, 0.3)
	await t2.finished
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_busy = false


func go_lobby() -> void:
	goto(SCENE_LOBBY, "Kembali ke Aurelia...")


func start_stage(stage_id: String) -> void:
	GameState.current_stage_id = stage_id
	var sd := Data.stage(stage_id)
	goto(SCENE_STAGE, "Menuju %s..." % (sd.display_name if sd else "stage"))


## Notifikasi singkat di atas layar.
func toast(text: String, seconds: float = 2.0) -> void:
	_toast_label.text = text
	_toast_box.reset_size()
	_toast_box.position.x = (get_viewport().get_visible_rect().size.x - _toast_box.size.x) * 0.5
	if _toast_tween:
		_toast_tween.kill()
	_toast_box.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(seconds)
	_toast_tween.tween_property(_toast_box, "modulate:a", 0.0, 0.4)
