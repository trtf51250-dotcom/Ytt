extends Node
## PERF: kelas perangkat + resolusi 3D dinamis agar perangkat ringan bisa mengejar 60 FPS.
##  - detect_tier(): tebak kelas perangkat 0 Lancar / 1 Sedang / 2 Bagus dari nama GPU, RAM, inti CPU (murni, bisa diuji).
##  - Skala resolusi 3D: tiap preset punya target jumlah piksel 3D; UI 2D tetap tajam (hanya dunia 3D yang diturunkan resolusinya).
##  - Governor: tiap detik mengukur waktu bingkai NYATA; bila < ~53 FPS skala diturunkan, bila stabil 60 FPS dicoba naik lagi
##    (dengan jeda yang membesar bila percobaan naik gagal, supaya tidak bolak-balik).
## CATATAN JUJUR: tebakan tier bergantung pada nama GPU yang diberikan Android; bila tidak dikenali dipakai Sedang. Pemain bisa memilih manual.

signal scale_changed(scale: float)

const TARGET_PIXELS := [0.55e6, 0.8e6, 1.0e9]      # jumlah piksel 3D yang dituju per preset (Lancar, Sedang, Bagus=asli)
const FLOOR_SCALE := [0.5, 0.65, 1.0]              # batas bawah skala per preset (governor tidak turun lebih rendah)
const LOWER_MS := 18.8                              # rata-rata bingkai di atas ini (< ~53 FPS) -> turunkan skala
const STEP := 0.06
const RAISE_AFTER_MIN := 8.0
const RAISE_AFTER_MAX := 120.0
const GRACE_AFTER_SCENE := 3.0                      # abaikan beberapa detik setelah pindah scene (lonjakan pemuatan)

var tier := 1
var gpu_name := ""
var info: Dictionary = {}
var dyn := 1.0                                       # pengali dari governor (<= 1.0)
var fps_avg := 0.0                                   # FPS rata-rata jendela terakhir (untuk tampilan/uji)
var last_event := ""                                 # catatan keputusan governor terakhir (untuk uji/info)

var _win_t := 0.0
var _win_frames := 0
var _win_max := 0.0
var _last_us := 0
var _grace := GRACE_AFTER_SCENE
var _good_s := 0.0
var _raise_after := RAISE_AFTER_MIN
var _since_raise := 999.0
var _raised := false
var _last_scene: Node = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	info = probe()
	gpu_name = str(info.get("gpu", ""))
	tier = detect_tier(info)
	GameState.changed.connect(func(kind: String):
		if kind == "settings":
			apply_scale())
	apply_scale()


# ---------------------------------------------------------------- tebak kelas perangkat
static func probe() -> Dictionary:
	var ram_mb := -1
	var mi := OS.get_memory_info()
	var phys := int(mi.get("physical", -1))
	if phys > 0:
		ram_mb = int(phys / 1048576)
	var sz := DisplayServer.window_get_size()
	return {"gpu": RenderingServer.get_video_adapter_name(), "cpu": OS.get_processor_name(), "cores": OS.get_processor_count(),
		"ram_mb": ram_mb, "w": sz.x, "h": sz.y}


## 0 = ringan (Lancar), 1 = menengah (Sedang), 2 = kuat (Bagus). Tidak dikenali -> 1.
static func detect_tier(i: Dictionary) -> int:
	var gpu := str(i.get("gpu", "")).to_lower()
	var cpu := str(i.get("cpu", "")).to_lower()
	var ram := int(i.get("ram_mb", -1))
	var cores := int(i.get("cores", 0))
	var t := 1
	var known := false
	# --- GPU
	if gpu.contains("llvmpipe") or gpu.contains("softpipe") or gpu.contains("swrast") or gpu.contains("software"):
		t = 0; known = true
	elif gpu.contains("powervr") or gpu.contains("sgx") or gpu.contains(" ge8") or gpu.begins_with("ge8"):
		t = 0; known = true                                   # PowerVR GE8320 (Helio P22/P35) dan sejenisnya
	elif gpu.contains("adreno"):
		var re := RegEx.create_from_string("adreno[^0-9]*(\\d+)")
		var m := re.search(gpu)
		var n := int(m.get_string(1)) if m else 0
		known = n > 0
		if n > 0:
			t = 0 if n < 510 else (1 if n < 620 else 2)
	elif gpu.contains("mali") or gpu.contains("immortalis"):
		known = true
		if gpu.contains("immortalis"):
			t = 2
		else:
			var re2 := RegEx.create_from_string("mali-?([tg]?)(\\d+)")
			var m2 := re2.search(gpu)
			if m2:
				var series := m2.get_string(1)
				var n2 := int(m2.get_string(2))
				if series != "g":                                  # Mali-4xx / Mali-Txxx (generasi lama)
					t = 0
				else:
					var table := {31: 0, 51: 0, 52: 1, 57: 1, 72: 1, 76: 2, 77: 2, 78: 2, 68: 2, 310: 0, 510: 1, 610: 2, 710: 2, 715: 2, 720: 2}
					t = int(table.get(n2, 1))
			else:
				t = 1
	elif gpu.contains("apple") or gpu.contains("nvidia") or gpu.contains("geforce") or gpu.contains("radeon") or gpu.contains("rtx") or gpu.contains("intel") or gpu.contains("xclipse"):
		t = 2; known = true
	# --- CPU yang dikenal lemah (nama prosesor Android sering tidak informatif, jadi hanya penambah)
	for p in ["mt6762", "mt6765", "mt6761", "mt6739", "mt6737", "mt6735", "mt6750", "mt658", "helio p22", "helio p32", "helio p35", "helio a2", "helio g25", "helio g35", "sc98", "sc77", "msm8917", "msm8937", "exynos 7"]:
		if cpu.contains(p):
			t = 0
			known = true
	# --- RAM & inti
	if ram > 0:
		if ram <= 3300:
			t = mini(t, 0)
		elif ram <= 4300:
			t = mini(t, 1)
	if cores > 0 and cores <= 2:
		t = 0
	if not known and ram <= 0:
		return 1
	return t


## Level efektif 0..2: manual (quality >= 0) atau hasil deteksi (quality = -1 "Otomatis").
func classic() -> bool:
	return int(GameState.setting("quality")) == 3


func level() -> int:
	var q := int(GameState.setting("quality"))
	if q == 3:
		return 1                                       # Klasik: setara Sedang, tanpa tambahan baru
	return tier if q < 0 else clampi(q, 0, 2)


static func preset_scale(lv: int, w: int, h: int) -> float:
	lv = clampi(lv, 0, 2)
	var px := float(maxi(w, 1) * maxi(h, 1))
	return clampf(sqrt(TARGET_PIXELS[lv] / px), FLOOR_SCALE[lv], 1.0)


func scale_now() -> float:
	if classic():
		return 1.0
	var lv := level()
	var sz := DisplayServer.window_get_size()
	var base := preset_scale(lv, sz.x, sz.y)
	var d := dyn if dyn_enabled() else 1.0
	return clampf(base * d, FLOOR_SCALE[lv], 1.0) if lv < 2 else clampf(base * d, 0.7, 1.0)


func dyn_enabled() -> bool:
	return not classic() and bool(GameState.setting("dyn_res"))


func apply_scale() -> void:
	var root := get_tree().root
	var s := scale_now()
	if absf(root.scaling_3d_scale - s) > 0.001:
		root.scaling_3d_scale = s
		scale_changed.emit(s)


# ---------------------------------------------------------------- governor
func _process(_dt: float) -> void:
	var now := Time.get_ticks_usec()
	if _last_us == 0:
		_last_us = now
		return
	var ms := (now - _last_us) / 1000.0
	_last_us = now
	var cs := get_tree().current_scene
	if cs != _last_scene:                              # scene baru: beri waktu agar lonjakan pemuatan tidak dianggap lambat
		_last_scene = cs
		_grace = GRACE_AFTER_SCENE
		_win_t = 0.0; _win_frames = 0; _win_max = 0.0
	_win_t += ms / 1000.0
	_win_frames += 1
	_win_max = maxf(_win_max, ms)
	if _win_t >= 1.0:
		var avg := _win_t * 1000.0 / maxf(_win_frames, 1)
		fps_avg = 1000.0 / maxf(avg, 0.001)
		var mx := _win_max
		var dt := _win_t
		_win_t = 0.0; _win_frames = 0; _win_max = 0.0
		if _grace > 0.0:
			_grace -= dt
			return
		if get_tree().paused:
			return
		govern(avg, mx, dt)


## Satu jendela 1 detik. avg_ms = rata-rata waktu bingkai, max_ms = bingkai terburuk. Dapat diuji dengan angka sintetis.
func govern(avg_ms: float, max_ms: float, dt: float = 1.0) -> void:
	if not dyn_enabled():
		return
	if max_ms > 400.0 and avg_ms < LOWER_MS:               # satu lonjakan besar (pemuatan/jeda), bukan beban terus-menerus
		return
	var lv := level()
	var sz := DisplayServer.window_get_size()
	var base := preset_scale(lv, sz.x, sz.y)
	var floor_d: float = FLOOR_SCALE[lv] / base if lv < 2 else 0.7 / base
	_since_raise += dt
	if avg_ms > LOWER_MS:
		_good_s = 0.0
		if dyn > floor_d + 0.001:
			dyn = maxf(dyn - STEP, floor_d)
			last_event = "turun -> dyn=%.2f (%.1f ms)" % [dyn, avg_ms]
			if _raised and _since_raise < 6.0:             # percobaan naik gagal -> tunda percobaan berikutnya
				_raise_after = minf(_raise_after * 2.0, RAISE_AFTER_MAX)
			_raised = false
			apply_scale()
		return
	_good_s += dt
	if dyn < 1.0 and _good_s >= _raise_after:
		_good_s = 0.0
		dyn = minf(dyn + STEP, 1.0)
		_raised = true
		_since_raise = 0.0
		last_event = "naik -> dyn=%.2f" % dyn
		apply_scale()
	elif _raised and _since_raise > 20.0:                  # naik tadi bertahan -> percobaan berikutnya boleh lebih cepat
		_raised = false
		_raise_after = maxf(_raise_after * 0.5, RAISE_AFTER_MIN)


## Untuk uji/ringkasan di Pengaturan.
func summary() -> String:
	return "GPU: %s · RAM: %s · Kualitas otomatis: %s · Skala 3D: %d%%" % [gpu_name if gpu_name != "" else "?",
		"%d MB" % int(info.get("ram_mb", -1)) if int(info.get("ram_mb", -1)) > 0 else "?", ["Lancar", "Sedang", "Bagus"][tier], int(round(scale_now() * 100.0))]
