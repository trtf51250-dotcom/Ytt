class_name UiTheme
extends RefCounted
## Tema UI bergaya RPG fantasi (biru malam + emas). Semua dibuat lewat kode: tidak ada aset gambar luar.

const NAVY := Color(0.07, 0.10, 0.22)
const PANEL := Color(0.10, 0.14, 0.30, 0.97)
const PANEL_LIGHT := Color(0.16, 0.21, 0.42, 1.0)
const GOLD := Color(0.97, 0.78, 0.30)
const GOLD_DARK := Color(0.72, 0.52, 0.16)
const BLUE := Color(0.32, 0.55, 0.95)
const SKY := Color(0.62, 0.8, 1.0)
const TEXT := Color(0.95, 0.97, 1.0)
const TEXT_DIM := Color(0.68, 0.74, 0.9)
const GOOD := Color(0.45, 0.9, 0.55)
const BAD := Color(1.0, 0.45, 0.45)
const RARITY := [Color(0.75, 0.78, 0.85), Color(0.5, 0.9, 0.55), Color(0.45, 0.7, 1.0), Color(0.78, 0.55, 1.0), Color(1.0, 0.8, 0.3), Color(1.0, 0.45, 0.6)]

static var _theme: Theme


static func box(bg: Color, border: Color = Color(0, 0, 0, 0), bw: int = 0, radius: int = 12, margin: int = 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.content_margin_left = margin
	s.content_margin_right = margin
	s.content_margin_top = margin * 0.7
	s.content_margin_bottom = margin * 0.7
	s.anti_aliasing = true
	return s


static func get_theme() -> Theme:
	if _theme != null:
		return _theme
	var t := Theme.new()
	t.default_font_size = 22
	# --- Label
	t.set_color("font_color", "Label", TEXT)
	# PERF: bayangan teks (font_shadow) membuat TIAP HURUF jadi draw call sendiri (teks 40 huruf = 77 draw call vs 1 tanpa bayangan; terukur
	# di tools/perf_probe4_bot). Diganti outline tipis: tetap terbaca, hanya +1 batch.
	t.set_color("font_shadow_color", "Label", Color(0, 0, 0, 0))
	t.set_constant("outline_size", "Label", 2)
	t.set_color("font_outline_color", "Label", Color(0.02, 0.03, 0.1, 0.75))
	# --- Button
	t.set_stylebox("normal", "Button", box(PANEL_LIGHT, GOLD_DARK, 2, 12, 16))
	t.set_stylebox("hover", "Button", box(Color(0.22, 0.28, 0.52), GOLD, 2, 12, 16))
	t.set_stylebox("pressed", "Button", box(Color(0.12, 0.16, 0.34), GOLD, 3, 12, 16))
	t.set_stylebox("disabled", "Button", box(Color(0.14, 0.17, 0.28, 0.8), Color(0.3, 0.33, 0.45), 2, 12, 16))
	t.set_stylebox("focus", "Button", box(Color(0, 0, 0, 0), GOLD, 3, 12, 16))
	t.set_color("font_color", "Button", TEXT)
	t.set_color("font_hover_color", "Button", Color(1, 1, 1))
	t.set_color("font_pressed_color", "Button", GOLD)
	t.set_color("font_disabled_color", "Button", Color(0.55, 0.6, 0.72))
	t.set_font_size("font_size", "Button", 22)
	# --- Panel
	t.set_stylebox("panel", "PanelContainer", box(PANEL, GOLD_DARK, 3, 18, 16))
	t.set_stylebox("panel", "Panel", box(PANEL, GOLD_DARK, 3, 18, 16))
	# --- ProgressBar
	t.set_stylebox("background", "ProgressBar", box(Color(0.04, 0.06, 0.14, 0.9), Color(0, 0, 0, 0.5), 1, 8, 0))
	t.set_stylebox("fill", "ProgressBar", box(BLUE, Color(0, 0, 0, 0), 0, 8, 0))
	t.set_color("font_color", "ProgressBar", TEXT)
	# --- Slider (besar agar mudah disentuh)
	t.set_stylebox("slider", "HSlider", box(Color(0.2, 0.26, 0.48), Color(0.5, 0.6, 0.9, 0.7), 1, 8, 9))
	t.set_stylebox("grabber_area", "HSlider", box(BLUE, Color(0, 0, 0, 0), 0, 8, 9))
	t.set_stylebox("grabber_area_highlight", "HSlider", box(SKY, Color(0, 0, 0, 0), 0, 8, 9))
	var grab := _circle_tex(34, GOLD)
	t.set_icon("grabber", "HSlider", grab)
	t.set_icon("grabber_highlight", "HSlider", grab)
	t.set_constant("center_grabber", "HSlider", 0)
	# --- Scroll
	t.set_stylebox("scroll", "VScrollBar", box(Color(0.04, 0.06, 0.14, 0.6), Color(0, 0, 0, 0), 0, 8, 0))
	t.set_stylebox("grabber", "VScrollBar", box(GOLD_DARK, Color(0, 0, 0, 0), 0, 8, 0))
	t.set_stylebox("grabber_highlight", "VScrollBar", box(GOLD, Color(0, 0, 0, 0), 0, 8, 0))
	t.set_stylebox("grabber_pressed", "VScrollBar", box(GOLD, Color(0, 0, 0, 0), 0, 8, 0))
	# --- CheckButton / OptionButton / TabContainer ringkas
	t.set_stylebox("panel", "TabContainer", box(Color(0.08, 0.11, 0.24, 0.9), GOLD_DARK, 2, 10, 8))
	t.set_stylebox("tab_selected", "TabContainer", box(PANEL_LIGHT, GOLD, 2, 10, 14))
	t.set_stylebox("tab_unselected", "TabContainer", box(Color(0.1, 0.13, 0.28), GOLD_DARK, 1, 10, 14))
	t.set_stylebox("tab_hovered", "TabContainer", box(Color(0.2, 0.26, 0.5), GOLD, 1, 10, 14))
	t.set_color("font_selected_color", "TabContainer", GOLD)
	t.set_color("font_unselected_color", "TabContainer", TEXT_DIM)
	t.set_color("font_hovered_color", "TabContainer", Color(1, 1, 1))
	_theme = t
	return t


static func _circle_tex(d: int, col: Color) -> ImageTexture:
	var img := Image.create(d, d, false, Image.FORMAT_RGBA8)
	var c := Vector2(d * 0.5, d * 0.5)
	for y in d:
		for x in d:
			var dist := Vector2(x + 0.5, y + 0.5).distance_to(c)
			var a := clampf(d * 0.5 - dist, 0.0, 1.0)
			var edge := clampf(dist - (d * 0.5 - 4.0), 0.0, 1.0)
			var cc := col.lerp(Color(0.5, 0.36, 0.1), edge)
			img.set_pixel(x, y, Color(cc.r, cc.g, cc.b, a))
	return ImageTexture.create_from_image(img)


## Tombol bergaya dengan teks (tinggi minimal ramah sentuhan).
static func button(text: String, min_size: Vector2 = Vector2(0, 54)) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	return b


static func accent_button(text: String, col: Color = GOLD, min_size: Vector2 = Vector2(0, 58)) -> Button:
	var b := button(text, min_size)
	b.add_theme_stylebox_override("normal", box(col.darkened(0.25), col, 3, 14, 18))
	b.add_theme_stylebox_override("hover", box(col.darkened(0.1), col.lightened(0.2), 3, 14, 18))
	b.add_theme_stylebox_override("pressed", box(col.darkened(0.4), col, 3, 14, 18))
	b.add_theme_color_override("font_color", Color(1, 1, 1))
	b.add_theme_font_size_override("font_size", 24)
	return b


static func label(text: String, size: int = 22, col: Color = TEXT, align: int = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = align
	return l


static func bar(color: Color, value: float = 1.0, h: float = 18.0) -> ProgressBar:
	var p := ProgressBar.new()
	p.min_value = 0.0
	p.max_value = 1.0
	p.value = value
	p.show_percentage = false
	p.custom_minimum_size = Vector2(0, h)
	p.add_theme_stylebox_override("fill", box(color, Color(0, 0, 0, 0), 0, 8, 0))
	return p


## Margin area aman layar (notch / lubang kamera / sudut membulat) dalam koordinat viewport: {left, top, right, bottom}.
## Di PC (area aman = seluruh jendela) hasilnya nol semua.
static func safe_insets() -> Dictionary:
	var zero := {"left": 0.0, "top": 0.0, "right": 0.0, "bottom": 0.0}
	if OS.get_cmdline_user_args().has("--bot=1"):
		return zero
	var win := Vector2(DisplayServer.window_get_size())
	var vp := Vector2(ProjectSettings.get_setting("display/window/size/viewport_width", 1280), ProjectSettings.get_setting("display/window/size/viewport_height", 720))
	if win.x <= 0.0 or win.y <= 0.0:
		return zero
	var area := Rect2(DisplayServer.get_display_safe_area())
	if area.size.x <= 0.0 or area.size.y <= 0.0:
		return zero
	return insets_from(area, win, vp)


## Dipisah agar bisa diuji: area aman (piksel jendela) -> margin di ruang viewport (stretch "expand" memakai satu skala).
static func insets_from(area: Rect2, win: Vector2, vp: Vector2) -> Dictionary:
	var k := minf(win.x / vp.x, win.y / vp.y)           # skala stretch canvas_items + expand
	if k <= 0.0:
		k = 1.0
	var l := maxf(0.0, area.position.x) / k
	var t := maxf(0.0, area.position.y) / k
	var r := maxf(0.0, win.x - area.end.x) / k
	var b := maxf(0.0, win.y - area.end.y) / k
	return {"left": minf(l, 120.0), "top": minf(t, 80.0), "right": minf(r, 120.0), "bottom": minf(b, 80.0)}


## Terapkan margin area aman pada Control layar-penuh (HUD, kontrol sentuh).
static func apply_safe_area(c: Control) -> void:
	var m := safe_insets()
	c.offset_left = m["left"]
	c.offset_top = m["top"]
	c.offset_right = -m["right"]
	c.offset_bottom = -m["bottom"]
