extends Node3D
## Scene lobi Aurelia: merangkai dunia, pemain, kamera, siang-malam, NPC, HUD, kontrol sentuh, dialog, dan panel menu.
## Interaksi: NPC / objek terdekat (dalam radius) -> prompt di HUD -> tombol Interaksi (E / tombol sentuh) atau ketuk prompt.

var world: LobbyWorld
var player: Player
var cam: CameraRig
var daynight: DayNight
var ui: CanvasLayer
var hud: Hud
var touch: TouchControls
var dialogue: DialogueBox
var host: PanelHost
var npcs: Dictionary = {}
var villagers: Array = []
var _target: Dictionary = {}
var _talking: Npc
var _hp_timer := 0.0
var _last_leader := ""
var _auto_attack_gate := 0.0


func _ready() -> void:
	InputSetup.ensure()
	WorldMats.reset()
	Sfx.music("music_main")
	daynight = DayNight.new()
	daynight.name = "DayNight"
	add_child(daynight)
	world = LobbyWorld.new()
	world.name = "World"
	add_child(world)
	world.build()
	_spawn_npcs()
	player = Player.new()
	player.name = "Player"
	add_child(player)
	_last_leader = GameState.leader()
	player.set_character(_last_leader)
	player.global_position = LobbyLayout.SPAWN
	player.facing = deg_to_rad(LobbyLayout.SPAWN_YAW)
	player.global_position = _spawn_point()
	cam = CameraRig.new()
	cam.name = "CameraRig"
	add_child(cam)
	cam.target = player
	cam.snap_to_target()
	_build_ui()
	Quality.apply(get_viewport(), daynight.sun, cam.cam, daynight.env)
	SkyLife.make(self, daynight, cam.cam, Vector3(0, 0, 6), 150.0, 78.0, 330.0)
	var amb := Ambient.new()
	amb.name = "Ambient"
	add_child(amb)
	amb.setup(player, daynight)
	GameState.changed.connect(_on_state_changed)
	_update_markers()
	_check_bot()
	_opening_sequence()


## Urutan pembuka: prolog cerita (sekali per dunia), lalu hadiah login otomatis.
func _opening_sequence() -> void:
	await StoryPlayer.play(self, "prolog")
	_auto_login_gift()


## Titik muncul: kembali dari stage = di depan portal/gerbang; baru mulai = titik spawn.
func _spawn_point() -> Vector3:
	return LobbyLayout.SPAWN


func _build_ui() -> void:
	ui = CanvasLayer.new()
	ui.name = "UI"
	ui.layer = 10
	add_child(ui)
	hud = Hud.new()
	ui.add_child(hud)
	touch = TouchControls.new()
	ui.add_child(touch)
	dialogue = DialogueBox.new()
	ui.add_child(dialogue)
	host = PanelHost.new()
	host.context = {"lobby": self, "player": player}
	add_child(host)
	hud.menu_pressed.connect(_on_menu)
	hud.adventure_pressed.connect(func(): host.open("stage_select"))
	hud.interact_pressed.connect(_try_interact)
	hud.profile_pressed.connect(func(): host.open("profile"))
	dialogue.action_chosen.connect(_run_action)
	dialogue.closed.connect(_on_dialogue_closed)
	host.opened.connect(func(_id): _set_ui_modal(true))
	host.closed.connect(func(): _set_ui_modal(false))
	touch.touch_enabled = DisplayServer.is_touchscreen_available() or bool(GameState.setting("force_touch")) or _arg("touch") != ""


func _set_ui_modal(on: bool) -> void:
	var open := on or dialogue.is_open
	player.control_enabled = not open
	cam.enabled = not open
	if open:
		player.move_input = Vector2.ZERO
		touch.release_all()
	touch.visible = not open and touch.touch_enabled
	hud.visible = not dialogue.is_open


func _on_menu(id: String) -> void:
	match id:
		"shop":
			host.open("shop", {"tab": "weapon"})
		_:
			host.open(id)


# ---------------------------------------------------------------- NPC
func _spawn_npcs() -> void:
	var root := Node3D.new()
	root.name = "Npcs"
	add_child(root)
	for id in NpcDefs.ids():
		var spot: Vector2 = LobbyLayout.NPC_SPOTS.get(id, Vector2.ZERO)
		var n := Npc.new()
		root.add_child(n)
		n.setup(id)
		n.position = Vector3(spot.x, 0.04, spot.y)
		n.face_yaw(float(LobbyLayout.NPC_FACE.get(id, atan2(-spot.x, -spot.y))))
		npcs[id] = n
	for d in NpcDefs.VILLAGERS:
		var v := Villager.new()
		root.add_child(v)
		v.setup(d)
		villagers.append(v)


func _update_markers() -> void:
	if not npcs.has("guild_master"):
		return
	var m := ""
	if GameState.ready_quest_count() > 0:
		m = "?"
	elif GameState.quest_state("q_welcome") == "active":
		m = "!"
	(npcs["guild_master"] as Npc).set_marker(m)


func _on_state_changed(kind: String) -> void:
	match kind:
		"quest":
			_update_markers()
		"party":
			var lead := GameState.leader()
			if lead != _last_leader:
				_last_leader = lead
				player.set_character(lead)
		"settings":
			cam.apply_settings()
			daynight.apply_mode()
			Quality.apply(get_viewport(), daynight.sun, cam.cam, daynight.env)
			touch.layout()


# ---------------------------------------------------------------- interaksi
func _find_target() -> Dictionary:
	var pp := player.global_position
	var best := {}
	var best_r := 1.0
	for id in npcs:
		var n: Npc = npcs[id]
		var d := Vector2(pp.x - n.global_position.x, pp.z - n.global_position.z).length()
		var r := d / n.talk_radius
		if r < best_r:
			best_r = r
			best = {"kind": "npc", "npc": n, "prompt": "Bicara dengan %s" % n.display_name}
	for it: Dictionary in world.interactions:
		var ip: Vector3 = it["pos"]
		var d2 := Vector2(pp.x - ip.x, pp.z - ip.z).length()
		var r2 := d2 / float(it["radius"])
		if r2 < best_r:
			best_r = r2
			best = {"kind": "obj", "action": it["action"], "prompt": it["prompt"], "id": it["id"], "pos": ip}
	return best


func _try_interact() -> void:
	if _target.is_empty() or not player.control_enabled or dialogue.is_open or host.is_open():
		return
	if _target["kind"] == "npc":
		_talk(_target["npc"])
	else:
		match _target["id"]:
			"portal", "gate":
				Sfx.play("portal")
		_run_action(_target["action"])


func _talk(n: Npc) -> void:
	_talking = n
	n.look_at_node = player
	var d := n.global_position - player.global_position
	player.facing = atan2(d.x, d.z)
	player.control_enabled = false
	player.move_input = Vector2.ZERO
	touch.release_all()
	touch.visible = false
	cam.enabled = false
	hud.visible = false
	GameState.report_event("talk", n.npc_id)
	dialogue.start(n.display_name, n.title, NpcDefs.dialogue(n.npc_id))


func _on_dialogue_closed() -> void:
	if _talking:
		_talking.look_at_node = null
		_talking = null
	if not host.is_open():
		_set_ui_modal(false)


func _run_action(action: String) -> void:
	match action:
		"quests": host.open("quest")
		"adventure": host.open("stage_select")
		"party": host.open("party")
		"gacha": host.open("gacha")
		"character": host.open("character")
		"equipment": host.open("equipment")
		"smith": host.open("smith")
		"shop:weapon": host.open("shop", {"tab": "weapon"})
		"shop:item": host.open("shop", {"tab": "item"})
		"shop:sell": host.open("shop", {"tab": "sell"})
		_: push_warning("Aksi dialog tidak dikenal: %s" % action)


# ---------------------------------------------------------------- loop
func _physics_process(delta: float) -> void:
	player.cam_yaw = cam.yaw
	if player.control_enabled:
		player.move_input = InputSetup.keyboard_vector()
		if Input.is_action_pressed("attack"):
			player.do_attack()
		if Input.is_action_just_pressed("skill"):
			player.do_skill()
		if Input.is_action_just_pressed("dodge"):
			player.do_dodge()
		if Input.is_action_just_pressed("interact"):
			_try_interact()
	elif dialogue.is_open and (Input.is_action_just_pressed("interact") or Input.is_action_just_pressed("attack")):
		dialogue.advance()
	_target = _find_target() if player.control_enabled else {}
	hud.set_prompt(str(_target.get("prompt", "")))
	touch.interact_ready = not _target.is_empty()
	touch.set_cooldown("skill", player.skill_cd, player.skill_cd_max)
	touch.set_cooldown("dodge", player.dodge_cd, 0.75)
	_hp_timer -= delta
	if _hp_timer <= 0.0:
		_hp_timer = 0.15
		hud.set_hp(player.hp, player.max_hp)
		hud.set_time_text(daynight.hour_text())
		hud.set_fps(Engine.get_frames_per_second())
		cam.blocked_rects = hud.blocked_rects() + touch.blocked_rects() + dialogue.blocked_rects()
	_update_occlusion()


func _update_occlusion() -> void:
	var head := player.global_position + Vector3(0, 1.4, 0)
	for b in world.buildings:
		if not b.can_fade:
			continue
		var box: AABB = b.world_aabb.grow(-0.25)           # dulu +0,3: bangunan memudar hanya karena pemain berada di dekatnya
		b.set_occluding(cam.segment_hits_aabb(head, box, 0.8))


# ---------------------------------------------------------------- bot uji
## Saat masuk lobi: buka panel hadiah login bila ada yang bisa diambil; kalau tidak, buka panel Event bila ada event aktif yang belum dilihat.
## (Tidak dijalankan saat uji bot otomatis.)
func _auto_login_gift() -> void:
	if _arg("bot") != "" and _arg("autogift") == "":
		return
	var which := ""
	if GameState.login_claimable():
		which = "login"
	elif GameState.unseen_event_count() > 0:
		which = "event"
	if which == "":
		return
	await get_tree().create_timer(0.8).timeout
	if is_inside_tree() and not host.is_open() and not dialogue.is_open:
		host.open(which)


func _arg(key: String, default: String = "") -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % key):
			return a.substr(key.length() + 3)
	return default


func _shot(name: String) -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	var dir := _arg("shots", "/tmp")
	get_viewport().get_texture().get_image().save_png("%s/%s.png" % [dir, name])
	print("shot ", name)


func _check_bot() -> void:
	if _arg("bot") == "":
		return
	call_deferred("_bot_run")


func _bot_run() -> void:
	var script_path := "res://tools/" + _arg("botscript", "lobby_bot") + ".gd"
	if ResourceLoader.exists(script_path):
		var bot: Object = (load(script_path) as GDScript).new()
		await bot.run(self)
	get_tree().quit()
