class_name SkyLife
extends Node3D
## Langit yang hidup: awan kartun 3D (gumpalan blob bersusun, pencahayaan toon) yang melayang pelan di sekeliling kota,
## bayangan awan yang bergeser di tanah, serta matahari (siang) / bulan (malam) mengikuti arah cahaya DayNight.
## Awan dibuat dari mesh (MeshKit.blob), bukan gambar tempel. Kualitas Lancar (0): awan lebih sedikit & tanpa bayangan awan.

const WIND := Vector2(1.0, 0.28)                   # arah angin (dinormalkan)
const SPEED := 1.4                                 # m/dtk awan
const SHADOW_SPEED := 0.00016                      # UV/dtk bayangan awan

var daynight: DayNight
var cam: Camera3D
var center := Vector3.ZERO
var extent := 150.0                                # setengah lebar area pergerakan awan
var inner := 0.0                                   # awan hanya muncul di luar jarak ini dari pusat
var low_enabled := true                            # awan "bank" rendah di cakrawala
var _clouds: Array = []                            # {mi, speed}
var _cloud_mat: ShaderMaterial
var _shadow: MeshInstance3D
var _shadow_mat: ShaderMaterial
var _sun: MeshInstance3D
var _sun_mat: ShaderMaterial
var _scroll := Vector2.ZERO
var _tex_sun: Texture2D
var _tex_moon: Texture2D
var _acc := 0.0
var _on := true
var _shadow_on := true


static func make(parent: Node, dn: DayNight, camera: Camera3D, p_center: Vector3, p_extent: float, p_inner: float, ground_size: float, p_low: bool = true) -> SkyLife:
	var s := SkyLife.new()
	s.name = "SkyLife"
	s.daynight = dn
	s.cam = camera
	s.center = p_center
	s.extent = p_extent
	s.inner = p_inner
	s.low_enabled = p_low
	parent.add_child(s)
	s.build(ground_size)
	return s


## Satu awan kumulus: dasar rata dari beberapa gumpalan melebar + menara gumpalan di atasnya.
static func cloud_mesh(seed_v: int) -> ArrayMesh:
	var r := RandomNumberGenerator.new()
	r.seed = seed_v
	var k := MeshKit.new(seed_v)
	var white := Color(1.0, 1.0, 1.0)
	var n := r.randi_range(5, 7)
	for i in n:
		var t := (float(i) + 0.5) / n
		var x := lerpf(-9.0, 9.0, t) + r.randf_range(-1.0, 1.0)
		var rad := (4.6 + 3.4 * sin(t * PI)) * r.randf_range(0.85, 1.15)
		k.blob(Vector3(x, rad * 0.55, r.randf_range(-2.0, 2.0)), rad, MeshKit.T_PLASTER, white, 4, 8, 0.72, 0.5, 0.0, 1.15, 1.0)
	var tops := r.randi_range(2, 4)
	for i in tops:
		var t2 := (float(i) + 0.5) / tops
		var x2 := lerpf(-4.5, 5.5, t2) + r.randf_range(-1.0, 1.0)
		var rad2 := (4.2 + 2.4 * sin(t2 * PI)) * r.randf_range(0.85, 1.15)
		k.blob(Vector3(x2, 4.6 + rad2 * 0.6, r.randf_range(-1.5, 1.5)), rad2, MeshKit.T_PLASTER, white, 4, 8, 0.85, 0.5)
	return k.build()


func build(ground_size: float) -> void:
	var lvl := Quality.level()
	var rng := RandomNumberGenerator.new()
	rng.seed = 90210
	_cloud_mat = ShaderMaterial.new()
	_cloud_mat.shader = load("res://assets/sky/cloud_mesh.gdshader")
	var meshes: Array = []
	for i in 4:
		meshes.append(cloud_mesh(31 + i * 17))
	var n_high: int = [3, 5, 7][lvl]
	var n_low: int = [3, 6, 9][lvl] if low_enabled else 0
	for i in n_high + n_low:
		var high: bool = i < n_high
		var mi := MeshInstance3D.new()
		mi.mesh = meshes[i % meshes.size()]
		mi.material_override = _cloud_mat
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var a := rng.randf() * TAU
		var r := rng.randf_range(maxf(inner, 95.0), extent) if not high else rng.randf_range(extent * 0.55, extent)
		var y := rng.randf_range(26.0, 40.0) if high else rng.randf_range(3.0, 12.0)
		mi.position = center + Vector3(cos(a) * r, y, sin(a) * r)
		mi.rotation.y = rng.randf() * TAU
		var sc := rng.randf_range(1.5, 2.6) if high else rng.randf_range(1.2, 2.2)
		mi.scale = Vector3(sc, sc * rng.randf_range(0.9, 1.2), sc)
		add_child(mi)
		_clouds.append({"mi": mi, "speed": SPEED * rng.randf_range(0.7, 1.3)})
	# bayangan awan di tanah
	if lvl > 0:
		_shadow = MeshInstance3D.new()
		var pm := PlaneMesh.new()
		pm.size = Vector2(ground_size, ground_size)
		_shadow.mesh = pm
		_shadow_mat = ShaderMaterial.new()
		_shadow_mat.shader = load("res://assets/sky/cloud_shadow.gdshader")
		_shadow_mat.set_shader_parameter("noise", load("res://assets/sky/cloud_noise.png"))
		_shadow.material_override = _shadow_mat
		_shadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_shadow.position = center + Vector3(0, 0.22, 0)
		add_child(_shadow)
	# matahari / bulan
	_tex_sun = load("res://assets/sky/sun_disc.png")
	_tex_moon = load("res://assets/sky/moon_disc.png")
	_sun = MeshInstance3D.new()
	var sq := QuadMesh.new()
	sq.size = Vector2(1, 1)
	_sun.mesh = sq
	_sun_mat = ShaderMaterial.new()
	var ss := Shader.new()
	ss.code = "shader_type spatial;\nrender_mode unshaded, blend_add, depth_draw_never, cull_disabled, fog_disabled;\nuniform sampler2D tex : source_color, filter_linear;\nuniform float k = 1.0;\nvoid vertex(){ vec3 sc = vec3(length(MODEL_MATRIX[0].xyz), length(MODEL_MATRIX[1].xyz), 1.0); mat4 bb = mat4(INV_VIEW_MATRIX[0]*sc.x, INV_VIEW_MATRIX[1]*sc.y, INV_VIEW_MATRIX[2], MODEL_MATRIX[3]); MODELVIEW_MATRIX = VIEW_MATRIX * bb; }\nvoid fragment(){ vec4 c = texture(tex, UV); ALBEDO = c.rgb * c.a * k; ALPHA = 1.0; }\n"
	_sun_mat.shader = ss
	_sun_mat.set_shader_parameter("tex", _tex_sun)
	_sun.material_override = _sun_mat
	_sun.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_sun.extra_cull_margin = 16384.0
	add_child(_sun)
	_refresh()


func _process(delta: float) -> void:
	var wind := WIND.normalized()
	for c in _clouds:
		var mi: MeshInstance3D = c["mi"]
		mi.position += Vector3(wind.x, 0, wind.y) * float(c["speed"]) * delta
		var d := Vector2(mi.position.x - center.x, mi.position.z - center.z)
		if d.x > extent:
			mi.position.x -= extent * 2.0
		elif d.x < -extent:
			mi.position.x += extent * 2.0
		if d.y > extent:
			mi.position.z -= extent * 2.0
		elif d.y < -extent:
			mi.position.z += extent * 2.0
	_scroll += wind * SHADOW_SPEED * delta * 60.0
	if _shadow_mat:
		_shadow_mat.set_shader_parameter("scroll", _scroll)
	_acc += delta
	if _acc > 0.2:
		_acc = 0.0
		_refresh()
	_place_sun()


## Warna/kekuatan mengikuti jam (siang putih terang, senja jingga, malam redup kebiruan).
func _refresh() -> void:
	if daynight == null or daynight.sun == null:
		return
	_on = bool(GameState.setting("sky_life"))
	_shadow_on = _on and bool(GameState.setting("cloud_shadows"))
	for c in _clouds:
		(c["mi"] as MeshInstance3D).visible = _on
	var h := daynight.hour
	var day := h >= 5.8 and h <= 18.4
	var base := daynight.sun.light_color.lerp(Color.WHITE, 0.5)
	var bright := clampf(0.5 + daynight.sun.light_energy * 0.6, 0.45, 1.0)
	_cloud_mat.set_shader_parameter("tint", Color(base.r * bright, base.g * bright, base.b * bright * (1.0 if day else 1.2), 1.0))
	_cloud_mat.set_shader_parameter("glow", 0.55 if day else 0.3)
	if _shadow_mat:
		var s := smoothstep(5.8, 7.5, h) * (1.0 - smoothstep(17.0, 18.6, h))
		_shadow_mat.set_shader_parameter("strength", 0.24 * s)
		_shadow.visible = s > 0.02 and _shadow_on
	if _sun_mat:
		_sun_mat.set_shader_parameter("tex", _tex_sun if day else _tex_moon)
		_sun_mat.set_shader_parameter("k", 1.0 if day else 0.85)


func _place_sun() -> void:
	if _sun == null or cam == null or daynight == null:
		return
	var far := cam.far * 0.82
	var dir := daynight.sun.global_transform.basis.z.normalized()      # arah menuju sumber cahaya
	_sun.global_position = cam.global_position + dir * far
	var size := far * (0.34 if daynight.hour >= 5.8 and daynight.hour <= 18.4 else 0.22)
	_sun.scale = Vector3(size, size, 1.0)
	_sun.visible = _on and dir.y > -0.05
