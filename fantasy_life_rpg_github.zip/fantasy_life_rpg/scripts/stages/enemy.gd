class_name Enemy
extends CharacterBody3D
## Musuh stage: slime (lompat + terkam), kelelawar (terbang, menukik), jamur racun (ledakan spora area), golem kristal (bos: hantam, gelombang kejut, lempar batu).
## Model dibangun prosedural (MeshKit + shader toon_flat); animasi digerakkan kode. Serangan punya fase persiapan (telegraf merah) agar bisa dihindari.
## Stage menghubungkan sinyal hit_player(damage, from) dan died(enemy).

signal died(enemy: Enemy)
signal hit_player(damage: int, from: Vector3)
signal hit_ghost(ghost: Node3D, damage: int, from: Vector3)     # co-op: serangan mengenai pemain lain (host)
signal request_spawn(kind: String, pos: Vector3)
signal request_shake(amount: float)
signal phase_changed(phase: int)

const TOON := preload("res://shaders/toon_flat.gdshader")
const T := 0
const BEAST_SCENE := "res://scenes/stages/monster_rig.tscn"
const BEAST_SCALE := 2.3
const WITHER_SCENE := "res://scenes/stages/wither_rig.tscn"
const WITHER_SCALE := 1.4
const WITHER_FOOT := 1.88          # jarak telapak kaki ke titik asal model (satuan model) -> dikali skala agar menapak tanah
const WITHER_HOVER := 0.55         # tinggi melayang di atas tanah (meter)

## Penyeimbang kesulitan: musuh biasa dulu terlalu rapuh (HP kecil, mati dalam 1-2 pukulan), bos juga cepat tumbang.
const HP_MULT_MINION := 2.6
const HP_MULT_BOSS := 1.8
const ATK_MULT_MINION := 1.2
const ATK_MULT_BOSS := 1.1
const POISE_FRAC := 0.28          # pukulan >= 28% HP maks memotong aba-aba serangan; pukulan kecil tidak
const KINDS := {
	"slime": {"name": "Slime", "hp": 38, "atk": 7, "def": 0, "speed": 2.5, "radius": 0.55, "range": 1.5, "windup": 0.5, "recover": 1.0},
	"slime_mini": {"name": "Slime Kecil", "hp": 16, "atk": 5, "def": 0, "speed": 3.3, "radius": 0.36, "range": 1.1, "windup": 0.35, "recover": 0.6},
	"bat": {"name": "Kelelawar Gua", "hp": 24, "atk": 6, "def": 0, "speed": 4.3, "radius": 0.4, "range": 1.0, "windup": 0.5, "recover": 0.9, "flying": true},
	"mushroom": {"name": "Jamur Racun", "hp": 62, "atk": 9, "def": 1, "speed": 1.8, "radius": 0.6, "range": 2.0, "windup": 0.85, "recover": 1.3},
	"golem": {"name": "Golem Kristal", "hp": 720, "atk": 19, "def": 3, "speed": 2.0, "radius": 1.5, "range": 5.0, "windup": 1.0, "recover": 1.2, "boss": true, "phase_text": "Golem mengamuk!"},
	"cave_beast": {"name": "Penguasa Gua", "hp": 640, "atk": 22, "def": 3, "speed": 2.7, "radius": 1.6, "range": 4.0, "windup": 0.9, "recover": 1.2, "boss": true, "phase_text": "Penguasa Gua meraung murka!"},
	"wither_god": {"name": "Dewa Wither", "hp": 1000, "atk": 28, "def": 5, "speed": 2.3, "radius": 1.7, "range": 7.0, "windup": 1.0, "recover": 1.4, "boss": true, "phase_text": "Dewa Wither membangkitkan jiwa-jiwa gelap!"},
	# --- musuh humanoid (Bab 4-5), lihat HumanoidEnemy
	"cultist": {"name": "Pengikut Berkerudung", "hp": 70, "atk": 10, "def": 1, "speed": 3.1, "radius": 0.5, "range": 1.7, "windup": 0.55, "recover": 0.9, "humanoid": true},
	"shadow_mage": {"name": "Penyihir Bayangan", "hp": 54, "atk": 12, "def": 0, "speed": 2.5, "radius": 0.5, "range": 9.0, "windup": 0.9, "recover": 1.1, "humanoid": true},
	"chain_knight": {"name": "Ksatria Rantai", "hp": 170, "atk": 15, "def": 4, "speed": 2.3, "radius": 0.65, "range": 2.2, "windup": 0.85, "recover": 1.0, "humanoid": true},
	"ronin": {"name": "Ronin Bayangan", "hp": 105, "atk": 14, "def": 1, "speed": 3.5, "radius": 0.5, "range": 1.9, "windup": 0.5, "recover": 0.8, "humanoid": true},
	"uranos": {"name": "Uranos, Penyihir Kehampaan", "hp": 1250, "atk": 31, "def": 5, "speed": 2.5, "radius": 0.9, "range": 8.0, "windup": 1.0, "recover": 1.0, "boss": true, "humanoid": true, "phase_text": "Uranos membuka Mata Kehampaan!"},
	"chain_king": {"name": "Raja Rantai Merah", "hp": 1500, "atk": 35, "def": 7, "speed": 2.4, "radius": 1.0, "range": 5.0, "windup": 1.0, "recover": 1.0, "boss": true, "humanoid": true, "phase_text": "Rantai Merah membelenggu arena!"},
}

var kind := "slime"
var info: Dictionary
var hp := 1
var max_hp := 1
var atk := 1
var defense := 0
var speed := 2.0
var radius := 0.5
var hit_radius := 0.5
var is_boss := false
var flying := false
var dead := false
var target: Node3D
var puppet := false                 # co-op (client): tidak menjalankan AI, hanya mengikuti snapshot dari host
var net_id := 0
var _net_pos := Vector3.ZERO
var _net_yaw := 0.0
var _net_has := false
var fx_parent: Node3D

var state := "spawn"
var _t := 0.0
var _anim_t := 0.0
var _knock := Vector3.ZERO
var _dir := Vector3.FORWARD
var _strike_dir := Vector3.ZERO
var _did_hit := false
var _cooldown := 1.2
var _slow := 1.0          # faktor waktu lokal (Aion): 1 = normal, 0.5 = setengah kecepatan
var _slow_t := 0.0
var _stagger_immune := 0.0
var _hop_t := 0.0
var _orbit_dir := 1.0
var _dive_cd := 2.0
var _attack := ""
var _last_attack := ""
var _phase := 1
var _telegraph: MeshInstance3D
var _wave_r := 0.0
var _wave_active := false
var _wave_hit := false
var _wave_center := Vector3.ZERO
var _visual: Node3D
var _mesh_scale := 1.0
var elite := false
var _tag: Label3D
var _mat: ShaderMaterial
var _wing_l: Node3D
var _wing_r: Node3D
var _arm_l: Node3D
var _arm_r: Node3D
var _cap: Node3D
var _bar_bg: MeshInstance3D
var _bar_fg: MeshInstance3D
var _flash := 0.0
var _rig: MonsterRig                # hanya untuk "cave_beast" (model GLB + animasi bawaan)
var _overlay: StandardMaterial3D    # kilatan (flash) untuk model GLB
var _beast_key := ""
var _wrig: WitherRig                # hanya untuk "wither_god"
var _wither_key := ""
var _extra_tele: Array = []         # telegraf tambahan (hujan tengkorak)
var _rain_pos: Array = []
var _hover := 0.0
var _hit_hold := 0.0
var _hit_cd := 0.0
var _step_t := 0.0
var _hit_pulse := 0.0           # 1 -> 0 setelah terkena pukulan: kedutan (squash + condong) pada kroco
var _wing_fold := 0.0
var _base_y := 0.0


## level_scale: pengali dari level rekomendasi stage (HP/ATK naik per level).
func setup(p_kind: String, level: int, p_target: Node3D, p_fx: Node3D) -> void:
	kind = p_kind
	info = KINDS[kind]
	target = p_target
	fx_parent = p_fx
	var lv := float(maxi(level - 1, 0))
	var boss_k := bool(info.get("boss", false))
	max_hp = int(info["hp"] * (1.0 + 0.2 * lv) * (HP_MULT_BOSS if boss_k else HP_MULT_MINION))
	hp = max_hp
	atk = int(info["atk"] * (1.0 + 0.13 * lv) * (ATK_MULT_BOSS if boss_k else ATK_MULT_MINION))
	defense = int(info["def"] + lv * 0.5)
	speed = float(info["speed"]) * (1.0 + 0.025 * lv)
	radius = float(info["radius"])
	hit_radius = radius
	is_boss = bool(info.get("boss", false))
	flying = bool(info.get("flying", false))
	_base_y = 1.7 if flying else 0.0
	name = "Enemy_" + kind
	collision_layer = 8
	collision_mask = 1 | 2
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = radius
	cap.height = maxf(radius * 2.0 + 0.3, 1.0) if not is_boss else 3.0
	cs.shape = cap
	cs.position = Vector3(0, cap.height * 0.5, 0)
	add_child(cs)
	Quality.blob(self, radius * (2.4 if is_boss else 1.5))
	_mat = ShaderMaterial.new()
	_mat.shader = TOON
	_visual = Node3D.new()
	_visual.name = "Visual"
	add_child(_visual)
	match kind:
		"slime": _build_slime()
		"slime_mini":
			_mesh_scale = 0.62
			_build_slime()
		"bat": _build_bat()
		"mushroom": _build_mushroom()
		"golem": _build_golem()
		"cave_beast": _build_beast()
		"wither_god": _build_wither()
	if not flying:
		add_child(Fx.shadow(radius * 3.0 + 0.4))
	if not is_boss:
		_build_bar()
	add_to_group("enemies")
	_orbit_dir = 1.0 if randf() < 0.5 else -1.0
	_dive_cd = randf_range(0.8, 1.8)
	_t = 0.7
	state = "spawn"
	_visual.scale = Vector3.ONE * 0.05
	rotation.y = randf() * TAU


## Musuh elit: HP 2x, serangan 1,3x, tidak mudah terpotong, berpendar emas dengan label "ELIT". Dipanggil Stage untuk sebagian musuh gelombang.
func make_elite() -> void:
	if elite or is_boss or dead:
		return
	elite = true
	max_hp = int(max_hp * 2.0)
	hp = max_hp
	atk = int(atk * 1.3)
	defense += 1
	if not info.get("humanoid", false):
		for c in _visual.get_children():
			if c is MeshInstance3D or c is Node3D:
				(c as Node3D).scale *= 1.22
	_tag = Label3D.new()
	_tag.text = "ELIT"
	_tag.font_size = 40
	_tag.pixel_size = 0.0065
	_tag.modulate = Color(1.0, 0.85, 0.35)
	_tag.outline_size = 10
	_tag.outline_modulate = Color(0.25, 0.12, 0.0, 1.0)
	_tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_tag.no_depth_test = true
	_tag.position = Vector3(0, (float(HumanoidEnemy.LOOKS[kind]["h"]) + 0.95) if info.get("humanoid", false) else (2.85 if flying else 1.75), 0)
	add_child(_tag)
	if _bar_fg:
		(_bar_fg.material_override as StandardMaterial3D).albedo_color = Color(1.0, 0.8, 0.25)
		_bar_bg.position.y += 0.5
		_bar_fg.position.y += 0.5
	Fx.ring(fx_parent, global_position + Vector3(0, 0.1, 0), 1.6, Color(1.0, 0.85, 0.35), 0.5)
	_update_bar()


# ---------------------------------------------------------------- model
func _mi(k: MeshKit, nm: String, parent: Node3D = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = nm
	mi.mesh = k.build()
	mi.material_override = _mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if parent == null and _mesh_scale != 1.0:
		mi.scale = Vector3.ONE * _mesh_scale
	(parent if parent != null else _visual).add_child(mi)
	return mi


func _eye(k: MeshKit, p: Vector3, r: float, col: Color = Color(0.08, 0.1, 0.2)) -> void:
	k.blob(p, r, T, col, 3, 6)
	k.blob(p + Vector3(r * 0.25, r * 0.3, r * 0.6), r * 0.38, T, Color(1, 1, 1), 3, 5)


func _build_slime() -> void:
	var k := MeshKit.new(11)
	var pal := [
		[Color(0.4, 0.85, 0.6), Color(0.3, 0.7, 0.55), Color(0.75, 1.0, 0.85)],
		[Color(0.42, 0.68, 1.0), Color(0.3, 0.52, 0.9), Color(0.8, 0.92, 1.0)],
		[Color(0.95, 0.55, 0.7), Color(0.82, 0.4, 0.58), Color(1.0, 0.85, 0.9)],
	]
	var pc: Array = pal[(net_id if net_id != 0 else randi()) % 3]
	k.blob(Vector3(0, 0.44, 0), 0.55, T, pc[0], 6, 10, 0.8, 0.3)
	k.blob(Vector3(0, 0.12, 0), 0.55, T, pc[1], 3, 10, 0.25, 0.0, 0.0, 1.05, 1.05)
	k.blob(Vector3(0, 0.5, -0.05), 0.26, T, MeshKit.glow(pc[2], 0.75), 4, 8, 0.6)       # inti berpendar di dalam tubuh
	k.blob(Vector3(-0.17, 0.78, 0.2), 0.12, T, Color(1, 1, 1), 3, 6, 0.6, 0.0)           # kilap
	k.blob(Vector3(0.3, 0.66, 0.1), 0.05, T, Color(1, 1, 1), 3, 5)
	for bp in [Vector3(-0.3, 0.3, -0.18), Vector3(0.2, 0.22, -0.3), Vector3(0.34, 0.4, 0.05)]:
		k.blob(bp, 0.06, T, pc[2], 3, 5)                                                    # gelembung
	_eye(k, Vector3(-0.2, 0.52, 0.45), 0.11)
	_eye(k, Vector3(0.2, 0.52, 0.45), 0.11)
	k.blob(Vector3(-0.34, 0.38, 0.4), 0.07, T, Color(1.0, 0.6, 0.65), 3, 5, 0.4)            # pipi
	k.blob(Vector3(0.34, 0.38, 0.4), 0.07, T, Color(1.0, 0.6, 0.65), 3, 5, 0.4)
	k.blob(Vector3(0, 0.34, 0.52), 0.05, T, Color(0.1, 0.25, 0.2), 3, 5)
	k.cylinder(Vector3(0, 0.88, 0.0), 0.07, 0.0, 0.18, 5, T, pc[1])                         # jambul tetesan di kepala
	_mi(k, "Body")


func _build_bat() -> void:
	var k := MeshKit.new(12)
	k.blob(Vector3(0, 0, 0), 0.26, T, Color(0.5, 0.35, 0.68), 5, 8, 1.1)
	k.blob(Vector3(0, 0.2, 0.13), 0.19, T, Color(0.55, 0.4, 0.72), 4, 8)
	k.cylinder(Vector3(-0.1, 0.32, 0.12), 0.07, 0.0, 0.2, 5, T, Color(0.45, 0.3, 0.6))
	k.cylinder(Vector3(0.1, 0.32, 0.12), 0.07, 0.0, 0.2, 5, T, Color(0.45, 0.3, 0.6))
	var red := MeshKit.glow(Color(1.0, 0.35, 0.35), 0.9)
	k.blob(Vector3(-0.07, 0.22, 0.29), 0.045, T, red, 3, 5)
	k.blob(Vector3(0.07, 0.22, 0.29), 0.045, T, red, 3, 5)
	k.blob(Vector3(0, 0.12, 0.3), 0.03, T, Color(1, 1, 1), 3, 4)
	k.cylinder(Vector3(-0.05, -0.07, 0.3), 0.0, 0.02, 0.1, 4, T, Color(1, 1, 0.95))          # taring
	k.cylinder(Vector3(0.05, -0.07, 0.3), 0.0, 0.02, 0.1, 4, T, Color(1, 1, 0.95))
	k.blob(Vector3(0, -0.12, 0.05), 0.17, T, Color(0.85, 0.75, 0.95), 3, 8, 0.6)             # bulu dada terang
	_mi(k, "Body")
	for side in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(side * 0.18, 0.05, 0)
		_visual.add_child(pivot)
		var wk := MeshKit.new(13)
		wk.blob(Vector3(side * 0.34, 0, 0), 0.34, T, Color(0.38, 0.25, 0.55), 3, 8, 0.1, 0.1, 0.0, 1.0, 0.7)
		wk.blob(Vector3(side * 0.62, 0, -0.08), 0.2, T, Color(0.3, 0.2, 0.45), 3, 6, 0.1, 0.1, 0.0, 1.0, 0.6)
		_mi(wk, "Wing", pivot)
		if side < 0.0:
			_wing_l = pivot
		else:
			_wing_r = pivot


func _build_mushroom() -> void:
	var k := MeshKit.new(14)
	k.cylinder(Vector3(0, 0, 0), 0.3, 0.24, 0.75, 8, T, Color(0.98, 0.93, 0.8), true)
	_eye(k, Vector3(-0.12, 0.5, 0.22), 0.07)
	_eye(k, Vector3(0.12, 0.5, 0.22), 0.07)
	_mi(k, "Stem")
	_cap = Node3D.new()
	_cap.position = Vector3(0, 0.7, 0)
	_visual.add_child(_cap)
	var ck := MeshKit.new(15)
	ck.blob(Vector3(0, 0.12, 0), 0.74, T, Color(0.88, 0.32, 0.4), 6, 10, 0.62, 0.3)
	for p in [Vector3(0.3, 0.42, 0.25), Vector3(-0.32, 0.38, 0.2), Vector3(0.05, 0.5, -0.3), Vector3(-0.15, 0.52, 0.28), Vector3(0.45, 0.2, -0.2)]:
		ck.blob(p, 0.13, T, Color(1, 0.95, 0.9), 3, 6, 0.5)
	_mi(ck, "Cap", _cap)


func _build_golem() -> void:
	var rock := Color(0.52, 0.58, 0.7)
	var dark := Color(0.4, 0.45, 0.58)
	var glow := MeshKit.glow(Color(0.4, 0.9, 1.0), 0.95)
	var k := MeshKit.new(16)
	k.blob(Vector3(0, 1.9, 0), 1.25, T, rock, 6, 10, 1.0, 0.3, 0.0, 1.15, 0.85)
	k.blob(Vector3(0, 3.35, 0.15), 0.62, T, dark, 5, 8, 0.95, 0.3)
	k.blob(Vector3(-0.22, 3.4, 0.62), 0.12, T, glow, 3, 5)
	k.blob(Vector3(0.22, 3.4, 0.62), 0.12, T, glow, 3, 5)
	k.blob(Vector3(-0.55, 1.0, 0), 0.55, T, dark, 4, 8, 1.2)
	k.blob(Vector3(0.55, 1.0, 0), 0.55, T, dark, 4, 8, 1.2)
	k.blob(Vector3(-0.6, 0.35, 0.1), 0.6, T, rock, 4, 8, 0.6, 0.3, 0.0, 1.1, 1.3)
	k.blob(Vector3(0.6, 0.35, 0.1), 0.6, T, rock, 4, 8, 0.6, 0.3, 0.0, 1.1, 1.3)
	k.crystal(Vector3(0, 1.9, 1.0), 0.28, 0.6, Color(0.4, 0.9, 1.0), 0.95, 6, 75.0)
	k.crystal(Vector3(-0.8, 3.0, -0.3), 0.2, 0.9, Color(0.4, 0.9, 1.0), 0.8, 5, -20.0)
	k.crystal(Vector3(0.7, 3.1, -0.4), 0.17, 0.75, Color(0.55, 0.8, 1.0), 0.8, 5, 25.0)
	k.crystal(Vector3(0, 2.9, -0.8), 0.25, 1.1, Color(0.4, 0.9, 1.0), 0.8, 5, -30.0)
	_mi(k, "Body")
	for side in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(side * 1.45, 2.6, 0)
		_visual.add_child(pivot)
		var ak := MeshKit.new(17)
		ak.blob(Vector3(0, 0, 0), 0.5, T, dark, 4, 8)
		ak.blob(Vector3(side * 0.15, -0.9, 0.1), 0.45, T, rock, 4, 8, 1.4, 0.3, 0.0, 0.9, 0.9)
		ak.blob(Vector3(side * 0.2, -1.65, 0.2), 0.65, T, rock, 5, 8, 0.9)
		ak.crystal(Vector3(side * 0.2, -1.65, 0.75), 0.14, 0.4, Color(0.4, 0.9, 1.0), 0.9, 5, 80.0)
		_mi(ak, "Arm", pivot)
		if side < 0.0:
			_arm_l = pivot
		else:
			_arm_r = pivot


## Efek suara bos dengan peredaman jarak sederhana (makin jauh dari pemain makin pelan).
func _sfx(n: String, pitch: float = 1.0, vol: float = 0.0) -> void:
	var d := 0.0
	if target != null and is_instance_valid(target):
		d = global_position.distance_to(target.global_position)
	Sfx.play(n, pitch, vol - clampf((d - 8.0) * 0.45, 0.0, 14.0))


func _footsteps(delta: float) -> void:
	var fast := kind == "cave_beast" and state == "strike" and _attack == "charge"
	if not (state == "chase" or fast):
		_step_t = 0.15
		return
	_step_t -= delta
	if _step_t <= 0.0:
		_step_t = 0.2 if fast else (0.38 if kind == "cave_beast" else 0.62)
		_sfx("boss_step", randf_range(0.9, 1.1), -2.0)
		if target != null and global_position.distance_to(target.global_position) < 12.0:
			request_shake.emit(0.07)


func _build_beast() -> void:
	var ps: PackedScene = load(BEAST_SCENE)
	_rig = ps.instantiate() as MonsterRig
	_rig.scale = Vector3.ONE * BEAST_SCALE
	_rig.position = Vector3(0, 0, -0.3 * BEAST_SCALE)     # titik tengah badan kira-kira di atas kolisi
	_visual.add_child(_rig)
	# cahaya ungu di sekitar bos: membuat siluetnya terbaca di arena gelap
	var aura := OmniLight3D.new()
	aura.light_color = Color(0.7, 0.4, 1.0)
	aura.light_energy = 1.6
	aura.omni_range = 11.0
	aura.position = Vector3(0, 3.2, 0)
	aura.shadow_enabled = false
	aura.add_to_group("deco_light")
	_visual.add_child(aura)
	_overlay = StandardMaterial3D.new()
	_overlay.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_overlay.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_overlay.albedo_color = Color(1, 1, 1, 0.0)
	var lit: StandardMaterial3D = null
	for n in _rig.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		if lit == null:
			var src := mi.get_active_material(0) as StandardMaterial3D
			if src:
				# tekstur GLB gelap di arena malam: terangkan + cahaya sendiri + rim agar siluetnya terbaca
				lit = src.duplicate() as StandardMaterial3D
				lit.albedo_color = Color(1.3, 1.2, 1.15)
				lit.emission_enabled = true
				lit.emission_texture = lit.albedo_texture
				lit.emission = Color(1.0, 0.62, 0.5)
				lit.emission_energy_multiplier = 0.22
				lit.rim_enabled = true
				lit.rim = 0.7
				lit.rim_tint = 0.4
		if lit:
			mi.material_override = lit
		mi.material_overlay = _overlay


func _build_wither() -> void:
	var ps: PackedScene = load(WITHER_SCENE)
	_wrig = ps.instantiate() as WitherRig
	_wrig.scale = Vector3.ONE * WITHER_SCALE
	_wrig.position = Vector3(0, WITHER_FOOT * WITHER_SCALE, 0.4)
	_visual.add_child(_wrig)
	_overlay = StandardMaterial3D.new()
	_overlay.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_overlay.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_overlay.albedo_color = Color(1, 1, 1, 0.0)
	# bahan GLB sangat gelap (hampir hitam): terangkan sedikit + rim ungu agar siluet terbaca di arena gelap
	var cache := {}
	for n in _wrig.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		if mi.mesh == null:
			continue
		for i in mi.mesh.get_surface_count():
			var src := mi.get_active_material(i) as StandardMaterial3D
			if src == null:
				continue
			var key := src.get_instance_id()
			if not cache.has(key):
				var m := src.duplicate() as StandardMaterial3D
				var c := m.albedo_color
				if m.albedo_texture == null and (c.r + c.g + c.b) < 0.45:
					m.albedo_color = c.lerp(Color(0.55, 0.46, 0.72), 0.85)
				m.rim_enabled = true
				m.rim = 0.8
				m.rim_tint = 0.3
				m.emission_enabled = true
				m.emission = Color(0.55, 0.3, 0.9)
				m.emission_energy_multiplier = 0.45
				cache[key] = m
			mi.set_surface_override_material(i, cache[key])
		mi.material_overlay = _overlay


func _build_bar() -> void:
	var w := 0.9
	_bar_bg = MeshInstance3D.new()
	var qb := QuadMesh.new()
	qb.size = Vector2(w + 0.08, 0.16)
	_bar_bg.mesh = qb
	_bar_bg.material_override = _bar_mat(Color(0.05, 0.05, 0.12, 0.85))
	_bar_fg = MeshInstance3D.new()
	var qf := QuadMesh.new()
	qf.size = Vector2(w, 0.1)
	_bar_fg.mesh = qf
	_bar_fg.material_override = _bar_mat(Color(0.95, 0.3, 0.35, 1.0))
	var h := 1.5 if kind == "mushroom" else (2.35 if flying else 1.25)
	_bar_bg.position = Vector3(0, h, 0)
	_bar_fg.position = Vector3(0, h, 0)
	add_child(_bar_bg)
	add_child(_bar_fg)
	_bar_bg.visible = false
	_bar_fg.visible = false
	_bar_bg.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_bar_fg.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _bar_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.albedo_color = c
	m.no_depth_test = true
	m.render_priority = 3
	return m


func _update_bar() -> void:
	if _bar_fg == null:
		return
	var ratio := clampf(float(hp) / float(max_hp), 0.0, 1.0)
	var show := (ratio < 1.0 or elite) and not dead
	_bar_bg.visible = show
	_bar_fg.visible = show
	var q: QuadMesh = _bar_fg.mesh
	var w := 0.9
	q.size.x = maxf(w * ratio, 0.001)
	q.center_offset.x = -(w - w * ratio) * 0.5


# ---------------------------------------------------------------- aksi
## Waktu melambat (Aion): musuh bergerak/menyerang/beranimasi dengan kecepatan `factor` selama `dur` detik. Tidak menumpuk (yang terkuat menang).
func apply_slow(factor: float, dur: float) -> void:
	if dead:
		return
	if is_boss:
		factor = maxf(factor, 0.6)                       # bos hanya melambat sedikit
	if _slow_t > 0.0 and factor > _slow:
		factor = _slow
	_slow = clampf(factor, 0.1, 1.0)
	_slow_t = maxf(_slow_t, dur)
	if not puppet:
		ChronoFx.slow_mark(self, dur)


func take_damage(amount: int, from: Vector3, knock: float = 3.0) -> void:
	if dead or state == "spawn":
		return
	if puppet:
		# client: hanya efek visual; hp & kematian ditentukan host
		_flash = 0.18
		if not is_boss:
			_hit_pulse = 1.0
		Sfx.play("hit", randf_range(0.9, 1.15))
		return
	hp = maxi(hp - amount, 0)
	_flash = 0.18
	if not is_boss:
		_hit_pulse = 1.0
	Sfx.play("hit", randf_range(0.9, 1.15))
	_update_bar()
	if hp <= 0:
		_die()
		return
	var away := global_position - from
	away.y = 0.0
	if away.length() > 0.01:
		_knock = away.normalized() * knock * (0.15 if is_boss else 1.0)
	if _wrig and _hit_cd <= 0.0 and state in ["chase", "recover"]:
		_hit_cd = 3.0
		_hit_hold = 0.5
		_wither_key = "hit"
		_wrig.anim_player.speed_scale = 1.0
		_wrig.play_state(&"hit", 0.08)
		_sfx("boss_hurt", randf_range(0.7, 0.8))
	if _rig and _hit_cd <= 0.0 and state in ["chase", "recover"]:
		_hit_cd = 3.5
		_hit_hold = 0.9
		_beast_key = "hit"
		_rig.anim_player.speed_scale = 1.0
		_rig.play_state(&"hit")
		_sfx("boss_hurt", randf_range(0.95, 1.05))
	if is_boss:
		if _phase == 1 and hp <= max_hp / 2:
			_enter_phase2()
	elif amount > 0 and _stagger_immune <= 0.0:
		# Poise: pukulan kecil tidak lagi membatalkan serangan musuh yang sedang aba-aba, hanya pukulan besar (>= 28% HP maks) atau saat berlari.
		var big := float(amount) >= float(max_hp) * POISE_FRAC
		if state == "chase" or (state == "windup" and big and not elite):
			_set_state("stagger", 0.28)
			_clear_telegraph()
			_stagger_immune = 0.9              # tidak bisa di-stunlock terus-menerus


func _enter_phase2() -> void:
	_phase = 2
	speed *= 1.25
	phase_changed.emit(2)
	request_shake.emit(0.5)
	Sfx.play("roar", 0.8)
	Fx.ring(fx_parent, global_position, 8.0, Color(0.4, 0.9, 1.0), 0.6)
	if _rig:
		_rig.anim_player.speed_scale = 1.0
		_rig.play_state(&"roar")
		Sfx.play("boss_roar", 0.9, 2.0)
		_beast_key = "hit"
		_hit_hold = 1.8
	if _wrig:
		_wrig.anim_player.speed_scale = 1.0
		_wrig.play_state(&"roar", 0.1)
		Sfx.play("boss_roar", 0.7, 2.0)
		_wither_key = "hit"
		_hit_hold = 1.6
		Fx.ring(fx_parent, global_position, 10.0, Color(0.75, 0.3, 1.0), 0.8)
	for i in 2:
		var a := randf() * TAU
		request_spawn.emit("bat" if (_rig or _wrig) else "slime", global_position + Vector3(cos(a), 0, sin(a)) * 4.0)


func _die() -> void:
	dead = true
	state = "dead"
	_clear_telegraph()
	collision_layer = 0
	collision_mask = 0
	remove_from_group("enemies")
	if _bar_bg:
		_bar_bg.visible = false
		_bar_fg.visible = false
	Fx.burst(fx_parent, global_position + Vector3(0, 0.8 if not is_boss else 2.0, 0), _death_color(), 18 if is_boss else 10, 5.0, 0.16)
	if _rig or _wrig:
		Sfx.play("boss_death", 0.8 if _wrig else 1.0, 2.0)
	else:
		Sfx.play("die" if not is_boss else "boom", 1.0 if not is_boss else 0.8)
	if is_boss:
		request_shake.emit(0.7)
	if kind == "slime" and not puppet:
		for sgn in [-1.0, 1.0]:                                  # slime pecah jadi dua slime kecil
			request_spawn.emit("slime_mini", global_position + Vector3(sgn * 0.7, 0, randf_range(-0.4, 0.4)))
	died.emit(self)
	var tw := create_tween()
	if _wrig:
		_wrig.anim_player.speed_scale = 1.0
		_wrig.play_state(&"death", 0.1)
		tw.tween_property(_visual, "position:y", 0.0, 0.9).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)   # jatuh ke tanah
		tw.tween_interval(2.2)
		tw.tween_property(_visual, "scale", Vector3(0.05, 0.05, 0.05), 0.8).set_ease(Tween.EASE_IN)
	elif _rig:
		_rig.anim_player.speed_scale = 1.0
		_rig.play_state(&"death", 0.1)
		tw.tween_interval(3.0)
		tw.tween_property(_visual, "position:y", -2.5, 0.8)
	elif kind == "bat":
		# jatuh berputar
		tw.set_parallel(true)
		tw.tween_property(_visual, "rotation:z", 7.0, 0.4)
		tw.tween_property(_visual, "position:y", -_base_y + 0.1, 0.4).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
		tw.tween_property(_visual, "scale", Vector3(0.6, 0.15, 0.6), 0.4).set_delay(0.15)
		tw.chain().tween_callback(queue_free)
		return
	elif kind == "mushroom":
		# menggembung lalu pecah
		tw.tween_property(_visual, "scale", Vector3(1.35, 0.75, 1.35), 0.12)
		tw.tween_property(_visual, "scale", Vector3(0.05, 0.05, 0.05), 0.14).set_ease(Tween.EASE_IN)
	elif kind == "slime" or kind == "slime_mini":
		# gepeng melebar lalu menguap
		tw.tween_property(_visual, "scale", Vector3(1.5, 0.35, 1.5), 0.12)
		tw.tween_property(_visual, "scale", Vector3(1.7, 0.03, 1.7), 0.2)
	else:
		tw.tween_property(_visual, "scale", Vector3(1.2, 0.05, 1.2), 0.5 if is_boss else 0.3)
	tw.tween_callback(queue_free)


func _death_color() -> Color:
	match kind:
		"slime": return Color(0.4, 0.9, 0.6)
		"bat": return Color(0.7, 0.5, 0.95)
		"mushroom": return Color(0.95, 0.4, 0.5)
		"cave_beast": return Color(1.0, 0.55, 0.3)
		"wither_god": return Color(0.75, 0.35, 1.0)
	return Color(0.4, 0.9, 1.0)


func _set_state(s: String, t: float = 0.0) -> void:
	state = s
	_t = t
	_did_hit = false


func _clear_telegraph() -> void:
	if _telegraph != null and is_instance_valid(_telegraph):
		_telegraph.queue_free()
	_telegraph = null
	for t in _extra_tele:
		if is_instance_valid(t):
			t.queue_free()
	_extra_tele.clear()


func _flat_to_target() -> Vector3:
	var d := target.global_position - global_position
	d.y = 0.0
	return d


func _deal(mult: float = 1.0, victim: Node = null) -> void:
	var v: Node = victim if victim != null else target
	if v != null and is_instance_valid(v) and v.is_in_group("ghost"):
		hit_ghost.emit(v, int(atk * mult), global_position)
		return
	hit_player.emit(int(atk * mult), global_position)


## Co-op client: terapkan data snapshot host (posisi, hadap, hp, state).
func puppet_apply(p: Vector3, yaw: float, p_hp: int, st: String, atk_name: String) -> void:
	if dead:
		return
	_net_pos = p
	_net_yaw = yaw
	if not _net_has:
		_net_has = true
		global_position = p
		rotation.y = yaw
	if p_hp != hp:
		hp = p_hp
		_update_bar()
	_attack = atk_name
	if st != state and st != "dead":
		_set_state(st, float(info.get("windup", 0.5)) if st == "windup" else 0.4)
		_puppet_on_state(st)


func _puppet_on_state(_st: String) -> void:
	pass


func _puppet_step(delta: float) -> void:
	if _net_has:
		var k := 1.0 - exp(-14.0 * delta)
		global_position = global_position.lerp(_net_pos, k)
		rotation.y = lerp_angle(rotation.y, _net_yaw, k)
	if state == "spawn":
		_set_state("chase")
	_animate(delta)


# ---------------------------------------------------------------- loop
func _physics_process(delta: float) -> void:
	if dead:
		return
	_anim_t += delta
	if _flash > 0.0:
		_flash -= delta
	_mat.set_shader_parameter("flash_amount", clampf(_flash / 0.18, 0.0, 1.0) * 0.8 + (0.35 + 0.35 * sin(_anim_t * 26.0) if state == "windup" else 0.0))
	_mat.set_shader_parameter("flash_color", Color(1, 0.3, 0.25) if state == "windup" else Color(1, 1, 1))
	if elite and state != "windup" and _flash <= 0.0 and _slow_t <= 0.0:
		_mat.set_shader_parameter("flash_color", Color(1.0, 0.8, 0.3))
		_mat.set_shader_parameter("flash_amount", 0.14 + 0.08 * sin(_anim_t * 3.0))
	if _slow_t > 0.0 and state != "windup" and _flash <= 0.0:       # efek waktu melambat: semburat biru berdenyut pelan
		_mat.set_shader_parameter("flash_color", Color(0.45, 0.65, 1.0))
		_mat.set_shader_parameter("flash_amount", 0.3 + 0.1 * sin(_anim_t * 4.0))
	if _overlay:
		var fa: float = clampf(_flash / 0.18, 0.0, 1.0) * 0.55 + (0.1 + 0.1 * sin(_anim_t * 26.0) if state == "windup" else 0.0)
		_overlay.albedo_color = Color(1, 0.15, 0.1, fa) if state == "windup" else Color(1, 1, 1, fa)
	_hit_hold = maxf(_hit_hold - delta, 0.0)
	_hit_pulse = maxf(_hit_pulse - delta * 4.5, 0.0)
	_hit_cd = maxf(_hit_cd - delta, 0.0)
	if puppet:
		_puppet_step(delta)
		return
	if target == null or not is_instance_valid(target):
		return
	if _slow_t > 0.0:
		_slow_t -= delta
		if _slow_t <= 0.0:
			_slow = 1.0
		delta *= _slow
	_t -= delta
	_cooldown -= delta
	_stagger_immune = maxf(_stagger_immune - delta, 0.0)
	match state:
		"spawn": _st_spawn(delta)
		"chase": _st_chase(delta)
		"windup": _st_windup(delta)
		"strike": _st_strike(delta)
		"recover": _st_recover(delta)
		"stagger": _st_stagger(delta)
	if is_boss and kind != "wither_god":
		_footsteps(delta)
	_separate(delta)
	_apply_move(delta)
	_animate(delta)
	if _wave_active:
		_update_wave(delta)


func _st_spawn(_delta: float) -> void:
	var f := clampf(1.0 - _t / 0.7, 0.0, 1.0)
	# muncul dengan "pop": membesar melewati ukuran asli lalu mengendap (easeOutBack)
	var c1 := 1.9
	var back := 1.0 + (c1 + 1.0) * pow(f - 1.0, 3.0) + c1 * pow(f - 1.0, 2.0)
	_visual.scale = Vector3.ONE * maxf(back, 0.05)
	_visual.position.y = (1.0 - f) * -0.25 if not flying else 0.0
	if _t <= 0.0:
		_visual.scale = Vector3.ONE
		_visual.position.y = 0.0
		_set_state("chase")


func _st_stagger(_delta: float) -> void:
	if _t <= 0.0:
		_set_state("chase")


func _st_recover(_delta: float) -> void:
	if _t <= 0.0:
		_cooldown = 0.2
		_set_state("chase")


func _move_dir(dir: Vector3, spd: float) -> void:
	velocity.x = dir.x * spd
	velocity.z = dir.z * spd


func _face(dir: Vector3, delta: float, rate: float = 8.0) -> void:
	if dir.length() < 0.01:
		return
	rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), 1.0 - exp(-rate * delta))


func _st_chase(delta: float) -> void:
	var to := _flat_to_target()
	var dist := to.length()
	var dir := to.normalized() if dist > 0.01 else Vector3.ZERO
	match kind:
		"slime", "slime_mini":
			_hop_t += delta
			var hop := maxf(sin(_hop_t * 6.0), 0.0)
			_move_dir(dir, speed * (0.25 + 1.1 * hop))
			_face(dir, delta)
			if dist < float(info["range"]) + radius + 0.4 and _cooldown <= 0.0:
				_begin_attack("")
		"bat":
			# mengitari pemain lalu menukik
			var ang := atan2(-to.z, -to.x) + _orbit_dir * 0.8 * delta
			var want := target.global_position + Vector3(cos(ang), 0, sin(ang)) * 4.2
			var mv := want - global_position
			mv.y = 0.0
			_move_dir(mv.normalized(), speed * clampf(mv.length(), 0.3, 1.0))
			_face(dir, delta, 10.0)
			_dive_cd -= delta
			if _dive_cd <= 0.0 and dist < 7.0:
				_begin_attack("")
		"mushroom":
			_move_dir(dir, speed)
			_face(dir, delta)
			if dist < float(info["range"]) + radius + 0.3 and _cooldown <= 0.0:
				_begin_attack("")
		"cave_beast":
			_move_dir(dir, speed)
			_face(dir, delta, 5.0)
			if _cooldown <= 0.0:
				_begin_attack(_pick_beast_attack(dist))
		"wither_god":
			# melayang menjaga jarak: mendekat bila jauh, mundur bila terlalu dekat
			_face(dir, delta, 4.0)
			if dist > 6.2:
				_move_dir(dir, speed)
			elif dist < 3.6:
				_move_dir(-dir, speed * 0.8)
			else:
				_move_dir(Vector3.ZERO, 0.0)
			if _cooldown <= 0.0:
				_begin_attack(_pick_wither_attack(dist))
		"golem":
			_move_dir(dir, speed)
			_face(dir, delta, 5.0)
			if _cooldown <= 0.0:
				var wait := 0.0 if _phase == 1 else 0.0
				if dist < 8.5:
					_begin_attack(_pick_attack(dist))
				elif dist > 8.5 and _cooldown <= -1.0 + wait:
					_begin_attack("rocks")


func _pick_beast_attack(dist: float) -> String:
	var opts: Array = ["claw", "claw", "wave"] if dist < 5.0 else ["charge", "charge", "wave"]
	opts = opts.filter(func(a): return a != _last_attack or opts.size() == 1)
	return opts[randi() % opts.size()]


func _pick_wither_attack(dist: float) -> String:
	var opts: Array = ["nova", "nova", "volley"] if dist < 5.5 else ["volley", "rain", "volley", "nova"]
	if _phase == 2:
		opts.append("rain")
	opts = opts.filter(func(a): return a != _last_attack or opts.size() == 1)
	return opts[randi() % opts.size()]


func _pick_attack(dist: float) -> String:
	var opts: Array = ["slam", "wave", "rocks"] if dist > 4.0 else ["slam", "slam", "wave"]
	opts = opts.filter(func(a): return a != _last_attack or opts.size() == 1)
	return opts[randi() % opts.size()]


func _begin_attack(which: String) -> void:
	_attack = which
	_last_attack = which
	_move_dir(Vector3.ZERO, 0.0)
	var wu := float(info["windup"])
	if kind == "golem":
		wu = {"slam": 1.0, "wave": 1.3, "rocks": 0.9}.get(which, 1.0)
		if _phase == 2:
			wu *= 0.8
	_set_state("windup", wu)
	_strike_dir = _flat_to_target().normalized()
	if kind == "cave_beast":
		wu = {"claw": 0.9, "charge": 1.1, "wave": 1.4}.get(which, 1.0)
		if _phase == 2:
			wu *= 0.8
		_set_state("windup", wu)
		_wu_total = wu
	if kind == "wither_god":
		wu = {"volley": 1.0, "nova": 1.5, "rain": 1.6}.get(which, 1.0)
		if _phase == 2:
			wu *= 0.8
		_set_state("windup", wu)
		_wu_total = wu
	var fwd := Vector3(sin(rotation.y), 0, cos(rotation.y))
	match kind:
		"wither_god":
			var pc := Color(0.75, 0.3, 1.0)
			match which:
				"volley":
					_telegraph = Fx.telegraph(fx_parent, global_position + _strike_dir * 5.5, 2.4, wu, pc)
					_sfx("boss_growl", 0.7, 0.0)
				"nova":
					_telegraph = Fx.telegraph(fx_parent, global_position, 10.0, wu, pc)
					_sfx("boss_roar", 0.75, 1.0)
				"rain":
					_rain_pos.clear()
					var n := 6 if _phase == 2 else 4
					var tp := target.global_position
					for i in n:
						var off := Vector3.ZERO if i == 0 else Vector3(randf_range(-5.5, 5.5), 0, randf_range(-5.5, 5.5))
						var pos := Vector3(tp.x, 0.0, tp.z) + off
						_rain_pos.append(pos)
						_extra_tele.append(Fx.telegraph(fx_parent, pos, 2.2, wu, pc))
					_sfx("boss_growl", 0.6, 1.0)
		"cave_beast":
			match which:
				"claw":
					_telegraph = Fx.telegraph(fx_parent, global_position + fwd * 2.8, 3.2, wu)
				"charge":
					_telegraph = Fx.telegraph(fx_parent, global_position + _strike_dir * 9.0, 2.6, wu, Color(1.0, 0.8, 0.2))
				"wave":
					_telegraph = Fx.telegraph(fx_parent, global_position, 9.5, wu, Color(1.0, 0.5, 0.2))
			match which:
				"claw": _sfx("boss_growl", 1.15)
				"charge": _sfx("boss_growl", 0.8, 1.0)
				"wave": _sfx("boss_roar", 1.0)
		"mushroom":
			_telegraph = Fx.telegraph(fx_parent, global_position, 2.7, wu)
		"golem":
			match which:
				"slam":
					_telegraph = Fx.telegraph(fx_parent, global_position + fwd * 3.0, 3.4, wu)
				"wave":
					_telegraph = Fx.telegraph(fx_parent, global_position, 9.5, wu, Color(1.0, 0.5, 0.2))
	if kind == "golem":
		Sfx.play("roar", 1.1, -6.0)


func _st_windup(delta: float) -> void:
	_move_dir(Vector3.ZERO, 0.0)
	if kind != "bat":
		_face(_flat_to_target(), delta, 4.0 if (kind == "golem" or kind == "cave_beast" or kind == "wither_god") else 6.0)
	_strike_dir = _flat_to_target().normalized()
	if _t > 0.0:
		return
	_clear_telegraph()
	match kind:
		"slime":
			_set_state("strike", 0.28)
		"bat":
			_set_state("strike", 0.55)
		"mushroom":
			_set_state("strike", 0.2)
			Fx.ring(fx_parent, global_position, 2.7, Color(0.8, 0.4, 0.9), 0.4)
			Fx.burst(fx_parent, global_position + Vector3(0, 0.8, 0), Color(0.75, 0.4, 0.9), 14, 4.0, 0.14)
			Sfx.play("boom", 1.6, -8.0)
			if _flat_to_target().length() < 2.7 + 0.3:
				_deal()
			_did_hit = true
		"golem":
			_strike_golem()
		"cave_beast":
			_strike_beast()
		"wither_god":
			_strike_wither()


func _strike_wither() -> void:
	var pc := Color(0.75, 0.3, 1.0)
	match _attack:
		"volley":
			_set_state("strike", 0.5)
			var n := 5 if _phase == 2 else 3
			for i in n:
				var ang := (i - (n - 1) * 0.5) * 0.26
				var dir := _strike_dir.rotated(Vector3.UP, ang)
				var p := Projectile.make("bolt", pc)
				p.target_group = "player"
				fx_parent.add_child(p)
				p.launch(global_position + Vector3(0, 3.2, 0) + dir * 1.6, dir, 11.5, 26.0)
				p.on_hit = func(t2): _deal(0.85, t2)
			Fx.burst(fx_parent, global_position + Vector3(0, 3.2, 0) + _strike_dir * 1.6, pc.lightened(0.3), 12, 5.0, 0.14)
			_sfx("boss_swipe", 0.7, 2.0)
			Sfx.play("shoot", 0.55, -2.0)
			request_shake.emit(0.2)
		"nova":
			_set_state("strike", 0.9)
			_wave_active = true
			_wave_r = 1.0
			_wave_hit = false
			_wave_center = global_position
			Fx.ring(fx_parent, global_position, 10.0, pc, 0.9)
			Fx.ring(fx_parent, global_position, 6.5, Color(1, 1, 1), 0.6)
			Fx.burst(fx_parent, global_position + Vector3(0, 1.5, 0), pc.lightened(0.4), 24, 7.0, 0.18)
			_sfx("boss_wave", 0.9, 3.0)
			request_shake.emit(0.45)
		"rain":
			_set_state("strike", 0.6)
			var hit := false
			for pos: Vector3 in _rain_pos:
				Fx.ring(fx_parent, pos, 2.2, pc, 0.45)
				Fx.burst(fx_parent, pos + Vector3(0, 0.5, 0), pc.lightened(0.4), 14, 6.0, 0.16)
				var tp := target.global_position
				if not hit and Vector2(tp.x - pos.x, tp.z - pos.z).length() < 2.2 + 0.4:
					hit = true
					_deal(1.25)
			_did_hit = true
			_rain_pos.clear()
			_sfx("boss_claw_hit", 0.8, 1.0)
			_sfx("boss_crash", 1.0, -2.0)
			request_shake.emit(0.4)


func _strike_beast() -> void:
	var fwd := Vector3(sin(rotation.y), 0, cos(rotation.y))
	match _attack:
		"claw":
			_set_state("strike", 0.5)
			var c := global_position + fwd * 2.8
			Fx.ring(fx_parent, c, 3.2, Color(1.0, 0.6, 0.3), 0.35)
			Fx.burst(fx_parent, c + Vector3(0, 0.4, 0), Color(0.9, 0.75, 0.6), 14, 6.0, 0.16)
			_sfx("boss_swipe", 1.0, 2.0)
			_sfx("boss_claw_hit", 1.0)
			request_shake.emit(0.4)
			if Vector2(target.global_position.x - c.x, target.global_position.z - c.z).length() < 3.2 + 0.4:
				_deal(1.3)
			_did_hit = true
		"charge":
			_set_state("strike", 0.75)
			_strike_dir = _flat_to_target().normalized()
			_sfx("boss_charge", 1.0, 2.0)
		"wave":
			_set_state("strike", 0.9)
			_wave_active = true
			_wave_r = 1.0
			_wave_hit = false
			_wave_center = global_position
			_sfx("boss_wave", 1.0, 3.0)
			request_shake.emit(0.4)


func _strike_golem() -> void:
	var fwd := Vector3(sin(rotation.y), 0, cos(rotation.y))
	match _attack:
		"slam":
			_set_state("strike", 0.35)
			var c := global_position + fwd * 3.0
			Fx.ring(fx_parent, c, 3.4, Color(1.0, 0.7, 0.3), 0.4)
			Fx.burst(fx_parent, c + Vector3(0, 0.3, 0), Color(0.8, 0.8, 0.9), 16, 6.0, 0.18)
			Sfx.play("boom", 0.7)
			request_shake.emit(0.45)
			var d := Vector2(target.global_position.x - c.x, target.global_position.z - c.z).length()
			if d < 3.4 + 0.4:
				_deal(1.4)
			_did_hit = true
		"wave":
			_set_state("strike", 0.9)
			_wave_active = true
			_wave_r = 1.0
			_wave_hit = false
			_wave_center = global_position
			Sfx.play("boom", 0.6)
			request_shake.emit(0.35)
		"rocks":
			_set_state("strike", 0.4)
			for i in 3:
				var ang := (i - 1) * 0.22
				var dir := _strike_dir.rotated(Vector3.UP, ang)
				var p := Projectile.make("rock", Color(0.5, 0.55, 0.68))
				p.target_group = "player"
				fx_parent.add_child(p)
				p.launch(global_position + Vector3(0, 3.0, 0) + dir * 1.2, dir, 9.5, 20.0)
				p.on_hit = func(t2): _deal(0.9, t2)
			Sfx.play("shoot", 0.6)


func _update_wave(delta: float) -> void:
	_wave_r += delta * 10.5
	if _wave_r > 10.0:
		_wave_active = false
		return
	if _wave_hit:
		return
	var tp := target.global_position
	var d := Vector2(tp.x - _wave_center.x, tp.z - _wave_center.z).length()
	if absf(d - _wave_r) < 0.75 and tp.y < 0.7:
		_wave_hit = true
		_deal(1.1)


func _st_strike(delta: float) -> void:
	match kind:
		"slime", "slime_mini":
			_move_dir(_strike_dir, 9.0)
			if not _did_hit and _flat_to_target().length() < radius + 0.95:
				_did_hit = true
				_deal()
		"bat":
			var f := 1.0 - _t / 0.55
			position.y = lerpf(_base_y, 1.0, sin(clampf(f, 0.0, 1.0) * PI))
			_move_dir(_strike_dir, 9.5)
			if not _did_hit and _flat_to_target().length() < radius + 0.8:
				_did_hit = true
				_deal()
		"mushroom":
			_move_dir(Vector3.ZERO, 0.0)
		"golem":
			_move_dir(Vector3.ZERO, 0.0)
		"cave_beast":
			if _attack == "charge":
				_move_dir(_strike_dir, 15.0)
				if not _did_hit and _flat_to_target().length() < radius + 1.1:
					_did_hit = true
					_deal(1.5)
					request_shake.emit(0.5)
					_sfx("boss_crash", 1.0, 1.0)
			else:
				_move_dir(Vector3.ZERO, 0.0)
	if _t <= 0.0:
		_wave_active = _wave_active and _attack == "wave"
		_dive_cd = randf_range(1.3, 2.3)
		var rec := float(info["recover"])
		if not is_boss:
			rec *= 0.75                                  # musuh biasa pulih lebih cepat -> lebih agresif
		if kind == "golem" or kind == "cave_beast" or kind == "wither_god":
			rec = 1.3 if _phase == 1 else 0.7
			if _attack == "charge":
				rec += 0.5                  # terengah setelah menyeruduk: celah untuk membalas
				_sfx("boss_crash", 0.85, -4.0)
				request_shake.emit(0.3)
			_cooldown = 0.3
		_set_state("recover", rec)


func _separate(_delta: float) -> void:
	if is_boss:
		return
	# PERF: jarak kuadrat, satu sqrt hanya untuk pasangan yang benar-benar tumpang tindih (dulu 3x length() + normalized() per pasangan).
	# Hasilnya identik dengan versi lama.
	var my := global_position
	var r := radius
	for o: Node in get_tree().get_nodes_in_group("enemies"):
		if o == self:
			continue
		var e := o as Enemy
		if e == null:
			continue
		var op := e.global_position
		var dx := my.x - op.x
		var dz := my.z - op.z
		var min_d := r + e.radius
		var d2 := dx * dx + dz * dz
		if d2 < min_d * min_d and d2 > 0.000001:
			var dist := sqrt(d2)
			velocity += Vector3(dx, 0.0, dz) / dist * ((min_d - dist) * 6.0)


func _apply_move(delta: float) -> void:
	var vel := velocity
	if flying:
		vel.y = 0.0
		var ty := _base_y + sin(_anim_t * 3.0) * 0.15
		if state != "strike":
			position.y = lerpf(position.y, ty, 1.0 - exp(-4.0 * delta))
	else:
		if not is_on_floor():
			vel.y -= 22.0 * delta
		else:
			vel.y = -0.5
	vel.x *= _slow
	vel.z *= _slow
	vel.x += _knock.x * 6.0
	vel.z += _knock.z * 6.0
	_knock = _knock * exp(-9.0 * delta)
	velocity = vel
	if state in ["recover", "stagger", "windup"] and absf(_knock.x) + absf(_knock.z) < 0.05:
		velocity.x = 0.0
		velocity.z = 0.0
	move_and_slide()
	if state != "spawn":
		velocity.x = 0.0
		velocity.z = 0.0


# ---------------------------------------------------------------- animasi (kode)
func _animate(delta: float) -> void:
	if state == "spawn":
		return
	var s := _anim_t
	match kind:
		"slime":
			_animate_slime(delta)
		"bat":
			_animate_bat(delta)
		"mushroom":
			_animate_mushroom(delta)
		"cave_beast":
			_animate_beast()
		"wither_god":
			_animate_wither(delta)
		"golem":
			var raise := 0.0
			match state:
				"windup":
					var f := clampf(1.0 - _t / maxf(float(info["windup"]), 0.1), 0.0, 1.0)
					raise = -2.6 * f if _attack != "wave" else -1.2 * f
				"strike":
					raise = 0.5 if _attack == "slam" else -0.6
				"chase":
					raise = sin(s * 4.0) * 0.4
			_arm_l.rotation.x = lerpf(_arm_l.rotation.x, raise, 1.0 - exp(-12.0 * delta))
			_arm_r.rotation.x = lerpf(_arm_r.rotation.x, -raise if state == "chase" else raise, 1.0 - exp(-12.0 * delta))
			_visual.position.y = absf(sin(s * 4.0)) * 0.06 if state == "chase" else 0.0


## Dewa Wither: klip dipilih menurut serangan (volley = hentak, nova = raung, rain = angkat tangan), melayang naik-turun, makin tinggi saat mengumpulkan tenaga.
func _animate_wither(delta: float) -> void:
	var ap := _wrig.anim_player
	if _hit_hold > 0.0:
		pass
	else:
		var key := state
		if state == "windup" or state == "strike":
			key = "a_" + _attack
		if key != _wither_key:
			_wither_key = key
			var clip := &"idle"
			var spd := 1.0
			var blend := 0.2
			match key:
				"chase", "recover", "stagger":
					clip = &"idle"
				"a_volley":
					clip = &"slam"
					spd = WitherRig.PEAK["slam"] / maxf(_wu_total, 0.1)
					blend = 0.12
				"a_nova":
					clip = &"roar"
					spd = WitherRig.PEAK["roar"] / maxf(_wu_total, 0.1)
					blend = 0.15
				"a_rain":
					clip = &"cast"
					spd = WitherRig.PEAK["cast"] / maxf(_wu_total, 0.1)
					blend = 0.15
			ap.speed_scale = spd
			_wrig.play_state(clip, blend)
	# melayang: naik-turun lembut, naik saat windup, condong ke depan saat menembak
	var lift := 0.0
	var lean := 0.0
	match state:
		"windup":
			lift = 0.7 * clampf(1.0 - _t / maxf(_wu_total, 0.1), 0.0, 1.0)
		"strike":
			lift = 0.5 if _attack != "volley" else 0.2
			lean = 0.12 if _attack == "volley" else 0.0
		"recover":
			lift = -0.1
	_hover = lerpf(_hover, lift, 1.0 - exp(-6.0 * delta))
	_visual.position.y = WITHER_HOVER + sin(_anim_t * 1.8) * 0.18 + _hover
	_visual.rotation.x = lerp_angle(_visual.rotation.x, lean, 1.0 - exp(-8.0 * delta))


## Waktu (detik, pada animasi asli) saat puncak gerakan: cakar menghantam ~0.6 s, raungan mencapai pose penuh ~1.0 s.
## Kecepatan putar dipilih agar momen itu jatuh tepat di akhir fase aba-aba (windup) = saat serangan benar-benar mengenai.
const ANIM_CLAW_IMPACT := 0.6
const ANIM_ROAR_PEAK := 1.0
const ANIM_REAR_HOLD := 0.42       # pose angkat tangan sebelum menyeruduk (animasi Attack ditahan di sini)
var _wu_total := 1.0


func _animate_beast() -> void:
	var ap := _rig.anim_player
	if _beast_key == "charge_w" and ap.current_animation_position >= ANIM_REAR_HOLD:
		ap.speed_scale = 0.0                   # tahan pose bersiap menyeruduk sampai serangan dimulai
	if _hit_hold > 0.0:
		return
	# kunci animasi: aba-aba dan serangan cakar/gelombang memakai SATU klip tanpa memulai ulang
	var key := state
	match state:
		"windup", "strike":
			match _attack:
				"claw": key = "claw"
				"wave": key = "wave"
				"charge": key = "charge_w" if state == "windup" else "charge_s"
	if key == _beast_key:
		return
	_beast_key = key
	var a := &"idle"
	var spd := 1.0
	var blend := 0.2
	match key:
		"chase":
			a = &"walk"
			spd = 1.6
		"claw":
			a = &"attack"
			spd = ANIM_CLAW_IMPACT / maxf(_wu_total, 0.1)
			blend = 0.1
		"charge_w":
			a = &"attack"
			spd = ANIM_REAR_HOLD / maxf(_wu_total * 0.6, 0.1)
			blend = 0.1
		"charge_s":
			a = &"walk"
			spd = 2.6
			blend = 0.08
		"wave":
			a = &"roar"
			spd = ANIM_ROAR_PEAK / maxf(_wu_total, 0.1)
			blend = 0.15
	ap.speed_scale = spd
	_rig.play_state(a, blend)


# ---------------------------------------------------------------- animasi kroco (kode)
## Menerapkan pose dengan penghalusan eksponensial agar perpindahan antar state tidak "loncat".
func _pose(sc: Vector3, y: float, rot: Vector3, delta: float, rate: float = 18.0) -> void:
	var k := 1.0 - exp(-rate * delta)
	_visual.scale = _visual.scale.lerp(sc, k)
	_visual.position.y = lerpf(_visual.position.y, y, k)
	_visual.rotation = Vector3(lerp_angle(_visual.rotation.x, rot.x, k), lerp_angle(_visual.rotation.y, rot.y, k), lerp_angle(_visual.rotation.z, rot.z, k))


func _squash_scale(sq: float) -> Vector3:
	# sq > 0 = memanjang (tinggi), sq < 0 = gepeng; volume dijaga kira-kira tetap
	var xz := 1.0 - sq * 0.5
	return Vector3(xz, 1.0 + sq, xz)


func _animate_slime(delta: float) -> void:
	var s := _anim_t
	var sq := 0.0
	var y := 0.0
	var sc: Vector3
	var rot := Vector3.ZERO
	var wu := float(info["windup"])
	match state:
		"chase":
			var ph := _hop_t * 6.0
			var hop := maxf(sin(ph), 0.0)
			y = hop * 0.3
			if hop > 0.001:
				sq = 0.2 * absf(cos(ph))                       # memanjang saat naik/turun
			else:
				sq = -0.22                                      # menekuk saat bersiap/mendarat
			sc = _squash_scale(sq)
		"windup":
			var f := clampf(1.0 - _t / wu, 0.0, 1.0)
			sq = -0.42 * f                                      # menekuk ke bawah sebelum menerkam
			sc = _squash_scale(sq)
			sc.x += 0.08 * sin(s * 40.0) * f                    # bergetar menahan tenaga
			rot.x = -0.2 * f
		"strike":
			var f2 := clampf(1.0 - _t / 0.28, 0.0, 1.0)
			sc = Vector3(0.82, 0.8, 1.0 + 0.45 * (1.0 - f2))   # memanjang searah terkaman
			y = 0.22 * sin(f2 * PI)
			rot.x = 0.25 * (1.0 - f2)
		"recover":
			var f3 := clampf(_t / float(info["recover"]), 0.0, 1.0)
			sq = 0.18 * sin((1.0 - f3) * 18.0) * f3             # bergoyang lalu tenang
			sc = _squash_scale(sq)
		"stagger":
			sc = Vector3(1.25, 0.7, 1.25)
			rot.x = -0.35
		_:
			sc = Vector3.ONE
	sc = sc * Vector3(1.0 + 0.2 * _hit_pulse, 1.0 - 0.3 * _hit_pulse, 1.0 + 0.2 * _hit_pulse)
	rot.x += -0.3 * _hit_pulse
	_pose(sc, y, rot, delta, 22.0)


func _animate_bat(delta: float) -> void:
	var s := _anim_t
	var freq := 22.0
	var amp := 0.9
	var lift := 0.0                 # + = sayap terangkat ke atas dari posisi netral
	var pitch := 0.0
	var roll := 0.0
	match state:
		"chase":
			freq = 18.0
			amp = 0.95
			roll = _orbit_dir * 0.3                              # miring saat mengitari pemain
			pitch = -0.1
		"windup":
			freq = 7.0
			amp = 0.35
			lift = 1.0                                           # sayap diangkat tinggi sebelum menukik
			pitch = 0.3
		"strike":
			freq = 3.0
			amp = 0.1
			lift = -0.75                                         # sayap dirapatkan ke belakang
			pitch = -0.7
		"stagger":
			freq = 34.0
			amp = 1.1
			roll = sin(s * 30.0) * 0.5
			pitch = 0.5
		"recover":
			freq = 12.0
			amp = 0.8
			pitch = 0.1
	_wing_fold = lerpf(_wing_fold, lift, 1.0 - exp(-14.0 * delta))
	var flap := sin(s * freq) * amp
	# sayap kiri: rotasi positif = turun, sayap kanan kebalikannya
	_wing_l.rotation.z = flap - _wing_fold
	_wing_r.rotation.z = -(flap - _wing_fold)
	_wing_l.rotation.y = lerpf(_wing_l.rotation.y, -0.5 if state == "strike" else 0.0, 1.0 - exp(-14.0 * delta))
	_wing_r.rotation.y = -_wing_l.rotation.y
	var by := sin(s * freq) * 0.05                               # badan naik-turun mengikuti kepakan
	var sc := Vector3.ONE * (1.0 + 0.12 * _hit_pulse)
	_pose(sc, by, Vector3(pitch - 0.3 * _hit_pulse, 0.0, roll), delta, 12.0)


func _animate_mushroom(delta: float) -> void:
	var s := _anim_t
	var wu := float(info["windup"])
	var cap_s := 1.0
	var cap_y := 0.7
	var y := 0.0
	var sc := Vector3.ONE
	var rot := Vector3.ZERO
	match state:
		"chase":
			var w := s * 7.0
			rot.z = sin(w) * 0.14                                # berjalan menggoyang badan
			y = absf(sin(w)) * 0.09
			sc = _squash_scale(0.05 * cos(w * 2.0))
			cap_y = 0.7 + 0.04 * sin(w * 2.0 + 1.2)              # tudung memantul sedikit terlambat
			cap_s = 1.0 + 0.04 * sin(w * 2.0 + 1.2)
		"windup":
			var f := clampf(1.0 - _t / wu, 0.0, 1.0)
			cap_s = 1.0 + 0.4 * f * f                            # menggembung
			sc = _squash_scale(-0.12 * f)
			rot.z = sin(s * 45.0) * 0.07 * f                     # bergetar
			rot.x = -0.1 * f
		"strike":
			var f2 := clampf(1.0 - _t / 0.2, 0.0, 1.0)
			cap_s = lerpf(0.7, 1.0, f2)                          # kempis cepat setelah menyemprotkan spora
			sc = _squash_scale(lerpf(0.18, 0.0, f2))
			cap_y = 0.7 - 0.12 * (1.0 - f2)
		"recover":
			var f3 := clampf(_t / float(info["recover"]), 0.0, 1.0)
			cap_s = 1.0 - 0.1 * f3                               # menggembung perlahan kembali
			rot.z = sin(s * 6.0) * 0.05 * f3
		"stagger":
			rot.x = -0.35
			cap_s = 0.9
			sc = _squash_scale(-0.12)
	sc = sc * Vector3(1.0 + 0.15 * _hit_pulse, 1.0 - 0.25 * _hit_pulse, 1.0 + 0.15 * _hit_pulse)
	rot.x += -0.25 * _hit_pulse
	_pose(sc, y, rot, delta, 18.0)
	var k := 1.0 - exp(-16.0 * delta)
	_cap.scale = _cap.scale.lerp(Vector3(cap_s, cap_s * (1.0 - 0.1 * (cap_s - 1.0)), cap_s), k)
	_cap.position.y = lerpf(_cap.position.y, cap_y, k)
