class_name StageResult
extends Control
## Layar hasil stage: KEMENANGAN / KALAH, bintang, statistik, hadiah, dan tombol Kembali ke Lobi / Ulangi.

signal lobby_pressed
signal retry_pressed


func show_result(res: Dictionary, sd: StageData, extra: Dictionary) -> void:
	theme = UiTheme.get_theme()
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var win: bool = res["win"]
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.1, 0.7)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var p := PanelContainer.new()
	p.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	p.grow_horizontal = Control.GROW_DIRECTION_BOTH
	p.grow_vertical = Control.GROW_DIRECTION_BOTH
	p.custom_minimum_size = Vector2(620, 0)
	add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	p.add_child(v)
	v.add_child(UiTheme.label("KEMENANGAN" if win else "KALAH", 52, UiTheme.GOLD if win else UiTheme.BAD, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(UiTheme.label(sd.display_name, 24, UiTheme.SKY, HORIZONTAL_ALIGNMENT_CENTER))
	if win:
		var st := "★".repeat(int(res["stars"])) + "☆".repeat(3 - int(res["stars"]))
		v.add_child(UiTheme.label(st, 56, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER))
		var why := PackedStringArray(["Stage selesai"])
		if extra.get("no_faint", false):
			why.append("tidak ada yang pingsan")
		if extra.get("hp_ok", false):
			why.append("sisa HP party ≥ 50%")
		v.add_child(UiTheme.label(" · ".join(why), 16, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER))
	else:
		v.add_child(UiTheme.label("Seluruh party pingsan. Hadiah hiburan tetap diberikan.", 18, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(HSeparator.new())
	var t: int = int(res["time"])
	v.add_child(UiTheme.label("Waktu %d:%02d   ·   Monster dikalahkan %d" % [t / 60, t % 60, int(res["kills"])], 22, UiTheme.TEXT, HORIZONTAL_ALIGNMENT_CENTER))
	var parts := PackedStringArray()
	parts.append("+%d gold" % int(res["gold"]))
	parts.append("+%d EXP" % int(res["exp"]))
	if int(res["diamond"]) > 0:
		parts.append("+%d diamond" % int(res["diamond"]))
	v.add_child(UiTheme.label("Hadiah: " + ",  ".join(parts), 24, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	if res["first_clear"]:
		v.add_child(UiTheme.label("Bonus clear pertama sudah termasuk!", 18, UiTheme.GOOD, HORIZONTAL_ALIGNMENT_CENTER))
	if int(res["levels"]) > 0:
		v.add_child(UiTheme.label("NAIK LEVEL!  Sekarang Lv %d" % GameState.level, 26, UiTheme.GOOD, HORIZONTAL_ALIGNMENT_CENTER))
	var qn := GameState.ready_quest_count()
	if qn > 0:
		v.add_child(UiTheme.label("%d quest siap diklaim di lobi." % qn, 18, UiTheme.SKY, HORIZONTAL_ALIGNMENT_CENTER))
	var br := HBoxContainer.new()
	br.add_theme_constant_override("separation", 12)
	v.add_child(br)
	var b1 := UiTheme.button("Ulangi" if win else "Coba lagi", Vector2(0, 64))
	b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b1.pressed.connect(func(): retry_pressed.emit())
	br.add_child(b1)
	var b2 := UiTheme.accent_button("Kembali ke Lobi", UiTheme.GOLD, Vector2(0, 64))
	b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b2.pressed.connect(func(): lobby_pressed.emit())
	br.add_child(b2)
