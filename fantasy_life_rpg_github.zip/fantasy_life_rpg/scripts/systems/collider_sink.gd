class_name ColliderSink
extends RefCounted
## Penampung bentuk tabrakan statis. Pembangun mesh mendaftarkan kotak/silinder (sudah dalam koordinat akar),
## lalu `apply_to()` mengubahnya menjadi CollisionShape3D pada sebuah StaticBody3D (layer 1 = dunia).

var items: Array = []     # {"t": "box"|"cyl", "xf": Transform3D, "size": Vector3, "r": float, "h": float}


## Kotak: xf = transformasi induk (mis. MeshKit.xf), center = pusat lokal, size = ukuran.
func box(xf: Transform3D, center: Vector3, size: Vector3) -> void:
	items.append({"t": "box", "xf": xf * Transform3D(Basis.IDENTITY, center), "size": size})


## Silinder tegak: base = titik pusat alas lokal.
func cyl(xf: Transform3D, base: Vector3, radius: float, height: float) -> void:
	items.append({"t": "cyl", "xf": xf * Transform3D(Basis.IDENTITY, base + Vector3(0, height * 0.5, 0)), "r": radius, "h": height})


func merge(other: ColliderSink, offset: Transform3D) -> void:
	for it in other.items:
		var c: Dictionary = it.duplicate()
		c["xf"] = offset * it["xf"]
		items.append(c)


func apply_to(body: StaticBody3D) -> void:
	for it in items:
		var cs := CollisionShape3D.new()
		if it["t"] == "box":
			var s := BoxShape3D.new()
			s.size = it["size"]
			cs.shape = s
		else:
			var s := CylinderShape3D.new()
			s.radius = it["r"]
			s.height = it["h"]
			cs.shape = s
		cs.transform = it["xf"]
		body.add_child(cs)
