class_name Decor
extends RefCounted
## Pustaka dekorasi & komponen bangunan (jendela, pintu, lampu, bangku, tong, lapak pasar, pagar, dll).
## Semua fungsi menulis ke MeshKit `k` (koordinat lokal mengikuti k.xf) dan mendaftarkan tabrakan ke ColliderSink `s`.

const WOOD := MeshKit.T_WOOD
const BARK := MeshKit.T_BARK
const BRICK := MeshKit.T_BRICK
const PLASTER := MeshKit.T_PLASTER
const METAL := MeshKit.T_METAL
const STRIPE := MeshKit.T_STRIPE
const CLOTH := MeshKit.T_CLOTH
const LEAVES := MeshKit.T_LEAVES


static func _v(x: float, y: float, z: float) -> Vector3:
	return Vector3(x, y, z)


# =====================================================================
#  Komponen bangunan (menghadap +Z lokal)
# =====================================================================
## Jendela dengan bingkai, kusen bawah, dan daun jendela. emit = kuat cahaya (menyala malam hari).
static func window(k: MeshKit, x: float, y: float, z: float, w: float = 1.0, h: float = 1.25, emit: float = 0.6,
		shutter: Color = Pal.WOOD_DARK, shutters: bool = true) -> void:
	k.box(_v(x, y, z + 0.03), _v(w + 0.24, h + 0.24, 0.1), WOOD, Pal.WOOD_DARK)
	var hw := w * 0.5
	var hh := h * 0.5
	k.quad(_v(x - hw, y - hh, z + 0.09), _v(x + hw, y - hh, z + 0.09), _v(x + hw, y + hh, z + 0.09), _v(x - hw, y + hh, z + 0.09),
		MeshKit.T_WINDOW, MeshKit.glow(Color.WHITE, emit), 1.0, 0.0, w / 1.2)
	k.box(_v(x, y - hh - 0.14, z + 0.14), _v(w + 0.5, 0.1, 0.3), BRICK, Pal.STONE)
	if shutters:
		k.box(_v(x - hw - 0.22, y, z + 0.08), _v(0.34, h + 0.12, 0.06), WOOD, shutter)
		k.box(_v(x + hw + 0.22, y, z + 0.08), _v(0.34, h + 0.12, 0.06), WOOD, shutter)


## Pintu kayu berbesi dengan kusen, lintel, dan anak tangga batu.
static func door(k: MeshKit, x: float, z: float, w: float = 1.4, h: float = 2.3, step: bool = true) -> void:
	var hw := w * 0.5
	k.box(_v(x, h * 0.5, z + 0.03), _v(w + 0.5, h + 0.2, 0.12), WOOD, Pal.WOOD_DARK)
	k.quad(_v(x - hw, 0.0, z + 0.1), _v(x + hw, 0.0, z + 0.1), _v(x + hw, h, z + 0.1), _v(x - hw, h, z + 0.1), MeshKit.T_DOOR, Color.WHITE, 1.0, 0.0, w / 2.0)
	k.box(_v(x, h + 0.22, z + 0.12), _v(w + 0.8, 0.22, 0.28), BRICK, Pal.STONE)
	if step:
		k.box(_v(x, 0.07, z + 0.55), _v(w + 0.9, 0.16, 0.9), BRICK, Pal.STONE_DARK)


## Kotak bunga di bawah jendela (bunga masuk surface cutout).
static func flower_box(k: MeshKit, x: float, y: float, z: float, w: float = 1.4) -> void:
	k.box(_v(x, y, z + 0.18), _v(w, 0.26, 0.34), WOOD, Pal.WOOD_DARK)
	k.cut = true
	var n := int(w / 0.28)
	for i in n:
		var c: Color = Pal.FLOWER_COLORS[k.rng.randi() % Pal.FLOWER_COLORS.size()]
		k.cross_quads(_v(x - w * 0.5 + 0.18 + i * (w - 0.36) / maxf(n - 1, 1), y + 0.1, z + 0.18), 0.34, 0.42, MeshKit.T_FLOWER, c, 0.4, k.rng.randf() * 90.0)
	k.cut = false


static func lantern(k: MeshKit, pos: Vector3, col: Color = Color(1.0, 0.85, 0.5)) -> void:
	k.box(pos, _v(0.22, 0.3, 0.22), METAL, MeshKit.glow(col, 1.0))
	k.box(pos + _v(0, 0.2, 0), _v(0.3, 0.07, 0.3), METAL, Pal.IRON)
	k.box(pos + _v(0, -0.18, 0), _v(0.26, 0.05, 0.26), METAL, Pal.IRON)


static func chimney(k: MeshKit, pos: Vector3, h: float = 2.0, glow_top: bool = false) -> void:
	k.box_b(pos, _v(0.9, h, 0.9), BRICK, Color(0.85, 0.62, 0.55))
	k.box(pos + _v(0, h + 0.07, 0), _v(1.1, 0.16, 1.1), BRICK, Pal.STONE)
	if glow_top:
		k.box(pos + _v(0, h + 0.16, 0), _v(0.6, 0.06, 0.6), METAL, MeshKit.glow(Color(1.0, 0.5, 0.2), 1.0))


# =====================================================================
#  Perabot jalan / taman
# =====================================================================
static func lamp_post(k: MeshKit, s: ColliderSink, pos: Vector3, h: float = 3.4) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.cylinder(_v(0, 0, 0), 0.26, 0.2, 0.45, 8, BRICK, Pal.STONE, true)
	k.cylinder(_v(0, 0.4, 0), 0.075, 0.06, h - 0.4, 6, METAL, Color(0.34, 0.38, 0.5), false, -1, true, 1.0)
	k.box(_v(0, h + 0.18, 0), _v(0.34, 0.42, 0.34), METAL, MeshKit.glow(Color(1.0, 0.86, 0.5), 1.0))
	k.cylinder(_v(0, h + 0.38, 0), 0.34, 0.0, 0.32, 4, METAL, Pal.GOLD, false, -1, false, 1.0)
	k.box(_v(0, h - 0.04, 0), _v(0.4, 0.06, 0.4), METAL, Color(0.34, 0.38, 0.5))
	s.cyl(k.xf, _v(0, 0, 0), 0.26, h)
	k.pop()


static func bench(k: MeshKit, s: ColliderSink, pos: Vector3, yaw_deg: float = 0.0, col: Color = Pal.WOOD) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(yaw_deg)
	k.box(_v(0, 0.5, 0), _v(1.9, 0.12, 0.55), WOOD, col)
	k.box(_v(0, 0.88, -0.24), _v(1.9, 0.5, 0.1), WOOD, col)
	for sx in [-0.8, 0.8]:
		k.box(_v(sx, 0.25, 0), _v(0.14, 0.5, 0.5), BRICK, Pal.STONE)
	s.box(k.xf, _v(0, 0.5, 0), _v(1.9, 1.0, 0.6))
	k.pop()


static func barrel(k: MeshKit, s: ColliderSink, pos: Vector3, col: Color = Pal.WOOD) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.cylinder(_v(0, 0, 0), 0.36, 0.4, 0.5, 8, WOOD, col, false, -1, true, 0.85)
	k.cylinder(_v(0, 0.5, 0), 0.4, 0.34, 0.4, 8, WOOD, col, true, WOOD, true, 1.0)
	k.cylinder(_v(0, 0.12, 0), 0.385, 0.385, 0.05, 8, METAL, Pal.IRON, false)
	k.cylinder(_v(0, 0.72, 0), 0.385, 0.385, 0.05, 8, METAL, Pal.IRON, false)
	s.cyl(k.xf, _v(0, 0, 0), 0.4, 0.9)
	k.pop()


static func crate(k: MeshKit, s: ColliderSink, pos: Vector3, size: float = 0.8, yaw_deg: float = 0.0) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(yaw_deg)
	k.box_b(_v(0, 0, 0), _v(size, size, size), WOOD, k.jitter(Pal.WOOD, 0.08), WOOD, k.jitter(Pal.WOOD, 0.08), 0.8)
	k.box(_v(0, size * 0.5, 0), _v(size + 0.04, 0.08, size + 0.04), WOOD, Pal.WOOD_DARK)
	s.box(k.xf, _v(0, size * 0.5, 0), _v(size, size, size))
	k.pop()


static func sack(k: MeshKit, pos: Vector3, col: Color = Color(0.95, 0.88, 0.7)) -> void:
	k.blob(pos + _v(0, 0.28, 0), 0.32, PLASTER, col, 4, 7, 0.9, 0.3)
	k.cylinder(pos + _v(0, 0.5, 0), 0.1, 0.06, 0.12, 6, WOOD, Pal.WOOD_DARK, true)


## Lapak pasar beratap kain bergaris. goods = warna barang yang dipajang.
static func stall(k: MeshKit, s: ColliderSink, pos: Vector3, yaw_deg: float, awning: Color, goods: Array = []) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(yaw_deg)
	# meja
	k.box(_v(0, 0.55, 0.2), _v(3.0, 0.2, 1.1), WOOD, Pal.WOOD)
	k.box(_v(0, 0.28, 0.2), _v(2.8, 0.55, 0.9), WOOD, Pal.WOOD_DARK)
	# tiang
	for sx in [-1.4, 1.4]:
		k.box(_v(sx, 1.2, -0.45), _v(0.12, 2.4, 0.12), WOOD, Pal.WOOD_DARK)
		k.box(_v(sx, 1.0, 0.8), _v(0.12, 2.0, 0.12), WOOD, Pal.WOOD_DARK)
	# atap kain miring (depan lebih rendah)
	k.quad(_v(-1.65, 1.95, 1.0), _v(1.65, 1.95, 1.0), _v(1.65, 2.6, -0.6), _v(-1.65, 2.6, -0.6), STRIPE, awning, 1.0, 0.0, 1.4)
	k.quad(_v(1.65, 1.93, 1.0), _v(-1.65, 1.93, 1.0), _v(-1.65, 2.58, -0.6), _v(1.65, 2.58, -0.6), CLOTH, _shade(awning, 0.7), 1.0)
	k.quad(_v(1.65, 1.95, 1.0), _v(-1.65, 1.95, 1.0), _v(-1.65, 1.8, 1.0), _v(1.65, 1.8, 1.0), CLOTH, _shade(awning, 0.85), 1.0)
	# barang dagangan
	var i := 0
	for g in goods:
		var gx := -1.05 + i * 0.7
		var col: Color = g
		if i % 2 == 0:
			k.blob(_v(gx, 0.82, 0.2), 0.2, LEAVES, col, 4, 7, 0.95, 0.3)
		else:
			k.box(_v(gx, 0.78, 0.2), _v(0.3, 0.26, 0.3), WOOD, col)
		i += 1
	s.box(k.xf, _v(0, 0.6, 0.2), _v(3.0, 1.2, 1.1))
	k.pop()


static func _shade(c: Color, f: float) -> Color:
	return Color(c.r * f, c.g * f, c.b * f, c.a)


## Pagar kayu dari titik a ke b (tinggi h). Tabrakan berupa satu kotak tipis sepanjang pagar.
static func fence(k: MeshKit, s: ColliderSink, a: Vector3, b: Vector3, h: float = 0.95, post_gap: float = 1.6) -> void:
	var d := b - a
	var length := d.length()
	if length < 0.1:
		return
	var n := maxi(1, int(round(length / post_gap)))
	var dir := d / length
	var ang := atan2(dir.x, dir.z)
	for i in n + 1:
		var p := a + d * (float(i) / n)
		k.box_b(p, _v(0.16, h, 0.16), WOOD, Pal.WOOD_DARK, WOOD, Pal.WOOD, 0.8)
	k.push()
	k.move((a.x + b.x) * 0.5, 0, (a.z + b.z) * 0.5)
	k.xf = k.xf.rotated_local(Vector3.UP, ang)
	for ry in [h * 0.45, h * 0.82]:
		k.box(_v(0, ry, 0), _v(0.08, 0.1, length), WOOD, Pal.WOOD)
	s.box(k.xf, _v(0, h * 0.5, 0), _v(0.3, h, length))
	k.pop()


static func well(k: MeshKit, s: ColliderSink, pos: Vector3) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.cylinder(_v(0, 0, 0), 0.95, 0.9, 0.95, 10, BRICK, Pal.STONE, true, MeshKit.T_WATER, true, 0.8)
	k.cylinder(_v(0, 0.85, 0), 0.95, 0.95, 0.12, 10, BRICK, Pal.STONE_DARK, false)
	for sx in [-0.85, 0.85]:
		k.box_b(_v(sx, 0.9, 0), _v(0.14, 1.9, 0.14), WOOD, Pal.WOOD_DARK)
	k.box(_v(0, 2.88, 0), _v(2.1, 0.1, 0.14), WOOD, Pal.WOOD_DARK)
	k.gable_roof(_v(0, 2.8, 0), 2.0, 1.5, 0.8, 0.2, MeshKit.T_ROOF, Pal.RED, PLASTER, Pal.CREAM, false)
	s.cyl(k.xf, _v(0, 0, 0), 1.0, 1.0)
	k.pop()


static func anvil(k: MeshKit, s: ColliderSink, pos: Vector3, yaw_deg: float = 0.0) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(yaw_deg)
	k.box_b(_v(0, 0, 0), _v(0.5, 0.45, 0.5), BARK, Color(0.7, 0.55, 0.4))
	k.box(_v(0, 0.55, 0), _v(0.4, 0.2, 0.28), METAL, Color(0.5, 0.52, 0.6))
	k.box(_v(0, 0.72, 0), _v(0.95, 0.16, 0.38), METAL, Color(0.6, 0.62, 0.7))
	k.box(_v(0.55, 0.72, 0), _v(0.3, 0.1, 0.2), METAL, Color(0.6, 0.62, 0.7))
	s.box(k.xf, _v(0, 0.4, 0), _v(1.0, 0.8, 0.5))
	k.pop()


static func training_dummy(k: MeshKit, s: ColliderSink, pos: Vector3, yaw_deg: float = 0.0) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(yaw_deg)
	k.cylinder(_v(0, 0, 0), 0.5, 0.5, 0.18, 8, BARK, Color(0.8, 0.65, 0.5), true)
	k.box_b(_v(0, 0.1, 0), _v(0.16, 1.5, 0.16), WOOD, Pal.WOOD_DARK)
	k.box(_v(0, 1.25, 0), _v(1.0, 0.14, 0.14), WOOD, Pal.WOOD_DARK)
	k.blob(_v(0, 1.0, 0), 0.4, PLASTER, Color(0.96, 0.85, 0.62), 4, 8, 1.2, 0.3)
	k.blob(_v(0, 1.72, 0), 0.26, PLASTER, Color(0.96, 0.85, 0.62), 4, 8, 1.0, 0.3)
	k.quad_free(_v(-0.2, 0.8, 0.43), _v(0.2, 0.8, 0.43), _v(0.2, 1.2, 0.43), _v(-0.2, 1.2, 0.43), _v(0, 0, 1), MeshKit.T_EMBLEM,
		Pal.RED, Pal.RED, Pal.RED, Pal.RED, Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0))
	s.cyl(k.xf, _v(0, 0, 0), 0.5, 1.6)
	k.pop()


static func campfire(k: MeshKit, pos: Vector3) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	for i in 8:
		var a := i * TAU / 8.0
		k.blob(_v(cos(a) * 0.6, 0.12, sin(a) * 0.6), 0.2, BRICK, Pal.STONE_DARK, 3, 5, 0.7, 0.3)
	for i in 3:
		k.push()
		k.yaw(i * 60.0 + 10.0)
		k.pitch(80.0)
		k.cylinder(_v(0, -0.5, 0), 0.07, 0.06, 1.0, 5, BARK, Color(0.7, 0.55, 0.4), true)
		k.pop()
	k.cylinder(_v(0, 0.1, 0), 0.28, 0.0, 0.7, 6, METAL, MeshKit.glow(Color(1.0, 0.6, 0.2), 1.0), false, -1, false, 1.0)
	k.cylinder(_v(0, 0.1, 0), 0.16, 0.0, 0.95, 5, METAL, MeshKit.glow(Color(1.0, 0.9, 0.4), 1.0), false, -1, false, 1.0)
	k.pop()


## Tiang spanduk dengan kain bergoyang (cutout). Lambang bintang fajar.
static func banner_pole(k: MeshKit, s: ColliderSink, pos: Vector3, col: Color = Pal.BLUE, h: float = 4.2, yaw_deg: float = 0.0) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(yaw_deg)
	k.cylinder(_v(0, 0, 0), 0.1, 0.07, h, 6, METAL, Color(0.34, 0.38, 0.5), true, -1, true, 1.0)
	k.blob(_v(0, h + 0.1, 0), 0.14, METAL, Pal.GOLD, 3, 6)
	k.box(_v(0.5, h - 0.2, 0), _v(1.0, 0.06, 0.06), METAL, Color(0.34, 0.38, 0.5))
	k.cut = true
	k.sway = 0.35
	var bw := 0.85
	var bh := 1.9
	var top := h - 0.25
	var cw := Color(col.r, col.g, col.b, 1.0)
	# dua sisi (depan +Z, belakang -Z) dengan UV penuh agar lambang utuh
	k.quad_free(_v(0.1, top - bh, 0.03), _v(0.1 + bw, top - bh, 0.03), _v(0.1 + bw, top, 0.03), _v(0.1, top, 0.03), _v(0, 0, 1),
		MeshKit.T_EMBLEM, cw, cw, cw, cw, Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0))
	k.quad_free(_v(0.1 + bw, top - bh, -0.03), _v(0.1, top - bh, -0.03), _v(0.1, top, -0.03), _v(0.1 + bw, top, -0.03), _v(0, 0, -1),
		MeshKit.T_EMBLEM, cw, cw, cw, cw, Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0))
	k.sway = 0.0
	k.cut = false
	s.cyl(k.xf, _v(0, 0, 0), 0.14, h)
	k.pop()


static func rock(k: MeshKit, s: ColliderSink, pos: Vector3, r: float = 0.7, col: Color = Pal.STONE_DARK) -> void:
	k.blob(pos + _v(0, r * 0.35, 0), r, BRICK, k.jitter(col, 0.1), 3, 6, 0.65, 0.4, 0.0, 1.2, 0.9)
	if s != null:
		s.cyl(k.xf, pos, r * 0.9, r * 0.8)


static func bush(k: MeshKit, s: ColliderSink, pos: Vector3, r: float = 0.8, col: Color = Pal.GREEN) -> void:
	k.blob(pos + _v(0, r * 0.55, 0), r, LEAVES, k.jitter(col, 0.08), 4, 7, 0.75, 0.35, 0.3)
	k.blob(pos + _v(r * 0.6, r * 0.4, r * 0.2), r * 0.65, LEAVES, k.jitter(col, 0.08), 3, 6, 0.75, 0.35, 0.3)
	if s != null:
		s.cyl(k.xf, pos, r * 0.8, r * 0.9)


## Hamparan bunga & rumput (cutout) di sekitar titik pusat.
static func flower_patch(k: MeshKit, center: Vector3, radius: float, count: int, with_tufts: bool = true) -> void:
	k.cut = true
	for i in count:
		var a := k.rng.randf() * TAU
		var d := sqrt(k.rng.randf()) * radius
		var p := center + _v(cos(a) * d, 0.0, sin(a) * d)
		var c: Color = Pal.FLOWER_COLORS[k.rng.randi() % Pal.FLOWER_COLORS.size()]
		k.cross_quads(p, 0.38, 0.46, MeshKit.T_FLOWER, c, 0.5, k.rng.randf() * 90.0)
		if with_tufts and i % 2 == 0:
			k.cross_quads(p + _v(0.2, 0, 0.1), 0.6, 0.5, MeshKit.T_TUFT, k.jitter(Color(0.85, 1.0, 0.8), 0.1), 0.8, k.rng.randf() * 90.0)
	k.cut = false


static func hay_bale(k: MeshKit, s: ColliderSink, pos: Vector3, yaw_deg: float = 0.0) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(yaw_deg)
	k.move(0, 0.5, 0)
	k.pitch(90.0)
	k.cylinder(_v(0, -0.5, 0), 0.5, 0.5, 1.0, 10, MeshKit.T_THATCH, Color(1.0, 0.95, 0.75), true, MeshKit.T_THATCH)
	k.pop()
	if s != null:
		s.cyl(k.xf, pos, 0.55, 1.0)


# =====================================================================
#  Senjata & ramuan (hiasan toko)
# =====================================================================
## Pedang berdiri (gagang di bawah). tilt_deg memiringkan pada bidang XY lokal.
static func sword(k: MeshKit, base: Vector3, length: float = 1.2, blade: Color = Color(0.86, 0.92, 1.0), hilt: Color = Pal.GOLD,
		tilt_deg: float = 0.0, yaw_deg: float = 0.0) -> void:
	k.push()
	k.move(base.x, base.y, base.z)
	k.yaw(yaw_deg)
	k.roll(tilt_deg)
	k.box(_v(0, 0.36 + length * 0.5, 0), _v(0.11, length, 0.03), METAL, blade)
	k.cylinder(_v(0, 0.36 + length, 0), 0.055, 0.0, 0.16, 4, METAL, blade, false, -1, false, 1.0)
	k.box(_v(0, 0.36, 0), _v(0.38, 0.07, 0.07), METAL, hilt)
	k.box(_v(0, 0.17, 0), _v(0.07, 0.34, 0.07), WOOD, Pal.WOOD_DARK)
	k.blob(_v(0, 0.0, 0), 0.07, METAL, hilt, 3, 5)
	k.pop()


static func spear(k: MeshKit, base: Vector3, length: float = 2.0, tilt_deg: float = 0.0, yaw_deg: float = 0.0) -> void:
	k.push()
	k.move(base.x, base.y, base.z)
	k.yaw(yaw_deg)
	k.roll(tilt_deg)
	k.box(_v(0, length * 0.5, 0), _v(0.06, length, 0.06), WOOD, Pal.WOOD_DARK)
	k.cylinder(_v(0, length, 0), 0.08, 0.0, 0.3, 4, METAL, Color(0.86, 0.92, 1.0), false, -1, false, 1.0)
	k.pop()


## Perisai bundar menghadap +Z (digantung di dinding atau berdiri).
static func shield(k: MeshKit, c: Vector3, r: float = 0.45, col: Color = Pal.BLUE) -> void:
	k.blob(c, r, METAL, col, 4, 12, 1.0, 0.25, 0.0, 1.0, 0.2)
	k.blob(c + _v(0, 0, r * 0.18), r * 0.3, METAL, Pal.GOLD, 3, 6, 1.0, 0.3, 0.0, 1.0, 0.7)
	k.cylinder(c + _v(0, 0, 0), r * 1.02, r * 1.02, 0.01, 12, METAL, Pal.GOLD, false, -1, false, 1.0)


## Botol ramuan bercahaya.
static func potion(k: MeshKit, base: Vector3, col: Color, scale: float = 1.0) -> void:
	k.blob(base + _v(0, 0.17 * scale, 0), 0.17 * scale, MeshKit.T_CRYSTAL, MeshKit.glow(col, 0.7), 4, 8, 1.0, 0.25)
	k.cylinder(base + _v(0, 0.3 * scale, 0), 0.06 * scale, 0.055 * scale, 0.14 * scale, 6, MeshKit.T_CRYSTAL, MeshKit.glow(col, 0.5), false, -1, true, 1.0)
	k.box(base + _v(0, 0.47 * scale, 0), _v(0.09, 0.07, 0.09) * scale, WOOD, Pal.WOOD_DARK)


## Rak senjata: dua tiang + palang, diisi pedang & tombak.
static func weapon_rack(k: MeshKit, s: ColliderSink, pos: Vector3, yaw_deg: float = 0.0) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(yaw_deg)
	for sx in [-1.2, 1.2]:
		k.box_b(_v(sx, 0, 0), _v(0.14, 1.9, 0.14), WOOD, Pal.WOOD_DARK)
	k.box(_v(0, 1.75, 0), _v(2.6, 0.12, 0.16), WOOD, Pal.WOOD)
	k.box(_v(0, 0.35, 0), _v(2.5, 0.12, 0.5), WOOD, Pal.WOOD)
	for i in 5:
		var x := -0.95 + i * 0.48
		if i % 2 == 0:
			sword(k, _v(x, 0.35, 0.0), 0.9, Color(0.86, 0.92, 1.0), Pal.GOLD, (i - 2) * 3.0)
		else:
			spear(k, _v(x, 0.35, 0.0), 1.5, (i - 2) * 3.0)
	s.box(k.xf, _v(0, 0.9, 0), _v(2.7, 1.8, 0.6))
	k.pop()


## Rak ramuan tiga tingkat menghadap +Z.
static func potion_shelf(k: MeshKit, s: ColliderSink, pos: Vector3, yaw_deg: float = 0.0) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(yaw_deg)
	k.box_b(_v(-1.2, 0, 0), _v(0.12, 1.9, 0.5), WOOD, Pal.WOOD_DARK)
	k.box_b(_v(1.2, 0, 0), _v(0.12, 1.9, 0.5), WOOD, Pal.WOOD_DARK)
	k.box(_v(0, 0.15, -0.2), _v(2.4, 0.3, 0.1), WOOD, Pal.WOOD)
	var cols: Array = [Pal.RED, Pal.BLUE, Pal.GREEN, Pal.PURPLE, Pal.GOLD, Pal.PINK, Pal.TEAL]
	var n := 0
	for ly in [0.55, 1.1, 1.65]:
		k.box(_v(0, ly, 0), _v(2.4, 0.08, 0.5), WOOD, Pal.WOOD)
		for i in 6:
			potion(k, _v(-1.0 + i * 0.4, ly + 0.04, 0.0), cols[n % cols.size()], 0.8 + 0.2 * float(n % 3 == 0))
			n += 1
	s.box(k.xf, _v(0, 0.95, 0), _v(2.6, 1.9, 0.6))
	k.pop()


# =====================================================================
#  Pohon & tanaman
# =====================================================================
## Pohon. kind 0 = berdaun lebar, 1 = cemara, 2 = sakura (merah muda). h = tinggi kira-kira. low = detail rendah (hutan luar).
static func tree(k: MeshKit, s: ColliderSink, pos: Vector3, h: float = 4.5, crown: Color = Pal.GREEN, kind: int = 0, low: bool = false) -> void:
	var sc := h / 5.0
	var rings := 3 if low else 4
	var seg := 6 if low else 8
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(k.rng.randf() * 360.0)
	var trunk_col := Color(1, 1, 1)
	match kind:
		1:
			k.cylinder(_v(0, 0, 0), 0.32 * sc, 0.2 * sc, 2.2 * sc, 6, BARK, trunk_col, false, -1, true, 0.9)
			var c1 := k.jitter(crown, 0.07)
			k.cylinder(_v(0, 1.4 * sc, 0), 2.0 * sc, 0.0, 2.6 * sc, seg, LEAVES, c1, false, -1, false, 0.8, false, 0.6)
			k.cylinder(_v(0, 2.8 * sc, 0), 1.6 * sc, 0.0, 2.3 * sc, seg, LEAVES, k.jitter(crown, 0.07), false, -1, false, 0.85, false, 0.7)
			k.cylinder(_v(0, 4.1 * sc, 0), 1.1 * sc, 0.0, 2.0 * sc, seg, LEAVES, k.jitter(crown, 0.07), false, -1, false, 0.9, false, 0.8)
		_:
			var crown_c := crown
			if kind == 2:
				crown_c = Color(1.0, 0.7, 0.8)
			k.cylinder(_v(0, 0, 0), 0.42 * sc, 0.26 * sc, 3.0 * sc, 7, BARK, trunk_col, false, -1, true, 0.9)
			k.blob(_v(0, 4.3 * sc, 0), 2.0 * sc, LEAVES, k.jitter(crown_c, 0.07), rings, seg, 0.85, 0.35, 0.6)
			k.blob(_v(1.1 * sc, 3.5 * sc, 0.6 * sc), 1.4 * sc, LEAVES, k.jitter(crown_c, 0.08), rings, seg, 0.85, 0.35, 0.6)
			if not low:
				k.blob(_v(-1.0 * sc, 3.6 * sc, -0.6 * sc), 1.3 * sc, LEAVES, k.jitter(crown_c, 0.08), rings, seg, 0.85, 0.35, 0.6)
	if s != null:
		s.cyl(k.xf, _v(0, 0, 0), 0.5 * sc, 3.0)
	k.pop()


## Petak bunga berbingkai batu (hiasan plaza & taman).
static func planter(k: MeshKit, s: ColliderSink, pos: Vector3, yaw_deg: float = 0.0, w: float = 3.0, d: float = 1.4) -> void:
	k.push()
	k.move(pos.x, pos.y, pos.z)
	k.yaw(yaw_deg)
	k.box_b(_v(0, 0, 0), _v(w, 0.5, d), BRICK, Pal.STONE, BRICK, Pal.STONE_DARK, 0.85)
	k.plane(_v(0, 0.51, 0), w - 0.3, d - 0.3, MeshKit.T_DIRT, Color(0.75, 0.6, 0.5))
	k.cut = true
	for i in int(w * 3.0):
		var c: Color = Pal.FLOWER_COLORS[k.rng.randi() % Pal.FLOWER_COLORS.size()]
		k.cross_quads(_v(k.rng.randf_range(-w * 0.45, w * 0.45), 0.5, k.rng.randf_range(-d * 0.4, d * 0.4)), 0.4, 0.55, MeshKit.T_FLOWER, c, 0.5, k.rng.randf() * 90.0)
	k.cut = false
	s.box(k.xf, _v(0, 0.3, 0), _v(w, 0.6, d))
	k.pop()
