class_name Quality
extends RefCounted
## Menerapkan preset grafis ke viewport, matahari, kamera, dan lingkungan. Level efektif (0 Lancar / 1 Sedang / 2 Bagus) datang dari
## Perf.level(): pilihan manual atau hasil deteksi perangkat ("Otomatis").
##   0 Lancar (paling ringan): resolusi 3D ~0.55 MP, tanpa bayangan nyata (diganti bayangan semu), tanpa MSAA/glow,
##      lampu titik dimatikan, jarak pandang pendek.
##   1 Sedang: resolusi 3D ~0.8 MP, bayangan 1 kaskade 1024 px jarak dekat, tanpa MSAA/glow.
##   2 Bagus: resolusi asli, bayangan 2 kaskade 2048 px halus + MSAA 2x + glow lembut + warna sedikit lebih kaya.
const CHUNK := 16.0                              # 1 chunk = 16 m
const CHUNKS := [6, 9, 12]                       # jarak render per kualitas Lancar / Sedang / Bagus
const SHADOW_DIST := [30.0, 30.0, 70.0]
const SHADOW_SIZE := [1024, 1024, 2048]

static var _blob_mat: StandardMaterial3D
static var _blob_mesh: QuadMesh


static func level() -> int:
	return Perf.level()


## Jarak render dalam chunk: pengaturan "Jarak render" (0 = otomatis mengikuti kualitas/perangkat; 1..3 = 6/9/12 chunk).
static func view_chunks() -> int:
	var v := int(GameState.setting("view_dist"))
	if v >= 1 and v <= 3:
		return CHUNKS[v - 1]
	return CHUNKS[clampi(level(), 0, 2)]


static func view_far() -> float:
	return 420.0 if Perf.classic() else float(view_chunks()) * CHUNK


static func shadows_on() -> bool:
	return bool(GameState.setting("shadows")) and level() > 0


static func apply(viewport: Viewport, sun: DirectionalLight3D, cam: Camera3D = null, env: Environment = null) -> void:
	var q := level()
	var shadows := shadows_on()
	var classic := Perf.classic()
	if sun:
		sun.shadow_enabled = shadows
		sun.directional_shadow_max_distance = 55.0 if classic else SHADOW_DIST[q]
		sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS if q >= 2 else DirectionalLight3D.SHADOW_ORTHOGONAL
		sun.directional_shadow_blend_splits = q >= 2
	RenderingServer.directional_shadow_atlas_set_size(2048 if classic else SHADOW_SIZE[q], q < 2)
	RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_LOW if q >= 2 else RenderingServer.SHADOW_QUALITY_HARD)
	if viewport:
		viewport.msaa_3d = Viewport.MSAA_2X if q >= 2 else Viewport.MSAA_DISABLED
	if cam:
		cam.far = view_far()
	if env:
		env.glow_enabled = q >= 2
		env.glow_intensity = 0.55
		env.glow_strength = 0.9
		env.glow_bloom = 0.04
		env.glow_hdr_threshold = 0.95
		env.adjustment_enabled = q >= 2
		env.adjustment_contrast = 1.06
		env.adjustment_saturation = 1.12
	Perf.apply_scale()
	if viewport:
		var tree := viewport.get_tree()
		if tree:
			for n in tree.get_nodes_in_group("blob_shadow"):
				(n as Node3D).visible = not shadows
			for l in tree.get_nodes_in_group("deco_light"):        # lampu titik: tiap lampu = render ulang objek di sekitarnya (Compatibility)
				(l as Light3D).visible = q > 0


## Bayangan semu bulat di tanah (1 quad, tanpa bayangan nyata). Hanya terlihat bila bayangan nyata mati (Lancar / saklar Bayangan mati).
static func blob(parent: Node3D, radius: float = 0.6, y: float = 0.04) -> MeshInstance3D:
	if _blob_mat == null:
		var gr := Gradient.new()
		gr.colors = PackedColorArray([Color(0, 0, 0, 0.5), Color(0, 0, 0, 0.32), Color(0, 0, 0, 0)])
		gr.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
		var tex := GradientTexture2D.new()
		tex.gradient = gr
		tex.fill = GradientTexture2D.FILL_RADIAL
		tex.fill_from = Vector2(0.5, 0.5)
		tex.fill_to = Vector2(1.0, 0.5)
		tex.width = 64
		tex.height = 64
		_blob_mat = StandardMaterial3D.new()
		_blob_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_blob_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_blob_mat.albedo_texture = tex
		_blob_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		_blob_mat.no_depth_test = false
		_blob_mat.render_priority = -1
		_blob_mesh = QuadMesh.new()
		_blob_mesh.orientation = PlaneMesh.FACE_Y
		_blob_mesh.size = Vector2(2, 2)
	var mi := MeshInstance3D.new()
	mi.name = "BlobShadow"
	mi.mesh = _blob_mesh
	mi.material_override = _blob_mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.position = Vector3(0, y, 0)
	mi.scale = Vector3(radius, 1.0, radius)
	mi.visible = not shadows_on()
	mi.add_to_group("blob_shadow")
	parent.add_child(mi)
	return mi
