extends RefCounted
## Bot uji eksplorasi lobi: peti (interaksi nyata, hadiah, simpan), area rahasia, titik teleport, minimap HUD, panel peta.
var lb: Node3D
var fails := 0

func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1

func _wait(t: float) -> void:
	await lb.get_tree().create_timer(t).timeout

func _stand_at(p: Vector2) -> void:
	lb.player.global_position = Vector3(p.x, 0.1, p.y)
	lb.player.velocity = Vector3.ZERO
	await _wait(0.5)

func run(l: Node3D) -> void:
	lb = l
	await _wait(1.0)
	var tmp := OS.get_cmdline_user_args()
	var shots: String = lb._arg("shots", "/tmp")
	check("minimap ada di HUD", lb.hud.minimap != null and lb.hud.minimap.is_visible_in_tree(), "")
	check("peta data: 13 peti, 3 area, 9 titik", Explore.CHESTS.size() == 13 and Explore.ZONES.size() == 3 and Explore.WAYPOINTS.size() == 9, "")
	# --- peti lewat interaksi nyata
	var g0: int = GameState.gold
	var c: Dictionary = Explore.chest_def("c_plaza")
	await _stand_at(c["pos"] + Vector2(0, 1.4))
	var tg: Dictionary = lb._find_target()
	check("peti terdeteksi sebagai target interaksi", str(tg.get("id", "")) == "chest:c_plaza", str(tg.get("id", "")))
	lb._target = tg
	var p0 := GameState.item_count("p_small")
	lb._try_interact()
	await _wait(0.3)
	check("peti terbuka & emas bertambah", Explore.is_opened("c_plaza") and GameState.gold == g0 + 150, "gold %d -> %d" % [g0, GameState.gold])
	check("peti memberi item", GameState.item_count("p_small") == p0 + 1, "")
	var g1: int = GameState.gold
	lb._run_action("chest:c_plaza")
	check("peti tidak bisa dibuka dua kali", GameState.gold == g1, "")
	await _wait(0.2)
	tg = lb._find_target()
	check("peti terbuka tidak lagi jadi target", str(tg.get("id", "")) != "chest:c_plaza", "")
	# --- simpan & muat
	# data peti harus lolos serialisasi JSON seperti berkas simpan (flags ikut disimpan oleh GameState.save_game)
	var d = JSON.parse_string(JSON.stringify({"flags": GameState.flags}))
	check("peti ikut dalam JSON simpan", d is Dictionary and d["flags"]["explore"]["chests"].has("c_plaza"), "")
	GameState.flags = d["flags"]
	check("peti tetap terbuka setelah muat", Explore.is_opened("c_plaza"), "")
	# --- area rahasia + titik teleport
	check("area rahasia belum ditemukan di awal", not Explore.is_discovered("z_lorong"), "")
	var dia0: int = GameState.diamonds
	await _stand_at(Vector2(-60, -36))
	check("area rahasia ditemukan & hadiah diamond", Explore.is_discovered("z_lorong") and GameState.diamonds == dia0 + 40, "dia %d -> %d" % [dia0, GameState.diamonds])
	check("titik teleport area rahasia terbuka", Explore.is_discovered("wp_lorong"), "")
	var dia1: int = GameState.diamonds
	await _stand_at(Vector2(-59, -35))
	check("area rahasia tak memberi hadiah dua kali", GameState.diamonds == dia1, "")
	await _stand_at(Vector2(-60, -42))
	check("peti tersembunyi terungkap dalam jarak dekat", Explore.is_discovered("h_w1"), "")
	check("teleport ke titik belum terbuka ditolak", not lb.teleport_to("wp_portal"), "")
	check("teleport ke titik terbuka berhasil", lb.teleport_to("wp_lorong"), "")
	await _wait(0.3)
	var pp: Vector3 = lb.player.global_position
	check("pemain berada di titik tujuan", Vector2(pp.x, pp.z).distance_to(Vector2(-60, -33.8)) < 1.5, str(pp))
	check("teleport ke titik selalu-terbuka (gerbang)", lb.teleport_to("wp_gate"), "")
	await _wait(0.3)
	# --- semua posisi peti/titik tidak berada di dalam benda padat selain objeknya sendiri (tes dilakukan sebelum objek dipasang di reach_scan)
	var bad := 0
	for cc: Dictionary in Explore.CHESTS:
		await _stand_at(cc["pos"] + Vector2(0, 1.6))
		var pz: Vector3 = lb.player.global_position
		if pz.y < -0.5 or Vector2(pz.x, pz.z).distance_to(cc["pos"] + Vector2(0, 1.6)) > 1.0:
			bad += 1
			print("  posisi bermasalah ", cc["id"], " ", pz)
	check("pemain dapat berdiri di sebelah semua peti", bad == 0, "bermasalah %d" % bad)
	# --- panel peta
	await _stand_at(Vector2(0, 14))
	lb.host.open("map")
	await _wait(0.6)
	check("panel peta terbuka", lb.host.current_id == "map", "")
	await lb._shot("explore_map")
	lb.host.close()
	await _wait(0.3)
	await lb._shot("explore_hud")
	check("tidak ada peringatan 'belum tersedia' pada panel peta", ResourceLoader.exists("res://scripts/ui/panels/map_panel.gd"), "")
	print("CHECK SUMMARY fails=", fails)
