extends RefCounted
## Menghitung pemutaran Sfx selama pertarungan bos (membungkus Sfx.play) — bukti bahwa tiap efek benar-benar terpicu.
var st: Node3D
var counts := {}
func _w(s: float) -> void:
	await st.get_tree().create_timer(s).timeout
func run(s: Node3D) -> void:
	st = s
	var guard := 0.0
	while st.boss == null and guard < 40.0:
		await _w(0.3)
		guard += 0.3
		for e in st.get_tree().get_nodes_in_group("enemies"):
			if not e.is_boss and e.state != "spawn":
				e.take_damage(99999, st.player.global_position, 0.0)
	var b: Enemy = st.boss
	# pasang penghitung pada pool pemutar
	var seen := {}
	var orig_sounds: Dictionary = Sfx._sounds.duplicate()
	var t := 0.0
	while t < 45.0 and not b.dead:
		await _w(0.1)
		t += 0.1
		for p in Sfx._pool + [Sfx._voice]:
			if p.playing and p.stream != null:
				for k in orig_sounds:
					if orig_sounds[k] == p.stream and p.get_playback_position() < 0.15:
						seen[k] = true
		for ps in st.party_state:
			ps["hp"] = ps["max"]
		if int(t * 10) % 40 == 0:
			b.take_damage(30, st.player.global_position, 1.0)
	b.take_damage(b.max_hp / 2 + 5, st.player.global_position, 3.0)
	await _w(0.5)
	b.take_damage(b.hp + 10, st.player.global_position, 3.0)
	await _w(0.5)
	for p in Sfx._pool + [Sfx._voice]:
		if p.playing and p.stream != null:
			for k in orig_sounds:
				if orig_sounds[k] == p.stream:
					seen[k] = true
	var boss_sfx: Array = []
	for k in seen:
		if str(k).begins_with("boss_"):
			boss_sfx.append(k)
	boss_sfx.sort()
	print("CHECK boss sfx triggered: ", boss_sfx)
	print("CHECK music: ", Sfx._music_name)
