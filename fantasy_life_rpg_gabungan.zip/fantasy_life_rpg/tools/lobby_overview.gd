extends RefCounted
## Bot: foto lobi dari atas (peta) dan dari beberapa sudut rendah untuk memeriksa tata letak.
func run(l: Node3D) -> void:
	var tree := l.get_tree()
	await tree.create_timer(1.5).timeout
	l.hud.visible = false
	l.touch.visible = false if l.get("touch") else false
	var c := Camera3D.new()
	l.add_child(c)
	c.make_current()
	c.projection = Camera3D.PROJECTION_ORTHOGONAL
	c.size = 150.0
	c.position = Vector3(0, 200, 8)
	c.rotation_degrees = Vector3(-90, 0, 0)
	await tree.create_timer(0.5).timeout
	await l._shot("ov_top")
	# empat kuadran lebih dekat
	c.size = 80.0
	for q in [["nw", Vector3(-38, 200, -26)], ["ne", Vector3(38, 200, -26)], ["sw", Vector3(-38, 200, 40)], ["se", Vector3(38, 200, 40)]]:
		c.position = q[1]
		await tree.create_timer(0.3).timeout
		await l._shot("ov_" + q[0])
