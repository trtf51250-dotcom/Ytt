extends Node
## Uji Perf (tebak kelas HP, skala resolusi, governor) & Quality. Angka sintetis, tidak mengukur FPS nyata.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1

func _ready() -> void:
	await get_tree().process_frame
	var T := Perf.detect_tier
	check("PowerVR GE8320 (Helio P22/P35) = Lancar", T.call({"gpu": "PowerVR Rogue GE8320", "ram_mb": 3000, "cores": 8}) == 0)
	check("Mali-G52 (Helio G80) = Sedang", T.call({"gpu": "Mali-G52 MC2", "ram_mb": 6000, "cores": 8}) == 1)
	check("Mali-G72 = Sedang", T.call({"gpu": "Mali-G72 MP3", "ram_mb": 6000, "cores": 8}) == 1)
	check("Mali-T830 lama = Lancar", T.call({"gpu": "Mali-T830", "ram_mb": 4000, "cores": 8}) == 0)
	check("Mali-G57 = Sedang", T.call({"gpu": "Mali-G57 MC2", "ram_mb": 6000, "cores": 8}) == 1)
	check("Adreno 505 = Lancar", T.call({"gpu": "Adreno (TM) 505", "ram_mb": 4000, "cores": 8}) == 0)
	check("Adreno 610 = Sedang", T.call({"gpu": "Adreno (TM) 610", "ram_mb": 6000, "cores": 8}) == 1)
	check("Adreno 740 = Bagus", T.call({"gpu": "Adreno (TM) 740", "ram_mb": 12000, "cores": 8}) == 2)
	check("Mali-G710 = Bagus", T.call({"gpu": "Mali-G710 MC10", "ram_mb": 8000, "cores": 8}) == 2)
	check("RAM 2 GB menekan ke Lancar", T.call({"gpu": "Adreno (TM) 740", "ram_mb": 2048, "cores": 8}) == 0)
	check("RAM 4 GB membatasi Bagus -> Sedang", T.call({"gpu": "Adreno (TM) 740", "ram_mb": 4000, "cores": 8}) == 1)
	check("tak dikenal tanpa RAM = Sedang", T.call({"gpu": "Mystery", "ram_mb": -1, "cores": 0}) == 1)
	check("llvmpipe = Lancar", T.call({"gpu": "llvmpipe (LLVM 15)", "ram_mb": -1, "cores": 4}) == 0)
	# skala
	var s0 := Perf.preset_scale(0, 1920, 1080)
	var s1 := Perf.preset_scale(1, 1920, 1080)
	check("skala Lancar < Sedang < Bagus(1.0) pada 1080p", s0 < s1 and s1 < 1.0 and s0 >= 0.5, "%.2f %.2f" % [s0, s1])
	check("layar kecil tidak diperbesar (720p Bagus = 1.0)", Perf.preset_scale(2, 1280, 720) == 1.0)
	# governor
	GameState.settings["quality"] = 0
	GameState.settings["dyn_res"] = true
	Perf.dyn = 1.0
	Perf._since_raise = 999.0
	for i in 10: Perf.govern(30.0, 40.0)
	check("governor menurunkan skala saat lambat", Perf.dyn < 1.0 and Perf.scale_now() >= Perf.FLOOR_SCALE[0] - 0.001, "dyn=%.2f" % Perf.dyn)
	var low := Perf.dyn
	for i in 40: Perf.govern(10.0, 12.0)
	check("governor menaikkan lagi setelah stabil", Perf.dyn > low, "dyn=%.2f" % Perf.dyn)
	Perf.dyn = 1.0
	Perf.govern(12.0, 900.0)
	check("lonjakan tunggal tidak menurunkan skala", Perf.dyn == 1.0)
	GameState.settings["dyn_res"] = false
	Perf.dyn = 0.6
	check("resolusi dinamis mati -> dyn diabaikan", absf(Perf.scale_now() - Perf.preset_scale(0, DisplayServer.window_get_size().x, DisplayServer.window_get_size().y)) < 0.001)
	GameState.settings["dyn_res"] = true
	Perf.dyn = 1.0
	# Quality
	var sun := DirectionalLight3D.new()
	var env := Environment.new()
	add_child(sun)
	for q in [0, 1, 2]:
		GameState.settings["quality"] = q
		GameState.settings["shadows"] = true
		Quality.apply(get_viewport(), sun, null, env)
		check("q%d bayangan=%s MSAA=%s glow=%s" % [q, sun.shadow_enabled, get_viewport().msaa_3d, env.glow_enabled],
			sun.shadow_enabled == (q > 0) and (get_viewport().msaa_3d == Viewport.MSAA_2X) == (q == 2) and env.glow_enabled == (q == 2))
	var holder := Node3D.new()
	add_child(holder)
	GameState.settings["quality"] = 0
	var b := Quality.blob(holder, 1.0)
	check("blob terlihat saat bayangan nyata mati (Lancar)", b.visible)
	GameState.settings["quality"] = 2
	Quality.apply(get_viewport(), sun, null, env)
	check("blob tersembunyi saat bayangan nyata aktif (Bagus)", not b.visible)
	GameState.settings["quality"] = -1
	check("Otomatis memakai tier terdeteksi", Perf.level() == Perf.tier)
	GameState.settings["quality"] = 3
	check("Klasik: skala 1.0, tanpa resolusi dinamis, level Sedang", Perf.scale_now() == 1.0 and not Perf.dyn_enabled() and Perf.level() == 1)
	Quality.apply(get_viewport(), sun, null, env)
	check("Klasik: tanpa MSAA/glow, bayangan aktif", get_viewport().msaa_3d == Viewport.MSAA_DISABLED and not env.glow_enabled and sun.shadow_enabled)
	print("SUMMARY fails=", fails)
	get_tree().quit(fails)
