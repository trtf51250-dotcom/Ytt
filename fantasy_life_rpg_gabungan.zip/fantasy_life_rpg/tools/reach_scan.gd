extends RefCounted
## Alat desain: peta ASCII lobi (. dapat dicapai dari spawn, # padat, o ruang kosong tak terjangkau) untuk menempatkan chest/area rahasia.
var lb: Node3D

func _blocked(x: float, z: float) -> bool:
	var q := PhysicsShapeQueryParameters3D.new()
	var sp := SphereShape3D.new()
	sp.radius = 0.45
	q.shape = sp
	q.transform = Transform3D(Basis(), Vector3(x, 1.0, z))
	q.collision_mask = 1
	return not lb.get_world_3d().direct_space_state.intersect_shape(q, 1).is_empty()

func run(l: Node3D) -> void:
	lb = l
	await lb.get_tree().create_timer(1.0).timeout
	var x0 := -80; var x1 := 80; var z0 := -66; var z1 := 80
	var W := x1 - x0 + 1
	var H := z1 - z0 + 1
	var blk := {}
	for z in range(z0, z1 + 1):
		for x in range(x0, x1 + 1):
			blk[Vector2i(x, z)] = _blocked(x, z)
	var seen := {}
	var st: Array = [Vector2i(0, 50)]
	seen[Vector2i(0, 50)] = true
	while not st.is_empty():
		var c: Vector2i = st.pop_back()
		for d in [Vector2i(1,0), Vector2i(-1,0), Vector2i(0,1), Vector2i(0,-1)]:
			var n: Vector2i = c + d
			if n.x < x0 or n.x > x1 or n.y < z0 or n.y > z1 or seen.has(n) or blk[n]:
				continue
			seen[n] = true
			st.push_back(n)
	var f := FileAccess.open("/tmp/reach.txt", FileAccess.WRITE)
	f.store_line("x from %d to %d, z from %d to %d (2 m per char)" % [x0, x1, z0, z1])
	for z in range(z0, z1 + 1, 2):
		var line := "%4d " % z
		for x in range(x0, x1 + 1, 2):
			var c := Vector2i(x, z)
			line += "." if seen.has(c) else ("#" if blk[c] else "o")
		f.store_line(line)
	f.close()
	print("reach cells ", seen.size())
	var cands := {"c_gate": Vector2i(-8, 56), "c_plaza": Vector2i(12, -12), "c_forge": Vector2i(-32, -44), "c_library": Vector2i(32, -44), "c_altar": Vector2i(-38, 42), "c_pond": Vector2i(38, 44), "c_camp": Vector2i(-58, 10), "c_portal": Vector2i(58, 12),
		"h_w1": Vector2i(-60, -44), "h_w2": Vector2i(-60, -28), "h_e1": Vector2i(60, -30), "h_e2": Vector2i(60, -18), "h_s1": Vector2i(-60, 57),
		"wp_gate": Vector2i(0, 52), "wp_plaza": Vector2i(0, 14), "wp_guild": Vector2i(0, -30), "wp_portal": Vector2i(46, 0), "wp_camp": Vector2i(-46, 0), "wp_pond": Vector2i(31, 31), "wp_altar": Vector2i(-31, 31), "wp_lorong": Vector2i(-60, -36), "wp_timur": Vector2i(60, -24)}
	for k in cands:
		var best := Vector2i(999, 999)
		var bd := 1e9
		for c in seen:
			var ok := true
			for dx in range(-2, 3):
				for dz in range(-2, 3):
					if not seen.has(c + Vector2i(dx, dz)):
						ok = false
			if ok:
				var d := Vector2(c - cands[k]).length()
				if d < bd:
					bd = d
					best = c
		print("SNAP ", k, " ", cands[k], " -> ", best, " d=", snappedf(bd, 0.1))
