extends RefCounted
## Rumah tembus pandang hanya jika benar-benar menghalangi kamera -> pemain; tidak boleh karena sekadar berdiri dekat dinding.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func run(lb: Node3D) -> void:
	var t := lb.get_tree()
	await t.create_timer(1.5).timeout
	var b: Node3D = null
	for x in lb.world.buildings:
		if x.can_fade:
			b = x
			break
	check("ada bangunan yang bisa memudar", b != null)
	if b == null:
		t.quit()
		return
	var box: AABB = b.world_aabb
	var c := box.get_center()
	var pl: Node3D = lb.player
	var cam = lb.cam
	# 1) pemain tepat di samping dinding (0,5 m di luar kotak), kamera di sisi yang sama -> TIDAK memudar
	pl.global_position = Vector3(box.position.x - 0.5, 0.1, c.z)
	cam.cam.global_position = Vector3(box.position.x - 8.0, 7.0, c.z)
	await t.create_timer(0.3).timeout
	var head := pl.global_position + Vector3(0, 1.4, 0)
	var near: bool = cam.segment_hits_aabb(head, box.grow(-0.25), 0.8)
	check("dekat dinding tanpa bangunan di antara kamera & pemain: tidak transparan", not near)
	# 2) pemain di sisi lain bangunan, kamera di seberang -> memudar
	pl.global_position = Vector3(box.end.x + 1.5, 0.1, c.z)
	head = pl.global_position + Vector3(0, 1.4, 0)
	var behind: bool = cam.segment_hits_aabb(head, box.grow(-0.25), 0.8)
	check("bangunan di antara kamera & pemain: transparan", behind)
	print("FAILS=", fails)
	t.quit()
