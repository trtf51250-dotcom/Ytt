class_name Ambient
extends Node3D
## Kehidupan lobi: kupu-kupu di siang hari, kunang-kunang di malam hari. Hanya ~18 quad kecil yang selalu berada di sekitar pemain
## (ditempatkan ulang bila terlalu jauh), jadi murah untuk HP. Mati otomatis pada kualitas "Lancar".

const COUNT := 18
const RADIUS := 24.0

var player: Node3D
var daynight: DayNight
var _bugs: Array = []          # {node, mat, base:Vector3, ph:float, spd:float, col:Color}
var _t := 0.0
var _tex_wing: ImageTexture
var _tex_glow: ImageTexture


static func _tex(kind: String) -> ImageTexture:
	var n := 48
	var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
	for y in n:
		for x in n:
			var u := (x + 0.5) / n * 2.0 - 1.0
			var v := (y + 0.5) / n * 2.0 - 1.0
			var a := 0.0
			if kind == "glow":
				a = clampf(1.0 - sqrt(u * u + v * v), 0.0, 1.0)
				a = a * a
			else:
				# dua sayap (elips miring kiri & kanan) + badan tipis
				var wx := absf(u)
				var d1 := Vector2((wx - 0.5) / 0.46, (v + 0.28 * (1.0 - wx)) / 0.55).length()
				var d2 := Vector2((wx - 0.4) / 0.34, (v - 0.4) / 0.4).length()
				if d1 < 1.0 or d2 < 1.0:
					a = 1.0 - 0.35 * minf(d1, d2)
				if wx < 0.06 and absf(v) < 0.6:
					a = 1.0
			img.set_pixel(x, y, Color(1, 1, 1, clampf(a, 0.0, 1.0)))
	return ImageTexture.create_from_image(img)


func setup(p: Node3D, dn: DayNight) -> void:
	player = p
	daynight = dn
	var quad := QuadMesh.new()
	quad.size = Vector2(0.6, 0.6)
	_tex_wing = _tex("wing")
	_tex_glow = _tex("glow")
	for i in COUNT:
		var mi := MeshInstance3D.new()
		mi.mesh = quad
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.no_depth_test = false
		mi.material_override = m
		add_child(mi)
		_bugs.append({"node": mi, "mat": m, "base": Vector3.ZERO, "ph": randf() * TAU, "spd": randf_range(0.6, 1.4), "col": Color.WHITE})
		_respawn(_bugs[i], true)
	visible = true


func _respawn(b: Dictionary, anywhere: bool) -> void:
	var c: Vector3 = player.global_position if player != null else Vector3.ZERO
	var a := randf() * TAU
	var r := sqrt(randf()) * (RADIUS if anywhere else RADIUS * 0.95)
	b["base"] = Vector3(clampf(c.x + cos(a) * r, LobbyLayout.BOUNDS_MIN.x, LobbyLayout.BOUNDS_MAX.x), randf_range(0.9, 2.6), clampf(c.z + sin(a) * r, LobbyLayout.BOUNDS_MIN.y, LobbyLayout.BOUNDS_MAX.y))
	var cols := [Color(1.0, 0.35, 0.65), Color(1.0, 0.7, 0.15), Color(0.3, 0.6, 1.0), Color(0.7, 0.4, 1.0)]
	b["col"] = cols[randi() % cols.size()]


func _process(delta: float) -> void:
	if player == null or daynight == null:
		return
	if Quality.level() == 0:       # "Lancar": tanpa hiasan
		visible = false
		return
	visible = true
	_t += delta
	var h := daynight.hour
	var day := h >= 6.5 and h <= 17.5
	var night := h >= 19.0 or h <= 4.5
	for b in _bugs:
		var n: MeshInstance3D = b["node"]
		var m: StandardMaterial3D = b["mat"]
		var base: Vector3 = b["base"]
		if Vector2(base.x - player.global_position.x, base.z - player.global_position.z).length() > RADIUS + 6.0:
			_respawn(b, false)
			base = b["base"]
		var t: float = _t * float(b["spd"]) + float(b["ph"])
		if day:
			# kupu-kupu: terbang meliuk, sayap mengepak (skala X)
			n.global_position = base + Vector3(sin(t * 0.7) * 2.2, sin(t * 1.3) * 0.5, cos(t * 0.55) * 2.2)
			n.scale = Vector3(0.25 + absf(sin(t * 9.0)) * 0.9, 1.0, 1.0)
			m.albedo_texture = _tex_wing
			m.albedo_color = Color(b["col"], 0.95)
			n.visible = true
		elif night:
			# kunang-kunang: melayang pelan, berkedip hangat
			n.global_position = base + Vector3(sin(t * 0.35) * 1.6, sin(t * 0.6) * 0.4, cos(t * 0.3) * 1.6)
			n.scale = Vector3.ONE * 1.1
			m.albedo_texture = _tex_glow
			var blink := 0.35 + 0.65 * (0.5 + 0.5 * sin(t * 2.2))
			m.albedo_color = Color(0.85, 1.0, 0.4, blink)
			n.visible = true
		else:
			n.visible = false      # senja/fajar: tidak ada
