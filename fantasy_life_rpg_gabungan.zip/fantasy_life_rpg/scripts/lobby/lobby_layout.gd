class_name LobbyLayout
extends RefCounted
## Data tata letak kota Aurelia (sumbu X = timur, Z = selatan/ke arah kamera). Satuan meter.
## Dipakai oleh LobbyWorld (membangun dunia), Lobby (NPC, spawn) dan alat uji.

const SPAWN := Vector3(0.0, 0.1, 50.0)          # titik muncul pemain (di dalam gerbang)
const SPAWN_YAW := 180.0                        # menghadap ke utara (-Z)
const WALL_MIN := Vector2(-64.0, -52.0)         # sudut tembok kota
const WALL_MAX := Vector2(64.0, 62.0)
const GATE_X := 9.2                             # setengah lebar bukaan gerbang pada tembok
const PLAZA_R := 15.0
const BUILDING_SCALE := 1.1                     # pembesaran semua bangunan (kecuali yang terikat ukuran tetap)
const NO_SCALE := ["fountain", "gate"]          # air mancur & gerbang terikat pada plaza/tembok
const BOUNDS_MIN := Vector2(-80.0, -66.0)       # batas tak terlihat tempat pemain bisa berjalan
const BOUNDS_MAX := Vector2(80.0, 78.0)

## Kota ditata seperti papan catur: sumbu utara-selatan (gerbang -> plaza -> guild), bulevar timur-barat
## (kamp party di ujung barat, portal di ujung timur), dua jalan samping di x = +-40 dan deretan bangunan yang SELALU menghadap jalan.
## Konvensi arah (yaw): 0 = muka menghadap +Z (selatan), 90 = menghadap +X (timur), 180 = menghadap -Z (utara), -90 = menghadap -X (barat).
## kind, pos (x,z), yaw (derajat), warna atap/dinding.
const BUILDINGS: Array = [
	{"kind": "fountain", "pos": Vector2(0, 0), "yaw": 0.0},
	{"kind": "gate", "pos": Vector2(0, 62), "yaw": 0.0, "seed": 11},
	# --- utara: guild menghadap plaza, bengkel & perpustakaan mengapit jalan guild
	{"kind": "guild", "pos": Vector2(0, -39.2), "yaw": 0.0, "roof": Color(0.32, 0.55, 0.95), "wall": Color(1.0, 0.96, 0.88), "seed": 1},
	{"kind": "forge", "pos": Vector2(-26, -33), "yaw": 90.0, "roof": Color(0.5, 0.52, 0.62), "seed": 4},
	{"kind": "library", "pos": Vector2(26, -33), "yaw": -90.0, "seed": 5},
	# --- bulevar timur-barat: toko di sisi utara menghadap jalan
	{"kind": "weapon_shop", "pos": Vector2(-30, -13), "yaw": 0.0, "roof": Color(0.92, 0.36, 0.32), "wall": Color(1.0, 0.94, 0.84), "seed": 2},
	{"kind": "item_shop", "pos": Vector2(30, -13), "yaw": 0.0, "roof": Color(0.22, 0.72, 0.7), "wall": Color(0.95, 1.0, 0.94), "seed": 3},
	# --- ujung bulevar: kamp party (barat) dan portal petualangan (timur)
	{"kind": "tent", "pos": Vector2(-54, 0), "yaw": 90.0, "seed": 8},
	{"kind": "portal", "pos": Vector2(53, 0), "yaw": -90.0, "seed": 7},
	# --- selatan: altar bintang & kolam taman di ujung jalan samping jalan utama
	{"kind": "altar", "pos": Vector2(-31, 38), "yaw": 90.0, "seed": 9},
	{"kind": "pond", "pos": Vector2(31, 38), "yaw": 0.0, "seed": 10},
	# --- rumah di sepanjang jalan utama selatan (menghadap jalan)
	{"kind": "house_d", "pos": Vector2(-17, 24), "yaw": 90.0, "roof": Color(0.64, 0.46, 0.9), "wall": Color(0.98, 0.95, 0.9), "seed": 21},
	{"kind": "house_b", "pos": Vector2(17, 24), "yaw": -90.0, "roof": Color(0.98, 0.64, 0.28), "wall": Color(1.0, 0.92, 0.84), "seed": 22},
	{"kind": "house_a", "pos": Vector2(-17, 51), "yaw": 90.0, "roof": Color(0.92, 0.36, 0.32), "wall": Color(0.96, 0.98, 1.0), "seed": 23},
	{"kind": "house_c", "pos": Vector2(17, 51), "yaw": -90.0, "roof": Color(0.32, 0.55, 0.95), "wall": Color(1.0, 0.94, 0.86), "seed": 24},
	# --- rumah di jalan samping barat (menghadap timur) dan timur (menghadap barat)
	{"kind": "house_a", "pos": Vector2(-51.5, -44), "yaw": 90.0, "roof": Color(0.35, 0.6, 0.45), "wall": Color(1.0, 0.94, 0.84), "seed": 31},
	{"kind": "house_b", "pos": Vector2(-51.5, -31), "yaw": 90.0, "roof": Color(0.35, 0.6, 0.45), "wall": Color(1.0, 0.96, 0.88), "seed": 32},
	{"kind": "house_c", "pos": Vector2(-51.5, -18), "yaw": 90.0, "roof": Color(0.85, 0.45, 0.55), "wall": Color(1.0, 0.96, 0.88), "seed": 33},
	{"kind": "house_a", "pos": Vector2(-51.5, 22), "yaw": 90.0, "roof": Color(0.22, 0.72, 0.7), "wall": Color(1.0, 0.96, 0.88), "seed": 34},
	{"kind": "house_b", "pos": Vector2(-51.5, 36), "yaw": 90.0, "roof": Color(0.98, 0.64, 0.28), "wall": Color(1.0, 0.92, 0.84), "seed": 35},
	{"kind": "house_c", "pos": Vector2(-51.5, 50), "yaw": 90.0, "roof": Color(0.64, 0.46, 0.9), "wall": Color(0.98, 0.95, 0.9), "seed": 36},
	{"kind": "tower", "pos": Vector2(50, -44), "yaw": -90.0, "seed": 6},
	{"kind": "house_b", "pos": Vector2(51.5, -31), "yaw": -90.0, "roof": Color(0.98, 0.64, 0.28), "wall": Color(1.0, 0.96, 0.88), "seed": 41},
	{"kind": "house_a", "pos": Vector2(51.5, -18), "yaw": -90.0, "roof": Color(0.32, 0.55, 0.95), "wall": Color(1.0, 0.95, 0.85), "seed": 42},
	{"kind": "house_a", "pos": Vector2(51.5, 22), "yaw": -90.0, "roof": Color(0.92, 0.36, 0.32), "wall": Color(0.97, 0.97, 1.0), "seed": 43},
	{"kind": "house_c", "pos": Vector2(51.5, 36), "yaw": -90.0, "roof": Color(0.35, 0.6, 0.45), "wall": Color(1.0, 0.96, 0.88), "seed": 44},
	{"kind": "house_b", "pos": Vector2(51.5, 50), "yaw": -90.0, "roof": Color(0.64, 0.46, 0.9), "wall": Color(1.0, 0.96, 0.9), "seed": 45},
]

## Jalan batu: titik kendali (garis lurus), lebar. Urutan penting: indeks 0-5 mendapat lampu jalan.
const ROADS: Array = [
	{"pts": [Vector2(0, 80), Vector2(0, 62), Vector2(0, 40), Vector2(0, 15)], "w": 8.0},        # 0 jalan utama selatan (gerbang -> plaza)
	{"pts": [Vector2(0, -15), Vector2(0, -24), Vector2(0, -33)], "w": 10.0},                      # 1 jalan menuju guild
	{"pts": [Vector2(-15, 0), Vector2(-30, 0), Vector2(-47, 0)], "w": 8.0},                       # 2 bulevar barat (ke kamp party)
	{"pts": [Vector2(15, 0), Vector2(30, 0), Vector2(46, 0)], "w": 8.0},                          # 3 bulevar timur (ke portal)
	{"pts": [Vector2(-40, -48), Vector2(-40, 0), Vector2(-40, 58)], "w": 5.0},                    # 4 jalan samping barat
	{"pts": [Vector2(40, -48), Vector2(40, 0), Vector2(40, 58)], "w": 5.0},                       # 5 jalan samping timur
	{"pts": [Vector2(-5, 38), Vector2(-15, 38), Vector2(-26, 38)], "w": 4.0},                     # 6 lorong ke altar
	{"pts": [Vector2(5, 38), Vector2(15, 38), Vector2(26, 38)], "w": 4.0},                        # 7 lorong ke kolam
	{"pts": [Vector2(-9, -33), Vector2(-14, -33), Vector2(-19, -33)], "w": 4.0},                  # 8 lorong ke bengkel
	{"pts": [Vector2(9, -33), Vector2(14, -33), Vector2(19, -33)], "w": 4.0},                     # 9 lorong ke perpustakaan
]

## Zona sebaran pohon (taman teratur): {"rect": Rect2, "count": n, "blossom": peluang bunga sakura}
const TREE_ZONES: Array = [
	{"rect": Rect2(20, 14, 16, 46), "count": 18, "blossom": 0.35},       # taman timur
	{"rect": Rect2(-36, 14, 16, 46), "count": 14, "blossom": 0.2},       # taman barat
	{"rect": Rect2(-38, -26, 18, 22), "count": 6, "blossom": 0.25},     # blok utara-barat & timur (di sela toko)
	{"rect": Rect2(20, -26, 18, 22), "count": 6, "blossom": 0.25},
	{"rect": Rect2(-38, -50, 10, 12), "count": 6, "blossom": 0.15},
	{"rect": Rect2(30, -52, 8, 10), "count": 5, "blossom": 0.15},
	{"rect": Rect2(57, -50, 6, 108), "count": 12, "blossom": 0.1},       # jajar pohon di sisi tembok
	{"rect": Rect2(-63, -50, 6, 108), "count": 12, "blossom": 0.1},
	{"rect": Rect2(-56, 56, 40, 6), "count": 8, "blossom": 0.1},
	{"rect": Rect2(16, 56, 40, 6), "count": 8, "blossom": 0.1},
]

## Titik tetap NPC (x, z): di depan bangunan masing-masing, menghadap jalan.
const NPC_SPOTS := {
	"guild_master": Vector2(-3.5, -27.5),
	"merchant": Vector2(-27.0, -4.6),
	"potion_seller": Vector2(27.0, -4.6),
	"blacksmith": Vector2(-17.5, -29.5),
	"info": Vector2(17.5, -29.5),
	"party_leader": Vector2(-46.0, 4.0),
	"gate_guard": Vector2(-6.0, 55.0),
	"priestess": Vector2(-27.0, 35.0),
}

## Arah hadap NPC (radian, atan2(dx, dz)): menghadap jalan tempat pemain datang.
const NPC_FACE := {
	"guild_master": 0.0,
	"merchant": 0.0,
	"potion_seller": 0.0,
	"blacksmith": PI / 2.0,
	"info": -PI / 2.0,
	"party_leader": PI / 2.0,
	"gate_guard": PI,
	"priestess": PI / 2.0,
}
