class_name ExploreWorld
extends Node3D
## Objek 3D eksplorasi di lobi: peti harta, batu teleport, dan pemindaian penemuan. Menambahkan dirinya ke daftar interaksi lobi.

var lobby: Node3D
var chest_nodes: Dictionary = {}       # id -> Node3D
var stone_nodes: Dictionary = {}
var _scan_t := 0.0
var _time := 0.0


func setup(l: Node3D) -> void:
	lobby = l
	name = "ExploreWorld"
	for c: Dictionary in Explore.CHESTS:
		var n := _make_chest(c)
		add_child(n)
		chest_nodes[c["id"]] = n
	for w: Dictionary in Explore.WAYPOINTS:
		var n2 := _make_stone(w)
		add_child(n2)
		stone_nodes[w["id"]] = n2
	_refresh_all()
	GameState.changed.connect(func(k: String) -> void:
		if k == "explore":
			_refresh_all())


static func _mat_node(k: MeshKit, nm: String) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = nm
	var m := k.build()
	k.apply_materials(m)
	mi.mesh = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi


func _make_chest(c: Dictionary) -> Node3D:
	var root := build_chest(str(c["tier"]))
	root.name = "Chest_" + str(c["id"])
	root.position = Vector3(c["pos"].x, 0.0, c["pos"].y)
	return root


## Model peti (dipakai lobi dan stage): tubuh + tutup berengsel (LidPivot) + percikan (Spark) + tabrakan.
static func build_chest(tier_id: String) -> Node3D:
	var root := Node3D.new()
	var tier: Dictionary = Explore.TIERS[tier_id]
	var col: Color = tier["col"]
	var body := MeshKit.new(7)
	body.box(Vector3(0, 0.3, 0), Vector3(1.0, 0.6, 0.66), MeshKit.T_WOOD, col.darkened(0.25))
	body.box(Vector3(0, 0.34, 0), Vector3(1.04, 0.1, 0.7), MeshKit.T_METAL, col.lightened(0.15))
	body.box(Vector3(0, 0.1, 0), Vector3(1.04, 0.08, 0.7), MeshKit.T_METAL, col.lightened(0.15))
	for sx in [-0.4, 0.4]:
		body.box(Vector3(sx, 0.3, 0), Vector3(0.1, 0.62, 0.7), MeshKit.T_METAL, col.lightened(0.15))
	body.box(Vector3(0, 0.38, 0.35), Vector3(0.16, 0.2, 0.05), MeshKit.T_METAL, Color(1, 0.86, 0.4))
	root.add_child(_mat_node(body, "Body"))
	var lid_pivot := Node3D.new()
	lid_pivot.name = "LidPivot"
	lid_pivot.position = Vector3(0, 0.6, -0.33)
	var lid := MeshKit.new(8)
	lid.box(Vector3(0, 0.1, 0.33), Vector3(1.0, 0.2, 0.66), MeshKit.T_WOOD, col.darkened(0.1))
	lid.box(Vector3(0, 0.22, 0.33), Vector3(0.94, 0.06, 0.6), MeshKit.T_WOOD, col)
	for sx2 in [-0.4, 0.4]:
		lid.box(Vector3(sx2, 0.12, 0.33), Vector3(0.1, 0.26, 0.7), MeshKit.T_METAL, col.lightened(0.15))
	lid_pivot.add_child(_mat_node(lid, "Lid"))
	root.add_child(lid_pivot)
	# berkas cahaya kecil di atas peti yang belum dibuka
	var glow := MeshKit.new(9)
	glow.blob(Vector3(0, 1.3, 0), 0.14, MeshKit.T_CRYSTAL, MeshKit.glow(Color(1, 0.9, 0.5), 1.0), 4, 6)
	var gm := _mat_node(glow, "Spark")
	root.add_child(gm)
	var body_c := StaticBody3D.new()
	body_c.collision_layer = 1
	body_c.collision_mask = 0
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1.0, 0.7, 0.7)
	cs.shape = bs
	cs.position = Vector3(0, 0.35, 0)
	body_c.add_child(cs)
	root.add_child(body_c)
	return root


func _make_stone(w: Dictionary) -> Node3D:
	var root := Node3D.new()
	root.name = "Stone_" + str(w["id"])
	root.position = Vector3(w["pos"].x, 0.0, w["pos"].y)
	var k := MeshKit.new(11)
	k.cylinder(Vector3(0, 0, 0), 1.1, 1.0, 0.25, 12, MeshKit.T_MARBLE, Color(0.72, 0.76, 0.9))
	k.ring(Vector3(0, 0.27, 0), 0.55, 0.85, 20, MeshKit.T_CRYSTAL, MeshKit.glow(Color(0.5, 0.8, 1.0), 0.9))
	for i in 4:
		var a := i * TAU / 4.0 + PI / 4.0
		k.box(Vector3(cos(a) * 0.9, 0.7, sin(a) * 0.9), Vector3(0.18, 1.0, 0.18), MeshKit.T_MARBLE, Color(0.8, 0.84, 0.95))
	k.spire(Vector3(0, 0.3, 0), 0.22, 1.3, 5, MeshKit.T_CRYSTAL, MeshKit.glow(Color(0.55, 0.85, 1.0), 0.9))
	root.add_child(_mat_node(k, "Stone"))
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var cs := CollisionShape3D.new()
	var cy := CylinderShape3D.new()
	cy.radius = 0.35
	cy.height = 1.4
	cs.shape = cy
	cs.position = Vector3(0, 0.7, 0)
	body.add_child(cs)
	root.add_child(body)
	var lbl := Label3D.new()
	lbl.name = "Name"
	lbl.text = str(w["name"])
	lbl.font_size = 40
	lbl.pixel_size = 0.01
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.no_depth_test = false
	lbl.shaded = false
	lbl.modulate = Color(0.8, 0.93, 1.0)
	lbl.outline_size = 10
	lbl.outline_modulate = Color(0.05, 0.08, 0.2, 0.95)
	lbl.position = Vector3(0, 2.3, 0)
	root.add_child(lbl)
	return root


func _refresh_all() -> void:
	for id in chest_nodes:
		var n: Node3D = chest_nodes[id]
		var op := Explore.is_opened(id)
		(n.get_node("LidPivot") as Node3D).rotation.x = -1.2 if op else 0.0
		(n.get_node("Spark") as Node3D).visible = not op
	for id in stone_nodes:
		var n2: Node3D = stone_nodes[id]
		var lbl := n2.get_node("Name") as Label3D
		lbl.visible = Explore.is_discovered(id)


## Entri interaksi dinamis untuk lobi: peti yang belum dibuka dan batu teleport.
func interactions() -> Array:
	var out: Array = []
	for c: Dictionary in Explore.CHESTS:
		if not Explore.is_opened(c["id"]):
			out.append({"id": "chest:" + c["id"], "pos": Vector3(c["pos"].x, 0, c["pos"].y), "action": "chest:" + c["id"], "prompt": "Buka %s" % c["name"], "radius": 2.0})
	for w: Dictionary in Explore.WAYPOINTS:
		out.append({"id": "wp:" + w["id"], "pos": Vector3(w["pos"].x, 0, w["pos"].y), "action": "map", "prompt": "Peta & Teleport", "radius": 2.6})
	return out


func _process(delta: float) -> void:
	_time += delta
	for id in chest_nodes:
		var sp := (chest_nodes[id] as Node3D).get_node("Spark") as Node3D
		if sp.visible:
			sp.position.y = sin(_time * 2.0 + float(str(id).hash() % 10)) * 0.08
	_scan_t -= delta
	if _scan_t <= 0.0 and lobby != null and lobby.get("player") != null:
		_scan_t = 0.25
		var pp: Vector3 = lobby.player.global_position
		for m in Explore.scan(Vector2(pp.x, pp.z)):
			Flow.toast(m, 3.0)
			Sfx.play("pickup")
