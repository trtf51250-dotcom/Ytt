class_name Villager
extends CharacterBody3D
## Penduduk hiasan: berjalan mengitari alun-alun (jalur melingkar di sekeliling air mancur) dengan animasi jalan, sesekali berhenti.
## Tidak bisa diajak bicara. Punya kapsul tabrakan agar pemain tidak menembusnya.

var rig: CharacterRig
var ring := 10.0
var dir_sign := 1
var angle := 0.0
var speed := 1.3
var _pause := 0.0
var _next_pause := 6.0


func setup(def: Dictionary) -> void:
	name = "Villager"
	collision_layer = 4
	collision_mask = 0
	ring = def["ring"]
	dir_sign = def["dir"]
	angle = def["phase"]
	speed = def["speed"]
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.42
	cap.height = 1.7
	cs.shape = cap
	cs.position = Vector3(0, 0.85, 0)
	add_child(cs)
	rig = CharacterRig.new()
	add_child(rig)
	Quality.blob(self, 0.6, 0.0)
	var skin: Texture2D = load("res://assets/hero/%s.png" % def["skin"])
	rig.setup(float(def["height"]), skin, false, false)
	rig.play_loop("walk_n", 0.0, 1.0)
	_place()


func _place() -> void:
	position = Vector3(cos(angle) * ring, 0.04, sin(angle) * ring)
	var tangent := Vector3(-sin(angle), 0, cos(angle)) * dir_sign
	rig.rotation.y = atan2(tangent.x, tangent.z)


var _cull_t := 0.0


func _physics_process(delta: float) -> void:
	_cull_t -= delta
	if _cull_t <= 0.0:
		_cull_t = 0.4
		var cam := get_viewport().get_camera_3d()
		if cam != null and Quality.level() == 0:
			rig.visible = cam.global_position.distance_to(global_position) < 42.0
	if _pause > 0.0:
		_pause -= delta
		rig.play_loop("idle_n", 0.25, 1.0)
		return
	_next_pause -= delta
	if _next_pause <= 0.0:
		_pause = randf_range(2.0, 4.5)
		_next_pause = randf_range(8.0, 16.0)
		return
	rig.play_loop("walk_n", 0.25, speed / 1.3)
	angle += dir_sign * speed / ring * delta
	var tangent := Vector3(-sin(angle), 0, cos(angle)) * dir_sign
	position = Vector3(cos(angle) * ring, 0.04, sin(angle) * ring)
	rig.rotation.y = lerp_angle(rig.rotation.y, atan2(tangent.x, tangent.z), 1.0 - exp(-8.0 * delta))
