class_name Npc
extends CharacterBody3D
## NPC lobi: model rig + aksesori, animasi idle (AnimationPlayer), nama melayang, penanda "!" / "?", menghadap pemain saat dekat.
## Memiliki kapsul tabrakan (layer 3) sehingga pemain tidak menembus.

var npc_id := ""
var display_name := ""
var title := ""
var rig: CharacterRig
var label: Label3D
var marker: Label3D
var talk_radius := 2.9
var _face_target := 0.0
var _base_yaw := 0.0
var _idle := "idle_n"
var _marker_t := 0.0
var look_at_node: Node3D


func setup(id: String) -> void:
	npc_id = id
	var d: Dictionary = NpcDefs.DEFS[id]
	display_name = d["name"]
	title = d["title"]
	name = "Npc_" + id
	collision_layer = 4
	collision_mask = 0
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.45
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0, 0.9, 0)
	add_child(cs)
	Quality.blob(self, 0.65)
	rig = CharacterRig.new()
	rig.name = "Rig"
	add_child(rig)
	var skin: Texture2D = load("res://assets/hero/%s.png" % d["skin"])
	rig.setup(float(d["height"]), skin, false, false)
	CharacterLooks.apply_npc(rig, d["look"])
	_idle = d["idle"]
	rig.play_loop(_idle, 0.0, 1.0)
	var h := float(d["height"])
	label = Label3D.new()
	label.text = "%s\n%s" % [display_name, title]
	label.font_size = 40
	label.outline_size = 14
	label.pixel_size = 0.0045
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.fixed_size = false
	label.modulate = Color(1, 0.96, 0.85)
	label.outline_modulate = Color(0.05, 0.08, 0.2, 0.95)
	label.position = Vector3(0, h + 0.55, 0)
	label.visibility_range_end = 18.0
	label.render_priority = 5
	add_child(label)
	marker = Label3D.new()
	marker.text = ""
	marker.font_size = 90
	marker.outline_size = 18
	marker.pixel_size = 0.006
	marker.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	marker.no_depth_test = true
	marker.modulate = Color(1, 0.85, 0.2)
	marker.outline_modulate = Color(0.2, 0.1, 0.0, 1)
	marker.position = Vector3(0, h + 1.35, 0)
	marker.visibility_range_end = 24.0
	marker.render_priority = 6
	marker.visible = false
	add_child(marker)


func face_yaw(yaw: float) -> void:
	_base_yaw = yaw
	_face_target = yaw
	if rig:
		rig.rotation.y = yaw


func set_marker(text: String) -> void:
	marker.visible = text != ""
	marker.text = text


var _cull_t := 0.0


## Hemat perangkat ringan: NPC yang jauh dari kamera disembunyikan dan animasinya dihentikan.
func _cull_far(delta: float) -> void:
	_cull_t -= delta
	if _cull_t > 0.0:
		return
	_cull_t = 0.4
	var cam := get_viewport().get_camera_3d()
	if cam == null:
		return
	var far := Quality.level() == 0
	var d := cam.global_position.distance_to(global_position)
	var show := (not far) or d < 42.0
	if rig.visible != show:
		rig.visible = show
		rig.process_mode = Node.PROCESS_MODE_INHERIT if show else Node.PROCESS_MODE_DISABLED


func _process(delta: float) -> void:
	_cull_far(delta)
	_marker_t += delta
	if marker.visible:
		marker.position.y = rig.height + 1.3 + sin(_marker_t * 3.0) * 0.08
	if look_at_node != null and is_instance_valid(look_at_node):
		var d := look_at_node.global_position - global_position
		d.y = 0
		_face_target = atan2(d.x, d.z) if d.length() > 0.1 else _base_yaw
	else:
		_face_target = _base_yaw
	rig.rotation.y = lerp_angle(rig.rotation.y, _face_target, 1.0 - exp(-6.0 * delta))
