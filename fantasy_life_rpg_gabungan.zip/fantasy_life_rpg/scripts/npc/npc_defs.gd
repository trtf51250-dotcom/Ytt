class_name NpcDefs
extends RefCounted
## Data NPC + dialog. Dialog = Dictionary simpul:
##   { "start": {"lines": ["...", "..."], "choices": [ {"text": "...", "action": "shop:weapon"}, {"text": "...", "goto": "simpul_lain"} ]}, "simpul_lain": {...} }
## Aksi yang dikenali Lobby: close, quests, adventure, party, gacha, smith, shop:weapon, shop:item, shop:sell, character, equipment.
## Menambah NPC baru = tambah satu entri di DEFS (+ tempat di LobbyLayout.NPC_SPOTS) dan satu cabang di dialogue().

const DEFS := {
	"guild_master": {"name": "Orwen", "title": "Master Serikat Bintang Fajar", "skin": "skin_orwen", "look": "guild_master", "height": 1.86, "idle": "idle_cross"},
	"merchant": {"name": "Rowan", "title": "Pedagang Senjata", "skin": "skin_rowan", "look": "merchant", "height": 1.72, "idle": "idle_gesture"},
	"potion_seller": {"name": "Mira", "title": "Peracik Ramuan", "skin": "skin_mira", "look": "potion_seller", "height": 1.62, "idle": "idle_stir"},
	"blacksmith": {"name": "Tobias", "title": "Pandai Besi", "skin": "skin_tobias", "look": "blacksmith", "height": 1.9, "idle": "idle_hammer"},
	"info": {"name": "Selin", "title": "Pemandu Kota", "skin": "skin_selin", "look": "info", "height": 1.66, "idle": "idle_gesture"},
	"party_leader": {"name": "Kael", "title": "Pemimpin Regu", "skin": "skin_kael", "look": "party_leader", "height": 1.8, "idle": "idle_wave"},
	"gate_guard": {"name": "Elio", "title": "Penjaga Gerbang", "skin": "skin_elio", "look": "gate_guard", "height": 1.95, "idle": "idle_attention"},
	"priestess": {"name": "Pip", "title": "Penjaga Altar Bintang", "skin": "skin_pip", "look": "priestess", "height": 1.55, "idle": "idle_n"},
}

## Penduduk yang berjalan-jalan (hanya hiasan, tidak bisa diajak bicara).
const VILLAGERS := [
	{"skin": "skin_town1", "height": 1.7, "ring": 9.5, "dir": 1, "phase": 0.0, "speed": 1.35},
	{"skin": "skin_town2", "height": 1.62, "ring": 11.5, "dir": -1, "phase": 2.0, "speed": 1.2},
	{"skin": "skin_town1", "height": 1.55, "ring": 10.5, "dir": 1, "phase": 4.1, "speed": 1.5},
	{"skin": "skin_town2", "height": 1.78, "ring": 12.0, "dir": -1, "phase": 5.3, "speed": 1.25},
]


static func ids() -> Array:
	return DEFS.keys()


static func display_name(id: String) -> String:
	return str(DEFS.get(id, {}).get("name", id))


static func _c(text: String, action: String = "", goto: String = "") -> Dictionary:
	var d := {"text": text}
	if action != "":
		d["action"] = action
	if goto != "":
		d["goto"] = goto
	return d


static func dialogue(id: String) -> Dictionary:
	var bye := _c("Sampai nanti.", "close")
	match id:
		"guild_master":
			var lines: Array = []
			if GameState.quest_state("q_welcome") != "claimed":
				lines = ["Ah, pendatang baru! Aku Orwen, Master Serikat Bintang Fajar.",
					"Aurelia adalah kota perbatasan. Di luar gerbang selatan, padang rumput dan hutan dipenuhi monster, dan serikat kami menjaga warga dari mereka.",
					"Namamu sudah tercatat di buku anggota. Buka menu Quest untuk mengambil hadiah sambutan, lalu cobalah petualangan pertamamu."]
			elif GameState.ready_quest_count() > 0:
				lines = ["Ada quest yang sudah kau selesaikan. Buka menu Quest dan klaim hadiahnya, itu hakmu."]
			else:
				lines = ["Kerja bagus, petualang. Papan quest di sebelahku selalu terbuka; stage berikutnya menunggu di balik gerbang selatan."]
			return {"start": {"lines": lines, "choices": [
				_c("Lihat daftar Quest", "quests"), _c("Mulai Petualangan", "adventure"), bye]}}
		"merchant":
			return {"start": {"lines": ["Selamat datang di Toko Senjata Aurelia! Besi terbaik, harga jujur, dan tidak ada yang kuberi gratis."],
				"choices": [_c("Beli senjata & armor", "shop:weapon"), _c("Jual barang", "shop:sell"), bye]}}
		"potion_seller":
			return {"start": {"lines": ["Ramuanku diseduh dari embun fajar dan daun yang dipetik sebelum matahari terbit. Rasanya... yah, sembuh itu lebih penting dari rasa."],
				"choices": [_c("Beli ramuan", "shop:item"), _c("Jual barang", "shop:sell"), bye]}}
		"blacksmith":
			return {"start": {"lines": ["Senjata bagus bukan hanya soal baja, tapi sabar dan palu. Bawa senjata yang sedang kau pakai, akan kutempa sampai +10.",
				"Biayanya naik tiap tingkat, tapi setiap tempaan menambah ATK senjatamu."],
				"choices": [_c("Tempa senjata", "smith"), bye]}}
		"info":
			return {
				"start": {"lines": ["Halo! Aku Selin, pemandu kota. Mau tahu apa?"], "choices": [
					_c("Cara bermain", "", "how"), _c("Kontrol", "", "controls"), _c("Tentang Aurelia", "", "lore"), bye]},
				"how": {"lines": ["Pilih Start Adventure atau lewati gerbang selatan untuk memilih stage. Bersihkan semua gelombang monster, kalahkan bos, lalu kembali ke lobi.",
					"Hadiah gold, EXP, dan diamond dipakai di toko, Blacksmith, dan Altar Bintang. Atur party empat orang di menu Party atau lewat Kael."],
					"choices": [_c("Kembali", "", "start"), bye]},
				"controls": {"lines": ["Joystick kiri untuk bergerak. Tombol kanan: Serang, Skill, Hindar, dan Interaksi (menyala bila ada NPC atau objek di dekatmu).",
					"Seret layar di area kosong untuk memutar kamera, cubit dua jari untuk zoom. Di komputer: WASD, J/Spasi serang, K skill, L/Shift hindar, E interaksi, Q/R putar kamera."],
					"choices": [_c("Kembali", "", "start"), bye]},
				"lore": {"lines": ["Aurelia dibangun di lereng bukit tempat cahaya fajar pertama jatuh. Air mancur di alun-alun katanya tak pernah kering sejak hari kota ini didirikan.",
					"Portal di timur membawa para petualang ke tempat yang jauh. Cerita lengkapnya? Itu tugasmu menulisnya."],
					"choices": [_c("Kembali", "", "start"), bye]},
			}
		"party_leader":
			return {"start": {"lines": ["Petualang sejati tak pernah sendirian. Empat orang dalam satu regu, dan kau bisa berganti pemimpin kapan saja.",
				"Di stage nanti, ketuk portret rekanmu untuk bertukar karakter di tengah pertempuran."],
				"choices": [_c("Atur Party", "party"), _c("Lihat Karakter", "character"), _c("Mulai Petualangan", "adventure"), bye]}}
		"gate_guard":
			return {"start": {"lines": ["Berhenti, petualang! ... Oh, kau anggota serikat. Silakan lewat.",
				"Di luar sana padang Fajar, hutan Remang, dan gua-gua tua. Bawa ramuan, dan jangan sok jagoan."],
				"choices": [_c("Keluar gerbang (pilih stage)", "adventure"), bye]}}
		"priestess":
			return {"start": {"lines": ["Altar Bintang menjawab mereka yang berani memanggil. Perlengkapan, ramuan, atau pecahan jiwa sahabatmu. Tak ada yang tahu apa yang akan turun.",
				"Peluang ditampilkan jujur di dalam altar, dan setiap lima puluh kali tanpa bintang lima, altar pasti memberi satu."],
				"choices": [_c("Panggil di Altar", "gacha"), bye]}}
	return {"start": {"lines": ["..."], "choices": [bye]}}
