extends BasePanel
## Panduan singkat: kontrol, tips, dan cara mendapat karakter/item.

func build() -> void:
	var sl := scroll_list()
	var scroll: ScrollContainer = sl[0]
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(scroll)
	var mc := MarginContainer.new()
	mc.add_theme_constant_override("margin_right", 22)
	mc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sl[1].add_child(mc)
	var body := vbox(8)
	mc.add_child(body)
	for sec in [
		["Kontrol", "Joystick kiri untuk bergerak. Kanan: tombol pedang = serangan, petir = skill, panah ganda = menghindar (kebal sesaat), kursor = interaksi dengan NPC/bangunan. Layar bisa diseret untuk memutar kamera."],
		["Memulai petualangan", "Tekan Start Adventure atau masuk lewat Portal, pilih stage, atur party (maksimal 4 karakter). Karakter pemimpin yang kamu kendalikan; ganti karakter saat bertarung lewat ikon party."],
		["Mendapat karakter", "Selesaikan quest dan event, ambil Hadiah Login, atau lakukan Panggilan Jiwa di Altar Bintang. Pecahan jiwa dari karakter ganda menaikkan bintang (+12% statistik)."],
		["Memperkuat", "Ganti Equipment, tempa senjata di Pandai Besi, dan naikkan level lewat stage. Perhatikan jeda skill dan jangkauan di panel Karakter."],
		["Tips performa", "Pengaturan → Grafis: Sedang adalah bawaan. Bila masih berat pilih Lancar; bila HP kuat pilih Bagus. Resolusi dinamis menurunkan resolusi otomatis saat FPS jatuh."],
		["Data & ID", "Game ini offline. Simpan ada satu dan terikat ke perangkat. Kode ekspor hanya untuk pindah perangkat, tidak untuk dibagikan."],
	]:
		var c := card()
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var v := vbox(4)
		c.add_child(v)
		v.add_child(lbl(sec[0], 24, UiTheme.GOLD))
		v.add_child(wrap_lbl(sec[1], 18, UiTheme.TEXT))
		body.add_child(c)
