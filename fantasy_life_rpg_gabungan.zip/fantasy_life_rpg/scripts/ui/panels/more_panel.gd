extends BasePanel
## Menu utama: laci yang meluncur masuk dari sisi kanan. Gaya terang bersih dengan kartu miring (jajar genjang) bergradasi putih-biru,
## dua kartu besar di atas (Hadiah Login, Misi & Pencapaian) dan tiga kartu lebih kecil (Event, Cerita, Profil & ID).
## Tiap kartu menampilkan lencana "!" / angka bila ada yang siap diambil. Ketuk area gelap di kiri / tombol panah = tutup (meluncur keluar).
## Semua desain orisinal (digambar lewat kode); hanya tata letak "kartu miring pilih mode" yang terinspirasi game bergenre sama.

const INK := UiTheme.TEXT                    # warna tema sama dengan panel lain (biru malam + emas)
const INK_DIM := UiTheme.TEXT_DIM
const SKEW := 0.22                          # kemiringan kartu (px geser per px tinggi)
const OPEN_T := 0.3
const CLOSE_T := 0.2

var _dim: ColorRect
var _drawer: Control
var _top_row: HBoxContainer
var _bottom_row: HBoxContainer
var _third_row: HBoxContainer
var _core_row: HBoxContainer
var _closing := false
var _first := true


func _init() -> void:
	refresh_on = ["login", "daily", "events", "profile", "roster", "currency", "story"]


## Kartu miring yang bisa diketuk (sinyal `pressed`).
class SlantTile extends Control:
	const SKEW := 0.22
	signal pressed
	var accent := Color(0.4, 0.6, 1.0)
	var enabled := true
	var highlight := false              # ada hadiah/lencana: bingkai emas terang
	var _down := false
	var _skew_px := 0.0

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP
		resized.connect(func():
			pivot_offset = size * 0.5
			queue_redraw())

	func _draw() -> void:
		var w := size.x
		var h := size.y
		var s := h * SKEW
		var top := Color(0.24, 0.31, 0.58) if enabled else Color(0.16, 0.2, 0.36)
		var bot := Color(0.11, 0.15, 0.34) if enabled else Color(0.1, 0.13, 0.25)
		var pts := PackedVector2Array([Vector2(s, 0), Vector2(w, 0), Vector2(w - s, h), Vector2(0, h)])
		# bayangan lembut
		var sh := PackedVector2Array([Vector2(s + 4, 5), Vector2(w + 4, 5), Vector2(w - s + 4, h + 5), Vector2(4, h + 5)])
		draw_colored_polygon(sh, Color(0, 0, 0.05, 0.35))
		draw_polygon(pts, PackedColorArray([top, top.lerp(bot, 0.2), bot, bot.lerp(top, 0.2)]))
		# garis aksen tebal di sisi bawah
		var ac := accent if enabled else Color(0.45, 0.5, 0.62)
		draw_polygon(PackedVector2Array([Vector2(0, h), Vector2(w - s, h), Vector2(w - s - 6, h - 9), Vector2(5, h - 9)]), PackedColorArray([ac, ac, ac, ac]))
		draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), UiTheme.GOLD if (enabled and highlight) else (UiTheme.GOLD_DARK if enabled else Color(0.4, 0.45, 0.6)), 2.5, true)
		# coretan diagonal tipis sebagai tekstur
		for i in 3:
			var x := w * (0.52 + 0.1 * i)
			draw_line(Vector2(x + s * 0.5, 4), Vector2(x - s * 0.5, h - 12), Color(0.62, 0.75, 1.0, 0.10), 3.0)
		if _down:
			draw_colored_polygon(pts, Color(1, 1, 1, 0.12))

	func _gui_input(ev: InputEvent) -> void:
		if not enabled:
			return
		if ev is InputEventMouseButton and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
			var mb := ev as InputEventMouseButton
			if mb.pressed:
				_down = true
				scale = Vector2(0.97, 0.97)
				queue_redraw()
			else:
				var was := _down
				_down = false
				scale = Vector2.ONE
				queue_redraw()
				if was and Rect2(Vector2.ZERO, size).has_point(mb.position):
					Sfx.play("select")
					pressed.emit()


## Tombol bulat dengan panah kembali (chevron) di kiri atas.
class BackButton extends Control:
	signal pressed

	func _ready() -> void:
		custom_minimum_size = Vector2(58, 58)
		mouse_filter = Control.MOUSE_FILTER_STOP

	func _draw() -> void:
		var c := size * 0.5
		draw_circle(c + Vector2(0, 3), 27.0, Color(0, 0, 0.05, 0.4))
		draw_circle(c, 27.0, Color(0.16, 0.21, 0.42))
		draw_arc(c, 27.0, 0.0, TAU, 32, UiTheme.GOLD, 3.0, true)
		draw_polyline(PackedVector2Array([c + Vector2(6, -13), c + Vector2(-7, 0), c + Vector2(6, 13)]), UiTheme.GOLD, 5.0, true)

	func _gui_input(ev: InputEvent) -> void:
		if ev is InputEventMouseButton and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT and not (ev as InputEventMouseButton).pressed:
			Sfx.play("select")
			pressed.emit()


## Garis-garis miring dekoratif di latar laci.
class Deco extends Control:
	func _draw() -> void:
		var h := size.y
		for i in 7:
			var x := size.x * (0.1 + 0.16 * i)
			var pts := PackedVector2Array([Vector2(x, 0), Vector2(x + 46, 0), Vector2(x + 46 - h * 0.22, h), Vector2(x - h * 0.22, h)])
			draw_colored_polygon(pts, Color(0.5, 0.65, 1.0, 0.07 if i % 2 == 0 else 0.04))
		draw_rect(Rect2(0, 0, size.x, 8), UiTheme.GOLD_DARK)


func _ready() -> void:
	theme = UiTheme.get_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	_dim = ColorRect.new()
	_dim.color = Color(0.02, 0.03, 0.1, 0.0)
	_dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_dim.mouse_filter = Control.MOUSE_FILTER_STOP
	_dim.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed:
			_close_anim())
	add_child(_dim)
	# laci di kanan (66% lebar), tepi kirinya miring
	_drawer = Control.new()
	_drawer.set_anchors_preset(Control.PRESET_FULL_RECT)
	_drawer.anchor_left = 0.34
	_drawer.offset_left = 0
	_drawer.offset_right = 0
	_drawer.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_drawer)
	var bg := Panel.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.add_theme_stylebox_override("panel", UiTheme.box(UiTheme.PANEL, UiTheme.GOLD_DARK, 3, 0, 0))
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_drawer.add_child(bg)
	var deco := Deco.new()
	deco.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	deco.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_drawer.add_child(deco)
	var v := VBoxContainer.new()
	v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	v.offset_left = 30
	v.offset_right = -30
	v.offset_top = 26
	v.offset_bottom = -26
	v.add_theme_constant_override("separation", 14)
	_drawer.add_child(v)
	# kepala: panah kembali + judul + gerigi pengaturan
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 14)
	v.add_child(head)
	var back := BackButton.new()
	back.pressed.connect(_close_anim)
	head.add_child(back)
	var tcol := VBoxContainer.new()
	tcol.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tcol.add_theme_constant_override("separation", -2)
	var t := UiTheme.label("Menu", 34, UiTheme.GOLD)
	t.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	tcol.add_child(t)
	var st := UiTheme.label("Pilih menu yang ingin dibuka", 16, INK_DIM)
	tcol.add_child(st)
	head.add_child(tcol)
	var gear := Button.new()
	gear.custom_minimum_size = Vector2(58, 58)
	gear.focus_mode = Control.FOCUS_NONE
	gear.add_theme_stylebox_override("normal", UiTheme.box(UiTheme.PANEL_LIGHT, UiTheme.GOLD_DARK, 2, 29, 4))
	gear.add_theme_stylebox_override("hover", UiTheme.box(Color(0.22, 0.29, 0.54), UiTheme.GOLD, 2, 29, 4))
	gear.add_theme_stylebox_override("pressed", UiTheme.box(Color(0.08, 0.1, 0.24), UiTheme.GOLD, 3, 29, 4))
	var gc := CenterContainer.new()
	gc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	gc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	gc.add_child(UiIcon.make("settings", UiTheme.GOLD, 32))
	gear.add_child(gc)
	gear.pressed.connect(func():
		Sfx.play("select")
		host.open("settings", {"return_to": "more"}))
	head.add_child(gear)
	var sep := ColorRect.new()                # garis emas pemisah kepala
	sep.color = Color(UiTheme.GOLD_DARK, 0.7)
	sep.custom_minimum_size = Vector2(0, 2)
	v.add_child(sep)
	var rows := VBoxContainer.new()
	rows.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rows.add_theme_constant_override("separation", 12)
	v.add_child(rows)
	_top_row = HBoxContainer.new()
	_top_row.add_theme_constant_override("separation", 14)
	_top_row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_top_row.size_flags_stretch_ratio = 1.15
	rows.add_child(_top_row)
	_bottom_row = HBoxContainer.new()
	_bottom_row.add_theme_constant_override("separation", 14)
	_bottom_row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rows.add_child(_bottom_row)
	_core_row = HBoxContainer.new()
	_core_row.add_theme_constant_override("separation", 14)
	_core_row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rows.add_child(_core_row)
	rows.move_child(_core_row, 1)                 # tepat di bawah dua kartu besar
	_third_row = HBoxContainer.new()
	_third_row.add_theme_constant_override("separation", 14)
	_third_row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rows.add_child(_third_row)
	var foot := UiTheme.label("Ketuk area gelap untuk menutup", 15, Color(UiTheme.TEXT_DIM, 0.7), HORIZONTAL_ALIGNMENT_CENTER)
	v.add_child(foot)
	_built = true
	GameState.changed.connect(_on_state_changed)
	refresh()
	# animasi masuk: gelap memudar + laci meluncur dari kanan
	var w := get_viewport_rect().size.x * 0.66
	_drawer.offset_left = w
	_drawer.offset_right = w
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(_dim, "color:a", 0.62, OPEN_T)
	tw.tween_property(_drawer, "offset_left", 0.0, OPEN_T).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(_drawer, "offset_right", 0.0, OPEN_T).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


static func _flat(l: Label) -> Label:
	return l


func _close_anim() -> void:
	if _closing:
		return
	_closing = true
	var w := get_viewport_rect().size.x * 0.66
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(_dim, "color:a", 0.0, CLOSE_T)
	tw.tween_property(_drawer, "offset_left", w, CLOSE_T).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
	tw.tween_property(_drawer, "offset_right", w, CLOSE_T).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
	tw.chain().tween_callback(func(): close_requested.emit())


func refresh() -> void:
	clear(_top_row)
	clear(_bottom_row)
	clear(_third_row)
	clear(_core_row)
	var login_left := GameState.LOGIN_DAYS - GameState.login_days
	var login_sub := "Semua hadiah sudah diambil" if login_left <= 0 else ("Hadiah hari ini siap diambil!" if GameState.login_claimable() else "Kembali besok untuk hadiah berikutnya")
	_top_row.add_child(_tile("login", "gift", "Hadiah Login", login_sub, 1 if GameState.login_claimable() else 0, login_left > 0, Color(1.0, 0.72, 0.2), 270))
	var d := GameState.daily_ready_count() + GameState.ach_ready_count()
	_top_row.add_child(_tile("daily", "flag", "Misi & Pencapaian", "%d hadiah siap diambil" % d if d > 0 else "Misi harian & 12 pencapaian", d, true, Color(0.3, 0.6, 1.0), 270))
	var ev := LiveEvents.active().size()
	_bottom_row.add_child(_tile("event", "star", "Event", "%d berlangsung" % ev if ev > 0 else "Belum ada", GameState.unseen_event_count(), true, Color(1.0, 0.5, 0.3), 200))
	var seen := 0
	for sc in Story.scenes():
		if Story.seen(sc["id"]):
			seen += 1
	_bottom_row.add_child(_tile("story", "quest", "Cerita", "%d / %d adegan" % [seen, Story.scenes().size()], 0, true, Color(0.66, 0.5, 1.0), 200))
	_bottom_row.add_child(_tile("profile", "character", "Profil & ID", GameState.player_id, 0, true, Color(0.25, 0.78, 0.72), 200))
	var coll := 0
	for cid in Data.character_ids():
		if GameState.is_unlocked(cid):
			coll += 1
	_third_row.add_child(_tile("collection", "inventory", "Koleksi", "%d karakter dimiliki" % coll, 0, true, Color(0.95, 0.6, 0.85), 150))
	_third_row.add_child(_tile("stats", "flag", "Statistik", "Main %s · %d musuh" % [GameState.time_string(), GameState.stats["kills"]], 0, true, Color(0.45, 0.85, 0.5), 150))
	_third_row.add_child(_tile("guide", "quest", "Panduan", "Kontrol, tips & cara main", 0, true, Color(0.5, 0.8, 1.0), 150))
	_third_row.add_child(_tile("multiplayer", "party", "Multiplayer", ("Room: %s" % Net.room_name) if Net.mode != "none" else "Duel PVP 1v1 & co-op", 0, true, Color(0.35, 0.85, 1.0), 150))
	for t in [["character", "character", "Karakter", Color(0.45, 0.7, 1.0)], ["party", "party", "Party", Color(0.4, 0.85, 0.6)], ["inventory", "inventory", "Inventori", Color(1.0, 0.75, 0.35)],
			["equipment", "equipment", "Equipment", Color(0.9, 0.5, 0.45)], ["map", "flag", "Peta", Color(0.5, 0.9, 1.0)]]:
		_core_row.add_child(_tile(t[0], t[1], t[2], "", 0, true, t[3], 150))
	# kartu muncul bertahap
	var i := 0
	for row: HBoxContainer in [_top_row, _core_row, _bottom_row, _third_row]:
		for tile: Control in row.get_children():
			if _first:
				tile.modulate.a = 0.0
				var tw := tile.create_tween()
				tw.tween_property(tile, "modulate:a", 1.0, 0.25).set_delay(0.12 + 0.06 * i)
			i += 1
	_first = false


func _tile(id: String, icon: String, title: String, sub: String, badge: int, enabled: bool, accent: Color, height: float) -> Control:
	var tile := SlantTile.new()
	tile.accent = accent
	tile.enabled = enabled
	tile.highlight = badge > 0
	tile.custom_minimum_size = Vector2(0, height * 0.45)
	tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tile.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var skew := height * SKEW
	# ikon besar pudar di kanan
	var isz := int(minf(height * 0.34, 64.0))
	var ic := UiIcon.make(icon, UiTheme.GOLD if enabled else UiTheme.TEXT_DIM, isz)
	ic.anchor_left = 1.0
	ic.anchor_right = 1.0
	ic.anchor_top = 1.0
	ic.anchor_bottom = 1.0
	ic.offset_left = -(isz + skew * 0.7 + 16)
	ic.offset_right = -(skew * 0.7 + 16)
	ic.offset_top = -(isz + 18)
	ic.offset_bottom = -18
	ic.modulate = Color(1, 1, 1, 0.32)
	ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tile.add_child(ic)
	var col := VBoxContainer.new()
	col.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	col.offset_left = skew + 18
	col.offset_right = -(skew + isz + 26)
	col.offset_top = height * 0.16
	col.offset_bottom = -16
	col.alignment = BoxContainer.ALIGNMENT_BEGIN
	col.add_theme_constant_override("separation", 4)
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var t := _flat(lbl(title, 28 if height > 240 else 23, INK if enabled else INK_DIM))
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(t)
	var sl := _flat(wrap_lbl(sub, 16, INK_DIM))
	sl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(sl)
	tile.add_child(col)
	if badge > 0:
		var bd := Label.new()
		bd.text = "!" if badge == 1 else str(badge)
		bd.add_theme_font_size_override("font_size", 18)
		bd.add_theme_color_override("font_color", Color(1, 1, 1))
		bd.add_theme_stylebox_override("normal", UiTheme.box(Color(0.92, 0.22, 0.3), Color(1, 1, 1), 2, 14, 5))
		bd.set_anchors_preset(Control.PRESET_TOP_RIGHT)
		bd.position = Vector2(-44, 4)
		bd.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tile.add_child(bd)
	tile.pressed.connect(func(): host.open(id))
	return tile
