extends BasePanel
## Hadiah login 3 hari. Ambil satu hadiah per hari kalender (tidak harus berturut-turut). Hari ke-3: karakter Zeya.

var _cards: HBoxContainer
var _foot: VBoxContainer


func _init() -> void:
	refresh_on = ["login", "roster"]


func build() -> void:
	content.add_child(wrap_lbl("Datanglah tiga hari (boleh tidak berturut-turut), ambil satu hadiah tiap hari. Hadiah hari ke-3: karakter baru Zeya!", 20, UiTheme.TEXT_DIM))
	_cards = hbox(14)
	_cards.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(_cards)
	_foot = vbox(8)
	content.add_child(_foot)


func refresh() -> void:
	clear(_cards)
	clear(_foot)
	for i in GameState.LOGIN_DAYS:
		_cards.add_child(_day_card(i))
	if GameState.login_days >= GameState.LOGIN_DAYS:
		_foot.add_child(lbl("Semua hadiah sudah diambil. Zeya kini bagian dari party-mu!", 22, UiTheme.GOLD))
	elif GameState.login_claimable():
		var day := GameState.login_days + 1
		var b := btn("Ambil Hadiah Hari ke-%d" % day, _claim, Vector2(380, 60), UiTheme.GOLD)
		b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		_foot.add_child(b)
	else:
		_foot.add_child(lbl("Hadiah hari ini sudah diambil. Kembali besok untuk hari ke-%d." % (GameState.login_days + 1), 22, UiTheme.SKY))


func _day_card(i: int) -> Control:
	var rw: Dictionary = GameState.LOGIN_REWARDS[i]
	var taken := i < GameState.login_days
	var current := i == GameState.login_days
	var border := UiTheme.GOLD if (current and GameState.login_claimable()) else (Color(0.4, 0.75, 0.5) if taken else UiTheme.GOLD_DARK)
	var c := card(border, Color(0.13, 0.2, 0.3) if taken else Color(0.13, 0.17, 0.36))
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var v := vbox(8)
	c.add_child(v)
	var h := lbl("Hari %d" % (i + 1), 26, UiTheme.GOLD)
	h.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(h)
	if rw.has("character"):
		var cd := Data.character(str(rw["character"]))
		var n := lbl(cd.display_name, 30, cd.accent.lightened(0.3))
		n.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(n)
		var t := lbl("%s · %s" % [cd.title, cd.role], 18, UiTheme.SKY)
		t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(t)
		v.add_child(wrap_lbl("HP %d · ATK %d · DEF %d · Kecepatan %.1f\nSkill: %s" % [cd.base_hp, cd.base_atk, cd.base_def, cd.move_speed, cd.skill_name], 17, UiTheme.TEXT))
		var d := wrap_lbl("+ 300 Berlian", 18, UiTheme.GOLD)
		v.add_child(d)
	else:
		var ic := UiIcon.make("gift", UiTheme.GOLD, 56)
		ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		v.add_child(ic)
		var t2 := wrap_lbl(str(rw["label"]), 20, UiTheme.TEXT)
		t2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(t2)
	var sp := Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(sp)
	var st := lbl("Sudah diambil" if taken else ("Siap diambil" if (current and GameState.login_claimable()) else ("Besok" if current else "Menunggu")), 20,
		Color(0.5, 0.9, 0.6) if taken else UiTheme.TEXT_DIM)
	st.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(st)
	return c


func _claim() -> void:
	var r := GameState.claim_login()
	if r.is_empty():
		return
	Sfx.play("chest" if r["new_character"] else "pickup")
	if r["new_character"]:
		toast("Zeya bergabung dengan party!")
	else:
		toast("Hadiah hari ke-%d diterima: %s" % [r["day"], str(r["reward"]["label"])])
