class_name Explore
extends RefCounted
## Sistem eksplorasi lobi Aurelia: peti harta, area rahasia, titik teleport. Data statis + penyimpanan di GameState.flags["explore"].
## Koordinat Vector2 = (x, z) dunia. Semua posisi sudah dipastikan dapat dicapai dari gerbang (tools/reach_scan.gd) dan bebas tabrakan.

const CHESTS: Array = [
	{"id": "c_gate", "pos": Vector2(-5, 55), "tier": "wood", "name": "Peti Gerbang"},
	{"id": "c_plaza", "pos": Vector2(13, -11), "tier": "wood", "name": "Peti Plaza"},
	{"id": "c_forge", "pos": Vector2(-32, -42), "tier": "silver", "name": "Peti Bengkel"},
	{"id": "c_library", "pos": Vector2(32, -43), "tier": "silver", "name": "Peti Perpustakaan"},
	{"id": "c_altar", "pos": Vector2(-38, 42), "tier": "silver", "name": "Peti Altar"},
	{"id": "c_pond", "pos": Vector2(38, 45), "tier": "wood", "name": "Peti Kolam"},
	{"id": "c_camp", "pos": Vector2(-58, 8), "tier": "wood", "name": "Peti Kamp"},
	{"id": "c_portal", "pos": Vector2(56, 11), "tier": "silver", "name": "Peti Portal"},
	{"id": "h_w1", "pos": Vector2(-60, -44), "tier": "gold", "name": "Peti Lorong", "hidden": true},
	{"id": "h_w2", "pos": Vector2(-60, -28), "tier": "gold", "name": "Peti Lorong", "hidden": true},
	{"id": "h_e1", "pos": Vector2(60, -30), "tier": "gold", "name": "Peti Senja", "hidden": true},
	{"id": "h_e2", "pos": Vector2(60, -18), "tier": "gold", "name": "Peti Senja", "hidden": true},
	{"id": "h_s1", "pos": Vector2(-60, 54), "tier": "gold", "name": "Peti Celah", "hidden": true},
]
const REVEAL_R := 16.0                 # peti biasa tampak di peta bila pemain pernah lewat sedekat ini
const REVEAL_HIDDEN_R := 7.0           # peti tersembunyi baru tampak bila sedekat ini

## Area rahasia: ditemukan saat pemain masuk radius. Menghadiahkan Diamond sekali.
const ZONES: Array = [
	{"id": "z_lorong", "name": "Lorong Rahasia", "pos": Vector2(-60, -36), "r": 14.0, "diamonds": 40},
	{"id": "z_senja", "name": "Sudut Senja", "pos": Vector2(60, -24), "r": 12.0, "diamonds": 40},
	{"id": "z_celah", "name": "Celah Selatan", "pos": Vector2(-60, 55), "r": 7.0, "diamonds": 30},
]

## Titik teleport (batu portal). always = sudah terbuka sejak awal.
const WAYPOINTS: Array = [
	{"id": "wp_gate", "name": "Gerbang Kota", "pos": Vector2(0, 52), "always": true},
	{"id": "wp_plaza", "name": "Plaza Air Mancur", "pos": Vector2(0, 14), "always": true},
	{"id": "wp_guild", "name": "Depan Guild", "pos": Vector2(0, -30)},
	{"id": "wp_portal", "name": "Portal Petualangan", "pos": Vector2(46, -3)},
	{"id": "wp_camp", "name": "Kamp Party", "pos": Vector2(-46, 0)},
	{"id": "wp_pond", "name": "Taman Kolam", "pos": Vector2(37, 28)},
	{"id": "wp_altar", "name": "Altar Bintang", "pos": Vector2(-31, 32)},
	{"id": "wp_lorong", "name": "Lorong Rahasia", "pos": Vector2(-60, -36), "zone": "z_lorong"},
	{"id": "wp_timur", "name": "Sudut Senja", "pos": Vector2(60, -27), "zone": "z_senja"},
]
const WP_DISCOVER_R := 5.0

## Wilayah jelajah (stage berawalan f_): posisi dalam koordinat kutub terhadap pusat arena (a = derajat, r = pecahan radius).
## Peti tersembunyi berada di dalam zona rahasia (relung di tepi arena). Posisi akhir disesuaikan ke titik bebas oleh Stage.free_spot.
const FIELDS := {
	"f_plains": {"name": "Padang Angin",
		"chests": [
			{"id": "f_plains_1", "a": 200.0, "r": 0.45, "tier": "wood", "name": "Peti Padang"},
			{"id": "f_plains_2", "a": 320.0, "r": 0.50, "tier": "wood", "name": "Peti Padang"},
			{"id": "f_plains_3", "a": 55.0, "r": 0.62, "tier": "silver", "name": "Peti Padang"},
			{"id": "f_plains_4", "a": 150.0, "r": 0.70, "tier": "silver", "name": "Peti Padang"},
			{"id": "f_plains_h1", "a": 10.0, "r": 0.86, "tier": "gold", "name": "Peti Relung", "hidden": true},
			{"id": "f_plains_h2", "a": 250.0, "r": 0.86, "tier": "gold", "name": "Peti Relung", "hidden": true}],
		"zones": [
			{"id": "fz_plains_1", "name": "Bukit Bisik", "a": 10.0, "r": 0.86, "rad": 9.0, "diamonds": 40},
			{"id": "fz_plains_2", "name": "Lembah Sunyi", "a": 250.0, "r": 0.86, "rad": 9.0, "diamonds": 40}]},
	"f_forest": {"name": "Hutan Berbisik",
		"chests": [
			{"id": "f_forest_1", "a": 180.0, "r": 0.40, "tier": "wood", "name": "Peti Hutan"},
			{"id": "f_forest_2", "a": 300.0, "r": 0.55, "tier": "wood", "name": "Peti Hutan"},
			{"id": "f_forest_3", "a": 40.0, "r": 0.60, "tier": "silver", "name": "Peti Hutan"},
			{"id": "f_forest_4", "a": 235.0, "r": 0.72, "tier": "silver", "name": "Peti Hutan"},
			{"id": "f_forest_h1", "a": 355.0, "r": 0.86, "tier": "gold", "name": "Peti Relung", "hidden": true},
			{"id": "f_forest_h2", "a": 160.0, "r": 0.86, "tier": "gold", "name": "Peti Relung", "hidden": true}],
		"zones": [
			{"id": "fz_forest_1", "name": "Pohon Tua", "a": 355.0, "r": 0.86, "rad": 9.0, "diamonds": 50},
			{"id": "fz_forest_2", "name": "Kolam Tersembunyi", "a": 160.0, "r": 0.86, "rad": 9.0, "diamonds": 50}]},
	"f_cave": {"name": "Gua Kristal",
		"chests": [
			{"id": "f_cave_1", "a": 210.0, "r": 0.42, "tier": "wood", "name": "Peti Gua"},
			{"id": "f_cave_2", "a": 330.0, "r": 0.52, "tier": "silver", "name": "Peti Gua"},
			{"id": "f_cave_3", "a": 60.0, "r": 0.62, "tier": "silver", "name": "Peti Gua"},
			{"id": "f_cave_4", "a": 130.0, "r": 0.72, "tier": "silver", "name": "Peti Gua"},
			{"id": "f_cave_h1", "a": 20.0, "r": 0.86, "tier": "gold", "name": "Peti Relung", "hidden": true},
			{"id": "f_cave_h2", "a": 265.0, "r": 0.86, "tier": "gold", "name": "Peti Relung", "hidden": true}],
		"zones": [
			{"id": "fz_cave_1", "name": "Ruang Kristal Biru", "a": 20.0, "r": 0.86, "rad": 9.0, "diamonds": 60},
			{"id": "fz_cave_2", "name": "Lorong Gema", "a": 265.0, "r": 0.86, "rad": 9.0, "diamonds": 60}]},
}
const GATE_A := 90.0                   # gerbang lobi di sudut ini, pada r = GATE_R
const GATE_R := 0.88

const TIERS := {
	"wood": {"label": "Peti Kayu", "gold": 150, "diamonds": 0, "items": {"p_small": 1}, "col": Color(0.72, 0.46, 0.22)},
	"silver": {"label": "Peti Perak", "gold": 320, "diamonds": 15, "items": {"p_small": 1, "p_big": 1}, "col": Color(0.74, 0.8, 0.9)},
	"gold": {"label": "Peti Emas", "gold": 600, "diamonds": 50, "items": {"p_big": 2, "p_elixir": 1}, "col": Color(1.0, 0.8, 0.28)},
}


static func _d() -> Dictionary:
	var d = GameState.flags.get("explore", null)
	if not (d is Dictionary):
		d = {}
		GameState.flags["explore"] = d
	if not (d.get("chests", null) is Array):
		d["chests"] = []
	if not (d.get("disc", null) is Array):
		d["disc"] = []
	return d


static func chest_def(id: String) -> Dictionary:
	for c: Dictionary in CHESTS:
		if c["id"] == id:
			return c
	for f in FIELDS:
		for c2: Dictionary in FIELDS[f]["chests"]:
			if c2["id"] == id:
				return c2
	return {}


static func _polar(a: float, r: float, R: float) -> Vector2:
	return Vector2(cos(deg_to_rad(a)), sin(deg_to_rad(a))) * r * R


## Daftar peti wilayah dengan "pos" (Vector2 x,z) menurut radius arena R.
static func field_chests(fid: String, R: float) -> Array:
	var out: Array = []
	if not FIELDS.has(fid):
		return out
	for c: Dictionary in FIELDS[fid]["chests"]:
		var d := c.duplicate()
		d["pos"] = _polar(c["a"], c["r"], R)
		out.append(d)
	return out


static func field_zones(fid: String, R: float) -> Array:
	var out: Array = []
	if not FIELDS.has(fid):
		return out
	for z: Dictionary in FIELDS[fid]["zones"]:
		var d := z.duplicate()
		d["pos"] = _polar(z["a"], z["r"], R)
		d["r"] = float(z["rad"])
		out.append(d)
	return out


static func gate_pos(R: float) -> Vector2:
	return _polar(GATE_A, GATE_R, R)


static func is_opened(id: String) -> bool:
	return _d()["chests"].has(id)


static func is_discovered(id: String) -> bool:
	if _d()["disc"].has(id):
		return true
	for w: Dictionary in WAYPOINTS:
		if w["id"] == id and bool(w.get("always", false)):
			return true
	return false


## Tandai ditemukan (peti/zona/titik teleport). true bila baru.
static func discover(id: String) -> bool:
	if is_discovered(id):
		return false
	_d()["disc"].append(id)
	GameState.changed.emit("explore")
	GameState.queue_save()
	return true


## Buka peti: beri hadiah dan simpan. Kembalikan {} bila sudah terbuka/tidak dikenal.
static func open_chest(id: String) -> Dictionary:
	var c := chest_def(id)
	if c.is_empty() or is_opened(id):
		return {}
	var t: Dictionary = TIERS[c["tier"]]
	_d()["chests"].append(id)
	if not _d()["disc"].has(id):
		_d()["disc"].append(id)
	var gold: int = int(t["gold"])
	var dia: int = int(t["diamonds"])
	GameState.add_gold(gold)
	if dia > 0:
		GameState.add_diamonds(dia)
	var got: Dictionary = {}
	for it in t["items"]:
		if Data.items.has(it):
			GameState.add_item(it, int(t["items"][it]))
			got[it] = int(t["items"][it])
	GameState.changed.emit("explore")
	GameState.queue_save()
	return {"gold": gold, "diamonds": dia, "items": got, "tier": c["tier"]}


static func reward_text(r: Dictionary) -> String:
	var parts: Array = ["+%d Gold" % int(r.get("gold", 0))]
	if int(r.get("diamonds", 0)) > 0:
		parts.append("+%d Diamond" % int(r["diamonds"]))
	for it in r.get("items", {}):
		var nm: String = Data.items[it].display_name if Data.items.has(it) and "display_name" in Data.items[it] else it
		parts.append("%s x%d" % [nm, int(r["items"][it])])
	return "  ".join(parts)


static func counts() -> Dictionary:
	var op := 0
	var ct := CHESTS.size()
	for c: Dictionary in CHESTS:
		if is_opened(c["id"]):
			op += 1
	var z := 0
	var zt := ZONES.size()
	for zz: Dictionary in ZONES:
		if is_discovered(zz["id"]):
			z += 1
	for f in FIELDS:
		for fc: Dictionary in FIELDS[f]["chests"]:
			ct += 1
			if is_opened(fc["id"]):
				op += 1
		for fz: Dictionary in FIELDS[f]["zones"]:
			zt += 1
			if is_discovered(fz["id"]):
				z += 1
	var w := 0
	for ww: Dictionary in WAYPOINTS:
		if is_discovered(ww["id"]):
			w += 1
	return {"chests": op, "chests_total": ct, "zones": z, "zones_total": zt, "wps": w, "wps_total": WAYPOINTS.size()}


## Perbarui penemuan berdasar posisi pemain (x,z) di lobi. Kembalikan daftar pesan untuk ditampilkan.
static func scan(p: Vector2) -> Array:
	return scan_defs(p, CHESTS, ZONES, WAYPOINTS)


## Versi umum (lobi & wilayah): chests/zones/wps berisi Dictionary dengan "pos" (Vector2).
static func scan_defs(p: Vector2, chests: Array, zones: Array, wps: Array) -> Array:
	var msgs: Array = []
	for z: Dictionary in zones:
		if p.distance_to(z["pos"]) <= float(z["r"]) and discover(z["id"]):
			var dia: int = int(z["diamonds"])
			GameState.add_diamonds(dia)
			msgs.append("Area rahasia ditemukan: %s  (+%d Diamond)" % [z["name"], dia])
	for w: Dictionary in wps:
		if p.distance_to(w["pos"]) <= WP_DISCOVER_R and discover(w["id"]):
			msgs.append("Titik teleport terbuka: %s" % w["name"])
	for c: Dictionary in chests:
		var r := REVEAL_HIDDEN_R if bool(c.get("hidden", false)) else REVEAL_R
		if p.distance_to(c["pos"]) <= r:
			discover(c["id"])
	return msgs


## Peti medan di dalam stage: emas tiap kali dibuka, Diamond bonus hanya pertama kali per stage.
static func open_stage_chest(stage_id: String, level: int) -> Dictionary:
	var sf: Array = _d().get("stage_first", [])
	var first: bool = not sf.has(stage_id)
	var gold := 40 + level * 12
	var dia := 20 if first else 0
	GameState.add_gold(gold)
	if dia > 0:
		GameState.add_diamonds(dia)
		if not (_d().get("stage_first", null) is Array):
			_d()["stage_first"] = []
		_d()["stage_first"].append(stage_id)
	GameState.add_item("p_small", 1)
	GameState.queue_save()
	return {"gold": gold, "diamonds": dia, "items": {"p_small": 1}}
