class_name Building
extends Node3D
## Satu bangunan/struktur di kota. `kind` memilih penyusun mesh (scripts/buildings/b_*.gd).
## Mesh digabung menjadi 1 surface opaque + 1 surface cutout (dedaunan/spanduk), tabrakan lewat ColliderSink.
## Bangunan tinggi memudar (dither) saat berada di antara kamera dan pemain.

const BUILDERS := {
	"guild": "res://scripts/buildings/b_guild.gd",
	"weapon_shop": "res://scripts/buildings/b_shops.gd",
	"item_shop": "res://scripts/buildings/b_shops.gd",
	"house_a": "res://scripts/buildings/b_houses.gd",
	"house_b": "res://scripts/buildings/b_houses.gd",
	"house_c": "res://scripts/buildings/b_houses.gd",
	"house_d": "res://scripts/buildings/b_houses.gd",
	"library": "res://scripts/buildings/b_landmarks.gd",
	"portal": "res://scripts/buildings/b_landmarks.gd",
	"gate": "res://scripts/buildings/b_landmarks.gd",
	"tent": "res://scripts/buildings/b_landmarks.gd",
	"altar": "res://scripts/buildings/b_landmarks.gd",
	"fountain": "res://scripts/buildings/b_landmarks.gd",
	"tower": "res://scripts/buildings/b_landmarks.gd",
	"forge": "res://scripts/buildings/b_landmarks.gd",
	"pond": "res://scripts/buildings/b_landmarks.gd",
}

@export var kind: String = "house_a"
@export var seed_value: int = 1
@export var sign_text: String = ""
@export var roof_color: Color = Color(0.92, 0.36, 0.32)
@export var wall_color: Color = Color(1.0, 0.96, 0.88)
@export var can_fade: bool = true

var kit: MeshKit
var sink := ColliderSink.new()
var mesh_instance: MeshInstance3D
var body: StaticBody3D
var footprint := 6.0                 # jari-jari tempat terlarang bagi pohon/dekorasi
var height := 6.0                    # tinggi perkiraan (untuk memudar)
var extras: Array = []               # node tambahan (label, partikel, dll) untuk dibuat builder
var interactions: Array = []         # {"id","pos"(lokal),"action","prompt","radius"}
var world_aabb := AABB()

var _fade_mat: ShaderMaterial
var _fade := 1.0
var _target := 1.0


func _ready() -> void:
	kit = MeshKit.new(seed_value)
	var path: String = BUILDERS.get(kind, "")
	if path == "":
		push_error("Building: jenis tidak dikenal '%s'" % kind)
		return
	var script: GDScript = load(path)
	script.build(self)
	_finish()


func _finish() -> void:
	var m := kit.build()
	kit.apply_materials(m)
	mesh_instance = MeshInstance3D.new()
	mesh_instance.name = "Mesh"
	mesh_instance.mesh = m
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	add_child(mesh_instance)
	if not sink.items.is_empty():
		body = StaticBody3D.new()
		body.name = "Body"
		body.collision_layer = 1
		body.collision_mask = 0
		add_child(body)
		sink.apply_to(body)
	for e in extras:
		add_child(e)
	extras.clear()
	world_aabb = global_transform * m.get_aabb() if is_inside_tree() else m.get_aabb()
	set_process(false)


## Label3D datar di dinding (menghadap +Z lokal).
func add_label(text: String, pos: Vector3, size: float = 0.012, color: Color = Color(1, 0.93, 0.7), rot_deg: Vector3 = Vector3.ZERO, font_size: int = 64) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font_size = font_size
	l.pixel_size = size
	l.modulate = color
	l.outline_size = 14
	l.outline_modulate = Color(0.1, 0.08, 0.12, 0.95)
	l.shaded = false
	l.double_sided = false
	l.position = pos
	l.rotation_degrees = rot_deg
	l.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	extras.append(l)
	return l


func add_interaction(id: String, local_pos: Vector3, action: String, prompt: String, radius: float = 2.2) -> void:
	interactions.append({"id": id, "pos": local_pos, "action": action, "prompt": prompt, "radius": radius})


## Dipanggil oleh Lobby: apakah bangunan ini menghalangi pandangan kamera ke pemain?
func set_occluding(v: bool) -> void:
	if not can_fade:
		return
	var t := 0.22 if v else 1.0
	if absf(t - _target) < 0.001:
		return
	_target = t
	set_process(true)


func _process(delta: float) -> void:
	_fade = move_toward(_fade, _target, delta * 3.5)
	var si := kit.surface_opaque
	if si < 0:
		set_process(false)
		return
	if _fade < 0.999:
		if _fade_mat == null:
			_fade_mat = WorldMats.fade_material()
		if mesh_instance.get_surface_override_material(si) != _fade_mat:
			mesh_instance.set_surface_override_material(si, _fade_mat)
		_fade_mat.set_shader_parameter("fade", _fade)
	else:
		mesh_instance.set_surface_override_material(si, null)
		set_process(false)
