extends Node
## Uji penyimpanan TUNGGAL tanpa slot: hapus data = benar-benar hilang (tanpa .bak/identitas/meta), ID acak di dalam save,
## kode cadangan terikat perangkat + bertanda tangan, kode dari perangkat lain = ditolak & dicatat (TANPA blokir), deteksi kecurangan, simpan otomatis, migrasi sisa sistem lama.
## Menulis ke user:// (dibersihkan di akhir).
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1

func _user_files() -> Array:
	var out: Array = []
	var da := DirAccess.open("user://")
	if da:
		for f in da.get_files():
			out.append(f)
	return out

func _junk() -> Array:
	var bad: Array = []
	for f in _user_files():
		if f.ends_with(".bak") or f.ends_with(".tmp") or f.begins_with("save_slot") or f in ["identity.json", "meta.json", "fantasy_life_save.json"]:
			bad.append(f)
	return bad

func _rm(path: String) -> void:
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(path))

func _ready() -> void:
	var gs := GameState
	_rm(gs.LEGACY_SANCTION_PATH)
	gs.delete_save()
	check("awal: tidak ada save & tidak ada sisa", not gs.has_save() and _junk().is_empty(), str(_junk()))
	# --- dunia baru + simpan
	gs.start_new_game()
	var id1 := gs.player_id
	check("save tunggal terbentuk di SAVE_PATH", gs.has_save() and FileAccess.file_exists(gs.SAVE_PATH))
	check("ID berformat benar", gs._id_valid(id1), id1)
	gs.gold = 1234; gs.player_name = "Ren2"; gs.pity = 23
	for i in 3:
		gs.save_game()
	check("setelah 3x simpan: tanpa .bak/.tmp/slot/identitas/meta", _junk().is_empty(), str(_junk()))
	var info := gs.save_info()
	check("save_info: nama & level", info.get("name") == "Ren2" and info.get("level") == 1, str(info))
	# --- muat kembali (ID tersimpan di dalam save)
	gs.gold = 1; gs.player_name = "x"; gs.player_id = "FL-AAAA-BBBB"
	check("lanjutkan: gold, nama, pity pulih", gs.continue_game() and gs.gold == 1234 and gs.player_name == "Ren2" and gs.pity == 23, "gold=%d" % gs.gold)
	check("ID dibaca dari save (sama)", gs.player_id == id1, gs.player_id + " vs " + id1)
	# --- hapus = hilang total, ID baru acak
	gs.delete_save()
	check("hapus: file save hilang & tak ada sisa apa pun", not gs.has_save() and _junk().is_empty() and not FileAccess.file_exists(gs.SAVE_PATH), str(_user_files()))
	gs.start_new_game()
	check("dunia baru setelah hapus: ID BERBEDA (tidak menempel ke perangkat)", gs.player_id != id1 and gs._id_valid(gs.player_id), gs.player_id + " vs " + id1)
	check("dunia baru: data kembali awal (gold awal)", gs.gold == gs.START_GOLD and gs.pity == 0, "gold=%d" % gs.gold)
	check("ID acak: 20 ID berturut-turut tak ada yang sama", _unique_ids(20))
	# --- ekspor terikat perangkat
	gs.gold = 777; gs.player_name = "Gt"
	var id_exp := gs.player_id
	var code := gs.export_code()
	check("kode berawalan FLSAVE2 dan tidak memuat ID perangkat mentah", code.begins_with("FLSAVE2:") and (OS.get_unique_id() == "" or not code.contains(OS.get_unique_id())), code.substr(0, 20))
	check("hash perangkat stabil 20 huruf", gs.device_hash() == gs.device_hash() and gs.device_hash().length() == 20, gs.device_hash())
	var r0 := gs.import_code(code)
	check("impor saat masih ada save ditolak (tanpa blokir, anti-putar-balik)", not r0["ok"] and not r0.get("cheat", false), str(r0.get("msg")))
	gs.delete_save()
	check("setelah hapus: tidak ada save di perangkat (kode ada di tangan pemain saja)", not gs.has_save())
	# kasus buruk (tanpa blokir)
	var parts := code.split(":")
	var bad_mac := gs.import_code("%s:%s:%s" % [parts[0], parts[1], "0".repeat(32)])
	check("tanda tangan salah ditolak, tidak diblokir", not bad_mac["ok"] and not bad_mac.get("cheat", false), str(bad_mac.get("msg")))
	var cut := gs.import_code(code.substr(0, code.length() / 2))
	check("kode terpotong ditolak", not cut["ok"], str(cut.get("msg")))
	var v1 := gs.import_code("FLSAVE1:" + parts[1] + ":abcdef12")
	check("kode versi lama ditolak", not v1["ok"], str(v1.get("msg")))
	check("teks acak/kosong ditolak", not gs.import_code("halo dunia")["ok"] and not gs.import_code("")["ok"])
	check("tidak ada save terbentuk dari impor gagal", not gs.has_save())
	# pulihkan di perangkat yang sama
	var r1 := gs.import_code(code)
	check("pulihkan di perangkat yang sama: ok", r1["ok"] and gs.has_save(), str(r1.get("msg")))
	check("hasil pulih: gold 777, nama Gt, ID sama dengan yang diekspor", gs.continue_game() and gs.gold == 777 and gs.player_name == "Gt" and gs.player_id == id_exp, "id=%s" % gs.player_id)
	check("kode dengan spasi/baris tambahan tetap diterima", _roundtrip_spacing(code))
	# --- kode dari perangkat lain -> DITOLAK + dicatat sebagai temuan, TANPA blokir
	var foreign := _forge(code, {"dev": "perangkat-lain-xyz"})
	gs.delete_save()
	gs._cheat_pending.clear()
	var rf := gs.import_code(foreign)
	check("kode perangkat lain: ditolak & dicatat, TIDAK diblokir (tak ada file sanksi)", not rf["ok"] and rf.get("cheat", false) and not FileAccess.file_exists(gs.LEGACY_SANCTION_PATH) and not gs.has_save(), str(rf.get("msg")))
	check("temuan 'other_device' menunggu di memori (belum ada save)", gs._cheat_pending.size() == 1 and str(gs._cheat_pending[0]["k"]) == "other_device", str(gs._cheat_pending))
	check("tetap bisa memulihkan kode sah milik sendiri", gs.import_code(code)["ok"] and gs.has_save())
	check("tetap bisa melanjutkan permainan", gs.continue_game())
	gs.save_game()
	check("temuan masuk ke save pada simpan berikutnya", _has_kind(gs, "other_device") and gs._cheat_pending.is_empty(), str(gs.cheat_log()))
	gs.delete_save()
	gs.start_new_game()
	check("mulai baru tetap bisa", gs.continue_game())
	# sisa file blokir versi lama dihapus otomatis saat game dibuka
	_write(gs.LEGACY_SANCTION_PATH, "{\"banned\": true, \"reason\": \"lama\"}")
	gs._clear_legacy_sanction()
	check("file blokir lama dihapus otomatis", not FileAccess.file_exists(gs.LEGACY_SANCTION_PATH))
	# --- deteksi kecurangan (hanya dicatat)
	gs.delete_save(); gs._cheat_pending.clear()
	gs.start_new_game(); gs.gold = 555; gs.save_game()
	var raw = JSON.parse_string(FileAccess.get_file_as_string(gs.SAVE_PATH))
	check("save memuat tanda tangan 24 huruf & penanda waktu", str(raw.get("sig", "")).length() == 24 and int(raw.get("seen", 0)) > 0, str(raw.get("sig")))
	check("save asli lolos verifikasi (setelah baca ulang dari JSON)", CheatGuard.verify(raw) == 0)
	check("muat save asli: tanpa temuan", gs.continue_game() and gs.cheat_log().is_empty(), str(gs.cheat_log()))
	raw["gold"] = 9999
	_write(gs.SAVE_PATH, JSON.stringify(raw))
	check("edit gold di luar game -> verifikasi TIDAK cocok", CheatGuard.verify(raw) == 2)
	check("muat save yang diedit: tetap bisa main, tercatat 'tamper', tanpa blokir", gs.continue_game() and gs.gold == 9999 and _has_kind(gs, "tamper") and not FileAccess.file_exists(gs.LEGACY_SANCTION_PATH), str(gs.cheat_log()))
	gs.save_game()
	check("disimpan ulang lalu dimuat lagi: tidak ada temuan baru", gs.continue_game() and gs.cheat_log().size() == 1, str(gs.cheat_log()))
	var legacy_save = JSON.parse_string(FileAccess.get_file_as_string(gs.SAVE_PATH))
	legacy_save.erase("sig"); legacy_save.erase("seen"); legacy_save["flags"] = {}
	_write(gs.SAVE_PATH, JSON.stringify(legacy_save))
	check("save lama tanpa tanda tangan diterima tanpa temuan", CheatGuard.verify(legacy_save) == 1 and gs.continue_game() and gs.cheat_log().is_empty(), str(gs.cheat_log()))
	check("jam: mundur 5 menit ditoleransi, 12 menit terdeteksi, tanpa data tidak dihitung", not CheatGuard.clock_rolled_back(1000, 700) and CheatGuard.clock_rolled_back(1000, 280) and not CheatGuard.clock_rolled_back(0, -5))
	gs.seen_unix = int(Time.get_unix_time_from_system()) + 7200
	gs.check_clock()
	check("jam diputar mundur 2 jam -> tercatat 'clock_back'", _has_kind(gs, "clock_back"), str(gs.cheat_log()))
	check("penanda waktu tidak turun (tetap tertinggi)", gs.seen_unix >= int(Time.get_unix_time_from_system()) + 7000)
	check("nilai mustahil terdeteksi", CheatGuard.anomalies({"level": 99, "gold": -5, "diamonds": 20_000_000, "roster": {"ren": {"stars": 9}}}, 50, 5).size() == 4 and CheatGuard.anomalies({"level": 10, "gold": 100, "diamonds": 5, "roster": {"ren": {"stars": 3}}}, 50, 5).is_empty())
	var odd = JSON.parse_string(FileAccess.get_file_as_string(gs.SAVE_PATH))
	odd["level"] = 99
	_write(gs.SAVE_PATH, JSON.stringify(odd))
	check("muat level 99: dibersihkan ke batas & tercatat 'anomaly', tanpa blokir", gs.continue_game() and gs.level == gs.MAX_LEVEL and _has_kind(gs, "anomaly"), "level=%d" % gs.level)
	check("catatan temuan dibatasi (maks LOG_MAX)", _log_cap(gs))
	# --- simpan otomatis
	gs.delete_save(); gs._cheat_pending.clear()
	gs.start_new_game()
	gs.set_setting("autosave", true); gs.set_setting("autosave_idx", 0)
	check("jeda simpan otomatis: idx 0 = 30 dtk, idx 3 = 300 dtk", is_equal_approx(gs.autosave_interval(), 30.0) and (func(): gs.set_setting("autosave_idx", 3); var r := is_equal_approx(gs.autosave_interval(), 300.0); gs.set_setting("autosave_idx", 0); return r).call())
	gs.gold = 31337
	gs._autosave_t = 0.0
	gs._autosave_tick(29.0)
	check("belum waktunya: file belum berubah", int(_read_save(gs)["gold"]) != 31337)
	gs._autosave_tick(2.0)
	check("lewat jeda: tersimpan otomatis ke file", int(_read_save(gs)["gold"]) == 31337, str(_read_save(gs)["gold"]))
	check("indikator 'Tersimpan otomatis' tampil", gs._ind != null and gs._ind.visible)
	gs.set_setting("autosave", false)
	gs.gold = 40000
	gs._autosave_tick(100.0)
	check("simpan otomatis dimatikan: tidak menulis", int(_read_save(gs)["gold"]) == 31337)
	gs.set_setting("autosave", true)
	gs.delete_save()
	gs._autosave_tick(100.0)
	check("belum ada dunia (setelah hapus): simpan otomatis tidak membuat file", not gs.has_save())
	gs.set_setting("autosave_idx", 1)
	# --- migrasi sisa sistem lama
	gs.delete_save()
	gs.start_new_game(); gs.gold = 4242; gs.save_game()
	var legacy = JSON.parse_string(FileAccess.get_file_as_string(gs.SAVE_PATH))
	legacy["world"] = "Dunia Lama"; legacy["slot"] = 2
	gs.delete_save()
	for f in ["user://save_slot_1.json", "user://save_slot_2.json", "user://save_slot_3.json"]:
		_write(f, JSON.stringify(legacy if f.contains("_2") else {"version": 1, "gold": 1}))
		_write(f + ".bak", "{}")
	_write("user://identity.json", "{\"id\":\"FL-AAAA-BBBB\"}")
	_write("user://meta.json", "{\"last_slot\":2}")
	_write("user://fantasy_life_save.json", "{}")
	gs._purge_legacy()
	check("migrasi: slot terakhir (SV2) menjadi save tunggal", gs.has_save() and gs.continue_game() and gs.gold == 4242, "gold=%d" % gs.gold)
	check("migrasi: semua sisa slot/.bak/identitas/meta dihapus", _junk().is_empty(), str(_junk()))
	check("migrasi: ID baru acak (bukan ID lama dari file identitas)", gs.player_id != "FL-AAAA-BBBB" and gs._id_valid(gs.player_id))
	# --- bersihkan
	gs.delete_save()
	_rm(gs.LEGACY_SANCTION_PATH)
	check("akhir: user:// bersih dari save/sisa", not gs.has_save() and _junk().is_empty())
	print("CHECK SUMMARY fails=", fails)
	get_tree().quit()

func _has_kind(gs: Node, kind: String) -> bool:
	for e in gs.cheat_log():
		if str(e.get("k", "")) == kind:
			return true
	return false

func _read_save(gs: Node) -> Dictionary:
	return JSON.parse_string(FileAccess.get_file_as_string(gs.SAVE_PATH))

func _log_cap(gs: Node) -> bool:
	for i in 40:
		gs._append_cheat({"k": "anomaly", "t": "x", "u": i, "d": ""})
	return gs.cheat_log().size() == CheatGuard.LOG_MAX

func _write(path: String, text: String) -> void:
	var f := FileAccess.open(path, FileAccess.WRITE)
	f.store_string(text)
	f.close()

func _unique_ids(n: int) -> bool:
	var seen := {}
	for i in n:
		seen[GameState._make_id()] = true
	return seen.size() == n

func _roundtrip_spacing(code: String) -> bool:
	var gs := GameState
	gs.delete_save()
	var ok: bool = gs.import_code("  " + code.substr(0, 30) + "\n" + code.substr(30) + " \n")["ok"]
	gs.delete_save()
	return ok

## Palsukan kode: ubah isi payload lalu tanda tangani ulang dengan kunci yang sama (meniru penyerang yang tahu kunci).
func _forge(code: String, changes: Dictionary) -> String:
	var gs := GameState
	var parts := code.split(":")
	var text := Marshalls.base64_to_raw(parts[1]).decompress_dynamic(8_000_000, FileAccess.COMPRESSION_GZIP).get_string_from_utf8()
	var pl: Dictionary = JSON.parse_string(text)
	for k in changes:
		pl[k] = changes[k]
	var t2 := JSON.stringify(pl)
	return "%s:%s:%s" % [gs.CODE_PREFIX, Marshalls.raw_to_base64(t2.to_utf8_buffer().compress(FileAccess.COMPRESSION_GZIP)), gs._code_mac(t2)]
