extends Node3D
## Alat pengembang: baris karakter dengan aksesori (party + NPC) dari depan/belakang.
##   --out=file.png --yaw=0 --set=heroes|npcs --cam=x,y,z --look=x,y,z
func _arg(key: String, default: String) -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % key):
			return a.substr(key.length() + 3)
	return default


func _vec(s: String) -> Vector3:
	var p := s.split(",")
	return Vector3(float(p[0]), float(p[1]), float(p[2]))


func _ready() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.6, 0.78, 0.95)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.75, 0.8, 0.95)
	e.ambient_light_energy = 0.55
	env.environment = e
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-45, -25, 0)
	sun.light_energy = 0.9
	add_child(sun)
	var yaw := float(_arg("yaw", "0"))
	var ids: Array = ["vael", "lucien", "wenyu", "kuroha", "aion"] if _arg("set", "heroes") == "new" else ["ren", "lyra", "brann", "sera"]
	if _arg("set", "heroes") == "aion":
		ids = ["aion", "kuroha"]
	if _arg("set", "heroes") == "kyomu":
		ids = ["kyomu", "zeya"]
	if _arg("set", "heroes") == "all":
		ids = ["ren", "lyra", "brann", "sera", "ember", "zeya", "hakuya", "vael", "lucien", "wenyu", "kuroha", "aion", "kyomu"]
	if _arg("ids", "") != "":
		ids = _arg("ids", "").split(",")
	var kind := _arg("set", "heroes")
	var looks: Array = []
	if kind == "npcs":
		looks = [["guild_master", "skin_elio"], ["merchant", "skin_tobias"], ["potion_seller", "skin_mira"], ["blacksmith", "skin_orwen"],
			["info", "skin_selin"], ["party_leader", "skin_kael"], ["gate_guard", "skin_rowan"], ["priestess", "skin_pip"]]
	elif kind == "enemies":
		for k in ["cultist", "shadow_mage", "chain_knight", "ronin", "uranos", "chain_king"]:
			looks.append([k, "skin_" + HumanoidEnemy.LOOKS[k]["skin"]])
	else:
		for i in ids:
			looks.append([i, "skin_" + i])
	var n := looks.size()
	for i in n:
		var rig := CharacterRig.new()
		add_child(rig)
		var skin: Texture2D = load("res://assets/hero/%s.png" % looks[i][1])
		rig.setup(float(HumanoidEnemy.LOOKS[looks[i][0]]["h"]) if kind == "enemies" else 1.8, skin, kind != "npcs", true)
		rig.position = Vector3((i - (n - 1) * 0.5) * float(_arg("space", "1.9")), 0, 0)
		rig.rotation_degrees.y = yaw
		if kind == "enemies":
			CharacterLooks.apply_enemy(rig, looks[i][0])
			rig.set_style(HumanoidEnemy.LOOKS[looks[i][0]]["style"])
			rig.set_move(0.0)
		elif kind != "npcs":
			CharacterLooks.apply_hero(rig, looks[i][0])
			rig.set_move(0.0)
		else:
			CharacterLooks.apply_npc(rig, looks[i][0])
	var ground := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(40, 20)
	ground.mesh = pm
	var gm := StandardMaterial3D.new()
	gm.albedo_color = Color(0.7, 0.8, 0.6)
	ground.material_override = gm
	add_child(ground)
	var cam := Camera3D.new()
	cam.fov = 35
	cam.position = _vec(_arg("cam", "0,1.6,11"))
	add_child(cam)
	cam.look_at(_vec(_arg("look", "0,1.0,0")))
	for k in 12:
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png(_arg("out", "/tmp/looks.png"))
	print("saved")
	get_tree().quit()
