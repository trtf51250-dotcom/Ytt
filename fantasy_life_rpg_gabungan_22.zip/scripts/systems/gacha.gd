class_name Gacha
extends RefCounted
## Dua gacha terpisah di Altar Bintang (peluang & pity masing-masing, ditampilkan jujur di panel):
##   POOL_CHAR "char" = Panggilan Jiwa  -> karakter baru (terbuka) atau Pecahan Jiwa bila sudah dimiliki. Banner event (karakter terbatas) ada di sini.
##   POOL_ITEM "item" = Panggilan Perlengkapan -> senjata/armor/aksesori & ramuan. Tidak pernah memberi karakter / Pecahan Jiwa.
## Bintang tertinggi: gacha karakter ★6, gacha perlengkapan ★5 (lihat top_of). 10x menjamin minimal satu bintang 4.
## Setiap pity_limit tarikan tanpa bintang tertinggi di gacha yang sama, tarikan berikutnya pasti bintang tertinggi.
## Hasil langsung dimasukkan ke GameState (inventori / karakter / pecahan).

const POOL_CHAR := "char"
const POOL_ITEM := "item"
const RATES_ITEM := [[5, 0.02], [4, 0.10], [3, 0.28], [2, 0.30], [1, 0.30]]   # [bintang, peluang]
const RATES_CHAR := [[6, 0.015], [5, 0.035], [4, 0.13], [3, 0.82]]
const PITY_LIMIT := 50                                                          # gacha perlengkapan
const PITY_LIMIT_CHAR := 80                                                     # gacha karakter (★6 lebih langka)
## Isi gacha karakter per bintang. Karakter event (mis. Ember) TIDAK ada di sini: hanya lewat banner event.
const CHAR_POOL := {6: ["hakuya"], 5: ["vael", "lucien", "aion", "kyomu"], 4: ["sera", "zeya", "lyra", "wenyu", "kuroha"], 3: ["ren", "brann"]}
const SHARDS := {6: 20, 5: 10, 4: 5, 3: 3}                                            # Pecahan Jiwa untuk duplikat


static func top_of(pool: String) -> int:
	return 6 if pool == POOL_CHAR else 5


static func pity_limit(pool: String) -> int:
	return PITY_LIMIT_CHAR if pool == POOL_CHAR else PITY_LIMIT


static func rates(pool: String) -> Array:
	return RATES_CHAR if pool == POOL_CHAR else RATES_ITEM


static func cost(n: int) -> int:
	return GameState.GACHA_TEN if n >= 10 else GameState.GACHA_SINGLE * n


static func can_afford(n: int) -> bool:
	return GameState.diamonds >= cost(n)


static func pity_of(pool: String) -> int:
	return GameState.pity if pool == POOL_CHAR else GameState.pity_item


static func _set_pity(pool: String, v: int) -> void:
	if pool == POOL_CHAR:
		GameState.pity = v
	else:
		GameState.pity_item = v


static func _roll_rarity(pool: String, force_min4: bool) -> int:
	if pity_of(pool) >= pity_limit(pool) - 1:
		return top_of(pool)
	var r := randf()
	var acc := 0.0
	var rar := 1
	for e: Array in rates(pool):
		acc += float(e[1])
		if r < acc:
			rar = int(e[0])
			break
	if force_min4 and rar < 4:
		rar = 4
	return rar


## Melakukan n tarikan (1 atau 10) pada gacha `pool` ("char" / "item"). Mengembalikan [{kind, id, count, rarity, name}] atau [] bila diamond kurang.
## banner_id = id event banner (data/events.json); hanya berlaku untuk pool "char". Banner yang sudah berakhir / belum mulai ditolak ([]).
static func pull(n: int, banner_id: String = "", pool: String = POOL_CHAR) -> Array:
	var banner: Dictionary = {}
	if banner_id != "":
		if pool != POOL_CHAR or not LiveEvents.is_active(banner_id):
			return []
		banner = LiveEvents.find(banner_id)
	if not can_afford(n) or not GameState.spend_diamonds(cost(n)):
		return []
	var out: Array = []
	var got4 := false
	for i in n:
		var last := i == n - 1
		var rar := _roll_rarity(pool, n >= 10 and last and not got4)
		if rar >= 4:
			got4 = true
		_set_pity(pool, 0 if rar == top_of(pool) else pity_of(pool) + 1)
		out.append(_result_char(rar, banner) if pool == POOL_CHAR else _result_item(rar))
	GameState.stats["pulls"] += n
	GameState.changed.emit("profile")
	GameState.report_event("summon", "", n)
	GameState.queue_save()
	return out


static func _give_char(cid: String, rar: int) -> Dictionary:
	var cd := Data.character(cid)
	if not GameState.is_unlocked(cid):
		GameState.unlock_character(cid)
		return {"kind": "character", "id": cid, "count": 1, "rarity": rar, "name": "%s (Karakter Baru!)" % cd.display_name, "new": true}
	var n: int = int(SHARDS.get(rar, 3))
	GameState.add_shards(cid, n)
	return {"kind": "shards", "id": cid, "count": n, "rarity": rar, "name": "Pecahan Jiwa %s" % cd.display_name}


static func _result_char(rar: int, banner: Dictionary) -> Dictionary:
	# banner event: sebagian hasil ★4 adalah karakter terbatas (event)
	if rar == 4 and not banner.is_empty() and randf() < float(banner.get("featured_share", 0.5)):
		return _give_char(str(banner["character"]), 4)
	if rar >= 4:
		var ids: Array = (CHAR_POOL[rar] as Array).filter(func(c): return Data.character(c) != null)
		if not ids.is_empty():
			return _give_char(ids[randi() % ids.size()], rar)
	# ★3: Pecahan Jiwa x3 untuk karakter yang sudah dimiliki
	var owned: Array = GameState.roster.keys()
	var cid: String = owned[randi() % owned.size()] if not owned.is_empty() else "ren"
	GameState.add_shards(cid, SHARDS[3])
	return {"kind": "shards", "id": cid, "count": SHARDS[3], "rarity": 3, "name": "Pecahan Jiwa %s" % Data.character(cid).display_name}


static func _result_item(rar: int) -> Dictionary:
	match rar:
		5, 4:
			var pool4: Array = Data.gacha_pool(rar).filter(func(it: ItemData): return it.type != "potion")
			if not pool4.is_empty():
				var it: ItemData = pool4[randi() % pool4.size()]
				GameState.add_item(it.id, 1)
				return {"kind": "item", "id": it.id, "count": 1, "rarity": rar, "name": it.display_name}
		3:
			var pool3: Array = Data.equipment_by_rarity(3)
			if not pool3.is_empty():
				var it3: ItemData = pool3[randi() % pool3.size()]
				GameState.add_item(it3.id, 1)
				return {"kind": "item", "id": it3.id, "count": 1, "rarity": 3, "name": it3.display_name}
	var pid := "p_big" if rar == 2 else "p_small"
	var cnt := 2 if rar == 2 else 3
	GameState.add_item(pid, cnt)
	return {"kind": "item", "id": pid, "count": cnt, "rarity": rar, "name": Data.item(pid).display_name}
