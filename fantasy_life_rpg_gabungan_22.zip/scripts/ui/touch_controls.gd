class_name TouchControls
extends Control
## Kontrol sentuh Android: joystick kiri (melayang atau tetap) + tombol kanan Serang / Skill / Hindar / Interaksi.
## Menangani multi-touch sendiri (tiap jari punya "klaim") dan menyalurkan hasilnya ke InputMap (Input.action_press),
## sehingga kode game cukup memakai Input.is_action_pressed("attack") dst. — sama untuk keyboard, gamepad, dan sentuhan.
## Layar yang tersentuh di luar joystick/tombol dibiarkan untuk kamera (seret = putar, cubit = zoom).

const ACTIONS := ["attack", "skill", "dodge", "interact", "ult"]
const COLORS := {
	"attack": Color(1.0, 0.55, 0.35),
	"skill": Color(0.45, 0.75, 1.0),
	"dodge": Color(0.7, 0.95, 0.6),
	"interact": Color(1.0, 0.85, 0.35),
	"ult": Color(1.0, 0.45, 0.85),
}

var joy_vec := Vector2.ZERO          # nilai joystick saat ini (panjang <= 1)
var interact_ready := false
var ult_visible := false              # true hanya di stage
var interact_visible := true          # false di stage (tidak ada yang diajak bicara)           # true bila ada sesuatu untuk diinteraksi (tombol menyala)
var touch_enabled := true:
	set(v):
		touch_enabled = v
		if not v:
			release_all()
		visible = v

var _joy_touch := -1
var _joy_active := false
var _joy_center := Vector2.ZERO
var _joy_knob := Vector2.ZERO
var _joy_r := 88.0
var _joy_zone := Rect2()
var _fixed_center := Vector2.ZERO
var _driving := false
var _btn: Dictionary = {}             # nama -> {pos, r, touch, cd, cd_max, icon}


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	UiTheme.apply_safe_area(self)
	for a in ACTIONS:
		var ic := UiIcon.make(a, Color(1, 1, 1), 40)
		add_child(ic)
		_btn[a] = {"pos": Vector2.ZERO, "r": 50.0, "touch": -1, "cd": 0.0, "cd_max": 1.0, "icon": ic}
	GameState.changed.connect(func(kind: String): if kind == "settings": layout())
	resized.connect(layout)
	layout()


## Hitung ulang posisi tombol & joystick (ukuran layar / pengaturan tangan kidal berubah).
func layout() -> void:
	var w := size.x
	var h := size.y
	if w < 10.0:
		return
	var left := bool(GameState.setting("left_handed"))
	var bs := float(GameState.setting("btn_size"))
	var js := float(GameState.setting("joy_size"))
	_joy_r = 88.0 * js
	var a_r := 78.0 * bs
	var ring := 170.0 * bs
	var a := Vector2(w - 132.0 * bs - 12.0, h - 124.0 * bs - 8.0)
	var spec := {"attack": [0.0, 0.0, a_r], "skill": [95.0, ring, 54.0 * bs], "interact": [132.0, ring * 1.02, 44.0 * bs], "dodge": [168.0, ring, 48.0 * bs], "ult": [58.0, ring * 1.02, 46.0 * bs]}
	for k in spec:
		var d: Array = spec[k]
		var off: Vector2 = Vector2(cos(deg_to_rad(float(d[0]))), -sin(deg_to_rad(float(d[0])))) * float(d[1])
		var p: Vector2 = a + off
		if left:
			p.x = w - p.x
		var b: Dictionary = _btn[k]
		b["pos"] = p
		b["r"] = d[2]
		var ic: UiIcon = b["icon"]
		var s: float = float(d[2]) * 1.05
		ic.custom_minimum_size = Vector2(s, s)
		ic.size = Vector2(s, s)
		ic.position = p - Vector2(s, s) * 0.5
	var zone_w := minf(w * 0.40, 520.0)
	_joy_zone = Rect2(0, h * 0.30, zone_w, h * 0.70)
	_fixed_center = Vector2(_joy_r + 74.0, h - _joy_r - 56.0)
	if left:
		_joy_zone.position.x = w - zone_w
		_fixed_center.x = w - _fixed_center.x
	queue_redraw()


## Persegi layar yang dipakai kontrol (kamera tidak boleh memutar dari sini).
func blocked_rects() -> Array:
	if not touch_enabled:
		return []
	var out: Array = [_joy_zone]
	for k in _btn:
		if (k == "interact" and not interact_visible) or (k == "ult" and not ult_visible):
			continue
		var b: Dictionary = _btn[k]
		var r: float = b["r"] + 14.0
		out.append(Rect2(b["pos"] - Vector2(r, r), Vector2(r, r) * 2.0))
	return out


## Redupkan tombol (mis. skill saat mana kurang) tanpa menutupnya dengan lingkaran cooldown.
func set_dim(action: String, dim: bool) -> void:
	if _btn.has(action):
		_btn[action]["dim"] = dim


func set_cooldown(action: String, remaining: float, total: float) -> void:
	if _btn.has(action):
		_btn[action]["cd"] = remaining
		_btn[action]["cd_max"] = maxf(total, 0.01)


func release_all() -> void:
	for a in ACTIONS:
		Input.action_release(a)
		if _btn.has(a):
			_btn[a]["touch"] = -1
	_joy_touch = -1
	_joy_active = false
	joy_vec = Vector2.ZERO
	_stop_driving()


func _process(_delta: float) -> void:
	if not touch_enabled:
		return
	_apply_joy()
	queue_redraw()


# ---------------------------------------------------------------- input
func _input(event: InputEvent) -> void:
	if not touch_enabled or not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			_touch_down(st.index, st.position - global_position)
		else:
			_touch_up(st.index)
	elif event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		if sd.index == _joy_touch:
			_joy_move(sd.position - global_position)


func _touch_down(idx: int, pos: Vector2) -> void:
	# tombol aksi lebih dulu (area sedikit diperluas agar mudah ditekan)
	for k in ACTIONS:
		var b: Dictionary = _btn[k]
		if (k == "interact" and not interact_visible) or (k == "ult" and not ult_visible):
			continue
		if b["touch"] == -1 and pos.distance_to(b["pos"]) <= float(b["r"]) * 1.2:
			b["touch"] = idx
			_fire(k, true)
			if bool(GameState.setting("vibrate")):
				Input.vibrate_handheld(18)
			return
	if _joy_touch == -1:
		var fixed := bool(GameState.setting("joy_fixed"))
		if fixed:
			if pos.distance_to(_fixed_center) <= _joy_r * 1.7:
				_joy_start(idx, _fixed_center, pos)
		elif _joy_zone.has_point(pos):
			var c := pos
			c.x = clampf(c.x, _joy_r + 16.0, size.x - _joy_r - 16.0)
			c.y = clampf(c.y, _joy_r + 16.0, size.y - _joy_r - 16.0)
			_joy_start(idx, c, pos)


func _joy_start(idx: int, center: Vector2, pos: Vector2) -> void:
	_joy_touch = idx
	_joy_active = true
	_joy_center = center
	_joy_move(pos)


func _joy_move(pos: Vector2) -> void:
	var off := pos - _joy_center
	var lim := _joy_r
	if off.length() > lim:
		off = off.normalized() * lim
	_joy_knob = off
	var v := off / lim
	joy_vec = Vector2.ZERO if v.length() < 0.12 else v


func _touch_up(idx: int) -> void:
	for k in ACTIONS:
		var b: Dictionary = _btn[k]
		if b["touch"] == idx:
			b["touch"] = -1
			_fire(k, false)
	if idx == _joy_touch:
		_joy_touch = -1
		_joy_active = false
		_joy_knob = Vector2.ZERO
		joy_vec = Vector2.ZERO
		_stop_driving()


## Kirim aksi sebagai InputEventAction agar Input.is_action_just_pressed DAN _unhandled_input(event.is_action_pressed) sama-sama bekerja.
func _fire(action: String, pressed: bool) -> void:
	var ev := InputEventAction.new()
	ev.action = action
	ev.pressed = pressed
	ev.strength = 1.0 if pressed else 0.0
	Input.parse_input_event(ev)


func _apply_joy() -> void:
	if joy_vec == Vector2.ZERO:
		_stop_driving()
		return
	_driving = true
	Input.action_press("move_left", maxf(-joy_vec.x, 0.0))
	Input.action_press("move_right", maxf(joy_vec.x, 0.0))
	Input.action_press("move_up", maxf(-joy_vec.y, 0.0))
	Input.action_press("move_down", maxf(joy_vec.y, 0.0))


func _stop_driving() -> void:
	if _driving:
		_driving = false
		for a in ["move_left", "move_right", "move_up", "move_down"]:
			Input.action_release(a)


# ---------------------------------------------------------------- gambar
func _draw() -> void:
	if not touch_enabled:
		return
	var op := float(GameState.setting("joy_opacity"))
	var base_c := _joy_center if _joy_active else _fixed_center
	if not _joy_active and not bool(GameState.setting("joy_fixed")):
		base_c = Vector2(_joy_zone.position.x + _joy_zone.size.x * 0.5, size.y - _joy_r - 56.0)
	var ga := op * (0.9 if _joy_active else 0.45)
	draw_circle(base_c, _joy_r, Color(0.06, 0.09, 0.22, 0.45 * ga))
	draw_arc(base_c, _joy_r, 0, TAU, 48, Color(0.75, 0.88, 1.0, 0.8 * ga), 4.0, true)
	draw_arc(base_c, _joy_r * 0.55, 0, TAU, 32, Color(0.75, 0.88, 1.0, 0.25 * ga), 2.0, true)
	var knob := base_c + (_joy_knob if _joy_active else Vector2.ZERO)
	draw_circle(knob, _joy_r * 0.42, Color(0.55, 0.75, 1.0, 0.7 * ga))
	draw_arc(knob, _joy_r * 0.42, 0, TAU, 32, Color(1, 1, 1, 0.85 * ga), 3.0, true)
	for k in ACTIONS:
		_btn[k]["icon"].visible = (k != "interact" or interact_visible) and (k != "ult" or ult_visible)
		if (k == "interact" and not interact_visible) or (k == "ult" and not ult_visible):
			continue
		_draw_button(k, op)


func _draw_button(k: String, op: float) -> void:
	var b: Dictionary = _btn[k]
	var p: Vector2 = b["pos"]
	var r: float = b["r"]
	var col: Color = COLORS[k]
	var down: bool = b["touch"] != -1
	var a := clampf(op + 0.25, 0.4, 1.0)
	if b.get("dim", false):
		a *= 0.5
	var glow := 0.0
	if k == "interact":
		if interact_ready:
			glow = 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.008)
		else:
			a *= 0.55
	draw_circle(p, r * (1.08 if down else 1.0), Color(0.06, 0.09, 0.22, 0.7 * a).lerp(col.darkened(0.2), 0.7 if down else glow * 0.6))
	draw_arc(p, r - 2.0, 0, TAU, 40, Color(col.r, col.g, col.b, a), 5.0, true)
	var cd: float = b["cd"]
	if cd > 0.0:
		var frac := clampf(cd / float(b["cd_max"]), 0.0, 1.0)
		var pts := PackedVector2Array([p])
		var steps := 28
		for i in steps + 1:
			var ang := -PI * 0.5 + TAU * frac * float(i) / float(steps)
			pts.append(p + Vector2(cos(ang), sin(ang)) * (r - 3.0))
		if pts.size() >= 3:
			draw_colored_polygon(pts, Color(0, 0, 0, 0.6))
		var f := ThemeDB.fallback_font
		var t := "SUDAH" if k == "ult" else ("%.1f" % cd if cd < 10.0 else str(int(cd)))
		draw_string(f, p + Vector2(-r, 9), t, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 18 if k == "ult" else 26, Color(1, 1, 1, 0.95))
	var ic: UiIcon = b["icon"]
	ic.modulate.a = 0.35 if cd > 0.0 else 1.0
	var want := col.lightened(0.55) if down else Color(1, 1, 1)
	if ic.color != want:
		ic.color = want
