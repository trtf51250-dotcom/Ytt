class_name Hud
extends Control
## HUD lobi: profil + level + EXP, HP, gold, diamond, 8 tombol menu (Character, Party, Inventory, Equipment, Quest, Gacha, Shop, Settings),
## tombol "Start Adventure", pelacak quest, prompt interaksi, jam kota, FPS opsional.

signal menu_pressed(id: String)
signal adventure_pressed
signal interact_pressed
signal profile_pressed
signal map_pressed

const MENU := [
	["quest", "quest", "Quest"],
	["gacha", "gacha", "Gacha"],
	["shop", "shop", "Shop"],
]

var _name_lbl: Label
var _lv_lbl: Label
var _exp_bar: ProgressBar
var _hp_bar: ProgressBar
var _hp_lbl: Label
var _gold_lbl: Label
var _dia_lbl: Label
var _avatar: PanelContainer
var _profile: PanelContainer
var _tracker: PanelContainer
var _tracker_title: Label
var _tracker_sub: Label
var _prompt: PanelContainer
var _prompt_lbl: Label
var _currency: HBoxContainer
var _menu_row: HBoxContainer
var _start_btn: Button
var _time_lbl: Label
var _date_lbl: Label
var _fps_lbl: Label
var _badges: Dictionary = {}
var _buttons: Dictionary = {}
var _more_btn: Button
var minimap: Minimap
var _hp := 1.0
var _hp_max := 1.0


func _ready() -> void:
	theme = UiTheme.get_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	UiTheme.apply_safe_area(self)
	_build_profile()
	_build_tracker()
	_build_currency()
	_build_menu()
	_build_start()
	_build_prompt()
	_build_misc()
	GameState.changed.connect(_on_changed)
	refresh()


# ---------------------------------------------------------------- bangun
func _tappable(c: Control, sig: Callable) -> void:
	c.mouse_filter = Control.MOUSE_FILTER_STOP
	c.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT:
			sig.call())


func _build_profile() -> void:
	_profile = PanelContainer.new()
	_profile.position = Vector2(10, 10)
	_profile.custom_minimum_size = Vector2(330, 0)
	_profile.add_theme_stylebox_override("panel", UiTheme.box(Color(0.07, 0.1, 0.24, 0.88), UiTheme.GOLD_DARK, 2, 16, 10))
	add_child(_profile)
	_tappable(_profile, func(): profile_pressed.emit())
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_profile.add_child(row)
	_avatar = PanelContainer.new()
	_avatar.custom_minimum_size = Vector2(66, 66)
	_avatar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_avatar.add_theme_stylebox_override("panel", UiTheme.box(Color(0.4, 0.6, 1.0), Color(1, 1, 1, 0.9), 3, 33, 6))
	var ic := UiIcon.make("character", Color(1, 1, 1), 46)
	ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_avatar.add_child(ic)
	row.add_child(_avatar)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 3)
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(col)
	var top := HBoxContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_name_lbl = UiTheme.label("Ren", 24, UiTheme.TEXT)
	_name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_lv_lbl = UiTheme.label("Lv 1", 22, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_RIGHT)
	top.add_child(_name_lbl)
	top.add_child(_lv_lbl)
	col.add_child(top)
	_exp_bar = UiTheme.bar(UiTheme.SKY, 0.0, 8.0)
	col.add_child(_exp_bar)
	var hp_row := HBoxContainer.new()
	hp_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hp_row.add_theme_constant_override("separation", 6)
	hp_row.add_child(UiIcon.make("heart", Color(1.0, 0.4, 0.45), 22))
	_hp_bar = UiTheme.bar(Color(0.95, 0.35, 0.4), 1.0, 18.0)
	_hp_bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_hp_bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hp_row.add_child(_hp_bar)
	_hp_lbl = UiTheme.label("100/100", 16, UiTheme.TEXT, HORIZONTAL_ALIGNMENT_RIGHT)
	_hp_lbl.custom_minimum_size = Vector2(76, 0)
	hp_row.add_child(_hp_lbl)
	col.add_child(hp_row)


func _build_tracker() -> void:
	_tracker = PanelContainer.new()
	_tracker.position = Vector2(10, 124)
	_tracker.custom_minimum_size = Vector2(330, 0)
	_tracker.add_theme_stylebox_override("panel", UiTheme.box(Color(0.07, 0.1, 0.24, 0.8), Color(0.45, 0.6, 0.95, 0.8), 2, 14, 10))
	add_child(_tracker)
	_tappable(_tracker, func(): menu_pressed.emit("quest"))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tracker.add_child(row)
	row.add_child(UiIcon.make("scroll", UiTheme.GOLD, 30))
	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(col)
	_tracker_title = UiTheme.label("", 19, UiTheme.TEXT)
	_tracker_title.clip_text = true
	_tracker_title.custom_minimum_size = Vector2(250, 0)
	col.add_child(_tracker_title)
	_tracker_sub = UiTheme.label("", 16, UiTheme.TEXT_DIM)
	_tracker_sub.clip_text = true
	_tracker_sub.custom_minimum_size = Vector2(250, 0)
	col.add_child(_tracker_sub)


func _chip(icon: String, label: Label) -> PanelContainer:
	var p := PanelContainer.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", UiTheme.box(Color(0.07, 0.1, 0.24, 0.88), UiTheme.GOLD_DARK, 2, 20, 10))
	var r := HBoxContainer.new()
	r.add_theme_constant_override("separation", 8)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.add_child(UiIcon.make(icon, Color(1, 1, 1), 30))
	label.custom_minimum_size = Vector2(92, 0)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	r.add_child(label)
	p.add_child(r)
	return p


func _build_currency() -> void:
	_currency = HBoxContainer.new()
	_currency.add_theme_constant_override("separation", 10)
	_currency.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_currency.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	_currency.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_currency.position = Vector2(-10, 10)
	add_child(_currency)
	_gold_lbl = UiTheme.label("0", 24, UiTheme.GOLD)
	_dia_lbl = UiTheme.label("0", 24, Color(0.6, 0.88, 1.0))
	_currency.add_child(_chip("gold", _gold_lbl))
	_currency.add_child(_chip("diamond", _dia_lbl))
	_currency.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 10)


func _build_menu() -> void:
	_menu_row = HBoxContainer.new()
	_menu_row.add_theme_constant_override("separation", 4)
	_menu_row.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	_menu_row.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	add_child(_menu_row)
	for m in MENU:
		var b := _menu_button(m[0], m[1], m[2])
		_menu_row.add_child(b)
		_buttons[m[0]] = b
		b.pressed.connect(func(): menu_pressed.emit(m[0]))
	_menu_row.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 10)
	_menu_row.offset_top = 68.0
	_menu_row.offset_bottom = 140.0
	# tombol "Menu" sebaris dengan Quest/Gacha/Shop: Karakter, Party, Inventori, Equipment, Peta, Login, Misi, Event, Pengaturan ada di dalamnya
	_more_btn = _menu_button("more", "star", "Menu")
	_menu_row.add_child(_more_btn)
	_buttons["more"] = _more_btn
	_more_btn.pressed.connect(func(): menu_pressed.emit("more"))


func _menu_button(id: String, icon: String, label: String) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(72, 72)
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", UiTheme.box(Color(0.1, 0.14, 0.32, 0.9), UiTheme.GOLD_DARK, 2, 14, 4))
	b.add_theme_stylebox_override("hover", UiTheme.box(Color(0.2, 0.26, 0.5, 0.95), UiTheme.GOLD, 2, 14, 4))
	b.add_theme_stylebox_override("pressed", UiTheme.box(Color(0.06, 0.08, 0.2, 0.95), UiTheme.GOLD, 3, 14, 4))
	var v := VBoxContainer.new()
	v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 2)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var ic := UiIcon.make(icon, UiTheme.GOLD, 32)
	ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(ic)
	var l := UiTheme.label(label, 14, UiTheme.TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	v.add_child(l)
	b.add_child(v)
	var badge := Label.new()
	badge.text = "!"
	badge.visible = false
	badge.add_theme_font_size_override("font_size", 15)
	badge.add_theme_stylebox_override("normal", UiTheme.box(Color(0.9, 0.2, 0.25), Color(1, 1, 1), 2, 12, 5))
	badge.position = Vector2(46, -6)
	badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(badge)
	_badges[id] = badge
	return b


func _build_start() -> void:
	_start_btn = UiTheme.accent_button("Start Adventure", UiTheme.GOLD, Vector2(270, 66))
	_start_btn.add_theme_font_size_override("font_size", 26)
	_start_btn.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_start_btn.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_start_btn.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_start_btn.offset_left = -135
	_start_btn.offset_right = 135
	_start_btn.offset_top = -84
	_start_btn.offset_bottom = -18
	var ic := UiIcon.make("flag", Color(1, 1, 1), 34)
	ic.position = Vector2(14, 16)
	_start_btn.add_child(ic)
	_start_btn.text = "     Start Adventure"
	add_child(_start_btn)
	_start_btn.pressed.connect(func(): adventure_pressed.emit())


func _build_prompt() -> void:
	_prompt = PanelContainer.new()
	_prompt.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_prompt.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_prompt.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_prompt.offset_bottom = -102
	_prompt.add_theme_stylebox_override("panel", UiTheme.box(Color(0.08, 0.11, 0.26, 0.93), UiTheme.GOLD, 3, 18, 14))
	_prompt.visible = false
	add_child(_prompt)
	_tappable(_prompt, func(): interact_pressed.emit())
	var r := HBoxContainer.new()
	r.add_theme_constant_override("separation", 10)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_prompt.add_child(r)
	r.add_child(UiIcon.make("interact", UiTheme.GOLD, 30))
	_prompt_lbl = UiTheme.label("", 24, UiTheme.TEXT)
	r.add_child(_prompt_lbl)
	var key := UiTheme.label("[E]", 18, UiTheme.TEXT_DIM)
	key.visible = not DisplayServer.is_touchscreen_available()
	r.add_child(key)


func _build_misc() -> void:
	_time_lbl = UiTheme.label("", 20, UiTheme.TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	_time_lbl.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_time_lbl.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_time_lbl.offset_top = 8
	_time_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_time_lbl.add_theme_color_override("font_outline_color", Color(0.05, 0.08, 0.2, 0.95))
	_time_lbl.add_theme_constant_override("outline_size", 8)
	add_child(_time_lbl)
	# tanggal & jam dunia nyata (jam perangkat) di bawah jam kota
	_date_lbl = UiTheme.label("", 16, Color(0.8, 0.9, 1.0), HORIZONTAL_ALIGNMENT_CENTER)
	_date_lbl.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_date_lbl.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_date_lbl.offset_top = 34
	_date_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_date_lbl.add_theme_color_override("font_outline_color", Color(0.05, 0.08, 0.2, 0.95))
	_date_lbl.add_theme_constant_override("outline_size", 6)
	add_child(_date_lbl)
	_fps_lbl = UiTheme.label("", 16, Color(0.7, 1, 0.7))
	_fps_lbl.position = Vector2(350, 10)
	_fps_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_fps_lbl)


## Minimap kiri-bawah profil: mengikuti pemain, ketuk = buka peta penuh, zoom tetap (tanpa tombol tambahan).
func setup_minimap(lobby: Node3D, player: Node3D, cam: Node) -> void:
	minimap = Minimap.new()
	minimap.name = "Minimap"
	minimap.lobby = lobby
	minimap.player = player
	minimap.cam = cam
	minimap.follow = true
	minimap.position = Vector2(10, 204)
	minimap.size = Vector2(184, 184)
	minimap.custom_minimum_size = Vector2(184, 184)
	minimap.tapped.connect(func() -> void: map_pressed.emit())
	add_child(minimap)


# ---------------------------------------------------------------- data
func _on_changed(kind: String) -> void:
	match kind:
		"profile", "currency", "party", "quest", "roster", "settings", "stage", "login", "events", "daily":
			refresh()


func refresh() -> void:
	var lead := Data.character(GameState.leader())
	_name_lbl.text = GameState.player_name
	_lv_lbl.text = "Lv %d" % GameState.level
	if GameState.level >= GameState.MAX_LEVEL:
		_exp_bar.value = 1.0
	else:
		_exp_bar.value = float(GameState.exp) / float(GameState.exp_needed(GameState.level))
	_gold_lbl.text = _fmt(GameState.gold)
	_dia_lbl.text = _fmt(GameState.diamonds)
	if lead:
		var s: StyleBoxFlat = _avatar.get_theme_stylebox("panel").duplicate()
		s.bg_color = lead.accent.darkened(0.15)
		_avatar.add_theme_stylebox_override("panel", s)
	var rq := GameState.ready_quest_count()
	var qb: Label = _badges["quest"]
	qb.visible = rq > 0
	qb.text = str(rq)
	_update_event_button()
	_update_tracker()
	_fps_lbl.visible = bool(GameState.setting("show_fps"))
	set_hp(_hp, _hp_max)


func _update_tracker() -> void:
	var pick := ""
	var vil: bool = Flow.lobby_map == "village"
	for id in Data.quest_order:
		if GameState.quest_state(id) == "ready" and (Data.quest(id).region == "village") == vil:
			pick = id
			break
	if pick == "":
		for id in Data.quest_order:
			if GameState.quest_state(id) == "active" and (Data.quest(id).region == "village") == vil:
				pick = id
				break
	if pick == "":
		_tracker_title.text = "Semua quest selesai"
		_tracker_sub.text = "Jelajahi stage untuk hadiah."
		return
	var qd: QuestData = Data.quest(pick)
	if GameState.quest_state(pick) == "ready":
		_tracker_title.text = "%s ✔" % qd.title
		_tracker_sub.text = "Selesai! Klaim di menu Quest."
		_tracker_sub.add_theme_color_override("font_color", UiTheme.GOOD)
	else:
		_tracker_title.text = qd.title
		_tracker_sub.text = "%d/%d  %s" % [GameState.quest_progress(pick), qd.amount, qd.hint]
		_tracker_sub.add_theme_color_override("font_color", UiTheme.TEXT_DIM)


func _fmt(n: int) -> String:
	var s := str(n)
	var out := ""
	var c := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		c += 1
		if c % 3 == 0 and i > 0:
			out = "." + out
	return out


func set_hp(hp: float, max_hp: float) -> void:
	_hp = hp
	_hp_max = max_hp
	_hp_bar.value = clampf(hp / maxf(max_hp, 1.0), 0.0, 1.0)
	_hp_lbl.text = "%d/%d" % [int(hp), int(max_hp)]


func set_prompt(text: String) -> void:
	_prompt.visible = text != ""
	if text != "":
		_prompt_lbl.text = text


func more_badge_count() -> int:
	var n := GameState.daily_ready_count() + GameState.ach_ready_count() + GameState.unseen_event_count()
	if GameState.login_claimable():
		n += 1
	return n


func _update_event_button() -> void:
	var n := more_badge_count()
	_badges["more"].visible = n > 0
	_badges["more"].text = str(n)


func set_time_text(t: String) -> void:
	_update_event_button()
	_time_lbl.text = "Jam kota " + t
	_date_lbl.text = real_datetime_text()


const DAYS_ID := ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
const MONTHS_ID := ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]


## Tanggal & jam dunia nyata dari jam perangkat (zona waktu lokal), mis. "Selasa, 3 November 2026 · 09:40".
static func real_datetime_text(d: Dictionary = {}) -> String:
	if d.is_empty():
		d = Time.get_datetime_dict_from_unix_time(int(GameState.now_local()))
	return "%s, %d %s %d · %02d:%02d" % [DAYS_ID[int(d["weekday"]) % 7], int(d["day"]), MONTHS_ID[int(d["month"]) - 1], int(d["year"]), int(d["hour"]), int(d["minute"])]


func set_fps(f: float) -> void:
	if _fps_lbl.visible:
		_fps_lbl.text = "%d FPS" % int(f)


## Persegi layar dari semua kontrol HUD yang bisa disentuh (kamera tidak memutar dari sini).
func blocked_rects() -> Array:
	var out: Array = []
	for c: Control in [_profile, _tracker, _currency, _menu_row, _more_btn, _start_btn, _prompt, minimap]:
		if c != null and c.is_visible_in_tree():
			out.append(c.get_global_rect().grow(8.0))
	return out


func menu_button(id: String) -> Button:
	return _buttons.get(id)


func start_button() -> Button:
	return _start_btn
