class_name PanelHost
extends CanvasLayer
## Mengelola satu panel menu pada satu waktu (membuka berdasarkan id). Panel yang file-nya tidak ada ditampilkan
## sebagai "belum tersedia" (bukan error).

signal opened(id: String)
signal closed

const PANELS := {
	"character": "res://scripts/ui/panels/character_panel.gd",
	"party": "res://scripts/ui/panels/party_panel.gd",
	"inventory": "res://scripts/ui/panels/inventory_panel.gd",
	"equipment": "res://scripts/ui/panels/equipment_panel.gd",
	"quest": "res://scripts/ui/panels/quest_panel.gd",
	"gacha": "res://scripts/ui/panels/gacha_panel.gd",
	"shop": "res://scripts/ui/panels/shop_panel.gd",
	"settings": "res://scripts/ui/panels/settings_panel.gd",
	"stage_select": "res://scripts/ui/panels/stage_panel.gd",
	"smith": "res://scripts/ui/panels/smith_panel.gd",
	"login": "res://scripts/ui/panels/login_panel.gd",
	"event": "res://scripts/ui/panels/event_panel.gd",
	"profile": "res://scripts/ui/panels/profile_panel.gd",
	"daily": "res://scripts/ui/panels/daily_panel.gd",
	"more": "res://scripts/ui/panels/more_panel.gd",
	"story": "res://scripts/ui/panels/story_panel.gd",
	"stats": "res://scripts/ui/panels/stats_panel.gd",
	"collection": "res://scripts/ui/panels/collection_panel.gd",
	"guide": "res://scripts/ui/panels/guide_panel.gd",
	"multiplayer": "res://scripts/ui/panels/multiplayer_panel.gd",
	"map": "res://scripts/ui/panels/map_panel.gd",
	"support": "res://scripts/ui/panels/support_panel.gd",
}
const TITLES := {
	"character": ["Karakter", "character"], "party": ["Party", "party"], "inventory": ["Inventori", "inventory"],
	"equipment": ["Equipment", "equipment"], "quest": ["Quest", "quest"], "gacha": ["Altar Bintang", "gacha"],
	"shop": ["Toko", "shop"], "settings": ["Pengaturan", "settings"], "stage_select": ["Adventure", "flag"], "smith": ["Tempa Senjata", "sword"],
	"login": ["Hadiah Login 3 Hari", "gift"], "event": ["Event", "star"], "profile": ["Profil", "character"], "daily": ["Misi & Pencapaian", "flag"], "more": ["Menu", "star"], "story": ["Cerita", "quest"],
	"stats": ["Statistik", "flag"], "collection": ["Koleksi", "inventory"], "guide": ["Panduan", "quest"], "multiplayer": ["Multiplayer", "party"], "map": ["Peta & Teleport", "flag"],
	"support": ["Dukung Developer", "heart"],
}

var current: BasePanel
var current_id := ""
var context: Dictionary = {}           # mis. {"lobby": Lobby, "player": Player}


func _init() -> void:
	layer = 20
	process_mode = Node.PROCESS_MODE_ALWAYS


func is_open() -> bool:
	return current != null


func open(id: String, args: Dictionary = {}) -> bool:
	if current != null:
		close()
	var p: BasePanel
	var path: String = PANELS.get(id, "")
	if path != "" and ResourceLoader.exists(path):
		var scr: Script = load(path)
		p = scr.new()
	else:
		p = BasePanel.new()
	var t: Array = TITLES.get(id, [id.capitalize(), "star"])
	p.title_text = t[0]
	p.title_icon = t[1]
	p.host = self
	p.args = args
	p.close_requested.connect(close)
	current = p
	current_id = id
	add_child(p)
	Sfx.play("door", 1.4, -6.0)
	opened.emit(id)
	return true


func switch_to(id: String, args: Dictionary = {}) -> void:
	open(id, args)


func close() -> void:
	if current == null:
		return
	var p := current
	var ret: String = p.args.get("return_to", "")
	var ret_args: Dictionary = p.args.get("return_args", {})
	current = null
	current_id = ""
	p.queue_free()
	if ret != "":
		open(ret, ret_args)
	else:
		closed.emit()


func _unhandled_input(event: InputEvent) -> void:
	if current != null and event.is_action_pressed("menu_back"):
		get_viewport().set_input_as_handled()
		close()
