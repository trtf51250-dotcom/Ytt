extends BasePanel
## Pengaturan: Suara, Grafis, Kontrol (joystick/tombol/tangan kidal), Kamera, Lobi (waktu, Uji Animasi), Data (simpan, judul, reset).
## Perubahan langsung berlaku dan disimpan (user://fantasy_life_settings.json).

var _confirm_reset := false
var _tabs: TabContainer


func _init() -> void:
	refresh_on = ["__none__"]


func build() -> void:
	_tabs = TabContainer.new()
	_tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_tabs.add_theme_font_size_override("font_size", 25)
	_tabs.add_theme_color_override("font_selected_color", UiTheme.GOLD)
	_tabs.add_theme_color_override("font_unselected_color", UiTheme.TEXT)
	_tabs.add_theme_stylebox_override("tab_selected", UiTheme.box(Color(0.24, 0.31, 0.62), UiTheme.GOLD, 3, 14, 24))
	_tabs.add_theme_stylebox_override("tab_unselected", UiTheme.box(Color(0.1, 0.13, 0.3), UiTheme.GOLD_DARK, 2, 14, 24))
	_tabs.add_theme_stylebox_override("tab_hovered", UiTheme.box(Color(0.16, 0.2, 0.42), UiTheme.GOLD_DARK, 2, 14, 24))
	_tabs.add_theme_stylebox_override("panel", UiTheme.box(Color(0.05, 0.07, 0.18, 0.55), Color(0, 0, 0, 0), 0, 12, 8))
	_tabs.add_theme_constant_override("h_separation", 10)
	content.add_child(_tabs)
	_tab_audio()
	_tab_graphics()
	_tab_controls()
	_tab_camera()
	_tab_lobby()
	_tab_data()


func _page(title: String) -> VBoxContainer:
	var sc := TouchScroll.new()
	sc.name = title
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var m := MarginContainer.new()
	m.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for side in ["left", "right"]:
		m.add_theme_constant_override("margin_" + side, 10)
	m.add_theme_constant_override("margin_top", 10)
	m.add_theme_constant_override("margin_bottom", 18)
	var v := vbox(10)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	m.add_child(v)
	sc.add_child(m)
	_tabs.add_child(sc)
	return v


## Judul bagian: teks emas + garis tipis.
func _section(parent: Control, text: String) -> void:
	var v := vbox(4)
	var l := lbl(text, 24, UiTheme.GOLD)
	v.add_child(l)
	var line := ColorRect.new()
	line.color = Color(UiTheme.GOLD_DARK, 0.7)
	line.custom_minimum_size = Vector2(0, 2)
	v.add_child(line)
	if parent.get_child_count() > 0:
		var gap := Control.new()
		gap.custom_minimum_size = Vector2(0, 6)
		parent.add_child(gap)
	parent.add_child(v)


## Satu baris pengaturan dalam kartu: kiri = nama + petunjuk, kanan = kontrol (lebar kolom kiri seragam di semua tab).
func _row(parent: Control, text: String, hint: String = "") -> HBoxContainer:
	var c := card(Color(UiTheme.GOLD_DARK, 0.8), Color(0.1, 0.13, 0.3, 0.95))
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var h := hbox(18)
	c.add_child(h)
	var left := vbox(2)
	left.custom_minimum_size = Vector2(330, 0)
	left.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	left.add_child(lbl(text, 23, UiTheme.TEXT))
	if hint != "":
		var hl := wrap_lbl(hint, 16, UiTheme.TEXT_DIM)
		hl.custom_minimum_size = Vector2(320, 0)
		left.add_child(hl)
	h.add_child(left)
	var right := hbox(12)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.alignment = BoxContainer.ALIGNMENT_END
	h.add_child(right)
	parent.add_child(c)
	return right


func _slider(parent: Control, text: String, key: String, lo: float, hi: float, step: float, fmt: String = "%.2f", hint: String = "") -> void:
	var row := _row(parent, text, hint)
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = step
	s.value = float(GameState.setting(key))
	s.custom_minimum_size = Vector2(260, 52)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(s)
	var val := lbl(fmt % s.value, 24, UiTheme.GOLD)
	val.custom_minimum_size = Vector2(86, 0)
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(val)
	s.value_changed.connect(func(v: float):
		val.text = fmt % v
		GameState.set_setting(key, v, false))
	s.drag_ended.connect(func(_c: bool): GameState.flush_settings())


func _switch_style(b: Button) -> void:
	b.add_theme_stylebox_override("normal", UiTheme.box(Color(0.14, 0.17, 0.34), Color(0.5, 0.55, 0.75), 2, 20, 18))
	b.add_theme_stylebox_override("hover", UiTheme.box(Color(0.18, 0.22, 0.42), Color(0.6, 0.65, 0.85), 2, 20, 18))
	b.add_theme_stylebox_override("pressed", UiTheme.box(Color(0.12, 0.42, 0.3), Color(0.55, 1.0, 0.75), 3, 20, 18))
	b.add_theme_stylebox_override("hover_pressed", UiTheme.box(Color(0.14, 0.48, 0.34), Color(0.65, 1.0, 0.8), 3, 20, 18))
	b.add_theme_color_override("font_color", Color(0.75, 0.78, 0.9))
	b.add_theme_color_override("font_pressed_color", Color(0.92, 1.0, 0.95))
	b.add_theme_color_override("font_hover_pressed_color", Color(0.92, 1.0, 0.95))


func _toggle(parent: Control, text: String, key: String, hint: String = "") -> void:
	var row := _row(parent, text, hint)
	var b := Button.new()
	b.toggle_mode = true
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(170, 54)
	b.add_theme_font_size_override("font_size", 22)
	_switch_style(b)
	b.button_pressed = bool(GameState.setting(key))
	b.text = "AKTIF" if b.button_pressed else "MATI"
	b.toggled.connect(func(on: bool):
		Sfx.play("select")
		b.text = "AKTIF" if on else "MATI"
		GameState.set_setting(key, on))
	row.add_child(b)


func _choice(parent: Control, text: String, key: String, options: Array, off: int = 0, hint: String = "", descs: Array = []) -> void:
	var row := _row(parent, text, hint)
	var desc: Label = null
	if not descs.is_empty():
		desc = wrap_lbl("", 17, UiTheme.SKY)
	var buttons: Array = []
	for i in options.size():
		var idx := i
		var b := UiTheme.button(str(options[i]), Vector2(96, 54))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 21)
		b.toggle_mode = true
		b.button_pressed = int(GameState.setting(key)) == idx + off
		b.pressed.connect(func():
			Sfx.play("select")
			GameState.set_setting(key, idx + off)
			for j in buttons.size():
				(buttons[j] as Button).button_pressed = j == idx
			if desc:
				desc.text = String(descs[idx]))
		buttons.append(b)
		row.add_child(b)
	if desc:
		var cur := clampi(int(GameState.setting(key)) - off, 0, descs.size() - 1)
		desc.text = String(descs[cur])
		parent.add_child(desc)


func _tab_audio() -> void:
	var p := _page("Suara")
	_section(p, "Volume")
	_slider(p, "Musik", "music", 0.0, 1.0, 0.05, "%.2f", "Lagu latar lobi, stage, dan bos")
	_slider(p, "Efek suara", "sfx", 0.0, 1.0, 0.05, "%.2f", "Pukulan, skill, UI, langkah")
	p.add_child(wrap_lbl("Musik dan efek suara dibuat khusus untuk game ini, tanpa aset luar.", 17, UiTheme.TEXT_DIM))


func _tab_graphics() -> void:
	var p := _page("Grafis")
	_section(p, "Kualitas")
	_choice(p, "Kualitas grafis", "quality", ["Otomatis", "Lancar", "Sedang", "Bagus", "Klasik"], -1, "", [
		"Otomatis: memilih kualitas terbaik untuk perangkatmu.",
		"Lancar: paling ringan dan stabil - resolusi 3D lebih rendah, bayangan semu, tanpa lampu titik, awan lebih sedikit.",
		"Sedang (bawaan): resolusi menengah, bayangan dekat.",
		"Bagus: resolusi penuh, bayangan halus, anti-aliasing 2x, glow & warna lebih kaya.",
		"Klasik: grafis seperti versi sebelum optimasi, tanpa resolusi dinamis/bayangan semu."])
	_choice(p, "Jarak render", "view_dist", ["Otomatis", "6 chunk", "9 chunk", "12 chunk"], 0, "", [
		"Otomatis: 6 chunk di Lancar, 9 di Sedang, 12 di Bagus (1 chunk = 16 m).",
		"6 chunk (96 m): paling ringan, objek jauh tidak digambar.",
		"9 chunk (144 m): seimbang.",
		"12 chunk (192 m): pemandangan paling jauh."])
	_toggle(p, "Resolusi dinamis", "dyn_res", "Turunkan resolusi 3D otomatis bila FPS jatuh")
	p.add_child(wrap_lbl(Perf.summary(), 16, UiTheme.SKY))
	if OS.is_debug_build():
		p.add_child(wrap_lbl("PERINGATAN: ini build DEBUG (lebih lambat, suara bisa patah-patah). Pasang APK RILIS dari GitHub Actions.", 16, Color(1.0, 0.55, 0.45)))
	_section(p, "Efek")
	_toggle(p, "Bayangan", "shadows", "Tidak aktif pada kualitas Lancar")
	_toggle(p, "Hit-stop", "hit_stop2", "Jeda singkat saat benturan. Bisa terasa seperti patah-patah, jadi mati secara bawaan")
	_toggle(p, "Tampilkan FPS", "show_fps", "Angka FPS di pojok layar")


func _tab_controls() -> void:
	var p := _page("Kontrol")
	_section(p, "Ukuran & tampilan")
	_slider(p, "Ukuran joystick", "joy_size", 0.7, 1.5, 0.05)
	_slider(p, "Transparansi kontrol", "joy_opacity", 0.2, 1.0, 0.05)
	_slider(p, "Ukuran tombol aksi", "btn_size", 0.8, 1.4, 0.05)
	_section(p, "Perilaku")
	_toggle(p, "Joystick tetap", "joy_fixed", "Mati = melayang di tempat jari menyentuh")
	_toggle(p, "Mode kidal", "left_handed", "Tukar sisi joystick dan tombol")
	_toggle(p, "Getar tombol", "vibrate", "Getaran ringan saat menekan tombol aksi")
	_toggle(p, "Paksa kontrol sentuh", "force_touch", "Untuk uji di PC; berlaku saat masuk lobi lagi")


func _tab_camera() -> void:
	var p := _page("Kamera")
	_section(p, "Posisi kamera")
	_slider(p, "Zoom (jarak)", "cam_zoom", 0.5, 1.5, 0.02, "%.2f", "Kecil = dekat")
	_slider(p, "Sudut miring", "cam_pitch", 10.0, 65.0, 1.0, "%.0f°", "Kecil = melihat langit & awan; besar = dari atas")
	_slider(p, "Bidang pandang (FOV)", "cam_fov", 40.0, 70.0, 1.0, "%.0f°")
	_section(p, "Putar kamera")
	_slider(p, "Kepekaan putar", "cam_sens", 0.0, 1.0, 0.05)
	_toggle(p, "Balik sumbu Y", "cam_invert_y", "Seret ke atas = kamera turun")
	p.add_child(btn("Reset kamera ke bawaan", func():
		GameState.set_setting("cam_zoom", 0.82, false)
		GameState.set_setting("cam_pitch", 42.0, false)
		GameState.set_setting("cam_sens", 0.5, false)
		GameState.set_setting("cam_fov", 50.0, false)
		GameState.set_setting("cam_invert_y", false)
		toast("Kamera dikembalikan ke bawaan. Buka ulang tab untuk melihat nilainya."), Vector2(0, 56)))
	p.add_child(wrap_lbl("Seret layar di area kosong untuk memutar kamera, cubit dua jari untuk zoom. PC: Q/R putar, roda mouse zoom, klik kanan + seret.", 17, UiTheme.TEXT_DIM))


func _tab_lobby() -> void:
	var p := _page("Lobi")
	_section(p, "Waktu & langit")
	_choice(p, "Waktu di kota", "time_mode", ["Otomatis", "Siang", "Senja", "Malam"], 0, "Otomatis = siang-malam berjalan pelan")
	_toggle(p, "Awan & matahari bergerak", "sky_life", "Awan 3D melayang, matahari/bulan mengikuti jam")
	_toggle(p, "Bayangan awan di tanah", "cloud_shadows", "Bayangan lembut bergeser (tidak ada di kualitas Lancar)")
	_section(p, "Uji Animasi (karakter di lobi)")
	var player: Player = host.context.get("player") if host and host.context.has("player") else null
	if player == null:
		p.add_child(lbl("Tersedia saat membuka Pengaturan dari lobi.", 18, UiTheme.TEXT_DIM))
		return
	p.add_child(wrap_lbl("Menutup menu lalu memutar animasi pada karakter agar terlihat di layar.", 17, UiTheme.TEXT_DIM))
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	for e in [["Serang 1", "attack1"], ["Serang 2", "attack2"], ["Skill", "skill"], ["ULTI", "ult"], ["Hindar", "dodge"], ["Terkena", "hurt"], ["Belok kiri", "turn_l"], ["Belok kanan", "turn_r"], ["Mati", "death"]]:
		var anim: String = e[1]
		var b := btn(e[0], func():
			host.close()
			player.play_test(anim), Vector2(0, 56))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(b)
	p.add_child(grid)


func _tab_data() -> void:
	var p := _page("Data")
	p.add_child(lbl("Waktu bermain: %s   ·   Level %d   ·   Stage selesai: %d" % [GameState.time_string(), GameState.level, int(GameState.stats["stages_cleared"])], 20, UiTheme.TEXT))
	p.add_child(btn("Simpan sekarang", func():
		GameState.save_game()
		toast("Data tersimpan."), Vector2(0, 56)))
	_section(p, "Simpan otomatis")
	_toggle(p, "Simpan otomatis", "autosave", "Menyimpan progres berkala; juga otomatis saat game ke latar belakang atau ditutup")
	_choice(p, "Jeda simpan otomatis", "autosave_idx", ["30 dtk", "1 mnt", "2 mnt", "5 mnt"], 0, "Makin pendek makin aman bila HP mati mendadak")
	_section(p, "Cadangan & data")
	p.add_child(btn("Salin kode cadangan (terikat perangkat ini)", func():
		var code := GameState.export_code()
		if code == "":
			toast("Tidak ada data untuk dicadangkan.")
			return
		DisplayServer.clipboard_set(code)
		toast("Kode cadangan disalin (%d karakter). Hanya bisa dipulihkan di perangkat INI." % code.length()), Vector2(0, 56)))
	p.add_child(btn("Kembali ke Layar Judul", func():
		GameState.save_game()
		host.close()
		Flow.goto(Flow.SCENE_TITLE, "Kembali ke judul..."), Vector2(0, 56)))
	var reset: Button
	reset = btn("Hapus semua data permainan", func():
		if not _confirm_reset:
			_confirm_reset = true
			reset.text = "Yakin? Ketuk lagi untuk MENGHAPUS semua data"
			return
		GameState.delete_save()
		host.close()
		Flow.goto(Flow.SCENE_TITLE, "Data dihapus..."), Vector2(0, 56))
	reset.add_theme_color_override("font_color", UiTheme.BAD)
	p.add_child(reset)
	p.add_child(wrap_lbl("Data hanya tersimpan di perangkat ini, dalam satu file, tanpa salinan cadangan: setelah dihapus, hilang selamanya. Kode cadangan terikat ke perangkat ini dan hanya bisa dipulihkan di sini setelah data dihapus; kode dari perangkat lain ditolak.", 15, UiTheme.TEXT_DIM))
	_section(p, "Dukung developer")
	p.add_child(btn("Dukung Developer (Saweria)", func(): host.open("support", {"return_to": "settings"}), Vector2(0, 56), Color(1.0, 0.45, 0.6)))
	_section(p, "Deteksi kecurangan")
	var lg: Array = GameState.cheat_log()
	if lg.is_empty():
		p.add_child(lbl("Tidak ada temuan.", 20, UiTheme.TEXT))
	else:
		var last: Dictionary = lg[lg.size() - 1]
		p.add_child(wrap_lbl("%d temuan tercatat. Terakhir: %s (%s)." % [lg.size(), str(CheatGuard.TEXT.get(str(last.get("k", "")), "kecurangan")).trim_suffix("."), str(last.get("t", "")).replace("T", " ")], 18, UiTheme.GOLD))
	p.add_child(wrap_lbl("Game hanya MENDETEKSI dan mencatat (edit data di luar game, jam diputar mundur, nilai tak wajar, kode dari perangkat lain). Tidak ada blokir atau sanksi akun.", 15, UiTheme.TEXT_DIM))
