extends BasePanel
## Dukung Developer: ucapan terima kasih + tombol ke halaman Saweria (dibuka di browser) + salin tautan.
## Dukungan sukarela, tidak memengaruhi permainan (tanpa item / keuntungan khusus).

const PINK := Color(1.0, 0.45, 0.6)


func build() -> void:
	var sl := scroll_list()
	content.add_child(sl[0])
	var p: VBoxContainer = sl[1]

	section(p, "Dukung Developer")
	var c := card(PINK, Color(0.13, 0.12, 0.3, 0.98))
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var v := vbox(10)
	c.add_child(v)
	var heart := UiIcon.make("heart", PINK, 64)
	heart.custom_minimum_size = Vector2(64, 64)
	heart.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(heart)
	var t := UiTheme.label("Terima kasih sudah bermain!", 30, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	v.add_child(t)
	var body := wrap_lbl("Fantasy Life RPG dikembangkan oleh %s. Game ini gratis dan bisa dimainkan offline. Kalau kamu menikmatinya, kamu bisa membantu kelanjutan pengembangannya (karakter, stage, dan fitur baru) lewat Saweria." % Support.DEV_NAME, 20, UiTheme.TEXT)
	body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(body)
	p.add_child(c)

	p.add_child(btn("Dukung via Saweria", _open, Vector2(0, 64), PINK))
	p.add_child(btn("Salin tautan", func():
		Support.copy_link()
		toast("Tautan disalin."), Vector2(0, 54)))

	section(p, "Tautan")
	var link := lbl(Support.URL, 22, UiTheme.SKY)
	link.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	link.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	p.add_child(link)
	p.add_child(wrap_lbl("Tautan dibuka di browser HP / komputermu. Dukungan sepenuhnya sukarela dan tidak memberi item atau keuntungan di dalam game — game tetap bisa dimainkan penuh tanpa mendukung. Boleh juga dukung dengan cara lain: bagikan game ini ke temanmu.", 16, UiTheme.TEXT_DIM))


func _open() -> void:
	if Support.open_page():
		toast("Membuka Saweria di browser...")
	else:
		toast("Browser tidak bisa dibuka. Tautan sudah disalin: %s" % Support.URL)
