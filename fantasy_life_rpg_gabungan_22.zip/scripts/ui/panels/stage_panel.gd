extends BasePanel
## Pilih Stage + ringkasan party. "Mulai" memuat scene stage lewat Flow.start_stage. "Atur Party" membuka panel Party lalu kembali ke sini.

const THEME_NAMES := {"meadow": "Padang rumput", "forest": "Hutan", "cave": "Gua kristal", "boss": "Arena bos", "lair": "Sarang Penguasa Gua", "abyss": "Altar Kehampaan", "temple": "Kuil Bayangan", "chains": "Menara Rantai Merah", "fajar": "Ladang Fajar", "lumbung": "Lumbung Desa", "mist": "Hutan Berkabut", "grove": "Hutan Fajar"}
var selected := ""
var adv := false                    # mode Adventure: tanpa daftar pilih; langsung langkah berikutnya (ulang stage selesai hanya untuk farming)
var _list: VBoxContainer
var _detail: VBoxContainer


func _init() -> void:
	refresh_on = ["stage", "party", "roster", "equipment", "profile"]


func build() -> void:
	var row := hbox(14)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(row)
	var sl := scroll_list(430)
	row.add_child(sl[0])
	_list = sl[1]
	var right := PanelContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_stylebox_override("panel", UiTheme.box(Color(0.08, 0.11, 0.25), UiTheme.GOLD_DARK, 2, 14, 14))
	row.add_child(right)
	_detail = vbox(8)
	right.add_child(_detail)
	adv = bool(args.get("adventure", false))
	selected = str(args.get("stage", ""))
	if adv:
		sl[0].visible = false
		if selected == "":
			selected = GameState.adventure_next()
			if selected == "":
				var done := GameState.adventure_cleared()
				selected = str(done[done.size() - 1]) if not done.is_empty() else ""
	elif selected == "":
		selected = _default_stage()


func _default_stage() -> String:
	var pick := ""
	for id in Data.stage_order:
		if GameState.stage_unlocked(id):
			pick = id
			if not GameState.stage_cleared(id):
				return id
	return pick


func refresh() -> void:
	if adv:
		_fill_detail()
		return
	clear(_list)
	var last_chapter := ""
	for id in Data.stage_order + Data.field_ids:
		var sd: StageData = Data.stage(id)
		var unlocked := GameState.stage_unlocked(id)
		if sd.chapter != last_chapter:
			last_chapter = sd.chapter
			var ch := lbl(sd.chapter, 20, UiTheme.GOLD)
			ch.add_theme_constant_override("outline_size", 0)
			_list.add_child(ch)
		var c := card(UiTheme.GOLD if id == selected else (UiTheme.GOLD_DARK if unlocked else Color(0.3, 0.33, 0.45)), Color(0.2, 0.26, 0.5) if id == selected else Color(0.13, 0.17, 0.36))
		var r := hbox(10)
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		c.add_child(r)
		r.add_child(UiIcon.make("lock" if not unlocked else ("check" if GameState.stage_cleared(id) else "flag"), UiTheme.GOOD if GameState.stage_cleared(id) else (UiTheme.GOLD if unlocked else UiTheme.TEXT_DIM), 38))
		var col := vbox(0)
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.mouse_filter = Control.MOUSE_FILTER_IGNORE
		col.add_child(lbl(sd.display_name, 22, UiTheme.TEXT if unlocked else UiTheme.TEXT_DIM))
		var stars := int(GameState.stages.get(id, {}).get("stars", 0))
		var sub := "%s · Rek. Lv %d" % [THEME_NAMES.get(sd.theme, sd.theme), sd.recommended_level]
		col.add_child(lbl(sub, 16, UiTheme.TEXT_DIM))
		r.add_child(col)
		var is_field: bool = str(id).begins_with("f_")
		var st := lbl("Jelajah" if (is_field and unlocked) else (stars_text(stars, 3) if GameState.stage_cleared(id) else ("" if unlocked else "Terkunci")), 20, UiTheme.GOLD if unlocked else UiTheme.TEXT_DIM)
		r.add_child(st)
		tap_on(c, func():
			selected = id
			refresh())
		_list.add_child(c)
	_fill_detail()


func _fill_detail() -> void:
	clear(_detail)
	if selected == "" or Data.stage(selected) == null:
		return
	var sd: StageData = Data.stage(selected)
	var unlocked := GameState.stage_unlocked(selected)
	if adv:
		var nxt := GameState.adventure_next()
		var total := (Data.village_order if Flow.lobby_map == "village" else Data.adventure_order).size()
		var done_n := GameState.adventure_cleared().size()
		var head := ("Kisah Desa Fajar" if Flow.lobby_map == "village" else "Adventure") + "  ·  %d / %d langkah selesai" % [done_n, total]
		if nxt == "":
			head = ("Kisah Desa Fajar tamat" if Flow.lobby_map == "village" else "Adventure tamat") + "  ·  %d / %d (ulangi stage mana saja untuk farming)" % [done_n, total]
		_detail.add_child(lbl(head, 17, UiTheme.SKY))
		var step_txt := "Langkah berikutnya" if selected == nxt else "Mengulang (farming)"
		_detail.add_child(lbl("%s  ·  %s" % [step_txt, sd.chapter], 17, UiTheme.GOOD if selected == nxt else UiTheme.TEXT_DIM))
	_detail.add_child(lbl(sd.display_name, 30, UiTheme.GOLD))
	var enemies := 0
	for w: Dictionary in sd.waves:
		for k in w:
			enemies += int(w[k])
	var is_f: bool = selected.begins_with("f_")
	var info := "%s · %d gelombang · %d monster%s" % [THEME_NAMES.get(sd.theme, sd.theme), sd.waves.size(), enemies, " + BOS" if sd.boss != "" else ""]
	if is_f:
		info = "%s · jelajah bebas · kalahkan %d monster untuk menaklukkan" % [THEME_NAMES.get(sd.theme, sd.theme), Stage.FIELD_GOAL]
	_detail.add_child(lbl(info, 18, UiTheme.SKY))
	_detail.add_child(wrap_lbl(sd.description, 19, UiTheme.TEXT_DIM))
	var rw := "Hadiah:  %d gold  ·  %d EXP" % [sd.reward_gold, sd.reward_exp]
	if is_f:
		rw = "Hadiah: gold & EXP tiap monster, peti harta, area rahasia"
		if not GameState.stage_cleared(selected):
			rw = "Tamat: %d gold · %d EXP · %d diamond  +  gold/EXP tiap monster, peti, area rahasia" % [sd.reward_gold, sd.reward_exp, sd.first_clear_diamond]
	elif sd.reward_diamond > 0 or sd.first_clear_diamond > 0:
		rw += "  ·  %d diamond" % (sd.reward_diamond + (0 if GameState.stage_cleared(selected) else sd.first_clear_diamond))
	_detail.add_child(lbl(rw, 20, UiTheme.GOLD))
	var sep := Control.new()
	sep.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_detail.add_child(sep)
	_detail.add_child(lbl("Party kamu  (Kekuatan %d)" % GameState.party_power(), 20, UiTheme.TEXT))
	var pr := hbox(8)
	for i in GameState.PARTY_SIZE:
		var pc := card(UiTheme.GOLD if i == 0 else UiTheme.GOLD_DARK)
		pc.custom_minimum_size = Vector2(118, 0)
		var v := vbox(0)
		pc.add_child(v)
		if i < GameState.party.size():
			var cid: String = GameState.party[i]
			var cd := Data.character(cid)
			var av := PanelContainer.new()
			av.custom_minimum_size = Vector2(46, 46)
			av.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
			av.add_theme_stylebox_override("panel", UiTheme.box(cd.accent.darkened(0.15), Color(1, 1, 1, 0.8), 2, 23, 4))
			var ic := UiIcon.make("character", Color(1, 1, 1), 28)
			ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
			ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			av.add_child(ic)
			v.add_child(av)
			var nm := lbl(cd.display_name + (" ♛" if i == 0 else ""), 18, UiTheme.TEXT)
			nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			v.add_child(nm)
			var pw := lbl("%s  %d" % [cd.role, GameState.char_stats(cid)["power"]], 14, UiTheme.TEXT_DIM)
			pw.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			v.add_child(pw)
		else:
			var e := lbl("kosong", 18, UiTheme.TEXT_DIM)
			e.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			e.custom_minimum_size = Vector2(0, 76)
			e.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			v.add_child(e)
		pr.add_child(pc)
	_detail.add_child(pr)
	var warn := ""
	if GameState.char_stats(GameState.leader())["power"] < sd.recommended_level * 40:
		warn = "Peringatan: levelmu di bawah rekomendasi stage ini."
	if GameState.level < sd.recommended_level:
		warn = "Peringatan: level kamu (Lv %d) di bawah rekomendasi (Lv %d)." % [GameState.level, sd.recommended_level]
	if warn != "":
		_detail.add_child(lbl(warn, 17, UiTheme.BAD))
	if adv:
		var done2 := GameState.adventure_cleared()
		if not done2.is_empty():
			var fr := hbox(8)
			var cur := done2.find(selected)
			fr.add_child(btn("◀ Ulangi sebelumnya", func():
				selected = str(done2[(cur - 1 + done2.size()) % done2.size()] if cur >= 0 else done2[done2.size() - 1])
				refresh(), Vector2(0, 50)))
			if selected != GameState.adventure_next() and GameState.adventure_next() != "":
				fr.add_child(btn("Lanjutkan Adventure", func():
					selected = GameState.adventure_next()
					refresh(), Vector2(0, 50), UiTheme.GOLD))
			if cur >= 0:
				fr.add_child(btn("Ulangi berikutnya ▶", func():
					selected = str(done2[(cur + 1) % done2.size()])
					refresh(), Vector2(0, 50)))
			for b in fr.get_children():
				b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			_detail.add_child(fr)
	var br := hbox(10)
	br.add_child(btn("Atur Party", func(): host.open("party", {"return_to": "stage_select", "return_args": {"stage": selected, "adventure": adv}}), Vector2(180, 62)))
	var go_text := ("Jelajahi!" if is_f else "Mulai!")
	if adv and selected == GameState.adventure_next():
		go_text = "Lanjutkan!"
	elif adv and GameState.stage_cleared(selected):
		go_text = "Ulangi!"
	var go := btn(go_text if unlocked else "Terkunci", _start, Vector2(0, 62), UiTheme.GOLD)
	go.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	go.disabled = not unlocked
	br.add_child(go)
	_detail.add_child(br)
	if not unlocked:
		var prev := Data.stage(sd.unlock_after)
		_detail.add_child(lbl("Selesaikan dulu: %s" % (prev.display_name if prev else "?"), 17, UiTheme.BAD))


func _start() -> void:
	var id := selected
	host.close()
	Flow.start_stage(id)
