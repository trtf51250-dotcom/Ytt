extends BasePanel
## Altar Bintang: tarik 1x (100 diamond) atau 10x (900 diamond). Peluang ditampilkan jujur; hasil dimasukkan ke inventori / pecahan karakter.

var _results: GridContainer
var _pity: Label
var _dia: Label
var _b1: Button
var _b10: Button
var _status: Label
var _left: VBoxContainer
var _tabs: HBoxContainer
var _banner := ""
var _pool := Gacha.POOL_CHAR       # gacha yang sedang dibuka: "char" / "item"
var _pool_tabs: HBoxContainer
var _sig := ""
var _cd_lbl: Label
var _pity_bar: ProgressBar
var _reveal: GachaReveal
var _last_n := 1
var _hint: Label


func _init() -> void:
	refresh_on = ["currency", "profile", "inventory"]


func build() -> void:
	var want := str(args.get("banner", ""))
	if want != "" and LiveEvents.is_active(want):
		_banner = want
	if str(args.get("pool", "")) == Gacha.POOL_ITEM and _banner == "":
		_pool = Gacha.POOL_ITEM
	var row := hbox(16)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(row)
	var left := PanelContainer.new()
	left.custom_minimum_size = Vector2(400, 0)
	left.add_theme_stylebox_override("panel", UiTheme.box(Color(0.08, 0.1, 0.3), UiTheme.GOLD_DARK, 2, 14, 14))
	row.add_child(left)
	var lsc := TouchScroll.new()
	lsc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	left.add_child(lsc)
	_left = vbox(8)
	_left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lsc.add_child(_left)
	var tm := Timer.new()
	tm.wait_time = 1.0
	tm.autostart = true
	tm.timeout.connect(_tick)
	add_child(tm)
	var right := vbox(10)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(right)
	_pool_tabs = hbox(8)
	right.add_child(_pool_tabs)
	_tabs = hbox(8)
	right.add_child(_tabs)
	var top := hbox(8)
	_status = lbl("Pilih jumlah tarikan.", 22, UiTheme.TEXT)
	_status.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(_status)
	top.add_child(UiIcon.make("diamond", Color(1, 1, 1), 30))
	_dia = lbl("", 24, Color(0.6, 0.88, 1.0))
	top.add_child(_dia)
	right.add_child(top)
	_hint = wrap_lbl("", 20, UiTheme.TEXT_DIM)
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_hint.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(_hint)
	var sc := TouchScroll.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_results = GridContainer.new()
	_results.columns = 5
	_results.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_results.add_theme_constant_override("h_separation", 8)
	_results.add_theme_constant_override("v_separation", 8)
	sc.add_child(_results)
	right.add_child(sc)
	var br := hbox(12)
	_b1 = btn("Tarik ×1   (%d diamond)" % Gacha.cost(1), func(): _do(1), Vector2(0, 66), UiTheme.BLUE)
	_b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_b10 = btn("Tarik ×10   (%d diamond)" % Gacha.cost(10), func(): _do(10), Vector2(0, 66), UiTheme.GOLD)
	_b10.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	br.add_child(_b1)
	br.add_child(_b10)
	right.add_child(br)


## Area hasil kosong diisi petunjuk nyata (karakter yang belum dimiliki / jarak pity) sebelum ada tarikan.
func _update_hint() -> void:
	if _hint == null:
		return
	var empty := _results.get_child_count() == 0
	_hint.visible = empty
	if not empty:
		return
	var txt := "Hasil tarikan akan muncul di sini."
	if _pool == Gacha.POOL_CHAR:
		var missing: PackedStringArray = []
		for id in Data.character_ids():
			if not GameState.is_unlocked(id):
				missing.append(Data.character(id).display_name)
		if missing.size() > 0:
			txt += "\n\nBelum kamu miliki (%d): %s" % [missing.size(), ", ".join(missing)]
		else:
			txt += "\n\nSemua karakter sudah dimiliki. Duplikat menjadi Pecahan Jiwa."
	txt += "\n\nTarikan tanpa ★%d: %d dari %d." % [Gacha.top_of(_pool), Gacha.pity_of(_pool), Gacha.pity_limit(_pool)]
	_hint.text = txt


func _banner_ev() -> Dictionary:
	return LiveEvents.find(_banner) if _banner != "" else {}


func _build_pool_tabs() -> void:
	clear(_pool_tabs)
	for e in [[Gacha.POOL_CHAR, "Gacha Karakter", "character"], [Gacha.POOL_ITEM, "Gacha Perlengkapan", "sword"]]:
		var pid: String = e[0]
		var on := _pool == pid
		var b := btn(str(e[1]), func():
			if _reveal != null and is_instance_valid(_reveal):
				return
			_pool = pid
			if pid == Gacha.POOL_ITEM:
				_banner = ""
			_sig = ""
			clear(_results)
			_status.text = "Pilih jumlah tarikan."
			refresh(), Vector2(0, 54), UiTheme.GOLD if on else Color(0.25, 0.3, 0.55))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_pool_tabs.add_child(b)


func _build_left() -> void:
	clear(_left)
	_cd_lbl = null
	var ev := _banner_ev() if _pool == Gacha.POOL_CHAR else {}
	if ev.is_empty():
		var star := UiIcon.make("star" if _pool == Gacha.POOL_CHAR else "sword", UiTheme.GOLD, 100)
		star.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		_left.add_child(star)
		var t := lbl("Panggilan Jiwa" if _pool == Gacha.POOL_CHAR else "Panggilan Perlengkapan", 28, UiTheme.GOLD)
		t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_left.add_child(t)
		var sub0 := lbl("Karakter & Pecahan Jiwa" if _pool == Gacha.POOL_CHAR else "Senjata, armor, aksesori & ramuan", 17, UiTheme.SKY)
		sub0.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_left.add_child(sub0)
	else:
		var cd := Data.character(ev["character"])
		var ic := UiIcon.make("character", cd.accent.lightened(0.2), 56)
		ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		_left.add_child(ic)
		var t2 := lbl(str(ev["title"]), 24, cd.accent.lightened(0.35))
		t2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_left.add_child(t2)
		var sub := lbl("%s · %s" % [cd.display_name, cd.role], 18, UiTheme.SKY)
		sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_left.add_child(sub)
		_cd_lbl = lbl(LiveEvents.countdown_text(ev), 20, Color(1.0, 0.85, 0.4))
		_cd_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_left.add_child(_cd_lbl)
	_left.add_child(HSeparator.new())
	_left.add_child(lbl("Peluang tiap tarikan:", 18, UiTheme.TEXT))
	var names: Dictionary
	if _pool == Gacha.POOL_CHAR:
		names = {6: "★6  Karakter legendaris (Hakuya)", 5: "★5  Karakter (Vael, Lucien, Aion, Kyomu)", 4: "★4  Karakter (Sera, Zeya, Lyra, Wenyu, Kuroha)", 3: "★3  Karakter (Ren, Brann) / Pecahan Jiwa ×3"}
	else:
		names = {5: "★5  Perlengkapan legendaris", 4: "★4  Perlengkapan epik", 3: "★3  Perlengkapan langka", 2: "★2  Ramuan Besar ×2", 1: "★1  Ramuan Kecil ×3"}
	for e: Array in Gacha.rates(_pool):
		var line := "%s   %s%%" % [names[e[0]], String.num(float(e[1]) * 100.0, 1).trim_suffix(".0")]
		_left.add_child(wrap_lbl(line, 16, UiTheme.RARITY[int(e[0]) - 1]))
	if _pool == Gacha.POOL_CHAR:
		_left.add_child(wrap_lbl("Karakter yang sudah dimiliki berubah jadi Pecahan Jiwa (★6 ×20, ★4 ×5, ★3 ×3) untuk menaikkan bintang di menu Karakter.", 15, UiTheme.TEXT_DIM))
	if not ev.is_empty():
		var cd2 := Data.character(ev["character"])
		var share := int(round(float(ev["featured_share"]) * 100.0))
		_left.add_child(wrap_lbl("Banner event: %d%% dari hasil ★4 adalah karakter %s (≈ %.1f%% per tarikan). Jika sudah dimiliki → Pecahan Jiwa ×5. %s tidak bisa ditarik lagi setelah event berakhir." % [share, cd2.display_name, 13.5 * share / 100.0, cd2.display_name], 15, Color(1.0, 0.85, 0.4)))
	_left.add_child(wrap_lbl("10x menjamin minimal satu ★4. Setelah %d tarikan tanpa ★%d di gacha ini, tarikan berikutnya pasti ★%d (hitungan pity tiap gacha terpisah)." % [Gacha.pity_limit(_pool), Gacha.top_of(_pool), Gacha.top_of(_pool)], 15, UiTheme.TEXT_DIM))
	_pity = lbl("", 18, UiTheme.SKY)
	_left.add_child(_pity)
	_pity_bar = UiTheme.bar(UiTheme.GOLD, 0.0, 12.0)
	_left.add_child(_pity_bar)


func _build_tabs() -> void:
	clear(_tabs)
	var banners := LiveEvents.active_banners()
	if banners.is_empty() or _pool != Gacha.POOL_CHAR:
		_tabs.visible = false
		return
	_tabs.visible = true
	_tabs.add_child(btn("Standar", func():
		_banner = ""
		_sig = ""
		refresh(), Vector2(150, 46), UiTheme.GOLD if _banner == "" else Color(0, 0, 0, 0)))
	for ev: Dictionary in banners:
		var eid: String = ev["id"]
		_tabs.add_child(btn("Event: %s" % Data.character(ev["character"]).display_name, func():
			_banner = eid
			_sig = ""
			refresh(), Vector2(210, 46), Color(1.0, 0.6, 0.3) if _banner == eid else Color(0, 0, 0, 0)))


## Tiap detik: perbarui hitung mundur; bila event dimulai/berakhir, bangun ulang banner.
func _tick() -> void:
	if _banner != "" and not LiveEvents.is_active(_banner):
		var old := _banner_ev()
		_banner = ""
		toast("Event %s telah berakhir." % str(old.get("title", "")))
	var sig := _pool + _banner + "|" + ",".join(LiveEvents.active_banners().map(func(e): return e["id"]))
	if sig != _sig:
		refresh()
		return
	if _cd_lbl != null and is_instance_valid(_cd_lbl):
		_cd_lbl.text = LiveEvents.countdown_text(_banner_ev())


func refresh() -> void:
	if _banner != "" and not LiveEvents.is_active(_banner):
		_banner = ""
	_sig = _pool + _banner + "|" + ",".join(LiveEvents.active_banners().map(func(e): return e["id"]))
	_build_pool_tabs()
	_build_tabs()
	_build_left()
	_dia.text = str(GameState.diamonds)
	var pt := Gacha.pity_of(_pool)
	_pity.text = "★%d pasti dalam %d tarikan lagi" % [Gacha.top_of(_pool), maxi(Gacha.pity_limit(_pool) - pt, 1)]
	_pity_bar.value = float(pt) / float(Gacha.pity_limit(_pool))
	_update_hint()
	_b1.disabled = not Gacha.can_afford(1)
	_b10.disabled = not Gacha.can_afford(10)


func _do(n: int) -> void:
	if _reveal != null and is_instance_valid(_reveal):
		return
	var res := Gacha.pull(n, _banner if _pool == Gacha.POOL_CHAR else "", _pool)
	if res.is_empty():
		if _banner != "" and not LiveEvents.is_active(_banner):
			toast("Event sudah berakhir. Banner ditutup.")
			refresh()
		else:
			toast("Diamond tidak cukup.")
		return
	var best := 1
	for r: Dictionary in res:
		best = maxi(best, int(r["rarity"]))
	_last_n = n
	_status.text = "Hasil %d tarikan:" % n
	clear(_results)
	if _hint != null:
		_hint.visible = false
	for r: Dictionary in res:
		var c := card(UiTheme.RARITY[int(r["rarity"]) - 1].darkened(0.1), Color(0.13, 0.17, 0.36))
		c.custom_minimum_size = Vector2(150, 118)
		var v := vbox(2)
		c.add_child(v)
		var ic_kind := "diamond"
		if r["kind"] == "item":
			ic_kind = item_icon_kind(Data.item(r["id"]))
		var ic := UiIcon.make(ic_kind, UiTheme.RARITY[int(r["rarity"]) - 1], 40)
		ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		v.add_child(ic)
		var nm := wrap_lbl(str(r["name"]), 16, UiTheme.TEXT)
		nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(nm)
		var ct := lbl("%s  ×%d" % [stars_text(int(r["rarity"]), int(r["rarity"])), int(r["count"])], 15, UiTheme.RARITY[int(r["rarity"]) - 1])
		ct.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(ct)
		_results.add_child(c)

	# upacara pemanggilan (hasil sudah diterapkan di atas; melewati animasi tidak mengubah hasil)
	_reveal = GachaReveal.new()
	_reveal.setup(res)
	add_child(_reveal)
	_reveal.finished.connect(func():
		var again := _reveal.wants_again
		_reveal = null
		if again:
			if Gacha.can_afford(_last_n):
				_do(_last_n)
			else:
				toast("Diamond tidak cukup."))
