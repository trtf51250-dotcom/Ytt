class_name StoryPlayer
extends CanvasLayer
## Pemutar adegan cerita: kotak dialog di bawah, nama pembicara berwarna, teks mengetik, ketuk untuk lanjut, tombol "Lewati".
## Memakai jeda pohon scene selama diputar (game berhenti, UI tetap jalan). Pakai:  await StoryPlayer.play(self, "prolog")
## Pada uji otomatis (--bot=1) adegan dilewati seketika kecuali ada argumen --story=1.

const COLORS := {
	"Ren": Color(0.55, 0.85, 1.0), "Lyra": Color(0.8, 0.6, 1.0), "Brann": Color(1.0, 0.7, 0.4), "Master Orwen": Color(0.6, 0.95, 0.6),
	"Narator": Color(0.82, 0.84, 0.95), "Golem Kristal": Color(1.0, 0.5, 0.5), "Dewa Wither": Color(0.85, 0.45, 1.0),
	"Uranos": Color(0.75, 0.5, 1.0), "Raja Rantai Merah": Color(1.0, 0.35, 0.4), "Pengikut Berkerudung": Color(0.95, 0.6, 0.65),
	"Arunika": Color(0.55, 1.0, 0.65), "Pak Wiryo": Color(1.0, 0.85, 0.5), "Mbah Kerto": Color(0.85, 0.8, 0.65), "Jaka": Color(0.7, 0.85, 0.55),
}

signal finished

var _scene: Dictionary
var _i := 0
var _name: Label
var _text: RichTextLabel
var _more: Label
var _prog: Label
var _typing := false
var _tween: Tween
var _was_paused := false
var _done := false


## Putar adegan id. force = true: putar ulang walau sudah pernah dibaca (dari menu Cerita). Selesai saat adegan ditutup.
static func play(host: Node, id: String, force: bool = false) -> void:
	var sc := Story.get_scene(id)
	if sc.is_empty() or (Story.seen(id) and not force):
		return
	var args := OS.get_cmdline_user_args()
	if args.has("--bot=1") and not args.has("--story=1"):
		Story.mark_seen(id)
		return
	var sp := StoryPlayer.new()
	sp._scene = sc
	host.get_tree().root.add_child.call_deferred(sp)
	await sp.finished
	sp.queue_free()


func _ready() -> void:
	layer = 40
	process_mode = Node.PROCESS_MODE_ALWAYS
	_was_paused = get_tree().paused
	get_tree().paused = true
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.theme = UiTheme.get_theme()
	root.gui_input.connect(_on_input)
	add_child(root)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.1, 0.45)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dim)
	var title := UiTheme.label(str(_scene.get("title", "")), 30, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	title.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	title.offset_left = -400
	title.offset_right = 400
	title.offset_top = 130
	title.add_theme_color_override("font_outline_color", Color(0.02, 0.03, 0.1, 0.95))
	title.add_theme_constant_override("outline_size", 8)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(title)
	var ch := str(_scene.get("chapter", ""))
	if ch != "":
		var cl := UiTheme.label(ch, 20, UiTheme.SKY, HORIZONTAL_ALIGNMENT_CENTER)
		cl.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
		cl.offset_left = -400
		cl.offset_right = 400
		cl.offset_top = 172
		cl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		root.add_child(cl)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiTheme.box(Color(0.06, 0.08, 0.22, 0.94), UiTheme.GOLD, 2, 16, 16))
	panel.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	panel.offset_left = 40
	panel.offset_right = -40
	panel.offset_top = -210
	panel.offset_bottom = -24
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(v)
	_name = UiTheme.label("", 26, UiTheme.GOLD)
	_name.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(_name)
	_text = RichTextLabel.new()
	_text.bbcode_enabled = false
	_text.fit_content = false
	_text.scroll_active = false
	_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_text.add_theme_font_size_override("normal_font_size", 22)
	_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(_text)
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(row)
	_prog = UiTheme.label("", 16, UiTheme.TEXT_DIM)
	_prog.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_prog.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(_prog)
	_more = UiTheme.label("Ketuk untuk lanjut ▶", 16, UiTheme.SKY, HORIZONTAL_ALIGNMENT_RIGHT)
	_more.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(_more)
	var skip := UiTheme.button("Lewati", Vector2(120, 44))
	skip.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	skip.offset_left = -140
	skip.offset_right = -20
	skip.offset_top = 20
	skip.offset_bottom = 64
	skip.pressed.connect(_finish)
	root.add_child(skip)
	_show()


func _show() -> void:
	var lines: Array = _scene["lines"]
	var ln: Dictionary = lines[_i]
	var who := str(ln["s"])
	_name.text = who
	_name.add_theme_color_override("font_color", COLORS.get(who, UiTheme.GOLD))
	_text.text = str(ln["t"])
	_text.visible_characters = 0
	_prog.text = "%d / %d" % [_i + 1, lines.size()]
	_more.visible = false
	_typing = true
	if _tween:
		_tween.kill()
	var n := _text.get_total_character_count()
	_tween = create_tween()
	_tween.tween_property(_text, "visible_characters", n, maxf(n * 0.02, 0.05))
	_tween.finished.connect(_typed)
	Sfx.play("dialog", randf_range(0.95, 1.1))


func _typed() -> void:
	_typing = false
	_text.visible_characters = -1
	_more.visible = true


func advance() -> void:
	if _done:
		return
	if _typing:
		if _tween:
			_tween.kill()
		_typed()
		return
	_i += 1
	if _i >= (_scene["lines"] as Array).size():
		_finish()
	else:
		_show()


func _on_input(ev: InputEvent) -> void:
	if (ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT) or (ev is InputEventScreenTouch and ev.pressed):
		advance()


func _unhandled_key_input(ev: InputEvent) -> void:
	if ev is InputEventKey and ev.pressed and ev.keycode in [KEY_SPACE, KEY_ENTER]:
		advance()


func _finish() -> void:
	if _done:
		return
	_done = true
	if _tween:
		_tween.kill()
	Story.mark_seen(str(_scene["id"]))
	get_tree().paused = _was_paused
	finished.emit()
