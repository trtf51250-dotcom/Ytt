class_name CoopSync
extends Node
## Sinkronisasi co-op di dalam Stage. Model: HOST yang menjalankan semua AI musuh, gelombang, bos & hasil akhir (otoritatif).
## CLIENT menjalankan pemain sendiri (gerak/serangan lokal), lalu: (1) mengirim posisinya, (2) mengirim damage ke musuh sebagai RPC "_hit",
## (3) menampilkan musuh sebagai "puppet" (Enemy.puppet) yang mengikuti snapshot host ~10 kali/detik, (4) menerima luka via "_hurt".
## Pemain lain tampil sebagai CoopGhost. Musuh menargetkan pemain/ghost terdekat yang masih hidup (khusus di host).

const SNAP_DT := 0.1
const PSTATE_DT := 0.066

var stage: Stage
var host := false
var ghosts: Dictionary = {}          # peer_id -> CoopGhost
var enemies: Dictionary = {}         # net_id -> Enemy
var ready_peers: Dictionary = {}
var peer_info: Dictionary = {}       # host: peer -> array pstate terakhir
var hp_scale := 1.0
var _next_id := 1
var _snap_t := 0.0
var _ps_t := 0.0
var _retarget_t := 0.0
var _label: Label
var _lost := false
var _snap_count := 0
var stat_snaps := 0
var stat_client_hits := 0       # host: jumlah RPC damage yang diterima dari client
var stat_hurt := 0              # client: luka dari host yang diterima
var stat_spawns := 0            # client: musuh puppet yang dibuat
# --- PVP
const PVP_TIME := 150.0
var pvp := false
var pvp_live := false           # pertarungan sudah dimulai (setelah hitung mundur)
var pvp_left := PVP_TIME
var pvp_kills: Dictionary = {}  # peer -> jumlah kill
var pvp_down: Dictionary = {}   # peer -> true bila tersingkir
var last_attacker := 0
var _pvp_sync_t := 0.0
var _pvp_over := false
var _pvp_started := false
var stat_pvp_hits_sent := 0
var stat_pvp_hurt := 0


func setup(p_stage: Stage) -> void:
	stage = p_stage
	host = Net.is_host()
	Net.coop = self
	hp_scale = 1.0 + 0.6 * float(maxi(Net.member_count() - 1, 0))
	pvp = stage.pvp
	if pvp:
		var ids: Array = Net.members.keys()
		ids.sort()
		var idx := maxi(ids.find(Net.my_id()), 0)
		var a := TAU * float(idx) / float(maxi(ids.size(), 1))
		var sp := Vector3(sin(a), 0.1, cos(a)) * stage.arena.radius * 0.55
		stage.player.global_position = sp
		stage.player.facing = atan2(-sp.x, -sp.z)
		for id in ids:
			pvp_kills[int(id)] = 0
	for id in Net.members:
		if int(id) != Net.my_id():
			_ensure_ghost(int(id))
	stage.player.action_started.connect(_on_my_action)
	_label = Label.new()
	_label.add_theme_font_size_override("font_size", 18)
	_label.add_theme_color_override("font_color", Color(0.7, 0.95, 1.0))
	_label.add_theme_color_override("font_outline_color", Color(0, 0.05, 0.15))
	_label.add_theme_constant_override("outline_size", 6)
	_label.position = Vector2(12, 8)
	if pvp:
		_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
		_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_label.position = Vector2(-160, 70)
		_label.custom_minimum_size = Vector2(320, 0)
	stage.ui.add_child(_label)
	_update_label()


func _exit_tree() -> void:
	if Net.coop == self:
		Net.coop = null


func _update_label() -> void:
	if _label != null:
		if pvp:
			var t := "PVP · %s · sisa %d:%02d" % [Net.room_name, int(pvp_left) / 60, int(pvp_left) % 60]
			var ids: Array = Net.members.keys()
			ids.sort()
			for id in ids:
				t += "\n%s%s  %d" % ["(tersingkir) " if pvp_down.has(int(id)) else "", str(Net.members[id].get("name", "?")), int(pvp_kills.get(int(id), 0))]
			_label.text = t
			return
		_label.text = "CO-OP · %s · %d pemain%s" % [Net.room_name, Net.member_count(), "" if host else "  (host: %s)" % Net.host_name]


func _ensure_ghost(id: int) -> CoopGhost:
	if ghosts.has(id) and is_instance_valid(ghosts[id]):
		return ghosts[id]
	var info: Dictionary = Net.members.get(id, {"name": "Pemain", "char": "ren"})
	var g := CoopGhost.new()
	g.name = "Ghost%d" % id
	stage.add_child(g)
	g.setup(id, str(info.get("char", "ren")), str(info.get("name", "Pemain")))
	g.global_position = Vector3(0, 0.1, stage.arena.radius * 0.35)
	ghosts[id] = g
	return g


# ---------------------------------------------------------------- siap / mulai
func announce_ready() -> void:
	if host:
		ready_peers[1] = true
	else:
		Net._peer_ready.rpc_id(1)


func wait_ready(limit: float = 12.0) -> void:
	var t := 0.0
	while t < limit and not _all_ready():
		await get_tree().create_timer(0.2).timeout
		t += 0.2


func _all_ready() -> bool:
	for id in Net.members:
		if not ready_peers.has(int(id)):
			return false
	return true


func on_peer_ready(id: int) -> void:
	ready_peers[id] = true


# ---------------------------------------------------------------- loop
func _physics_process(delta: float) -> void:
	if stage == null or _lost:
		return
	_ps_t -= delta
	if _ps_t <= 0.0:
		_ps_t = PSTATE_DT
		var a := _my_state()
		if host:
			peer_info[1] = a
		else:
			Net._pstate.rpc_id(1, a)
	if pvp:
		_pvp_tick(delta)
	if host:
		_snap_t -= delta
		if _snap_t <= 0.0:
			_snap_t = SNAP_DT
			_send_snapshot()
			_check_defeat()
		_retarget_t -= delta
		if _retarget_t <= 0.0:
			_retarget_t = 0.4
			_retarget()
	# spektator: bila pemain ini sudah habis, kamera ikut rekan yang masih hidup
	if stage.all_down and stage.cam != null:
		for g: CoopGhost in ghosts.values():
			if is_instance_valid(g) and not g.dead:
				stage.cam.target = g
				break


func _my_state() -> Array:
	var p: Player = stage.player
	var run := maxf(p.run_speed, 0.1)
	return [p.global_position.x, p.global_position.y, p.global_position.z, p.facing, clampf(p._moving_speed / run, 0.0, 1.0),
		p.char_id, p.hp, p.max_hp, p.dead, stage.all_down]


func _on_my_action(kind: String) -> void:
	if host:
		for id in Net._authed:
			Net._gaction.rpc_id(id, 1, kind)
	else:
		Net._action.rpc_id(1, kind)


func on_action(peer: int, kind: String) -> void:
	var g: CoopGhost = ghosts.get(peer)
	if g != null:
		g.play(kind)
	for id in Net._authed:
		if id != peer:
			Net._gaction.rpc_id(id, peer, kind)


func on_ghost_action(peer: int, kind: String) -> void:
	var g: CoopGhost = ghosts.get(peer)
	if g != null:
		g.play(kind)


func on_pstate(peer: int, a: Array) -> void:
	peer_info[peer] = a
	var g := _ensure_ghost(peer)
	_apply_ghost(g, a)


func _apply_ghost(g: CoopGhost, a: Array) -> void:
	if a.size() < 10:
		return
	g.apply(Vector3(a[0], a[1], a[2]), float(a[3]), float(a[4]), str(a[5]), int(a[6]), int(a[7]), bool(a[8]), bool(a[9]))


# ---------------------------------------------------------------- HOST: musuh
func on_enemy_spawned(e: Enemy) -> void:
	e.net_id = _next_id
	_next_id += 1
	enemies[e.net_id] = e
	if hp_scale > 1.0:
		e.max_hp = int(e.max_hp * hp_scale)
		e.hp = e.max_hp
		e._update_bar()
	for id in Net._authed:
		Net._spawn.rpc_id(id, e.net_id, e.kind, e.global_position, e.max_hp)
	var eid := e.net_id
	e.died.connect(func(_x: Enemy):
		for id in Net._authed:
			Net._edead.rpc_id(id, eid))
	if e.is_boss:
		e.phase_changed.connect(func(_p: int): event("banner", [str(Enemy.KINDS[e.kind].get("phase_text", "Bos mengamuk!")), "ff9a4d"]))


func _retarget() -> void:
	var cands: Array = []
	if not stage.player.dead:
		cands.append(stage.player)
	for g: CoopGhost in ghosts.values():
		if is_instance_valid(g) and not g.dead:
			cands.append(g)
	if cands.is_empty():
		return
	for e: Enemy in get_tree().get_nodes_in_group("enemies"):
		if e.dead or not (e.state in ["chase", "recover", "spawn", "stagger"]):
			continue
		var best: Node3D = null
		var bd := 1e9
		for c: Node3D in cands:
			var d := e.global_position.distance_squared_to(c.global_position)
			if d < bd:
				bd = d
				best = c
		if best != null:
			e.target = best


func _send_snapshot() -> void:
	if Net._authed.is_empty():
		return
	var arr: Array = []
	for id in enemies:
		var e: Enemy = enemies[id]
		if e == null or not is_instance_valid(e) or e.dead:
			continue
		arr.append([id, e.global_position.x, e.global_position.y, e.global_position.z, e.rotation.y, e.hp, e.state, e._attack])
	var players := {}
	peer_info[1] = _my_state()
	for id in peer_info:
		var a: Array = (peer_info[id] as Array).duplicate()
		players[id] = a
	var meta := [stage.wave_idx, stage.boss_spawned]
	for id in Net._authed:
		Net._snap.rpc_id(id, arr, players, meta)


func on_client_hit(peer: int, id: int, dmg: int, from: Vector3, knock: float, crit: bool) -> void:
	stat_client_hits += 1
	var e: Enemy = enemies.get(id)
	if e == null or not is_instance_valid(e) or e.dead:
		return
	dmg = clampi(dmg, 1, 99999)                      # batasi nilai dari client (cegah angka absurd)
	e.take_damage(dmg, from, clampf(knock, 0.0, 30.0))
	var h := 3.8 if e.is_boss else (2.2 if e.flying else e.radius * 2.0 + 0.7)
	Fx.float_text(stage.fx_root, e.global_position + Vector3(0, h, 0), ("%d!" % dmg) if crit else str(dmg), Color(0.7, 0.95, 1.0), 1.0)


func on_ghost_hit(g: Node3D, dmg: int, from: Vector3) -> void:
	var gg := g as CoopGhost
	if gg == null or gg.dead:
		return
	Net._hurt.rpc_id(gg.peer_id, dmg, from)
	gg.play("hurt")


func _check_defeat() -> void:
	if pvp:
		return
	if stage.state == Stage.S.ENDED or not stage.all_down:
		return
	for g: CoopGhost in ghosts.values():
		if is_instance_valid(g) and not g.all_down:
			return
	stage._finish(false)


func event(ev: String, data: Array) -> void:
	if not host:
		return
	for id in Net._authed:
		Net._event.rpc_id(id, ev, data)


func on_peer_left(id: int) -> void:
	var g: CoopGhost = ghosts.get(id)
	if g != null and is_instance_valid(g):
		Flow.toast("%s keluar dari room" % g.pname)
		g.queue_free()
	ghosts.erase(id)
	peer_info.erase(id)
	ready_peers.erase(id)
	_update_label()
	_check_defeat()
	if pvp and host and not _pvp_over:
		on_pvp_down(id, 0)
		if pvp_live and not _pvp_over:        # lawan keluar -> yang tersisa menang
			var left: Array = []
			for mid in Net.members:
				if not pvp_down.has(int(mid)):
					left.append(int(mid))
			_pvp_end(left[0] if left.size() == 1 else 0)


# ---------------------------------------------------------------- CLIENT
func on_spawn(id: int, kind: String, pos: Vector3, max_hp: int) -> void:
	if host or stage == null or enemies.has(id):
		return
	stat_spawns += 1
	var e := stage._spawn_enemy(kind, pos, true)
	e.net_id = id
	e.max_hp = max_hp
	e.hp = max_hp
	e._update_bar()
	enemies[id] = e
	if e.is_boss:
		stage.boss = e
		stage.boss_spawned = true
		stage.state = Stage.S.FIGHT
		stage._boss_intro(e)


func on_enemy_dead(id: int) -> void:
	var e: Enemy = enemies.get(id)
	if e != null and is_instance_valid(e) and not e.dead:
		e.hp = 0
		e._die()
	enemies.erase(id)


func on_snap(arr: Array, players: Dictionary, meta: Array) -> void:
	if host or stage == null:
		return
	_snap_count += 1
	stat_snaps += 1
	for a in arr:
		if not (a is Array) or a.size() < 8:
			continue
		var e: Enemy = enemies.get(int(a[0]))
		if e != null and is_instance_valid(e):
			e.puppet_apply(Vector3(a[1], a[2], a[3]), float(a[4]), int(a[5]), str(a[6]), str(a[7]))
	for id in players:
		if int(id) == Net.my_id():
			continue
		_apply_ghost(_ensure_ghost(int(id)), players[id])
	for id in ghosts.keys():
		if not players.has(id):
			var g: CoopGhost = ghosts[id]
			if is_instance_valid(g):
				g.queue_free()
			ghosts.erase(id)
	if stage.state != Stage.S.ENDED and meta.size() >= 2:
		stage.wave_idx = int(meta[0])
		stage.boss_spawned = bool(meta[1])
		if stage.state == Stage.S.INTRO and int(meta[0]) >= 0:
			stage.state = Stage.S.FIGHT


func on_hurt(dmg: int, from: Vector3) -> void:
	stat_hurt += 1
	if stage != null:
		stage._on_enemy_hit(dmg, from)


func on_event(ev: String, data: Array) -> void:
	if stage == null:
		return
	match ev:
		"wave":
			stage.wave_idx = int(data[0])
			stage.state = Stage.S.FIGHT
			stage.hud.banner("Gelombang %d / %d" % [int(data[0]) + 1, stage.sd.waves.size()], UiTheme.GOLD, 1.2)
		"banner":
			stage.hud.banner(str(data[0]), Color(str(data[1])), 1.4)
		"finish":
			stage._finish(bool(data[0]))
		"pvp_go":
			pvp_go(float(data[0]))
		"pvp_score":
			pvp_left = float(data[0])
			pvp_kills = data[1]
			pvp_down = data[2]
			if not _pvp_started and pvp:        # klien lambat: event mulai terlewat -> mulai dari sinkron skor
				pvp_go(3.0)
				pvp_left = float(data[0])
			_update_label()
		"pvp_end":
			_pvp_over = true
			pvp_live = false
			stage.pvp_finish(int(data[0]), data[1])


func on_host_lost() -> void:
	if _lost:
		return
	_lost = true
	if stage != null and stage.state != Stage.S.ENDED:
		stage.state = Stage.S.ENDED
		stage.hud.banner("Host terputus", UiTheme.BAD, 2.0)
		await get_tree().create_timer(2.0).timeout
		Flow.go_lobby()


# ---------------------------------------------------------------- PVP
## HOST: mulai pertandingan (semua peserta sudah siap).
func pvp_start() -> void:
	event("pvp_go", [PVP_TIME])
	pvp_go(PVP_TIME)


func pvp_go(dur: float) -> void:
	if _pvp_started:
		return
	_pvp_started = true
	pvp_left = dur
	stage.player.control_enabled = false
	stage.player.invuln = 5.0
	for n in [3, 2, 1]:
		stage.hud.banner(str(n), UiTheme.GOLD, 0.7)
		if not is_inside_tree():
			return
		await get_tree().create_timer(0.85).timeout
		if not is_instance_valid(stage) or not is_inside_tree() or stage.state == Stage.S.ENDED:
			return
	stage.hud.banner("BERTARUNG!", UiTheme.BAD, 1.2)
	stage.state = Stage.S.FIGHT
	stage.player.invuln = 0.0
	stage.player.control_enabled = true
	pvp_live = true


func _pvp_tick(delta: float) -> void:
	if not pvp_live or _pvp_over:
		return
	pvp_left = maxf(pvp_left - delta, 0.0)
	_pvp_sync_t -= delta
	if _pvp_sync_t <= 0.0:
		_pvp_sync_t = 1.0
		if host:
			_pvp_broadcast()
		_update_label()
	if host and pvp_left <= 0.0:
		_pvp_timeup()


func _pvp_broadcast() -> void:
	event("pvp_score", [pvp_left, pvp_kills, pvp_down])


func send_pvp_hit(target: int, dmg: int, from: Vector3) -> void:
	stat_pvp_hits_sent += 1
	if host:
		on_pvp_hit(1, target, dmg, from)
	else:
		Net._pvp_hit.rpc_id(1, target, dmg, from)


## HOST: terima serangan dari penyerang -> teruskan ke korban.
func on_pvp_hit(attacker: int, target: int, dmg: int, from: Vector3) -> void:
	dmg = clampi(dmg, 0, 9999)
	if not pvp_live or pvp_down.has(target) or pvp_down.has(attacker):
		return
	if target == 1:
		on_pvp_hurt(attacker, dmg, from)
	elif Net._authed.has(target):
		Net._pvp_hurt.rpc_id(target, attacker, dmg, from)


func on_pvp_hurt(attacker: int, dmg: int, from: Vector3) -> void:
	if not pvp_live or stage.all_down or stage.state == Stage.S.ENDED:
		return
	stat_pvp_hurt += 1
	last_attacker = attacker
	stage._on_enemy_hit(dmg, from)


## Semua party kita habis -> laporkan ke host (dengan penyerang terakhir untuk kill).
func pvp_report_down() -> void:
	if host:
		on_pvp_down(1, last_attacker)
	else:
		Net._pvp_down.rpc_id(1, last_attacker)


func on_pvp_down(peer: int, attacker: int) -> void:
	if not host or _pvp_over or pvp_down.has(peer):
		return
	pvp_down[peer] = true
	if attacker != 0 and attacker != peer and pvp_kills.has(attacker):
		pvp_kills[attacker] = int(pvp_kills[attacker]) + 1
	_pvp_broadcast()
	_update_label()
	var alive: Array = []
	for id in Net.members:
		if not pvp_down.has(int(id)):
			alive.append(int(id))
	if alive.size() <= 1 and Net.members.size() >= 2 and pvp_live:
		_pvp_end(alive[0] if alive.size() == 1 else 0)


func _pvp_timeup() -> void:
	var best := -1
	var winner := 0
	var tie := false
	for id in Net.members:
		var i := int(id)
		if pvp_down.has(i):
			continue
		var k := int(pvp_kills.get(i, 0))
		if k > best:
			best = k
			winner = i
			tie = false
		elif k == best:
			tie = true
	_pvp_end(0 if tie else winner)


func _pvp_end(winner: int) -> void:
	if _pvp_over:
		return
	_pvp_over = true
	pvp_live = false
	event("pvp_end", [winner, pvp_kills])
	stage.pvp_finish(winner, pvp_kills)
