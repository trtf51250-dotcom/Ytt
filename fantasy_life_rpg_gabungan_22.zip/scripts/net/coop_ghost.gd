class_name CoopGhost
extends Node3D
## Wujud pemain lain di dunia kita (co-op). Hanya visual: posisi/hadap/animasi diisi dari jaringan. Untuk host juga jadi sasaran musuh (grup "ghost").

var peer_id := 0
var char_id := "ren"
var pname := "Pemain"
var rig: CharacterRig
var dead := false
var all_down := false
var hit_radius := 0.45
var hp := 100
var max_hp := 100
var _tp := Vector3.ZERO
var _tyaw := 0.0
var _move := 0.0
var _has := false
var _label: Label3D
var _atk := 0


func setup(p_peer: int, p_char: String, p_name: String) -> void:
	peer_id = p_peer
	pname = p_name
	add_to_group("ghost")
	_build(p_char)
	_label = Label3D.new()
	_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_label.no_depth_test = true
	_label.pixel_size = 0.0085
	_label.font_size = 40
	_label.outline_size = 12
	_label.modulate = Color(0.55, 0.95, 1.0)
	_label.position = Vector3(0, 2.35, 0)
	add_child(_label)
	_refresh_label()


func _build(id: String) -> void:
	char_id = id
	var data := Data.character(id)
	if data == null:
		data = Data.character("ren")
	if rig != null:
		rig.queue_free()
	rig = CharacterRig.new()
	rig.name = "Rig"
	add_child(rig)
	var skin: Texture2D = load(data.skin_path)
	rig.setup(1.8, skin, true, true)
	rig.set_weapon_class(data.anim_style if data.anim_style != "" else data.weapon_class)
	rig.set_style(data.id)
	rig.set_skill_kind(data.skill_kind)
	rig.set_ult_kind(data.ult_kind)
	CharacterLooks.apply_hero(rig, data.id)


func _refresh_label() -> void:
	if _label == null:
		return
	var pct := int(round(100.0 * float(hp) / maxf(float(max_hp), 1.0)))
	_label.text = "%s  %s" % [pname, ("Pingsan" if dead else "%d%%" % pct)]


func apply(p: Vector3, yaw: float, move01: float, p_char: String, p_hp: int, p_max: int, p_dead: bool, p_all_down: bool) -> void:
	_tp = p
	_tyaw = yaw
	_move = move01
	if not _has:
		_has = true
		global_position = p
	if p_char != char_id:
		_build(p_char)
	hp = p_hp
	max_hp = p_max
	all_down = p_all_down
	if p_dead != dead:
		dead = p_dead
		if dead:
			rig.play_action("death")
		else:
			rig.revive()
	_refresh_label()


func play(kind: String) -> void:
	if rig == null or dead:
		return
	if kind == "attack" or kind == "skill" or kind == "ult":
		if kind == "attack":
			_atk = (_atk % 2) + 1
		var st := get_parent()
		if st != null and st.has_method("ghost_fx"):
			st.ghost_fx(self, kind)
	if kind == "attack":
		rig.play_action("attack%d" % _atk)
	elif kind == "ult":
		rig.play_action("ult")
	elif kind == "skill":
		rig.play_action("skill")
	elif kind == "dodge":
		rig.play_action("dodge")
	elif kind == "hurt":
		rig.flash(Color(1, 0.3, 0.3))
		rig.play_action("hurt")


func _process(delta: float) -> void:
	if not _has or rig == null:
		return
	var k := 1.0 - exp(-12.0 * delta)
	global_position = global_position.lerp(_tp, k)
	rig.rotation.y = lerp_angle(rig.rotation.y, _tyaw, k)
	rig.set_move(0.0 if dead else _move, 1.0)
