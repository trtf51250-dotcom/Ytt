class_name CharacterRig
extends Node3D
## Model karakter 3D beranimasi dari rig "ZN RIG V2" (assets/hero/hero.glb): satu mesh berkulit, 17 tulang.
## - Animasi: Animation asli dari AnimLibrary, dimainkan AnimationPlayer.
##   Pemain memakai AnimationTree (state machine + BlendSpace1D) untuk Idle/Walk/Run + Turn/Attack/Skill/Dodge/Damage/Death.
##   NPC & monster humanoid memakai AnimationPlayer saja (lebih ringan).
## - Tampilan: ShaderMaterial toon (shaders/toon_character.gdshader), kulit (skin) berbeda tiap karakter.
## Model menghadap +Z. Titik pusat rig = telapak kaki.

signal action_finished(action: String)

const MODEL_PATH := "res://assets/hero/hero.glb"
const MODEL_HEIGHT := 2.43
const FOOT_OFFSET := 0.0337
const TOON_SHADER := preload("res://shaders/toon_character.gdshader")
const ACTION_NODES := {"attack1": "Attack1", "attack2": "Attack2", "attack3": "Attack3", "skill": "Skill", "hurt": "Hurt",
	"dodge": "Dodge", "turn_l": "TurnL", "turn_r": "TurnR", "death": "Death", "ult": "Ult", "wind": "Wind"}

const GRIP_X := 0.095           # pusat genggaman relatif sendi tangan (satuan model): bergeser ke sisi dalam telapak
const GRIP_Y := -0.10
const GRIP_Z := 0.0
const READY_POS := 0.14           # posisi blend pose siaga (antara diam dan jalan)
const READY_TIME := 3.5           # detik tetap siaga setelah menyerang

static var _mat_cache: Dictionary = {}

var _space: AnimationNodeBlendSpace1D
var style_id := ""
var _ready_t := 0.0
var _bp := 0.0
var _bp_target := 0.0
var _speed_mps := -1.0           # kecepatan dunia (m/s) untuk menyamakan langkah kaki; -1 = tidak diketahui (pemanggil lama)
var _rate_mul := 1.0
var _stride_mul := 1.0
## Animasi skill khusus per (kelas senjata | jenis skill) bila gerakan kelas senjata tidak cocok dengan jenis skill-nya.
const SKILL_OVERRIDE := {"sword|iai": "skill_iai", "sword|dash_cut": "skill_dashcut", "staff|volley": "skill_volley"}
var skill_kind := ""
var ult_kind := ""
# momentum badan (Tahap 1): miring ke tikungan & condong saat akselerasi/pengereman, hanya untuk rig yang tahu kecepatannya (pemain / ghost)
var _prev_yaw := 0.0
var _prev_mps := 0.0
var _yaw_rate := 0.0
var _accel := 0.0
var _lean_x := 0.0
var _lean_z := 0.0
const LEAN_MAX_X := 0.1          # rad, condong depan/belakang
const LEAN_MAX_Z := 0.13         # rad, miring ke tikungan

var height := 1.8
var model_scale := 1.0
var model: Node3D
var skel: Skeleton3D
var mesh: MeshInstance3D
var player: AnimationPlayer
var tree: AnimationTree
var playback: AnimationNodeStateMachinePlayback
var material: ShaderMaterial
var armed := true
var use_tree := true
var weapon_class := "sword"

var hand_r: BoneAttachment3D
var hand_l: BoneAttachment3D
var head_att: BoneAttachment3D
var chest_att: BoneAttachment3D
var hips_att: BoneAttachment3D
var weapon_holder: Node3D          # di tangan kanan; 1 satuan = 1 meter dunia
var weapon_holder_l: Node3D        # di tangan kiri (busur)

const FINGER_CURL := [Vector2(1.15, 1.45), Vector2(1.2, 1.5), Vector2(1.25, 1.55), Vector2(1.3, 1.6)]   # rad: pangkal, ujung (genggam penuh)
var _finger_bones := {"l": [], "r": []}   # tiap sisi: [[a,b] x4, [th_a, th_b]]
var _grip := {"l": -1.0, "r": -1.0}
var eye_bones := {}                       # "l"/"r" -> indeks tulang mata (kedip/lirik)
var _anim_nodes: Dictionary = {}   # "Attack1" -> AnimationNodeAnimation
var _flash_left := 0.0
var _flash_color := Color(1, 1, 1)
var _last_action := ""
var _was_busy := false
var _dead := false
var fidget_enabled := true       # aksi diam acak saat berdiri (AnimLibrary.fidgets); dimatikan untuk NPC/boneka
var _fid_t := 0.0
var _fid_wait := 6.0
var _fid_grace := 0.0
var _fid_playing := false
var _fid_last := ""


## p_height: tinggi karakter di dunia (meter). skin: tekstur kulit. with_tree: pakai AnimationTree (pemain).
var skin_texture: Texture2D


func setup(p_height: float, skin: Texture2D, with_tree: bool = false, p_armed: bool = true) -> void:
	skin_texture = skin
	height = p_height
	use_tree = with_tree
	armed = p_armed
	model_scale = p_height / MODEL_HEIGHT
	var ps: PackedScene = load(MODEL_PATH)
	model = ps.instantiate()
	model.name = "Model"
	model.scale = Vector3.ONE * model_scale
	model.position.y = FOOT_OFFSET * model_scale
	add_child(model)
	skel = _find_skel(model)
	skel.name = "Skeleton3D"
	for c in skel.get_children():
		if c is MeshInstance3D:
			mesh = c
	_find_finger_bones()
	material = _material_for(skin)
	mesh.material_override = material
	mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	mesh.extra_cull_margin = 1.5

	hand_r = _attach("hand_r")
	hand_l = _attach("hand_l")
	head_att = _attach("head")
	chest_att = _attach("chest")
	hips_att = _attach("hips")
	# pegangan senjata: bilah (sumbu +Y senjata) menunjuk ke depan saat tangan menggantung
	weapon_holder = Node3D.new()
	weapon_holder.name = "WeaponHolder"
	weapon_holder.position = Vector3(GRIP_X, GRIP_Y, GRIP_Z)       # pusat kepalan kanan (inward = +x)
	weapon_holder.rotation_degrees = Vector3(90, 0, 0)
	weapon_holder.scale = Vector3.ONE / model_scale
	hand_r.add_child(weapon_holder)
	weapon_holder_l = Node3D.new()
	weapon_holder_l.name = "WeaponHolderL"
	weapon_holder_l.position = Vector3(-GRIP_X, GRIP_Y, GRIP_Z)
	weapon_holder_l.rotation_degrees = Vector3(90, 0, 0)
	weapon_holder_l.scale = Vector3.ONE / model_scale
	hand_l.add_child(weapon_holder_l)

	_build_animation()
	set_grip("r", 1.0 if armed else 0.35)
	set_grip("l", 0.35)


## Badan ramping: skala lebar (X/Z) pinggul ke atas & ke bawah = s, lalu kepala dan tangan dikembalikan ke 1/s agar bentuk kepala & senjata tetap normal.
## Hanya skala pose tulang (animasi tidak memakai track skala), jadi aman dipanggil sekali setelah setup.
func set_slim(s: float) -> void:
	if skel == null or is_equal_approx(s, 1.0):
		return
	var inv := 1.0 / s
	var scales := {"hips": Vector3(s, 1.0, s), "head": Vector3(inv, 1.0, inv), "hand_l": Vector3(inv, 1.0, inv), "hand_r": Vector3(inv, 1.0, inv)}
	for nm in scales:
		var bi := skel.find_bone(nm)
		if bi >= 0:
			skel.set_bone_pose_scale(bi, scales[nm])


func _find_finger_bones() -> void:
	for sd in ["l", "r"]:
		var arr: Array = []
		for i in 4:
			arr.append([skel.find_bone("f%d_%s_a" % [i, sd]), skel.find_bone("f%d_%s_b" % [i, sd])])
		arr.append([skel.find_bone("th_%s_a" % sd), skel.find_bone("th_%s_b" % sd)])
		_finger_bones[sd] = arr
		eye_bones[sd] = skel.find_bone("eye_%s" % sd)


## Mata (tulang eye_l / eye_r): closed 0 = terbuka, 1 = menutup (skala Y); gaze (-1..1) menggeser kuad mata untuk melirik.
func set_eye_state(closed: float, gaze: Vector2 = Vector2.ZERO) -> void:
	for sd in ["l", "r"]:
		var bi: int = eye_bones.get(sd, -1)
		if bi < 0:
			continue
		var rest := skel.get_bone_rest(bi)
		skel.set_bone_pose_position(bi, rest.origin + Vector3(gaze.x * 0.014, gaze.y * 0.01, 0.0))
		skel.set_bone_pose_scale(bi, Vector3(1.0, lerpf(1.0, 0.08, clampf(closed, 0.0, 1.0)), 1.0))


## Genggaman tangan: 0 = terbuka santai, 1 = kepalan penuh (jari melingkar ke arah telapak, jempol menutup). side: "l" / "r".
func set_grip(side: String, amount: float) -> void:
	amount = clampf(amount, 0.0, 1.0)
	if absf(float(_grip[side]) - amount) < 0.001:
		return
	_grip[side] = amount
	var sg := 1.0 if side == "l" else -1.0
	var fb: Array = _finger_bones[side]
	if fb.is_empty() or int(fb[0][0]) < 0:
		return
	for i in 4:
		var c: Vector2 = FINGER_CURL[i]
		var open_a := 0.12 + 0.05 * i                      # jari santai sedikit menekuk, makin ke kelingking makin menekuk
		skel.set_bone_pose_rotation(fb[i][0], Quaternion(Vector3(0, 0, 1), -sg * lerpf(open_a, c.x, amount)))
		skel.set_bone_pose_rotation(fb[i][1], Quaternion(Vector3(0, 0, 1), -sg * lerpf(open_a * 1.3, c.y, amount)))
	skel.set_bone_pose_rotation(fb[4][0], Quaternion(Vector3(0, 1, 0), -sg * lerpf(0.15, 0.75, amount)))
	skel.set_bone_pose_rotation(fb[4][1], Quaternion(Vector3(0, 1, 0), -sg * lerpf(0.1, 0.55, amount)))


func _find_skel(n: Node) -> Skeleton3D:
	if n is Skeleton3D:
		return n
	for c in n.get_children():
		var r := _find_skel(c)
		if r:
			return r
	return null


## Tempelkan BoneAttachment3D pada tulang mana pun (anak-anaknya memakai satuan rig, bukan meter).
func attach_bone(bone: String) -> BoneAttachment3D:
	var nm := "Att_" + bone
	if skel.has_node(nm):
		return skel.get_node(nm)
	return _attach(bone)


func _attach(bone: String) -> BoneAttachment3D:
	var a := BoneAttachment3D.new()
	a.name = "Att_" + bone
	a.bone_name = bone
	skel.add_child(a)
	return a


func _material_for(skin: Texture2D) -> ShaderMaterial:
	var key := skin.resource_path if skin.resource_path != "" else str(skin.get_instance_id())
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := ShaderMaterial.new()
	m.shader = TOON_SHADER
	m.set_shader_parameter("skin", skin)
	_mat_cache[key] = m
	return m


# =====================================================================
#  Animasi
# =====================================================================
func _build_animation() -> void:
	player = AnimationPlayer.new()
	player.name = "AnimationPlayer"
	add_child(player)
	player.add_animation_library("", AnimLibrary.get_library())
	if not use_tree:
		player.play("idle" if armed else "idle_n")
		return
	tree = AnimationTree.new()
	tree.name = "AnimationTree"
	add_child(tree)
	tree.anim_player = tree.get_path_to(player)

	var sm := AnimationNodeStateMachine.new()
	# --- state Move: BlendSpace1D (idle 0 - walk 0.5 - run 1) dibungkus TimeScale
	var bt := AnimationNodeBlendTree.new()
	var space := AnimationNodeBlendSpace1D.new()
	space.min_space = 0.0
	space.max_space = 1.0
	space.sync = true
	space.add_blend_point(_anim_node("idle"), 0.0)
	space.add_blend_point(_anim_node("idle"), READY_POS)     # indeks 1: pose siaga (diganti set_style)
	space.add_blend_point(_anim_node("walk"), 0.5)
	space.add_blend_point(_anim_node("run"), 1.0)
	_space = space
	bt.add_node("Space", space, Vector2(0, 0))
	var scale_node := AnimationNodeTimeScale.new()
	bt.add_node("Scale", scale_node, Vector2(300, 0))
	bt.connect_node("Scale", 0, "Space")
	bt.connect_node("output", 0, "Scale")
	sm.add_node("Move", bt, Vector2(200, 100))
	# --- state aksi sekali jalan
	var y := 0.0
	for a in ACTION_NODES.values():
		var n := _anim_node(_default_anim_for(a))
		_anim_nodes[a] = n
		sm.add_node(a, n, Vector2(500, y))
		y += 80.0
	sm.add_transition("Start", "Move", _tr(AnimationNodeStateMachineTransition.ADVANCE_MODE_AUTO))
	for a in ACTION_NODES.values():
		sm.add_transition("Move", a, _tr(AnimationNodeStateMachineTransition.ADVANCE_MODE_ENABLED, AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, 0.05))
		if a == "Death":
			sm.add_transition(a, "Move", _tr(AnimationNodeStateMachineTransition.ADVANCE_MODE_ENABLED, AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, 0.2))
		else:
			sm.add_transition(a, "Move", _tr(AnimationNodeStateMachineTransition.ADVANCE_MODE_AUTO, AnimationNodeStateMachineTransition.SWITCH_MODE_AT_END, 0.12))
		for b in ACTION_NODES.values():
			if a != b:
				sm.add_transition(a, b, _tr(AnimationNodeStateMachineTransition.ADVANCE_MODE_ENABLED, AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, 0.04))
	tree.tree_root = sm
	tree.active = true
	playback = tree.get("parameters/playback")
	set_weapon_class(weapon_class)


func _anim_node(anim: StringName) -> AnimationNodeAnimation:
	var n := AnimationNodeAnimation.new()
	n.animation = anim
	return n


func _tr(adv: int, sw: int = AnimationNodeStateMachineTransition.SWITCH_MODE_IMMEDIATE, xf: float = 0.08) -> AnimationNodeStateMachineTransition:
	var t := AnimationNodeStateMachineTransition.new()
	t.advance_mode = adv
	t.switch_mode = sw
	t.xfade_time = xf
	return t


func _default_anim_for(node_name: String) -> String:
	match node_name:
		"Attack1": return "attack_sword1"
		"Attack2": return "attack_sword2"
		"Attack3": return "attack_sword3"
		"Skill": return "skill_sword"
		"Ult": return "skill_sword"
		"Wind": return "enemy_wind_sword"
		"Hurt": return "hurt"
		"Dodge": return "dodge"
		"TurnL": return "turn_l"
		"TurnR": return "turn_r"
		"Death": return "death"
	return "idle"


## Pilih animasi serang/skill sesuai kelas senjata (sword / staff / guard / bow).
func set_weapon_class(wc: String) -> void:
	weapon_class = wc
	if _anim_nodes.is_empty():
		return
	var a1 := "attack_sword1"
	var a2 := "attack_sword2"
	var a3 := "attack_sword3"          # penutup kombo pedang: gerakan sendiri (bukan ulangan serangan 1)
	var sk := "skill_sword"
	match wc:
		"dagger":
			a1 = "attack_dagger1"; a2 = "attack_dagger2"; a3 = "attack_dagger3"; sk = "skill_dagger"
		"dagger_vortex":                       # belati ganda + skill Vortex (Kyomu)
			a1 = "attack_dagger1"; a2 = "attack_dagger2"; a3 = "attack_dagger3"; sk = "skill_vortex"
		"staff":
			a1 = "attack_staff"; a2 = "attack_staff2"; a3 = "attack_staff3"; sk = "skill_staff"
		"guard":
			a1 = "attack_smash"; a2 = "attack_smash2"; a3 = "attack_smash3"; sk = "skill_guard"
		"bow":
			a1 = "attack_bow"; a2 = "attack_bow2"; a3 = "attack_bow3"; sk = "skill_bow"
	var ov: String = SKILL_OVERRIDE.get(wc + "|" + skill_kind, "")
	if ov != "":
		sk = ov
	if style_id != "":                                    # gerakan serang & skill khas karakter (AnimLibrary.ATK)
		a1 = AnimLibrary.attack_variant(a1, style_id)
		a2 = AnimLibrary.attack_variant(a2, style_id)
		a3 = AnimLibrary.attack_variant(a3, style_id)
		sk = AnimLibrary.attack_variant(sk, style_id)
	_anim_nodes["Attack1"].animation = a1
	_anim_nodes["Attack2"].animation = a2
	_anim_nodes["Attack3"].animation = a3
	_anim_nodes["Skill"].animation = sk
	_apply_ult_anim()
	_fit_nodes()


## Anti-tembus: ganti animasi tiap aksi dengan versi yang senjatanya tidak menembus badan/kepala (AnimLibrary.fit, di-cache).
func _fit_nodes() -> void:
	if style_id == "" or _anim_nodes.is_empty():
		return
	for nd in ["Attack1", "Attack2", "Attack3", "Skill", "Ult", "Dodge", "Hurt"]:
		if _anim_nodes.has(nd):
			_anim_nodes[nd].animation = AnimLibrary.fit(String(_anim_nodes[nd].animation), style_id)


## Beri tahu rig jenis ULTI karakter (data.ult_kind) -> animasi ULTI khusus "ult_<kind>" (AnimLibrary.ensure_ult).
func set_ult_kind(k: String) -> void:
	ult_kind = k
	_apply_ult_anim()


func _apply_ult_anim() -> void:
	if ult_kind == "" or not _anim_nodes.has("Ult"):
		return
	var un := AnimLibrary.ensure_ult(ult_kind)
	if style_id != "":
		un = AnimLibrary.fit(un, style_id)
	_anim_nodes["Ult"].animation = un


## Beri tahu rig jenis skill karakter (data.skill_kind) agar animasi skill sesuai (iai, dash_cut, volley).
func set_skill_kind(k: String) -> void:
	skill_kind = k
	if not _anim_nodes.is_empty():
		set_weapon_class(weapon_class)


## Pasang animasi diam/jalan/lari/siaga khas karakter (lihat AnimLibrary.STYLES).
func set_style(id: String) -> void:
	if not AnimLibrary.ensure_style(id):
		return
	style_id = id
	_stride_mul = float(AnimLibrary.STYLES[id]["stride"])
	if _space != null:
		_space.set_blend_point_node(0, _anim_node(AnimLibrary.fit("idle@" + id, id)))
		_space.set_blend_point_node(1, _anim_node(AnimLibrary.fit("ready@" + id, id)))
		_space.set_blend_point_node(2, _anim_node(AnimLibrary.fit("walk@" + id, id)))
		_space.set_blend_point_node(3, _anim_node(AnimLibrary.fit("run@" + id, id)))
		set_weapon_class(weapon_class)                    # pasang ulang animasi serang/skill khas karakter
	elif player != null and not use_tree:
		player.play("idle@" + id)


## Gerak dasar: speed01 0..1 (0 diam, 0.5 jalan, 1 lari), speed_scale = pengali kecepatan putar animasi (pemanggil yang tidak tahu kecepatan dunia;
## kecepatan putar dasarnya diperkirakan dari posisi blend). Pemain memakai set_move_speed supaya telapak kaki menempel tanah.
func set_move(speed01: float, speed_scale: float = 1.0) -> void:
	if tree == null:
		return
	var tgt := clampf(speed01, 0.0, 1.0)
	if tgt < 0.04 and _ready_t > 0.0 and style_id != "":
		tgt = READY_POS
	_bp_target = tgt
	_speed_mps = -1.0
	_rate_mul = maxf(speed_scale, 0.05)


## Seperti set_move, tetapi kecepatan putar siklus dihitung dari kecepatan dunia (m/s) dan panjang langkah animasi -> kaki tidak meluncur.
func set_move_speed(speed01: float, speed_mps: float) -> void:
	set_move(speed01, 1.0)
	_speed_mps = speed_mps


## Jalankan aksi: attack1, attack2, skill, hurt, dodge, turn_l, turn_r, death.
func play_action(action: String) -> void:
	if playback == null or not ACTION_NODES.has(action):
		return
	var node: String = ACTION_NODES[action]
	if action == "death":
		_dead = true
	_last_action = action
	if action in ["attack1", "attack2", "attack3", "skill", "ult"]:
		_ready_t = READY_TIME
	if (action == "skill" or action == "ult") and has_meta("eye_glow"):
		(get_meta("eye_glow") as Callable).call(0.8, 0.9)        # mata bersinar saat skill/ULT
	if playback.get_current_node() == node:
		playback.start(node, true)
	else:
		playback.travel(node)


## Putar pose khusus (musuh/boss): "enemy_wind_*" (persiapan), "enemy_winded" (terengah), "enemy_roar" (raungan fase).
func play_pose(anim: String) -> void:
	if playback == null or not _anim_nodes.has("Wind"):
		return
	_anim_nodes["Wind"].animation = anim
	play_action("wind")


func revive() -> void:
	_dead = false
	if playback:
		playback.travel("Move")


func current_state() -> String:
	if playback == null:
		return ""
	return str(playback.get_current_node())


## Sedang menjalankan aksi (bukan Move)?
func is_busy() -> bool:
	if playback == null:
		return false
	return playback.get_current_node() != &"Move"


## Panjang animasi aksi saat ini dalam detik (untuk menyinkronkan serangan).
func action_length(action: String) -> float:
	if not _anim_nodes.has(ACTION_NODES.get(action, "")):
		return 0.4
	var a: Animation = player.get_animation(_anim_nodes[ACTION_NODES[action]].animation)
	return a.length if a else 0.4


## Detik sejak aksi mulai sampai momen serangan benar-benar mengenai (fase ayunan puncak pada animasi).
func action_impact(action: String) -> float:
	if not _anim_nodes.has(ACTION_NODES.get(action, "")):
		return 0.2
	var nm := String(_anim_nodes[ACTION_NODES[action]].animation)
	return AnimLibrary.impact_time(nm)


## Putar animasi berulang tanpa AnimationTree (NPC): idle, idle_cross, idle_hammer, walk_n, dst.
func play_loop(anim: String, blend: float = 0.25, speed: float = 1.0) -> void:
	if player == null or tree != null:
		return
	if player.current_animation == anim:
		player.speed_scale = speed
		return
	player.play(anim, blend, speed)


func stop_animation() -> void:
	if player:
		player.pause()


# =====================================================================
#  Efek
# =====================================================================
func flash(color: Color = Color(1, 1, 1), seconds: float = 0.14) -> void:
	_flash_color = color
	_flash_left = seconds
	set_flash_amount(1.0)


## Catatan: material dibagi antar rig dengan kulit yang sama, jadi kilatan memakai material tiruan per-rig.
func set_flash_amount(a: float) -> void:
	if material == null:
		return
	if not mesh.material_override.has_meta("own"):
		var own := material.duplicate() as ShaderMaterial
		own.set_meta("own", true)
		material = own
		mesh.material_override = own
	material.set_shader_parameter("flash", Color(_flash_color.r, _flash_color.g, _flash_color.b, a))


func set_tint(c: Color) -> void:
	if not mesh.material_override.has_meta("own"):
		var own := material.duplicate() as ShaderMaterial
		own.set_meta("own", true)
		material = own
		mesh.material_override = own
	material.set_shader_parameter("tint", c)


## Aksi diam acak: berdiri diam 5-10 dtk -> mainkan satu aksi kecil karakter (bukan yang sama dua kali berturut-turut). Bergerak/menyerang
## langsung memutus aksi (kembali ke Move). Tidak berjalan saat siaga pasca-serangan, mati, atau animasi lain berlangsung.
func _fidget_tick(delta: float) -> void:
	if style_id == "" or playback == null or _dead or not fidget_enabled or _speed_mps < 0.0:
		return
	var st := current_state()
	if _fid_playing:
		_fid_grace -= delta
		if _speed_mps > 0.3 and st == "Wind":
			playback.start("Move", true)                # transisi Wind->Move hanya "di akhir"; langsung potong agar karakter tidak meluncur sambil beraksi
			_fid_playing = false
		elif _fid_grace <= 0.0 and st != "Wind":
			_fid_playing = false
		return
	if st != "Move" or _speed_mps > 0.05 or _ready_t > 0.0 or _bp > 0.05:
		_fid_t = 0.0
		return
	_fid_t += delta
	if _fid_t >= _fid_wait:
		_fid_t = 0.0
		_fid_wait = randf_range(5.0, 10.0)
		play_fidget()


func play_fidget(name_override: String = "") -> void:
	var list := AnimLibrary.fidgets(style_id)
	if list.is_empty() or not _anim_nodes.has("Wind"):
		return
	var pick := name_override
	if pick == "":
		var pool := list.filter(func(n): return n != _fid_last)
		pick = pool[randi() % pool.size()]
	_fid_last = pick
	_anim_nodes["Wind"].animation = AnimLibrary.fit(pick, style_id)
	_fid_playing = true
	_fid_grace = 0.4
	playback.travel("Wind")


func _process(delta: float) -> void:
	_fidget_tick(delta)
	if _ready_t > 0.0:
		_ready_t -= delta
		if _ready_t <= 0.0 and _bp_target == READY_POS:
			_bp_target = 0.0
	if tree != null:
		_bp = move_toward(_bp, _bp_target, delta * (2.2 if _bp_target < 0.2 else 6.0))
		tree.set("parameters/Move/Space/blend_position", _bp)
		# kecepatan siklus = kecepatan dunia / panjang langkah (dibatasi agar kaki tidak berputar tak wajar)
		var mps := _speed_mps if _speed_mps >= 0.0 else _bp * 5.8
		var rate := 1.0
		if _bp > 0.04 and mps > 0.2:
			var stride_m := AnimLibrary.stride_units(_bp) * model_scale * _stride_mul
			rate = clampf(mps / maxf(stride_m, 0.05), 1.0, AnimLibrary.cycle_rate_cap(_bp))
		if _speed_mps < 0.0:
			rate *= _rate_mul
		tree.set("parameters/Move/Scale/scale", maxf(rate, 0.05))
	_update_momentum(delta)
	if _flash_left > 0.0:
		_flash_left -= delta
		set_flash_amount(clampf(_flash_left / 0.14, 0.0, 1.0))
	if tree != null and playback != null:
		var busy := is_busy()
		if _was_busy and not busy and not _dead:
			action_finished.emit(_last_action)
		_was_busy = busy


## Lapisan momentum: seluruh badan (node model, bukan tulang, jadi tidak mengganggu animasi/hit) condong ke depan saat berakselerasi,
## ke belakang saat mengerem, dan miring ke dalam tikungan saat berbelok sambil bergerak. Nol saat diam atau sedang beraksi (serang/skill/dodge).
func _update_momentum(delta: float) -> void:
	if model == null or delta <= 0.0:
		return
	var yaw := rotation.y
	var rate := clampf(angle_difference(_prev_yaw, yaw) / delta, -10.0, 10.0)
	_prev_yaw = yaw
	var mps := maxf(_speed_mps, 0.0)
	var acc := clampf((mps - _prev_mps) / delta, -30.0, 30.0)
	_prev_mps = mps
	var k := 1.0 - exp(-12.0 * delta)
	_yaw_rate = lerpf(_yaw_rate, rate, k)
	_accel = lerpf(_accel, acc, k)
	var active := _speed_mps >= 0.0 and tree != null and not _dead and not is_busy()
	var tx := 0.0
	var tz := 0.0
	if active:
		var run_w := clampf(mps / 4.0, 0.0, 1.0)                       # kuat hanya saat benar-benar bergerak
		tx = clampf(_accel * 0.006, -LEAN_MAX_X, LEAN_MAX_X) * run_w
		tz = clampf(-_yaw_rate * 0.03, -LEAN_MAX_Z, LEAN_MAX_Z) * run_w
	var ks := 1.0 - exp(-9.0 * delta)
	_lean_x = lerpf(_lean_x, tx, ks)
	_lean_z = lerpf(_lean_z, tz, ks)
	if absf(_lean_x) < 0.0005 and absf(_lean_z) < 0.0005 and tx == 0.0 and tz == 0.0:
		_lean_x = 0.0
		_lean_z = 0.0
		if model.rotation.x != 0.0 or model.rotation.z != 0.0:
			model.rotation.x = 0.0
			model.rotation.z = 0.0
		return
	model.rotation.x = _lean_x
	model.rotation.z = _lean_z


# =====================================================================
#  Benda pada tubuh (koordinat benda = satuan dunia, bukan satuan rig)
# =====================================================================
func add_in_right_hand(n: Node3D, pos: Vector3 = Vector3.ZERO, rot_deg: Vector3 = Vector3.ZERO) -> void:
	n.position = pos
	n.rotation_degrees = rot_deg
	weapon_holder.add_child(n)
	set_grip("r", 1.0)


func add_in_left_hand(n: Node3D, pos: Vector3 = Vector3.ZERO, rot_deg: Vector3 = Vector3.ZERO) -> void:
	n.position = pos
	n.rotation_degrees = rot_deg
	weapon_holder_l.add_child(n)
	set_grip("l", 1.0)


## Pasang di kepala: pos dalam meter dunia relatif ke sendi leher.
func add_on_head(n: Node3D, pos: Vector3 = Vector3.ZERO, rot_deg: Vector3 = Vector3.ZERO) -> void:
	_add_scaled(head_att, n, pos, rot_deg)


func add_on_chest(n: Node3D, pos: Vector3 = Vector3.ZERO, rot_deg: Vector3 = Vector3.ZERO) -> void:
	_add_scaled(chest_att, n, pos, rot_deg)


func add_on_hips(n: Node3D, pos: Vector3 = Vector3.ZERO, rot_deg: Vector3 = Vector3.ZERO) -> void:
	_add_scaled(hips_att, n, pos, rot_deg)


func _add_scaled(att: BoneAttachment3D, n: Node3D, pos: Vector3, rot_deg: Vector3) -> void:
	var h := Node3D.new()
	h.position = pos / model_scale
	h.rotation_degrees = rot_deg
	h.scale = Vector3.ONE / model_scale
	att.add_child(h)
	h.add_child(n)


func clear_holder(h: Node3D) -> void:
	for c in h.get_children():
		c.queue_free()


func bone_world_position(bone: String) -> Vector3:
	var i := skel.find_bone(bone)
	return skel.to_global(skel.get_bone_global_pose(i).origin)
