class_name VillageWorld
extends LobbyWorld
## Desa Fajar: peta terpisah di luar gerbang kota. Memakai ulang mesin dunia LobbyWorld (chunk 32 m + tabrakan tergabung),
## hanya tata letaknya yang berbeda: jalan tanah berkelok, alun-alun kecil bersumur, rumah-rumah yang bisa dimasuki,
## Balai Desa, warung, bengkel, ladang, kincir angin, kolam, dan hutan di sekeliling. Satu peta dimuat pada satu waktu.

var windmill_blades: Node3D


func build() -> void:
	rng.seed = 51117
	noise.seed = 31
	noise.frequency = 0.04
	g_min = VillageLayout.GROUND_MIN
	g_max = VillageLayout.GROUND_MAX
	road_lines.clear()
	for r in VillageLayout.ROADS:
		road_lines.append({"pts": _catmull(r["pts"], 8), "w": r["w"]})
	_spawn_buildings()
	_house_paths()
	_ground()
	_roads()
	_plaza()
	_gates()
	_props()
	_fields()
	_windmill()
	_trees()
	_flora()
	_far_scenery()
	_commit()
	_make_colliders()


func plaza_radius() -> float:
	return VillageLayout.SQUARE_R


func plaza_center() -> Vector2:
	return VillageLayout.SQUARE_C


func inside_walls(p: Vector2, margin: float = 0.0) -> bool:
	return p.x > VillageLayout.WALL_MIN.x + margin and p.x < VillageLayout.WALL_MAX.x - margin \
		and p.y > VillageLayout.WALL_MIN.y + margin and p.y < VillageLayout.WALL_MAX.y - margin


## Titik terdekat pada jalan mana pun (untuk menghadapkan rumah ke jalan).
func _nearest_road_point(p: Vector2) -> Vector2:
	var best := Vector2.ZERO
	var bd := 1e9
	for r in road_lines:
		var pts: Array = r["pts"]
		for i in pts.size() - 1:
			var a: Vector2 = pts[i]
			var ab: Vector2 = (pts[i + 1] as Vector2) - a
			var t := clampf((p - a).dot(ab) / maxf(ab.length_squared(), 0.0001), 0.0, 1.0)
			var q := a + ab * t
			if p.distance_to(q) < bd:
				bd = p.distance_to(q)
				best = q
	return best


func _building_list() -> Array:
	var out: Array = []
	for e in VillageLayout.SPECIAL:
		out.append(e)
	for h in VillageLayout.HOUSES:
		var e: Dictionary = (h as Dictionary).duplicate()
		var p: Vector2 = e["pos"]
		if not e.has("yaw"):
			var v := _nearest_road_point(p) - p
			e["yaw"] = rad_to_deg(atan2(v.x, v.y))
		out.append(e)
	return out


# =====================================================================
#  Jalan & alun-alun
# =====================================================================
func _roads() -> void:
	for r in road_lines:
		var pts: Array = r["pts"]
		var w: float = r["w"]
		if r.get("path", false):
			_strip(pts, w + 0.5, T_DIRT, Color(0.92, 0.82, 0.7), 0.02)
			_strip(pts, w, T_COBBLE, Color(1.0, 0.97, 0.92), 0.03, 0.95)
		else:
			# jalan desa: tanah padat bertepi batu kecil (lebih sederhana dari jalan kota)
			_strip(pts, w + 1.4, T_DIRT, Color(0.93, 0.83, 0.7), 0.02)
			_strip(pts, w, T_DIRT, Color(1.0, 0.92, 0.8), 0.03)
			_strip(pts, w * 0.42, T_COBBLE, Color(0.96, 0.93, 0.88), 0.035)


func _plaza() -> void:
	var c := Vector3(VillageLayout.SQUARE_C.x, 0, VillageLayout.SQUARE_C.y)
	var R := VillageLayout.SQUARE_R
	_ring_seg_full(c, 0.0, R, 40, T_COBBLE, Color(1.0, 0.97, 0.92), 0.05)
	_ring_seg_full(c, R, R + 0.9, 40, T_BRICK, Pal.STONE, 0.055)
	_ring_seg_full(c, 3.4, 3.8, 24, T_PLAZA, Color(0.82, 0.8, 0.84), 0.06)


# =====================================================================
#  Lengkung gerbang (utara = ke kota Aurelia, selatan = ke padang petualangan)
# =====================================================================
func _arch(pos: Vector3, label: String, action: String, prompt: String, iid: String, stone: Color) -> void:
	var k := kit_at(pos)
	for sx in [-4.2, 4.2]:
		var pp := pos + Vector3(sx, 0, 0)
		k.box_b(pp, Vector3(1.3, 5.2, 1.3), MeshKit.T_BRICK, stone, MeshKit.T_BRICK, stone.lightened(0.1))
		k.box_b(pp + Vector3(0, 5.2, 0), Vector3(1.7, 0.4, 1.7), MeshKit.T_BRICK, stone.darkened(0.1))
		sink.box(k.xf, pp + Vector3(0, 2.6, 0), Vector3(1.4, 5.2, 1.4))
	k.box(pos + Vector3(0, 5.0, 0), Vector3(9.6, 0.9, 1.1), MeshKit.T_WOOD, Pal.WOOD_DARK)
	k.box(pos + Vector3(0, 5.6, 0), Vector3(10.2, 0.25, 1.4), MeshKit.T_BRICK, stone.darkened(0.12))
	# tanda kayu dengan tulisan
	var sk := Label3D.new()
	sk.text = label
	sk.font_size = 44
	sk.pixel_size = 0.0085
	sk.modulate = Color(1.0, 0.92, 0.68)
	sk.outline_size = 8
	sk.outline_modulate = Color(0.2, 0.1, 0.04)
	sk.shaded = false
	sk.position = pos + Vector3(0, 5.0, 0.58)
	sk.visibility_range_end = 60.0
	add_child(sk)
	var sk2 := sk.duplicate() as Label3D
	sk2.position = pos + Vector3(0, 5.0, -0.58)
	sk2.rotation.y = PI
	add_child(sk2)
	for sx in [-3.2, 3.2]:
		var lp := pos + Vector3(sx, 0, 1.6)
		Decor.lamp_post(kit_at(lp), sink, lp, 3.2)
	interactions.append({"id": iid, "pos": pos + Vector3(0, 0, 0), "action": action, "prompt": prompt, "radius": 4.6})
	_reserve(Vector2(pos.x, pos.z), 6.0)


func _gates() -> void:
	_arch(VillageLayout.NORTH_GATE, "Kota Aurelia  ↑", "go_town", "Kembali ke Kota Aurelia", "gate_town", Color(0.74, 0.74, 0.8))
	_arch(VillageLayout.SOUTH_GATE, "Padang Petualangan  ↓", "adventure", "Menuju Padang Petualangan", "gate_adventure", Color(0.66, 0.62, 0.56))


# =====================================================================
#  Hiasan desa
# =====================================================================
func _props() -> void:
	var sq := VillageLayout.SQUARE_C
	# sumur di tengah alun-alun
	var wp := VillageLayout.WELL
	Decor.well(kit_at(wp), sink, wp)
	_reserve(sq, 3.5)
	# bangku mengelilingi sumur & lapak kecil di tepi alun-alun
	for i in 4:
		var a := i * TAU / 4.0 + PI / 4.0
		var p := Vector3(cos(a) * 6.0, 0, sin(a) * 6.0)
		Decor.bench(kit_at(p), sink, p, rad_to_deg(atan2(-p.x, -p.z)))
		_reserve(Vector2(p.x, p.z), 1.6)
	var cols: Array = [Pal.GREEN, Pal.ORANGE, Pal.TEAL]
	var goods: Array = [[Pal.GREEN, Pal.GOLD, Pal.RED], [Pal.ORANGE, Pal.GOLD, Pal.RED], [Pal.TEAL, Pal.WHITE, Pal.BLUE]]
	var si := 0
	for deg in [40.0, 140.0, 220.0]:
		var a := deg_to_rad(deg)
		var p := Vector3(cos(a) * 8.8, 0, sin(a) * 8.8)
		Decor.stall(kit_at(p), sink, p, rad_to_deg(atan2(-p.x, -p.z)), cols[si], goods[si])
		_reserve(Vector2(p.x, p.z), 2.6)
		si += 1
	# lampu jalan di sepanjang jalan utama dan jalan timur-barat
	for ri in [0, 1]:
		var line: Array = road_lines[ri]["pts"]
		var w: float = road_lines[ri]["w"]
		var acc := 0.0
		var side := 1.0
		for i in line.size() - 1:
			var a: Vector2 = line[i]
			var b: Vector2 = line[i + 1]
			acc += a.distance_to(b)
			if acc < 15.0:
				continue
			acc = 0.0
			var t := (b - a).normalized()
			var p := b + Vector2(t.y, -t.x) * side * (w * 0.5 + 1.0)
			side = -side
			if p.length() < VillageLayout.SQUARE_R + 2.0 or _near_building(p, -1.0) or p.y > 88.0 or p.y < -70.0:
				continue
			var pos := Vector3(p.x, 0, p.y)
			Decor.lamp_post(kit_at(pos), sink, pos, 3.2)
			_reserve(p, 1.4)
	# depan Warung & Bengkel: tong, peti, karung
	var items: Array = [
		["barrel", Vector3(-34.5, 0, -6.0)], ["crate", Vector3(-33.5, 0, -4.4)], ["barrel", Vector3(-18.0, 0, -6.0)],
		["crate", Vector3(-34.0, 0, 5.5)], ["barrel", Vector3(-18.5, 0, 5.5)], ["crate", Vector3(-17.8, 0, 7.0)],
	]
	for it in items:
		var pos: Vector3 = it[1]
		if it[0] == "barrel":
			Decor.barrel(kit_at(pos), sink, pos)
		else:
			Decor.crate(kit_at(pos), sink, pos, 0.85, rng.randf_range(-20.0, 20.0))
		_reserve(Vector2(pos.x, pos.z), 1.2)
	var anv := Vector3(-26.0, 0, 5.0)
	Decor.anvil(kit_at(anv), sink, anv, 90.0)
	_reserve(Vector2(anv.x, anv.z), 1.5)
	# api unggun & bangku di dekat Balai Desa
	var fire := Vector3(18.0, 0, 11.0)
	Decor.campfire(kit_at(fire), fire)
	sink.cyl(Transform3D.IDENTITY, fire, 1.0, 0.8)
	_reserve(Vector2(fire.x, fire.z), 2.5)
	for i in 3:
		var a := 0.6 + i * 2.1
		var bp := fire + Vector3(cos(a) * 2.5, 0, sin(a) * 2.5)
		Decor.bench(kit_at(bp), sink, bp, rad_to_deg(atan2(-(bp.x - fire.x), -(bp.z - fire.z))))
		_reserve(Vector2(bp.x, bp.z), 1.5)
	# jerami di dekat ladang, bangku di tepi kolam
	for hp in [Vector3(26, 0, 57), Vector3(54, 0, 74), Vector3(27, 0, 90), Vector3(25, 0, 74.5)]:
		Decor.hay_bale(kit_at(hp), sink, hp, rng.randf_range(0, 180))
		_reserve(Vector2(hp.x, hp.z), 1.4)
	var pond := Vector3(VillageLayout.POND.x, 0, VillageLayout.POND.y)
	for i in 4:
		var a := i * TAU / 4.0 + 0.5
		var p := pond + Vector3(cos(a) * 8.4, 0, sin(a) * 8.4)
		Decor.bench(kit_at(p), sink, p, rad_to_deg(atan2(-(p.x - pond.x), -(p.z - pond.z))))
		_reserve(Vector2(p.x, p.z), 1.8)
	# batu-batu kecil
	var rn := 0
	var tries := 0
	while rn < 14 and tries < 200:
		tries += 1
		var p := Vector2(rng.randf_range(-80, 80), rng.randf_range(-70, 90))
		if _near_building(p, 3.0) or dist_to_roads(p) < 2.5 or not _free_for_prop(p, 2.0):
			continue
		Decor.rock(kit_at(Vector3(p.x, 0, p.y)), sink, Vector3(p.x, 0, p.y), rng.randf_range(0.5, 1.0))
		_reserve(p, 1.0)
		rn += 1


# =====================================================================
#  Ladang
# =====================================================================
func _in_field(p: Vector2, margin: float = 0.0) -> bool:
	for f in VillageLayout.FIELDS:
		if (f as Rect2).grow(margin).has_point(p):
			return true
	return false


func _fields() -> void:
	var crop_cols: Array = [Color(0.55, 0.85, 0.35), Color(0.95, 0.82, 0.35), Color(0.45, 0.78, 0.42)]
	var fi := 0
	for f in VillageLayout.FIELDS:
		var r: Rect2 = f
		var kc := kit_at(Vector3(r.get_center().x, 0, r.get_center().y))
		# tanah olahan gelap
		kc.quad_free(Vector3(r.position.x, 0.04, r.end.y), Vector3(r.end.x, 0.04, r.end.y), Vector3(r.end.x, 0.04, r.position.y), Vector3(r.position.x, 0.04, r.position.y),
			Vector3.UP, T_DIRT, Color(0.62, 0.46, 0.34), Color(0.62, 0.46, 0.34), Color(0.62, 0.46, 0.34), Color(0.62, 0.46, 0.34),
			Vector2(0, 0), Vector2(r.size.x / 4.0, 0), Vector2(r.size.x / 4.0, r.size.y / 4.0), Vector2(0, r.size.y / 4.0))
		# baris tanaman (cutout): tiap 2,4 m satu baris, rumpun tiap 1,6 m
		var z := r.position.y + 1.4
		var col: Color = crop_cols[fi % 3]
		while z < r.end.y - 0.8:
			var x := r.position.x + 1.0
			while x < r.end.x - 0.6:
				var k := kit_at(Vector3(x, 0, z))
				k.cut = true
				k.cross_quads(Vector3(x, 0, z), 1.1, 0.9, MeshKit.T_TUFT, k.jitter(col, 0.1), 0.9, rng.randf() * 90.0)
				k.cut = false
				x += 1.7
			z += 2.4
		fi += 1
		# pagar di sekeliling (dengan celah di sisi jalan)
		var y0 := r.position.y
		var y1 := r.end.y
		var x0 := r.position.x
		var x1 := r.end.x
		Decor.fence(kit_at(Vector3(x0, 0, y0)), sink, Vector3(x0, 0, y1), Vector3(x0, 0, y0 + 5.0), 0.9, 2.0)
		Decor.fence(kit_at(Vector3(x1, 0, y0)), sink, Vector3(x1, 0, y0), Vector3(x1, 0, y1), 0.9, 2.0)
		Decor.fence(kit_at(Vector3(x0, 0, y1)), sink, Vector3(x0, 0, y1), Vector3(x1, 0, y1), 0.9, 2.0)
		Decor.fence(kit_at(Vector3(x0, 0, y0)), sink, Vector3(x0, 0, y0), Vector3(x1, 0, y0), 0.9, 2.0)
		_reserve(r.get_center(), maxf(r.size.x, r.size.y) * 0.5)
	# orang-orangan sawah
	for sp in [Vector3(40, 0, 66), Vector3(69, 0, 69)]:
		var k := kit_at(sp)
		k.box_b(sp, Vector3(0.14, 2.0, 0.14), MeshKit.T_WOOD, Pal.WOOD_DARK)
		k.box(sp + Vector3(0, 1.55, 0), Vector3(1.5, 0.12, 0.12), MeshKit.T_WOOD, Pal.WOOD_DARK)
		k.blob(sp + Vector3(0, 1.98, 0), 0.26, MeshKit.T_PLASTER, Color(0.95, 0.85, 0.6), 4, 8, 1.0, 0.3)
		k.box(sp + Vector3(0, 2.28, 0), Vector3(0.62, 0.1, 0.62), MeshKit.T_THATCH, Color(0.9, 0.75, 0.4))
		k.box(sp + Vector3(0, 1.25, 0), Vector3(0.5, 0.7, 0.3), MeshKit.T_CLOTH, Color(0.7, 0.3, 0.3))
		sink.cyl(k.xf, sp, 0.3, 2.0)


# =====================================================================
#  Kincir angin (satu node berputar pelan, satu mesh)
# =====================================================================
func _windmill() -> void:
	var c := VillageLayout.WINDMILL
	var base := Vector3(c.x, 0, c.y)
	var k := kit_at(base)
	k.cylinder(base, 4.0, 2.7, 10.0, 8, MeshKit.T_PLASTER, Color(1.0, 0.95, 0.85), false, -1, false, 0.9)
	k.cylinder(base + Vector3(0, 10.0, 0), 3.2, 0.0, 3.6, 8, MeshKit.T_ROOF, Color(0.78, 0.36, 0.3), false, -1, false, 0.9)
	k.box(base + Vector3(0, 1.0, 4.0), Vector3(1.5, 2.0, 0.3), MeshKit.T_DOOR, Color.WHITE)
	k.box(base + Vector3(0, 5.5, 2.8), Vector3(1.0, 1.3, 0.2), MeshKit.T_WINDOW, MeshKit.glow(Color.WHITE, 0.5))
	sink.cyl(k.xf, base, 3.9, 10.0)
	_reserve(c, 6.5)
	# baling-baling: satu mesh, berputar di sumbu depan
	var bk := MeshKit.new(77)
	for i in 4:
		var a := i * PI * 0.5
		var d := Vector3(cos(a), sin(a), 0)
		var n := Vector3(-sin(a), cos(a), 0)
		bk.box(d * 4.2, Vector3(0.22, 0.22, 0.22) + Vector3(abs(d.x) * 7.8, abs(d.y) * 7.8, 0.0), MeshKit.T_WOOD, Pal.WOOD_DARK)
		bk.quad_free(d * 1.6 + n * 0.0 + Vector3(0, 0, 0.12), d * 7.4 + Vector3(0, 0, 0.12), d * 7.4 + n * 1.7 + Vector3(0, 0, 0.12), d * 1.6 + n * 1.7 + Vector3(0, 0, 0.12),
			Vector3(0, 0, 1), MeshKit.T_CLOTH, Color(0.97, 0.93, 0.85), Color(0.97, 0.93, 0.85), Color(0.97, 0.93, 0.85), Color(0.97, 0.93, 0.85),
			Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	windmill_blades = Node3D.new()
	windmill_blades.name = "WindmillBlades"
	windmill_blades.position = base + Vector3(0, 9.2, 3.5)
	var mi := MeshInstance3D.new()
	var mesh := bk.build()
	bk.apply_materials(mesh)
	mi.mesh = mesh
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	windmill_blades.add_child(mi)
	add_child(windmill_blades)
	var hub := kit_at(base)
	hub.cylinder(base + Vector3(0, 9.2, 3.0), 0.5, 0.5, 0.9, 8, MeshKit.T_WOOD, Pal.WOOD_DARK, true)


func _process(delta: float) -> void:
	if windmill_blades != null and visible:
		windmill_blades.rotation.z += delta * 0.35


# =====================================================================
#  Pohon: hutan lebat di sekeliling, pohon jarang di dalam desa
# =====================================================================
func _vtree_ok(p: Vector2, min_d: float, road_margin: float = 2.6) -> bool:
	if p.distance_to(VillageLayout.SQUARE_C) < VillageLayout.SQUARE_R + 2.5:
		return false
	if _near_building(p, 2.5) or dist_to_roads(p) < road_margin or _in_field(p, 2.5):
		return false
	for q in props_placed:
		if Vector2(q.x, q.z).distance_to(p) < q.y + 1.0:
			return false
	for t in tree_positions:
		if (t as Vector2).distance_to(p) < min_d:
			return false
	if p.distance_to(Vector2(VillageLayout.NORTH_GATE.x, VillageLayout.NORTH_GATE.z)) < 12.0:
		return false
	if p.distance_to(Vector2(VillageLayout.SOUTH_GATE.x, VillageLayout.SOUTH_GATE.z)) < 12.0:
		return false
	if p.distance_to(Vector2(VillageLayout.POND.x, VillageLayout.POND.y)) < 11.0:
		return false
	return true


func _trees() -> void:
	# pohon peneduh teratur di sepanjang jalan utama (hanya di lajur kosong antar rumah)
	var line: Array = road_lines[0]["pts"]
	var acc := 0.0
	var side := 1.0
	for i in line.size() - 1:
		var a: Vector2 = line[i]
		var b: Vector2 = line[i + 1]
		acc += a.distance_to(b)
		if acc < 16.0:
			continue
		acc = 0.0
		var t := (b - a).normalized()
		var p := b + Vector2(t.y, -t.x) * side * 6.2
		side = -side
		if not _vtree_ok(p, 5.0, 3.5):
			continue
		var pos := Vector3(p.x, 0, p.y)
		Decor.tree(kit_at(pos), sink, pos, rng.randf_range(4.6, 5.8), _greens(), 2 if rng.randf() < 0.25 else 0)
		tree_positions.append(p)
	# pohon di dalam desa (berkelompok jarang)
	var placed := 0
	var tries := 0
	while placed < 46 and tries < 1600:
		tries += 1
		var p := Vector2(rng.randf_range(-80.0, 80.0), rng.randf_range(-72.0, 90.0))
		if not _vtree_ok(p, 5.5):
			continue
		var kind := 0
		var r := rng.randf()
		if r < 0.2:
			kind = 2
		elif r < 0.45:
			kind = 1
		var pos := Vector3(p.x, 0, p.y)
		Decor.tree(kit_at(pos), sink, pos, rng.randf_range(4.2, 6.4), _greens(), kind)
		tree_positions.append(p)
		placed += 1
	# hutan di luar batas jalan (tanpa tabrakan, detail rendah)
	var outside := 0
	tries = 0
	while outside < 190 and tries < 3600:
		tries += 1
		var p := Vector2(rng.randf_range(-104.0, 104.0), rng.randf_range(-98.0, 116.0))
		if inside_walls(p, -2.0):
			continue
		if absf(p.x) < 9.0 and (p.y > 90.0 or p.y < -70.0):
			continue
		var ok := true
		for t in tree_positions:
			if (t as Vector2).distance_to(p) < 4.2:
				ok = false
				break
		if not ok:
			continue
		var kind := 1 if rng.randf() < 0.45 else 0
		var pos := Vector3(p.x, 0, p.y)
		Decor.tree(kit_at(pos), null, pos, rng.randf_range(5.0, 8.5), _greens(), kind, true)
		tree_positions.append(p)
		outside += 1


# =====================================================================
#  Rumput, bunga, semak
# =====================================================================
func _flora() -> void:
	var n := 0
	var tries := 0
	while n < 1300 and tries < 9000:
		tries += 1
		var p := Vector2(rng.randf_range(-86.0, 86.0), rng.randf_range(-78.0, 94.0))
		if p.distance_to(VillageLayout.SQUARE_C) < VillageLayout.SQUARE_R + 1.0 or dist_to_roads(p) < 1.0 or _near_building(p, 1.5) or _in_field(p, 1.0):
			continue
		var k := kit_at(Vector3(p.x, 0, p.y))
		k.cut = true
		k.cross_quads(Vector3(p.x, 0, p.y), rng.randf_range(0.7, 1.2), rng.randf_range(0.55, 0.95), MeshKit.T_TUFT, k.jitter(Color(0.92, 1.0, 0.8), 0.12), 0.9, rng.randf() * 90.0)
		k.cut = false
		n += 1
	var f := 0
	tries = 0
	while f < 90 and tries < 2400:
		tries += 1
		var p := Vector2(rng.randf_range(-84.0, 84.0), rng.randf_range(-76.0, 92.0))
		if p.distance_to(VillageLayout.SQUARE_C) < VillageLayout.SQUARE_R + 2.0 or dist_to_roads(p) < 1.4 or _near_building(p, 2.0) or _in_field(p, 1.5):
			continue
		Decor.flower_patch(kit_at(Vector3(p.x, 0, p.y)), Vector3(p.x, 0, p.y), rng.randf_range(1.0, 2.2), rng.randi_range(8, 16))
		f += 1
	var bsh := 0
	tries = 0
	while bsh < 40 and tries < 1500:
		tries += 1
		var p := Vector2(rng.randf_range(-82.0, 82.0), rng.randf_range(-74.0, 90.0))
		if not _vtree_ok(p, 2.4, 3.0):
			continue
		var pos := Vector3(p.x, 0, p.y)
		Decor.bush(kit_at(pos), sink, pos, rng.randf_range(0.6, 1.1), _greens())
		tree_positions.append(p)
		bsh += 1
	# bunga di sepanjang jalan utama (kotak bunga rendah)
	var line: Array = road_lines[0]["pts"]
	var acc := 0.0
	for i in line.size() - 1:
		var a: Vector2 = line[i]
		var b: Vector2 = line[i + 1]
		acc += a.distance_to(b)
		if acc < 9.0:
			continue
		acc = 0.0
		for sd: float in [-1.0, 1.0]:
			var t := (b - a).normalized()
			var p: Vector2 = b + Vector2(t.y, -t.x) * sd * 4.2
			if _near_building(p, 1.0) or p.distance_to(VillageLayout.SQUARE_C) < VillageLayout.SQUARE_R + 2.0:
				continue
			Decor.flower_patch(kit_at(Vector3(p.x, 0, p.y)), Vector3(p.x, 0, p.y), 0.9, 8)
	# rumput di luar batas
	var o := 0
	tries = 0
	while o < 500 and tries < 3000:
		tries += 1
		var p := Vector2(rng.randf_range(-104.0, 104.0), rng.randf_range(-98.0, 116.0))
		if inside_walls(p, -3.0):
			continue
		var k := kit_at(Vector3(p.x, 0, p.y))
		k.cut = true
		k.cross_quads(Vector3(p.x, 0, p.y), 1.0, 0.8, MeshKit.T_TUFT, k.jitter(Color(0.8, 0.95, 0.75), 0.1), 0.9, rng.randf() * 90.0)
		k.cut = false
		o += 1


# =====================================================================
#  Tabrakan: lantai + batas tak terlihat peta Desa
# =====================================================================
func _make_colliders() -> void:
	var body := StaticBody3D.new()
	body.name = "WorldBody"
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	var floor_cs := CollisionShape3D.new()
	var fb := BoxShape3D.new()
	fb.size = Vector3(600, 2, 600)
	floor_cs.shape = fb
	floor_cs.position = Vector3(0, -1.0, 0)
	body.add_child(floor_cs)
	var bmn := VillageLayout.BOUNDS_MIN
	var bmx := VillageLayout.BOUNDS_MAX
	var walls: Array = [
		[Vector3((bmn.x + bmx.x) * 0.5, 5, bmn.y - 1.0), Vector3(bmx.x - bmn.x + 4, 10, 2)],
		[Vector3((bmn.x + bmx.x) * 0.5, 5, bmx.y + 1.0), Vector3(bmx.x - bmn.x + 4, 10, 2)],
		[Vector3(bmn.x - 1.0, 5, (bmn.y + bmx.y) * 0.5), Vector3(2, 10, bmx.y - bmn.y + 4)],
		[Vector3(bmx.x + 1.0, 5, (bmn.y + bmx.y) * 0.5), Vector3(2, 10, bmx.y - bmn.y + 4)],
	]
	for w in walls:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = w[1]
		cs.shape = bs
		cs.position = w[0]
		body.add_child(cs)
	sink.apply_to(body)
