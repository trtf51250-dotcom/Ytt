class_name LobbyLayout
extends RefCounted
## Kota diperbesar 50%: semua jarak/posisi ×1,5 (MAP_SCALE) sedangkan ukuran bangunan hanya naik 1,1→1,2, jadi ruangnya lebih lega.
## Data tata letak kota Aurelia (sumbu X = timur, Z = selatan/ke arah kamera). Satuan meter.
## Dipakai oleh LobbyWorld (membangun dunia), Lobby (NPC, spawn) dan alat uji.

const MAP_SCALE := 1.5                          # pengali ukuran peta dibanding versi awal (dipakai LobbyWorld/Explore untuk angka tetap)
const SPAWN := Vector3(0.0, 0.1, 75.0)          # titik muncul pemain (di dalam gerbang)
const SPAWN_YAW := 180.0                        # menghadap ke utara (-Z)
const WALL_MIN := Vector2(-96.0, -78.0)         # sudut tembok kota
const WALL_MAX := Vector2(96.0, 93.0)
const GATE_X := 9.2                             # setengah lebar bukaan gerbang pada tembok
const PLAZA_R := 22.5
const BUILDING_SCALE := 1.2                     # pembesaran semua bangunan (kecuali yang terikat ukuran tetap)
const NO_SCALE := ["fountain", "gate"]          # air mancur & gerbang terikat pada plaza/tembok
const BOUNDS_MIN := Vector2(-120.0, -99.0)       # batas tak terlihat tempat pemain bisa berjalan
const BOUNDS_MAX := Vector2(120.0, 117.0)

## --- Konstanta jalan (satu sumber untuk ROADS dan rumus penempatan rumah) ---
const MAIN_W := 9.0                              # lebar jalan utama selatan & bulevar timur-barat
const SIDE_X := 60.0                             # sumbu jalan samping (x = +-SIDE_X)
const SIDE_W := 6.0
const SIDE_Z0 := -72.0                           # ujung utara & selatan jalan samping (lingkaran putar)
const SIDE_Z1 := 87.0
const LORONG_Z := 57.0                           # lorong altar & kolam
const LORONG_W := 4.5
const ROAD_EDGE := 0.75                          # tepi tanah di luar lebar jalan (LobbyWorld._roads menggambar lebar + 1,5)

## Kota ditata seperti papan catur: sumbu utara-selatan (gerbang -> plaza -> guild), bulevar timur-barat
## (kamp party di ujung barat, portal di ujung timur), dua jalan samping di x = +-SIDE_X dan deretan bangunan yang SELALU menghadap jalan.
## Konvensi arah (yaw): 0 = muka menghadap +Z (selatan), 90 = menghadap +X (timur), 180 = menghadap -Z (utara), -90 = menghadap -X (barat).
## Rumah warga dihitung oleh buildings() (lihat bagian "Rumus penempatan rumah" di bawah): tiap deret rumah = satu ruas jalan + batas bebas, jumlah rumah = yang muat dengan jarak antar rumah >= HOUSE_GAP_MIN, simetris barat-timur.
## Bangunan tetap (landmark): kind, pos (x,z), yaw (derajat), warna atap/dinding. Rumah warga TIDAK ditulis di sini: dihitung oleh buildings() dari rumus di bawah.
const LANDMARKS: Array = [
	{"kind": "fountain", "pos": Vector2(0, 0), "yaw": 0.0},
	{"kind": "gate", "pos": Vector2(0, 93), "yaw": 0.0, "seed": 11},
	# --- utara: guild menghadap plaza, bengkel & perpustakaan mengapit jalan guild
	{"kind": "guild", "pos": Vector2(0, -58.8), "yaw": 0.0, "roof": Color(0.32, 0.55, 0.95), "wall": Color(1.0, 0.96, 0.88), "seed": 1},
	{"kind": "forge", "pos": Vector2(-39, -49.5), "yaw": 90.0, "roof": Color(0.5, 0.52, 0.62), "seed": 4},
	{"kind": "library", "pos": Vector2(39, -49.5), "yaw": -90.0, "seed": 5},
	# --- bulevar timur-barat: toko di sisi utara menghadap jalan
	{"kind": "weapon_shop", "pos": Vector2(-45, -19.5), "yaw": 0.0, "roof": Color(0.92, 0.36, 0.32), "wall": Color(1.0, 0.94, 0.84), "seed": 2},
	{"kind": "item_shop", "pos": Vector2(45, -19.5), "yaw": 0.0, "roof": Color(0.22, 0.72, 0.7), "wall": Color(0.95, 1.0, 0.94), "seed": 3},
	# --- ujung bulevar: kamp party (barat) dan portal petualangan (timur)
	{"kind": "tent", "pos": Vector2(-81, 0), "yaw": 90.0, "seed": 8},
	{"kind": "portal", "pos": Vector2(79.5, 0), "yaw": -90.0, "seed": 7},
	# --- selatan: altar bintang & kolam taman di ujung jalan samping jalan utama
	{"kind": "altar", "pos": Vector2(-46.5, 57), "yaw": 90.0, "seed": 9},
	{"kind": "pond", "pos": Vector2(46.5, 57), "yaw": 0.0, "seed": 10},
	{"kind": "tower", "pos": Vector2(75, -63), "yaw": -90.0, "seed": 6},
]

## Jalan batu: titik kendali (garis lurus), lebar. Urutan penting: indeks 0-5 mendapat lampu jalan.
const ROADS: Array = [
	{"pts": [Vector2(0, 120), Vector2(0, 93), Vector2(0, 60), Vector2(0, PLAZA_R)], "w": MAIN_W},        # 0 jalan utama selatan (gerbang -> plaza)
	{"pts": [Vector2(0, -PLAZA_R), Vector2(0, -36), Vector2(0, -49.5)], "w": 11.5},                      # 1 jalan menuju guild
	{"pts": [Vector2(-PLAZA_R, 0), Vector2(-45, 0), Vector2(-73.2, 0)], "w": MAIN_W},                    # 2 bulevar barat (ke kamp party)
	{"pts": [Vector2(PLAZA_R, 0), Vector2(45, 0), Vector2(71.4, 0)], "w": MAIN_W},                       # 3 bulevar timur (ke portal)
	{"pts": [Vector2(-SIDE_X, SIDE_Z0), Vector2(-SIDE_X, 0), Vector2(-SIDE_X, SIDE_Z1)], "w": SIDE_W},   # 4 jalan samping barat
	{"pts": [Vector2(SIDE_X, SIDE_Z0), Vector2(SIDE_X, 0), Vector2(SIDE_X, SIDE_Z1)], "w": SIDE_W},      # 5 jalan samping timur
	{"pts": [Vector2(-MAIN_W * 0.5, LORONG_Z), Vector2(-22.5, LORONG_Z), Vector2(-41.8, LORONG_Z)], "w": LORONG_W},   # 6 lorong ke altar (mulai di dalam badan jalan utama: tanpa celah)
	{"pts": [Vector2(MAIN_W * 0.5, LORONG_Z), Vector2(22.5, LORONG_Z), Vector2(40.0, LORONG_Z)], "w": LORONG_W},      # 7 lorong ke kolam
	{"pts": [Vector2(-13.5, -49.5), Vector2(-24, -49.5), Vector2(-34.6, -49.5)], "w": LORONG_W},             # 8 lorong ke bengkel
	{"pts": [Vector2(13.5, -49.5), Vector2(21, -49.5), Vector2(28.5, -49.5)], "w": LORONG_W},                # 9 lorong ke perpustakaan
]

## Zona sebaran pohon (taman teratur): {"rect": Rect2, "count": n, "blossom": peluang bunga sakura}
const TREE_ZONES: Array = [
	{"rect": Rect2(30, 21, 24, 69), "count": 27, "blossom": 0.35},       # taman timur
	{"rect": Rect2(-54, 21, 24, 69), "count": 21, "blossom": 0.2},       # taman barat
	{"rect": Rect2(-57, -39, 27, 33), "count": 9, "blossom": 0.25},     # blok utara-barat & timur (di sela toko)
	{"rect": Rect2(30, -39, 27, 33), "count": 9, "blossom": 0.25},
	{"rect": Rect2(-57, -75, 15, 18), "count": 9, "blossom": 0.15},
	{"rect": Rect2(45, -78, 12, 15), "count": 8, "blossom": 0.15},
	{"rect": Rect2(85.5, -75, 9, 162), "count": 18, "blossom": 0.1},       # jajar pohon di sisi tembok
	{"rect": Rect2(-94.5, -75, 9, 162), "count": 18, "blossom": 0.1},
	{"rect": Rect2(-84, 84, 60, 9), "count": 12, "blossom": 0.1},
	{"rect": Rect2(24, 84, 60, 9), "count": 12, "blossom": 0.1},
]

# =====================================================================
#  Rumus penempatan rumah warga
# =====================================================================
## Rumah tidak lagi ditulis koordinat demi koordinat. Setiap DERET adalah satu sisi satu ruas jalan:
##   muka rumah (beranda/tangga ikut) = tepi tanah jalan + FRONT_GAP   -> rumah selalu sejajar jalan dengan jarak sama
##   rentang z deret [z0, z1]  = batas bebas yang dihitung dari landmark/persimpangan terdekat + SPACE
##   jumlah rumah n            = n terbesar dengan sisa ruang rata (L - jumlah panjang rumah) / (n + 1) >= HOUSE_GAP_MIN
##   posisi tiap rumah         = dibagi rata: jarak yang sama ke tetangga dan ke ujung rentang
## Ukuran rumah (HOUSE_DIM) diukur dari mesh nyata (tools/layout_audit.gd mencetak kotak mesh tiap bangunan), nilai terbesar dipakai.
const FRONT_GAP := 2.5            # muka rumah ke tepi tanah jalan (m)
const SPACE := 1.5                # jarak bebas rumah ke landmark / persimpangan / tembok
const HOUSE_GAP_MIN := 1.5        # jarak minimum antar rumah satu deret
const MAIN_FRONT := 12.0          # muka rumah di jalan utama: |x| = 12 (sisakan bahu jalan untuk lampu, penjaga gerbang, peti)
const HOUSE_SEQ := ["house_b", "house_a", "house_c"]     # urutan jenis rumah berulang di tiap deret (variasi tanpa acak)
## front/back = jangkauan mesh dari titik rumah ke arah muka/belakang, len = panjang sepanjang jalan, fp = jejak asli (sebelum BUILDING_SCALE).
const HOUSE_DIM := {
	"house_a": {"front": 7.1, "back": 4.3, "len": 11.0, "fp": 6.0},
	"house_b": {"front": 8.4, "back": 5.0, "len": 12.0, "fp": 7.0},
	"house_c": {"front": 7.9, "back": 6.0, "len": 12.0, "fp": 6.5},
}
const HOUSE_ROOFS := [Color(0.92, 0.36, 0.32), Color(0.32, 0.55, 0.95), Color(0.98, 0.64, 0.28), Color(0.35, 0.6, 0.45), Color(0.64, 0.46, 0.9), Color(0.22, 0.72, 0.7), Color(0.85, 0.45, 0.55)]
const HOUSE_WALLS := [Color(1.0, 0.96, 0.88), Color(1.0, 0.94, 0.84), Color(0.96, 0.98, 1.0), Color(0.98, 0.95, 0.9), Color(1.0, 0.92, 0.84)]

static var _cache: Array = []


## Seluruh bangunan kota: landmark tetap + rumah hasil rumus. Hasilnya di-cache (deterministik).
static func buildings() -> Array:
	if _cache.is_empty():
		_cache = LANDMARKS.duplicate()
		_cache.append_array(houses())
	return _cache


## Tepi mesh landmark (diukur dari tools/layout_audit.gd) dan titik penting yang tidak boleh tertimpa rumah.
const TENT_Z := Vector2(-9.4, 8.3)               # kamp party (barat): rentang z mesh
const PORTAL_HALF_Z := 8.6                       # panggung portal (timur): setengah lebar z mesh
const TOWER_Z1 := -56.2                          # menara (timur laut): tepi selatan mesh
const FORGE_Z := Vector2(-56.5, -42.5)           # bengkel (barat)
const LIBRARY_Z := Vector2(-58.5, -40.2)         # perpustakaan (timur)
const SHOP_Z0 := -26.2                           # tepi utara toko senjata & toko ramuan
const ALTAR_Z1 := 61.8                           # tepi selatan altar (barat)
const POND_Z1 := 63.5                            # tepi selatan kolam (timur)
const TELEPORT_ALTAR_Z := 48.0                   # batu teleport altar (-46,5; 48): deret dalam barat berhenti 4 m sebelumnya
const TELEPORT_POND_Z := 42.0                    # batu teleport kolam (55,5; 42): deret dalam timur berhenti 4 m sebelumnya


## Deret rumah: {"front": x muka rumah, "face": +1 menghadap timur (yaw 90) / -1 menghadap barat (yaw -90), "z0","z1": rentang mesh}.
## Rentang SELALU berupa ekspresi dari konstanta jalan/landmark di atas, jadi bila jalan atau landmark digeser, deret ikut menyesuaikan.
static func house_rows() -> Array:
	var half_side := SIDE_W * 0.5 + ROAD_EDGE                    # sumbu jalan samping -> tepi tanah (3,75)
	var side_front := half_side + FRONT_GAP                      # sumbu jalan samping -> muka rumah (6,25)
	var half_blvd := MAIN_W * 0.5 + ROAD_EDGE                    # sumbu bulevar -> tepi tanah (5,25)
	var half_lor := LORONG_W * 0.5 + ROAD_EDGE                   # sumbu lorong -> tepi tanah (3,0)
	var z_n := WALL_MIN.y + 5.0                                  # batas utara deret samping (jauh dari tembok & lingkaran putar jalan)
	var z_s := WALL_MAX.y - 5.0                                  # batas selatan deret samping
	var blvd_s := half_blvd + SPACE                              # tepi selatan bulevar + jarak bebas
	# jalan utama: batas utara = tepi plaza (PLAZA_R + cincin bata 1,4) di sudut dalam rumah; batas lorong = tepi lorong + SPACE
	var main_z0 := ceilf(sqrt(pow(PLAZA_R + 1.4 + SPACE, 2.0) - MAIN_FRONT * MAIN_FRONT))
	var main_n1 := LORONG_Z - half_lor - SPACE
	var main_s0 := LORONG_Z + half_lor + SPACE
	var main_s1 := WALL_MAX.y - 3.0
	var rows: Array = []
	# sgn = -1 sisi barat, +1 sisi timur. Rumah sisi barat menghadap timur (+1), sisi timur menghadap barat (-1).
	for sgn_v in [-1.0, 1.0]:
		var sgn: float = sgn_v
		var face_out := -int(sgn)        # untuk rumah di LUAR jalan samping & di jalan utama: menghadap ke arah tengah kota
		var face_in := int(sgn)          # untuk rumah di DALAM jalan samping (antara jalan samping & alun-alun): menghadap keluar ke jalan samping
		var out_front := sgn * (SIDE_X + side_front)
		var in_front := sgn * (SIDE_X - side_front)
		# jalan utama selatan: dua ruas (utara & selatan lorong)
		rows.append({"front": sgn * MAIN_FRONT, "face": face_out, "z0": main_z0, "z1": main_n1})
		rows.append({"front": sgn * MAIN_FRONT, "face": face_out, "z0": main_s0, "z1": main_s1})
		if sgn < 0.0:
			# sisi luar barat: utara kamp & selatan kamp
			rows.append({"front": out_front, "face": face_out, "z0": z_n, "z1": TENT_Z.x - SPACE})
			rows.append({"front": out_front, "face": face_out, "z0": TENT_Z.y + SPACE, "z1": z_s})
			# sisi dalam barat: sela bengkel & toko senjata, bulevar -> batu teleport altar, setelah altar
			rows.append({"front": in_front, "face": face_in, "z0": FORGE_Z.y + SPACE, "z1": SHOP_Z0 - SPACE})
			rows.append({"front": in_front, "face": face_in, "z0": blvd_s, "z1": TELEPORT_ALTAR_Z - 4.0})
			rows.append({"front": in_front, "face": face_in, "z0": ALTAR_Z1 + SPACE, "z1": z_s})
		else:
			# sisi luar timur: setelah menara -> portal, portal -> selatan
			rows.append({"front": out_front, "face": face_out, "z0": TOWER_Z1 + SPACE, "z1": -PORTAL_HALF_Z - SPACE})
			rows.append({"front": out_front, "face": face_out, "z0": PORTAL_HALF_Z + SPACE, "z1": z_s})
			# sisi dalam timur: sela perpustakaan & toko ramuan, bulevar -> batu teleport kolam, setelah kolam
			rows.append({"front": in_front, "face": face_in, "z0": LIBRARY_Z.y + SPACE, "z1": SHOP_Z0 - SPACE})
			rows.append({"front": in_front, "face": face_in, "z0": blvd_s, "z1": TELEPORT_POND_Z - 4.0})
			rows.append({"front": in_front, "face": face_in, "z0": POND_Z1 + SPACE, "z1": z_s})
	return rows


## Rumah hasil rumus (daftar dict seperti LANDMARKS).
static func houses() -> Array:
	var out: Array = []
	var shift_k := (BUILDING_SCALE - 1.0) * BUILDING_SCALE * 0.45     # LobbyWorld menggeser badan mundur sebesar ini x jejak asli
	var idx := 0
	var row_i := 0
	for row in house_rows():
		var z0: float = row["z0"]
		var z1: float = row["z1"]
		var length := z1 - z0
		# n terbesar yang masih menyisakan jarak rata >= HOUSE_GAP_MIN
		var n := 0
		for cand in range(1, 12):
			var sum := 0.0
			for i in cand:
				sum += float(HOUSE_DIM[HOUSE_SEQ[(row_i + i) % HOUSE_SEQ.size()]]["len"])
			if (length - sum) / float(cand + 1) >= HOUSE_GAP_MIN:
				n = cand
		var kinds: Array = []
		var sum2 := 0.0
		for i in n:
			var k: String = HOUSE_SEQ[(row_i + i) % HOUSE_SEQ.size()]
			kinds.append(k)
			sum2 += float(HOUSE_DIM[k]["len"])
		if n > 0:
			var gap := (length - sum2) / float(n + 1)
			var cur := z0 + gap
			var face: int = row["face"]
			for k in kinds:
				var dm: Dictionary = HOUSE_DIM[k]
				var ln: float = dm["len"]
				var x_final: float = float(row["front"]) - float(face) * float(dm["front"])     # titik rumah setelah digeser skala
				var x_layout := x_final + float(face) * shift_k * float(dm["fp"])   # nilai yang ditulis (LobbyWorld menggeser mundur)
				out.append({"kind": k, "pos": Vector2(x_layout, cur + ln * 0.5), "yaw": 90.0 * float(face),
					"roof": HOUSE_ROOFS[(idx * 3 + row_i) % HOUSE_ROOFS.size()], "wall": HOUSE_WALLS[(idx * 2 + row_i) % HOUSE_WALLS.size()], "seed": 21 + idx})
				cur += ln + gap
				idx += 1
		row_i += 1
	return out


## Titik tetap NPC (x, z): di depan bangunan masing-masing, menghadap jalan.
const NPC_SPOTS := {
	"guild_master": Vector2(-3.85, -45.93),
	"merchant": Vector2(-41.7, -10.26),
	"potion_seller": Vector2(41.7, -10.26),
	"blacksmith": Vector2(-29.65, -45.65),
	"info": Vector2(29.65, -45.65),
	"party_leader": Vector2(-72.2, 4.4),
	"gate_guard": Vector2(-6.6, 85.3),
	"priestess": Vector2(-42.1, 53.7),
}

## Arah hadap NPC (radian, atan2(dx, dz)): menghadap jalan tempat pemain datang.
const NPC_FACE := {
	"guild_master": 0.0,
	"merchant": 0.0,
	"potion_seller": 0.0,
	"blacksmith": PI / 2.0,
	"info": -PI / 2.0,
	"party_leader": PI / 2.0,
	"gate_guard": PI,
	"priestess": PI / 2.0,
}
