extends Node
## Autoload "Sfx": efek suara + musik latar. Semua .wav dibuat oleh tools/gen_audio.py (tanpa aset luar).
## Volume diatur lewat bus "Music" dan "SFX" (slider di Settings).

const SFX_NAMES := ["swing", "hit", "hurt", "pickup", "shard", "door", "boom", "select", "dash",
	"shoot", "die", "chest", "portal", "dialog", "roar", "heal", "break",
	"boss_roar", "boss_growl", "boss_swipe", "boss_claw_hit", "boss_charge", "boss_crash", "boss_wave", "boss_step", "boss_hurt", "boss_death",
	"step_stone", "step_grass", "step_wood"]
const MUSIC_NAMES := ["music_village", "music_desert", "music_cave", "music_castle", "music_boss", "music_ending", "music_lair", "music_main", "music_abyss"]

## Bila file suara baru gagal dimuat (belum diimpor / rusak), pakai suara lama sebagai cadangan agar tidak senyap.
const FALLBACK := {
	"boss_roar": "roar", "boss_growl": "roar", "boss_swipe": "swing", "boss_claw_hit": "boom", "boss_charge": "dash",
	"boss_crash": "boom", "boss_wave": "boom", "boss_step": "hit", "boss_hurt": "hurt", "boss_death": "boom",
	"music_lair": "music_boss", "music_abyss": "music_boss", "music_main": "music_village",
}
## Penyesuaian kekerasan per lagu (dB): lagu utama (mono, diturunkan dari MP3) lebih pelan daripada musik chiptune.
const MUSIC_GAIN := {"music_main": 4.7}
const VOICE_SOUNDS := ["boss_roar", "boss_death", "boss_wave", "boss_growl", "boss_charge", "boss_hurt"]

## Jeda minimum (detik) antar pemutaran suara yang sama. Mencegah belasan salinan "hit"/"swing" menumpuk dalam 1 frame
## (membuat suara pecah/patah dan membebani mixer audio di HP).
## Dibuat kecil (hanya menyaring salinan di bingkai yang sama) supaya serangan beruntun tidak kehilangan suara.
const MIN_GAP := 0.03
const MIN_GAP_BY_NAME := {"hit": 0.035, "swing": 0.03, "shoot": 0.05, "boss_step": 0.12, "step_stone": 0.1, "step_grass": 0.1, "step_wood": 0.1, "hurt": 0.08, "pickup": 0.04, "shard": 0.04}
const POOL_SIZE := 14
## Suara penting punya pemutar sendiri (bergantian) agar tidak dipotong oleh efek lain / pool penuh.
const DEDICATED := {"swing": 3, "hurt": 2, "die": 1, "dash": 2}
const VOICE_PLAYERS := 3

var _last_play := {}
var _sounds := {}
var _voice: Array[AudioStreamPlayer] = []   # pemutar khusus suara bos panjang (bergantian) agar tidak terpotong efek lain
var _voice_i := 0
var _ded := {}                                # nama -> Array pemutar khusus
var _ded_i := {}
var _pool: Array[AudioStreamPlayer] = []
var _pool_i := 0
var _music: AudioStreamPlayer
var _music_name := ""
var _tween: Tween


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_ensure_bus("Music")
	_ensure_bus("SFX")
	for i in POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		p.volume_db = -3.0
		add_child(p)
		_pool.append(p)
	for i in VOICE_PLAYERS:
		var vp := AudioStreamPlayer.new()
		vp.bus = "SFX"
		add_child(vp)
		_voice.append(vp)
	for dn in DEDICATED:
		var arr: Array[AudioStreamPlayer] = []
		for i in int(DEDICATED[dn]):
			var dp := AudioStreamPlayer.new()
			dp.bus = "SFX"
			dp.volume_db = -3.0
			add_child(dp)
			arr.append(dp)
		_ded[dn] = arr
		_ded_i[dn] = 0
	_music = AudioStreamPlayer.new()
	_music.bus = "Music"
	_music.volume_db = -80.0
	add_child(_music)
	for n in SFX_NAMES:
		_load(n)
	for n in MUSIC_NAMES:
		_load(n)
	for n in FALLBACK:
		if not _sounds.has(n) and _sounds.has(FALLBACK[n]):
			push_warning("Sfx: '%s' tidak termuat, memakai '%s'" % [n, FALLBACK[n]])
			_sounds[n] = _sounds[FALLBACK[n]]
	apply_volumes()
	GameState.changed.connect(func(kind: String):
		if kind == "settings":
			apply_volumes())


func _ensure_bus(bus_name: String) -> void:
	if AudioServer.get_bus_index(bus_name) >= 0:
		return
	AudioServer.add_bus()
	var idx := AudioServer.bus_count - 1
	AudioServer.set_bus_name(idx, bus_name)
	AudioServer.set_bus_send(idx, "Master")


func apply_volumes() -> void:
	var m := AudioServer.get_bus_index("Music")
	var s := AudioServer.get_bus_index("SFX")
	var mv: float = float(GameState.setting("music"))
	var sv: float = float(GameState.setting("sfx"))
	AudioServer.set_bus_volume_db(m, linear_to_db(maxf(mv, 0.0001)) - 6.0)
	AudioServer.set_bus_mute(m, mv <= 0.001)
	AudioServer.set_bus_volume_db(s, linear_to_db(maxf(sv, 0.0001)))
	AudioServer.set_bus_mute(s, sv <= 0.001)


func _load(n: String) -> void:
	var path := "res://assets/audio/%s.wav" % n
	if not ResourceLoader.exists(path):
		path = "res://assets/audio/%s.mp3" % n            # lagu utama (music_main) berformat MP3
	if not ResourceLoader.exists(path):
		return
	var s = load(path)
	if s is AudioStreamMP3:
		(s as AudioStreamMP3).loop = true
	if s is AudioStreamWAV and n.begins_with("music"):
		var w: AudioStreamWAV = s
		var bytes_per_frame := (2 if w.format == AudioStreamWAV.FORMAT_16_BITS else 1) * (2 if w.stereo else 1)
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = int(w.data.size() / bytes_per_frame) - 1
	_sounds[n] = s


func play(n: String, pitch: float = 1.0, vol_db: float = 0.0) -> void:
	if not _sounds.has(n):
		return
	var now := Time.get_ticks_msec() * 0.001
	if now - float(_last_play.get(n, -10.0)) < float(MIN_GAP_BY_NAME.get(n, MIN_GAP)):
		return
	_last_play[n] = now
	var p: AudioStreamPlayer
	if n in VOICE_SOUNDS:
		p = _voice[_voice_i]
		for k in _voice.size():                      # utamakan pemutar suara bos yang bebas, bila semua sibuk potong yang berikutnya
			var vc := _voice[(_voice_i + k) % _voice.size()]
			if not vc.playing:
				p = vc
				break
		_voice_i = (_voice.find(p) + 1) % _voice.size()
	elif _ded.has(n):
		var arr: Array = _ded[n]
		var di: int = _ded_i[n]
		p = arr[di]
		for k in arr.size():
			var dc: AudioStreamPlayer = arr[(di + k) % arr.size()]
			if not dc.playing:
				p = dc
				break
		_ded_i[n] = (arr.find(p) + 1) % arr.size()
	else:
		p = _pool[_pool_i]
		for k in _pool.size():                       # utamakan pemutar yang sedang bebas
			var c := _pool[(_pool_i + k) % _pool.size()]
			if not c.playing:
				p = c
				break
		_pool_i = (_pool_i + 1) % _pool.size()
	p.stream = _sounds[n]
	p.pitch_scale = pitch * randf_range(0.96, 1.04)
	p.volume_db = -3.0 + vol_db
	p.play()


func music(n: String, fade: float = 0.8) -> void:
	if n == _music_name and _music.playing:
		return
	_music_name = n
	if _tween:
		_tween.kill()
	_tween = create_tween()
	if _music.playing:
		_tween.tween_property(_music, "volume_db", -60.0, fade * 0.5)
	_tween.tween_callback(_start_music.bind(n))
	_tween.tween_property(_music, "volume_db", float(MUSIC_GAIN.get(n, 0.0)), fade)


func _start_music(n: String) -> void:
	if _sounds.has(n):
		_music.stream = _sounds[n]
		_music.volume_db = -60.0
		_music.play()
	else:
		_music.stop()


func stop_music(fade: float = 0.8) -> void:
	_music_name = ""
	if _tween:
		_tween.kill()
	_tween = create_tween()
	_tween.tween_property(_music, "volume_db", -60.0, fade)
	_tween.tween_callback(_music.stop)
