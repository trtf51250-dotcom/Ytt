class_name Player
extends CharacterBody3D
## Pemain 3D: gerak 8 arah relatif kamera (analog), rotasi halus, tabrakan kapsul, combo serangan, skill, dodge, damage, mati.
## Model = CharacterRig (rig ZN V2) + aksesori CharacterLooks. Dipakai di lobi dan di stage.

signal swing(kind: String, origin: Vector3, dir: Vector3)   # saat bilah/skill benar-benar "kena" (untuk hit detection)
signal action_started(kind: String)
signal died

const GRAVITY := 22.0
const FALL_MULT := 1.35         # jatuh terasa lebih berat/natural daripada naik
const TERMINAL_V := 38.0
const ACCEL := 46.0             # m/s^2 saat mulai bergerak (halus, tidak langsung loncat ke kecepatan penuh)
const DECEL := 60.0             # m/s^2 saat berhenti/melepas joystick
const AIR_CONTROL := 0.35

var char_id := "ren"
var data: CharacterData
var rig: CharacterRig
var cape: Node3D
var shadow_blob: MeshInstance3D

var move_input := Vector2.ZERO        # x kanan, y bawah (layar). Diisi kontrol (joystick/keyboard)
var cam_yaw := 0.0                    # yaw kamera (radian); dorongan "atas" = maju searah kamera
var control_enabled := true
var walk_speed := 3.2
var run_speed := 5.8
var facing := PI                      # yaw model (radian); 0 = menghadap +Z
var speed_mult := 1.0

var hp := 100
var max_hp := 100
var invuln := 0.0
var dead := false
var hit_radius := 0.45                # dipakai peluru musuh

var _lunge_v := 0.0
var attack_cd := 0.0
var skill_cd := 0.0
var skill_cd_max := 6.0
var dodge_cd := 0.0
var _combo := 0
var swing_idx := 0          # urutan pukulan dalam kombo untuk swing yang sedang dieksekusi
var swing_final := false    # pukulan penutup kombo?
var _combo_t := 0.0
var _act_t := 0.0                     # sisa waktu kunci aksi
var _dash_t := 0.0
var _dash_dir := Vector3.ZERO
var _pending_swing: Array = []        # [{"t": float, "kind": String}]
var _moving_speed := 0.0
var step_surface := "grass"          # "stone" | "grass" | "wood": jenis suara langkah (diatur Lobby/Stage)
var surface_probe: Callable          # opsional: (Vector3) -> String; dipanggil tiap langkah (lobi: jalan batu / rumput / lantai kayu)
var _step_t := 0.0
var _turn_lock := 0.0
var _aim_t := 0.0                     # selama > 0 arah hadap dikunci ke sasaran (sampai ayunan mengenai)


func _init() -> void:
	collision_layer = 2
	collision_mask = 1 | 4 | 8 | 16  # dunia + musuh (agar tidak menembus) + NPC (layer 3 = bit 4)
	floor_snap_length = 0.4
	motion_mode = CharacterBody3D.MOTION_MODE_GROUNDED
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.38
	cap.height = 1.7
	cs.shape = cap
	cs.position = Vector3(0, 0.85, 0)
	add_child(cs)
	Quality.blob(self, 0.62)


func set_character(id: String) -> void:
	char_id = id
	data = Data.character(id)
	cancel_actions()
	if rig:
		rig.queue_free()
		rig = null
	rig = CharacterRig.new()
	rig.name = "Rig"
	add_child(rig)
	var skin: Texture2D = load(data.skin_path)
	rig.setup(1.8, skin, true, true)
	rig.set_weapon_class(data.anim_style if data.anim_style != "" else data.weapon_class)
	rig.set_style(id)
	var out := CharacterLooks.apply_hero(rig, id)
	cape = out.get("cape", null)
	rig.rotation.y = facing
	walk_speed = data.move_speed * 0.55
	run_speed = data.move_speed
	skill_cd_max = data.skill_cooldown
	if shadow_blob == null:
		shadow_blob = _make_shadow()
		add_child(shadow_blob)
	dead = false
	CharFx.attach_aura(self, id)
	var st := GameState.char_stats(id)
	max_hp = st["hp"]
	hp = max_hp


func _make_shadow() -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(1.5, 1.5)
	q.orientation = PlaneMesh.FACE_Y
	m.mesh = q
	var g := Gradient.new()
	g.colors = PackedColorArray([Color(0, 0, 0, 0.55), Color(0, 0, 0, 0.0)])
	g.offsets = PackedFloat32Array([0.0, 1.0])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 64
	gt.height = 64
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_texture = gt
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.material_override = mat
	m.position = Vector3(0, 0.04, 0)
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return m


func forward_dir() -> Vector3:
	return Vector3(sin(facing), 0, cos(facing))


# =====================================================================
#  Aksi
# =====================================================================
## Batalkan ayunan/skill yang masih menunggu momen kena (ganti karakter, menghindar, mati) agar tidak "menyerang hantu".
## refund = kembalikan cooldown serangan/skill yang belum sempat mengenai.
func cancel_actions(refund: bool = false) -> void:
	if refund:
		for p in _pending_swing:
			if p["kind"] == "attack":
				attack_cd = 0.0
			elif p["kind"] == "skill":
				skill_cd = minf(skill_cd, 0.5)
	_pending_swing.clear()
	_lunge_v = 0.0
	_aim_t = 0.0
	_act_t = 0.0


func can_act() -> bool:
	return control_enabled and not dead and _dash_t <= 0.0


func _lunge_for(kind: String) -> float:
	if data == null:
		return 0.0
	if kind == "attack":
		match data.attack_kind:
			"arc": return 4.0
			"dagger": return 7.0 if swing_final else 5.0
			"smash": return 2.5
			"bolt": return -1.5
			"arrow": return -2.0
	else:
		match data.skill_kind:
			"cone": return 5.5
			"dash_cut": return 13.0
			"iai": return 3.0
			"volley": return -3.0
	return 0.0


## Bantuan bidik: saat menyerang, hadap musuh terdekat dalam jangkauan (kecuali joystick sedang diarahkan ke arah lain),
## supaya pukulan tidak meleset hanya karena karakter menghadap arah gerak terakhir.
func _aim_assist() -> void:
	if not is_inside_tree():
		return
	var reach: float = (data.attack_range if data else 2.5) + 2.2
	var best: Node3D = null
	var bd := reach + 99.0
	for e in get_tree().get_nodes_in_group("enemies"):
		var en := e as Node3D
		if en == null or ("dead" in en and en.dead):
			continue
		var to := en.global_position - global_position
		to.y = 0.0
		var d := to.length() - (float(en.radius) if "radius" in en else 0.0)
		if d < reach and d < bd:
			bd = d
			best = en
	if best == null:
		return
	var dir := best.global_position - global_position
	dir.y = 0.0
	if dir.length() < 0.05:
		return
	# joystick diarahkan jelas ke arah lain (>100 derajat dari musuh)? hormati arah pemain
	if move_input.length() > 0.3:
		var mv := _input_world_dir()
		if mv != Vector3.ZERO and absf(mv.signed_angle_to(dir, Vector3.UP)) > deg_to_rad(100.0):
			return
	facing = atan2(dir.x, dir.z)
	rig.rotation.y = facing


func do_attack() -> bool:
	if not can_act() or attack_cd > 0.0 or _act_t > 0.15:
		return false
	_aim_assist()
	var hits := maxi(data.combo_hits, 1) if data else 2
	var idx := _combo % hits
	var final := idx == hits - 1 and hits > 1
	var name := "attack%d" % (mini(idx, 2) + 1)
	_combo = (idx + 1) % hits if hits > 1 else 0
	_combo_t = 0.8
	var len := rig.action_length(name)
	_act_t = len * 0.8
	# cooldown benar-benar berlaku: serangan berikutnya tidak bisa lebih cepat dari ini (penutup kombo ada jeda ekstra)
	attack_cd = (data.attack_cooldown if data else 0.45) + (data.combo_recovery if (data and final) else 0.0)
	rig.play_action(name)
	var hit_t := rig.action_impact(name)
	_aim_t = hit_t + 0.1
	_pending_swing.append({"t": hit_t, "kind": "attack", "idx": idx, "final": final})
	_pending_swing.append({"t": maxf(hit_t - 0.07, 0.0), "kind": "sfx", "pitch": randf_range(0.95, 1.1) + (0.25 if final else 0.0)})
	action_started.emit("attack")
	return true


func do_skill() -> bool:
	if not can_act() or skill_cd > 0.0:
		return false
	_aim_assist()
	var len := rig.action_length("skill")
	_act_t = len * 0.9
	skill_cd = skill_cd_max
	rig.play_action("skill")
	var hit_t := rig.action_impact("skill")
	_aim_t = hit_t + 0.1
	_pending_swing.append({"t": hit_t, "kind": "skill", "idx": 0, "final": true})
	_pending_swing.append({"t": maxf(hit_t - 0.1, 0.0), "kind": "sfx", "pitch": 0.75})
	# kilau warna karakter saat mengumpulkan tenaga (fase antisipasi)
	if data:
		rig.flash(data.accent.lightened(0.4), maxf(hit_t * 0.8, 0.2))
		if data.skill_kind == "dash_cut":
			invuln = maxf(invuln, hit_t + 0.35)          # menerjang = kebal sesaat
	action_started.emit("skill")
	return true


## ULT: kunci aksi ~1.7 dtk & kebal ~2.4 dtk. Pembatasan "1× per match" dijaga Stage.
func do_ult() -> bool:
	if not can_act():
		return false
	cancel_actions(true)
	_act_t = 1.7
	invuln = maxf(invuln, 2.4)
	rig.play_action("skill")
	if data:
		rig.flash(data.accent.lightened(0.5), 1.2)
	Sfx.play("dash")
	action_started.emit("ult")
	return true


func do_dodge() -> bool:
	if not can_act() or dodge_cd > 0.0:
		return false
	var dir := _input_world_dir()
	if dir == Vector3.ZERO:
		dir = forward_dir()
	cancel_actions(true)
	_dash_dir = dir.normalized()
	facing = atan2(_dash_dir.x, _dash_dir.z)
	_dash_t = 0.26
	dodge_cd = 0.75
	invuln = maxf(invuln, 0.3)
	rig.play_action("dodge")
	Sfx.play("dash")
	action_started.emit("dodge")
	return true


func take_damage(amount: int, from: Vector3 = Vector3.ZERO) -> bool:
	if dead or invuln > 0.0:
		return false
	hp = maxi(hp - amount, 0)
	invuln = 0.5
	rig.flash(Color(1, 0.3, 0.3))
	Sfx.play("hurt")
	if hp <= 0:
		die()
	else:
		rig.play_action("hurt")
		_act_t = 0.3
		if from != Vector3.ZERO:
			var away := (global_position - from)
			away.y = 0
			if away.length() > 0.01:
				velocity += away.normalized() * 4.0
	return true


func die() -> void:
	cancel_actions()
	dead = true
	rig.play_action("death")
	Sfx.play("die")
	died.emit()


func revive(full: bool = true) -> void:
	dead = false
	if full:
		hp = max_hp
	rig.revive()
	invuln = 1.5


func heal(n: int) -> void:
	hp = mini(hp + n, max_hp)


## Putar animasi uji (dipakai menu Pengaturan > Uji Animasi di lobi).
func play_test(anim: String) -> void:
	match anim:
		"attack1", "attack2", "attack3", "skill", "hurt", "dodge", "turn_l", "turn_r", "death":
			rig.play_action(anim)
			if anim == "death":
				dead = true
				get_tree().create_timer(2.2).timeout.connect(func(): revive(false))


# =====================================================================
#  Fisika & gerak
# =====================================================================
func _input_world_dir() -> Vector3:
	var v := move_input
	if v.length() < 0.12:
		return Vector3.ZERO
	var d := Vector3(v.x, 0, v.y).rotated(Vector3.UP, cam_yaw)
	return d


func _physics_process(delta: float) -> void:
	attack_cd = maxf(attack_cd - delta, 0.0)
	skill_cd = maxf(skill_cd - delta, 0.0)
	dodge_cd = maxf(dodge_cd - delta, 0.0)
	invuln = maxf(invuln - delta, 0.0)
	_act_t = maxf(_act_t - delta, 0.0)
	_aim_t = maxf(_aim_t - delta, 0.0)
	_turn_lock = maxf(_turn_lock - delta, 0.0)
	if _combo_t > 0.0:
		_combo_t -= delta
		if _combo_t <= 0.0:
			_combo = 0
	# hit tertunda (sinkron dengan animasi)
	for p in _pending_swing.duplicate():
		p["t"] -= delta
		if p["t"] <= 0.0:
			_pending_swing.erase(p)
			if p["kind"] == "sfx":
				Sfx.play("swing", float(p.get("pitch", 1.0)))
				continue
			_lunge_v = _lunge_for(p["kind"])
			swing_idx = int(p.get("idx", 0))
			swing_final = bool(p.get("final", false))
			swing.emit(p["kind"], global_position + Vector3(0, 0.9, 0), forward_dir())

	var vel := velocity
	if not is_on_floor():
		vel.y -= GRAVITY * (FALL_MULT if vel.y < 0.0 else 1.0) * delta
		vel.y = maxf(vel.y, -TERMINAL_V)
	else:
		vel.y = -2.0                                      # menempel ke lantai (turun lereng/tangga kecil tidak melayang)

	var horizontal := Vector3.ZERO
	if dead:
		_moving_speed = 0.0
	elif _dash_t > 0.0:
		_dash_t -= delta
		horizontal = _dash_dir * 15.0
	elif control_enabled:
		var d := _input_world_dir()
		if d != Vector3.ZERO:
			var m := clampf(move_input.length(), 0.0, 1.0)
			var spd := walk_speed * (m / 0.6) if m < 0.6 else walk_speed + (run_speed - walk_speed) * (m - 0.6) / 0.4
			spd *= speed_mult
			if _act_t > 0.0:
				spd *= 0.45                                       # bisa sedikit bergerak sambil menyerang (dulu 0,35: terasa menempel di tanah)
			horizontal = d.normalized() * spd
			var target := atan2(d.x, d.z)
			var diff := absf(angle_difference(facing, target))
			# balik arah tajam saat diam: putar cepat dengan animasi belok
			if _moving_speed < 0.6 and diff > deg_to_rad(110.0) and _act_t <= 0.0 and _turn_lock <= 0.0:
				_turn_lock = 0.35
				rig.play_action("turn_l" if angle_difference(facing, target) > 0.0 else "turn_r")
			facing = lerp_angle(facing, target, 1.0 - exp(-14.0 * delta))
		_moving_speed = lerpf(_moving_speed, horizontal.length(), 1.0 - exp(-12.0 * delta))
	else:
		_moving_speed = lerpf(_moving_speed, 0.0, 1.0 - exp(-12.0 * delta))

	# dorongan tubuh saat serangan mengenai (maju untuk tebasan, mundur sedikit untuk tembakan)
	_lunge_v = move_toward(_lunge_v, 0.0, 22.0 * delta) if absf(_lunge_v) > 0.01 else 0.0
	if _lunge_v != 0.0 and not dead and _dash_t <= 0.0:
		horizontal += forward_dir() * _lunge_v

	# kecepatan mendatar mendekati target dengan percepatan/perlambatan (bukan langsung loncat); dash & dorongan tetap instan
	var cur := Vector3(velocity.x, 0, velocity.z)
	var want := horizontal
	if _dash_t > 0.0 or dead or horizontal.length() > run_speed * 1.6:
		cur = want
	else:
		var on_floor := is_on_floor()
		var rate := (ACCEL if want.length() > cur.length() - 0.05 else DECEL) * (1.0 if on_floor else AIR_CONTROL)
		if want == Vector3.ZERO and absf(_lunge_v) < 0.01:
			cur = cur.move_toward(Vector3.ZERO, DECEL * delta * (1.0 if on_floor else AIR_CONTROL))
		else:
			cur = cur.move_toward(want, rate * delta)
	vel.x = cur.x
	vel.z = cur.z
	velocity = vel
	move_and_slide()
	_footsteps(delta)

	if rig:
		rig.rotation.y = facing
		var blend := clampf(_moving_speed / maxf(run_speed, 0.1), 0.0, 1.0)
		var ref := walk_speed if blend < 0.55 else run_speed
		rig.set_move(blend, clampf(_moving_speed / maxf(ref * (0.55 if blend < 0.55 else 1.0), 0.1), 0.7, 1.6) if _moving_speed > 0.2 else 1.0)
		if cape:
			var flare := clampf(blend * 0.7, 0.0, 0.7) + (0.05 if blend < 0.1 else 0.0)
			cape.rotation.x = lerpf(cape.rotation.x, flare, 1.0 - exp(-6.0 * delta))
		if invuln > 0.0 and not dead:
			rig.visible = int(invuln * 30.0) % 2 == 0 or invuln > 1.0
		else:
			rig.visible = true


## Langkah kaki: satu bunyi tiap kali kaki menapak (jarak langkah tetap ≈ 1,1 m, jadi lari lebih rapat dari jalan). Pelan agar tidak menutupi efek pertempuran.
func _footsteps(delta: float) -> void:
	if dead or _dash_t > 0.0 or not is_on_floor() or _moving_speed < 1.2:
		_step_t = 0.12
		return
	_step_t -= delta
	if _step_t > 0.0:
		return
	_step_t = clampf(1.1 / maxf(_moving_speed, 0.1), 0.16, 0.5)
	var surf := step_surface
	if surface_probe.is_valid():
		surf = str(surface_probe.call(global_position))
	Sfx.play("step_" + surf, randf_range(0.92, 1.08), -9.0 if surf != "grass" else -7.0)
