class_name CharacterLooks
extends RefCounted
## Aksesori & senjata prosedural untuk karakter (jubah, bahu, topi, pedang, tongkat, perisai, busur) dan perlengkapan NPC.
## Semua dibangun dengan MeshKit (warna vertex) + shader toon_flat. Senjata dalam satuan METER (WeaponHolder), aksesori badan dalam satuan RIG
## (anak BoneAttachment3D; tinggi rig 2.43, dada di y=1.275, kepala di y=1.822, pinggul di y=0.905, bahu x=±0.4).

const T := MeshKit.T_METAL
const SILVER := Color(0.86, 0.92, 1.0)
const GOLD := Color(1.0, 0.82, 0.32)
const NAVY := Color(0.2, 0.3, 0.66)
const ICE := Color(0.55, 0.78, 1.0)
const WHITE := Color(0.97, 0.98, 1.0)

static var _mat: ShaderMaterial


static func material() -> ShaderMaterial:
	if _mat == null:
		_mat = ShaderMaterial.new()
		_mat.shader = load("res://shaders/toon_flat.gdshader")
	return _mat


static func _mi(k: MeshKit, nm: String) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = nm
	mi.mesh = k.build()
	mi.material_override = material()
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi


static func _glow(c: Color, e: float = 0.8) -> Color:
	return MeshKit.glow(c, e)


# =====================================================================
#  Titik masuk
# =====================================================================
## Pasang tampilan lengkap untuk karakter party (id: ren/lyra/brann/sera). Mengembalikan Dictionary node penting {"cloak": pivot}.
static func apply_hero(rig: CharacterRig, id: String) -> Dictionary:
	var out := {}
	match id:
		"ren":
			out = _ren(rig)
			_sword(rig)
		"lyra":
			out = _lyra(rig)
			_staff(rig)
		"brann":
			out = _brann(rig)
			_hammer(rig)
			_shield(rig)
		"sera":
			out = _sera(rig)
			_bow(rig)
		"ember":
			out = _ember(rig)
			_staff(rig)
		"zeya":
			out = _zeya(rig)
			_daggers(rig)
		"hakuya":
			out = _hakuya(rig)
			_katana(rig)
		"vael":
			out = _vael(rig)
			_greatsword(rig)
		"lucien":
			out = _lucien(rig)
			_cane(rig)
		"wenyu":
			out = _wenyu(rig)
			_flute(rig)
		"kuroha":
			out = _kuroha(rig)
			_katana(rig, false)
		"aion":
			out = _aion(rig)
			_clock_staff(rig)
		_:
			out = _ren(rig)
			_sword(rig)
	_eyes(rig, id)
	_hair_volume(rig, id)
	return out


## Warna rambut (untuk alis). Mata & alis bawaan model (titik/balok gelap) sudah dihapus dari assets/hero/hero.glb; diganti mata bertekstur.
const BROW_COLORS := {
	"ren": Color(0.35, 0.5, 0.85), "lyra": Color(0.4, 0.28, 0.7), "brann": Color(0.3, 0.14, 0.07), "sera": Color(0.3, 0.5, 0.2),
	"ember": Color(0.7, 0.28, 0.1), "zeya": Color(0.5, 0.12, 0.25), "hakuya": Color(0.45, 0.5, 0.6), "vael": Color(0.4, 0.5, 0.65),
	"lucien": Color(0.05, 0.07, 0.17), "wenyu": Color(0.07, 0.07, 0.1), "kuroha": Color(0.45, 0.48, 0.55), "aion": Color(0.62, 0.64, 0.78),
}
static var _eye_tex := {}
const EYE_Z := 0.29            # bidang wajah kulit ~0.278 (satuan model); mata menempel tepat di depannya


## Mata anime bertekstur (assets/hero/eyes, dibuat tools/gen_eyes.py): sklera berbayang kelopak, iris bergradasi + cincin tepi, pupil,
## dua kilau, kelopak atas tebal dengan ekor bulu mata; alis berwarna rambut; berkedip tiap beberapa detik (tween ringan).
static func _eyes(rig: CharacterRig, id: String) -> void:
	var head := rig.attach_bone("head")
	if head == null:
		return
	if not _eye_tex.has(id):
		var path := "res://assets/hero/eyes/eye_%s.png" % id
		_eye_tex[id] = load(path) if ResourceLoader.exists(path) else load("res://assets/hero/eyes/eye_ren.png")
	if not _eye_tex.has("brow"):
		_eye_tex["brow"] = load("res://assets/hero/eyes/brow.png")
	var root := Node3D.new()
	root.name = "Eyes"
	head.add_child(root)
	var eye_mesh := QuadMesh.new()
	eye_mesh.size = Vector2(0.2, 0.125)
	var brow_mesh := QuadMesh.new()
	brow_mesh.size = Vector2(0.17, 0.042)
	var em := _face_mat(_eye_tex[id], Color(1, 1, 1), true)
	var em_r := em                                             # mata kanan karakter: tekstur *_r bila ada (mata beda warna)
	var rpath := "res://assets/hero/eyes/eye_%s_r.png" % id
	if ResourceLoader.exists(rpath):
		em_r = _face_mat(load(rpath), Color(1, 1, 1), true)
	var bc: Color = BROW_COLORS.get(id, Color(0.2, 0.2, 0.3))
	var bm := _face_mat(_eye_tex["brow"], bc)
	var glows: Array = []
	var glow_mat := _face_mat(_eye_tex[id], Color(1, 1, 1, 0.0), true)
	glow_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	glow_mat.albedo_color = Color(0, 0, 0, 0)
	rig.set_meta("eye_glow", func(strength: float, dur: float):
		var c := _eye_glow_color(id)
		for g in glows:
			g.visible = true
		var tw := root.create_tween()
		tw.tween_method(func(v: float): glow_mat.albedo_color = Color(c.r * v, c.g * v, c.b * v, 1.0), 0.0, strength, dur * 0.2)
		tw.tween_method(func(v: float): glow_mat.albedo_color = Color(c.r * v, c.g * v, c.b * v, 1.0), strength, 0.0, dur * 0.8)
		tw.tween_callback(func():
			for g in glows:
				g.visible = false))
	for side in [-1.0, 1.0]:                                  # +1 = mata kiri karakter (+X pada model), -1 = mata kanan
		var att := rig.attach_bone("eye_l" if side > 0.0 else "eye_r")
		var host: Node3D = att if att != null else root
		var mi := MeshInstance3D.new()
		mi.name = "Eye"
		mi.mesh = eye_mesh
		mi.material_override = em if side > 0.0 else em_r
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.position = Vector3(0, 0, 0.004)
		mi.scale.x = side * -1.0                              # sudut luar menghadap telinga
		host.add_child(mi)
		var gl := MeshInstance3D.new()                          # kilau mata (aditif) untuk skill/ULT
		gl.mesh = eye_mesh
		gl.material_override = glow_mat
		gl.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		gl.position = Vector3(0, 0, 0.012)
		gl.scale = Vector3(side * -1.0 * 1.35, 1.35, 1.0)
		gl.visible = false                                       # hanya tampil saat kilau aktif (hemat draw call)
		glows.append(gl)
		host.add_child(gl)
		var br := MeshInstance3D.new()
		br.mesh = brow_mesh
		br.material_override = bm
		br.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		br.position = Vector3(0.128 * side, 0.205, EYE_Z + 0.006)
		br.scale.x = side * -1.0
		br.rotation_degrees.z = 4.0 * side
		root.add_child(br)
	# kedip + lirikan acak, lewat tulang mata (CharacterRig.set_eye_state)
	var st := {"closed": 0.0, "gaze": Vector2.ZERO}
	var apply := func(): rig.set_eye_state(st["closed"], st["gaze"])
	var tw := root.create_tween().set_loops()
	tw.tween_interval(randf_range(1.2, 4.6))
	tw.tween_method(func(v: float): st["closed"] = v; apply.call(), 0.0, 1.0, 0.055)
	tw.tween_interval(0.05)
	tw.tween_method(func(v: float): st["closed"] = v; apply.call(), 1.0, 0.0, 0.09)
	tw.tween_interval(randf_range(2.2, 4.2))
	var tg := root.create_tween().set_loops()
	tg.tween_callback(func():
		var g := Vector2(randf_range(-1.0, 1.0), randf_range(-0.6, 0.6)) if randf() < 0.65 else Vector2.ZERO
		var t2 := root.create_tween()
		t2.tween_method(func(v: Vector2): st["gaze"] = v; apply.call(), st["gaze"], g, 0.09))
	tg.tween_interval(randf_range(1.4, 3.6))


static func _eye_glow_color(id: String) -> Color:
	var iris := {"ren": Color(0.25, 0.6, 1), "lyra": Color(0.75, 0.45, 1), "brann": Color(1, 0.6, 0.2), "sera": Color(0.35, 0.9, 0.45),
		"ember": Color(1, 0.45, 0.15), "zeya": Color(0.95, 0.3, 0.75), "hakuya": Color(0.5, 0.8, 1), "vael": Color(0.25, 0.95, 1),
		"lucien": Color(1, 0.8, 0.3), "wenyu": Color(0.3, 0.85, 0.8), "kuroha": Color(0.9, 0.2, 0.3), "aion": Color(0.55, 0.75, 1.0)}
	return iris.get(id, Color(0.6, 0.7, 1))


## Volume rambut tambahan (poni berlapis, rambut samping, lapisan belakang, jambul/ekor) agar rambut tidak terlihat seperti helm datar.
## Warna berpadu dari warna rambut dasar: akar terang -> ujung gelap. Gaya per karakter di HAIR_STYLE.
const HAIR_STYLE := {
	"ren":   {"col": Color(0.36, 0.6, 0.97),  "fringe": 0.34, "side": 0.30, "back": 0.42, "spikes": 3},
	"lyra":  {"col": Color(0.71, 0.55, 1.0),  "fringe": 0.30, "side": 0.5, "back": 0.6},
	"brann": {"col": Color(0.48, 0.23, 0.11), "fringe": 0.0,  "side": 0.30, "back": 0.40},
	"sera":  {"col": Color(0.6, 0.85, 0.35),  "fringe": 0.32, "side": 0.40, "back": 0.45, "tail": 5},
	"ember": {"col": Color(1.0, 0.5, 0.23),   "fringe": 0.30, "side": 0.35, "back": 0.40, "tail": 6, "tail_hi": true},
	"zeya":  {"col": Color(0.91, 0.27, 0.42), "fringe": 0.34, "side": 0.50, "back": 0.46, "asym": true},
	"vael":  {"col": Color(0.85, 0.92, 1.0),  "fringe": 0.34, "side": 0.40, "back": 0.30},
	"lucien": {"col": Color(0.1, 0.14, 0.32), "fringe": 0.0,  "side": 0.34, "back": 0.40},
	"aion":  {"col": Color(0.9, 0.92, 0.98),  "fringe": 0.36, "side": 0.46, "back": 0.5},
}


static func _skin_hair_color(rig: CharacterRig) -> Color:
	if rig.skin_texture == null:
		return Color(0, 0, 0, 0)
	var im := rig.skin_texture.get_image()
	if im == null:
		return Color(0, 0, 0, 0)
	if im.is_compressed():
		im.decompress()
	var r := 0.0
	var g := 0.0
	var b := 0.0
	var n := 0
	for y in range(8, 16):
		for x in range(0, 32):
			var c := im.get_pixel(x, y)
			if c.a > 0.5 and c.s > 0.3 and c.v > 0.15:
				r += c.r
				g += c.g
				b += c.b
				n += 1
	if n < 12:
		return Color(0, 0, 0, 0)
	return Color(r / n, g / n, b / n, 1.0)


static func _hair_volume(rig: CharacterRig, id: String) -> void:
	var lite_q := Quality.level() == 0              # kualitas Lancar: rambut tambahan lebih hemat
	if lite_q and not HAIR_STYLE.has(id):
		return
	var st: Dictionary
	if HAIR_STYLE.has(id):
		st = HAIR_STYLE[id]
	else:                                              # NPC: warna rambut diambil dari skin (piksel jenuh di area kepala)
		var c := _skin_hair_color(rig)
		if c.a < 0.5:
			return
		st = {"col": c, "fringe": 0.28, "side": 0.28, "back": 0.34}
	var att := rig.attach_bone("head")
	if att == null:
		return
	var col: Color = st["col"]
	var lite := col.lightened(0.22)
	var dark := col.darkened(0.28)
	var k := MeshKit.new(41)
	k.sway = 0.0
	# poni: untaian di depan dahi (sisi bawah di atas alis; tidak menutupi mata)
	var fr: float = st.get("fringe", 0.0)
	if fr > 0.0:
		k.sway = 0.25
		var n := 5 if lite_q else 7
		for i in n:
			var t := float(i) / float(n - 1)
			var x := lerpf(-0.31, 0.31, t)
			var ln := fr * (0.72 + 0.28 * absf(sin(float(i) * 2.1))) * (1.0 - 0.18 * absf(t - 0.5) * 2.0)
			if st.get("asym", false):
				ln *= lerpf(1.2, 0.6, t)
			ln = minf(ln, 0.36)
			var segs := 3
			for j in segs:
				var f := float(j) / float(segs)
				var y := 0.585 - ln * f - ln / float(segs) * 0.5
				var c := lite.lerp(col, f * 1.4).lerp(dark, maxf(0.0, f - 0.55))
				k.box(Vector3(x + sin(float(i) + j) * 0.012, y, 0.385 + 0.012 * j), Vector3(0.115 - j * 0.014, ln / float(segs) + 0.004, 0.05), T, c)
	# rambut samping (membingkai wajah)
	var sd: float = st.get("side", 0.0)
	if sd > 0.0:
		k.sway = 0.5
		for sx in [-1.0, 1.0]:
			var segs2 := 2 if lite_q else 4
			for j in segs2:
				var f2 := float(j) / float(segs2)
				var hh := sd / float(segs2)
				k.box(Vector3(sx * (0.378 - f2 * 0.006), 0.28 - sd * f2 - hh * 0.5, 0.05 + f2 * 0.02), Vector3(0.05, hh + 0.004, 0.16 - f2 * 0.05), T, lite.lerp(dark, f2 * 0.7))
	# lapisan belakang bergerigi, helai berselang-seling
	var bk: float = st.get("back", 0.0)
	if bk > 0.0:
		for layer in (1 if lite_q else 2):
			k.sway = 0.35 + layer * 0.25
			var cols := 5 if lite_q else 7
			for i in cols:
				var x2 := lerpf(-0.3, 0.3, float(i) / float(cols - 1)) + layer * 0.04
				var ln2 := bk * (0.5 + 0.35 * layer) * (0.7 + 0.3 * absf(sin(float(i) * 2.3 + layer * 1.3)))
				var c2 := col.lerp(dark, 0.08 + 0.18 * layer).lerp(lite, 0.2 * (i % 2))
				k.box(Vector3(x2, 0.3 - (ln2 + 0.18) * 0.5, -0.385 - layer * 0.035 - (i % 2) * 0.02), Vector3(0.1, ln2 + 0.18, 0.05), T, c2)
	# jambul (spike) di atas kepala
	var sp: int = st.get("spikes", 0)
	if sp > 0:
		k.sway = 0.0
		for i in sp:
			var x3 := lerpf(-0.18, 0.18, float(i) / float(maxi(1, sp - 1)))
			k.box(Vector3(x3, 0.66, 0.2 - i * 0.04), Vector3(0.1, 0.12, 0.1), T, lite)
			k.box(Vector3(x3 + 0.01, 0.74, 0.2 - i * 0.04), Vector3(0.06, 0.1, 0.06), T, lite.lightened(0.1))
	# ekor kuda di belakang
	var tl: int = st.get("tail", 0)
	if tl > 0:
		var y4: float = 0.42 if st.get("tail_hi", false) else 0.3
		var z4 := -0.42
		var w4 := 0.2
		for j in tl:
			k.sway = 0.7 + j * 0.15
			k.box(Vector3(sin(float(j) * 0.9) * 0.05, y4, z4), Vector3(w4, 0.2, 0.14), T, col.lerp(dark, float(j) / float(tl) * 0.6))
			y4 -= 0.18
			z4 -= 0.03
			w4 = maxf(0.1, w4 - 0.025)
	k.sway = 0.0
	att.add_child(_mi(k, "HairVolume"))


static func _face_mat(texture: Texture2D, col: Color, pixel: bool = false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_DEPTH_PRE_PASS
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.albedo_texture = texture
	m.albedo_color = col
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST if pixel else BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	return m


static func apply_npc(rig: CharacterRig, look: String) -> void:
	_hair_volume(rig, "npc")
	_eyes(rig, "brann")
	match look:
		"guild_master":
			_cape(rig, Color(0.22, 0.3, 0.7), Color(0.95, 0.85, 0.5), 1.1, 0.5)
			_pauldrons(rig, Color(0.22, 0.3, 0.7), GOLD)
			_crown_hat(rig)
		"merchant":
			_backpack(rig, Color(0.85, 0.55, 0.3))
			_hat_wide(rig, Color(0.85, 0.35, 0.3))
			_apron(rig, Color(0.95, 0.9, 0.8))
		"potion_seller":
			_hat_witch(rig, Color(0.3, 0.7, 0.6), Color(0.95, 0.9, 0.5))
			_satchel(rig, Color(0.35, 0.65, 0.55))
		"blacksmith":
			_apron(rig, Color(0.35, 0.28, 0.25))
			_goggles(rig)
			var k := MeshKit.new(3)
			_hammer_mesh(k, 0.85, 0.34, 0.26)
			rig.add_in_right_hand(_mi(k, "Hammer"), Vector3.ZERO, Vector3.ZERO)
		"info":
			_hat_beret(rig, Color(0.62, 0.45, 0.85))
			_book(rig)
			_scarf(rig, Color(0.62, 0.45, 0.85))
		"party_leader":
			_backpack(rig, Color(0.32, 0.55, 0.95))
			_banner_back(rig)
			_headband(rig, Color(0.32, 0.55, 0.95))
		"gate_guard":
			_helmet(rig, Color(0.72, 0.76, 0.85), true)
			_pauldrons(rig, Color(0.72, 0.76, 0.85), Color(0.32, 0.55, 0.95))
			var k2 := MeshKit.new(4)
			_spear_mesh(k2, 2.1)
			rig.add_in_right_hand(_mi(k2, "Spear"), Vector3(0, 0, 0), Vector3(0, 0, 0))
		"priestess":
			_veil(rig)
			_cape(rig, Color(0.98, 0.96, 0.9), Color(1.0, 0.84, 0.4), 1.0, 0.44)
			var k3 := MeshKit.new(5)
			_staff_mesh(k3, 1.5, Color(1.0, 0.92, 0.55))
			rig.add_in_right_hand(_mi(k3, "Staff"), Vector3.ZERO, Vector3.ZERO)
		_:
			pass


# =====================================================================
#  Jubah (kain bergoyang) - satuan rig
# =====================================================================
## Jubah menggantung dari belakang leher. Pivot (untuk membentang saat berlari) di node yang dikembalikan.
static func _cape(rig: CharacterRig, top: Color, hem: Color, length: float = 1.2, hw_top: float = 0.34, trim: Color = GOLD, star: bool = false) -> Node3D:
	var att := rig.attach_bone("chest")
	var pivot := Node3D.new()
	pivot.name = "CapePivot"
	pivot.position = Vector3(0, 0.5, -0.17)
	att.add_child(pivot)
	var k := MeshKit.new(11)
	var rows := 5
	var hw_bot := hw_top * 1.55
	for r in rows:
		var f0 := float(r) / rows
		var f1 := float(r + 1) / rows
		var y0 := -length * f0
		var y1 := -length * f1
		var w0 := lerpf(hw_top, hw_bot, f0)
		var w1 := lerpf(hw_top, hw_bot, f1)
		var z0 := -0.02 - 0.12 * f0 * f0
		var z1 := -0.02 - 0.12 * f1 * f1
		var c0 := top.lerp(hem, f0 * f0)
		var c1 := top.lerp(hem, f1 * f1)
		k.quad_free(Vector3(-w0, y0, z0), Vector3(w0, y0, z0), Vector3(w1, y1, z1), Vector3(-w1, y1, z1), Vector3(0, 0, -1), MeshKit.T_CLOTH,
			c0, c0, c1, c1, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector3.ZERO, Vector3.ZERO, Vector3.ZERO, Vector3.ZERO, f0 + 0.1)
	# lipatan kain (garis gelap tipis vertikal) + jahitan tepi samping emas + kancing leher
	for fi in [-0.5, 0.0, 0.5]:
		var fw0: float = hw_top * fi * 0.9
		var fw1: float = hw_bot * fi * 0.9
		k.quad_free(Vector3(fw0 - 0.012, -0.02, -0.024), Vector3(fw0 + 0.012, -0.02, -0.024), Vector3(fw1 + 0.016, -length * 0.96, -0.136), Vector3(fw1 - 0.016, -length * 0.96, -0.136), Vector3(0, 0, -1), MeshKit.T_CLOTH,
			top.darkened(0.22), top.darkened(0.22), hem.darkened(0.2), hem.darkened(0.2), Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	for sd in [-1.0, 1.0]:
		k.quad_free(Vector3(sd * hw_top, -0.02, -0.022), Vector3(sd * (hw_top - 0.022), -0.02, -0.022), Vector3(sd * (hw_bot - 0.03), -length * 0.97, -0.134), Vector3(sd * hw_bot, -length * 0.97, -0.134), Vector3(0, 0, -1), MeshKit.T_CLOTH,
			trim, trim, trim, trim, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	# pita emas di tepi bawah
	var wb := hw_bot
	k.sway = 1.0
	k.quad_free(Vector3(-wb, -length, -0.14), Vector3(wb, -length, -0.14), Vector3(wb, -length + 0.08, -0.12), Vector3(-wb, -length + 0.08, -0.12), Vector3(0, 0, -1), MeshKit.T_CLOTH,
		trim, trim, trim, trim, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	k.sway = 0.0
	if star:
		_star(k, Vector3(0, -length * 0.38, -0.055), 0.13, trim)
	var mi := _mi(k, "Cape")
	pivot.add_child(mi)
	return pivot


static func _star(k: MeshKit, c: Vector3, r: float, col: Color) -> void:
	for i in 2:
		var a := deg_to_rad(45.0 * i)
		var dx := Vector3(cos(a), sin(a), 0) * r
		var dy := Vector3(-sin(a), cos(a), 0) * r * 0.3
		k.quad_free(c - dx - dy, c + dx - dy, c + dx + dy, c - dx + dy, Vector3(0, 0, -1), MeshKit.T_CLOTH, col, col, col, col,
			Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
		var dy2 := Vector3(-sin(a + PI / 2.0), cos(a + PI / 2.0), 0) * r
		var dx2 := Vector3(cos(a + PI / 2.0), sin(a + PI / 2.0), 0) * r * 0.3
		k.quad_free(c - dy2 - dx2, c + dy2 - dx2, c + dy2 + dx2, c - dy2 + dx2, Vector3(0, 0, -1), MeshKit.T_CLOTH, col, col, col, col,
			Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)


## Bahu (pauldron) kiri-kanan di atas lengan atas.
static func _pauldrons(rig: CharacterRig, base: Color, trim: Color) -> void:
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(12)
	for sx in [-1.0, 1.0]:
		k.box(Vector3(sx * 0.42, 0.52, 0.0), Vector3(0.34, 0.1, 0.38), T, base)
		k.box(Vector3(sx * 0.42, 0.59, 0.0), Vector3(0.26, 0.05, 0.3), T, trim)
		k.box(Vector3(sx * 0.42, 0.45, 0.0), Vector3(0.33, 0.04, 0.37), T, trim)
		k.blob(Vector3(sx * 0.42, 0.64, 0.0), 0.05, T, GOLD, 3, 5)
	att.add_child(_mi(k, "Pauldrons"))


## Syal / kerah di leher.
static func _scarf(rig: CharacterRig, col: Color) -> void:
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(13)
	k.box(Vector3(0, 0.5, 0), Vector3(0.72, 0.16, 0.44), T, col)
	k.box(Vector3(0, 0.54, 0), Vector3(0.74, 0.04, 0.46), T, GOLD)
	k.sway = 0.7
	k.box(Vector3(-0.2, 0.2, 0.22), Vector3(0.16, 0.6, 0.03), T, col)
	k.sway = 0.0
	att.add_child(_mi(k, "Scarf"))


static func _belt(rig: CharacterRig, col: Color = Color(0.45, 0.3, 0.2), buckle: Color = GOLD, pouch: bool = true) -> void:
	var att := rig.attach_bone("hips")
	var k := MeshKit.new(14)
	k.box(Vector3(0, 0.1, 0), Vector3(0.66, 0.1, 0.34), T, col)
	k.box(Vector3(0, 0.1, 0.18), Vector3(0.14, 0.12, 0.02), T, buckle)
	k.box(Vector3(0, 0.1, 0.195), Vector3(0.07, 0.06, 0.015), T, col.darkened(0.35))                    # bingkai gesper
	k.box(Vector3(0, 0.1, 0.0), Vector3(0.68, 0.016, 0.36), T, col.lightened(0.12))                      # kilau tepi atas sabuk
	for si in 5:                                                                                         # paku/stud sepanjang sabuk
		for sx in [-1.0, 1.0]:
			k.box(Vector3(sx * (0.13 + si * 0.045), 0.1, 0.175), Vector3(0.022, 0.03, 0.02), T, buckle)
	k.box(Vector3(-0.2, 0.0, 0.18), Vector3(0.04, 0.16, 0.025), T, col.darkened(0.12))                   # ujung tali menjuntai
	if pouch:
		k.box(Vector3(0.32, 0.0, 0.1), Vector3(0.1, 0.2, 0.2), T, Color(0.55, 0.38, 0.25))
		k.box(Vector3(0.32, 0.1, 0.1), Vector3(0.11, 0.05, 0.21), T, buckle)
		k.box(Vector3(0.32, -0.04, 0.205), Vector3(0.06, 0.06, 0.015), T, buckle)                         # kancing kantong
		k.box(Vector3(0.32, -0.08, 0.1), Vector3(0.105, 0.012, 0.205), T, Color(0.4, 0.27, 0.18))         # jahitan
	att.add_child(_mi(k, "Belt"))


## Kain depan (tabard) menggantung dari ikat pinggang.
static func _tabard(rig: CharacterRig, col: Color, trim: Color) -> void:
	var att := rig.attach_bone("hips")
	var k := MeshKit.new(15)
	k.sway = 0.4
	k.quad_free(Vector3(-0.17, 0.05, 0.19), Vector3(0.17, 0.05, 0.19), Vector3(0.2, -0.5, 0.2), Vector3(-0.2, -0.5, 0.2), Vector3(0, 0, 1), MeshKit.T_CLOTH,
		col, col, col, col, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	k.quad_free(Vector3(-0.2, -0.46, 0.2), Vector3(0.2, -0.46, 0.2), Vector3(0.2, -0.5, 0.2), Vector3(-0.2, -0.5, 0.2), Vector3(0, 0, 1), MeshKit.T_CLOTH,
		trim, trim, trim, trim, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	k.sway = 0.0
	k.box(Vector3(0, -0.2, 0.215), Vector3(0.05, 0.05, 0.015), T, trim)                                  # lambang belah ketupat
	k.box(Vector3(0, -0.2, 0.22), Vector3(0.1, 0.012, 0.012), T, trim)
	k.box(Vector3(0, -0.2, 0.22), Vector3(0.012, 0.1, 0.012), T, trim)
	k.sway = 0.9
	for ti in 5:                                                                                          # rumbai di tepi bawah
		k.box(Vector3(-0.15 + ti * 0.075, -0.56, 0.2), Vector3(0.03, 0.12, 0.02), T, trim)
	k.sway = 0.0
	att.add_child(_mi(k, "Tabard"))


static func _cuffs(rig: CharacterRig, col: Color, trim: Color) -> void:
	for b in ["shin_l", "shin_r"]:
		var att := rig.attach_bone(b)
		var k := MeshKit.new(16)
		k.box(Vector3(0, -0.2, 0), Vector3(0.36, 0.12, 0.36), T, col)
		k.box(Vector3(0, -0.14, 0), Vector3(0.38, 0.03, 0.38), T, trim)
		k.box(Vector3(0, -0.26, 0), Vector3(0.375, 0.02, 0.375), T, trim.darkened(0.15))                 # garis tipis bawah
		for rv in [-0.1, 0.0, 0.1]:
			k.box(Vector3(rv, -0.2, 0.185), Vector3(0.03, 0.03, 0.02), T, trim)                           # paku manset
		att.add_child(_mi(k, "Cuff"))
	for b in ["forearm_l", "forearm_r"]:
		var att2 := rig.attach_bone(b)
		var k2 := MeshKit.new(17)
		k2.box(Vector3(0, -0.14, 0), Vector3(0.34, 0.12, 0.34), T, col)
		k2.box(Vector3(0, -0.08, 0), Vector3(0.36, 0.03, 0.36), T, trim)
		k2.box(Vector3(0, -0.2, 0), Vector3(0.355, 0.02, 0.355), T, trim.darkened(0.15))
		for rv2 in [-0.09, 0.0, 0.09]:
			k2.box(Vector3(rv2, -0.14, 0.175), Vector3(0.03, 0.03, 0.02), T, trim)
		att2.add_child(_mi(k2, "Bracer"))


# =====================================================================
#  Karakter party
# =====================================================================
static func _ren(rig: CharacterRig) -> Dictionary:
	var cape := _cape(rig, WHITE, Color(0.36, 0.58, 0.96), 1.3, 0.34, GOLD, true)
	_pauldrons(rig, WHITE, NAVY)
	_scarf(rig, Color(0.32, 0.55, 0.95))
	_belt(rig, Color(0.35, 0.3, 0.45), GOLD, true)
	_tabard(rig, Color(0.32, 0.55, 0.95), GOLD)
	_cuffs(rig, NAVY, GOLD)
	# aksesori rambut: jepit bintang emas + ahoge
	var head := rig.attach_bone("head")
	var k := MeshKit.new(18)
	k.box(Vector3(0.0, 0.68, 0.05), Vector3(0.06, 0.2, 0.06), T, WHITE)
	k.box(Vector3(-0.05, 0.83, 0.05), Vector3(0.05, 0.14, 0.05), T, ICE)
	k.box(Vector3(0.32, 0.5, 0.26), Vector3(0.04, 0.16, 0.16), T, GOLD)
	k.blob(Vector3(0.345, 0.5, 0.26), 0.07, T, ICE, 3, 6, 1.0, 0.2, 0.0, 0.5, 1.0)
	head.add_child(_mi(k, "HairAcc"))
	# kristal pengikat di pinggang
	var hip := rig.attach_bone("hips")
	var kc := MeshKit.new(19)
	kc.crystal(Vector3(-0.36, -0.1, 0.05), 0.07, 0.2, ICE, 0.9, 5)
	hip.add_child(_mi(kc, "Charm"))
	return {"cape": cape}


static func _lyra(rig: CharacterRig) -> Dictionary:
	var cape := _cape(rig, Color(0.62, 0.45, 0.88), Color(0.38, 0.28, 0.7), 1.1, 0.34, GOLD)
	_scarf(rig, Color(0.95, 0.9, 1.0))
	_belt(rig, Color(0.35, 0.25, 0.5), GOLD, false)
	_hat_witch(rig, Color(0.5, 0.36, 0.8), GOLD)
	_cuffs(rig, Color(0.95, 0.9, 1.0), GOLD)
	return {"cape": cape}


static func _brann(rig: CharacterRig) -> Dictionary:
	var cape := _cape(rig, Color(0.75, 0.3, 0.28), Color(0.5, 0.16, 0.18), 1.0, 0.34, GOLD)
	_pauldrons(rig, Color(0.62, 0.66, 0.76), Color(0.95, 0.75, 0.3))
	_belt(rig, Color(0.35, 0.25, 0.2), GOLD, true)
	_helmet(rig, Color(0.62, 0.66, 0.76), false)
	_cuffs(rig, Color(0.62, 0.66, 0.76), GOLD)
	return {"cape": cape}


static func _sera(rig: CharacterRig) -> Dictionary:
	var cape := _cape(rig, Color(0.42, 0.72, 0.5), Color(0.22, 0.48, 0.36), 0.95, 0.32, GOLD)
	_belt(rig, Color(0.42, 0.3, 0.2), GOLD, true)
	_headband(rig, Color(0.42, 0.78, 0.5))
	_cuffs(rig, Color(0.35, 0.58, 0.4), GOLD)
	_quiver(rig)
	return {"cape": cape}


static func _ember(rig: CharacterRig) -> Dictionary:
	var cape := _cape(rig, Color(0.9, 0.35, 0.18), Color(0.55, 0.14, 0.1), 1.0, 0.32, Color(1.0, 0.8, 0.3))
	_belt(rig, Color(0.3, 0.15, 0.1), Color(1.0, 0.8, 0.3), false)
	_hat_witch(rig, Color(0.8, 0.25, 0.15), Color(1.0, 0.8, 0.3))
	_cuffs(rig, Color(1.0, 0.9, 0.7), Color(1.0, 0.8, 0.3))
	return {"cape": cape}


static func _zeya(rig: CharacterRig) -> Dictionary:
	var cape := _cape(rig, Color(0.2, 0.14, 0.3), Color(0.9, 0.28, 0.45), 0.85, 0.3, Color(1.0, 0.5, 0.65))
	_belt(rig, Color(0.16, 0.12, 0.2), Color(1.0, 0.5, 0.65), true)
	_headband(rig, Color(0.9, 0.28, 0.45))
	_cuffs(rig, Color(0.2, 0.14, 0.3), Color(1.0, 0.5, 0.65))
	return {"cape": cape}


## Hakuya: haori putih bergaris hitam (jubah pendek), obi hitam, pita lengan bersilang, rambut perak panjang diikat tinggi.
static func _hakuya(rig: CharacterRig) -> Dictionary:
	var white := Color(0.96, 0.97, 1.0)
	var black := Color(0.1, 0.1, 0.14)
	var cape := _cape(rig, white, Color(0.78, 0.82, 0.9), 1.05, 0.4, black)
	_belt(rig, black, Color(0.75, 0.8, 0.9), false)
	_cuffs(rig, black, Color(0.9, 0.93, 1.0))
	_ponytail(rig, Color(0.9, 0.93, 0.98), black)
	_hakuya_sleeves(rig, white, black)
	return {"cape": cape}


# =====================================================================
#  Karakter baru (dari gambar referensi): Vael, Lucien, Wenyu, Kuroha
# =====================================================================
## Vael: hoodie putih (tudung terlipat di belakang), sabuk hitam, tanduk kecil hitam-biru, jubah pendek putih.
static func _vael(rig: CharacterRig) -> Dictionary:
	var white := Color(0.94, 0.96, 1.0)
	var cyan := Color(0.2, 0.85, 1.0)
	var dark := Color(0.08, 0.1, 0.18)
	var cape := _cape(rig, white, Color(0.7, 0.82, 0.95), 0.8, 0.36, cyan)
	_belt(rig, dark, Color(0.75, 0.8, 0.9), false)
	_cuffs(rig, dark, cyan)
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(60)
	k.box(Vector3(0, 0.6, -0.22), Vector3(0.74, 0.3, 0.28), T, white)           # tudung terlipat di leher
	k.box(Vector3(0, 0.5, -0.36), Vector3(0.5, 0.2, 0.1), T, white.darkened(0.12))
	k.box(Vector3(0, 0.66, 0.16), Vector3(0.42, 0.06, 0.1), T, dark)            # choker hitam
	k.box(Vector3(0.05, 0.3, 0.27), Vector3(0.03, 0.4, 0.03), T, cyan)         # tali hoodie
	k.box(Vector3(-0.05, 0.3, 0.27), Vector3(0.03, 0.4, 0.03), T, cyan)
	att.add_child(_mi(k, "Hoodie"))
	var h := rig.attach_bone("head")
	var hk := MeshKit.new(61)
	for sx in [-1.0, 1.0]:                                                       # tanduk melengkung ke belakang
		hk.box(Vector3(sx * 0.26, 0.55, 0.0), Vector3(0.14, 0.18, 0.14), T, dark)
		hk.box(Vector3(sx * 0.34, 0.7, -0.08), Vector3(0.11, 0.18, 0.11), T, dark)
		hk.box(Vector3(sx * 0.42, 0.83, -0.18), Vector3(0.08, 0.16, 0.08), T, Color(0.1, 0.3, 0.6))
		hk.box(Vector3(sx * 0.46, 0.94, -0.26), Vector3(0.04, 0.1, 0.04), T, _glow(cyan, 0.9))
	hk.box(Vector3(0, 0.5, -0.02), Vector3(0.7, 0.1, 0.7), T, Color(0.95, 0.97, 1.0))   # volume rambut atas
	hk.sway = 0.5
	for i in 5:                                                                  # poni acak
		hk.box(Vector3(-0.26 + i * 0.13, 0.38 - (i % 2) * 0.05, 0.37), Vector3(0.12, 0.16 + (i % 2) * 0.06, 0.05), T, Color(0.9, 0.94, 1.0))
	hk.sway = 0.0
	h.add_child(_mi(hk, "VaelHair"))
	return {"cape": cape}


## Pedang raksasa Vael: bilah lebar hitam berurat cyan bercahaya, pelindung bersayap, gagang berlilit tali cyan.
static func _greatsword(rig: CharacterRig) -> void:
	var k := MeshKit.new(62)
	var cyan := Color(0.25, 0.9, 1.0)
	var dark := Color(0.08, 0.12, 0.22)
	var L := 1.35
	k.box(Vector3(0, 0.1 + L * 0.5, 0), Vector3(0.2, L, 0.03), T, dark)
	k.box(Vector3(0, 0.1 + L * 0.5, 0), Vector3(0.05, L * 0.96, 0.04), T, _glow(cyan, 0.9))          # urat tengah
	for sx in [-1.0, 1.0]:
		k.box(Vector3(sx * 0.095, 0.1 + L * 0.5, 0), Vector3(0.02, L, 0.04), T, _glow(cyan, 0.7))   # tepi cahaya
		k.box(Vector3(sx * 0.05, 0.1 + L * 0.35, 0), Vector3(0.015, L * 0.5, 0.045), T, _glow(cyan, 0.6))
	k.cylinder(Vector3(0, 0.1 + L, 0), 0.1, 0.0, 0.2, 4, T, dark, false, -1, false, 1.0)
	k.box(Vector3(0, 0.1, 0), Vector3(0.46, 0.07, 0.08), T, dark)                                       # pelindung
	for sx in [-1.0, 1.0]:
		k.box(Vector3(sx * 0.26, 0.15, 0), Vector3(0.12, 0.08, 0.07), T, Color(0.1, 0.3, 0.6))
	k.blob(Vector3(0, 0.1, 0.05), 0.045, MeshKit.T_CRYSTAL, _glow(cyan, 1.0), 3, 5)
	k.box(Vector3(0, -0.08, 0), Vector3(0.05, 0.3, 0.05), T, Color(0.9, 0.95, 1.0))                     # gagang
	for i in 5:
		k.box(Vector3(0, -0.2 + i * 0.06, 0), Vector3(0.058, 0.018, 0.058), T, cyan)                    # lilitan tali
	k.blob(Vector3(0, -0.25, 0), 0.04, T, dark, 3, 5)
	var mi := _mi(k, "Greatsword")
	rig.add_in_right_hand(mi, Vector3.ZERO, Vector3.ZERO)
	CharFx.attach_blade_trail(mi, rig, Color(0.8, 0.98, 1.0), Color(0.1, 0.6, 1.0))


## Lucien: mantel panjang hitam berlis emas, kerah tinggi, monokel berantai, bros emas.
static func _lucien(rig: CharacterRig) -> Dictionary:
	var black := Color(0.08, 0.1, 0.22)
	var gold := Color(0.88, 0.7, 0.34)
	var cape := _cape(rig, black, Color(0.14, 0.17, 0.32), 1.45, 0.4, gold)
	_belt(rig, Color(0.1, 0.12, 0.24), gold, false)
	_cuffs(rig, black, gold)
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(63)
	k.box(Vector3(0, 0.62, 0.02), Vector3(0.5, 0.14, 0.4), T, black)                       # kerah tinggi
	for sx in [-1.0, 1.0]:
		k.box(Vector3(sx * 0.22, 0.3, 0.22), Vector3(0.05, 0.6, 0.04), T, gold)            # lis emas bukaan mantel
		k.box(Vector3(sx * 0.46, 0.45, 0.0), Vector3(0.2, 0.05, 0.4), T, gold)             # lis bahu
	k.blob(Vector3(0, 0.5, 0.24), 0.04, T, gold, 3, 5)
	for sx in [-1.0, 1.0]:                                                                 # panel sulaman emas di dada
		k.box(Vector3(sx * 0.3, 0.22, 0.225), Vector3(0.14, 0.34, 0.02), T, gold.darkened(0.15))
		k.box(Vector3(sx * 0.3, 0.22, 0.236), Vector3(0.08, 0.26, 0.01), T, black)
		k.blob(Vector3(sx * 0.08, 0.05 - 0.1 * (sx + 1.0) * 0.5, 0.235), 0.03, T, gold, 3, 5)  # kancing
	k.blob(Vector3(0, 0.38, 0.25), 0.05, MeshKit.T_CRYSTAL, _glow(Color(0.25, 0.4, 1.0), 0.9), 3, 5)  # liontin safir
	k.box(Vector3(0, 0.5, 0.235), Vector3(0.012, 0.2, 0.012), T, Color(0.8, 0.84, 0.95))
	att.add_child(_mi(k, "LucienCoat"))
	var h := rig.attach_bone("head")
	var hk := MeshKit.new(64)
	hk.box(Vector3(0, 0.5, -0.02), Vector3(0.72, 0.1, 0.72), T, Color(0.08, 0.11, 0.24))
	hk.sway = 0.4
	for i in 6:                                                                              # poni hitam acak menutupi dahi
		hk.box(Vector3(-0.3 + i * 0.12, 0.4 - (i % 3) * 0.04, 0.37), Vector3(0.12, 0.2 + (i % 3) * 0.05, 0.05), T, Color(0.08, 0.11, 0.24))
	hk.sway = 0.0
	# monokel di mata kanan karakter + rantai emas
	var mx := -0.16
	for a in 8:
		var an := float(a) / 8.0 * TAU
		hk.box(Vector3(mx + cos(an) * 0.1, 0.1 + sin(an) * 0.1, 0.4), Vector3(0.04, 0.04, 0.03), T, gold)
	hk.box(Vector3(mx + 0.1, -0.2, 0.4), Vector3(0.015, 0.5, 0.015), T, Color(0.82, 0.86, 0.95))
	hk.blob(Vector3(0.38, -0.05, 0.1), 0.035, MeshKit.T_CRYSTAL, _glow(Color(0.3, 0.5, 1.0), 0.8), 3, 5)  # anting
	h.add_child(_mi(hk, "Monocle"))
	return {"cape": cape}


## Tongkat Lucien: batang hitam, gagang emas berukir melengkung berkepala singa.
static func _cane(rig: CharacterRig) -> void:
	var k := MeshKit.new(65)
	var silver := Color(0.82, 0.86, 0.95)
	var gold := Color(0.9, 0.72, 0.35)
	k.box(Vector3(0, 0.55, 0), Vector3(0.045, 1.2, 0.045), T, Color(0.1, 0.1, 0.16))
	for i in 4:
		k.box(Vector3(0, 0.2 + i * 0.35, 0), Vector3(0.062, 0.03, 0.062), T, gold)
	k.cylinder(Vector3(0, 1.18, 0), 0.05, 0.035, 0.1, 6, T, silver, true, T, false, 1.0)
	k.box(Vector3(0, 1.26, 0), Vector3(0.1, 0.1, 0.1), T, gold)                                # leher berukir emas
	k.box(Vector3(0.06, 1.34, 0), Vector3(0.18, 0.07, 0.08), T, silver)                        # kepala elang perak melengkung
	k.blob(Vector3(0.17, 1.31, 0), 0.07, T, silver, 4, 6)
	k.box(Vector3(0.24, 1.26, 0), Vector3(0.05, 0.1, 0.05), T, silver)                         # paruh melengkung ke bawah
	k.box(Vector3(0.25, 1.2, 0), Vector3(0.03, 0.06, 0.03), T, silver.darkened(0.2))
	k.blob(Vector3(0.17, 1.33, 0.05), 0.025, MeshKit.T_CRYSTAL, _glow(Color(0.3, 0.5, 1.0), 0.9), 3, 5)
	rig.add_in_right_hand(_mi(k, "Cane"), Vector3.ZERO, Vector3.ZERO)


## Wenyu: rambut hitam sangat panjang berayun + bunga di sanggul, jubah tipis abu, lengan lebar, selempang.
static func _wenyu(rig: CharacterRig) -> Dictionary:
	var ink := Color(0.12, 0.12, 0.17)
	var pale := Color(0.88, 0.87, 0.95)
	var cape := _cape(rig, Color(0.76, 0.74, 0.86), Color(0.5, 0.55, 0.72), 1.6, 0.42, Color(0.9, 0.93, 1.0))
	_belt(rig, Color(0.35, 0.42, 0.58), Color(0.9, 0.93, 1.0), false)
	var att := rig.attach_bone("chest")
	var sk := MeshKit.new(66)
	for sx in [-1.0, 1.0]:                                                                       # lengan lebar
		sk.box(Vector3(sx * 0.46, 0.42, 0.0), Vector3(0.3, 0.12, 0.4), T, pale)
		sk.box(Vector3(sx * 0.46, 0.36, 0.0), Vector3(0.31, 0.03, 0.41), T, Color(0.5, 0.55, 0.72))
	att.add_child(_mi(sk, "WideSleeves"))
	var h := rig.attach_bone("head")
	var k := MeshKit.new(67)
	k.box(Vector3(0, 0.5, -0.02), Vector3(0.72, 0.1, 0.72), T, ink)
	k.box(Vector3(0, 0.3, -0.37), Vector3(0.74, 0.62, 0.1), T, ink)
	k.box(Vector3(-0.1, 0.62, -0.28), Vector3(0.3, 0.26, 0.26), T, ink)                           # sanggul
	k.sway = 0.7
	for sx in [-1.0, 1.0]:                                                                       # sisi wajah
		k.box(Vector3(sx * 0.4, 0.2, 0.05), Vector3(0.1, 0.7, 0.3), T, ink)
	var y := 0.0
	for i in 9:                                                                                  # rambut panjang ke bawah
		var w := 0.7 - i * 0.03
		k.box(Vector3(sin(float(i) * 0.7) * 0.06, y, -0.42 - i * 0.02), Vector3(w, 0.3, 0.1), T, ink.lerp(Color(0.3, 0.3, 0.38), float(i) / 12.0))
		y -= 0.28
	k.sway = 1.3
	for j in 4:
		for i in 5:
			k.box(Vector3((j - 1.5) * 0.2 + sin(float(i)) * 0.05, -0.2 - i * 0.28, -0.52 - j * 0.02), Vector3(0.05, 0.3, 0.04), T, ink.lightened(0.12))
	k.sway = 0.0
	# bunga di sanggul + untaian manik
	for a in 7:
		var an := float(a) / 7.0 * TAU
		k.blob(Vector3(-0.28 + cos(an) * 0.13, 0.74 + sin(an) * 0.12, -0.12), 0.07, T, Color(0.94, 0.97, 1.0), 3, 5)
	for a in 5:
		var an2 := float(a) / 5.0 * TAU + 0.3
		k.blob(Vector3(-0.28 + cos(an2) * 0.06, 0.74 + sin(an2) * 0.06, -0.08), 0.05, T, Color(0.8, 0.86, 0.98), 3, 5)
	k.blob(Vector3(-0.28, 0.74, -0.05), 0.04, T, Color(0.98, 0.85, 0.5), 3, 5)
	k.sway = 0.9
	for i in 8:
		k.blob(Vector3(-0.4, 0.62 - i * 0.12, -0.08), 0.028, T, Color(0.92, 0.95, 1.0), 2, 4)   # untaian manik
	for i in 5:
		k.blob(Vector3(-0.46, 0.5 - i * 0.12, -0.04), 0.022, T, Color(0.7, 0.9, 0.85), 2, 4)
	h.add_child(_mi(k, "WenyuHair"))
	return {"cape": cape}


## Seruling bambu hitam Wenyu dengan rumbai di ujung.
static func _flute(rig: CharacterRig) -> void:
	var k := MeshKit.new(68)
	var jade := Color(0.55, 0.88, 0.74)
	k.box(Vector3(0, 0.3, 0), Vector3(0.05, 1.0, 0.05), T, jade)
	k.box(Vector3(0, 0.3, 0.012), Vector3(0.02, 0.96, 0.03), T, jade.lightened(0.35))
	for i in 3:
		k.box(Vector3(0, -0.1 + i * 0.4, 0), Vector3(0.062, 0.025, 0.062), T, Color(0.92, 0.95, 0.98))
	for i in 5:
		k.blob(Vector3(0, 0.25 + i * 0.07, 0.026), 0.013, T, jade.darkened(0.35), 2, 4)
	k.sway = 1.0
	k.box(Vector3(0, -0.28, 0), Vector3(0.025, 0.22, 0.025), T, Color(0.7, 0.9, 0.85))
	k.blob(Vector3(0, -0.42, 0), 0.03, T, Color(0.9, 0.98, 0.95), 3, 5)
	rig.add_in_right_hand(_mi(k, "Flute"), Vector3.ZERO, Vector3.ZERO)


## Kuroha: mantel panjang hitam berlis putih, kerah tinggi putih, pita rumbai putih, rambut pendek acak.
static func _kuroha(rig: CharacterRig) -> Dictionary:
	var black := Color(0.08, 0.08, 0.11)
	var white := Color(0.94, 0.96, 1.0)
	var cape := _cape(rig, black, Color(0.2, 0.2, 0.28), 1.7, 0.42, white)
	_belt(rig, Color(0.12, 0.12, 0.16), Color(0.8, 0.85, 0.95), false)
	_cuffs(rig, black, white)
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(69)
	k.box(Vector3(0, 0.64, 0.0), Vector3(0.58, 0.18, 0.44), T, black)                         # kerah tinggi
	k.box(Vector3(0, 0.72, 0.02), Vector3(0.6, 0.04, 0.46), T, white)
	for sx in [-1.0, 1.0]:
		k.box(Vector3(sx * 0.12, 0.35, 0.22), Vector3(0.06, 0.62, 0.03), T, white)         # lapel putih
	k.box(Vector3(0, 0.0, 0.23), Vector3(0.18, 0.12, 0.03), T, Color(0.45, 0.65, 0.95))    # batu biru
	k.sway = 1.0
	for sx in [-0.3, -0.12, 0.12, 0.3]:                                                         # rumbai putih menggantung
		k.box(Vector3(sx, -0.15, 0.24), Vector3(0.035, 0.42, 0.02), T, white)
	k.box(Vector3(0.6, 0.35, -0.05), Vector3(0.04, 0.5, 0.03), T, white)                      # pita bahu
	k.sway = 0.0
	att.add_child(_mi(k, "KurohaCoat"))
	var h := rig.attach_bone("head")
	var hk := MeshKit.new(70)
	hk.box(Vector3(0, 0.5, -0.02), Vector3(0.72, 0.1, 0.72), T, Color(0.94, 0.96, 1.0))
	hk.sway = 0.6
	for i in 7:
		var xx := -0.32 + i * 0.107
		hk.box(Vector3(xx, 0.62 + (i % 2) * 0.08, 0.05 - (i % 3) * 0.1), Vector3(0.12, 0.16, 0.12), T, Color(0.9, 0.93, 1.0))
		hk.box(Vector3(xx, 0.4 - (i % 3) * 0.04, 0.38), Vector3(0.11, 0.18 + (i % 3) * 0.05, 0.05), T, Color(0.93, 0.95, 1.0))
	hk.sway = 0.0
	h.add_child(_mi(hk, "KurohaHair"))
	return {"cape": cape}


## Aion (pengendali waktu): desain ramping & elegan. Mantel panjang putih-hitam berkerah tinggi, pelindung bahu bersudut,
## jubah pendek asimetris di satu bahu, dasi pita teal + bros jam emas kecil, celemek panjang tipis, rambut putih disisir ke samping
## dengan kuncir rendah berklip emas. Tanpa stola bulu, simpul/bola, sanggul, maupun anting rumbai (terasa berat & aneh).
static func _aion(rig: CharacterRig) -> Dictionary:
	var white := Color(0.96, 0.97, 1.0)
	var black := Color(0.09, 0.09, 0.12)
	var teal := Color(0.17, 0.72, 0.68)
	var gold := Color(0.78, 0.66, 0.36)
	var ice := Color(0.55, 0.78, 1.0)
	var cape := _cape(rig, white, black, 1.45, 0.3, teal)
	_belt(rig, black, gold, false)
	_cuffs(rig, black, gold)
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(81)
	# kerah tinggi hitam + garis emas
	k.box(Vector3(0, 0.6, 0.0), Vector3(0.5, 0.14, 0.4), T, black)
	k.box(Vector3(0, 0.68, 0.02), Vector3(0.52, 0.03, 0.42), T, gold)
	# dasi pita teal tipis + penjepit emas + bros jam wajik (kotak kecil, bukan bola)
	k.sway = 1.0
	k.box(Vector3(0, 0.06, 0.26), Vector3(0.07, 0.5, 0.02), T, teal)
	k.box(Vector3(0, -0.22, 0.26), Vector3(0.07, 0.05, 0.025), T, gold)
	k.sway = 0.0
	k.box(Vector3(0, 0.32, 0.265), Vector3(0.09, 0.09, 0.02), T, gold)
	k.box(Vector3(0, 0.32, 0.278), Vector3(0.045, 0.045, 0.02), T, _glow(ice, 0.9))
	# pelindung bahu bersudut: putih, tepi hitam, garis emas tipis
	for sx in [-1.0, 1.0]:
		k.box(Vector3(sx * 0.44, 0.54, 0.0), Vector3(0.3, 0.07, 0.34), T, white)
		k.box(Vector3(sx * 0.46, 0.49, 0.0), Vector3(0.3, 0.04, 0.35), T, black)
		k.box(Vector3(sx * 0.44, 0.585, 0.0), Vector3(0.24, 0.025, 0.28), T, gold)
	# jubah pendek asimetris di bahu kiri: putih -> hitam, runcing ke bawah (dua sisi agar terlihat dari mana pun)
	k.sway = 0.8
	var wt := Vector3(-0.6, 0.56, 0.17)
	var wb := Vector3(-0.6, 0.56, -0.17)
	var ht := Vector3(-0.66, -0.5, 0.05)
	var hb := Vector3(-0.66, -0.5, -0.1)
	k.quad_free(wt, wb, hb, ht, Vector3(-1, 0, 0), MeshKit.T_CLOTH, white, white, black, black,
		Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	k.quad_free(wt, wb, hb, ht, Vector3(1, 0, 0), MeshKit.T_CLOTH, white, white, black, black,
		Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	k.box(Vector3(-0.66, -0.47, -0.02), Vector3(0.025, 0.06, 0.2), T, teal)
	k.sway = 0.0
	att.add_child(_mi(k, "AionCoat"))
	# celemek panjang tipis (putih bermotif di depan, hitam di belakang) di pinggul
	var hp := rig.attach_bone("hips")
	var ap := MeshKit.new(83)
	ap.sway = 0.5
	ap.box(Vector3(0, -0.34, 0.2), Vector3(0.3, 0.7, 0.03), T, white)
	ap.box(Vector3(0, -0.34, 0.215), Vector3(0.04, 0.7, 0.02), T, black)
	ap.box(Vector3(0, -0.66, 0.2), Vector3(0.3, 0.08, 0.035), T, teal)
	ap.box(Vector3(0, -0.34, -0.2), Vector3(0.3, 0.7, 0.03), T, black)
	ap.box(Vector3(0, -0.34, -0.215), Vector3(0.04, 0.7, 0.02), T, white)
	ap.sway = 0.0
	hp.add_child(_mi(ap, "AionApron"))
	# rambut: volume atas rapi, beberapa jambul runcing, kuncir rendah berklip emas (poni miring ditambah _hair_volume)
	var h := rig.attach_bone("head")
	var hk := MeshKit.new(84)
	hk.box(Vector3(0, 0.5, -0.02), Vector3(0.72, 0.1, 0.72), T, Color(0.95, 0.96, 1.0))
	hk.sway = 0.4
	for i in 4:
		var xx := -0.2 + i * 0.13
		hk.box(Vector3(xx, 0.6 + (i % 2) * 0.05, 0.08 - (i % 3) * 0.1), Vector3(0.11, 0.13, 0.11), T, Color(0.93, 0.95, 1.0))
	hk.sway = 0.0
	hk.box(Vector3(0, 0.16, -0.42), Vector3(0.12, 0.1, 0.1), T, gold)                             # klip emas
	hk.sway = 0.9
	for i in 6:
		hk.box(Vector3(sin(float(i) * 0.8) * 0.05, 0.02 - i * 0.26, -0.46 - i * 0.02), Vector3(0.2 - i * 0.02, 0.3, 0.1), T, Color(0.92, 0.94, 0.99).darkened(i * 0.02))
	hk.sway = 0.0
	h.add_child(_mi(hk, "AionHair"))
	return {"cape": cape}


## Tongkat jam: gagang gelap bercincin emas, kepala berupa lingkaran jam emas dengan jarum biru bercahaya & rumbai teal.
static func _clock_staff(rig: CharacterRig) -> void:
	var k := MeshKit.new(85)
	var gold := Color(0.85, 0.7, 0.36)
	var teal := Color(0.17, 0.72, 0.68)
	k.box(Vector3(0, 0.55, 0), Vector3(0.05, 1.2, 0.05), T, Color(0.1, 0.1, 0.15))
	for i in 4:
		k.box(Vector3(0, 0.15 + i * 0.32, 0), Vector3(0.07, 0.03, 0.07), T, gold)
	k.cylinder(Vector3(0, 1.15, 0), 0.06, 0.045, 0.1, 6, T, gold, true, T, false, 1.0)
	k.torus_xy(Vector3(0, 1.45, 0), 0.22, 0.03, 14, 5, T, gold)                                    # lingkar jam
	k.box(Vector3(0, 1.45, 0), Vector3(0.015, 0.34, 0.02), T, _glow(Color(0.35, 0.6, 1.0), 0.95))   # jarum menit
	k.box(Vector3(0.06, 1.45, 0), Vector3(0.1, 0.015, 0.02), T, _glow(Color(0.6, 0.8, 1.0), 0.95))  # jarum jam
	for a in 4:
		var ang := float(a) * PI * 0.5
		k.box(Vector3(sin(ang) * 0.19, 1.45 + cos(ang) * 0.19, 0), Vector3(0.025, 0.025, 0.02), T, gold)
	k.blob(Vector3(0, 1.45, 0), 0.03, MeshKit.T_CRYSTAL, _glow(Color(0.6, 0.85, 1.0), 0.9), 3, 5)
	k.sway = 1.0
	k.box(Vector3(0.04, 1.12, 0), Vector3(0.03, 0.3, 0.02), T, teal)
	k.sway = 0.0
	rig.add_in_right_hand(_mi(k, "ClockStaff"), Vector3.ZERO, Vector3.ZERO)


## Rambut Hakuya (mengikuti gambar): ekor kuda tinggi yang tebal, panjang, bergelombang + helai liar tipis, jambul tebal,
## dan sisi rambut yang mengembang di samping wajah. Semua berayun lembut (sway).
static func _ponytail(rig: CharacterRig, col: Color, tie: Color) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(27)
	var lite := Color(0.97, 0.98, 1.0)
	var dark := Color(0.72, 0.78, 0.9)
	# ikat hitam di atas-belakang kepala + jambul tebal
	k.box(Vector3(0, 0.6, -0.3), Vector3(0.26, 0.17, 0.24), T, tie)
	k.box(Vector3(0, 0.55, -0.02), Vector3(0.72, 0.1, 0.72), T, lite)         # tudung rambut (volume atas)
	k.box(Vector3(0, 0.3, -0.37), Vector3(0.74, 0.62, 0.1), T, col)            # rambut belakang kepala
	k.sway = 0.35
	for sx in [-1.0, 1.0]:                                                       # sisi mengembang
		k.box(Vector3(sx * 0.4, 0.32, 0.02), Vector3(0.1, 0.5, 0.42), T, col.lightened(0.04))
		k.box(Vector3(sx * 0.42, -0.02, 0.1), Vector3(0.07, 0.34, 0.14), T, dark)
	# ekor kuda utama: tebal, bergelombang (S), mengecil ke ujung
	k.sway = 0.9
	var y := 0.52
	var z := -0.38
	var w := 0.46
	for i in 8:
		var wave := sin(float(i) * 0.95) * 0.09
		var c := lite.lerp(dark, float(i) / 8.0 * 0.55)
		k.box(Vector3(wave, y, z), Vector3(w, 0.3, 0.2 - i * 0.012), T, c)
		# helai pemisah gelap tipis agar terlihat berserat
		k.box(Vector3(wave + w * 0.22, y, z - 0.1), Vector3(0.03, 0.3, 0.02), T, dark)
		k.box(Vector3(wave - w * 0.2, y, z - 0.1), Vector3(0.03, 0.3, 0.02), T, dark)
		y -= 0.27
		z -= 0.045
		w = maxf(w - 0.04, 0.16)
	# helai liar tipis di kedua sisi ekor kuda (seperti di gambar)
	k.sway = 1.3
	for j in 4:
		var side := -1.0 if j % 2 == 0 else 1.0
		var sy := 0.2 - j * 0.12
		for i in 4:
			k.box(Vector3(side * (0.3 + j * 0.05 + sin(float(i)) * 0.05), sy - i * 0.2, -0.4 - j * 0.02), Vector3(0.05, 0.22, 0.04), T, lite.lerp(dark, 0.3))
	k.sway = 0.0
	att.add_child(_mi(k, "Ponytail"))


## Lengan lebar haori: dua panel putih di sisi dada dengan motif silang hitam.
static func _hakuya_sleeves(rig: CharacterRig, white: Color, black: Color) -> void:
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(28)
	for sx in [-1.0, 1.0]:
		k.box(Vector3(sx * 0.46, 0.42, 0.0), Vector3(0.3, 0.12, 0.4), T, white)
		k.box(Vector3(sx * 0.46, 0.36, 0.0), Vector3(0.31, 0.03, 0.41), T, black)
		k.box(Vector3(sx * 0.46, 0.43, 0.2), Vector3(0.14, 0.03, 0.02), T, black)
	att.add_child(_mi(k, "HaoriSleeves"))


# =====================================================================
#  Topi & kepala (satuan rig, relatif sendi kepala; atas kepala = y +0.61)
# =====================================================================
static func _hat_witch(rig: CharacterRig, col: Color, trim: Color) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(21)
	k.cylinder(Vector3(0, 0.56, 0), 0.62, 0.62, 0.06, 10, T, col, true, T, false, 1.0)
	k.cylinder(Vector3(0, 0.6, 0), 0.42, 0.14, 0.5, 8, T, col, false, -1, false, 0.9)
	k.cylinder(Vector3(0, 1.08, 0), 0.14, 0.0, 0.3, 8, T, col, false, -1, false, 0.95)
	k.cylinder(Vector3(0, 0.62, 0), 0.43, 0.43, 0.08, 10, T, trim, false, -1, false, 1.0)
	k.blob(Vector3(0, 1.36, 0), 0.05, T, trim, 3, 5)
	att.add_child(_mi(k, "Hat"))


static func _hat_wide(rig: CharacterRig, col: Color) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(22)
	k.cylinder(Vector3(0, 0.55, 0), 0.7, 0.66, 0.05, 12, T, col, true, T, false, 1.0)
	k.cylinder(Vector3(0, 0.58, 0), 0.4, 0.34, 0.26, 10, T, col, true, T, false, 0.9)
	k.cylinder(Vector3(0, 0.6, 0), 0.41, 0.41, 0.07, 10, T, GOLD, false, -1, false, 1.0)
	k.box(Vector3(0.2, 0.82, 0.3), Vector3(0.04, 0.4, 0.04), T, Color(1, 1, 1))
	att.add_child(_mi(k, "Hat"))


static func _hat_beret(rig: CharacterRig, col: Color) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(23)
	k.blob(Vector3(0.05, 0.66, 0), 0.4, T, col, 4, 8, 0.4, 0.3, 0.0, 1.1, 1.0)
	k.blob(Vector3(0.05, 0.86, 0), 0.05, T, GOLD, 3, 5)
	att.add_child(_mi(k, "Beret"))


static func _crown_hat(rig: CharacterRig) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(24)
	k.cylinder(Vector3(0, 0.6, 0), 0.4, 0.38, 0.12, 8, T, GOLD, false, -1, false, 1.0)
	for i in 5:
		var a := i * TAU / 5.0
		k.cylinder(Vector3(cos(a) * 0.36, 0.7, sin(a) * 0.36), 0.07, 0.0, 0.24, 4, T, GOLD, false, -1, false, 1.0)
	k.crystal(Vector3(0, 0.74, 0.38), 0.05, 0.14, ICE, 0.9, 4)
	att.add_child(_mi(k, "Circlet"))


static func _helmet(rig: CharacterRig, col: Color, plume: bool) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(25)
	k.box(Vector3(0, 0.62, 0), Vector3(0.66, 0.14, 0.66), T, col)
	k.box(Vector3(0, 0.36, -0.34), Vector3(0.66, 0.5, 0.06), T, col)
	k.box(Vector3(0, 0.74, 0.0), Vector3(0.2, 0.14, 0.7), T, GOLD)
	for sx in [-1.0, 1.0]:
		k.cylinder(Vector3(sx * 0.34, 0.66, 0.0), 0.07, 0.0, 0.3, 5, T, Color(0.95, 0.92, 0.85), false, -1, false, 1.0)
	if plume:
		k.sway = 0.8
		k.box(Vector3(0, 0.95, -0.1), Vector3(0.1, 0.34, 0.4), T, Color(0.9, 0.3, 0.3))
		k.sway = 0.0
	att.add_child(_mi(k, "Helmet"))


static func _headband(rig: CharacterRig, col: Color) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(26)
	k.box(Vector3(0, 0.5, 0), Vector3(0.66, 0.08, 0.66), T, col)
	k.sway = 0.9
	k.box(Vector3(-0.36, 0.45, -0.2), Vector3(0.06, 0.36, 0.04), T, col)
	k.sway = 0.0
	k.blob(Vector3(0, 0.52, 0.34), 0.06, T, GOLD, 3, 5)
	att.add_child(_mi(k, "Headband"))


static func _goggles(rig: CharacterRig) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(27)
	k.box(Vector3(0, 0.58, 0), Vector3(0.66, 0.06, 0.66), T, Color(0.3, 0.22, 0.2))
	for sx in [-0.17, 0.17]:
		k.cylinder(Vector3(sx, 0.62, 0.3), 0.12, 0.12, 0.08, 8, T, Color(0.5, 0.45, 0.42), true, T, false, 1.0)
		k.blob(Vector3(sx, 0.62, 0.4), 0.09, T, Color(0.55, 0.85, 1.0), 3, 6, 1.0, 0.2, 0.0, 1.0, 0.3)
	att.add_child(_mi(k, "Goggles"))


static func _veil(rig: CharacterRig) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(28)
	k.sway = 0.6
	k.quad_free(Vector3(-0.38, 0.62, 0.34), Vector3(0.38, 0.62, 0.34), Vector3(0.4, 0.1, 0.36), Vector3(-0.4, 0.1, 0.36), Vector3(0, 0, 1), MeshKit.T_CLOTH,
		Color(0.98, 0.96, 0.92), Color(0.98, 0.96, 0.92), Color(1, 1, 1), Color(1, 1, 1), Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	k.sway = 0.0
	k.box(Vector3(0, 0.65, 0), Vector3(0.7, 0.1, 0.7), T, GOLD)
	k.blob(Vector3(0, 0.7, 0.36), 0.07, T, ICE, 3, 6)
	att.add_child(_mi(k, "Veil"))


# =====================================================================
#  Perlengkapan punggung / badan (rig)
# =====================================================================
static func _backpack(rig: CharacterRig, col: Color) -> void:
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(31)
	k.box(Vector3(0, 0.15, -0.34), Vector3(0.56, 0.7, 0.3), T, col)
	k.box(Vector3(0, 0.55, -0.34), Vector3(0.58, 0.14, 0.32), T, Color(col.r * 0.8, col.g * 0.8, col.b * 0.8))
	k.box(Vector3(0, -0.12, -0.34), Vector3(0.3, 0.2, 0.34), T, Color(0.95, 0.9, 0.7))
	for sx in [-0.2, 0.2]:
		k.box(Vector3(sx, 0.25, -0.05), Vector3(0.08, 0.7, 0.03), T, Color(0.4, 0.28, 0.2))
	att.add_child(_mi(k, "Backpack"))


static func _satchel(rig: CharacterRig, col: Color) -> void:
	var att := rig.attach_bone("hips")
	var k := MeshKit.new(32)
	k.box(Vector3(0.38, -0.08, 0.05), Vector3(0.2, 0.34, 0.3), T, col)
	k.box(Vector3(0.38, 0.1, 0.05), Vector3(0.22, 0.06, 0.32), T, GOLD)
	for i in 3:
		k.blob(Vector3(0.38, 0.14, -0.04 + i * 0.09), 0.06, MeshKit.T_CRYSTAL, _glow([Pal.PINK, Pal.GOLD, ICE][i], 0.8), 3, 5)
	k.box(Vector3(0, 0.1, 0), Vector3(0.66, 0.1, 0.34), T, Color(0.4, 0.3, 0.22))
	att.add_child(_mi(k, "Satchel"))


static func _apron(rig: CharacterRig, col: Color) -> void:
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(33)
	k.quad_free(Vector3(-0.28, 0.4, 0.17), Vector3(0.28, 0.4, 0.17), Vector3(0.3, -0.7, 0.18), Vector3(-0.3, -0.7, 0.18), Vector3(0, 0, 1), MeshKit.T_CLOTH,
		col, col, col, col, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	k.box(Vector3(0, 0.45, 0), Vector3(0.62, 0.04, 0.32), T, Color(0.3, 0.22, 0.18))
	att.add_child(_mi(k, "Apron"))


static func _book(rig: CharacterRig) -> void:
	var k := MeshKit.new(34)
	k.box(Vector3(0, 0.0, 0.0), Vector3(0.22, 0.04, 0.3), T, Color(0.5, 0.3, 0.75))
	k.box(Vector3(0, 0.03, 0.0), Vector3(0.2, 0.025, 0.28), T, Color(0.98, 0.95, 0.85))
	k.box(Vector3(0, 0.05, 0.0), Vector3(0.22, 0.02, 0.3), T, Color(0.5, 0.3, 0.75))
	k.blob(Vector3(0, 0.07, 0.0), 0.04, T, GOLD, 3, 5)
	rig.add_in_left_hand(_mi(k, "Book"), Vector3(0.0, 0.05, 0.05), Vector3(0, 0, 0))


static func _banner_back(rig: CharacterRig) -> void:
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(35)
	k.box(Vector3(0.28, 0.9, -0.52), Vector3(0.06, 1.7, 0.06), T, Color(0.45, 0.32, 0.22))
	k.sway = 0.8
	k.quad_free(Vector3(0.31, 1.4, -0.52), Vector3(0.9, 1.4, -0.52), Vector3(0.9, 1.9, -0.52), Vector3(0.31, 1.9, -0.52), Vector3(0, 0, -1), MeshKit.T_CLOTH,
		Pal.BLUE, Pal.BLUE, Pal.BLUE, Pal.BLUE, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
	k.sway = 0.0
	_star(k, Vector3(0.6, 1.65, -0.53), 0.14, GOLD)
	att.add_child(_mi(k, "Banner"))


static func _quiver(rig: CharacterRig) -> void:
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(36)
	k.push()
	k.move(0.18, 0.2, -0.3)
	k.roll(-18.0)
	k.cylinder(Vector3(0, -0.4, 0), 0.14, 0.14, 0.85, 7, T, Color(0.5, 0.36, 0.24), true, T, true, 1.0)
	for i in 4:
		k.cylinder(Vector3(-0.07 + i * 0.05, 0.4, 0.0), 0.012, 0.012, 0.28, 4, T, Color(0.8, 0.7, 0.55), false, -1, false, 1.0)
		k.cylinder(Vector3(-0.07 + i * 0.05, 0.62, 0.0), 0.04, 0.0, 0.1, 4, T, Color(0.4, 0.8, 0.5), false, -1, false, 1.0)
	k.pop()
	att.add_child(_mi(k, "Quiver"))


# =====================================================================
#  Senjata (satuan METER, bilah menghadap +Y pada WeaponHolder)
# =====================================================================
static func _sword_mesh(k: MeshKit, length: float, glow_blade: bool = true) -> void:
	var blade := _glow(SILVER, 0.55) if glow_blade else SILVER
	k.box(Vector3(0, 0.1 + length * 0.5, 0), Vector3(0.075, length, 0.018), T, blade)
	k.box(Vector3(0, 0.1 + length * 0.5, 0), Vector3(0.03, length * 0.98, 0.03), T, ICE)
	k.cylinder(Vector3(0, 0.1 + length, 0), 0.0375, 0.0, 0.12, 4, T, blade, false, -1, false, 1.0)
	k.box(Vector3(0, 0.1, 0), Vector3(0.3, 0.05, 0.05), T, GOLD)
	k.blob(Vector3(0, 0.1, 0.03), 0.03, MeshKit.T_CRYSTAL, _glow(ICE, 0.9), 3, 5)
	k.box(Vector3(0, 0.0, 0), Vector3(0.04, 0.2, 0.04), T, Color(0.3, 0.25, 0.4))
	k.blob(Vector3(0, -0.12, 0), 0.04, T, GOLD, 3, 5)


static func _sword(rig: CharacterRig) -> void:
	var k := MeshKit.new(40)
	_sword_mesh(k, 0.9)
	rig.add_in_right_hand(_mi(k, "Sword"), Vector3.ZERO, Vector3.ZERO)


## Katana di tangan kanan (bilah perak tipis, tsuba persegi, gagang hitam) + sarung hitam di pinggang kiri.
static func _katana(rig: CharacterRig, fire: bool = true) -> void:
	var k := MeshKit.new(46)
	var blade := _glow(Color(0.9, 0.95, 1.0), 0.6)
	k.box(Vector3(0, 0.1 + 0.6, 0), Vector3(0.05, 1.2, 0.014), T, blade)
	k.box(Vector3(0, 0.1 + 0.6, 0), Vector3(0.018, 1.18, 0.022), T, Color(0.6, 0.78, 1.0))
	k.cylinder(Vector3(0, 0.1 + 1.2, 0), 0.025, 0.0, 0.1, 4, T, blade, false, -1, false, 1.0)
	k.box(Vector3(0, 0.1, 0), Vector3(0.14, 0.03, 0.14), T, Color(0.18, 0.18, 0.24))
	k.box(Vector3(0, -0.06, 0), Vector3(0.05, 0.3, 0.05), T, Color(0.08, 0.08, 0.12))
	for i in 4:
		k.box(Vector3(0, -0.14 + i * 0.07, 0), Vector3(0.056, 0.012, 0.056), T, Color(0.55, 0.62, 0.78))
	k.blob(Vector3(0, -0.23, 0), 0.035, T, Color(0.18, 0.18, 0.24), 3, 5)
	var kmi := _mi(k, "Katana")
	rig.add_in_right_hand(kmi, Vector3.ZERO, Vector3.ZERO)
	if fire:
		CharFx.blade_fire(kmi)
		CharFx.attach_blade_trail(kmi, rig, Color(0.95, 0.98, 1.0), Color(0.3, 0.6, 1.0))
	else:
		CharFx.attach_blade_trail(kmi, rig, Color(0.92, 0.94, 1.0), Color(0.25, 0.25, 0.4))
	# sarung (saya) di pinggang
	var att := rig.attach_bone("hips")
	var s := MeshKit.new(47)
	s.box(Vector3(-0.38, 0.0, 0.0), Vector3(0.09, 0.09, 1.0), T, Color(0.08, 0.08, 0.12))
	s.box(Vector3(-0.38, 0.0, 0.5), Vector3(0.11, 0.11, 0.06), T, Color(0.7, 0.76, 0.9))
	s.box(Vector3(-0.38, 0.0, -0.3), Vector3(0.11, 0.11, 0.05), T, Color(0.7, 0.76, 0.9))
	att.add_child(_mi(s, "Saya"))


static func _daggers(rig: CharacterRig) -> void:
	for side in 2:
		var k := MeshKit.new(43 + side)
		_sword_mesh(k, 0.42)
		if side == 0:
			rig.add_in_right_hand(_mi(k, "DaggerR"), Vector3.ZERO, Vector3.ZERO)
		else:
			rig.add_in_left_hand(_mi(k, "DaggerL"), Vector3.ZERO, Vector3.ZERO)


static func _staff_mesh(k: MeshKit, length: float, orb: Color) -> void:
	k.box(Vector3(0, length * 0.5 - 0.3, 0), Vector3(0.05, length, 0.05), T, Color(0.55, 0.38, 0.28))
	k.cylinder(Vector3(0, length - 0.38, 0), 0.07, 0.11, 0.08, 6, T, GOLD, true, T, false, 1.0)
	k.crystal(Vector3(0, length - 0.28, 0), 0.1, 0.3, orb, 0.95, 6)
	k.box(Vector3(0, length - 0.34, 0), Vector3(0.22, 0.03, 0.03), T, GOLD)
	k.box(Vector3(0, length - 0.34, 0), Vector3(0.03, 0.03, 0.22), T, GOLD)


static func _staff(rig: CharacterRig) -> void:
	var k := MeshKit.new(41)
	_staff_mesh(k, 1.6, Color(0.75, 0.55, 1.0))
	rig.add_in_right_hand(_mi(k, "Staff"), Vector3(0, 0, 0), Vector3.ZERO)


static func _hammer_mesh(k: MeshKit, length: float, head_w: float, head_h: float) -> void:
	k.box(Vector3(0, length * 0.5 - 0.1, 0), Vector3(0.06, length, 0.06), T, Color(0.5, 0.35, 0.25))
	k.box(Vector3(0, length - 0.1, 0), Vector3(head_w, head_h, head_h), T, Color(0.62, 0.66, 0.76))
	k.box(Vector3(0, length - 0.1, 0), Vector3(head_w + 0.04, head_h * 0.3, head_h + 0.02), T, GOLD)
	k.blob(Vector3(0, -0.12, 0), 0.04, T, GOLD, 3, 5)


static func _hammer(rig: CharacterRig) -> void:
	var k := MeshKit.new(42)
	_hammer_mesh(k, 1.0, 0.46, 0.3)
	rig.add_in_right_hand(_mi(k, "Hammer"), Vector3.ZERO, Vector3.ZERO)


static func _shield(rig: CharacterRig) -> void:
	var k := MeshKit.new(43)
	k.cylinder(Vector3(0, 0, 0), 0.34, 0.34, 0.05, 12, T, Color(0.4, 0.45, 0.8), true, T, false, 1.0)
	k.cylinder(Vector3(0, 0.05, 0), 0.34, 0.34, 0.015, 12, T, GOLD, false, -1, false, 1.0)
	k.blob(Vector3(0, 0.07, 0), 0.1, T, Color(0.95, 0.85, 0.5), 3, 6, 0.6, 0.2)
	rig.add_in_left_hand(_mi(k, "Shield"), Vector3(0.18, 0.1, 0.1), Vector3(0, 0, -90))


static func _bow(rig: CharacterRig) -> void:
	var k := MeshKit.new(44)
	k.push()
	k.pitch(0.0)
	# busur melengkung: busur torus (bidang XY) -> dikecilkan
	k.torus_xy(Vector3(0, 0.0, 0), 0.5, 0.02, 14, 4, T, Color(0.55, 0.38, 0.25), -PI * 0.38, PI * 0.38)
	k.pop()
	k.box(Vector3(0.5 * cos(PI * 0.38) - 0.01, 0.0, 0), Vector3(0.006, 2.0 * 0.5 * sin(PI * 0.38), 0.006), T, Color(0.95, 0.95, 0.9))
	k.box(Vector3(0.5, 0.0, 0), Vector3(0.05, 0.12, 0.05), T, GOLD)
	var mi := _mi(k, "Bow")
	# busur di tangan kiri: sumbu panjang tegak (Y dunia), lengkung menghadap depan (+Z)
	rig.add_in_left_hand(mi, Vector3(0.0, 0.0, 0.05), Vector3(0, 90, 90))


static func _spear_mesh(k: MeshKit, length: float) -> void:
	k.box(Vector3(0, length * 0.5 - 0.3, 0), Vector3(0.045, length, 0.045), T, Color(0.5, 0.36, 0.26))
	k.cylinder(Vector3(0, length - 0.3, 0), 0.07, 0.0, 0.32, 4, T, SILVER, false, -1, false, 1.0)
	k.sway = 0.0
	k.box(Vector3(0, length - 0.32, 0), Vector3(0.14, 0.03, 0.03), T, GOLD)


# =====================================================================
#  Musuh humanoid (Bab 4-5): pengikut berkerudung bertopeng putih, penyihir bayangan, ksatria rantai, ronin, Uranos, Raja Rantai Merah
# =====================================================================
const BLOOD := Color(0.9, 0.1, 0.16)

## look: cultist / shadow_mage / chain_knight / ronin / uranos / chain_king / arunika. Mengembalikan {"cape": pivot} bila ada.
static func apply_enemy(rig: CharacterRig, look: String) -> Dictionary:
	var out := {}
	match look:
		"cultist":
			out["cape"] = _cape(rig, Color(0.1, 0.05, 0.08), Color(0.35, 0.05, 0.1), 1.35, 0.4, BLOOD)
			_hood(rig, Color(0.1, 0.05, 0.08), BLOOD, false)
			_mask(rig, BLOOD, 0)
			var k := MeshKit.new(80)
			_sword_mesh(k, 0.5, false)
			rig.add_in_right_hand(_mi(k, "RitualBlade"), Vector3.ZERO, Vector3.ZERO)
		"shadow_mage":
			out["cape"] = _cape(rig, Color(0.16, 0.08, 0.3), Color(0.04, 0.02, 0.1), 1.5, 0.4, Color(0.75, 0.4, 1.0))
			_hood(rig, Color(0.16, 0.08, 0.3), Color(0.75, 0.4, 1.0), true)
			_mask(rig, Color(0.75, 0.4, 1.0), 1)
			var k2 := MeshKit.new(81)
			_staff_mesh(k2, 1.6, Color(0.7, 0.3, 1.0))
			rig.add_in_right_hand(_mi(k2, "ShadowStaff"), Vector3.ZERO, Vector3.ZERO)
		"chain_knight":
			_pauldrons(rig, Color(0.42, 0.45, 0.54), BLOOD)
			_tabard(rig, Color(0.35, 0.05, 0.08), Color(0.12, 0.12, 0.16))
			_belt(rig, Color(0.12, 0.12, 0.16), BLOOD, false)
			_chains(rig, 3)
			_knight_helm(rig, false)
			var k3 := MeshKit.new(82)
			_sword_mesh(k3, 1.05, false)
			rig.add_in_right_hand(_mi(k3, "KnightBlade"), Vector3.ZERO, Vector3.ZERO)
		"ronin":
			out["cape"] = _cape(rig, Color(0.2, 0.06, 0.06), Color(0.06, 0.03, 0.03), 1.1, 0.36, BLOOD)
			_kasa(rig)
			_mask(rig, BLOOD, 2)
			_scarf(rig, Color(0.65, 0.08, 0.1))
			_katana(rig, false)
		"uranos":
			out["cape"] = _cape(rig, Color(0.2, 0.1, 0.38), Color(0.05, 0.02, 0.12), 1.9, 0.46, GOLD, true)
			_hood(rig, Color(0.2, 0.1, 0.38), GOLD, true)
			_mask(rig, GOLD, 1)
			_pauldrons(rig, Color(0.2, 0.1, 0.38), GOLD)
			_halo_rings(rig, Color(0.8, 0.5, 1.0))
			var k4 := MeshKit.new(83)
			_staff_mesh(k4, 2.0, Color(0.8, 0.4, 1.0))
			rig.add_in_right_hand(_mi(k4, "UranosStaff"), Vector3.ZERO, Vector3.ZERO)
		"chain_king":
			out["cape"] = _cape(rig, Color(0.45, 0.04, 0.08), Color(0.08, 0.02, 0.04), 1.9, 0.5, GOLD)
			_pauldrons(rig, Color(0.2, 0.2, 0.26), BLOOD)
			_chains(rig, 5)
			_knight_helm(rig, true)
			var k5 := MeshKit.new(84)
			var L := 1.5
			k5.box(Vector3(0, 0.1 + L * 0.5, 0), Vector3(0.26, L, 0.035), T, Color(0.14, 0.12, 0.16))
			k5.box(Vector3(0, 0.1 + L * 0.5, 0), Vector3(0.06, L * 0.96, 0.045), T, _glow(BLOOD, 0.9))
			for sx in [-1.0, 1.0]:
				k5.box(Vector3(sx * 0.125, 0.1 + L * 0.5, 0), Vector3(0.025, L, 0.045), T, _glow(BLOOD, 0.7))
			k5.cylinder(Vector3(0, 0.1 + L, 0), 0.13, 0.0, 0.24, 4, T, Color(0.14, 0.12, 0.16), false, -1, false, 1.0)
			k5.box(Vector3(0, 0.1, 0), Vector3(0.56, 0.08, 0.09), T, Color(0.14, 0.12, 0.16))
			k5.box(Vector3(0, -0.08, 0), Vector3(0.05, 0.3, 0.05), T, Color(0.8, 0.8, 0.85))
			var mi := _mi(k5, "ChainGreatsword")
			rig.add_in_right_hand(mi, Vector3.ZERO, Vector3.ZERO)
			CharFx.attach_blade_trail(mi, rig, Color(1.0, 0.6, 0.6), Color(0.8, 0.05, 0.1))
		"arunika":
			var leaf := Color(0.45, 1.0, 0.55)
			out["cape"] = _cape(rig, Color(0.22, 0.52, 0.32), Color(0.07, 0.24, 0.15), 1.75, 0.46, leaf)
			_antlers(rig, Color(0.66, 0.54, 0.38), leaf)
			_leaf_crown(rig, leaf)
			var ka := MeshKit.new(87)
			_staff_mesh(ka, 1.9, leaf)
			rig.add_in_right_hand(_mi(ka, "RootStaff"), Vector3.ZERO, Vector3.ZERO)
	return out


## Tanduk rusa bercabang di kepala (Arunika): dua batang melengkung ke atas, masing-masing dengan tiga cabang; ujungnya berpendar.
static func _antlers(rig: CharacterRig, col: Color, glow: Color) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(88)
	for sx in [-1.0, 1.0]:
		k.push()
		k.move(sx * 0.22, 0.68, -0.02)
		k.xf = k.xf.rotated_local(Vector3(0, 0, 1), deg_to_rad(-sx * 18.0))
		k.box(Vector3(0, 0.32, 0), Vector3(0.09, 0.64, 0.09), T, col)
		for bi in 3:
			var by := 0.2 + float(bi) * 0.17
			k.push()
			k.move(0, by, 0)
			k.xf = k.xf.rotated_local(Vector3(0, 0, 1), deg_to_rad(-sx * (42.0 - bi * 6.0)))
			var bl := 0.34 - bi * 0.05
			k.box(Vector3(0, bl * 0.5, 0), Vector3(0.06, bl, 0.06), T, col)
			k.blob(Vector3(0, bl + 0.02, 0), 0.045, T, _glow(glow, 0.95), 3, 5)
			k.pop()
		k.blob(Vector3(0, 0.66, 0), 0.055, T, _glow(glow, 0.95), 3, 5)
		k.pop()
	att.add_child(_mi(k, "Antlers"))


## Mahkota daun di dahi (Arunika).
static func _leaf_crown(rig: CharacterRig, glow: Color) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(89)
	for i in 9:
		var a := float(i) / 9.0 * TAU
		var p := Vector3(cos(a) * 0.43, 0.6, sin(a) * 0.43)
		k.push()
		k.move(p.x, p.y, p.z)
		k.yaw(rad_to_deg(atan2(p.x, p.z)))
		k.box(Vector3(0, 0.05, 0), Vector3(0.14, 0.12, 0.05), T, Color(0.3, 0.7, 0.38) if i % 2 == 0 else Color(0.4, 0.8, 0.46))
		k.pop()
	k.blob(Vector3(0, 0.62, 0.44), 0.06, T, _glow(glow, 0.95), 3, 5)
	att.add_child(_mi(k, "LeafCrown"))


## Kerudung gelap: atas, belakang, dan sisi kepala (wajah terbuka untuk topeng). tall = ujung runcing menjuntai.
static func _hood(rig: CharacterRig, col: Color, trim: Color, tall: bool) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(85)
	var dark := col.darkened(0.35)
	k.box(Vector3(0, 0.66, -0.02), Vector3(0.8, 0.18, 0.8), T, col)
	k.box(Vector3(0, 0.34, -0.4), Vector3(0.8, 0.78, 0.1), T, dark)
	for sx in [-1.0, 1.0]:
		k.box(Vector3(sx * 0.4, 0.34, 0.0), Vector3(0.1, 0.78, 0.8), T, col)
		k.box(Vector3(sx * 0.4, 0.34, 0.38), Vector3(0.12, 0.8, 0.05), T, trim)             # tepi muka kerudung
	k.box(Vector3(0, 0.76, 0.38), Vector3(0.8, 0.05, 0.05), T, trim)
	k.sway = 0.5
	k.box(Vector3(0, 0.0, -0.44), Vector3(0.7, 0.42, 0.06), T, dark)                      # jatuh ke punggung
	k.sway = 0.0
	if tall:
		k.cylinder(Vector3(0, 0.74, -0.02), 0.4, 0.0, 0.62, 5, T, col, false, -1, false, 0.95)
		k.blob(Vector3(0, 1.38, -0.02), 0.06, T, trim, 3, 5)
	att.add_child(_mi(k, "Hood"))


## Topeng putih tanpa wajah + mata menyala. style 0 = garis merah (pengikut), 1 = tanda di dahi, 2 = separuh bawah (ronin).
static func _mask(rig: CharacterRig, glow: Color, style: int) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(86)
	var white := Color(0.95, 0.95, 0.98)
	var h0 := 0.56 if style != 2 else 0.34
	var cy := 0.32 if style != 2 else 0.2
	k.box(Vector3(0, cy, 0.37), Vector3(0.56, h0, 0.04), T, white)
	k.box(Vector3(0, cy - h0 * 0.5 - 0.03, 0.36), Vector3(0.34, 0.08, 0.04), T, white)       # dagu
	var g := _glow(glow, 1.0)
	if style != 2:
		for sx in [-1.0, 1.0]:
			k.box(Vector3(sx * 0.13, 0.38, 0.4), Vector3(0.14, 0.04, 0.02), T, g)            # celah mata menyala
			k.box(Vector3(sx * 0.13, 0.36, 0.395), Vector3(0.05, 0.03, 0.02), T, Color(1, 1, 1))
	else:
		k.box(Vector3(0, 0.38, 0.4), Vector3(0.5, 0.03, 0.02), T, g)
	match style:
		0:
			k.box(Vector3(0, 0.2, 0.4), Vector3(0.03, 0.22, 0.02), T, glow)                   # garis tengah merah
			k.box(Vector3(0, 0.1, 0.4), Vector3(0.24, 0.03, 0.02), T, glow)
		1:
			k.blob(Vector3(0, 0.55, 0.4), 0.045, MeshKit.T_CRYSTAL, g, 3, 5)
			k.box(Vector3(0, 0.22, 0.4), Vector3(0.1, 0.02, 0.02), T, glow)
		2:
			k.box(Vector3(0, 0.24, 0.4), Vector3(0.02, 0.2, 0.02), T, glow)
	att.add_child(_mi(k, "Mask"))


## Helm ksatria rantai: tertutup, celah mata merah; raja bermahkota duri.
static func _knight_helm(rig: CharacterRig, king: bool) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(87)
	var steel := Color(0.34, 0.36, 0.44) if not king else Color(0.16, 0.16, 0.2)
	k.box(Vector3(0, 0.34, 0), Vector3(0.78, 0.8, 0.78), T, steel)
	k.box(Vector3(0, 0.7, 0), Vector3(0.82, 0.08, 0.82), T, steel.lightened(0.15))
	k.box(Vector3(0, 0.4, 0.4), Vector3(0.7, 0.07, 0.03), T, _glow(BLOOD, 1.0))                # celah mata
	k.box(Vector3(0, 0.22, 0.4), Vector3(0.05, 0.3, 0.03), T, steel.darkened(0.3))
	for sx in [-0.2, 0.2]:
		k.box(Vector3(sx, 0.18, 0.4), Vector3(0.14, 0.02, 0.03), T, steel.darkened(0.4))
	if king:
		for i in 7:
			var a := i * TAU / 7.0
			k.cylinder(Vector3(cos(a) * 0.36, 0.72, sin(a) * 0.36), 0.07, 0.0, 0.34 + (i % 2) * 0.16, 4, T, GOLD, false, -1, false, 1.0)
		for sx in [-1.0, 1.0]:
			k.cylinder(Vector3(sx * 0.42, 0.55, 0.0), 0.09, 0.0, 0.5, 5, T, Color(0.9, 0.88, 0.8), false, -1, false, 1.0)   # tanduk
	else:
		k.sway = 0.8
		k.box(Vector3(0, 0.95, -0.1), Vector3(0.1, 0.34, 0.4), T, Color(0.7, 0.06, 0.1))
		k.sway = 0.0
	att.add_child(_mi(k, "KnightHelm"))


## Rantai melintang dada (n = jumlah lilitan) + rantai menjuntai dari pinggang.
static func _chains(rig: CharacterRig, n: int) -> void:
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(88)
	var iron := Color(0.5, 0.52, 0.6)
	for c in n:
		var y0 := 0.5 - c * 0.14
		var sgn := 1.0 if c % 2 == 0 else -1.0
		for i in 12:
			var t := float(i) / 11.0
			var p := Vector3(lerpf(-0.36, 0.36, t) * sgn, lerpf(y0, y0 - 0.55, t), 0.25)
			var big := i % 2 == 0
			k.box(p, Vector3(0.1, 0.06, 0.05) if big else Vector3(0.05, 0.08, 0.05), T, iron if big else iron.darkened(0.25))
	att.add_child(_mi(k, "Chains"))
	var hip := rig.attach_bone("hips")
	var hk := MeshKit.new(89)
	hk.sway = 1.0
	for side in [-1.0, 1.0]:
		for i in 7:
			hk.box(Vector3(side * 0.36, 0.0 - i * 0.1, 0.1), Vector3(0.07, 0.06, 0.05) if i % 2 == 0 else Vector3(0.04, 0.08, 0.05), T, iron)
		hk.box(Vector3(side * 0.36, -0.75, 0.1), Vector3(0.12, 0.12, 0.08), T, Color(0.7, 0.06, 0.1))
	hk.sway = 0.0
	hip.add_child(_mi(hk, "HipChains"))


## Topi jerami lebar (kasa) kehitaman.
static func _kasa(rig: CharacterRig) -> void:
	var att := rig.attach_bone("head")
	var k := MeshKit.new(90)
	k.cylinder(Vector3(0, 0.56, 0), 0.95, 0.12, 0.42, 10, T, Color(0.22, 0.17, 0.13), true, T, false, 0.95)
	k.cylinder(Vector3(0, 0.56, 0), 0.96, 0.96, 0.03, 10, T, Color(0.55, 0.08, 0.1), false, -1, false, 1.0)
	att.add_child(_mi(k, "Kasa"))


## Cincin sihir melayang di belakang kepala (Uranos).
static func _halo_rings(rig: CharacterRig, col: Color) -> void:
	var att := rig.attach_bone("chest")
	var k := MeshKit.new(91)
	k.torus_xy(Vector3(0, 1.0, -0.5), 0.55, 0.025, 20, 4, MeshKit.T_CRYSTAL, _glow(col, 0.9))
	k.torus_xy(Vector3(0, 1.0, -0.5), 0.4, 0.018, 18, 4, MeshKit.T_CRYSTAL, _glow(Color(1, 0.85, 0.4), 0.9))
	for i in 8:
		var a := i * TAU / 8.0
		k.box(Vector3(cos(a) * 0.48, 1.0 + sin(a) * 0.48, -0.5), Vector3(0.04, 0.04, 0.04), T, _glow(Color(1, 0.9, 0.5), 1.0))
	att.add_child(_mi(k, "HaloRings"))
