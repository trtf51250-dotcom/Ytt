class_name NpcDefs
extends RefCounted
## Data NPC + dialog. Dialog = Dictionary simpul:
##   { "start": {"lines": ["...", "..."], "choices": [ {"text": "...", "action": "shop:weapon"}, {"text": "...", "goto": "simpul_lain"} ]}, "simpul_lain": {...} }
## Aksi yang dikenali Lobby: close, quests, adventure, party, gacha, smith, shop:weapon, shop:item, shop:sell, character, equipment.
## Menambah NPC baru = tambah satu entri di DEFS (+ tempat di LobbyLayout.NPC_SPOTS) dan satu cabang di dialogue().

const DEFS := {
	"guild_master": {"name": "Orwen", "title": "Master Serikat Bintang Fajar", "skin": "skin_orwen", "look": "guild_master", "height": 1.86, "idle": "idle_cross"},
	"merchant": {"name": "Rowan", "title": "Pedagang Senjata", "skin": "skin_rowan", "look": "merchant", "height": 1.72, "idle": "idle_gesture"},
	"potion_seller": {"name": "Mira", "title": "Peracik Ramuan", "skin": "skin_mira", "look": "potion_seller", "height": 1.62, "idle": "idle_stir"},
	"blacksmith": {"name": "Tobias", "title": "Pandai Besi", "skin": "skin_tobias", "look": "blacksmith", "height": 1.9, "idle": "idle_hammer"},
	"info": {"name": "Selin", "title": "Pemandu Kota", "skin": "skin_selin", "look": "info", "height": 1.66, "idle": "idle_gesture"},
	"party_leader": {"name": "Kael", "title": "Pemimpin Regu", "skin": "skin_kael", "look": "party_leader", "height": 1.8, "idle": "idle_wave"},
	"gate_guard": {"name": "Elio", "title": "Penjaga Gerbang", "skin": "skin_elio", "look": "gate_guard", "height": 1.95, "idle": "idle_attention"},
	"priestess": {"name": "Pip", "title": "Penjaga Altar Bintang", "skin": "skin_pip", "look": "priestess", "height": 1.55, "idle": "idle_n"},
}

## Penduduk yang berjalan-jalan; bisa diajak bicara (nama, gelar, dan "say" = kalimat khas masing-masing; sisanya dari VILLAGER_RUMORS dan petunjuk sesuai kemajuan pemain).
const VILLAGER_PRIORITY := [0, 4, 2, 6, 1, 5, 3, 7, 8, 9, 10, 11]   # urutan dibuat saat anggaran warga terbatas (campur alun-alun dan jalan)
const VILLAGERS := [
	{"skin": "skin_town1", "height": 1.7, "ring": 13.5, "dir": 1, "phase": 0.0, "speed": 1.35, "name": "Bu Lestari", "title": "Penjual Roti", "say": ["Roti hangat, baru dari tungku! Sayang tokoku tak muat di alun-alun, jadi aku keliling saja.", "Kalau perutmu kosong, pedangmu pun jadi lamban. Ingat itu."]},
	{"skin": "skin_town2", "height": 1.62, "ring": 16.0, "dir": -1, "phase": 2.0, "speed": 1.2, "name": "Pak Darma", "title": "Tukang Kebun Kota", "say": ["Pohon-pohon di taman ini kutanam sendiri. Sakura itu yang paling manja.", "Kalau kau lihat kelopak berguguran, itu tandanya musim sedang baik."]},
	{"skin": "skin_town1", "height": 1.55, "ring": 14.8, "dir": 1, "phase": 4.1, "speed": 1.5, "name": "Nia", "title": "Pelukis Jalanan", "say": ["Aku melukis air mancur setiap pagi. Tak pernah sama, cahayanya selalu berubah.", "Kota ini indah kalau dilihat dari atas bukit. Sayang tembok menghalangi."]},
	{"skin": "skin_town2", "height": 1.78, "ring": 17.0, "dir": -1, "phase": 5.3, "speed": 1.25, "name": "Mbah Surya", "title": "Sesepuh Kota", "say": ["Dulu Aurelia hanya sebuah pondok di lereng bukit. Sekarang lihat, sudah punya tembok dan gerbang.", "Anak muda zaman sekarang kuat-kuat. Dulu kami cuma bawa tongkat."]},
	# penjaga jalan: bolak-balik menyusuri jalan kota (sisi jalan, jadi tidak bertabrakan), sesekali berhenti
	{"skin": "skin_town1", "height": 1.68, "route": [Vector2(3, 100), Vector2(3, 34)], "speed": 1.3, "name": "Dimas", "title": "Kurir Surat", "say": ["Aku mengantar surat dari gerbang selatan sampai ke guild. Kakiku sudah hafal tiap batu jalan.", "Cepat atau lambat, semua kabar lewat jalan ini."]},
	{"skin": "skin_town2", "height": 1.6, "route": [Vector2(-3, 36), Vector2(-3, 98)], "speed": 1.15, "name": "Wulan", "title": "Penyiram Bunga", "say": ["Bunga-bunga di pinggir jalan butuh air tiap hari. Jangan injak yang kecil-kecil, ya.", "Kupu-kupu suka sekali taman kota kita."]},
	{"skin": "skin_town2", "height": 1.72, "route": [Vector2(-32, 3), Vector2(-66, 3)], "speed": 1.2, "name": "Hadi", "title": "Pemanggul Barang", "say": ["Peti, karung, tong, semua aku pikul. Bahuku lebih kuat dari baja Tobias, katanya sendiri iri.", "Kalau ada barang berat, bilang saja. Upahnya murah."]},
	{"skin": "skin_town1", "height": 1.58, "route": [Vector2(34, -3), Vector2(66, -3)], "speed": 1.4, "name": "Rani", "title": "Pembawa Kabar", "say": ["Aku selalu tahu kabar terbaru sebelum orang lain. Itu pekerjaanku.", "Kalau kau dengar sesuatu yang menarik, ceritakan padaku ya."]},
	{"skin": "skin_town1", "height": 1.65, "route": [Vector2(-58.5, -60), Vector2(-58.5, 80)], "speed": 1.25, "name": "Joko", "title": "Peronda Kota", "say": ["Aku keliling sepanjang jalan samping tiap hari, memastikan semua aman.", "Sejak ada serikat, kota jadi tenang. Tapi tetap, mata harus terbuka."]},
	{"skin": "skin_town2", "height": 1.75, "route": [Vector2(61.5, 80), Vector2(61.5, -60)], "speed": 1.3, "name": "Sari", "title": "Penenun Kain", "say": ["Kain tenunanku dipakai separuh warga kota. Jubah petualang pun kadang pesan padaku.", "Warna biru fajar itu paling sulit dibuat."]},
	{"skin": "skin_town1", "height": 1.6, "route": [Vector2(4, -30), Vector2(4, -46)], "speed": 1.1, "name": "Bagas", "title": "Murid Serikat", "say": ["Aku baru tiga bulan di serikat. Orwen galak, tapi adil.", "Suatu hari aku akan jadi petualang hebat, seperti kamu."]},
	{"skin": "skin_town2", "height": 1.55, "route": [Vector2(-12, 58), Vector2(-36, 58)], "speed": 1.2, "name": "Ayu", "title": "Pengumpul Herbal", "say": ["Daun dan embun yang kuambil dari taman dibeli Mira untuk ramuannya.", "Jangan petik tanaman sembarangan, ada yang beracun."]},
]


## Penghuni rumah: satu per rumah, berjaga/mondar-mandir di depan pintu rumahnya (nama, gelar, kalimat khas).
const RESIDENTS := [
	["Bu Marni", "Penghuni Rumah", "Rumah ini warisan nenekku. Atapnya sering bocor, tapi hatiku selalu hangat."],
	["Pak Ujang", "Penghuni Rumah", "Tiap pagi aku menyapu halaman. Tamu yang datang harus disambut halaman bersih."],
	["Lilis", "Penghuni Rumah", "Suamiku petualang. Katanya tiap pulang dia selalu rindu masakanku."],
	["Pak Bima", "Penghuni Rumah", "Rumahku kecil tapi pintunya selalu terbuka untuk petualang yang kelelahan."],
	["Tika", "Penghuni Rumah", "Aku suka duduk di depan rumah, menonton orang lalu-lalang di jalan."],
	["Mang Eman", "Penghuni Rumah", "Dulu aku petualang juga. Sekarang lututku yang jadi lawan terberat."],
	["Rina", "Penghuni Rumah", "Kata ibuku, rumah yang baik itu yang ada kucingnya. Sayang kucingku suka kabur."],
	["Pak Slamet", "Penghuni Rumah", "Tembok rumah ini kubangun sendiri. Kokoh, tak ada yang bisa menembusnya."],
	["Yuni", "Penghuni Rumah", "Aku menjemur kain di sini tiap hari. Matahari kota ini memang murah hati."],
	["Pak Anto", "Penghuni Rumah", "Malam hari lampu kota menyala, rumahku jadi tampak seperti di dalam lukisan."],
	["Fitri", "Penghuni Rumah", "Tetangga sebelah suka berisik, tapi kalau mereka pergi malah sepi."],
	["Mas Rudi", "Penghuni Rumah", "Aku baru pindah kemari. Kotanya ramah, warganya baik semua."],
	["Bu Hesti", "Penghuni Rumah", "Kalau kau lapar, mampir saja. Ada sup hangat di dapur."],
	["Pak Gilang", "Penghuni Rumah", "Rumah ini menghadap jalan, jadi aku selalu tahu siapa yang lewat."],
	["Dewi", "Penghuni Rumah", "Taman di depan rumahku kurawat sendiri. Jangan diinjak ya, petualang."],
]

## Warga Desa Fajar (peta desa). "still" = berdiri di tempat (yaw = arah hadap, rad); "actions" = pilihan dialog fungsional tambahan.
## Urutan = prioritas dibuat saat anggaran NPC terbatas (fungsional dulu, lalu pengembara, lalu penghuni rumah).
const VILLAGE_NPCS := [
	{"skin": "skin_orwen", "height": 1.8, "still": true, "yaw": 0.0, "route": [Vector2(30, -5)], "name": "Pak Wiryo", "title": "Kepala Desa",
		"say": ["Selamat datang di Desa Fajar! Kami desa kecil di luar tembok Aurelia, tapi warganya ramah semua.", "Balai Desa di sebelah selalu terbuka. Papan quest-nya sama dengan milik serikat."],
		"actions": [{"text": "Lihat daftar Quest", "action": "quests"}, {"text": "Mulai Petualangan", "action": "adventure"}]},
	{"skin": "skin_rowan", "height": 1.66, "still": true, "yaw": 0.0, "route": [Vector2(-26, -5)], "name": "Bu Sekar", "title": "Pemilik Warung Desa",
		"say": ["Warungku menjual ramuan dan bekal buatan desa. Murah, segar, dan tanpa embel-embel.", "Hasil ladang kami selalu yang terbaik di perbatasan."],
		"actions": [{"text": "Beli ramuan", "action": "shop:item"}, {"text": "Jual barang", "action": "shop:sell"}]},
	{"skin": "skin_tobias", "height": 1.84, "still": true, "yaw": 3.14, "route": [Vector2(-26, 6.5)], "name": "Tarno", "title": "Pandai Besi Desa",
		"say": ["Bengkel kecilku menempa cangkul dan pedang. Sini, kutempa senjatamu sampai +10.", "Palu ini turun dari kakekku. Tak pernah mengkhianati."],
		"actions": [{"text": "Tempa senjata", "action": "smith"}]},
	{"skin": "skin_elio", "height": 1.9, "still": true, "yaw": 0.0, "route": [Vector2(-5.5, -71)], "name": "Pandu", "title": "Penjaga Gerbang Utara",
		"say": ["Gerbang ini mengarah ke kota Aurelia. Jalan lurus saja ke utara.", "Malam hari lampu di sini menyala. Desa kami tak pernah gelap."],
		"actions": [{"text": "Kembali ke Kota Aurelia", "action": "go_town"}, {"text": "Mulai Petualangan", "action": "adventure"}]},
	{"skin": "skin_town2", "height": 1.7, "route": [Vector2(5, 2), Vector2(5, 10)], "speed": 0.8, "name": "Mbah Kerto", "title": "Sesepuh Desa",
		"say": ["Sumur ini lebih tua dariku. Airnya tak pernah kering, bahkan di kemarau terpanjang.", "Dulu desa ini cuma tiga pondok. Sekarang lihat, ada kincir angin!"]},
	{"skin": "skin_town1", "height": 1.62, "route": [Vector2(34, 62), Vector2(48, 62)], "speed": 1.1, "name": "Soleh", "title": "Petani Jagung",
		"say": ["Panen tahun ini bagus. Burung-burung saja yang masih iseng.", "Orang-orangan sawah itu kubuat sendiri. Lumayan galak, kan?"]},
	{"skin": "skin_town2", "height": 1.56, "route": [Vector2(34, 80), Vector2(48, 80)], "speed": 1.1, "name": "Minah", "title": "Petani Sayur",
		"say": ["Wortel dan sawi dari ladangku dijual di warung Bu Sekar.", "Pagi hari adalah waktu terbaik menyiram. Embunnya masih ikut membantu."]},
	{"skin": "skin_town1", "height": 1.66, "route": [Vector2(-34, 64), Vector2(-34, 80)], "speed": 1.0, "name": "Karyo", "title": "Pemancing Kolam",
		"say": ["Ikan di kolam ini sulit ditangkap. Mereka pintar, katanya.", "Sabar itu umpan terbaik. Duduk saja dulu di sini."]},
	{"skin": "skin_town2", "height": 1.74, "route": [Vector2(55, -24), Vector2(66, -26)], "speed": 1.0, "name": "Gito", "title": "Penjaga Kincir",
		"say": ["Kincir ini menggiling gandum untuk seluruh desa. Angin dari utara paling bagus.", "Kalau baling-balingnya berhenti, berarti ada yang salah. Atau anginnya libur."]},
	{"skin": "skin_town1", "height": 1.15, "route": [Vector2(-6, 8), Vector2(8, -8)], "speed": 1.9, "name": "Cahyo", "title": "Anak Desa",
		"say": ["Kejar aku kalau bisa! ...Eh, kamu petualang, ya? Keren!", "Aku mau jadi petualang kalau sudah besar. Pedangku dari kayu, tapi tajam."]},
	{"skin": "skin_town2", "height": 1.58, "route": [Vector2(-5.5, -22), Vector2(-5.5, -50)], "speed": 1.2, "name": "Mbok Inem", "title": "Penjual Sayur Keliling",
		"say": ["Sayur segar, sayur segar! Dipetik subuh tadi.", "Kalau mau yang paling manis, tanya Minah di ladang selatan."]},
	{"skin": "skin_town1", "height": 1.7, "route": [Vector2(5.5, 58), Vector2(5.5, 90)], "speed": 1.3, "name": "Jaka", "title": "Pemburu Hutan",
		"say": ["Hutan di selatan ramai monster. Aku cuma berburu rusa, sisanya urusan petualang.", "Jejak di tanah bisa bercerita banyak. Belajarlah membacanya."]},
]

## Penghuni rumah Desa Fajar: satu per rumah (rumah terdekat alun-alun lebih dulu): nama, gelar, kalimat khas.
const VILLAGE_RESIDENTS := [
	["Bu Lastri", "Penghuni Rumah", "Rumah kami kecil tapi dapurnya selalu mengepul. Mampir kalau lapar."],
	["Pak Sugeng", "Penghuni Rumah", "Aku menanam jagung sejak muda. Tanah desa ini murah hati."],
	["Wati", "Penghuni Rumah", "Aku menenun di beranda tiap sore. Anginnya enak."],
	["Pak Karta", "Penghuni Rumah", "Tetangga di sini seperti keluarga. Kalau ada yang sakit, semua datang membantu."],
	["Sinta", "Penghuni Rumah", "Ayahku penjaga kincir. Aku sering diajak naik, pemandangannya indah sekali."],
	["Mang Dadang", "Penghuni Rumah", "Aku tukang kayu. Separuh pagar di desa ini buatanku."],
	["Ibu Ningsih", "Penghuni Rumah", "Kucingku suka tidur di atas atap. Jangan kaget kalau ada yang mengeong."],
	["Pak Rahmat", "Penghuni Rumah", "Dulu aku petualang, sekarang pensiun. Lutut ini sudah menyerah."],
	["Yanti", "Penghuni Rumah", "Kalau malam, bintang di desa kami jauh lebih banyak daripada di kota."],
	["Pak Joyo", "Penghuni Rumah", "Pintu rumahku tak pernah dikunci. Desa ini aman."],
	["Lina", "Penghuni Rumah", "Aku baru menikah dan pindah ke desa ini. Orang-orangnya baik sekali."],
	["Mas Bayu", "Penghuni Rumah", "Besok aku mau ke kota menjual hasil panen. Doakan laku, ya."],
]

## Kabar khas Desa Fajar (ditambahkan ke obrolan warga desa).
const VILLAGE_RUMORS := [
	"Gerbang selatan desa menuju padang petualangan. Hati-hati, monster di sana lebih galak dari anjing kampung.",
	"Pandai besi Tarno di bengkel desa bisa menempa senjata, sama seperti Tobias di kota.",
	"Kincir angin kami berputar sejak zaman kakek buyut. Katanya, kalau berhenti, hujan akan turun.",
	"Warung Bu Sekar menjual ramuan murah. Bawa cukup sebelum menantang bos.",
	"Balai Desa punya papan quest sendiri. Pak Wiryo jarang ada di dalam, lebih suka berdiri di depan.",
	"Anak-anak suka bermain di sekitar sumur. Hati-hati melangkah, jangan sampai menabrak mereka.",
]

## Kabar/obrolan umum antarwarga (semuanya sesuai isi game).
const VILLAGER_RUMORS := [
	"Tobias si pandai besi bisa menempa senjatamu sampai +10. Biayanya naik tiap tingkat, tapi tambahan ATK-nya terasa.",
	"Kata Pip, Altar Bintang pasti memberi bintang lima setiap lima puluh panggilan tanpa hasil. Jujur sekali altarnya.",
	"Di wilayah di luar gerbang, kalahkan dua belas monster dan daerah itu ditaklukkan. Ada peti dan area rahasia juga di sana.",
	"Orwen selalu menaruh quest baru di papan serikat. Jangan lupa klaim hadiahnya.",
	"Dalam satu regu ada empat orang. Ketuk portret rekanmu untuk bertukar karakter di tengah pertempuran. Kael yang mengajariku.",
	"Mira meracik ramuan dari embun fajar. Rasanya aneh, tapi bawa beberapa sebelum menghadapi bos.",
	"Elio menjaga gerbang selatan sejak sebelum aku lahir. Katanya belum ada monster yang berhasil lewat.",
	"Air mancur di alun-alun katanya tak pernah kering sejak kota ini berdiri.",
	"Portal di timur menuju tempat yang jauh. Aku sendiri tak pernah berani melangkah masuk.",
	"Kalau bingung soal kontrol atau cara bermain, tanya Selin si pemandu kota.",
	"Barang yang tak terpakai bisa kau jual ke Rowan atau Mira, lumayan buat modal menempa.",
	"Serikat memberi bonus masuk harian selama tiga hari pertama. Jangan sampai terlewat.",
	"Kalau malam tiba, lampu-lampu kota menyala dan kunang-kunang muncul di sekitar taman. Indah sekali.",
	"Ada peti tersembunyi di luar kota. Yang berkilau perak biasanya isinya lumayan.",
]

static var _talk_n := {}


static func villager_dialogue(key: String, d: Dictionary) -> Dictionary:
	var n: int = int(_talk_n.get(key, 0))
	_talk_n[key] = n + 1
	var say: Array = d.get("say", ["Halo!"])
	if d.get("village", false):
		say = _village_say(str(d["name"]), say)
	var bye := _c("Sampai nanti.", "close")
	var pool: Array = VILLAGER_RUMORS.duplicate()
	if d.get("village", false):
		pool = VILLAGE_RUMORS + VILLAGER_RUMORS.slice(0, 6)
	var seed_off: int = key.hash() % pool.size()
	var r1: String = pool[(seed_off + n * 3) % pool.size()]
	var r2: String = pool[(seed_off + n * 3 + 1) % pool.size()]
	var r3: String = pool[(seed_off + n * 3 + 2) % pool.size()]
	var greet := "Halo, petualang! Aku %s, %s." % [d["name"], str(d["title"]).to_lower()] if n == 0 else "Oh, kamu lagi! Ada perlu apa?"
	if d.get("home", false):
		greet = "Selamat datang! Aku %s, tinggal di rumah ini." % d["name"] if n == 0 else "Mampir lagi? Senang melihatmu."
	var start_choices: Array = []
	for act in d.get("actions", []):
		start_choices.append(_c(str(act["text"]), str(act["action"])))
	start_choices.append_array([_c("Ada kabar apa?", "", "rumor"), _c("Apa yang sebaiknya kulakukan?", "", "hint"), bye])
	return {
		"start": {"lines": [greet, say[n % say.size()]], "choices": start_choices},
		"rumor": {"lines": [r1, r2], "choices": [_c("Ada lagi?", "", "rumor2"), _c("Kembali", "", "start"), bye]},
		"rumor2": {"lines": [r3], "choices": [_c("Kembali", "", "start"), bye]},
		"hint": {"lines": [_hint_line()], "choices": [_c("Kembali", "", "start"), bye]},
	}


## Kalimat warga Desa Fajar menyesuaikan kemajuan Bab Desa (stage v1_*): urutan terbaru yang terpenuhi yang dipakai.
const VILLAGE_STORY := {
	"Pak Wiryo": [["", ["Panen gagal tiga kali berturut-turut. Tolong, lihatlah ladang dulu sebelum kau putuskan apa-apa.", "Kalau ada yang bisa menjelaskan kabut ini, kita akan dengar dengan telinga terbuka."]],
		["v1_2", ["Kabutnya berkurang di jalan setapak? Aku belum berani percaya, tapi terima kasih sudah berani masuk."]],
		["v1_boss", ["Pagi ini ayam berkokok tepat waktu. Sudah lama sekali aku tidak mendengarnya. Kami akan menaruh Sedekah Bumi di tepi hutan, dan tidak akan lupa lagi."]]],
	"Mbah Kerto": [["", ["Daun itu... jangan taruh sembarangan. Itu daun dari hutan tua. Duduklah, akan kuceritakan sesuatu yang orang muda sudah lupa.", "Dulu setiap panen kami membawa separuh karung pertama ke hutan. Orang menyebutnya Sedekah Bumi."]],
		["v1_3", ["Kau melihat pohon tertua itu? Dulu kami menebang satu sisi untuk membuka ladang. Aku sendiri ikut mengangkat kayunya, dan aku masih malu."]],
		["v1_boss", ["Aku akan memimpin Sedekah Bumi tahun ini. Pelan-pelan saja, dengan hati, bukan sekadar upacara."]]],
	"Jaka": [["", ["Rusa-rusa di bukit selatan sekarang diam saja kalau kulihat. Seperti menunggu sesuatu."]],
		["v1_3", ["Kau sudah masuk sampai pohon tua itu? Aku tak sanggup. Tapi aku akan menunjukkan jalan pulang yang aman kalau kau butuh."]],
		["v1_boss", ["Pagi ini seekor rusa mendekatiku tanpa takut. Baru sekali ini seumur hidupku."]]],
	"Cahyo": [["", ["Aku lihat orang tinggi bertanduk di tepi hutan! Tidak ada yang percaya. Kamu percaya, kan?"]],
		["v1_boss", ["Orang bertanduk itu tidak jahat, ya? Aku sudah taruh bunga di tepi hutan. Biar dia tahu kita ingat."]]],
	"Soleh": [["", ["Jagungku layu sebelum berbuah. Ini tahun ketiga. Aku mulai berpikir tanahnya yang marah."]],
		["v1_boss", ["Ada tunas baru di sudut ladangku, padahal belum musim. Aku tidak mau bertanya kenapa, aku syukuri saja."]]],
	"Bu Sekar": [["", ["Warungku sepi. Orang tak punya hasil panen untuk dijual, dan aku tak punya bahan untuk dimasak."]],
		["v1_boss", ["Hasil ladang pelan-pelan kembali. Untuk perayaan nanti, aku sudah menyiapkan resep bubur yang sudah lama tak kubuat."]]],
}


static func _village_say(name: String, fallback: Array) -> Array:
	if not VILLAGE_STORY.has(name):
		return fallback
	var out: Array = fallback
	for ent in VILLAGE_STORY[name]:
		var need: String = ent[0]
		if need == "" or GameState.stage_cleared(need):
			out = ent[1]
	return out


static func _hint_line() -> String:
	if Flow.lobby_map == "village":
		var nv := GameState.adventure_next()
		if nv != "":
			var vs: StageData = Data.stage(nv)
			if vs != null:
				return "Kisah Desa Fajar berikutnya: %s. Keluar lewat gerbang selatan desa atau tekan Start Adventure." % vs.display_name
		return "Kabut Desa Fajar sudah terangkat. Ulangi stage desa kapan pun untuk emas dan EXP."
	if GameState.ready_quest_count() > 0:
		return "Kudengar Orwen menunggumu di guild: ada quest yang sudah selesai dan hadiahnya belum kau ambil."
	var nxt := GameState.adventure_next()
	if nxt != "":
		var sd: StageData = Data.stage(nxt)
		if sd != null:
			if Data.field_ids.has(nxt):
				return "Petualanganmu berikutnya: menjelajahi %s. Kalahkan dua belas monster di sana untuk menaklukkannya. Tekan Start Adventure atau keluar lewat gerbang." % sd.display_name
			return "Petualanganmu berikutnya: %s. Tekan Start Adventure atau keluar lewat gerbang selatan." % sd.display_name
	return "Semua petualangan sudah kau tamatkan! Ulangi stage mana pun lewat Start Adventure untuk mencari emas dan EXP."


static func ids() -> Array:
	return DEFS.keys()


static func display_name(id: String) -> String:
	return str(DEFS.get(id, {}).get("name", id))


static func _c(text: String, action: String = "", goto: String = "") -> Dictionary:
	var d := {"text": text}
	if action != "":
		d["action"] = action
	if goto != "":
		d["goto"] = goto
	return d


static func dialogue(id: String) -> Dictionary:
	var bye := _c("Sampai nanti.", "close")
	match id:
		"guild_master":
			var lines: Array = []
			if GameState.quest_state("q_welcome") != "claimed":
				lines = ["Ah, pendatang baru! Aku Orwen, Master Serikat Bintang Fajar.",
					"Aurelia adalah kota perbatasan. Di luar gerbang selatan, padang rumput dan hutan dipenuhi monster, dan serikat kami menjaga warga dari mereka.",
					"Namamu sudah tercatat di buku anggota. Buka menu Quest untuk mengambil hadiah sambutan, lalu cobalah petualangan pertamamu."]
			elif GameState.ready_quest_count() > 0:
				lines = ["Ada quest yang sudah kau selesaikan. Buka menu Quest dan klaim hadiahnya, itu hakmu."]
			else:
				lines = ["Kerja bagus, petualang. Papan quest di sebelahku selalu terbuka; stage berikutnya menunggu di balik gerbang selatan."]
			return {"start": {"lines": lines, "choices": [
				_c("Lihat daftar Quest", "quests"), _c("Mulai Petualangan", "adventure"), bye]}}
		"merchant":
			return {"start": {"lines": ["Selamat datang di Toko Senjata Aurelia! Besi terbaik, harga jujur, dan tidak ada yang kuberi gratis."],
				"choices": [_c("Beli senjata & armor", "shop:weapon"), _c("Jual barang", "shop:sell"), bye]}}
		"potion_seller":
			return {"start": {"lines": ["Ramuanku diseduh dari embun fajar dan daun yang dipetik sebelum matahari terbit. Rasanya... yah, sembuh itu lebih penting dari rasa."],
				"choices": [_c("Beli ramuan", "shop:item"), _c("Jual barang", "shop:sell"), bye]}}
		"blacksmith":
			return {"start": {"lines": ["Senjata bagus bukan hanya soal baja, tapi sabar dan palu. Bawa senjata yang sedang kau pakai, akan kutempa sampai +10.",
				"Biayanya naik tiap tingkat, tapi setiap tempaan menambah ATK senjatamu."],
				"choices": [_c("Tempa senjata", "smith"), bye]}}
		"info":
			return {
				"start": {"lines": ["Halo! Aku Selin, pemandu kota. Mau tahu apa?"], "choices": [
					_c("Cara bermain", "", "how"), _c("Kontrol", "", "controls"), _c("Tentang Aurelia", "", "lore"), bye]},
				"how": {"lines": ["Tekan Start Adventure atau lewati gerbang selatan: petualangan langsung lanjut ke langkah berikutnya (stage cerita, wilayah jelajah, lalu bos). Bersihkan semua gelombang monster, lalu kembali ke lobi.",
					"Hadiah gold, EXP, dan diamond dipakai di toko, Blacksmith, dan Altar Bintang. Atur party empat orang di menu Party atau lewat Kael."],
					"choices": [_c("Kembali", "", "start"), bye]},
				"controls": {"lines": ["Joystick kiri untuk bergerak. Tombol kanan: Serang, Skill, Hindar, dan Interaksi (menyala bila ada NPC atau objek di dekatmu).",
					"Seret layar di area kosong untuk memutar kamera, cubit dua jari untuk zoom. Di komputer: WASD, J/Spasi serang, K skill, L/Shift hindar, E interaksi, Q/R putar kamera."],
					"choices": [_c("Kembali", "", "start"), bye]},
				"lore": {"lines": ["Aurelia dibangun di lereng bukit tempat cahaya fajar pertama jatuh. Air mancur di alun-alun katanya tak pernah kering sejak hari kota ini didirikan.",
					"Portal di timur membawa para petualang ke tempat yang jauh. Cerita lengkapnya? Itu tugasmu menulisnya."],
					"choices": [_c("Kembali", "", "start"), bye]},
			}
		"party_leader":
			return {"start": {"lines": ["Petualang sejati tak pernah sendirian. Empat orang dalam satu regu, dan kau bisa berganti pemimpin kapan saja.",
				"Di stage nanti, ketuk portret rekanmu untuk bertukar karakter di tengah pertempuran."],
				"choices": [_c("Atur Party", "party"), _c("Lihat Karakter", "character"), _c("Mulai Petualangan", "adventure"), bye]}}
		"gate_guard":
			return {"start": {"lines": ["Berhenti, petualang! ... Oh, kau anggota serikat. Silakan lewat.",
				"Di luar sana padang Fajar, hutan Remang, dan gua-gua tua. Bawa ramuan, dan jangan sok jagoan."],
				"choices": [_c("Keluar gerbang (lanjut Adventure)", "adventure"), _c("Pergi ke Desa Fajar", "go_village"), bye]}}
		"priestess":
			return {"start": {"lines": ["Altar Bintang menjawab mereka yang berani memanggil. Perlengkapan, ramuan, atau pecahan jiwa sahabatmu. Tak ada yang tahu apa yang akan turun.",
				"Peluang ditampilkan jujur di dalam altar, dan setiap lima puluh kali tanpa bintang lima, altar pasti memberi satu."],
				"choices": [_c("Panggil di Altar", "gacha"), bye]}}
	return {"start": {"lines": ["..."], "choices": [bye]}}
