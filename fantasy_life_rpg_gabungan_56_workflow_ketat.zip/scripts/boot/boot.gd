extends Control
## Scene pertama saat aplikasi dibuka. Meneruskan splash bawaan Godot (gambar & warna latar sama persis, jadi tidak ada loncatan),
## lalu menyerahkan ke autoload Flow: layar memuat (bar kemajuan + tips) memuat layar judul di thread dan membukanya saat sudah stabil.
## Dilewati (langsung ke layar judul) untuk mode headless / bila ada argumen uji (--bot, --shots, dst) supaya alat uji tidak tertunda.

const SPLASH := "res://assets/app_icon/splash.png"
const BG := Color(0.051, 0.071, 0.161)             # = boot_splash/bg_color di project.godot (13, 18, 41)


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = BG
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	if ResourceLoader.exists(SPLASH):
		var tex = load(SPLASH)
		if tex is Texture2D:
			var tr := TextureRect.new()
			tr.texture = tex
			tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
			tr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
			tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			add_child(tr)
	if _skip_intro():
		get_tree().change_scene_to_file.call_deferred(Flow.SCENE_TITLE)
		return
	await get_tree().process_frame                    # biarkan satu bingkai tergambar dulu supaya peralihan dari splash mulus
	Flow.goto(Flow.SCENE_TITLE, "Menyiapkan petualangan...")


func _skip_intro() -> bool:
	return DisplayServer.get_name() == "headless" or not OS.get_cmdline_user_args().is_empty()
