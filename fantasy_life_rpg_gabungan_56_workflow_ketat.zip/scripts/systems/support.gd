class_name Support
extends RefCounted
## Dukungan untuk developer: tautan Saweria + fungsi pembuka tautan. Dipakai layar Judul, Menu, Pengaturan, dan panel "support".
## Dukungan sepenuhnya sukarela dan TIDAK memberi keuntungan apa pun di dalam game.

const URL := "https://saweria.co/Yumantara"
const DEV_NAME := "Yumantara"


## Membuka halaman Saweria di browser. Bila gagal (mis. tidak ada browser), tautan disalin ke papan klip.
## Mengembalikan true bila browser berhasil dipanggil.
static func open_page() -> bool:
	var err := OS.shell_open(URL)
	if err != OK:
		DisplayServer.clipboard_set(URL)
		return false
	return true


static func copy_link() -> void:
	DisplayServer.clipboard_set(URL)
