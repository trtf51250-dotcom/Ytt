class_name WorldMats
extends RefCounted
## Pabrik material dunia: atlas tekstur + shader world*.gdshader. Dibagi di seluruh lobi agar draw call sedikit.
## `set_glow()` dipanggil DayNight untuk menaikkan cahaya emisi (lampu, jendela, kristal) saat malam.

const ATLAS_PATH := "res://assets/textures/world_atlas.png"
const TILE_PX := 64                  # ukuran satu petak pada world_atlas.png (8 x 4 petak, lihat tools/gen_textures.py)
const TILE_COLS := 8
const TILE_ROWS := 4

static var _atlas: TextureLayered
static var _opaque: ShaderMaterial
static var _cutout: ShaderMaterial
static var _fades: Array = []
static var _glow := 0.4
static var _wind := 1.0


## Atlas dipecah jadi Texture2DArray (satu lapisan per petak, nomor lapisan = nomor petak). Tiap lapisan punya mipmap sendiri:
## permukaan jauh tidak berkedip/berbintik, tidak ada kebocoran warna antar petak, dan pengulangan petak tersambung mulus.
## Dibuat sekali saat pertama dipakai (32 petak x 64 px, hitungan milidetik).
static func atlas() -> TextureLayered:
	if _atlas == null:
		_atlas = _build_array()
	return _atlas


static func _build_array() -> TextureLayered:
	var src := load(ATLAS_PATH) as Texture2D
	var img: Image = src.get_image() if src != null else null
	if img == null:
		# Atlas belum terimpor (mis. proyek baru dibuka dan langsung dijalankan sebelum impor selesai, atau cache .godot hilang):
		# baca PNG-nya langsung (editor/PC). Bila tetap gagal, pakai petak abu-abu agar game tidak crash.
		push_warning("WorldMats: atlas belum terimpor, memuat PNG langsung. Tunggu impor selesai lalu jalankan ulang.")
		img = Image.load_from_file(ATLAS_PATH)
	if img == null:
		img = Image.create(TILE_PX * TILE_COLS, TILE_PX * TILE_ROWS, false, Image.FORMAT_RGBA8)
		img.fill(Color(0.6, 0.62, 0.6, 1.0))
	if img.is_compressed():
		img.decompress()
	img.convert(Image.FORMAT_RGBA8)
	var layers: Array[Image] = []
	for r in TILE_ROWS:
		for c in TILE_COLS:
			var t := img.get_region(Rect2i(c * TILE_PX, r * TILE_PX, TILE_PX, TILE_PX))
			t.generate_mipmaps()
			layers.append(t)
	var arr := Texture2DArray.new()
	var err := arr.create_from_images(layers)
	if err != OK:
		push_error("WorldMats: gagal membuat array tekstur dunia (kode %d)" % err)
	return arr


static func _make(shader_path: String) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = load(shader_path)
	m.set_shader_parameter("atlas", atlas())
	m.set_shader_parameter("glow", _glow)
	m.set_shader_parameter("wind", _wind)
	return m


static func opaque() -> ShaderMaterial:
	if _opaque == null:
		_opaque = _make("res://shaders/world.gdshader")
	return _opaque


static func cutout() -> ShaderMaterial:
	if _cutout == null:
		_cutout = _make("res://shaders/world_cutout.gdshader")
	return _cutout


## Material yang bisa memudar (dither) - satu per bangunan, dipakai saat bangunan menutupi pemain.
static func fade_material() -> ShaderMaterial:
	var m := _make("res://shaders/world_fade.gdshader")
	_fades.append(m)
	return m


static func set_glow(v: float) -> void:
	_glow = v
	for m in [_opaque, _cutout]:
		if m != null:
			m.set_shader_parameter("glow", v)
	for m in _fades:
		(m as ShaderMaterial).set_shader_parameter("glow", v)


static func set_wind(v: float) -> void:
	_wind = v
	for m in [_opaque, _cutout]:
		if m != null:
			m.set_shader_parameter("wind", v)
	for m in _fades:
		(m as ShaderMaterial).set_shader_parameter("wind", v)


## Dipanggil saat scene lobi dibuang agar tidak menyimpan material lama.
static func reset() -> void:
	_fades.clear()
	_opaque = null
	_cutout = null
