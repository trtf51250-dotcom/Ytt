class_name LiveEvents
extends RefCounted
## Event berjadwal dari data/events.json. Setiap event punya waktu mulai & selesai (jam perangkat pemain); event muncul saat waktunya tiba dan
## hilang sendiri setelah selesai. Event bertipe "banner" membuka banner gacha karakter terbatas yang tidak bisa ditarik lagi setelah event berakhir.
## Event bertipe "rate_up" menaikkan sementara peluang per tarikan satu karakter ekstra (Gacha.EXTRA_CHARS, mis. Ember) di gacha karakter standar;
## setelah event berakhir peluangnya kembali ke angka dasar (bukan hilang).
## Waktu "sekarang" = GameState.now_local() (jam perangkat; bisa dipalsukan hanya untuk uji otomatis dengan --now=).

const PATH := "res://data/events.json"

static var _events: Array = []
static var _loaded := false


static func reload() -> void:
	_loaded = false
	_events = []
	_load()


## Format yang diterima: "YYYY-MM-DD", "YYYY-MM-DD HH:MM", "YYYY-MM-DD HH:MM:SS" (boleh dengan "T"). Mengembalikan -1 bila tidak valid.
static func parse_time(s: String, is_end: bool = false) -> float:
	s = s.strip_edges().replace("T", " ")
	var parts := s.split(" ", false)
	if parts.is_empty():
		return -1.0
	var dp := parts[0].split("-")
	if dp.size() != 3:
		return -1.0
	var hh := 23 if is_end else 0
	var mm := 59 if is_end else 0
	var ss := 59 if is_end else 0
	if parts.size() > 1:
		var tp := parts[1].split(":")
		hh = int(tp[0])
		mm = int(tp[1]) if tp.size() > 1 else 0
		ss = int(tp[2]) if tp.size() > 2 else 0
	return Time.get_unix_time_from_datetime_dict({"year": int(dp[0]), "month": int(dp[1]), "day": int(dp[2]), "hour": hh, "minute": mm, "second": ss})


static func _parse_time(s: String, is_end: bool) -> float:
	return parse_time(s, is_end)


static func _load() -> void:
	if _loaded:
		return
	_loaded = true
	_events = []
	if not FileAccess.file_exists(PATH):
		return
	var f := FileAccess.open(PATH, FileAccess.READ)
	if f == null:
		return
	var d = JSON.parse_string(f.get_as_text())
	f.close()
	if not (d is Dictionary):
		push_warning("LiveEvents: events.json tidak valid")
		return
	for e in d.get("events", []):
		if not (e is Dictionary) or not e.has("id") or not e.has("start") or not e.has("end"):
			continue
		var ev := {
			"id": str(e["id"]), "type": str(e.get("type", "banner")), "title": str(e.get("title", e["id"])),
			"description": str(e.get("description", "")), "character": str(e.get("character", "")),
			"featured_share": clampf(float(e.get("featured_share", 0.5)), 0.0, 1.0),
			"rate": clampf(float(e.get("rate", 0.0)), 0.0, 0.8),
			"start": _parse_time(str(e["start"]), false), "end": _parse_time(str(e["end"]), true),
			"start_text": str(e["start"]), "end_text": str(e["end"]),
		}
		if ev["end"] <= ev["start"]:
			push_warning("LiveEvents: event %s berakhir sebelum mulai, dilewati" % ev["id"])
			continue
		if ev["type"] in ["banner", "rate_up"] and not Data.characters.has(ev["character"]):
			push_warning("LiveEvents: karakter '%s' pada event %s tidak ada, dilewati" % [ev["character"], ev["id"]])
			continue
		if ev["type"] == "rate_up" and (float(ev["rate"]) <= 0.0 or not Gacha.EXTRA_CHARS.has(ev["character"])):
			push_warning("LiveEvents: rate_up %s butuh 'rate' > 0 dan karakter yang terdaftar di Gacha.EXTRA_CHARS, dilewati" % ev["id"])
			continue
		_events.append(ev)
	_events.sort_custom(func(a, b): return a["start"] < b["start"])


static func all() -> Array:
	_load()
	return _events


## "active" | "upcoming" | "ended"
static func status(ev: Dictionary) -> String:
	var t := GameState.now_local()
	if t < float(ev["start"]):
		return "upcoming"
	if t > float(ev["end"]):
		return "ended"
	return "active"


static func active() -> Array:
	return all().filter(func(e): return status(e) == "active")


static func upcoming() -> Array:
	return all().filter(func(e): return status(e) == "upcoming")


static func active_banners() -> Array:
	return active().filter(func(e): return e["type"] == "banner")


static func find(id: String) -> Dictionary:
	for e in all():
		if e["id"] == id:
			return e
	return {}


static func is_active(id: String) -> bool:
	var e := find(id)
	return not e.is_empty() and status(e) == "active"


## Karakter ini adalah karakter event (ada di event mana pun)?
static func is_event_character(cid: String) -> bool:
	for e in all():
		if e["type"] == "banner" and e["character"] == cid:
			return true
	return false


static func remaining_seconds(ev: Dictionary) -> float:
	return maxf(float(ev["end"]) - GameState.now_local(), 0.0)


static func countdown_text(ev: Dictionary) -> String:
	var st := status(ev)
	if st == "upcoming":
		return "Mulai %s" % _fmt_time(float(ev["start"]))
	if st == "ended":
		return "Sudah berakhir"
	var s := int(remaining_seconds(ev))
	var d := s / 86400
	var h := (s % 86400) / 3600
	var m := (s % 3600) / 60
	if d > 0:
		return "Sisa %d hari %d jam" % [d, h]
	if h > 0:
		return "Sisa %d jam %d menit" % [h, m]
	return "Sisa %d menit %d detik" % [m, s % 60]


static func _fmt_time(unix_local: float) -> String:
	var d := Time.get_datetime_dict_from_unix_time(int(unix_local))
	return "%d %s %d %02d:%02d" % [int(d["day"]), Hud.MONTHS_ID[int(d["month"]) - 1], int(d["year"]), int(d["hour"]), int(d["minute"])]


static func range_text(ev: Dictionary) -> String:
	return "%s – %s" % [_fmt_time(float(ev["start"])), _fmt_time(float(ev["end"]))]
