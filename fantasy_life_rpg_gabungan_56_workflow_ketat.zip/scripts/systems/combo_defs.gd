class_name ComboDefs
extends RefCounted
## Kombo serangan biasa TIAP KARAKTER (data, bukan kode): urutan pukulan, bentuk serangan, jeda, dorongan. Dijalankan ComboRunner.
##
## Kunci langkah:
##   n   nama langkah (tampil di panel Karakter)
##   a   nomor animasi serang 1..3 (attack1..3 milik kelas senjatanya)
##   t   tipe: arc (tebasan lebar) · cone (tusukan sempit & panjang) · spin (putaran 360°) · slam (hantaman area) · pull (sedot) · multi (n tebasan beruntun) · wave (gelombang tebasan menembus)
##            shot (1 peluru) · twin (2 peluru sejajar) · fan (n peluru menyebar) · burst (n peluru beruntun) · pierce (peluru besar menembus) · big (peluru besar meledak)
##            rain (jatuh ke musuh terdekat) · nova (ledakan nada di sekeliling) · chain (petir melompat antar-musuh) · echo (peluru + gema menyusul)
##   m   pengali damage PER PUKULAN/PELURU (x attack_mult x ATK)        [1.0]
##   x   jumlah pukulan / peluru / lompatan                              [1]
##   cd  pengali jeda sebelum serangan berikutnya (x attack_cooldown)    [1.0]
##   rec jeda tambahan setelah langkah ini (detik; dipakai di penutup)   [0.0]
##   r   melee: pengali jangkauan [1.0] · nova/rain/big: radius efek dalam meter
##   h   setengah sudut tebasan (derajat; >=180 = 360°)                  [75]
##   k   dorongan musuh                                                  [3.0]
##   lg  dorongan maju badan saat memukul (m/dtk; negatif = mundur)      [bawaan senjata]
##   sp  sudut sebar peluru (derajat)   gap  jeda antar pukulan beruntun (detik)
##   big efek visual penutup (lebih besar) walau bukan langkah terakhir
##   need_dash  true = langkah ini HANYA jalan bila pemain sudah dash (menghindar) sesudah langkah sebelumnya; tanpa dash kombo diulang dari awal (Player.do_attack)
##   bomb  (tipe) lempar bom: ledakan radius r setelah sumbu fuse detik; x = jumlah bom, sp = sebaran (meter)
const TABLE := {
	# ── jarak dekat ─────────────────────────────────────────────
	"ren": [   # pedang es: tebas kanan, tebas kiri, tusukan es menembus
		{"n": "Tebas", "a": 1, "t": "arc", "m": 0.8, "h": 75, "k": 3.0},
		{"n": "Tebas Balik", "a": 2, "t": "arc", "m": 0.8, "h": 75, "k": 3.0},
		{"n": "Tusuk Es", "a": 3, "t": "cone", "m": 1.5, "r": 1.45, "h": 22, "k": 7.0, "lg": 8.0, "cd": 1.1, "rec": 0.25},
	],
	"zeya": [  # belati bayangan: dua tusukan cepat, silang, penutup bayangan ganda
		{"n": "Tusuk", "a": 1, "t": "cone", "m": 0.9, "r": 1.1, "h": 35, "k": 2.0},
		{"n": "Tusuk", "a": 2, "t": "cone", "m": 0.9, "r": 1.1, "h": 35, "k": 2.0},
		{"n": "Silang", "a": 3, "t": "arc", "m": 1.3, "r": 1.15, "h": 110, "k": 4.0},
		{"n": "Bayangan Ganda", "a": 3, "t": "multi", "m": 1.1, "x": 2, "gap": 0.13, "r": 1.2, "h": 130, "k": 6.0, "cd": 1.2, "rec": 0.4, "lg": 8.0},
	],
	"kyomu": [ # belati kehampaan: dua tebasan, tarikan vortex, hantaman hampa
		{"n": "Tebas", "a": 1, "t": "arc", "m": 1.0, "h": 70, "k": 2.0},
		{"n": "Tebas", "a": 2, "t": "arc", "m": 1.0, "h": 70, "k": 2.0},
		{"n": "Tarik Hampa", "a": 3, "t": "pull", "m": 0.9, "r": 1.35, "h": 180, "k": 0.0, "cd": 1.2},
		{"n": "Ledak Hampa", "a": 3, "t": "slam", "m": 2.3, "r": 1.2, "h": 180, "k": 7.0, "cd": 1.3, "rec": 0.4},
	],
	"hakuya": [ # katana api biru: cabut cepat menerjang, tebas balik, gelombang api biru
		{"n": "Cabut", "a": 1, "t": "cone", "m": 0.9, "r": 1.3, "h": 28, "k": 4.0, "lg": 9.0},
		{"n": "Tebas Balik", "a": 2, "t": "arc", "m": 0.8, "h": 85, "k": 3.0},
		{"n": "Gelombang Api Biru", "a": 3, "t": "wave", "m": 1.5, "r": 2.6, "k": 6.0, "cd": 1.2, "rec": 0.3},
	],
	"vael": [  # pedang cahaya: dua tebasan, putaran, tebasan naik
		{"n": "Tebas", "a": 1, "t": "arc", "m": 0.7, "h": 70, "k": 3.0},
		{"n": "Tebas Balik", "a": 2, "t": "arc", "m": 0.7, "h": 70, "k": 3.0},
		{"n": "Putaran", "a": 1, "t": "spin", "m": 1.0, "r": 1.05, "h": 180, "k": 4.0, "cd": 1.1},
		{"n": "Tebas Naik", "a": 3, "t": "arc", "m": 1.7, "r": 1.15, "h": 100, "k": 9.0, "cd": 1.2, "rec": 0.3, "lg": 6.0},
	],
	"kuroha": [ # samurai hitam-putih: cabut, balik, silang dua tebasan
		{"n": "Cabut", "a": 1, "t": "cone", "m": 0.8, "r": 1.25, "h": 30, "k": 3.0, "lg": 6.0},
		{"n": "Balik", "a": 2, "t": "arc", "m": 0.8, "h": 80, "k": 3.0},
		{"n": "Silang", "a": 3, "t": "multi", "m": 0.8, "x": 2, "gap": 0.11, "r": 1.1, "h": 95, "k": 5.0, "cd": 1.2, "rec": 0.2},
	],
	"brann": [ # tank: pukulan, tabrak bahu, hantaman dua tangan
		{"n": "Pukul", "a": 1, "t": "arc", "m": 0.9, "h": 55, "k": 4.0},
		{"n": "Tabrak Bahu", "a": 2, "t": "arc", "m": 1.0, "r": 1.1, "h": 80, "k": 7.0, "lg": 8.5},
		{"n": "Hantam Bumi", "a": 3, "t": "slam", "m": 2.0, "r": 1.25, "h": 180, "k": 8.0, "cd": 1.3, "rec": 0.3},
	],
	# ── jarak jauh ─────────────────────────────────────────────
	"sera": [  # busur: dua panah, tiga panah menyebar
		{"n": "Panah", "a": 1, "t": "shot", "m": 0.85},
		{"n": "Panah Cepat", "a": 2, "t": "shot", "m": 0.85, "cd": 0.9},
		{"n": "Tiga Panah", "a": 3, "t": "fan", "m": 0.8, "x": 3, "sp": 16, "cd": 1.2, "rec": 0.2},
	],
	"lyra": [  # tongkat bintang: bintang, bintang kembar, bintang jatuh
		{"n": "Bintang", "a": 1, "t": "shot", "m": 0.8},
		{"n": "Bintang Kembar", "a": 2, "t": "twin", "m": 0.55},
		{"n": "Bintang Jatuh", "a": 3, "t": "rain", "m": 1.8, "r": 2.3, "k": 5.0, "cd": 1.2, "rec": 0.2},
	],
	"ember": [ # tongkat api: dua bola api, bola api besar meledak
		{"n": "Bola Api", "a": 1, "t": "shot", "m": 0.85},
		{"n": "Bola Api", "a": 2, "t": "shot", "m": 0.85},
		{"n": "Bola Api Meledak", "a": 3, "t": "big", "m": 2.2, "r": 2.5, "k": 6.0, "cd": 1.4, "rec": 0.25},
	],
	"wenyu": [ # musisi: dua nada, ledakan akor di sekeliling
		{"n": "Nada", "a": 1, "t": "shot", "m": 0.9},
		{"n": "Nada Ganda", "a": 2, "t": "shot", "m": 0.9},
		{"n": "Akor", "a": 3, "t": "nova", "m": 1.8, "r": 3.6, "k": 6.0, "cd": 1.2, "rec": 0.2},
	],
	"aion": [  # waktu & tinta: pecahan, pecahan + gema, hujan pecahan jam
		{"n": "Pecahan", "a": 1, "t": "shot", "m": 0.9},
		{"n": "Pecahan Gema", "a": 2, "t": "echo", "m": 0.55, "x": 2, "gap": 0.28, "cd": 1.1},
		{"n": "Pecahan Jam", "a": 3, "t": "fan", "m": 0.6, "x": 4, "sp": 9, "cd": 1.2, "rec": 0.2},
	],
	"lucien": [ # tuan bermonokel: tembak, dua tembakan cepat, peluru emas menembus
		{"n": "Tembak", "a": 1, "t": "shot", "m": 1.0},
		{"n": "Dua Tembak", "a": 2, "t": "burst", "m": 0.5, "x": 2, "gap": 0.11},
		{"n": "Peluru Emas", "a": 3, "t": "pierce", "m": 2.0, "k": 6.0, "cd": 1.4, "rec": 0.25},
	],
	"midori": [ # One For All (KECEPATAN): dua smash secepat kilat, lalu WAJIB dash -> rentetan Detroit Smash. Tanpa dash kombo tidak berjalan
		{"n": "Smash Kilat", "a": 1, "t": "cone", "m": 0.8, "r": 1.15, "h": 38, "k": 2.5, "lg": 6.0, "cd": 0.85},
		{"n": "Smash Kilat", "a": 2, "t": "cone", "m": 0.8, "r": 1.15, "h": 38, "k": 2.5, "lg": 6.0, "cd": 0.85},
		{"n": "Detroit Smash (setelah Dash)", "a": 3, "t": "multi", "m": 0.8, "x": 5, "gap": 0.06, "r": 1.3, "h": 120, "k": 6.0, "lg": 9.0, "cd": 1.2, "rec": 0.15, "big": true, "need_dash": true},
	],
	"zyrax": [ # BOM: dua bom lempar, lalu bom besar Void
		{"n": "Bom Lempar", "a": 1, "t": "bomb", "m": 0.9, "r": 2.1, "fuse": 0.4, "k": 4.0},
		{"n": "Bom Lempar", "a": 2, "t": "bomb", "m": 0.9, "r": 2.1, "fuse": 0.4, "k": 4.0},
		{"n": "Bom Void Besar", "a": 3, "t": "bomb", "m": 0.65, "x": 3, "sp": 2.2, "r": 2.4, "fuse": 0.55, "k": 7.0, "cd": 1.4, "rec": 0.3, "big": true},
	],
	"kiriel": [ # petir: sambaran, sambaran kembar, petir berantai
		{"n": "Sambar", "a": 1, "t": "shot", "m": 0.85},
		{"n": "Sambar Kembar", "a": 2, "t": "twin", "m": 0.5},
		{"n": "Petir Berantai", "a": 3, "t": "chain", "m": 1.6, "x": 3, "r": 1.0, "cd": 1.2, "rec": 0.2},
	],
}

## Kombo wujud Pedang Petir Kiriel (selama ULTI): tiga tebasan petir jarak dekat.
const KIRIEL_BLADE := [
	{"n": "Tebas Petir", "a": 1, "t": "arc", "m": 1.0, "h": 75, "k": 3.0},
	{"n": "Tebas Balik", "a": 2, "t": "arc", "m": 1.0, "h": 75, "k": 3.0},
	{"n": "Sambaran Penutup", "a": 3, "t": "arc", "m": 2.0, "r": 1.15, "h": 120, "k": 7.0, "big": true, "rec": 0.15},
]


## Langkah kombo untuk data karakter ini. Tanpa entri khusus -> pola lama dari combo_hits (kompatibel mundur).
static func steps(cd: CharacterData) -> Array:
	if cd == null:
		return [{"a": 1, "t": "arc"}]
	if cd.id == "kiriel" and cd.attack_kind == "arc":
		return KIRIEL_BLADE
	if TABLE.has(cd.id):
		return TABLE[cd.id]
	var out: Array = []
	var n := maxi(cd.combo_hits, 1)
	for i in n:
		var fin := i == n - 1 and n > 1
		out.append({"n": "Serang", "a": mini(i, 2) + 1, "t": cd.attack_kind if cd.attack_kind in ["bolt", "arrow"] else "arc",
				"m": cd.finisher_mult if fin else 1.0, "rec": cd.combo_recovery if fin else 0.0})
	return out


static func names(cd: CharacterData) -> PackedStringArray:
	var out: PackedStringArray = []
	for s in steps(cd):
		out.append(String((s as Dictionary).get("n", "Serang")))
	return out


## Total pengali damage satu putaran kombo (anggap semua kena satu musuh; fan dihitung sebagian) dan lamanya (detik). Untuk uji keseimbangan.
static func cycle(cd: CharacterData) -> Vector2:
	var tot := 0.0
	var t := 0.0
	for s: Dictionary in steps(cd):
		var x := float(s.get("x", 1))
		var typ := String(s.get("t", "arc"))
		var hits := x
		if typ == "fan":
			hits = 1.0 + (x - 1.0) * 0.4
		elif typ == "twin":
			hits = 2.0
		elif typ == "bomb":
			hits = x
		elif typ in ["slam", "spin", "pull", "nova", "rain", "big", "wave", "pierce", "shot", "arc", "cone", "chain"]:
			hits = 1.0
		tot += float(s.get("m", 1.0)) * hits
		t += cd.attack_cooldown * float(s.get("cd", 1.0)) + float(s.get("rec", 0.0))
		if bool(s.get("need_dash", false)):
			t += 0.45                                  # langkah wajib-dash: hitung waktu dash di antara serangan
	return Vector2(tot, t)
