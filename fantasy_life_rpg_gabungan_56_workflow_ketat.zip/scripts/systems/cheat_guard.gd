class_name CheatGuard
extends RefCounted
## DETEKSI kecurangan saja (offline). TIDAK ADA blokir/penghapusan akun: temuan hanya dicatat (GameState.cheat_log),
## ditampilkan sebagai peringatan singkat, dan game tetap berjalan normal.
##
## Yang dideteksi:
##  - "tamper"        : isi save diubah di luar game (tanda tangan `sig` tidak cocok). Save lama tanpa `sig` diterima dulu & ditandatangani saat simpan berikutnya.
##  - "clock_back"    : jam perangkat diputar mundur (> CLOCK_TOLERANCE detik dari waktu tertinggi yang pernah tercatat di save).
##  - "anomaly"       : nilai mustahil (level/bintang di atas batas, gold/diamond negatif atau tak masuk akal).
##  - "other_device"  : kode cadangan dari perangkat lain dipakai di perangkat ini (ditolak, tanpa sanksi).
## CATATAN JUJUR: game ini offline dan kunci tanda tangan tertanam di aplikasi. Ini cukup untuk menangkap edit biasa, tetapi bukan
## perlindungan terhadap orang yang membongkar aplikasi. Deteksi yang kuat butuh server.

const CLOCK_TOLERANCE := 600          # detik: koreksi jam otomatis (NTP) biasanya jauh di bawah ini
const GOLD_SANE_MAX := 100_000_000
const DIAMOND_SANE_MAX := 10_000_000
const LOG_MAX := 20
const _KEY := "Fl-Aurelia|7Kq2mZ|save-sig|v1"

const TEXT := {
	"tamper": "Data permainan terdeteksi diubah di luar game.",
	"clock_back": "Jam perangkat terdeteksi diputar mundur.",
	"anomaly": "Terdeteksi nilai data yang tidak wajar.",
	"other_device": "Kode cadangan dari perangkat lain terdeteksi.",
}


## String kanonik dari isi save: HANYA bilangan bulat & teks (tanpa float) dengan kunci terurut, jadi sama persis
## sebelum disimpan dan sesudah dibaca lagi dari JSON.
static func canonical(d: Dictionary) -> String:
	var parts: PackedStringArray = []
	parts.append("id=%s" % str(d.get("id", "")))
	parts.append("n=%s" % str(d.get("name", "")))
	for k in ["version", "level", "exp", "gold", "diamonds", "pity", "pity_item", "login_days"]:
		parts.append("%s=%d" % [k, int(d.get(k, 0))])
	parts.append("ll=%s" % str(d.get("login_last", "")))
	for k in ["roster", "inventory", "stats", "stages", "equipment"]:
		var sub = d.get(k, {})
		var keys: Array = []
		if sub is Dictionary:
			keys = sub.keys()
			keys.sort()
		var seg: PackedStringArray = []
		for kk in keys:
			var v = sub[kk]
			if v is Dictionary:
				var ik: Array = v.keys()
				ik.sort()
				var inner: PackedStringArray = []
				for i in ik:
					var iv = v[i]
					inner.append("%s:%s" % [str(i), str(iv) if iv is String else str(int(iv))])
				seg.append("%s{%s}" % [str(kk), ",".join(inner)])
			else:
				seg.append("%s:%d" % [str(kk), int(v)])
		parts.append("%s=[%s]" % [k, ";".join(seg)])
	var party = d.get("party", [])
	parts.append("party=%s" % (",".join(PackedStringArray(party)) if party is Array else ""))
	return "|".join(parts)


static func signature(d: Dictionary) -> String:
	return Crypto.new().hmac_digest(HashingContext.HASH_SHA256, _KEY.to_utf8_buffer(), canonical(d).to_utf8_buffer()).hex_encode().substr(0, 24)


## 0 = cocok, 1 = tidak ada tanda tangan (save lama, diterima), 2 = TIDAK cocok (diubah).
static func verify(d: Dictionary) -> int:
	var s := str(d.get("sig", ""))
	if s == "":
		return 1
	return 0 if s == signature(d) else 2


## true bila `now` lebih kecil dari waktu tertinggi yang pernah tercatat (melebihi toleransi). seen = 0 -> belum ada data.
static func clock_rolled_back(seen: int, now: int, tolerance: int = CLOCK_TOLERANCE) -> bool:
	return seen > 0 and now < seen - tolerance


## Nilai mustahil di save mentah (SEBELUM dibersihkan/clamp saat dimuat). Mengembalikan daftar kode singkat.
static func anomalies(d: Dictionary, max_level: int, max_stars: int) -> Array:
	var out: Array = []
	if int(d.get("level", 1)) > max_level or int(d.get("level", 1)) < 1:
		out.append("level")
	if int(d.get("gold", 0)) < 0 or int(d.get("diamonds", 0)) < 0:
		out.append("negatif")
	if int(d.get("gold", 0)) > GOLD_SANE_MAX or int(d.get("diamonds", 0)) > DIAMOND_SANE_MAX:
		out.append("terlalu_besar")
	var ro = d.get("roster", {})
	if ro is Dictionary:
		for id in ro:
			if ro[id] is Dictionary and int(ro[id].get("stars", 1)) > max_stars:
				out.append("bintang")
				break
	return out
