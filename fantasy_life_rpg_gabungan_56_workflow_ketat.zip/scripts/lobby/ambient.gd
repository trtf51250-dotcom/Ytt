class_name Ambient
extends Node3D
## Kehidupan lobi: kupu-kupu di siang hari, kunang-kunang di malam hari. Hanya ~18 quad kecil yang selalu berada di sekitar pemain
## (ditempatkan ulang bila terlalu jauh), jadi murah untuk HP. Mati otomatis pada kualitas "Lancar".

const COUNT := 18
const RADIUS := 24.0
const BIRDS := 7                   # burung berputar tinggi di atas kota (siang)
const PETALS := 18                 # kelopak/daun berguguran di dekat pemain (siang)

var player: Node3D
var bounds_min := LobbyLayout.BOUNDS_MIN     # batas area serangga (peta Desa mengganti)
var bounds_max := LobbyLayout.BOUNDS_MAX
var daynight: DayNight
var _bugs: Array = []          # {node, mat, base:Vector3, ph:float, spd:float, col:Color}
var _t := 0.0
var _tex_wing: ImageTexture
var _tex_glow: ImageTexture
var _tex_petal: ImageTexture
var _birds: Array = []         # {node, ph, spd, r, h}
var _petals: Array = []        # {node, base:Vector3, life, spd, ph, col}


static func _tex(kind: String) -> ImageTexture:
	var n := 48
	var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
	for y in n:
		for x in n:
			var u := (x + 0.5) / n * 2.0 - 1.0
			var v := (y + 0.5) / n * 2.0 - 1.0
			var a := 0.0
			if kind == "petal":
				a = 1.0 if Vector2(u / 0.55, v / 1.0).length() < 1.0 else 0.0
			elif kind == "glow":
				a = clampf(1.0 - sqrt(u * u + v * v), 0.0, 1.0)
				a = a * a
			else:
				# dua sayap (elips miring kiri & kanan) + badan tipis
				var wx := absf(u)
				var d1 := Vector2((wx - 0.5) / 0.46, (v + 0.28 * (1.0 - wx)) / 0.55).length()
				var d2 := Vector2((wx - 0.4) / 0.34, (v - 0.4) / 0.4).length()
				if d1 < 1.0 or d2 < 1.0:
					a = 1.0 - 0.35 * minf(d1, d2)
				if wx < 0.06 and absf(v) < 0.6:
					a = 1.0
			img.set_pixel(x, y, Color(1, 1, 1, clampf(a, 0.0, 1.0)))
	return ImageTexture.create_from_image(img)


func setup(p: Node3D, dn: DayNight) -> void:
	player = p
	daynight = dn
	var quad := QuadMesh.new()
	quad.size = Vector2(0.6, 0.6)
	_tex_wing = _tex("wing")
	_tex_glow = _tex("glow")
	_tex_petal = _tex("petal")
	for i in COUNT:
		var mi := MeshInstance3D.new()
		mi.mesh = quad
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.no_depth_test = false
		mi.material_override = m
		add_child(mi)
		_bugs.append({"node": mi, "mat": m, "base": Vector3.ZERO, "ph": randf() * TAU, "spd": randf_range(0.6, 1.4), "col": Color.WHITE})
		_respawn(_bugs[i], true)
	_build_extras()
	visible = true


func _unshaded(tex: Texture2D) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_texture = tex
	return m


func _build_extras() -> void:
	var bq := QuadMesh.new()
	bq.size = Vector2(1.7, 1.7)
	var bm := _unshaded(_tex_wing)
	bm.albedo_color = Color(0.16, 0.18, 0.27, 0.92)
	for i in BIRDS:
		var mi := MeshInstance3D.new()
		mi.mesh = bq
		mi.material_override = bm
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)
		_birds.append({"node": mi, "ph": randf() * TAU, "spd": randf_range(0.07, 0.13) * (1.0 if i % 2 == 0 else -1.0), "r": randf_range(26.0, 52.0), "h": randf_range(17.0, 28.0)})
	var pq := QuadMesh.new()
	pq.size = Vector2(0.3, 0.3)
	var cols := [Color(1.0, 0.72, 0.82, 0.95), Color(1.0, 0.85, 0.9, 0.95), Color(0.75, 0.9, 0.5, 0.9)]
	for i in PETALS:
		var mi2 := MeshInstance3D.new()
		mi2.mesh = pq
		var pm := _unshaded(_tex_petal)
		pm.albedo_color = cols[i % cols.size()]
		mi2.material_override = pm
		mi2.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi2)
		_petals.append({"node": mi2, "base": Vector3.ZERO, "life": randf() * 6.0, "spd": randf_range(0.7, 1.3), "ph": randf() * TAU})
		_respawn_petal(_petals[i])


func _respawn_petal(p: Dictionary) -> void:
	var c: Vector3 = player.global_position if player != null else Vector3.ZERO
	var a := randf() * TAU
	var r := sqrt(randf()) * 15.0
	p["base"] = Vector3(c.x + cos(a) * r, 0.0, c.z + sin(a) * r)
	p["life"] = 0.0


func _update_extras(day: bool) -> void:
	var c := player.global_position
	for b in _birds:
		var n: MeshInstance3D = b["node"]
		n.visible = day
		if not day:
			continue
		var a: float = _t * float(b["spd"]) + float(b["ph"])
		var r: float = b["r"]
		n.global_position = Vector3(c.x + cos(a) * r, float(b["h"]) + sin(a * 3.0) * 1.2, c.z + sin(a) * r)
		n.scale = Vector3(0.35 + absf(sin(_t * 6.0 + float(b["ph"]))) * 0.75, 0.5, 1.0)
	for p in _petals:
		var n2: MeshInstance3D = p["node"]
		n2.visible = day
		if not day:
			continue
		p["life"] = float(p["life"]) + get_process_delta_time() * float(p["spd"])
		var y := 7.0 - float(p["life"]) * 1.1
		var bs: Vector3 = p["base"]
		if y < 0.05 or Vector2(bs.x - c.x, bs.z - c.z).length() > 20.0:
			_respawn_petal(p)
			continue
		var t2: float = _t * 1.4 + float(p["ph"])
		n2.global_position = Vector3(bs.x + sin(t2) * 0.9 + float(p["life"]) * 0.5, y, bs.z + cos(t2 * 0.8) * 0.7)
		n2.scale = Vector3(0.4 + 0.6 * absf(sin(t2 * 2.0)), 1.0, 1.0)


func _respawn(b: Dictionary, anywhere: bool) -> void:
	var c: Vector3 = player.global_position if player != null else Vector3.ZERO
	var a := randf() * TAU
	var r := sqrt(randf()) * (RADIUS if anywhere else RADIUS * 0.95)
	b["base"] = Vector3(clampf(c.x + cos(a) * r, bounds_min.x, bounds_max.x), randf_range(0.9, 2.6), clampf(c.z + sin(a) * r, bounds_min.y, bounds_max.y))
	var cols := [Color(1.0, 0.35, 0.65), Color(1.0, 0.7, 0.15), Color(0.3, 0.6, 1.0), Color(0.7, 0.4, 1.0)]
	b["col"] = cols[randi() % cols.size()]


func _process(delta: float) -> void:
	if player == null or daynight == null:
		return
	if Quality.level() == 0:       # "Lancar": tanpa hiasan
		visible = false
		return
	visible = true
	_t += delta
	var h := daynight.hour
	var day := h >= 6.5 and h <= 17.5
	var night := h >= 19.0 or h <= 4.5
	_update_extras(day)
	for b in _bugs:
		var n: MeshInstance3D = b["node"]
		var m: StandardMaterial3D = b["mat"]
		var base: Vector3 = b["base"]
		if Vector2(base.x - player.global_position.x, base.z - player.global_position.z).length() > RADIUS + 6.0:
			_respawn(b, false)
			base = b["base"]
		var t: float = _t * float(b["spd"]) + float(b["ph"])
		if day:
			# kupu-kupu: terbang meliuk, sayap mengepak (skala X)
			n.global_position = base + Vector3(sin(t * 0.7) * 2.2, sin(t * 1.3) * 0.5, cos(t * 0.55) * 2.2)
			n.scale = Vector3(0.25 + absf(sin(t * 9.0)) * 0.9, 1.0, 1.0)
			m.albedo_texture = _tex_wing
			m.albedo_color = Color(b["col"], 0.95)
			n.visible = true
		elif night:
			# kunang-kunang: melayang pelan, berkedip hangat
			n.global_position = base + Vector3(sin(t * 0.35) * 1.6, sin(t * 0.6) * 0.4, cos(t * 0.3) * 1.6)
			n.scale = Vector3.ONE * 1.1
			m.albedo_texture = _tex_glow
			var blink := 0.35 + 0.65 * (0.5 + 0.5 * sin(t * 2.2))
			m.albedo_color = Color(0.85, 1.0, 0.4, blink)
			n.visible = true
		else:
			n.visible = false      # senja/fajar: tidak ada
