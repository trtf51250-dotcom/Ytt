class_name DayNight
extends Node3D
## Langit, matahari/bulan, kabut, cahaya ambien, dan "glow" lampu/jendela mengikuti jam (0-24).
## time_mode (pengaturan): 0 otomatis (siklus pelan), 1 siang, 2 senja, 3 malam.

const DAY_LENGTH := 480.0          # detik nyata untuk 24 jam game (mode otomatis)

var hour := 10.5
var env: Environment
var sun: DirectionalLight3D
var sky_mat: ProceduralSkyMaterial
var mode := 0
var fixed_hour := -1.0            # >= 0: jam tetap (dipakai scene stage), mengabaikan pengaturan time_mode
var _t_acc := 0.0

# kunci warna: [jam, top, horizon, sun_color, sun_energy, ambient_color, ambient_energy, fog, glow]
const KEYS := [
	[0.0, Color(0.05, 0.07, 0.18), Color(0.12, 0.16, 0.32), Color(0.55, 0.65, 1.0), 0.28, Color(0.35, 0.42, 0.7), 0.5, Color(0.12, 0.16, 0.3), 1.5],
	[5.0, Color(0.1, 0.12, 0.3), Color(0.35, 0.3, 0.5), Color(0.7, 0.7, 1.0), 0.3, Color(0.4, 0.42, 0.7), 0.5, Color(0.3, 0.28, 0.45), 1.4],
	[6.5, Color(0.35, 0.45, 0.8), Color(1.0, 0.65, 0.5), Color(1.0, 0.72, 0.52), 0.75, Color(0.78, 0.72, 0.84), 0.62, Color(0.95, 0.7, 0.6), 0.9],
	[9.0, Color(0.32, 0.55, 0.92), Color(0.72, 0.86, 1.0), Color(1.0, 0.96, 0.86), 0.88, Color(0.8, 0.85, 0.95), 0.6, Color(0.75, 0.87, 0.98), 0.35],
	[13.0, Color(0.3, 0.55, 0.95), Color(0.74, 0.88, 1.0), Color(1.0, 0.97, 0.9), 0.92, Color(0.82, 0.87, 0.96), 0.6, Color(0.76, 0.88, 0.98), 0.3],
	[16.5, Color(0.36, 0.52, 0.9), Color(0.95, 0.85, 0.72), Color(1.0, 0.86, 0.68), 0.92, Color(0.82, 0.78, 0.9), 0.6, Color(0.95, 0.85, 0.75), 0.5],
	[18.2, Color(0.28, 0.3, 0.62), Color(1.0, 0.55, 0.4), Color(1.0, 0.62, 0.42), 0.75, Color(0.7, 0.62, 0.82), 0.6, Color(0.95, 0.6, 0.5), 1.0],
	[20.0, Color(0.1, 0.12, 0.3), Color(0.3, 0.25, 0.5), Color(0.6, 0.65, 1.0), 0.3, Color(0.4, 0.42, 0.7), 0.5, Color(0.25, 0.25, 0.45), 1.4],
	[24.0, Color(0.05, 0.07, 0.18), Color(0.12, 0.16, 0.32), Color(0.55, 0.65, 1.0), 0.28, Color(0.35, 0.42, 0.7), 0.5, Color(0.12, 0.16, 0.3), 1.5],
]


func _ready() -> void:
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_curve = 0.18
	sky_mat.ground_curve = 0.05
	sky_mat.sun_angle_max = 20.0
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	env.fog_enabled = true
	env.fog_density = 0.0
	env.fog_depth_begin = 110.0
	env.fog_depth_end = 330.0
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = bool(GameState.setting("shadows"))
	sun.directional_shadow_max_distance = 70.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.shadow_bias = 0.06
	sun.shadow_normal_bias = 1.2
	add_child(sun)
	apply_mode()


func apply_mode() -> void:
	if fixed_hour >= 0.0:
		mode = 99
		hour = fixed_hour
		apply_hour()
		sun.shadow_enabled = bool(GameState.setting("shadows"))
		return
	mode = int(GameState.setting("time_mode"))
	match mode:
		1: hour = 11.0
		2: hour = 17.8
		3: hour = 22.0
	apply_hour()
	sun.shadow_enabled = bool(GameState.setting("shadows"))


func _process(delta: float) -> void:
	if mode == 0:
		hour = fposmod(hour + delta * 24.0 / DAY_LENGTH, 24.0)
		_t_acc += delta
		if _t_acc > 0.25:
			_t_acc = 0.0
			apply_hour()


func apply_hour() -> void:
	var a: Array = KEYS[0]
	var b: Array = KEYS[1]
	for i in KEYS.size() - 1:
		if hour >= KEYS[i][0] and hour <= KEYS[i + 1][0]:
			a = KEYS[i]
			b = KEYS[i + 1]
			break
	var f := inverse_lerp(a[0], b[0], hour)
	f = f * f * (3.0 - 2.0 * f)
	sky_mat.sky_top_color = (a[1] as Color).lerp(b[1], f)
	var hz: Color = (a[2] as Color).lerp(b[2], f)
	sky_mat.sky_horizon_color = hz
	sky_mat.ground_horizon_color = hz
	sky_mat.ground_bottom_color = hz.darkened(0.25)
	sun.light_color = (a[3] as Color).lerp(b[3], f)
	sun.light_energy = lerpf(a[4], b[4], f)
	env.ambient_light_color = (a[5] as Color).lerp(b[5], f)
	env.ambient_light_energy = lerpf(a[6], b[6], f)
	env.fog_light_color = (a[7] as Color).lerp(b[7], f)
	WorldMats.set_glow(lerpf(a[8], b[8], f))
	# arah matahari/bulan: busur di langit (siang) atau bulan (malam)
	var day := hour >= 6.0 and hour <= 18.0
	var t := inverse_lerp(6.0, 18.0, hour) if day else inverse_lerp(18.0, 30.0, hour if hour >= 18.0 else hour + 24.0)
	var elev := sin(t * PI) * 58.0 + 8.0
	sun.rotation_degrees = Vector3(-elev, -40.0 + t * 100.0, 0.0)
	sun.light_energy *= 1.0 if day else 0.8


func hour_text() -> String:
	return "%02d:%02d" % [int(hour), int((hour - floor(hour)) * 60.0)]
