class_name VillageLayout
extends RefCounted
## Data tata letak Desa Fajar (peta terpisah di luar gerbang kota). Sumbu X = timur, Z = selatan. Satuan meter.
## Dipakai oleh VillageWorld (membangun dunia), Lobby (NPC, spawn), Minimap dan alat uji.
## Peta sengaja kecil (±170 x 190 m) dan hanya satu peta dimuat pada satu waktu supaya ringan di ponsel.

const SPAWN := Vector3(0.0, 0.1, -64.0)         # muncul di gerbang utara (arah kota Aurelia)
const SPAWN_YAW := 0.0                          # menghadap selatan (+Z), ke dalam desa
const WALL_MIN := Vector2(-84.0, -78.0)         # kotak yang digambar minimap
const WALL_MAX := Vector2(84.0, 92.0)
const BOUNDS_MIN := Vector2(-88.0, -158.0)      # batas tak terlihat tempat pemain bisa berjalan (z sampai -158: jalan raya penghubung ke kota Aurelia)
const BOUNDS_MAX := Vector2(88.0, 100.0)
const GROUND_MIN := Vector2(-108.0, -192.0)
const GROUND_MAX := Vector2(108.0, 120.0)
const SQUARE_C := Vector2(0, 0)
const SQUARE_R := 11.0
const NORTH_GATE := Vector3(0, 0, -74.0)        # lengkung pintu masuk desa (jalan raya ke kota Aurelia menyambung ke utara)

## --- Jalan raya penghubung Desa Fajar -> Aurelia (lurus ke utara dari lengkung utara desa) ---
## Berjalan sampai gerbang perbatasan (ROAD_GATE.z) memicu adegan peralihan ke kota. Dari kota pemain tiba di ROAD_ARRIVE menghadap selatan
## dan berjalan sendiri masuk ke arah desa.
const ROAD_GATE := Vector3(0, 0, -150.0)        # gerbang perbatasan di ujung jalan raya (ke kota Aurelia)
const ROAD_TRIGGER_Z := -144.0                  # melewati z ini (ke utara) = peralihan ke kota dimulai
const ROAD_ARRIVE := Vector3(0.0, 0.1, -124.0)  # titik tiba dari kota
const ROAD_ARRIVE_WALK := 24.0                  # jarak jalan otomatis saat tiba (m)
const ROAD_HALF_W := 12.0                       # setengah lebar koridor tak terlihat di sepanjang jalan raya
const SOUTH_GATE := Vector3(0, 0, 94.0)         # lengkung ke padang petualangan
const WINDMILL := Vector2(60.0, -32.0)
const WELL := Vector3(0, 0, 0)
const POND := Vector2(-46.0, 72.0)

## Jalan lurus & rapi: jalan utama utara-selatan (x = 0), jalan barat-timur (z = 0), dan tiga gang kecil.
const ROADS: Array = [
	{"pts": [Vector2(0, -82), Vector2(0, -40), Vector2(0, 0), Vector2(0, 50), Vector2(0, 98)], "w": 6.0},
	{"pts": [Vector2(-74, 0), Vector2(0, 0), Vector2(66, 0)], "w": 5.0},
	{"pts": [Vector2(0, -27), Vector2(30, -27), Vector2(56, -30)], "w": 3.6},
	{"pts": [Vector2(0, 52), Vector2(26, 52), Vector2(50, 52)], "w": 3.6},
	{"pts": [Vector2(0, 52), Vector2(-26, 52), Vector2(-40, 54), Vector2(-46, 62)], "w": 3.6},
	{"pts": [Vector2(0, -78), Vector2(0, -114), Vector2(0, -154)], "w": 6.0},       # 5 jalan raya penghubung ke kota Aurelia (lurus ke utara dari lengkung utara)
]

## Bangunan khusus (yaw tetap). Sisi utara jalan barat-timur menghadap selatan (yaw 0), sisi selatan menghadap utara (yaw 180).
const SPECIAL: Array = [
	{"kind": "library", "pos": Vector2(30, -14), "yaw": 0.0, "roof": Color(0.86, 0.5, 0.28), "wall": Color(1.0, 0.94, 0.8), "seed": 61},   # Balai Desa
	{"kind": "item_shop", "pos": Vector2(-26, -13), "yaw": 0.0, "roof": Color(0.3, 0.72, 0.5), "wall": Color(1.0, 0.97, 0.88), "seed": 62},  # Warung Desa
	{"kind": "forge", "pos": Vector2(-26, 13), "yaw": 180.0, "roof": Color(0.5, 0.52, 0.62), "seed": 63},                                      # Bengkel Desa
	{"kind": "pond", "pos": POND, "yaw": 0.0, "seed": 64},
]

## Rumah warga (12), dua barisan sejajar jalan utama dengan jarak sama (barat x = -13 menghadap timur, timur x = +13 menghadap barat).
## Lajur kosong: alun-alun (z -13..13), gang timur-barat z = -27 dan z = 52.
const HOUSES: Array = [
	{"kind": "house_a", "pos": Vector2(-13, -58), "yaw": 90.0, "roof": Color(0.92, 0.36, 0.32), "wall": Color(1.0, 0.95, 0.85), "seed": 71},
	{"kind": "house_b", "pos": Vector2(-13, -42), "yaw": 90.0, "roof": Color(0.98, 0.64, 0.28), "wall": Color(1.0, 0.92, 0.84), "seed": 73},
	{"kind": "house_c", "pos": Vector2(13, -58), "yaw": -90.0, "roof": Color(0.32, 0.55, 0.95), "wall": Color(1.0, 0.96, 0.88), "seed": 72},
	{"kind": "house_a", "pos": Vector2(13, -42), "yaw": -90.0, "roof": Color(0.64, 0.46, 0.9), "wall": Color(0.98, 0.95, 0.9), "seed": 74},
	{"kind": "house_b", "pos": Vector2(-13, 26), "yaw": 90.0, "roof": Color(0.35, 0.6, 0.45), "wall": Color(1.0, 0.94, 0.84), "seed": 75},
	{"kind": "house_a", "pos": Vector2(-13, 40), "yaw": 90.0, "roof": Color(0.85, 0.45, 0.55), "wall": Color(1.0, 0.96, 0.88), "seed": 76},
	{"kind": "house_c", "pos": Vector2(13, 26), "yaw": -90.0, "roof": Color(0.22, 0.72, 0.7), "wall": Color(1.0, 0.96, 0.88), "seed": 77},
	{"kind": "house_b", "pos": Vector2(13, 40), "yaw": -90.0, "roof": Color(0.92, 0.36, 0.32), "wall": Color(0.97, 0.97, 1.0), "seed": 78},
	{"kind": "house_a", "pos": Vector2(-13, 66), "yaw": 90.0, "roof": Color(0.64, 0.46, 0.9), "wall": Color(1.0, 0.96, 0.9), "seed": 79},
	{"kind": "house_c", "pos": Vector2(-13, 82), "yaw": 90.0, "roof": Color(0.98, 0.64, 0.28), "wall": Color(1.0, 0.96, 0.88), "seed": 80},
	{"kind": "house_a", "pos": Vector2(13, 66), "yaw": -90.0, "roof": Color(0.35, 0.6, 0.45), "wall": Color(1.0, 0.94, 0.84), "seed": 81},
	{"kind": "house_b", "pos": Vector2(13, 82), "yaw": -90.0, "roof": Color(0.32, 0.55, 0.95), "wall": Color(1.0, 0.95, 0.85), "seed": 82},
]

## Ladang (kotak sumbu dunia): baris tanam ke arah X.
const FIELDS: Array = [
	Rect2(28, 60, 24, 12),
	Rect2(28, 76, 24, 12),
	Rect2(58, 56, 22, 26),
]
