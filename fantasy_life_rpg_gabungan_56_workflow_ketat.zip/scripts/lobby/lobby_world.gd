class_name LobbyWorld
extends Node3D
## Membangun seluruh dunia lobi kota Aurelia secara prosedural: tanah, jalan, plaza, tembok, pohon, hiasan, bangunan.
## Mesh statis dipecah per "chunk" 32 m agar frustum culling bekerja baik di ponsel; tabrakan statis digabung dalam satu StaticBody3D.

const CHUNK := 32.0
## Pintu depan bangunan non-rumah (x lokal, z muka depan lokal, sebelum skala): dipakai untuk jalan setapak ke jalan.
const DOOR_LOCAL := {"weapon_shop": Vector2(-3.6, 4.0), "item_shop": Vector2(3.2, 4.0), "tower": Vector2(0.0, 3.9)}
const T_GRASS := MeshKit.T_GRASS
const T_COBBLE := MeshKit.T_COBBLE
const T_PLAZA := MeshKit.T_PLAZA
const T_DIRT := MeshKit.T_DIRT
const T_BRICK := MeshKit.T_BRICK
const T_MARBLE := MeshKit.T_MARBLE
const GROUND_MIN := Vector2(-180.0, -156.0)         # kota diperbesar 50% (lihat LobbyLayout.MAP_SCALE)
const GROUND_MAX := Vector2(180.0, 232.0)

var rng := RandomNumberGenerator.new()
var noise := FastNoiseLite.new()
var chunks: Dictionary = {}
var sink := ColliderSink.new()
var buildings: Array = []
var interactions: Array = []        # {"id","pos"(dunia),"action","prompt","radius"}
var road_lines: Array = []          # {"pts": Array[Vector2], "w": float}
var tree_positions: Array = []      # Vector2
var mesh_rects: Array = []          # Rect2 (XZ dunia) mesh tiap bangunan: pohon/lampu dijauhkan dari sini (beranda, atap, tangga)
var props_placed: Array = []        # Vector3 (pusat hiasan besar) agar tidak saling tumpuk
var g_min := GROUND_MIN              # luas tanah yang digambar (peta Desa lebih kecil)
var g_max := GROUND_MAX


func build() -> void:
	rng.seed = 20260
	noise.seed = 99
	noise.frequency = 0.03
	_spawn_buildings()
	_sample_roads()
	_ground()
	_roads()
	_plaza()
	_walls()
	_props()
	_connector()
	_trees()
	_flora()
	_far_scenery()
	_commit()
	_make_colliders()


# =====================================================================
#  Util
# =====================================================================
func kit_at(p: Vector3) -> MeshKit:
	var key := Vector2i(floori(p.x / CHUNK), floori(p.z / CHUNK))
	if not chunks.has(key):
		chunks[key] = MeshKit.new(key.x * 131 + key.y * 17 + 5)
	return chunks[key]


static func _catmull(pts: Array, per_seg: int = 8) -> Array:
	var out: Array = []
	var n := pts.size()
	if n < 3:
		return pts.duplicate()
	for i in n - 1:
		var p0: Vector2 = pts[maxi(i - 1, 0)]
		var p1: Vector2 = pts[i]
		var p2: Vector2 = pts[i + 1]
		var p3: Vector2 = pts[mini(i + 2, n - 1)]
		for j in per_seg:
			var t := float(j) / per_seg
			var v := 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t * t + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t * t * t)
			out.append(v)
	out.append(pts[n - 1])
	return out


static func dist_to_polyline(p: Vector2, pts: Array) -> float:
	var best := 1e9
	for i in pts.size() - 1:
		var a: Vector2 = pts[i]
		var b: Vector2 = pts[i + 1]
		var ab := b - a
		var t := clampf((p - a).dot(ab) / maxf(ab.length_squared(), 0.0001), 0.0, 1.0)
		best = minf(best, p.distance_to(a + ab * t))
	return best


func dist_to_roads(p: Vector2) -> float:
	var best := 1e9
	for r in road_lines:
		best = minf(best, dist_to_polyline(p, r["pts"]) - float(r["w"]) * 0.5)
	return best


func _near_building(p: Vector2, extra: float = 0.0) -> bool:
	for b in buildings:
		var bp := Vector2(b.position.x, b.position.z)
		if bp.distance_to(p) < b.footprint + extra:
			return true
	return false


## Titik p terlalu dekat dengan badan bangunan (mesh termasuk beranda/atap/tangga) -> jangan taruh pohon/lampu di sini.
func _near_mesh(p: Vector2, margin: float) -> bool:
	for r in mesh_rects:
		if (r as Rect2).grow(margin).has_point(p):
			return true
	return false


func plaza_radius() -> float:
	return LobbyLayout.PLAZA_R


func plaza_center() -> Vector2:
	return Vector2.ZERO


func inside_walls(p: Vector2, margin: float = 0.0) -> bool:
	return p.x > LobbyLayout.WALL_MIN.x + margin and p.x < LobbyLayout.WALL_MAX.x - margin \
		and p.y > LobbyLayout.WALL_MIN.y + margin and p.y < LobbyLayout.WALL_MAX.y - margin


# =====================================================================
#  Bangunan
# =====================================================================
## Daftar bangunan peta ini (peta Desa menimpa).
func _building_list() -> Array:
	return LobbyLayout.buildings()


func _spawn_buildings() -> void:
	for e in _building_list():
		var b := Building.new()
		b.kind = e["kind"]
		b.seed_value = e.get("seed", 1)
		if e.has("roof"):
			b.roof_color = e["roof"]
		if e.has("wall"):
			b.wall_color = e["wall"]
		var p: Vector2 = e["pos"]
		b.position = Vector3(p.x, 0.0, p.y)
		var yaw: float = e.get("yaw", 0.0)
		if e.get("face", false):
			yaw = rad_to_deg(atan2(-p.x, -p.y))
		b.rotation_degrees = Vector3(0, yaw, 0)
		b.name = "B_%s_%d" % [b.kind, buildings.size()]
		add_child(b)
		if not (b.kind in LobbyLayout.NO_SCALE):
			# Bangunan 10% lebih besar. Muka bangunan dijaga tetap di garis jalan: badan digeser mundur (menjauhi jalan) sebesar pertambahan kedalamannya.
			var s := LobbyLayout.BUILDING_SCALE
			b.scale = Vector3(s, s, s)
			b.footprint *= s
			b.position -= Vector3(sin(b.rotation.y), 0, cos(b.rotation.y)) * (s - 1.0) * b.footprint * 0.45
		buildings.append(b)
		if not (b.kind in ["gate", "fountain"]) and b.mesh_instance != null:
			var ab: AABB = b.global_transform * b.mesh_instance.mesh.get_aabb()
			mesh_rects.append(Rect2(ab.position.x, ab.position.z, ab.size.x, ab.size.z))
		for it in b.interactions:
			interactions.append({"id": it["id"], "pos": b.to_global(it["pos"]), "action": it["action"], "prompt": it["prompt"], "radius": it["radius"]})


# =====================================================================
#  Tanah
# =====================================================================
func _grass_color(x: float, z: float) -> Color:
	var n := noise.get_noise_2d(x, z) * 0.5 + 0.5
	var n2 := noise.get_noise_2d(x * 3.1 + 40.0, z * 3.1) * 0.5 + 0.5
	var a := Color(0.74, 0.88, 0.62)
	var b := Color(0.86, 0.96, 0.68)
	var c := a.lerp(b, n)
	c = c.lerp(Color(0.7, 0.86, 0.66), n2 * 0.35)
	# di luar tembok sedikit lebih gelap/kebiruan agar hutan terasa jauh
	var out_d := 0.0
	if not inside_walls(Vector2(x, z), -4.0):
		out_d = 0.12
	return Color(c.r * (1.0 - out_d), c.g * (1.0 - out_d * 0.6), c.b * (1.0 - out_d * 0.2))


func _ground() -> void:
	var cell := 6.0                                  # sel lebih besar (warna vertex halus) agar jumlah segi tanah tetap sama walau peta 1,5x
	var x := g_min.x
	while x < g_max.x:
		var z := g_min.y
		while z < g_max.y:
			var c00 := _grass_color(x, z)
			var c10 := _grass_color(x + cell, z)
			var c11 := _grass_color(x + cell, z + cell)
			var c01 := _grass_color(x, z + cell)
			var mid := Vector3(x + cell * 0.5, 0, z + cell * 0.5)
			var k := kit_at(mid)
			var s := k.uv_size
			k.quad_free(Vector3(x, 0, z + cell), Vector3(x + cell, 0, z + cell), Vector3(x + cell, 0, z), Vector3(x, 0, z), Vector3.UP, T_GRASS,
				c01, c11, c10, c00, Vector2(x, z + cell) / s * 1.4, Vector2(x + cell, z + cell) / s * 1.4, Vector2(x + cell, z) / s * 1.4, Vector2(x, z) / s * 1.4)
			z += cell
		x += cell


# =====================================================================
#  Jalan
# =====================================================================
func _sample_roads() -> void:
	road_lines.clear()
	for r in LobbyLayout.ROADS:
		var rl := {"pts": _catmull(r["pts"], 8), "w": r["w"]}
		if r.get("path", false):
			rl["path"] = true                                                            # jalan tanah berbatu (jalan raya penghubung di luar gerbang)
		road_lines.append(rl)
	for cp in [Vector2(-60, -72), Vector2(60, -72), Vector2(-60, 87), Vector2(60, 87)]:        # lingkaran putar ujung jalan samping (lihat _roads)
		road_lines.append({"pts": [cp, cp + Vector2(0.01, 0)], "w": 9.6, "cap": true})
	_house_paths()


## Jalan setapak ke tiap rumah: dari pintu depan ke titik terdekat pada jalan yang ada.
func _house_paths() -> void:
	for b in buildings:
		if not String(b.kind).begins_with("house"):
			continue
		var fwd := Vector3(sin(b.rotation.y), 0, cos(b.rotation.y))
		var door: Vector2 = Vector2(b.position.x, b.position.z) + Vector2(fwd.x, fwd.z) * (b.footprint * 0.55 + 2.2)
		var best_pt := Vector2.ZERO
		var best_d := 1e9
		for r in road_lines:
			var pts: Array = r["pts"]
			for i in pts.size() - 1:
				var a: Vector2 = pts[i]
				var c: Vector2 = pts[i + 1]
				var ab := c - a
				var t := clampf((door - a).dot(ab) / maxf(ab.length_squared(), 0.0001), 0.0, 1.0)
				var q := a + ab * t
				if door.distance_to(q) < best_d:
					best_d = door.distance_to(q)
					best_pt = q
		if b.has_door:                                       # mulai tepat di depan anak tangga pintu sebenarnya
			var dg: Vector3 = b.to_global(b.door_pos + Vector3(0, -0.4, 1.55))
			door = Vector2(dg.x, dg.z)
			best_d = 1e9
			var fwd2 := Vector2(fwd.x, fwd.z)
			for r in road_lines:
				if r.get("path", false):
					continue                                 # jangan menyambung ke setapak rumah lain
				var pts2: Array = r["pts"]
				for i in pts2.size() - 1:
					var a2: Vector2 = pts2[i]
					var c2: Vector2 = pts2[i + 1]
					var ab2 := c2 - a2
					var t2 := clampf((door - a2).dot(ab2) / maxf(ab2.length_squared(), 0.0001), 0.0, 1.0)
					var q2 := a2 + ab2 * t2
					var d2 := door.distance_to(q2)
					# setapak harus keluar KE DEPAN pintu (maks. ~35 derajat dari arah hadap), bukan menyamping ke ujung lorong/jalan lain
					if d2 > 1.0 and (q2 - door).normalized().dot(fwd2) < 0.82:
						continue
					if d2 < best_d:
						best_d = d2
						best_pt = q2
			if best_d > 33.0:                                # tak ada jalan di depan: pakai jalan terdekat seperti semula
				best_d = 1e9
				for r in road_lines:
					var pts4: Array = r["pts"]
					for i in pts4.size() - 1:
						var a4: Vector2 = pts4[i]
						var c4: Vector2 = pts4[i + 1]
						var ab4 := c4 - a4
						var t4 := clampf((door - a4).dot(ab4) / maxf(ab4.length_squared(), 0.0001), 0.0, 1.0)
						var q4 := a4 + ab4 * t4
						if door.distance_to(q4) < best_d:
							best_d = door.distance_to(q4)
							best_pt = q4
		if best_d < 34.0 and best_d > 1.0:
			var mid: Vector2 = (door + best_pt) * 0.5 + Vector2(-(best_pt - door).y, (best_pt - door).x).normalized() * minf(best_d * 0.08, 2.5)
			road_lines.append({"pts": _catmull([door, mid, best_pt], 6), "w": 2.6, "path": true})
	# toko & menara: pintu bukan di tengah muka bangunan; jalan setapak lurus dari pintu ke jalan terdekat agar tidak "melayang" di rumput
	for b in buildings:
		if not DOOR_LOCAL.has(b.kind):
			continue
		var dl: Vector2 = DOOR_LOCAL[b.kind]
		var dg2: Vector3 = b.to_global(Vector3(dl.x, 0.0, dl.y + 0.9))
		var door2 := Vector2(dg2.x, dg2.z)
		var bp2 := Vector2.ZERO
		var bd2 := 1e9
		for r in road_lines:
			var pts3: Array = r["pts"]
			for i in pts3.size() - 1:
				var a3: Vector2 = pts3[i]
				var c3: Vector2 = pts3[i + 1]
				var ab3 := c3 - a3
				var t3 := clampf((door2 - a3).dot(ab3) / maxf(ab3.length_squared(), 0.0001), 0.0, 1.0)
				var q3 := a3 + ab3 * t3
				if door2.distance_to(q3) < bd2:
					bd2 = door2.distance_to(q3)
					bp2 = q3
		if bd2 > 1.5 and bd2 < 34.0:
			var mid2: Vector2 = (door2 + bp2) * 0.5
			road_lines.append({"pts": _catmull([door2, mid2, bp2], 6), "w": 2.6, "path": true})


func _strip(pts: Array, width: float, tile: int, col: Color, y: float, edge: float = 1.0) -> void:
	var dist := 0.0
	var n := pts.size()
	var hw := width * 0.5
	for i in n - 1:
		var a: Vector2 = pts[i]
		var b: Vector2 = pts[i + 1]
		var t := b - a
		var sl := t.length()
		if sl < 0.01:
			continue
		t /= sl
		var ta := t
		var tb := t
		if i > 0:
			ta = ((a - (pts[i - 1] as Vector2)).normalized() + t).normalized()
		if i < n - 2:
			tb = (((pts[i + 2] as Vector2) - b).normalized() + t).normalized()
		var sa := Vector2(ta.y, -ta.x)
		var sb := Vector2(tb.y, -tb.x)
		var l0 := a + sa * hw
		var r0 := a - sa * hw
		var l1 := b + sb * hw
		var r1 := b - sb * hw
		var mid := (a + b) * 0.5
		var k := kit_at(Vector3(mid.x, 0, mid.y))
		var v0 := dist / k.uv_size
		var v1 := (dist + sl) / k.uv_size
		var uw := width / k.uv_size
		var cd := Color(col.r * edge, col.g * edge, col.b * edge, col.a)
		k.quad_free(Vector3(l0.x, y, l0.y), Vector3(r0.x, y, r0.y), Vector3(r1.x, y, r1.y), Vector3(l1.x, y, l1.y), Vector3.UP, tile, cd, cd, cd, cd,
			Vector2(0, v0), Vector2(uw, v0), Vector2(uw, v1), Vector2(0, v1))
		dist += sl


## Garis tengah jalan besar dipotong di tempat jalan lain memotongnya (persimpangan), supaya garis abu-abu tidak melintang di atas jalan yang menyilang.
func _inlay_runs(r: Dictionary) -> Array:
	var pts: Array = r["pts"]
	var runs: Array = []
	var cur: Array = []
	for i in pts.size() - 1:
		var a: Vector2 = pts[i]
		var b: Vector2 = pts[i + 1]
		var seg := a.distance_to(b)
		var steps := maxi(1, int(ceil(seg / 1.0)))
		for j in steps + (1 if i == pts.size() - 2 else 0):
			var p := a.lerp(b, float(j) / float(steps))
			var blocked := false
			for o in road_lines:
				if o == r or o.get("path", false) or o.get("cap", false):
					continue
				if dist_to_polyline(p, o["pts"]) < float(o["w"]) * 0.5 + 0.9:
					blocked = true
					break
			if blocked:
				if cur.size() >= 2:
					runs.append(cur)
				cur = []
			else:
				cur.append(p)
	if cur.size() >= 2:
		runs.append(cur)
	return runs


func _roads() -> void:
	for r in road_lines:
		if r.get("cap", false):
			continue
		var pts: Array = r["pts"]
		var w: float = r["w"]
		if r.get("path", false):
			_strip(pts, w + 0.5, T_DIRT, Color(0.92, 0.82, 0.7), 0.02)
			_strip(pts, w, T_COBBLE, Color(1.0, 0.97, 0.92), 0.03, 0.95)
		else:
			_strip(pts, w + 1.5, T_DIRT, Color(0.95, 0.85, 0.72), 0.02)
			_strip(pts, w + 0.7, T_BRICK, Pal.STONE, 0.03, 0.9)                 # tepi/trotoar batu terang
			_strip(pts, w, T_COBBLE, Color(1.0, 0.98, 0.94), 0.035)
			if w >= 8.0:
				for run in _inlay_runs(r):                                       # garis tengah (inlay) jalan besar, TERPUTUS di persimpangan
					_strip(run, 0.5, T_PLAZA, Color(0.82, 0.8, 0.84), 0.04)
	# ujung buntu jalan samping: lingkaran putar batu bertepi (tidak berhenti mendadak)
	for cp in [Vector2(-60, -72), Vector2(60, -72), Vector2(-60, 87), Vector2(60, 87)]:
		_ring_seg_full(Vector3(cp.x, 0, cp.y), 0.0, 4.4, 20, T_COBBLE, Color(1.0, 0.98, 0.94), 0.036)
		_ring_seg_full(Vector3(cp.x, 0, cp.y), 4.4, 5.0, 20, T_BRICK, Pal.STONE, 0.034)
		_ring_seg_full(Vector3(cp.x, 0, cp.y), 0.0, 1.1, 12, T_PLAZA, Color(0.82, 0.8, 0.84), 0.04)
	# jalan tanah di luar gerbang
	_strip([Vector2(0, 66), Vector2(1, 78), Vector2(0, 100)], 7.5, T_DIRT, Color(0.95, 0.85, 0.72), 0.03)
	# di luar gerbang jalan TIDAK lagi buntu: jalan raya penghubung (ROADS indeks 10) menyambung ke Desa Fajar (lihat _connector)
	# pelataran depan guild
	_ring_seg_full(Vector3(0, 0, -31.0), 0.0, 9.5, 28, T_PLAZA, Color(0.8, 0.79, 0.8), 0.05)
	_ring_seg_full(Vector3(0, 0, -31.0), 9.5, 10.3, 28, T_BRICK, Pal.STONE, 0.06)


## Cincin/cakram horizontal per baji (agar masuk chunk yang tepat).
func _ring_seg(c: Vector3, r0: float, r1: float, a0: float, a1: float, tile: int, col: Color, y: float, uv_mul: float = 1.0) -> void:
	var d0 := Vector2(cos(a0), sin(a0))
	var d1 := Vector2(cos(a1), sin(a1))
	var p00 := Vector3(c.x + d0.x * r0, y, c.z + d0.y * r0)
	var p01 := Vector3(c.x + d1.x * r0, y, c.z + d1.y * r0)
	var p11 := Vector3(c.x + d1.x * r1, y, c.z + d1.y * r1)
	var p10 := Vector3(c.x + d0.x * r1, y, c.z + d0.y * r1)
	var k := kit_at((p00 + p11) * 0.5)
	var s := k.uv_size / uv_mul
	k.quad_free(p00, p01, p11, p10, Vector3.UP, tile, col, col, col, col,
		Vector2(p00.x, p00.z) / s, Vector2(p01.x, p01.z) / s, Vector2(p11.x, p11.z) / s, Vector2(p10.x, p10.z) / s)


func _ring_seg_full(c: Vector3, r0: float, r1: float, segs: int, tile: int, col: Color, y: float, uv_mul: float = 1.0) -> void:
	for i in segs:
		_ring_seg(c, r0, r1, i * TAU / segs, (i + 1) * TAU / segs, tile, col, y, uv_mul)


func _plaza() -> void:
	var R := LobbyLayout.PLAZA_R
	var c := Vector3.ZERO
	_ring_seg_full(c, 0.0, R, 72, T_PLAZA, Color(0.8, 0.79, 0.8), 0.06)
	_ring_seg_full(c, R, R + 1.4, 72, T_BRICK, Color(0.92, 0.9, 0.88), 0.075)
	# cincin marmer & sinar matahari (8 jari-jari) sebagai ornamen lantai
	var ps := R / 15.0                                # ornamen lantai ikut membesar bersama plaza (air mancur & cincin emas tetap)
	_ring_seg_full(c, 8.4 * ps, 9.0 * ps, 72, T_MARBLE, Color(0.85, 0.88, 0.95), 0.08)
	_ring_seg_full(c, 12.3 * ps, 12.7 * ps, 72, T_MARBLE, Color(0.85, 0.88, 0.95), 0.08)
	for i in 8:
		var a := i * TAU / 8.0 + PI / 8.0
		var half := 0.055
		_ring_seg(c, 5.4, 8.4 * ps, a - half, a + half, T_MARBLE, Color(0.85, 0.88, 0.95), 0.08)
		_ring_seg(c, 9.0 * ps, 12.3 * ps, a - half * 0.8, a + half * 0.8, T_MARBLE, Color(0.85, 0.88, 0.95), 0.08)
	# cincin emas tipis dekat air mancur
	_ring_seg_full(c, 5.0, 5.2, 36, MeshKit.T_METAL, MeshKit.glow(Pal.GOLD, 0.35), 0.085)


# =====================================================================
#  Tembok & menara sudut
# =====================================================================
func _wall_run(a: Vector2, b: Vector2) -> void:
	var total := a.distance_to(b)
	var dir := (b - a) / total
	var ang := atan2(dir.x, dir.y)       # memutar +Z lokal ke arah dir
	var step := 10.0
	var n := int(ceil(total / step))
	for i in n:
		var l0 := total * float(i) / n
		var l1 := total * float(i + 1) / n
		var mid2 := a + dir * ((l0 + l1) * 0.5)
		var len := l1 - l0
		var k := kit_at(Vector3(mid2.x, 0, mid2.y))
		k.push()
		k.move(mid2.x, 0, mid2.y)
		k.xf = k.xf.rotated_local(Vector3.UP, ang)
		k.box_b(Vector3.ZERO, Vector3(2.1, 0.9, len + 0.05), T_BRICK, Pal.STONE_DARK, T_BRICK, Pal.STONE, 0.85)
		k.box_b(Vector3(0, 0.9, 0), Vector3(1.7, 3.6, len + 0.05), T_BRICK, Pal.STONE, T_BRICK, Pal.STONE_DARK, 0.8)
		k.box(Vector3(0, 4.65, 0), Vector3(2.0, 0.35, len + 0.05), T_BRICK, Pal.STONE_DARK, T_BRICK, Pal.STONE, 0.9)
		var m := int(len / 1.7)
		for j in m:
			var z := -len * 0.5 + (j + 0.5) * len / m
			k.box(Vector3(0.7, 5.15, z), Vector3(0.5, 0.65, 0.7), T_BRICK, Pal.STONE, T_BRICK, Pal.STONE, 0.9)
			k.box(Vector3(-0.7, 5.15, z), Vector3(0.5, 0.65, 0.7), T_BRICK, Pal.STONE, T_BRICK, Pal.STONE, 0.9)
		sink.box(k.xf, Vector3(0, 2.7, 0), Vector3(2.1, 5.4, len + 0.05))
		k.pop()


func _corner_tower(p: Vector2) -> void:
	var k := kit_at(Vector3(p.x, 0, p.y))
	k.push()
	k.move(p.x, 0, p.y)
	k.cylinder(Vector3.ZERO, 3.9, 3.7, 1.0, 10, T_BRICK, Pal.STONE_DARK, true, T_BRICK, false, 0.85)
	k.cylinder(Vector3(0, 1.0, 0), 3.4, 3.2, 8.0, 10, T_BRICK, Pal.STONE, true, T_BRICK, false, 0.8)
	k.cylinder(Vector3(0, 9.0, 0), 3.6, 3.9, 0.5, 10, T_BRICK, Pal.STONE_DARK, true, T_BRICK, false, 0.9)
	k.spire(Vector3(0, 9.5, 0), 4.3, 5.0, 10, MeshKit.T_ROOF, Pal.BLUE, 0.0)
	k.blob(Vector3(0, 14.7, 0), 0.25, MeshKit.T_METAL, Pal.GOLD, 3, 6)
	for face in 4:
		k.push()
		k.yaw(90.0 * face + 45.0)
		Decor.window(k, 0.0, 5.5, 3.2, 0.7, 1.3, 0.7, Pal.BLUE_DEEP, false)
		k.pop()
	sink.cyl(k.xf, Vector3.ZERO, 3.9, 9.5)
	k.pop()


func _walls() -> void:
	var mn := LobbyLayout.WALL_MIN
	var mx := LobbyLayout.WALL_MAX
	var gx := LobbyLayout.GATE_X
	_wall_run(Vector2(mn.x, mn.y), Vector2(mx.x, mn.y))
	_wall_run(Vector2(mx.x, mn.y), Vector2(mx.x, mx.y))
	_wall_run(Vector2(mn.x, mn.y), Vector2(mn.x, mx.y))
	_wall_run(Vector2(mn.x, mx.y), Vector2(-gx, mx.y))
	_wall_run(Vector2(gx, mx.y), Vector2(mx.x, mx.y))
	for c in [mn, Vector2(mx.x, mn.y), Vector2(mn.x, mx.y), mx]:
		_corner_tower(c)


# =====================================================================
#  Hiasan kota (lampu, lapak, bangku, sumur, dll)
# =====================================================================
func _free_for_prop(p: Vector2, r: float) -> bool:
	for q in props_placed:
		if Vector2(q.x, q.z).distance_to(p) < maxf(r, q.y):
			return false
	return true


func _reserve(p: Vector2, r: float) -> void:
	props_placed.append(Vector3(p.x, r, p.y))


func _props() -> void:
	var kk := func(p: Vector3) -> MeshKit: return kit_at(p)
	# --- lampu jalan di sepanjang jalan utama
	for ri in [0, 1, 2, 3, 4, 5]:
		var line: Array = road_lines[ri]["pts"]
		var w: float = road_lines[ri]["w"]
		var acc := 0.0
		var side := 1.0
		for i in line.size() - 1:
			var a: Vector2 = line[i]
			var b: Vector2 = line[i + 1]
			var seg := a.distance_to(b)
			acc += seg
			if acc < 11.0:
				continue
			acc = 0.0
			var t := (b - a).normalized()
			var p := b + Vector2(t.y, -t.x) * side * (w * 0.5 + 0.9)
			side = -side
			if p.length() < LobbyLayout.PLAZA_R + 2.0 or _near_building(p, -2.0) or p.y > 90.0 or _near_mesh(p, 0.8) or dist_to_roads(p) < 0.5:
				continue
			var pos := Vector3(p.x, 0, p.y)
			Decor.lamp_post(kk.call(pos), sink, pos)
			_reserve(p, 1.5)
	# --- papan penunjuk di luar gerbang (lampu & dekorasi jalan raya ada di _connector)
	var sp := Vector3(6.6, 0, 96.0)
	var sk := kit_at(sp)
	sk.box_b(sp, Vector3(0.22, 2.2, 0.22), MeshKit.T_WOOD, Pal.WOOD_DARK)
	sk.box(sp + Vector3(0, 2.0, 0.0), Vector3(2.2, 0.7, 0.14), MeshKit.T_WOOD, Pal.WOOD)
	sink.cyl(sk.xf, sp, 0.2, 2.2)
	var sl := Label3D.new()
	sl.text = "Desa Fajar  ↓\nJalan Raya  ±75 m"
	sl.font_size = 40
	sl.pixel_size = 0.008
	sl.modulate = Color(0.25, 0.14, 0.06)
	sl.outline_size = 0
	sl.shaded = false
	sl.position = sp + Vector3(0, 2.0, 0.09)
	sl.visibility_range_end = 40.0
	add_child(sl)
	interactions.append({"id": "sign_village", "pos": sp + Vector3(-1.2, 0, 0.6), "action": "go_village", "prompt": "Pergi ke Desa Fajar (langsung)", "radius": 3.4})
	# --- lampu cincin plaza + bangku mengelilingi air mancur + pot bunga
	var pr := LobbyLayout.PLAZA_R / 15.0              # faktor pembesaran plaza
	for i in 12:
		var a := i * TAU / 12.0
		var pos := Vector3(cos(a) * 14.2 * pr, 0, sin(a) * 14.2 * pr)
		if absf(sin(a)) > 0.9 or absf(cos(a)) > 0.95:
			continue
		Decor.lamp_post(kit_at(pos), sink, pos)
	for i in 9:
		var a := (i + 0.5) * TAU / 9.0 + 0.2
		var p := Vector3(cos(a) * 7.0 * pr, 0, sin(a) * 7.0 * pr)
		Decor.bench(kit_at(p), sink, p, rad_to_deg(atan2(-p.x, -p.z)))
	for i in 8:
		var a := i * TAU / 8.0 + PI / 8.0
		var p := Vector3(cos(a) * 10.6 * pr, 0, sin(a) * 10.6 * pr)
		Decor.planter(kit_at(p), sink, p, rad_to_deg(atan2(-p.x, -p.z)) + 90.0, 3.2, 1.4)
	# --- lapak pasar di tepi plaza (menghadap pusat)
	var stall_cols: Array = [Pal.RED, Pal.BLUE, Pal.ORANGE, Pal.TEAL]
	var goods: Array = [[Pal.RED, Pal.GOLD, Pal.GREEN], [Pal.PURPLE, Pal.PINK, Pal.SKY_BLUE], [Pal.ORANGE, Pal.GOLD, Pal.RED], [Pal.GREEN, Pal.WHITE, Pal.BLUE]]
	var si := 0
	for deg in [38.0, 62.0, 118.0, 142.0, 200.0, 242.0, 298.0, 340.0]:
		var a := deg_to_rad(deg)
		var p := Vector3(cos(a) * 12.2 * pr, 0, sin(a) * 12.2 * pr)
		Decor.stall(kit_at(p), sink, p, rad_to_deg(atan2(-p.x, -p.z)), stall_cols[si % 4], goods[si % 4])
		si += 1
	# --- jalan menuju guild: spanduk berpasangan
	for z in [-30.0, -39.0]:
		for sx in [-6.0, 6.0]:
			var p := Vector3(sx, 0, z)
			Decor.banner_pole(kit_at(p), sink, p, Pal.BLUE, 4.6, 0.0)
	# --- sumur, api unggun, boneka latihan, kolam taman
	var well_pos := Vector3(-39, 0, 14.25)
	Decor.well(kit_at(well_pos), sink, well_pos)
	_reserve(Vector2(well_pos.x, well_pos.z), 3.0)
	var well2 := Vector3(39, 0, 14.25)
	Decor.well(kit_at(well2), sink, well2)
	_reserve(Vector2(well2.x, well2.z), 3.0)
	# area latihan dekat tenda persiapan
	for i in 3:
		var p := Vector3(-85.5 + i * 3.6, 0, 17.25)
		Decor.training_dummy(kit_at(p), sink, p, 0.0)
		_reserve(Vector2(p.x, p.z), 2.0)
	var fire := Vector3(-70.5, 0, -16.5)
	Decor.campfire(kit_at(fire), fire)
	for i in 3:
		var a := 2.2 + i * 2.1
		var bp := fire + Vector3(cos(a) * 2.4, 0, sin(a) * 2.4)
		Decor.bench(kit_at(bp), sink, bp, rad_to_deg(atan2(-(bp.x - fire.x), -(bp.z - fire.z))))
	sink.cyl(Transform3D.IDENTITY, fire, 1.0, 0.8)
	# taman tenggara: bangku, pot bunga, batu
	var pond := Vector3(46.5, 0, 57)
	for i in 5:
		var a := i * TAU / 5.0 + 0.4
		var p := pond + Vector3(cos(a) * 8.4, 0, sin(a) * 8.4)
		Decor.bench(kit_at(p), sink, p, rad_to_deg(atan2(-(p.x - pond.x), -(p.z - pond.z))))
		_reserve(Vector2(p.x, p.z), 2.0)
	for i in 10:
		var p := Vector3(rng.randf_range(24, 75), 0, rng.randf_range(36, 81))
		if _near_building(Vector2(p.x, p.z), 3.0) or dist_to_roads(Vector2(p.x, p.z)) < 2.0:
			continue
		Decor.rock(kit_at(p), sink, p, rng.randf_range(0.5, 1.0))
	# peti & tong dekat gerbang (penjaga)
	Decor.crate(kit_at(Vector3(-8, 0, 87)), sink, Vector3(-8, 0, 87.5), 0.9, 10.0)
	Decor.barrel(kit_at(Vector3(-9, 0, 86)), sink, Vector3(-9.2, 0, 86.0))
	Decor.crate(kit_at(Vector3(8, 0, 87)), sink, Vector3(8.2, 0, 87.5), 0.9, -15.0)
	# pot bunga di sepanjang jalan selatan
	for z in [42.0, 54.0, 66.0]:
		for sx in [-5.5, 5.5]:
			var p := Vector3(sx, 0, z)
			Decor.planter(kit_at(p), sink, p, 90.0, 2.6, 1.2)


# =====================================================================
#  Pohon jalan (berjajar teratur di tepi jalan) lalu pohon taman
# =====================================================================
# =====================================================================
#  Jalan raya penghubung (Aurelia <-> Desa Fajar) & lengkung gerbang
# =====================================================================
## Lengkung batu: tiang kembar + palang kayu bertulisan. label = tulisan sisi +Z (dibaca orang yang datang dari utara/dalam),
## label_back = tulisan sisi -Z (kosong = sama). action kosong = hanya hiasan (tanpa tombol interaksi).
func _arch(pos: Vector3, label: String, action: String, prompt: String, iid: String, stone: Color, label_back: String = "") -> void:
	var k := kit_at(pos)
	for sx in [-4.2, 4.2]:
		var pp := pos + Vector3(sx, 0, 0)
		k.box_b(pp, Vector3(1.3, 5.2, 1.3), MeshKit.T_BRICK, stone, MeshKit.T_BRICK, stone.lightened(0.1))
		k.box_b(pp + Vector3(0, 5.2, 0), Vector3(1.7, 0.4, 1.7), MeshKit.T_BRICK, stone.darkened(0.1))
		sink.box(k.xf, pp + Vector3(0, 2.6, 0), Vector3(1.4, 5.2, 1.4))
	k.box(pos + Vector3(0, 5.0, 0), Vector3(9.6, 0.9, 1.1), MeshKit.T_WOOD, Pal.WOOD_DARK)
	k.box(pos + Vector3(0, 5.6, 0), Vector3(10.2, 0.25, 1.4), MeshKit.T_BRICK, stone.darkened(0.12))
	# tanda kayu dengan tulisan (dua sisi)
	var sk := Label3D.new()
	sk.text = label
	sk.font_size = 44
	sk.pixel_size = 0.0085
	sk.modulate = Color(1.0, 0.92, 0.68)
	sk.outline_size = 8
	sk.outline_modulate = Color(0.2, 0.1, 0.04)
	sk.shaded = false
	sk.position = pos + Vector3(0, 5.0, 0.58)
	sk.visibility_range_end = 60.0
	add_child(sk)
	var sk2 := sk.duplicate() as Label3D
	sk2.text = label_back if label_back != "" else label
	sk2.position = pos + Vector3(0, 5.0, -0.58)
	sk2.rotation.y = PI
	add_child(sk2)
	for sx in [-3.2, 3.2]:
		var lp := pos + Vector3(sx, 0, 1.6)
		Decor.lamp_post(kit_at(lp), sink, lp, 3.2)
	if action != "":
		interactions.append({"id": iid, "pos": pos + Vector3(0, 0, 0), "action": action, "prompt": prompt, "radius": 4.6})
	_reserve(Vector2(pos.x, pos.z), 6.0)


## Jalan raya penghubung peta Kota (z 117 -> 172): sebelumnya jalan buntu bertanda papan, kini menyambung ke gerbang perbatasan menuju Desa Fajar.
func _connector() -> void:
	_road_dressing(LobbyLayout.ROAD_START_Z, LobbyLayout.ROAD_GATE_Z, "Desa Fajar", 76.0)
	_arch(Vector3(0, 0, LobbyLayout.ROAD_GATE_Z), "Kota Aurelia  ↑", "go_village", "Pergi ke Desa Fajar", "gate_village", Color(0.66, 0.62, 0.56), "Desa Fajar  ↓")


## Perabot sepanjang jalan raya dari z_from ke z_to (arah mana pun): pagar kayu, lampu berselang-seling, tugu jarak bertulisan,
## pos istirahat (bangku, tong, peti, jerami, papan), barisan pohon rapi di kedua sisi, dan petak bunga. RNG sendiri agar tata letak lama tidak bergeser.
func _road_dressing(z_from: float, z_to: float, dest: String, extra_m: float) -> void:
	var dir := signf(z_to - z_from)
	var total := absf(z_to - z_from)
	var crng := RandomNumberGenerator.new()
	crng.seed = 7311 + int(absf(z_to))
	var z_rest := z_from + dir * 36.0
	var leaf_cols: Array = [Color(0.45, 0.82, 0.42), Color(0.38, 0.74, 0.46), Color(0.58, 0.86, 0.4)]
	# --- pagar kayu di kedua sisi (potongan 10 m; sisi timur dibuka di pos istirahat)
	var seg := 10.0
	var d := 8.0
	while d + seg <= total - 9.0:
		var za := z_from + dir * d
		var zb := z_from + dir * (d + seg)
		for sx in [-5.4, 5.4]:
			if sx > 0.0 and absf((za + zb) * 0.5 - z_rest) < 7.0:
				continue
			var fa := Vector3(sx, 0, za)
			var fb := Vector3(sx, 0, zb)
			Decor.fence(kit_at(fa), sink, fa, fb, 0.95, 2.0)
		d += seg
	# --- lampu jalan berselang-seling tiap 14 m
	var side := 1.0
	d = 9.0
	while d < total - 4.0:
		var lp := Vector3(side * 4.7, 0, z_from + dir * d)
		Decor.lamp_post(kit_at(lp), sink, lp, 3.2)
		side = -side
		d += 14.0
	# --- tugu jarak (sisi timur): nama tujuan + sisa jarak
	d = 20.0
	while d < total - 10.0:
		var mz := z_from + dir * d
		var mp := Vector3(4.4, 0, mz)
		var mk := kit_at(mp)
		mk.box_b(mp, Vector3(0.7, 1.0, 0.45), MeshKit.T_BRICK, Pal.STONE, MeshKit.T_BRICK, Pal.STONE_DARK)
		mk.box(mp + Vector3(0, 1.06, 0), Vector3(0.82, 0.14, 0.56), MeshKit.T_BRICK, Pal.STONE_DARK)
		sink.box(mk.xf, mp + Vector3(0, 0.55, 0), Vector3(0.8, 1.1, 0.55))
		var ml := Label3D.new()
		ml.text = "%s\n%d m" % [dest, int(absf(z_to - mz) + extra_m)]
		ml.font_size = 32
		ml.pixel_size = 0.0034
		ml.modulate = Color(0.3, 0.18, 0.08)
		ml.outline_size = 0
		ml.shaded = false
		ml.position = mp + Vector3(0, 0.62, 0.24)
		ml.visibility_range_end = 36.0
		add_child(ml)
		var ml2 := ml.duplicate() as Label3D
		ml2.position = mp + Vector3(0, 0.62, -0.24)
		ml2.rotation.y = PI
		add_child(ml2)
		d += 22.0
	# --- pos istirahat di sisi timur: pelataran tanah, dua bangku menghadap jalan, tong, peti, jerami, papan
	_strip([Vector2(3.4, z_rest), Vector2(10.5, z_rest)], 4.6, T_DIRT, Color(0.93, 0.84, 0.7), 0.031)
	for bz in [-2.4, 2.4]:
		var bp := Vector3(7.0, 0, z_rest + bz)
		Decor.bench(kit_at(bp), sink, bp, -90.0)
	var br := Vector3(10.0, 0, z_rest - 1.4)
	Decor.barrel(kit_at(br), sink, br)
	var cr := Vector3(10.2, 0, z_rest + 0.3)
	Decor.crate(kit_at(cr), sink, cr, 0.85, 12.0)
	var hb := Vector3(9.8, 0, z_rest + 2.4)
	Decor.hay_bale(kit_at(hb), sink, hb, 35.0)
	var np := Vector3(8.6, 0, z_rest)
	var nk := kit_at(np)
	nk.box_b(np + Vector3(0, 0, -0.9), Vector3(0.16, 2.0, 0.16), MeshKit.T_WOOD, Pal.WOOD_DARK)
	nk.box_b(np + Vector3(0, 0, 0.9), Vector3(0.16, 2.0, 0.16), MeshKit.T_WOOD, Pal.WOOD_DARK)
	nk.box(np + Vector3(0, 1.55, 0), Vector3(0.12, 0.8, 2.1), MeshKit.T_WOOD, Pal.WOOD)
	sink.box(nk.xf, np + Vector3(0, 1.0, 0), Vector3(0.3, 2.0, 2.1))
	var nl := Label3D.new()
	nl.text = "Pos Istirahat\nJalan Raya Fajar"
	nl.font_size = 34
	nl.pixel_size = 0.0055
	nl.modulate = Color(0.25, 0.14, 0.06)
	nl.outline_size = 0
	nl.shaded = false
	nl.position = np + Vector3(-0.1, 1.55, 0)
	nl.rotation.y = -PI * 0.5
	nl.visibility_range_end = 36.0
	add_child(nl)
	_reserve(Vector2(8.6, z_rest), 5.0)
	# --- barisan pohon rapi di kedua sisi (di luar pagar), petak bunga di antaranya
	d = 6.0
	var ti := 0
	while d < total - 8.0:
		var tz := z_from + dir * d
		for sx in [-9.3, 9.3]:
			if sx > 0.0 and absf(tz - z_rest) < 8.0:
				continue
			var tp := Vector3(sx + crng.randf_range(-0.5, 0.5), 0, tz + crng.randf_range(-1.2, 1.2))
			Decor.tree(kit_at(tp), sink, tp, crng.randf_range(4.4, 5.6), leaf_cols[(ti + (1 if sx > 0.0 else 0)) % leaf_cols.size()], 1 if (ti + (1 if sx > 0.0 else 0)) % 3 == 1 else 0)
			tree_positions.append(Vector2(tp.x, tp.z))
		ti += 1
		d += 9.0
	d = 14.0
	while d < total - 10.0:
		for sx in [-6.9, 6.9]:
			if sx > 0.0 and absf(z_from + dir * d - z_rest) < 8.0:
				continue
			var fp := Vector3(sx, 0, z_from + dir * d + crng.randf_range(-1.5, 1.5))
			Decor.flower_patch(kit_at(fp), fp, crng.randf_range(0.8, 1.4), crng.randi_range(6, 11))
		d += 15.0


func _street_trees() -> void:
	var spots: Array = []
	# bulevar timur-barat: dua baris di kedua sisi
	for sx in [-1.0, 1.0]:
		for i in 6:
			var x: float = sx * (32.0 + 6.5 * i)
			spots.append(Vector2(x, -6.6))
			spots.append(Vector2(x, 6.6))
	# jalan samping barat & timur
	for sx in [-1.0, 1.0]:
		for i in 16:
			var z: float = -63.0 + 9.0 * i
			if absf(z) < 13.5:
				continue
			spots.append(Vector2(sx * 60.0 - 5.2, z))
			spots.append(Vector2(sx * 60.0 + 5.2, z))
	# jalan utama selatan
	for i in 6:
		var z2: float = 36.0 + 9.0 * i
		spots.append(Vector2(-6.4, z2 + 4.5))
		spots.append(Vector2(6.4, z2 + 4.5))
	for p in spots:
		if not inside_walls(p, 3.0) or _near_building(p, -1.0) or p.length() < LobbyLayout.PLAZA_R + 2.5:
			continue
		if _near_mesh(p, 2.2) or dist_to_roads(p) < 1.4:
			continue
		if not _free_for_prop(p, 2.2):
			continue
		var pos := Vector3(p.x, 0, p.y)
		Decor.tree(kit_at(pos), sink, pos, 4.6, _greens(), 2 if rng.randf() < 0.3 else 0)
		tree_positions.append(p)
		_reserve(p, 1.8)


# =====================================================================
#  Pohon
# =====================================================================
func _tree_ok(p: Vector2, min_d: float, road_margin: float = 2.2) -> bool:
	if p.length() < LobbyLayout.PLAZA_R + 3.5:
		return false
	if _near_building(p, 2.5) or _near_mesh(p, 2.2):
		return false
	if dist_to_roads(p) < road_margin:
		return false
	for q in props_placed:
		if Vector2(q.x, q.z).distance_to(p) < q.y + 1.0:
			return false
	for t in tree_positions:
		if (t as Vector2).distance_to(p) < min_d:
			return false
	if Vector2(0, 93).distance_to(p) < 14.0:
		return false
	if p.distance_to(Vector2(LobbyLayout.SPAWN.x, LobbyLayout.SPAWN.z)) < 6.0:
		return false
	return true


func _greens() -> Color:
	var opts: Array = [Color(0.45, 0.82, 0.42), Color(0.38, 0.74, 0.46), Color(0.58, 0.86, 0.4), Color(0.36, 0.7, 0.56)]
	return opts[rng.randi() % opts.size()]


func _trees() -> void:
	_street_trees()
	# di dalam kota
	for z in LobbyLayout.TREE_ZONES:
		var rect: Rect2 = z["rect"]
		var count: int = z["count"]
		var placed := 0
		var tries := 0
		while placed < count and tries < count * 40:
			tries += 1
			var p := Vector2(rng.randf_range(rect.position.x, rect.end.x), rng.randf_range(rect.position.y, rect.end.y))
			if not inside_walls(p, 4.5) or not _tree_ok(p, 3.4):
				continue
			var kind := 0
			var r := rng.randf()
			if r < float(z["blossom"]):
				kind = 2
			elif r < float(z["blossom"]) + 0.25:
				kind = 1
			var pos := Vector3(p.x, 0, p.y)
			Decor.tree(kit_at(pos), sink, pos, rng.randf_range(4.0, 6.2), _greens(), kind)
			tree_positions.append(p)
			placed += 1
	# hutan di luar tembok (tanpa tabrakan, detail rendah)
	var outside := 0
	var tries2 := 0
	while outside < 330 and tries2 < 7000:
		tries2 += 1
		var p := Vector2(rng.randf_range(-162.0, 162.0), rng.randf_range(-144.0, 222.0))
		if inside_walls(p, -6.0):
			continue
		if absf(p.x) < LobbyLayout.ROAD_HALF_W + 3.0 and p.y > 90.0:          # koridor jalan raya penghubung dibiarkan bebas
			continue
		var ok := true
		for t in tree_positions:
			if (t as Vector2).distance_to(p) < 4.0:
				ok = false
				break
		if not ok:
			continue
		var kind := 1 if rng.randf() < 0.45 else 0
		var pos := Vector3(p.x, 0, p.y)
		Decor.tree(kit_at(pos), null, pos, rng.randf_range(5.0, 8.5), _greens(), kind, true)
		tree_positions.append(p)
		outside += 1


# =====================================================================
#  Rumput, bunga, semak (cutout)
# =====================================================================
func _flora() -> void:
	# rumput liar
	var n := 0
	var tries := 0
	while n < 2100 and tries < 13000:
		tries += 1
		var p := Vector2(rng.randf_range(-99.0, 99.0), rng.randf_range(-81.0, 96.0))
		if not inside_walls(p, 2.0):
			continue
		if p.length() < LobbyLayout.PLAZA_R + 2.0 or dist_to_roads(p) < 0.8 or _near_building(p, 1.5):
			continue
		var k := kit_at(Vector3(p.x, 0, p.y))
		k.cut = true
		k.cross_quads(Vector3(p.x, 0, p.y), rng.randf_range(0.7, 1.2), rng.randf_range(0.55, 0.95), MeshKit.T_TUFT, k.jitter(Color(0.92, 1.0, 0.8), 0.12), 0.9, rng.randf() * 90.0)
		k.cut = false
		n += 1
	# kelompok bunga
	var f := 0
	tries = 0
	while f < 130 and tries < 3000:
		tries += 1
		var p := Vector2(rng.randf_range(-93.0, 93.0), rng.randf_range(-75.0, 90.0))
		if not inside_walls(p, 3.0) or p.length() < LobbyLayout.PLAZA_R + 2.5 or dist_to_roads(p) < 1.2 or _near_building(p, 2.0):
			continue
		var k := kit_at(Vector3(p.x, 0, p.y))
		Decor.flower_patch(k, Vector3(p.x, 0, p.y), rng.randf_range(1.0, 2.2), rng.randi_range(8, 18))
		f += 1
	# semak
	var bsh := 0
	tries = 0
	while bsh < 60 and tries < 2200:
		tries += 1
		var p := Vector2(rng.randf_range(-90.0, 90.0), rng.randf_range(-72.0, 87.0))
		if not inside_walls(p, 3.5) or not _tree_ok(p, 2.2, 3.0):
			continue
		var pos := Vector3(p.x, 0, p.y)
		Decor.bush(kit_at(pos), sink, pos, rng.randf_range(0.6, 1.1), _greens())
		tree_positions.append(p)
		bsh += 1
	# rumput di luar tembok (jarang)
	var o := 0
	tries = 0
	while o < 800 and tries < 4800:
		tries += 1
		var p := Vector2(rng.randf_range(-150.0, 150.0), rng.randf_range(-135.0, 212.0))
		if inside_walls(p, -3.0) or (absf(p.x) < 7.0 and p.y > 93.0):
			continue
		var k := kit_at(Vector3(p.x, 0, p.y))
		k.cut = true
		k.cross_quads(Vector3(p.x, 0, p.y), 1.0, 0.8, MeshKit.T_TUFT, k.jitter(Color(0.8, 0.95, 0.75), 0.1), 0.9, rng.randf() * 90.0)
		k.cut = false
		o += 1


# =====================================================================
#  Pemandangan jauh (bukit & gunung)
# =====================================================================
## Bukit/gunung jauh tidak boleh berdiri di atas jalan raya penghubung (peta Desa menimpa: koridor di sisi utara).
func _far_blocked(p: Vector3, r: float) -> bool:
	return absf(p.x) < r + 16.0 and p.z > 90.0 and p.z - r < LobbyLayout.BOUNDS_MAX.y + 24.0


func _far_scenery() -> void:
	for i in 26:
		var a := i * TAU / 26.0 + rng.randf() * 0.2
		var d := rng.randf_range(225.0, 322.0)
		var p := Vector3(cos(a) * d * 1.15, 0, 15.0 + sin(a) * d)
		var h := rng.randf_range(34.0, 62.0)
		var r := h * rng.randf_range(0.9, 1.25)
		var k := kit_at(p)
		var col := Color(0.62, 0.74, 0.9).lerp(Color(0.7, 0.82, 0.8), rng.randf() * 0.6)
		if _far_blocked(p, r):
			continue
		k.cylinder(p, r, r * 0.08, h, 7, MeshKit.T_PLASTER, col, false, -1, false, 0.9)
		# puncak salju
		k.cylinder(p + Vector3(0, h * 0.72, 0), r * 0.08 + (r - r * 0.08) * 0.28, 0.0, h * 0.28 + 0.4, 7, MeshKit.T_PLASTER, Color(0.97, 0.98, 1.0), false, -1, false, 0.95)
	for i in 30:
		var a := i * TAU / 30.0 + rng.randf() * 0.3
		var d := rng.randf_range(172.0, 210.0)
		var p := Vector3(cos(a) * d * 1.2, 0, 15.0 + sin(a) * d)
		var k := kit_at(p)
		var br := rng.randf_range(18.0, 30.0)
		if _far_blocked(p, br):
			continue
		k.blob(p, br, T_GRASS, Color(0.62, 0.8, 0.56), 4, 8, 0.38, 0.3)


# =====================================================================
#  Hasil
# =====================================================================
func _commit() -> void:
	for key in chunks:
		var kit: MeshKit = chunks[key]
		if kit.vertex_count() == 0:
			continue
		var mesh := kit.build()
		kit.apply_materials(mesh)
		var mi := MeshInstance3D.new()
		mi.name = "Chunk_%d_%d" % [key.x, key.y]
		mi.mesh = mesh
		# Gunung/pemandangan jauh tidak boleh melempar bayangan: kotak bayangan matahari jadi melebar dan seluruh kota tampak gelap
		# kebiruan (dan menambah beban render). Hanya potongan kota yang ikut membuat bayangan.
		var bb := mesh.get_aabb()
		var cc := bb.get_center()
		if Vector2(cc.x, cc.z).length() > 150.0 or bb.size.y > 30.0:
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)
	chunks.clear()


func _make_colliders() -> void:
	var body := StaticBody3D.new()
	body.name = "WorldBody"
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	# lantai
	var floor_cs := CollisionShape3D.new()
	var fb := BoxShape3D.new()
	fb.size = Vector3(800, 2, 800)
	floor_cs.shape = fb
	floor_cs.position = Vector3(0, -1.0, 0)
	body.add_child(floor_cs)
	# batas dunia tak terlihat
	var bmn := LobbyLayout.BOUNDS_MIN
	var bmx := LobbyLayout.BOUNDS_MAX
	var walls: Array = [
		[Vector3((bmn.x + bmx.x) * 0.5, 5, bmn.y - 1.0), Vector3(bmx.x - bmn.x + 4, 10, 2)],
		[Vector3((bmn.x + bmx.x) * 0.5, 5, bmx.y + 1.0), Vector3(bmx.x - bmn.x + 4, 10, 2)],
		[Vector3(bmn.x - 1.0, 5, (bmn.y + bmx.y) * 0.5), Vector3(2, 10, bmx.y - bmn.y + 4)],
		[Vector3(bmx.x + 1.0, 5, (bmn.y + bmx.y) * 0.5), Vector3(2, 10, bmx.y - bmn.y + 4)],
		# koridor jalan raya di luar gerbang sampai gerbang perbatasan (hutan di sisinya hanya hiasan)
		[Vector3(-(LobbyLayout.ROAD_HALF_W + 0.5), 5, (LobbyLayout.WALL_MAX.y + bmx.y) * 0.5), Vector3(2, 10, bmx.y - LobbyLayout.WALL_MAX.y + 2.0)],
		[Vector3(LobbyLayout.ROAD_HALF_W + 0.5, 5, (LobbyLayout.WALL_MAX.y + bmx.y) * 0.5), Vector3(2, 10, bmx.y - LobbyLayout.WALL_MAX.y + 2.0)],
	]
	for w in walls:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = w[1]
		cs.shape = bs
		cs.position = w[0]
		body.add_child(cs)
	sink.apply_to(body)
