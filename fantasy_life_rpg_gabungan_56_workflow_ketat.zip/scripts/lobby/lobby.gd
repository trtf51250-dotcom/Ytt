extends Node3D
## Scene lobi Aurelia: merangkai dunia, pemain, kamera, siang-malam, NPC, HUD, kontrol sentuh, dialog, dan panel menu.
## Interaksi: NPC / objek terdekat (dalam radius) -> prompt di HUD -> tombol Interaksi (E / tombol sentuh) atau ketuk prompt.

var world: LobbyWorld
var player: Player
var cam: CameraRig
var daynight: DayNight
var ui: CanvasLayer
var hud: Hud
var touch: TouchControls
var dialogue: DialogueBox
var host: PanelHost
var explore: ExploreWorld              # hanya di kota (peta Desa tidak punya peti/teleport)
var map_id := "town"                    # "town" | "village" (lihat Flow.lobby_map)
var _res_list: Array = NpcDefs.RESIDENTS
var npcs: Dictionary = {}
var villagers: Array = []
var interior: HouseInterior = null        # ruangan rumah yang sedang dimasuki (dibuat saat masuk, dibuang saat keluar)
var _house_busy := false
var _house_b: Building = null
var _house_saved := {}
var _house_occupant: Villager = null
var _house_hidden: Array = []
var _fade_rect: ColorRect
var _target: Dictionary = {}
var _talking: Node3D
var _hp_timer := 0.0
var _last_leader := ""
var _auto_attack_gate := 0.0
var _crossing := false                  # adegan peralihan peta lewat jalan raya sedang berjalan
var _cross_grace := 0.0                 # jeda setelah tiba supaya pemicu tidak langsung aktif lagi


func _ready() -> void:
	InputSetup.ensure()
	WorldMats.reset()
	Sfx.music("music_main")
	daynight = DayNight.new()
	daynight.name = "DayNight"
	add_child(daynight)
	map_id = _arg("map", Flow.lobby_map)
	Flow.lobby_map = map_id
	if map_id == "village":
		_res_list = NpcDefs.VILLAGE_RESIDENTS
		world = VillageWorld.new()
	else:
		world = LobbyWorld.new()
	world.name = "World"
	add_child(world)
	world.build()
	_spawn_npcs()
	if map_id != "village":
		explore = ExploreWorld.new()
		add_child(explore)
		explore.setup(self)
	player = Player.new()
	player.name = "Player"
	add_child(player)
	_last_leader = GameState.leader()
	player.set_character(_last_leader)
	player.global_position = _spawn_point()
	player.facing = deg_to_rad(VillageLayout.SPAWN_YAW if map_id == "village" else LobbyLayout.SPAWN_YAW)
	player.global_position = _spawn_point()
	player.surface_probe = _surface_at
	cam = CameraRig.new()
	cam.name = "CameraRig"
	add_child(cam)
	cam.target = player
	cam.lead_enabled = true
	cam.kick_enabled = true
	cam.set_occluders_from(world.buildings)       # bangunan padat tidak memudar, jadi kamera yang ditarik mendekat bila ada dinding di belakang pemain
	var arrival := Flow.road_arrival
	Flow.road_arrival = ""
	if arrival != "":
		_place_for_arrival(arrival)
	cam.snap_to_target()
	_build_ui()
	Quality.apply(get_viewport(), daynight.sun, cam.cam, daynight.env)
	if map_id == "village":
		SkyLife.make(self, daynight, cam.cam, Vector3(0, 0, 8), 200.0, 110.0, 450.0)
	else:
		SkyLife.make(self, daynight, cam.cam, Vector3(0, 0, 9), 225.0, 117.0, 500.0)
	var amb := Ambient.new()
	amb.name = "Ambient"
	if map_id == "village":
		amb.bounds_min = VillageLayout.BOUNDS_MIN
		amb.bounds_max = VillageLayout.BOUNDS_MAX
	add_child(amb)
	amb.setup(player, daynight)
	GameState.changed.connect(_on_state_changed)
	_update_markers()
	_check_bot()
	if arrival != "":
		_arrive_walk(arrival)
	else:
		_opening_sequence()


## Urutan pembuka: prolog cerita (sekali per dunia), lalu hadiah login otomatis.
func _opening_sequence() -> void:
	var first_time := not Story.seen("prolog")
	await StoryPlayer.play(self, "prolog")
	if first_time and map_id != "village" and Story.seen("prolog"):
		Flow.toast("Misi pertama: masuk Portal Petualangan di sisi timur alun-alun.", 4.0)
	if map_id == "village":
		await StoryPlayer.play(self, "v_prolog")
	if map_id == "village":
		if GameState.stage_cleared("v1_boss"):                   # Sedekah Bumi: Mbah Kerto menceritakan tiga Penjaga
			await StoryPlayer.play(self, "v_hub")
	else:
		if GameState.stage_cleared("s1_boss") and not GameState.stage_cleared("v1_boss"):
			await StoryPlayer.play(self, "a_to_village")
		if GameState.stage_cleared("s5_boss"):
			await StoryPlayer.play(self, "a_return")
		if GameState.stage_cleared("s6_boss"):
			await StoryPlayer.play(self, "a_epilogue")
	_auto_login_gift()


## Titik muncul: kembali dari stage = di depan portal/gerbang; baru mulai = titik spawn.
func _spawn_point() -> Vector3:
	return VillageLayout.SPAWN if map_id == "village" else LobbyLayout.SPAWN


func _build_ui() -> void:
	Vignette.attach(self)
	ui = CanvasLayer.new()
	ui.name = "UI"
	ui.layer = 10
	add_child(ui)
	hud = Hud.new()
	ui.add_child(hud)
	touch = TouchControls.new()
	ui.add_child(touch)
	dialogue = DialogueBox.new()
	ui.add_child(dialogue)
	host = PanelHost.new()
	host.context = {"lobby": self, "player": player}
	add_child(host)
	hud.menu_pressed.connect(_on_menu)
	hud.adventure_pressed.connect(func(): host.open("stage_select", {"adventure": true}))
	hud.interact_pressed.connect(_try_interact)
	hud.profile_pressed.connect(func(): host.open("profile"))
	hud.setup_minimap(self, player, cam)
	hud.map_pressed.connect(_open_map)
	dialogue.action_chosen.connect(_run_action)
	dialogue.closed.connect(_on_dialogue_closed)
	host.opened.connect(func(_id): _set_ui_modal(true))
	host.closed.connect(func(): _set_ui_modal(false))
	touch.touch_enabled = DisplayServer.is_touchscreen_available() or bool(GameState.setting("force_touch")) or _arg("touch") != ""


func _set_ui_modal(on: bool) -> void:
	var open := on or dialogue.is_open
	player.control_enabled = not open
	cam.enabled = not open
	if open:
		player.move_input = Vector2.ZERO
		touch.release_all()
	touch.visible = not open and touch.touch_enabled
	hud.visible = not dialogue.is_open


func _open_map() -> void:
	if map_id == "village":
		host.open("world_map")                  # Desa Fajar kecil (cukup minimap); tombol peta membuka Peta Dunia penghubung ke Aurelia
		return
	host.open("map")


func _on_menu(id: String) -> void:
	match id:
		"shop":
			host.open("shop", {"tab": "weapon"})
		"map":
			_open_map()
		_:
			host.open(id)


# ---------------------------------------------------------------- NPC
func _spawn_npcs() -> void:
	var root := Node3D.new()
	root.name = "Npcs"
	add_child(root)
	if map_id == "village":
		_spawn_village_npcs(root)
		return
	for id in NpcDefs.ids():
		var spot: Vector2 = LobbyLayout.NPC_SPOTS.get(id, Vector2.ZERO)
		var n := Npc.new()
		root.add_child(n)
		n.setup(id)
		n.position = Vector3(spot.x, 0.04, spot.y)
		n.face_yaw(float(LobbyLayout.NPC_FACE.get(id, atan2(-spot.x, -spot.y))))
		npcs[id] = n
	var vb := Quality.villager_budget()
	for i in NpcDefs.VILLAGER_PRIORITY:
		if villagers.size() >= vb or i >= NpcDefs.VILLAGERS.size():
			continue
		var d: Dictionary = NpcDefs.VILLAGERS[i]
		var v := Villager.new()
		root.add_child(v)
		v.setup(d)
		villagers.append(v)
	_spawn_residents(root)


## NPC Desa Fajar (±20): fungsional + pengembara + penghuni rumah. Jumlah menyesuaikan kualitas grafis; yang jauh disembunyikan otomatis (Villager).
func _spawn_village_npcs(root: Node3D) -> void:
	var budget := Quality.village_npc_budget()
	var made := 0
	for d0 in NpcDefs.VILLAGE_NPCS:
		if made >= budget:
			break
		var d: Dictionary = (d0 as Dictionary).duplicate()
		d["village"] = true
		d["speed"] = d.get("speed", 1.0)
		var v := Villager.new()
		root.add_child(v)
		v.setup(d)
		villagers.append(v)
		made += 1
	_spawn_residents(root, maxi(0, budget - made))


## Satu penghuni per rumah: berdiri/mondar-mandir pendek di depan pintu. Rumah terdekat dari alun-alun diutamakan.
func _spawn_residents(root: Node3D, limit: int = -1) -> void:
	var houses: Array = []
	for b in world.buildings:
		if str(b.kind).begins_with("house_"):
			houses.append(b)
	houses.sort_custom(func(a, c): return a.global_position.length() < c.global_position.length())
	var rb := Quality.resident_budget() if limit < 0 else limit
	for i in mini(houses.size(), mini(rb, _res_list.size())):
		var b: Building = houses[i]
		var fwd := Vector3(sin(b.rotation.y), 0, cos(b.rotation.y))
		var box: AABB = b.world_aabb
		var half := absf(fwd.x) * box.size.x * 0.5 + absf(fwd.z) * box.size.z * 0.5
		var c := box.get_center()
		var base := Vector3(c.x, 0, c.z) + fwd * (half + 2.4)
		var lat := Vector3(fwd.z, 0, -fwd.x)
		var p1 := base + lat * 1.4
		var p2 := base - lat * 1.4
		var r: Array = _res_list[i]
		var d := {"skin": "skin_town%d" % (1 + i % 2), "height": 1.55 + 0.05 * float(i % 5), "speed": 0.8, "home": true, "village": map_id == "village",
			"route": [Vector2(p1.x, p1.z), Vector2(p2.x, p2.z)], "name": r[0], "title": r[1], "say": [r[2], "Kalau ada waktu, ngobrol saja denganku. Aku jarang ke mana-mana."]}
		var v := Villager.new()
		root.add_child(v)
		v.setup(d)
		villagers.append(v)


func _update_markers() -> void:
	if not npcs.has("guild_master"):
		return
	var m := ""
	if GameState.ready_quest_count() > 0:
		m = "?"
	elif GameState.quest_state("q_welcome") == "active":
		m = "!"
	(npcs["guild_master"] as Npc).set_marker(m)


func _on_state_changed(kind: String) -> void:
	match kind:
		"quest":
			_update_markers()
		"party":
			var lead := GameState.leader()
			if lead != _last_leader:
				_last_leader = lead
				player.set_character(lead)
		"settings":
			cam.apply_settings()
			daynight.apply_mode()
			Quality.apply(get_viewport(), daynight.sun, cam.cam, daynight.env)
			touch.layout()


# ---------------------------------------------------------------- interaksi
func _find_target() -> Dictionary:
	var pp := player.global_position
	var best := {}
	var best_r := 1.0
	for id in npcs:
		var n: Npc = npcs[id]
		var d := Vector2(pp.x - n.global_position.x, pp.z - n.global_position.z).length()
		var r := d / n.talk_radius
		if r < best_r:
			best_r = r
			best = {"kind": "npc", "npc": n, "prompt": "Bicara dengan %s" % n.display_name}
	for v in villagers:
		if not is_instance_valid(v) or not v.visible:
			continue
		var dv := Vector2(pp.x - v.global_position.x, pp.z - v.global_position.z).length()
		var rv: float = dv / v.talk_radius
		if rv < best_r:
			best_r = rv
			best = {"kind": "npc", "npc": v, "prompt": "Bicara dengan %s" % v.display_name}
	var its: Array = interior.interactions if interior != null else world.interactions + (explore.interactions() if explore != null else [])
	for it: Dictionary in its:
		var ip: Vector3 = it["pos"]
		var d2 := Vector2(pp.x - ip.x, pp.z - ip.z).length()
		var r2 := d2 / float(it["radius"])
		if r2 < best_r:
			best_r = r2
			best = {"kind": "obj", "action": it["action"], "prompt": it["prompt"], "id": it["id"], "pos": ip}
	return best


func _try_interact() -> void:
	if _house_busy:
		return
	if _target.is_empty() or not player.control_enabled or dialogue.is_open or host.is_open():
		return
	if _target["kind"] == "npc":
		_talk(_target["npc"])
	else:
		match _target["id"]:
			"portal", "gate":
				Sfx.play("portal")
		_run_action(_target["action"])


func _talk(n: Node3D) -> void:
	_talking = n
	n.look_at_node = player
	var d := n.global_position - player.global_position
	player.facing = atan2(d.x, d.z)
	player.control_enabled = false
	player.move_input = Vector2.ZERO
	touch.release_all()
	touch.visible = false
	cam.enabled = false
	cam.frame_begin(n)                            # kamera maju & memandang pemain + NPC dari samping, di atas kotak dialog
	hud.visible = false
	GameState.report_event("talk", n.npc_id)
	dialogue.start(n.display_name, n.title, n.dialogue() if n is Villager else NpcDefs.dialogue(n.npc_id))


func _on_dialogue_closed() -> void:
	cam.frame_end()
	if _talking:
		_talking.look_at_node = null
		_talking = null
	if not host.is_open():
		_set_ui_modal(false)


func _run_action(action: String) -> void:
	if action.begins_with("house:"):
		_enter_house(action.substr(6))
		return
	if action == "house_exit":
		_exit_house()
		return
	if action.begins_with("chest:"):
		_open_chest(action.substr(6))
		return
	match action:
		"quests": host.open("quest")
		"adventure": host.open("stage_select", {"adventure": true})
		"party": host.open("party")
		"gacha": host.open("gacha")
		"character": host.open("character")
		"equipment": host.open("equipment")
		"smith": host.open("smith")
		"shop:weapon": host.open("shop", {"tab": "weapon"})
		"shop:item": host.open("shop", {"tab": "item"})
		"shop:sell": host.open("shop", {"tab": "sell"})
		"map": _open_map()
		"go_village":
			Flow.go_village()
		"go_town":
			Flow.go_town()
		_: push_warning("Aksi dialog tidak dikenal: %s" % action)


# ---------------------------------------------------------------- eksplorasi
func _open_chest(id: String) -> void:
	var r := Explore.open_chest(id)
	if r.is_empty():
		return
	Sfx.play("chest")
	Flow.toast("%s dibuka!  %s" % [Explore.chest_def(id)["name"], Explore.reward_text(r)], 3.5)
	GameState.report_event("chest", id)


## Pindahkan pemain ke titik teleport yang sudah terbuka.
func teleport_to(id: String) -> bool:
	if map_id == "village" or not Explore.is_discovered(id):
		return false
	for w: Dictionary in Explore.WAYPOINTS:
		if w["id"] == id:
			var p: Vector2 = w["pos"]
			player.global_position = Vector3(p.x, 0.1, p.y + 2.2)
			player.velocity = Vector3.ZERO
			cam.snap_to_target()
			Sfx.play("portal")
			Flow.toast("Teleport: %s" % w["name"], 1.8)
			return true
	return false


# ---------------------------------------------------------------- jalan raya penghubung Aurelia <-> Desa Fajar
## Tiba dari seberang: pemain diletakkan di ujung jalan raya menghadap ke arah kota/desa; kamera tepat di belakangnya.
func _place_for_arrival(arrival: String) -> void:
	var to_village := arrival == "to_village"
	var pos: Vector3 = VillageLayout.ROAD_ARRIVE if to_village else LobbyLayout.ROAD_ARRIVE
	var f: float = 0.0 if to_village else PI                 # Desa: berjalan ke +Z; Kota: berjalan ke -Z
	player.global_position = pos
	player.facing = f
	cam.yaw = f + PI
	cam.cine_set(f + PI, 24.0, cam.distance * 1.25, 62.0)     # mulai agak lebar, lalu mendekat saat berjalan


func _arrive_walk(arrival: String) -> void:
	var to_village := arrival == "to_village"
	var walk: float = VillageLayout.ROAD_ARRIVE_WALK if to_village else LobbyLayout.ROAD_ARRIVE_WALK
	var dir := Vector3(0, 0, 1) if to_village else Vector3(0, 0, -1)
	_crossing = true
	_cross_grace = 4.0
	player.control_enabled = false
	player.move_input = Vector2.ZERO
	while Flow.is_busy():                                    # tunggu layar memuat selesai
		await get_tree().process_frame
	var secs: float = walk / 4.2
	cam.cine_to(cam.yaw, 17.0, 11.0, 55.0, secs)
	player.auto_dir = dir
	player.auto_speed = 4.2
	await get_tree().create_timer(secs).timeout
	player.auto_dir = Vector3.ZERO
	player.auto_speed = 0.0
	_crossing = false
	_set_ui_modal(false)
	await StoryPlayer.play(self, "road_to_village" if to_village else "road_to_town")     # sekali saja per arah (status "sudah dibaca" otomatis)
	await _opening_sequence()


## Melewati ujung jalan raya: berjalan terus, kamera menjauh, layar memudar, lalu peta seberang dimuat.
func _cross_road(to_village: bool) -> void:
	if _crossing:
		return
	_crossing = true
	player.control_enabled = false
	player.move_input = Vector2.ZERO
	player.auto_dir = Vector3(0, 0, 1) if to_village else Vector3(0, 0, -1)
	player.auto_speed = 4.2
	cam.cine_to(cam.yaw + 0.5, 12.0, cam.distance * 1.5, 66.0, 1.6)
	await get_tree().create_timer(1.1).timeout
	await _fade_to(1.0, 0.5)
	if to_village:
		Flow.go_village_road()
	else:
		Flow.go_town_road()


func _check_road_trigger() -> void:
	if _crossing or interior != null or _house_busy:
		return
	var z := player.global_position.z
	if map_id == "village":
		if z < VillageLayout.ROAD_TRIGGER_Z and absf(player.global_position.x) < VillageLayout.ROAD_HALF_W:
			_cross_road(false)
	elif z > LobbyLayout.ROAD_TRIGGER_Z and absf(player.global_position.x) < LobbyLayout.ROAD_HALF_W:
		_cross_road(true)


# ---------------------------------------------------------------- loop
func _physics_process(delta: float) -> void:
	player.cam_yaw = cam.yaw
	_cross_grace = maxf(0.0, _cross_grace - delta)
	if _cross_grace <= 0.0:
		_check_road_trigger()
	if player.control_enabled:
		player.move_input = InputSetup.keyboard_vector()
		if Input.is_action_pressed("attack"):
			player.do_attack()
		if Input.is_action_just_pressed("skill"):
			player.do_skill()
		if Input.is_action_just_pressed("dodge"):
			player.do_dodge()
		if Input.is_action_just_pressed("interact"):
			_try_interact()
	elif dialogue.is_open and (Input.is_action_just_pressed("interact") or Input.is_action_just_pressed("attack")):
		dialogue.advance()
	_target = _find_target() if player.control_enabled else {}
	hud.set_prompt(str(_target.get("prompt", "")))
	touch.interact_ready = not _target.is_empty()
	touch.set_cooldown("skill", player.skill_cd, player.skill_cd_max)
	touch.set_cooldown("dodge", player.dodge_cd, 0.75)
	if interior != null:
		cam.yaw = 0.0                                  # di dalam rumah kamera tetap menghadap ke dalam (dinding depan rendah)
	_hp_timer -= delta
	if _hp_timer <= 0.0:
		_hp_timer = 0.15
		hud.set_hp(player.hp, player.max_hp)
		hud.set_time_text(daynight.hour_text())
		hud.set_fps(Engine.get_frames_per_second())
		cam.blocked_rects = hud.blocked_rects() + touch.blocked_rects() + dialogue.blocked_rects()


# ---------------------------------------------------------------- rumah (pintu bisa dibuka, ada isinya)
func _fade_to(a: float, secs: float) -> void:
	if _fade_rect == null:
		_fade_rect = ColorRect.new()
		_fade_rect.color = Color(0.02, 0.02, 0.05, 1.0)
		_fade_rect.modulate.a = 0.0
		_fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_fade_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
		ui.add_child(_fade_rect)
	var t := create_tween()
	t.tween_property(_fade_rect, "modulate:a", a, secs)
	await t.finished


## Jenis permukaan di bawah kaki (untuk suara langkah): lantai kayu di dalam rumah, batu di jalan/alun-alun, selain itu rumput.
func _surface_at(p: Vector3) -> String:
	if interior != null:
		return "wood"
	var q := Vector2(p.x, p.z)
	if (q - world.plaza_center()).length() < world.plaza_radius() + 1.0 or world.dist_to_roads(q) < 0.3:
		return "stone"
	return "grass"


## Daun pintu sementara yang berayun terbuka di depan pintu rumah (dibuang setelahnya; tidak menambah beban saat idle).
func _swing_door(b: Building) -> void:
	var hinge := Node3D.new()
	b.add_child(hinge)
	hinge.position = b.door_pos + Vector3(-b.door_w * 0.5, 0.0, 0.07)
	var leaf := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(b.door_w - 0.08, b.door_h - 0.08, 0.07)
	leaf.mesh = bm
	leaf.position = Vector3(b.door_w * 0.5, b.door_h * 0.5, 0)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.58, 0.38, 0.22)
	mat.roughness = 0.9
	leaf.material_override = mat
	hinge.add_child(leaf)
	var t := create_tween()
	t.tween_property(hinge, "rotation:y", deg_to_rad(105.0), 0.4).set_trans(Tween.TRANS_SINE)
	await t.finished
	await get_tree().create_timer(0.1).timeout
	hinge.queue_free()


func _set_outdoor(on: bool) -> void:
	world.visible = on
	var amb := get_node_or_null("Ambient")
	if amb is Node3D:
		amb.visible = on
	if on:
		for n in _house_hidden:
			if is_instance_valid(n):
				n.visible = true
				n.process_mode = Node.PROCESS_MODE_INHERIT
		_house_hidden.clear()
	else:
		_house_hidden.clear()
		for id in npcs:
			_house_hidden.append(npcs[id])
		for v in villagers:
			_house_hidden.append(v)
		for n in _house_hidden:
			n.visible = false
			n.process_mode = Node.PROCESS_MODE_DISABLED
	if hud.minimap != null:
		hud.minimap.visible = on


func _enter_house(bname: String) -> void:
	if interior != null or _house_busy:
		return
	var b: Building = world.get_node_or_null(bname) as Building
	if b == null or not b.has_door:
		return
	_house_busy = true
	_talking = null
	player.control_enabled = false
	player.move_input = Vector2.ZERO
	touch.release_all()
	player.facing = b.rotation.y + PI                         # menghadap pintu
	await _swing_door(b)
	await _fade_to(1.0, 0.22)
	_house_b = b
	_house_saved = {"pos": player.global_position, "yaw": cam.yaw, "pitch": cam.pitch, "dist": cam.distance,
		"dmax": cam.max_distance, "dmin": cam.min_distance, "pmin": cam.min_pitch}
	interior = HouseInterior.new()
	cam.lead_enabled = false
	cam.kick_enabled = false
	interior.name = "Interior"
	add_child(interior)
	interior.build(b.kind, b.seed_value, b.wall_color, b.roof_color)
	_set_outdoor(false)
	player.global_position = interior.spawn
	player.facing = PI
	cam.yaw = 0.0
	cam.pitch = deg_to_rad(52.0)
	cam.min_pitch = deg_to_rad(40.0)
	cam.distance = 9.0
	cam.min_distance = 7.0
	cam.max_distance = 11.0
	cam.snap_to_target()
	# penghuni rumah ini menyambut di dalam
	var idx := _house_index(b)
	if idx >= 0 and idx < _res_list.size():
		var r: Array = _res_list[idx]
		var c := interior.occupant_pos
		var d := {"skin": "skin_town%d" % (1 + idx % 2), "height": 1.55 + 0.05 * float(idx % 5), "speed": 0.7, "home": true,
			"route": [Vector2(c.x - 1.3, c.y), Vector2(c.x + 1.3, c.y)], "name": r[0], "title": r[1],
			"say": [r[2], "Silakan duduk dan beristirahat. Rumah ini selalu terbuka untuk petualang."]}
		_house_occupant = Villager.new()
		add_child(_house_occupant)
		_house_occupant.setup(d)
		villagers.append(_house_occupant)
	await _fade_to(0.0, 0.25)
	player.control_enabled = not dialogue.is_open
	_house_busy = false


func _exit_house() -> void:
	if interior == null or _house_busy:
		return
	_house_busy = true
	player.control_enabled = false
	player.move_input = Vector2.ZERO
	touch.release_all()
	await _fade_to(1.0, 0.22)
	if _house_occupant != null:
		villagers.erase(_house_occupant)
		_house_occupant.queue_free()
		_house_occupant = null
	interior.queue_free()
	interior = null
	cam.lead_enabled = true
	cam.kick_enabled = true
	_set_outdoor(true)
	var b := _house_b
	var fwd := Vector3(sin(b.rotation.y), 0, cos(b.rotation.y))
	player.global_position = b.to_global(b.door_pos + Vector3(0, -0.4, 1.7))
	player.global_position.y = 0.1
	player.facing = b.rotation.y
	cam.yaw = _house_saved["yaw"]
	cam.pitch = _house_saved["pitch"]
	cam.distance = _house_saved["dist"]
	cam.max_distance = _house_saved["dmax"]
	cam.min_distance = _house_saved["dmin"]
	cam.min_pitch = _house_saved["pmin"]
	cam.snap_to_target()
	_house_b = null
	await _fade_to(0.0, 0.25)
	player.control_enabled = not dialogue.is_open
	_house_busy = false


## Urutan rumah (dekat alun-alun lebih dulu) = indeks penghuninya; sama dengan pembagian di _spawn_residents.
func _house_index(b: Building) -> int:
	var houses: Array = []
	for x in world.buildings:
		if str(x.kind).begins_with("house_"):
			houses.append(x)
	houses.sort_custom(func(a, c): return a.global_position.length() < c.global_position.length())
	return houses.find(b)


# ---------------------------------------------------------------- bot uji
## Saat masuk lobi: buka panel hadiah login bila ada yang bisa diambil; kalau tidak, buka panel Event bila ada event aktif yang belum dilihat.
## (Tidak dijalankan saat uji bot otomatis.)
func _auto_login_gift() -> void:
	if _arg("bot") != "" and _arg("autogift") == "":
		return
	var which := ""
	if GameState.login_claimable():
		which = "login"
	elif GameState.unseen_event_count() > 0:
		which = "event"
	if which == "":
		return
	await get_tree().create_timer(0.8).timeout
	if is_inside_tree() and not host.is_open() and not dialogue.is_open:
		host.open(which)


func _arg(key: String, default: String = "") -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % key):
			return a.substr(key.length() + 3)
	return default


func _shot(name: String) -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	var dir := _arg("shots", "/tmp")
	get_viewport().get_texture().get_image().save_png("%s/%s.png" % [dir, name])
	print("shot ", name)


func _check_bot() -> void:
	if _arg("bot") == "":
		return
	call_deferred("_bot_run")


func _bot_run() -> void:
	var script_path := "res://tools/" + _arg("botscript", "lobby_bot") + ".gd"
	if ResourceLoader.exists(script_path):
		var bot: Object = (load(script_path) as GDScript).new()
		await bot.run(self)
	get_tree().quit()
