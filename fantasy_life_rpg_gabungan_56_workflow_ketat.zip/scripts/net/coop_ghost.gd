class_name CoopGhost
extends Node3D
## Wujud pemain lain di dunia kita (co-op). Hanya visual: posisi/hadap/animasi diisi dari jaringan. Untuk host juga jadi sasaran musuh (grup "ghost").

var peer_id := 0
var char_id := "ren"
var pname := "Pemain"
var rig: CharacterRig
var dead := false
var all_down := false
var hit_radius := 0.45
var hp := 100
var max_hp := 100
var _tp := Vector3.ZERO
var _tyaw := 0.0
var _move := 0.0
var _has := false
var _label: Label3D
var _atk := 0
var warp_t := 0.0                  # >0: hantu menyusul sangat cepat ke posisi terbaru (teleport lawan), tanpa menghilang
var form := false                  # wujud Pedang Petir Kiriel aktif (dari status pemain)
var immune := false                # kebal total (selubung petir)
var _aura: MeshInstance3D


func setup(p_peer: int, p_char: String, p_name: String) -> void:
	peer_id = p_peer
	pname = p_name
	add_to_group("ghost")
	_build(p_char)
	_label = Label3D.new()
	_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_label.no_depth_test = true
	_label.pixel_size = 0.0085
	_label.font_size = 40
	_label.outline_size = 12
	_label.modulate = Color(0.55, 0.95, 1.0)
	_label.position = Vector3(0, 2.35, 0)
	add_child(_label)
	_refresh_label()


func _build(id: String) -> void:
	char_id = id
	var data := Data.character(id)
	if data == null:
		data = Data.character("ren")
	if rig != null:
		rig.queue_free()
	form = false
	immune = false
	_aura = null
	rig = CharacterRig.new()
	rig.name = "Rig"
	add_child(rig)
	var skin: Texture2D = load(data.skin_path)
	rig.setup(1.8, skin, true, true)
	rig.set_weapon_class(data.anim_style if data.anim_style != "" else data.weapon_class)
	rig.set_style(data.id)
	rig.set_skill_kind(data.skill_kind)
	rig.set_ult_kind(data.ult_kind)
	CharacterLooks.apply_hero(rig, data.id)


func _refresh_label() -> void:
	if _label == null:
		return
	var pct := int(round(100.0 * float(hp) / maxf(float(max_hp), 1.0)))
	_label.text = "%s  %s" % [pname, ("Pingsan" if dead else "%d%%" % pct)]


func apply(p: Vector3, yaw: float, move01: float, p_char: String, p_hp: int, p_max: int, p_dead: bool, p_all_down: bool) -> void:
	_tp = p
	_tyaw = yaw
	_move = move01
	if not _has:
		_has = true
		global_position = p
	if p_char != char_id:
		_build(p_char)
	hp = p_hp
	max_hp = p_max
	all_down = p_all_down
	if p_dead != dead:
		dead = p_dead
		if dead:
			rig.play_action("death")
		else:
			rig.revive()
	_refresh_label()


## Aksi dari jaringan: "jenis" atau "jenis:langkah:arah" (lihat CoopSync._on_my_action). Efeknya dikerjakan Stage.ghost_fx -> GhostFx
## (kombo tiap karakter, semua skill, ULTI per ult_kind, menghindar) mengikuti animasi.
func play(kind_msg: String) -> void:
	if rig == null or dead:
		return
	var parts := kind_msg.split(":")
	var kind := parts[0]
	var idx := int(parts[1]) if parts.size() > 1 else -1
	var has_yaw := parts.size() > 2
	var yaw := float(parts[2]) if has_yaw else _tyaw
	if has_yaw:                                          # hadapkan badan ke arah serang penyerang sebelum animasi mulai
		_tyaw = yaw
		rig.rotation.y = yaw
	if kind == "attack":
		if idx < 0:                                      # pengirim lama tanpa nomor langkah: putar sendiri
			_atk += 1
			idx = _atk - 1
		else:
			_atk = idx + 1
	var st := get_parent()
	if kind in ["attack", "skill", "ult", "dodge"] and st != null and st.has_method("ghost_fx"):
		st.ghost_fx(self, kind, maxi(idx, 0), yaw)
	elif kind == "hurt":
		rig.flash(Color(1, 0.3, 0.3))
		rig.play_action("hurt")


## Wujud Pedang Petir Kiriel di hantu: pedang di tangan + gaya pedang (sama seperti Stage._enter_blade_form / _exit_blade_form).
func set_form(on: bool) -> void:
	if on == form or rig == null:
		return
	form = on
	var data := Data.character(char_id)
	if data == null:
		return
	if on:
		rig.set_weapon_class("sword")
		rig.set_style("ren")
		CharacterLooks.equip_storm_sword(rig)
		var st := get_parent()
		if st != null and st.get("fx_root") != null:
			StormFx.strike(st.fx_root, global_position, Color(1.0, 0.9, 0.3))
	else:
		rig.set_weapon_class(data.anim_style if data.anim_style != "" else data.weapon_class)
		rig.set_style(data.id)
		CharacterLooks.remove_storm_sword(rig)


## Selubung petir berdenyut saat lawan kebal total, supaya jelas kenapa serangan kita tidak melukainya.
func set_immune(on: bool) -> void:
	if on == immune:
		return
	immune = on
	if on:
		var mi := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 1.15
		sm.height = 2.3
		sm.radial_segments = 12
		sm.rings = 6
		mi.mesh = sm
		mi.material_override = Fx._unshaded(Color(1.0, 0.9, 0.3, 0.22), true)
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.position = Vector3(0, 1.0, 0)
		add_child(mi)
		_aura = mi
		var tw := mi.create_tween().set_loops()
		tw.tween_property(mi, "scale", Vector3.ONE * 1.1, 0.18)
		tw.tween_property(mi, "scale", Vector3.ONE * 0.92, 0.18)
	elif _aura != null and is_instance_valid(_aura):
		_aura.queue_free()
		_aura = null


func _process(delta: float) -> void:
	if not _has or rig == null:
		return
	warp_t = maxf(warp_t - delta, 0.0)
	var k := 1.0 - exp(-(45.0 if warp_t > 0.0 else 12.0) * delta)
	global_position = global_position.lerp(_tp, k)
	rig.rotation.y = lerp_angle(rig.rotation.y, _tyaw, k)
	rig.set_move(0.0 if dead else _move, 1.0)
