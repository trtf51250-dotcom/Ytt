class_name Projectile
extends Node3D
## Peluru: bola sihir / panah (milik pemain, menarget grup "enemies") atau batu (milik musuh, menarget grup "player").
## Bergerak lurus; mengenai target pertama dalam hit_radius (bidang XZ) lalu memanggil on_hit(target).

var velocity := Vector3.ZERO
var life := 1.0
var hit_radius := 0.5
var target_group := "enemies"
var include_ghosts := false         # PVP: ikut mengenai CoopGhost
var on_hit: Callable
var pierce := false
var _hit: Array = []


static func make(kind: String, color: Color) -> Projectile:
	var p := Projectile.new()
	var mi := MeshInstance3D.new()
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = color
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	match kind:
		"arrow":
			var cm := CylinderMesh.new()
			cm.top_radius = 0.03
			cm.bottom_radius = 0.03
			cm.height = 0.9
			cm.radial_segments = 5
			mi.mesh = cm
			mi.rotation.x = PI / 2.0
			p.hit_radius = 0.45
		"rock":
			var sm := SphereMesh.new()
			sm.radius = 0.45
			sm.height = 0.8
			sm.radial_segments = 8
			sm.rings = 4
			mi.mesh = sm
			mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
			mat.roughness = 1.0
			p.hit_radius = 0.7
		_:
			var sm2 := SphereMesh.new()
			sm2.radius = 0.3
			sm2.height = 0.6
			sm2.radial_segments = 10
			sm2.rings = 5
			mi.mesh = sm2
			p.hit_radius = 0.6
	mi.material_override = mat
	p.add_child(mi)
	if kind == "bolt":
		var l := OmniLight3D.new()
		l.light_color = color
		l.light_energy = 1.2
		l.omni_range = 4.0
		p.add_child(l)
	return p


func launch(from: Vector3, dir: Vector3, speed: float, range_m: float) -> void:
	global_position = from
	var d := dir
	d.y = 0.0
	d = d.normalized()
	velocity = d * speed
	life = range_m / maxf(speed, 0.1)
	look_at(from + d, Vector3.UP)


func _physics_process(delta: float) -> void:
	var from := global_position
	global_position += velocity * delta
	life -= delta
	# rintangan tinggi (pilar, pohon, dinding, bangunan) menahan peluru; rintangan rendah (layer 16) dilewati
	var rq := PhysicsRayQueryParameters3D.create(from, global_position, 1)
	if not get_world_3d().direct_space_state.intersect_ray(rq).is_empty():
		Fx.burst(get_parent(), global_position, Color(1, 1, 1), 5, 2.5, 0.1)
		queue_free()
		return
	if life <= 0.0:
		queue_free()
		return
	var cands: Array = get_tree().get_nodes_in_group(target_group)       # salinan baru tiap panggilan: aman dimodifikasi
	if target_group == "player" or include_ghosts:                       # co-op: pemain lain (host) / PVP: pemain lain
		var ghosts: Array = get_tree().get_nodes_in_group("ghost")
		if not ghosts.is_empty():                                        # PERF: tanpa co-op tak ada alokasi array gabungan tiap frame
			cands.append_array(ghosts)
	for t: Node in cands:
		if not (t is Node3D) or t in _hit:
			continue
		# PERF: musuh (kasus terbanyak) diakses langsung; pencarian properti lewat string ("dead" in t) hanya untuk pemain/hantu.
		var tr := 0.45
		var en := t as Enemy
		if en != null:
			if en.dead:
				continue
			tr = en.hit_radius
		else:
			if "dead" in t and t.dead:
				continue
			if "hit_radius" in t:
				tr = t.hit_radius
		var tp := (t as Node3D).global_position
		var d := Vector2(tp.x - global_position.x, tp.z - global_position.z).length()
		if d < hit_radius + tr:
			_hit.append(t)
			if on_hit.is_valid():
				on_hit.call(t)
			if not pierce:
				Fx.burst(get_parent(), global_position, Color(1, 1, 1), 6, 3.0, 0.1)
				queue_free()
				return
