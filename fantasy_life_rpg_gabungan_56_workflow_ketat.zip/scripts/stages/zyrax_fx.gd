class_name ZyraxFx
extends RefCounted
## Efek khas Zyrax (★6 BOM): kubus Void bermata X raksasa yang jatuh dari langit, sayap bayangan, retakan & pilar Void.
## Dipakai Stage (pemain sendiri) dan GhostFx (lawan) lewat fungsi yang sama, jadi kedua sisi melihat hal yang sama.
## Semua dibangun dari kotak sederhana + bahan tak berbayang (murah untuk HP); jumlah node kecil.

const VOID := Color(0.5, 0.2, 0.95)
const CYAN := Color(0.25, 0.85, 1.0)
const RED := Color(0.95, 0.15, 0.32)
const INK := Color(0.05, 0.04, 0.1)


static func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.position = pos
	parent.add_child(mi)
	return mi


## Kubus Void: badan gelap, bingkai ungu menyala, mata X cyan di keempat sisi (sama seperti bom melayang Zyrax, tapi besar).
static func cube(size: float, tint: Color) -> Node3D:
	var root := Node3D.new()
	root.name = "VoidCube"
	var body := Fx._unshaded(Color(INK.r, INK.g, INK.b, 1.0), false)
	var edge := Fx._unshaded(Color(tint.r, tint.g, tint.b, 0.9), true)
	var eye := Fx._unshaded(Color(CYAN.r, CYAN.g, CYAN.b, 0.95), true)
	_box(root, Vector3.ZERO, Vector3.ONE * size, body)
	var h := size * 0.5
	for sx in [-1.0, 1.0]:                                                  # bingkai tepi menyala
		for sy in [-1.0, 1.0]:
			_box(root, Vector3(sx * h, sy * h, 0), Vector3(size * 0.06, size * 0.06, size * 1.02), edge)
			_box(root, Vector3(sx * h, 0, sy * h), Vector3(size * 0.06, size * 1.02, size * 0.06), edge)
			_box(root, Vector3(0, sx * h, sy * h), Vector3(size * 1.02, size * 0.06, size * 0.06), edge)
	for face in 4:                                                          # mata X di tiap sisi samping
		var pivot := Node3D.new()
		pivot.rotation.y = PI * 0.5 * float(face)
		root.add_child(pivot)
		for ex in [-0.2, 0.2]:
			for rot in [PI * 0.25, -PI * 0.25]:
				var bar := _box(pivot, Vector3(size * ex, size * 0.08, h + size * 0.01), Vector3(size * 0.2, size * 0.045, size * 0.02), eye)
				bar.rotation.z = rot
	return root


## Kubus raksasa jatuh ke `pos` dalam `fall` detik (dengan lingkaran peringatan), lalu meledak: cincin, kilat X, retakan, pilar Void.
## dmg > 0 = ledakan melukai (sisi penyerang); dmg = 0 = visual saja (lawan). Berjalan sendiri (tidak perlu di-await).
static func cube_drop(s: Stage, pos: Vector3, size: float, height: float, fall: float, tint: Color, radius: float, dmg: float = 0.0, kb: float = 6.0) -> void:
	var ground := Vector3(pos.x, 0.0, pos.z)
	var c := cube(size, tint)
	s.fx_root.add_child(c)
	c.global_position = ground + Vector3(0, height, 0)
	var tele: MeshInstance3D = Fx.telegraph(s.fx_root, ground, radius, fall, tint)
	var tw := c.create_tween().set_parallel(true)
	tw.tween_property(c, "global_position:y", size * 0.5, fall).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.tween_property(c, "rotation:y", PI * 1.5, fall)
	await s.get_tree().create_timer(fall).timeout
	if is_instance_valid(c):
		c.queue_free()
	if is_instance_valid(tele):
		tele.queue_free()
	if not is_instance_valid(s) or s.state == Stage.S.ENDED:
		return
	impact(s, ground, radius, tint, size > 1.0)
	ComboRunner.explode(s, ground, radius, dmg, kb, tint, true)


## Ledakan Void (visual): pilar ungu, retakan tanah, gelombang kejut berlapis.
static func impact(s: Stage, ground: Vector3, radius: float, tint: Color, big: bool) -> void:
	UltFx.pillar(s.fx_root, ground, tint, 12.0 if big else 8.0, 1.8 if big else 1.2, 0.6)
	CharFx.cracks(s.fx_root, ground, radius * 0.9, CYAN, 0.7, 9 if big else 6)
	Fx.ring(s.fx_root, ground + Vector3(0, 0.1, 0), radius * 1.15, RED, 0.5)
	CharFx.puff(s.fx_root, ground + Vector3(0, 0.6, 0), INK.lightened(0.15), 10, 5.0, 0.55, Vector3.UP, 150.0, 0.5, 0.8, "sphere", false)


## Skill Ranjau Void: 8 bom melingkar jauh di sekitar sasaran + kubus Void raksasa jatuh di tengah. Satu musuh di tengah kena semuanya (~1,06 x dmg_total).
## dmg_total <= 0 = visual saja (efek lawan).
static func bomb_field(s: Stage, cd: CharacterData, origin: Vector3, fwd: Vector3, pos: Vector3, dmg_total: float, col: Color) -> void:
	var ctr := ComboRunner.bomb_target(s, pos, fwd, cd.skill_range * 1.3, cd.skill_range * 0.7)
	var ring_r := cd.skill_range * 0.4
	var blast := cd.skill_range * 0.42
	var n := 8
	for i in n:
		var a := TAU * float(i) / float(n)
		ComboRunner.throw_bomb(s, cd, origin + fwd * 0.4, ctr + Vector3(sin(a), 0, cos(a)) * ring_r, dmg_total * 0.07, blast, 0.45 + 0.09 * float(i), 6.0, col, false)
	cube_drop(s, ctr, 1.5, 15.0, 0.7, col, cd.skill_range * 0.72, dmg_total * 0.5, 9.0)


## Sayap bayangan: dua sayap berbilah piksel (hitam, tepi merah/cyan menyala) mengembang di punggung selama `life` detik lalu mengecil.
static func wings(rig: Node3D, tint: Color, life: float = 3.2) -> void:
	if rig == null or not is_instance_valid(rig):
		return
	var old := rig.get_node_or_null("VoidWings")
	if old != null:
		old.queue_free()
	var root := Node3D.new()
	root.name = "VoidWings"
	root.position = Vector3(0, 1.35, -0.2)
	rig.add_child(root)
	var dark := Fx._unshaded(Color(0.07, 0.04, 0.14, 0.95), false)
	var glow_a := Fx._unshaded(Color(RED.r, RED.g, RED.b, 0.9), true)
	var glow_b := Fx._unshaded(Color(CYAN.r, CYAN.g, CYAN.b, 0.9), true)
	for sx in [-1.0, 1.0]:
		var wing := Node3D.new()
		wing.rotation.y = float(sx) * deg_to_rad(28.0)
		root.add_child(wing)
		for i in 6:
			var piv := Node3D.new()
			piv.rotation.z = -float(sx) * deg_to_rad(18.0 + float(i) * 17.0)
			wing.add_child(piv)
			var len := 2.3 - float(i) * 0.22
			_box(piv, Vector3(0, len * 0.5 + 0.1, 0), Vector3(0.2, len, 0.05), dark)
			_box(piv, Vector3(0.0, len * 0.5 + 0.1, 0.03), Vector3(0.05, len * 0.96, 0.03), glow_a if i % 2 == 0 else glow_b)
	root.scale = Vector3(0.05, 0.05, 0.05)
	var tw := root.create_tween()
	tw.tween_property(root, "scale", Vector3.ONE, 0.45).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_interval(maxf(life - 0.9, 0.1))
	tw.tween_property(root, "scale", Vector3(0.05, 0.05, 0.05), 0.45)
	tw.tween_callback(root.queue_free)
	var fl := root.create_tween().set_loops()                              # kepak pelan
	fl.tween_property(root, "rotation:x", deg_to_rad(-8.0), 0.35)
	fl.tween_property(root, "rotation:x", deg_to_rad(6.0), 0.35)


## Lambang X di lantai (motif mata X Zyrax): dua balok pipih bersilang, membesar cepat lalu memudar. `yaw0` memutar seluruh lambang.
static func xglyph(parent: Node3D, pos: Vector3, length: float, width: float, tint: Color, life: float, core: Color = Color(1, 1, 1), yaw0: float = 0.0) -> void:
	var root := Node3D.new()
	parent.add_child(root)
	root.global_position = Vector3(pos.x, 0.09, pos.z)
	root.rotation.y = yaw0
	var m := Fx._unshaded(Color(tint.r, tint.g, tint.b, 0.85), true)
	var mc := Fx._unshaded(Color(core.r, core.g, core.b, 0.9), true)
	for k in 2:
		var arm := Node3D.new()
		arm.rotation.y = PI * 0.25 + PI * 0.5 * float(k)
		root.add_child(arm)
		_box(arm, Vector3.ZERO, Vector3(width, 0.03, length), m)
		_box(arm, Vector3(0, 0.01, 0), Vector3(width * 0.35, 0.03, length * 0.96), mc)
	root.scale = Vector3(0.15, 1.0, 0.15)
	var tw := root.create_tween().set_parallel(true)
	tw.tween_property(root, "scale", Vector3.ONE, life * 0.3).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(m, "albedo_color:a", 0.0, life * 0.6).set_delay(life * 0.4)
	tw.tween_property(mc, "albedo_color:a", 0.0, life * 0.5).set_delay(life * 0.35)
	tw.chain().tween_callback(root.queue_free)


## Lubang hitam Void: inti hitam pekat, selubung ungu menyala, dan cakram cyan berputar (bukan bola api/kubus). Skala awal = `radius`.
static func orb(radius: float, tint: Color) -> Node3D:
	var root := Node3D.new()
	root.name = "VoidOrb"
	root.add_to_group("void_orbs")
	var core := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 1.0
	sm.height = 2.0
	sm.radial_segments = 14
	sm.rings = 7
	core.mesh = sm
	core.material_override = Fx._unshaded(Color(0.02, 0.0, 0.05, 1.0), false)
	core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(core)
	var shell := MeshInstance3D.new()
	shell.mesh = sm
	shell.scale = Vector3.ONE * 1.22
	shell.material_override = Fx._unshaded(Color(tint.r, tint.g, tint.b, 0.3), true)
	shell.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(shell)
	var disc := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 1.55
	tm.outer_radius = 1.85
	tm.rings = 20
	tm.ring_segments = 6
	disc.mesh = tm
	disc.scale = Vector3(1.0, 0.18, 1.0)
	disc.rotation.x = deg_to_rad(18.0)
	disc.material_override = Fx._unshaded(Color(CYAN.r, CYAN.g, CYAN.b, 0.85), true)
	disc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(disc)
	var sp := disc.create_tween().set_loops()
	sp.tween_property(disc, "rotation:y", TAU, 1.1).from(0.0)
	root.scale = Vector3.ONE * radius
	return root


## Pengisian ULTI: lubang hitam terbentuk di atas pemain, serpihan kubus tersedot masuk, lambang X menyala di bawah kaki.
## Lubang hitam bertahan sampai penutup (ULT_Finale menyerapnya); bila ULTI terputus ia hilang sendiri.
static func charge(s: Stage, c: Vector3, rng: float, tint: Color) -> void:
	var pos := c + Vector3(0, 3.8, 0)
	var o := orb(0.2, tint)
	s.fx_root.add_child(o)
	o.global_position = pos
	var tw := o.create_tween()
	tw.tween_property(o, "scale", Vector3.ONE * 1.3, 0.6).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_interval(2.6)
	tw.tween_callback(o.queue_free)
	xglyph(s.fx_root, c, 6.0, 0.4, tint, 1.0)
	for i in 10:                                                              # serpihan kubus tersedot ke lubang hitam
		var a := TAU * float(i) / 10.0 + randf() * 0.5
		var start := pos + Vector3(sin(a) * 3.6, randf_range(-1.8, 1.0), cos(a) * 3.6)
		var chip := _box(s.fx_root, Vector3.ZERO, Vector3.ONE * 0.2, Fx._unshaded(Color(tint.r, tint.g, tint.b, 0.9), true))
		chip.global_position = start
		var ct := chip.create_tween().set_parallel(true)
		ct.tween_property(chip, "global_position", pos, 0.55).set_delay(0.04 * float(i)).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
		ct.tween_property(chip, "rotation", Vector3(PI, PI, 0), 0.55).set_delay(0.04 * float(i))
		ct.chain().tween_callback(chip.queue_free)


## Sambaran ULTI ke-i "Ranjau X Void": lambang X menyala di lantai bawah sasaran, kubus kecil bermata X muncul dari tanah lalu meledak
## (balok X menyapu lantai, serpihan piksel). Meledak tepat saat damage diterapkan (0,18 dtk). Visual saja; damage di Stage._ult_cast.
static func strike(s: Stage, p: Vector3, tint: Color, radius: float) -> void:
	var g := Vector3(p.x, 0.0, p.z)
	xglyph(s.fx_root, g, radius * 1.5, 0.35, tint, 0.5)
	var cb := cube(0.55, tint)
	s.fx_root.add_child(cb)
	cb.global_position = g + Vector3(0, -0.4, 0)
	var tw := cb.create_tween().set_parallel(true)
	tw.tween_property(cb, "global_position:y", 1.1, 0.17).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(cb, "rotation:y", PI, 0.18)
	await s.get_tree().create_timer(0.18).timeout
	if is_instance_valid(cb):
		cb.queue_free()
	if not is_instance_valid(s) or s.state == Stage.S.ENDED:
		return
	xglyph(s.fx_root, g, radius * 2.4, 0.9, CYAN, 0.45, Color(1, 1, 1), PI * 0.125)
	Fx.ring(s.fx_root, g + Vector3(0, 0.1, 0), radius, tint, 0.4)
	CharFx.x_flash(s.fx_root, g + Vector3(0, 1.0, 0), Color(1, 1, 1), radius * 0.8, 0.18)
	CharFx.puff(s.fx_root, g + Vector3(0, 0.5, 0), tint.lightened(0.2), 12, 7.0, 0.22, Vector3.UP, 80.0, -14.0, 0.7, "chip", false)
	Sfx.play("boom", 1.1, -4.0)


## Penutup ULTI "Void Requiem": lubang hitam runtuh, lalu mekar menjadi X raksasa di lantai (dua lapis, delapan sinar) + serpihan piksel ke segala arah.
static func finale(s: Stage, c: Vector3, r: float, tint: Color) -> void:
	var best: Node3D = null
	var bd := 1e9
	for o in s.get_tree().get_nodes_in_group("void_orbs"):
		var on := o as Node3D
		if on != null and is_instance_valid(on):
			var d := Vector2(on.global_position.x - c.x, on.global_position.z - c.z).length()
			if d < bd:
				bd = d
				best = on
	if best != null:
		best.remove_from_group("void_orbs")
		var ot := best.create_tween()
		ot.tween_property(best, "scale", Vector3.ONE * 0.05, 0.12).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_IN)
		ot.tween_callback(best.queue_free)
	var g := Vector3(c.x, 0.1, c.z)
	xglyph(s.fx_root, c, r * 2.1, 1.7, tint, 0.9, Color(1, 1, 1))
	xglyph(s.fx_root, c, r * 1.5, 1.1, CYAN, 0.8, Color(1, 1, 1), PI * 0.25)
	Fx.ring(s.fx_root, g, r, tint, 0.8)
	Fx.ring(s.fx_root, g, r * 0.55, RED, 0.6)
	UltFx.flare(s.fx_root, c + Vector3(0, 2.4, 0), Color(1, 0.95, 1), 9.0, 0.7)
	CharFx.x_flash(s.fx_root, c + Vector3(0, 1.4, 0), Color(1, 1, 1), 7.0, 0.3)
	CharFx.puff(s.fx_root, c + Vector3(0, 1.0, 0), tint.lightened(0.15), 36, 14.0, 0.3, Vector3.UP, 180.0, -12.0, 1.1, "chip", false)
	CharFx.puff(s.fx_root, c + Vector3(0, 0.8, 0), INK.lightened(0.15), 16, 9.0, 0.7, Vector3.UP, 180.0, 0.5, 1.0, "sphere", false)


# ---------------------------------------------------------------- dash teleport
## Portal kecil: lambang X + cincin + serpihan (dipakai di titik awal & tiba).
static func portal(s: Stage, pos: Vector3, tint: Color) -> void:
	var g := Vector3(pos.x, 0.0, pos.z)
	xglyph(s.fx_root, g, 2.6, 0.26, tint, 0.45)
	Fx.ring(s.fx_root, g + Vector3(0, 0.1, 0), 1.3, tint, 0.35)
	CharFx.puff(s.fx_root, g + Vector3(0, 0.7, 0), tint.lightened(0.2), 8, 5.0, 0.18, Vector3.UP, 120.0, -6.0, 0.5, "chip", false)


## Dash teleport Zyrax: portal di titik awal, badan melesat ~7 m dalam 0,09 dtk (tanpa menghilang/berkedip), portal + jejak garis di titik tiba.
## `who` = pemain (posisi nyata) atau CoopGhost (posisi target terbaru dari jaringan).
static func teleport(s: Stage, who: Node3D, tint: Color) -> void:
	var a := who.global_position
	portal(s, a, tint)
	var wait := 0.11
	if who is CoopGhost:
		wait = 0.16
	await s.get_tree().create_timer(wait).timeout
	if not is_instance_valid(s) or not is_instance_valid(who) or s.state == Stage.S.ENDED:
		return
	var b := who.global_position
	if who is CoopGhost:
		b = (who as CoopGhost)._tp
	portal(s, b, tint)
	CharFx.streak(s.fx_root, a + Vector3(0, 1.0, 0), b + Vector3(0, 1.0, 0), tint.lightened(0.3), 0.5, 0.25)
	CharFx.streak(s.fx_root, a + Vector3(0, 1.0, 0), b + Vector3(0, 1.0, 0), Color(1, 1, 1), 0.14, 0.2)
