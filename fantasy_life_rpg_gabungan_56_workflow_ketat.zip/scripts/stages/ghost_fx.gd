class_name GhostFx
extends RefCounted
## Efek PEMAIN LAIN (lawan PVP / rekan co-op) di layar kita. Hanya visual, TANPA damage (damage dihitung di penyerang lalu dikirim lewat jaringan).
## Tujuannya: apa yang dilihat penyerang = apa yang dilihat lawan. Karena itu semua fungsi di sini mencerminkan Stage._on_swing / ComboRunner / Stage._ult_cast
## (kombo tiap karakter termasuk bom Zyrax, semua skill_kind, semua ult_kind, wujud Pedang Petir) memakai pustaka efek yang sama (CharFx, UltFx, StormFx, ChronoFx).
##
## Pewaktuan: efek serangan/skill muncul tepat saat animasi "kena" (action_impact), bukan saat tombol ditekan, sama seperti di sisi penyerang.
## Arah: yaw dikirim bersama aksi (sudah termasuk bantuan bidik penyerang), bukan ditebak dari posisi hantu yang masih meluncur.
## Peringatan: ULTI lawan menampilkan cincin jarak bahaya + banner supaya korban bisa menghindar sebelum serangan dilepas.


static func ok(s: Stage, g: CoopGhost) -> bool:
	return is_instance_valid(s) and s.state != Stage.S.ENDED and s.fx_root != null and is_instance_valid(g) and g.rig != null and not g.dead


## Data karakter yang berlaku sekarang (Kiriel dalam wujud Pedang Petir = tebasan jarak dekat berkombo 3, sama seperti Stage._enter_blade_form).
static func eff_data(g: CoopGhost) -> CharacterData:
	var cd: CharacterData = Data.character(g.char_id)
	if cd == null:
		return null
	if g.form and cd.id == "kiriel":
		var fd: CharacterData = cd.duplicate()
		fd.attack_kind = "arc"
		fd.attack_range = 3.3
		return fd
	return cd


static func _fwd(yaw: float) -> Vector3:
	return Vector3(sin(yaw), 0.0, cos(yaw))


## Lawan dari sudut pandang penyerang itu = kita (pemain lokal) dan hantu lain, bila dalam jangkauan.
static func _foes(s: Stage, g: CoopGhost, center: Vector3, rng: float) -> Array:
	var out: Array = []
	if is_instance_valid(s.player) and not s.player.dead and s.player.global_position.distance_to(center) <= rng:
		out.append(s.player)
	for o in s.get_tree().get_nodes_in_group("ghost"):
		var og := o as CoopGhost
		if og != null and og != g and is_instance_valid(og) and not og.dead and og.global_position.distance_to(center) <= rng:
			out.append(og)
	return out


## Guncangan kamera kita, mengecil menurut jarak ke penyerang (jauh = nyaris tak terasa).
static func _shake(s: Stage, g: CoopGhost, amt: float) -> void:
	if s.cam == null or not is_instance_valid(s.player):
		return
	var d := s.player.global_position.distance_to(g.global_position)
	var k := clampf(1.0 - (d - 3.0) / 14.0, 0.0, 1.0)
	if k > 0.05:
		s.cam.shake(amt * k)


static func _wait(s: Stage, secs: float) -> void:
	await s.get_tree().create_timer(maxf(secs, 0.0)).timeout


# ---------------------------------------------------------------- serangan biasa (kombo per karakter)
static func attack(s: Stage, g: CoopGhost, idx: int, yaw: float) -> void:
	var cd := eff_data(g)
	if cd == null or not ok(s, g):
		return
	var steps: Array = ComboDefs.steps(cd)
	if steps.is_empty():
		return
	var n := steps.size()
	var i := posmod(idx, n)
	var st: Dictionary = steps[i]
	var anim := "attack%d" % clampi(int(st.get("a", 1)), 1, 3)
	g.rig.play_action(anim)
	var hit_t := g.rig.action_impact(anim)
	if hit_t > 0.0:
		await _wait(s, hit_t)
	if not ok(s, g):
		return
	var typ := String(st.get("t", "arc"))
	var col := cd.accent.lightened(0.35)
	var rng := cd.attack_range * float(st.get("r", 1.0))
	var big := bool(st.get("big", i == n - 1 and n > 1))
	var pos := g.global_position
	var fwd := _fwd(yaw)
	var origin := pos + Vector3(0, 0.9, 0)
	var fx := s.fx_root
	match typ:
		"arc":
			_slash(s, cd, st, pos, yaw, rng, col, i, big)
		"cone":
			var tip := pos + fwd * rng
			CharFx.streak(fx, pos + fwd * 0.4, tip, col, 0.34, 0.2)
			CharFx.streak(fx, pos + fwd * 0.4, tip, Color(1, 1, 1), 0.12, 0.16)
			CharFx.spark_lines(fx, tip + Vector3(0, 0.9, 0), fwd, col.lightened(0.3), 8, 9.0, 40.0, 0.2, 0.8)
			CharFx.x_flash(fx, tip + Vector3(0, 0.9, 0), Color(1, 1, 1), 0.9, 0.14)
		"spin":
			Fx.ring(fx, pos + Vector3(0, 0.1, 0), rng, col, 0.3)
			_slash(s, cd, st, pos, yaw, rng, col, i, false)
			_slash(s, cd, st, pos, yaw + PI, rng, col, i + 1, false)
			_shake(s, g, 0.05)
		"slam":
			var c := pos + fwd * rng * 0.55
			var rad := rng * 0.8
			Fx.ring(fx, Vector3(c.x, 0.1, c.z), rad, col, 0.4)
			Fx.ring(fx, Vector3(c.x, 0.1, c.z), rad * 0.55, Color(1, 1, 1), 0.28)
			Fx.burst(fx, c + Vector3(0, 0.3, 0), col.lightened(0.3), 16, 6.0, 0.14)
			if cd.id == "brann":
				CharFx.attack_smash(fx, cd.id, pos, yaw, rng, col, 2)
				CharFx.cracks(fx, c, rad, Color(1.0, 0.65, 0.3), 0.6, 7)
			elif cd.id == "kyomu":
				CharFx.skill_vortex(fx, cd.id, c, rad, 0.3)
			else:
				_slash(s, cd, st, pos, yaw, rng, col, i, true)
			_shake(s, g, 0.12)
		"pull":
			CharFx.skill_vortex(fx, cd.id, pos, rng * 0.8, 0.35)
		"multi":
			var cnt := int(st.get("x", 2))
			var gap := float(st.get("gap", 0.12))
			for k in cnt:
				if k > 0:
					await _wait(s, gap)
					if not ok(s, g):
						return
					pos = g.global_position
				_slash(s, cd, st, pos, yaw, rng, col, i + k, big and k == cnt - 1)
			_shake(s, g, 0.07)
		"wave":
			_slash(s, cd, st, pos, yaw, cd.attack_range, col, i, true)
			_wave(s, origin, fwd, rng * 3.0, col)
			_shake(s, g, 0.08)
		"bomb":                                           # Zyrax: bom lengkung + telegraf area ledakan (dmg 0 = ledakan visual saja)
			var bn := int(st.get("x", 1))
			var bsp := float(st.get("sp", 0.0))
			var btgt := ComboRunner.bomb_target(s, pos, fwd, 9.0, 5.0)
			var bfrom := pos + Vector3(0, 1.4, 0) + fwd * 0.4
			for k in bn:
				var bto := btgt
				if bn > 1:
					var ba := TAU * float(k) / float(bn) + randf() * 0.4
					bto = btgt + Vector3(sin(ba), 0, cos(ba)) * bsp
				ComboRunner.throw_bomb(s, cd, bfrom, bto, 0.0, float(st.get("r", 2.2)), float(st.get("fuse", 0.5)) + 0.08 * k, 0.0, col, bool(st.get("big", false)))
		"shot", "twin", "fan", "burst", "echo", "pierce", "big":
			await _ranged(s, g, cd, st, typ, origin, fwd, col)
		"rain":
			await _rain(s, g, cd, st, pos, fwd, col)
		"nova":
			CharFx.skill_nova(fx, cd.id, pos, float(st.get("r", 3.5)), col)
			_shake(s, g, 0.08)
		"chain":
			var hand := origin + fwd * 0.3
			var ts := _foes(s, g, pos, cd.attack_range + 2.0)
			if ts.is_empty():
				StormFx.bolt(fx, hand + fwd * 0.1, origin + fwd * 5.0, col, 0.2, 0.45, 6)
			else:
				var pts: Array = []
				for t in ts:
					pts.append((t as Node3D).global_position + Vector3(0, 1.0, 0))
				StormFx.chain(fx, hand, pts, col)
				for t in ts:
					StormFx.strike(fx, (t as Node3D).global_position, col)
			_shake(s, g, 0.09)
		_:
			_slash(s, cd, st, pos, yaw, rng, col, i, big)


static func _slash(s: Stage, cd: CharacterData, st: Dictionary, pos: Vector3, yaw: float, rng: float, col: Color, idx: int, big: bool) -> void:
	if cd.attack_kind == "smash":
		CharFx.attack_smash(s.fx_root, cd.id, pos, yaw, rng, col, int(st.get("a", 1)) - 1)
	else:
		CharFx.attack_slash(s.fx_root, cd.id, pos, yaw, rng, col, idx, big)


## Peluru visual. Di PVP peluru berhenti saat mengenai kita (seperti peluru asli di sisi penyerang); di co-op melewati rekan. Tanpa damage.
static func _vproj(s: Stage, g: CoopGhost, cd: CharacterData, kind: String, from: Vector3, dir: Vector3, speed: float, rng: float, col: Color,
		sc: float = 1.0, pierce: bool = false, aoe: float = 0.0) -> void:
	var pr := Projectile.make(kind, col)
	pr.target_group = "player" if s.pvp else "none_visual"
	pr._hit.append(g)                                  # jangan mengenai penembaknya sendiri (grup "player" ikut menyertakan hantu)
	CharFx.decorate_projectile(pr, kind, cd.id, col)
	s.fx_root.add_child(pr)
	pr.launch(Vector3(from.x, 1.0, from.z) + dir * 0.7, dir, speed, rng)
	if sc != 1.0:
		pr.scale = Vector3.ONE * sc
		pr.hit_radius *= sc
	pr.pierce = pierce
	if aoe > 0.0:
		var fxr := s.fx_root
		pr.on_hit = func(_t: Node) -> void:
			if not is_instance_valid(fxr) or not is_instance_valid(pr):
				return
			var c: Vector3 = pr.global_position
			Fx.ring(fxr, Vector3(c.x, 0.1, c.z), aoe, col, 0.4)
			Fx.burst(fxr, c + Vector3(0, 0.5, 0), col.lightened(0.3), 18, 7.0, 0.16)
			CharFx.x_flash(fxr, c + Vector3(0, 0.8, 0), Color(1, 1, 0.9), 2.0, 0.2)


static func _ranged(s: Stage, g: CoopGhost, cd: CharacterData, st: Dictionary, typ: String, origin: Vector3, dir: Vector3, col: Color) -> void:
	var kind := cd.attack_kind if cd.attack_kind in ["bolt", "arrow"] else "bolt"
	var spd := ComboRunner._spd(cd, kind)
	var rg := ComboRunner._rng_of(kind)
	var n := int(st.get("x", 1))
	var side := dir.cross(Vector3.UP).normalized()
	if cd.id == "kiriel":
		StormFx.bolt(s.fx_root, origin + dir * 0.3, origin + dir * 1.9, col, 0.12, 0.22, 3)
	match typ:
		"shot":
			_vproj(s, g, cd, kind, origin, dir, spd, rg, col)
		"twin":
			for sg in [-1.0, 1.0]:
				_vproj(s, g, cd, kind, origin + side * 0.45 * float(sg), dir, spd, rg, col)
		"fan":
			var sp := float(st.get("sp", 12.0))
			for k in n:
				var a := 0.0 if n <= 1 else lerpf(-sp, sp, float(k) / float(n - 1))
				_vproj(s, g, cd, kind, origin, dir.rotated(Vector3.UP, deg_to_rad(a)), spd, rg, col)
		"burst", "echo":
			var gap := float(st.get("gap", 0.12))
			for k in n:
				if k > 0:
					await _wait(s, gap)
					if not ok(s, g):
						return
					origin = g.global_position + Vector3(0, 0.9, 0)
				_vproj(s, g, cd, kind, origin, dir, spd, rg, col, 1.0 if typ == "burst" else 0.9)
		"pierce":
			_vproj(s, g, cd, kind, origin, dir, spd * 1.1, rg + 2.0, col, 1.6, true)
			_shake(s, g, 0.06)
		"big":
			_vproj(s, g, cd, kind, origin, dir, spd * 0.75, rg, col, 2.2, false, float(st.get("r", 2.5)))


## Gelombang tebasan menembus (Hakuya), versi visual.
static func _wave(s: Stage, origin: Vector3, dir: Vector3, dist: float, col: Color) -> void:
	var pr := Projectile.make("bolt", col)
	pr.target_group = "none_visual"
	for c in pr.get_children():
		if c is MeshInstance3D or c is OmniLight3D:
			pr.remove_child(c)
			c.free()
	pr.add_child(ComboRunner.wave_visual(col))
	s.fx_root.add_child(pr)
	pr.launch(Vector3(origin.x, 1.0, origin.z) + dir * 0.9, dir, 17.0, dist)
	pr.pierce = true
	CharFx.trail(pr, col, 14, 0.2, 0.35, 0.5, true, "flame")


## Bintang jatuh (Lyra): penanda di lawan terdekat (kita bila dalam jangkauan), lalu menghantam.
static func _rain(s: Stage, g: CoopGhost, cd: CharacterData, st: Dictionary, pos: Vector3, dir: Vector3, col: Color) -> void:
	var rad := float(st.get("r", 2.3))
	var tp := pos + dir * 4.5
	var best := 1e9
	for t in _foes(s, g, pos, cd.attack_range + 1.0):
		var d := (t as Node3D).global_position.distance_to(pos)
		if d < best:
			best = d
			tp = (t as Node3D).global_position
	tp.y = pos.y
	Fx.magic_circle(s.fx_root, tp, rad, col, 0.4)
	CharFx.puff(s.fx_root, tp + Vector3(0, 5.0, 0), col.lightened(0.3), 8, 12.0, 0.16, Vector3.DOWN, 6.0, 0.0, 0.4, "spark")
	await _wait(s, 0.4)
	if not ok(s, g):
		return
	Fx.ring(s.fx_root, tp + Vector3(0, 0.1, 0), rad, col, 0.4)
	CharFx.x_flash(s.fx_root, tp + Vector3(0, 0.8, 0), Color(1, 1, 1), 2.0, 0.2)
	CharFx.puff(s.fx_root, tp + Vector3(0, 0.5, 0), col, 14, 6.0, 0.14, Vector3.UP, 180.0, -3.0, 0.6, "spark")
	_shake(s, g, 0.09)


# ---------------------------------------------------------------- skill
static func skill(s: Stage, g: CoopGhost, yaw: float) -> void:
	var cd := eff_data(g)
	if cd == null or not ok(s, g):
		return
	g.rig.play_action("skill")
	var hit_t := g.rig.action_impact("skill")
	var col := cd.accent.lightened(0.35)
	var fx := s.fx_root
	if cd.skill_kind == "nova" and cd.id != "wenyu":                    # antisipasi: lingkaran sihir bintang di bawah penyihir (sama seperti sisi penyerang)
		Fx.magic_circle(fx, g.global_position, cd.skill_range * 1.05, cd.accent.lerp(Color(0.4, 0.8, 1.0), 0.65), hit_t)
	elif cd.skill_kind in ["shockwave", "vortex", "chrono", "chain_bolt"]:   # skill area besar: cincin jangkauan sebagai peringatan singkat
		Fx.ring(fx, g.global_position + Vector3(0, 0.1, 0), cd.skill_range, col, maxf(hit_t, 0.2))
	if hit_t > 0.0:
		await _wait(s, hit_t)
	if not ok(s, g):
		return
	var pos := g.global_position
	var fwd := _fwd(yaw)
	var origin := pos + Vector3(0, 0.9, 0)
	match cd.skill_kind:
		"cone":
			CharFx.skill_cone(fx, cd.id, pos, yaw, cd.skill_range, col)
		"dash_cut":
			CharFx.skill_dash(fx, cd.id, pos, yaw, cd.skill_range, col, 0)
			await _wait(s, 0.1)
			if not ok(s, g):
				return
			CharFx.skill_dash(fx, cd.id, g.global_position, yaw, cd.skill_range, col, 1)
			_shake(s, g, 0.12)
		"iai":
			CharFx.skill_iai(fx, cd.id, pos, yaw, cd.skill_range, col, 0)
			await _wait(s, 0.12)
			if not ok(s, g):
				return
			CharFx.skill_iai(fx, cd.id, g.global_position, yaw, cd.skill_range, col, 1)
			_shake(s, g, 0.14)
		"nova":
			CharFx.skill_nova(fx, cd.id, pos, cd.skill_range, cd.accent.lerp(Color(0.4, 0.8, 1.0), 0.65))
		"shockwave":
			CharFx.skill_shockwave(fx, cd.id, pos, yaw, cd.skill_range, col)
			_shake(s, g, 0.3)
		"vortex":
			CharFx.skill_vortex(fx, cd.id, pos, cd.skill_range)
			_shake(s, g, 0.14)
		"chrono":
			ChronoFx.skill(fx, pos, cd.skill_range, col)
			_shake(s, g, 0.12)
		"chain_bolt":
			var hand := origin + fwd * 0.5 + Vector3(0, 0.2, 0)
			var ts := _foes(s, g, pos, cd.skill_range)
			ts.sort_custom(func(a, b): return (a as Node3D).global_position.distance_squared_to(pos) < (b as Node3D).global_position.distance_squared_to(pos))
			if ts.is_empty():
				StormFx.strike(fx, pos + fwd * 3.5, col)
			else:
				var cpts: Array = []
				for t in ts:
					cpts.append((t as Node3D).global_position + Vector3(0, 1.0, 0))
				StormFx.chain(fx, hand, cpts, col)
				for t in ts:
					StormFx.strike(fx, (t as Node3D).global_position, col)
		"bomb_field":                                     # Ranjau Void (Zyrax): sama persis dengan sisi penyerang, tanpa damage
			ZyraxFx.bomb_field(s, cd, origin, fwd, pos, 0.0, col)
		"volley":
			CharFx.skill_volley_start(fx, cd.id, pos, col)
			for k in 7:
				_vproj(s, g, cd, "arrow", origin, fwd.rotated(Vector3.UP, deg_to_rad(-24.0 + k * 8.0)), 25.0, 15.0, col)
	_shake(s, g, 0.1)


# ---------------------------------------------------------------- ULTI
## ULTI lawan: peringatan (cincin jarak bahaya + banner) -> pengisian -> pelepasan -> sambaran/penutup, semuanya dengan efek khas ult_kind-nya.
## Sambaran jatuh di kita bila kita dalam jangkauan (itulah yang dihitung penyerang), selain itu di sekitar penyerang.
static func ult(s: Stage, g: CoopGhost) -> void:
	var cd := eff_data(g)
	if cd == null or not ok(s, g):
		return
	var kind := s.ult_fx_kind(cd)
	var tint := s.ult_tint(cd)
	var center := g.global_position
	var near := is_instance_valid(s.player) and s.player.global_position.distance_to(center) <= cd.ult_range + 2.0
	g.rig.play_action("ult")
	g.rig.flash(cd.accent.lightened(0.5), 1.2)
	Sfx.play("dash")
	Fx.float_text(s.fx_root, center + Vector3(0, 3.2, 0), "ULT! " + cd.ult_name, tint.lightened(0.3), 1.6)
	if near and s.hud != null:
		s.hud.banner("AWAS! ULT %s" % g.pname, tint, 1.6)
	Fx.ring(s.fx_root, center + Vector3(0, 0.1, 0), cd.ult_range, tint, 0.6)            # jarak bahaya
	_shake(s, g, 0.1)
	s._ult_charge(kind, center, cd, tint)
	if cd.id == "zyrax":
		ZyraxFx.wings(g.rig, tint, 3.4)
	await _wait(s, 0.6)
	if not ok(s, g):
		return
	_shake(s, g, 0.16)
	Fx.ring(s.fx_root, g.global_position + Vector3(0, 0.1, 0), cd.ult_range, tint.lightened(0.3), 0.5)
	center = g.global_position
	if kind == "vortex_gate":
		await _vortex_gate(s, g, cd, center, tint)
		return
	if kind == "storm_blade":
		await _storm_blade(s, g, cd, center, tint)
		return
	var yaw := g.rig.rotation.y
	if kind == "shadow_dragon":
		UltFx.dragon(s.fx_root, center + Vector3(0, 1.0, 0), _fwd(yaw), cd.ult_range, tint.darkened(0.55), Color(1.0, 0.2, 0.25), 1.15)
	for i in 7:
		if not ok(s, g):
			return
		var p := _strike_point(s, g, center, cd.ult_range, i)
		s._ult_strike(kind, p, tint)
		await _wait(s, 0.18)
		_shake(s, g, 0.06)
	await _wait(s, 0.15)
	if not ok(s, g):
		return
	s._ult_finale(kind, center, cd.ult_range, tint)
	_shake(s, g, 0.25)


## Titik sambaran ke-i: bergantian di lawan (kita) dalam jangkauan, bila tak ada di titik acak sekitar penyerang.
static func _strike_point(s: Stage, g: CoopGhost, center: Vector3, rng: float, i: int) -> Vector3:
	var ts := _foes(s, g, center, rng)
	var p: Vector3
	if ts.is_empty():
		var a := randf() * TAU
		p = center + Vector3(sin(a), 0, cos(a)) * randf_range(2.0, rng * 0.7)
	else:
		p = (ts[i % ts.size()] as Node3D).global_position
	p.y = center.y
	return p


static func _vortex_gate(s: Stage, g: CoopGhost, cd: CharacterData, center: Vector3, tint: Color) -> void:
	var rad := 3.4
	var life := 2.4
	var ts := _foes(s, g, center, cd.ult_range)
	var spots: Array = []
	for i in 6:
		var p: Vector3
		if ts.is_empty():
			var a := TAU * float(i) / 6.0
			p = center + Vector3(sin(a), 0, cos(a)) * cd.ult_range * 0.4
		else:
			p = (ts[(i * 2) % ts.size()] as Node3D).global_position
		p.y = center.y
		spots.append(p)
		CharFx.vortex_portal(s.fx_root, p, rad, life, tint)
		await _wait(s, 0.06)
	_shake(s, g, 0.12)
	await _wait(s, life)
	if not ok(s, g):
		return
	for p in spots:
		CharFx.x_flash(s.fx_root, p + Vector3(0, 1.0, 0), tint.lightened(0.5), 2.6, 0.25)
		Fx.ring(s.fx_root, p, rad * 1.2, tint, 0.45)
	_shake(s, g, 0.2)


static func _storm_blade(s: Stage, g: CoopGhost, cd: CharacterData, center: Vector3, tint: Color) -> void:
	for i in 7:
		if not ok(s, g):
			return
		var p := _strike_point(s, g, center, cd.ult_range, i)
		StormFx.strike(s.fx_root, p, tint)
		await _wait(s, 0.14)
		_shake(s, g, 0.06)
	if not ok(s, g):
		return
	StormFx.strike(s.fx_root, g.global_position, tint)                 # petir ke-8 menempa pedang (wujud pedang & aura kebal tiba lewat status pemain)
	UltFx.flare(s.fx_root, g.global_position + Vector3(0, 1.2, 0), tint, 4.0, 0.5)
	_shake(s, g, 0.22)


# ---------------------------------------------------------------- menghindar
static func dodge(s: Stage, g: CoopGhost, yaw: float) -> void:
	if not ok(s, g):
		return
	var cd := eff_data(g)
	if cd != null and cd.dodge_kind == "teleport":                      # teleport Zyrax: tanpa animasi guling; hantu menyusul cepat (tanpa berkedip) + portal
		g.warp_t = 0.5
		ZyraxFx.teleport(s, g, s.ult_tint(cd))
		return
	g.rig.play_action("dodge")
	var col := (cd.accent.lightened(0.4) if cd != null else Color(0.8, 0.9, 1.0))
	var back := -_fwd(yaw)
	CharFx.puff(s.fx_root, g.global_position + Vector3(0, 0.3, 0), col, 6, 3.0, 0.14, back, 40.0, 0.0, 0.3, "sphere", false)
