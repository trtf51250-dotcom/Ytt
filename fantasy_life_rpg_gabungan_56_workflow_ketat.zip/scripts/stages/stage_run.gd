class_name StageRun
extends Node3D
## Lapisan "alur petualangan" di atas gelombang stage supaya tiap stage terasa berbeda dan ada keputusan yang harus diambil:
##  1) BERKAH BINTANG: sebelum gelombang berikutnya (dan sebelum bos) pemain memilih 1 dari 3 berkah acak (damage, tahan banting, laju,
##     kritikal, pulih per kill, lifesteal, ledakan, kurangi cooldown dst). Berkah bertumpuk & hanya berlaku selama satu percobaan stage.
##  2) TANTANGAN STAGE (satu gelombang per stage tertentu): LINGKARAN SEGEL (injak & bertahan di lingkaran sampai penuh sementara musuh terus datang),
##     BERTAHAN SAMPAI FAJAR (hitung mundur, musuh membanjir), PEMIMPIN PASUKAN (satu elit besar bertanda; tumbang = sisa pasukan buyar).
##     Selesai = hadiah emas/EXP + peluang berkah lebih langka. Tantangan menggantikan syarat "habiskan semua musuh" untuk gelombang itu.
##  3) SUARA DI TENGAH PERTARUNGAN: baris dialog singkat teman satu tim (data/story.json "barks") muncul saat gelombang mulai, bos muncul, dsb.
## Dipasang oleh Stage._add_run(): hanya stage Adventure/Desa biasa solo (bukan co-op, PVP, wilayah jelajah). Dimatikan saat bot uji
## (kecuali bot memasangnya sendiri) atau lewat Pengaturan > Efek > "Berkah & tantangan". Semua angka ada di konstanta di bawah.

const ST_FIGHT := 1                       # = Stage.S.FIGHT
const ST_ENDED := 2                       # = Stage.S.ENDED
const MAX_STACK := 4
const ZONE_R := 3.3
const ZONE_FILL := 8.0                    # detik berdiri di dalam lingkaran sampai penuh
const ZONE_DECAY := 0.35                  # laju surut (x laju isi) saat pemain di luar
const ZONE_EXTRA_EVERY := 6.0             # detik antar bala bantuan selama lingkaran belum penuh
const SURVIVE_TIME := 30.0
const SURVIVE_EXTRA_EVERY := 2.6
const EXTRA_ALIVE_MAX := 9                # bala bantuan tidak muncul bila musuh hidup sudah sebanyak ini (jaga performa & keadilan)

## id -> {name, icon, desc (pakai %d untuk nilai), v: [biasa, langka, epik], need_ult?, need_hurt?}
const BOONS := {
	"fajar":   {"name": "Bilah Fajar",     "desc": "Damage seranganmu +%d%%.", "v": [8, 13, 20]},
	"tameng":  {"name": "Tameng Bintang",  "desc": "Damage yang kamu terima -%d%%.", "v": [8, 12, 17]},
	"angin":   {"name": "Langkah Angin",   "desc": "Kecepatan gerak +%d%%.", "v": [6, 9, 13]},
	"elang":   {"name": "Mata Elang",      "desc": "Peluang kritikal +%d%%.", "v": [6, 10, 15]},
	"napas":   {"name": "Napas Kristal",   "desc": "Pulih %d%% HP maks tiap musuh tumbang.", "v": [1, 2, 3]},
	"serap":   {"name": "Serap Cahaya",    "desc": "Curi %d%% damage yang kamu beri menjadi HP.", "v": [3, 5, 8]},
	"gema":    {"name": "Gema Kilat",      "desc": "Cooldown skill -%d%%.", "v": [12, 20, 28]},
	"bayang":  {"name": "Tarian Bayangan", "desc": "Cooldown hindar -%d%%.", "v": [15, 25, 35]},
	"kilau":   {"name": "Kilau Fajar",     "desc": "%d%% peluang musuh tumbang meledak & melukai sekitarnya.", "v": [20, 32, 45]},
	"jiwa":    {"name": "Jiwa Baja",       "desc": "HP maks seluruh tim +%d%% (sekaligus pulih sebesar itu).", "v": [10, 15, 22]},
	"napasan": {"name": "Napas Panjang",   "desc": "Jendela combo +%d detik.", "v": [1, 2, 3]},
	"emas":    {"name": "Hasrat Emas",     "desc": "Emas hadiah stage ini +%d%%.", "v": [15, 25, 40]},
	"embun":   {"name": "Embun Peri",      "desc": "Seluruh tim pulih %d%% HP sekarang.", "v": [25, 40, 60], "need_hurt": true, "instant": true},
	"kedua":   {"name": "Bintang Kedua",   "desc": "ULT karakter yang sudah kamu pakai siap dipakai sekali lagi.", "v": [0, 0, 0], "need_ult": true, "instant": true},
}
const TIER_NAMES := ["Biasa", "Langka", "Epik"]
const TIER_COLORS := [Color(0.75, 0.82, 0.95), Color(0.45, 0.72, 1.0), Color(0.82, 0.55, 1.0)]

const CH_NAMES := {"zone": "Lingkaran Segel", "survive": "Bertahan sampai Fajar", "hunt": "Pemimpin Pasukan"}

signal offer_done(id: String)

var stage: Node
var enabled := true
var modal := false                        # layar pilih berkah terbuka (jeda stage dikunci)
var boons: Dictionary = {}                # id -> {"n": jumlah tumpukan, "val": total nilai}
var rare_bonus := 0                       # naik tiap tantangan selesai: berkah berikutnya lebih mungkin langka/epik
var gold_pct := 0
var plan: Dictionary = {}                 # indeks gelombang -> jenis tantangan
var _barks: Array = []
var _barked: Dictionary = {}
var _rng := RandomNumberGenerator.new()
var _in_blast := false
var _offer_ui: Control
var _offer_ids: Array = []
var _offer_tiers: Array = []

# tantangan yang sedang berjalan
var ch_type := ""
var ch_done := false
var ch_wave := -1
var ch_prog := 0.0                        # zone: 0..1
var ch_time := 0.0                        # survive: detik tersisa
var ch_extra_t := 0.0
var ch_pos := Vector3.ZERO
var ch_champion: Enemy
var _zone_root: Node3D
var _zone_fill: MeshInstance3D
var _zone_mat: StandardMaterial3D
var _chars_hint := 0.0
var _dissolve_t := 0.0


func setup(st: Node) -> void:
	stage = st
	_rng.seed = int(hash(st.sd.id)) ^ int(Time.get_ticks_msec())
	plan = plan_for(st.sd)
	_barks = Story.barks(st.sd.id)


## Rancangan tantangan per stage (deterministik dari id): x-2 = lingkaran segel, x-3 = bertahan, x-4 = pemimpin pasukan; x-1 bab 2+ = pemimpin.
## Stage 1-1 (pengenalan), bos, wilayah jelajah & PVP tidak punya tantangan.
static func plan_for(sd: StageData) -> Dictionary:
	var out := {}
	if sd == null or sd.boss != "" or sd.id.begins_with("f_") or sd.id.begins_with("pvp_") or sd.id == "s1_1" or sd.waves.size() < 2:
		return out
	var us := sd.id.find("_")
	if us < 0:
		return out
	var tail := sd.id.substr(us + 1)
	var last := sd.waves.size() - 1
	match tail:
		"1":
			if sd.id.length() > 1 and sd.id[1].is_valid_int() and int(sd.id[1]) >= 2:
				out[last] = "hunt"
		"2":
			out[1] = "zone"
		"3":
			out[last] = "survive"
		"4":
			out[last] = "hunt"
	return out


# ---------------------------------------------------------------- pengali & kait dari Stage
func val(id: String) -> float:
	return float(boons.get(id, {}).get("val", 0.0))


func dmg_mult() -> float:
	return 1.0 + val("fajar") / 100.0


func taken_mult() -> float:
	return maxf(1.0 - val("tameng") / 100.0, 0.4)


func crit_bonus() -> float:
	return val("elang") / 100.0


func combo_bonus() -> float:
	return val("napasan")


## Dipanggil Stage setelah memberi damage `final` ke musuh.
func after_hit(final: int) -> void:
	var ls := val("serap")
	if ls > 0.0 and stage.player != null and not stage.player.dead:
		var h := int(round(float(final) * ls / 100.0))
		if h > 0:
			stage.player.heal(h)


## Dipanggil Stage tiap musuh tumbang (juga musuh yang dibuyarkan tantangan).
func on_kill(e: Enemy) -> void:
	if not enabled:
		return
	if stage.player != null and not stage.player.dead:
		var np := val("napas")
		if np > 0.0:
			var h := int(ceil(float(stage.player.max_hp) * np / 100.0))
			stage.player.heal(h)
		var kc := val("kilau")
		if kc > 0.0 and not _in_blast and not e.is_boss and _rng.randf() * 100.0 < kc:
			_in_blast = true
			var atk := float(GameState.char_stats(stage.player.char_id)["atk"])
			Fx.ring(stage.fx_root, e.global_position, 3.0, Color(1.0, 0.85, 0.4), 0.35)
			Fx.burst(stage.fx_root, e.global_position + Vector3(0, 0.8, 0), Color(1.0, 0.85, 0.4), 14, 5.0, 0.14)
			stage._ult_aoe(e.global_position, 3.0, atk * 0.7, 4.0, Color(1.0, 0.85, 0.4))
			_in_blast = false
	if ch_type == "hunt" and not ch_done and e == ch_champion:
		_complete_challenge()


## true = syarat "habiskan semua musuh" untuk menutup gelombang sedang ditahan (tantangan belum selesai).
func blocks_wave_end() -> bool:
	return enabled and ch_type != "" and not ch_done


func _physics_process(delta: float) -> void:
	if not enabled or stage == null or stage.state == ST_ENDED:
		return
	var p: Player = stage.player
	if p == null:
		return
	if val("angin") > 0.0:
		p.speed_mult = 1.0 + val("angin") / 100.0
	var gm := val("gema")
	if gm > 0.0 and p.skill_cd > 0.0:
		p.skill_cd = maxf(p.skill_cd - delta * gm / 100.0, 0.0)
	var bd := val("bayang")
	if bd > 0.0 and p.dodge_cd > 0.0:
		p.dodge_cd = maxf(p.dodge_cd - delta * bd / 100.0, 0.0)
	if _dissolve_t > 0.0:
		_dissolve_t -= delta
		_dissolve_pass()                                   # terus sampai waktunya habis: musuh yang baru keluar dari antrean ikut buyar
		if _dissolve_t < 1.0 and get_tree().get_nodes_in_group("enemies").size() > 0:
			_dissolve_t = 1.0                              # slime pecah menjadi slime kecil saat mati: lanjutkan sampai benar-benar bersih
	_chars_hint -= delta
	if _chars_hint <= 0.0:
		_chars_hint = 0.5
		_low_hp_check()
	if ch_type != "" and not ch_done and stage.state == ST_FIGHT:
		_tick_challenge(delta)


func _low_hp_check() -> void:
	var mx := 0.0
	var cur := 0.0
	for ps in stage.party_state:
		mx += float(ps["max"])
		cur += 0.0 if ps["dead"] else float(ps["hp"])
	if mx > 0.0 and cur / mx < 0.35:
		bark("low")


# ---------------------------------------------------------------- dialog di tengah pertarungan
## Tampilkan satu baris dialog untuk kunci `key` (sekali per stage): "w0", "w1", "boss", "low", "zone", "survive", "hunt", "done", "half"...
func bark(key: String) -> void:
	if not enabled or _barked.has(key) or stage == null or stage.hud == null:
		return
	for b in _barks:
		if str(b.get("k", "")) == key:
			_barked[key] = true
			stage.hud.say(str(b.get("s", "")), str(b.get("t", "")), 4.2)
			return


# ---------------------------------------------------------------- tantangan
## Dipanggil Stage._start_wave(i) setelah daftar musuh gelombang dibuat.
func on_wave_start(i: int) -> void:
	if not enabled:
		return
	_dissolve_t = 0.0
	bark("w%d" % i)
	if not plan.has(i):
		return
	ch_type = str(plan[i])
	ch_done = false
	ch_wave = i
	ch_extra_t = 4.0
	match ch_type:
		"zone":
			_spawn_zone()
			ch_prog = 0.0
			stage.hud.banner("Lingkaran Segel!", Color(0.6, 0.85, 1.0), 1.3)
		"survive":
			ch_time = SURVIVE_TIME
			stage.hud.banner("Bertahan sampai fajar!", Color(1.0, 0.8, 0.45), 1.3)
		"hunt":
			_spawn_champion()
			stage.hud.banner("Pemimpin Pasukan muncul!", Color(1.0, 0.5, 0.4), 1.3)
	bark(ch_type)
	_update_hud()


func _wave_kinds() -> Array:
	var w: Dictionary = stage.sd.waves[clampi(ch_wave, 0, stage.sd.waves.size() - 1)]
	var ks: Array = []
	for k in w:
		if Enemy.KINDS.has(k):
			ks.append(str(k))
	return ks


func _spawn_extra() -> void:
	var ks := _wave_kinds()
	if ks.is_empty():
		return
	if get_tree().get_nodes_in_group("enemies").size() + stage._pending >= EXTRA_ALIVE_MAX:
		return
	stage._pending += 1
	stage._spawn_delayed(ks[_rng.randi() % ks.size()], 0.05)


func _tick_challenge(delta: float) -> void:
	match ch_type:
		"zone":
			var pp := Vector2(stage.player.global_position.x, stage.player.global_position.z)
			var inside := pp.distance_to(Vector2(ch_pos.x, ch_pos.z)) <= ZONE_R
			if inside:
				ch_prog += delta / ZONE_FILL
			else:
				ch_prog -= delta / ZONE_FILL * ZONE_DECAY
			ch_prog = clampf(ch_prog, 0.0, 1.0)
			_zone_visual(inside)
			ch_extra_t -= delta
			if ch_extra_t <= 0.0 and ch_prog < 1.0:
				ch_extra_t = ZONE_EXTRA_EVERY
				_spawn_extra()
			if ch_prog >= 1.0:
				_complete_challenge()
		"survive":
			ch_time -= delta
			ch_extra_t -= delta
			if ch_extra_t <= 0.0:
				ch_extra_t = SURVIVE_EXTRA_EVERY
				_spawn_extra()
			if ch_time <= 0.0:
				_complete_challenge()
		"hunt":
			if ch_champion == null or not is_instance_valid(ch_champion):
				if not ch_done:
					_complete_challenge()
	_update_hud()


func _update_hud() -> void:
	if stage == null or stage.hud == null:
		return
	if ch_type == "" or ch_done:
		stage.hud.set_objective("", -1.0)
		return
	match ch_type:
		"zone":
			stage.hud.set_objective("Segel: berdiri di lingkaran bercahaya", ch_prog)
		"survive":
			stage.hud.set_objective("Bertahan: %d dtk" % int(ceil(maxf(ch_time, 0.0))), 1.0 - clampf(ch_time / SURVIVE_TIME, 0.0, 1.0))
		"hunt":
			var f := 0.0
			if ch_champion != null and is_instance_valid(ch_champion):
				f = float(ch_champion.hp) / maxf(float(ch_champion.max_hp), 1.0)
			stage.hud.set_objective("Kalahkan Pemimpin Pasukan", f)


func _complete_challenge() -> void:
	if ch_done:
		return
	ch_done = true
	var name_ := str(CH_NAMES.get(ch_type, "Tantangan"))
	var lv: int = stage.sd.recommended_level
	var gold := 40 + lv * 14
	var xp := 25 + lv * 9
	GameState.add_gold(gold)
	GameState.add_exp(xp)
	rare_bonus += 1
	stage.hud.banner("%s selesai!  +%d emas" % [name_, gold], Color(0.55, 1.0, 0.7), 1.7)
	Sfx.play("chest", 1.0, -4.0)
	if stage.player != null and not stage.player.dead:
		Fx.ring(stage.fx_root, stage.player.global_position, 5.0, Color(0.6, 0.95, 1.0), 0.5)
		for ps in stage.party_state:
			if not ps["dead"]:
				ps["hp"] = mini(int(ps["hp"]) + int(float(ps["max"]) * 0.18), int(ps["max"]))
		stage.player.hp = mini(stage.player.hp + int(float(stage.player.max_hp) * 0.18), stage.player.max_hp)
	_clear_zone()
	_dissolve_enemies()
	_update_hud()
	bark("done")
	if stage.state == ST_FIGHT and get_tree().get_nodes_in_group("enemies").is_empty() and stage._pending == 0:
		stage._wave_timer = 1.5


## Sisa pasukan buyar menjadi cahaya. Musuh yang masih dalam animasi muncul kebal, jadi dicoba ulang beberapa detik (_dissolve_t).
func _dissolve_enemies() -> void:
	_dissolve_t = 4.0
	_dissolve_pass()


func _dissolve_pass() -> void:
	for pass_i in 3:
		for e in get_tree().get_nodes_in_group("enemies"):
			if is_instance_valid(e) and e is Enemy and not e.is_boss and not e.dead:
				Fx.burst(stage.fx_root, e.global_position + Vector3(0, 0.8, 0), Color(0.7, 0.9, 1.0), 8, 3.5, 0.12)
				e.take_damage(999999, stage.player.global_position, 0.0)
	stage._pending = 0


func _spawn_zone() -> void:
	var R: float = stage.arena.radius
	var pp := Vector2(stage.player.global_position.x, stage.player.global_position.z)
	var best := Vector3(0, 0.05, 0)
	for attempt in 14:
		var a := _rng.randf() * TAU
		var r := R * _rng.randf_range(0.25, 0.55)
		var c := Vector3(cos(a) * r, 0.05, sin(a) * r)
		if pp.distance_to(Vector2(c.x, c.z)) > 7.0 and not stage.spot_blocked(c, ZONE_R * 0.4):
			best = c
			break
	ch_pos = best
	_zone_root = Node3D.new()
	_zone_root.name = "ZoneSeal"
	stage.add_child(_zone_root)
	_zone_root.global_position = Vector3(ch_pos.x, 0.09, ch_pos.z)
	var rim := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = ZONE_R - 0.14
	tm.outer_radius = ZONE_R
	tm.rings = 32
	tm.ring_segments = 4
	rim.mesh = tm
	rim.material_override = Fx._unshaded(Color(0.6, 0.85, 1.0, 0.9))
	rim.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_zone_root.add_child(rim)
	_zone_fill = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = ZONE_R
	cm.bottom_radius = ZONE_R
	cm.height = 0.03
	cm.radial_segments = 32
	cm.rings = 1
	_zone_fill.mesh = cm
	_zone_mat = Fx._unshaded(Color(0.5, 0.8, 1.0, 0.18))
	_zone_fill.material_override = _zone_mat
	_zone_fill.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_zone_root.add_child(_zone_fill)
	var beam := MeshInstance3D.new()
	var bm := CylinderMesh.new()
	bm.top_radius = 0.1
	bm.bottom_radius = 0.35
	bm.height = 9.0
	bm.radial_segments = 8
	bm.rings = 1
	beam.mesh = bm
	beam.material_override = Fx._unshaded(Color(0.6, 0.9, 1.0, 0.28))
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	beam.position = Vector3(0, 4.5, 0)
	_zone_root.add_child(beam)


func _zone_visual(inside: bool) -> void:
	if _zone_mat == null:
		return
	var a := 0.16 + 0.38 * ch_prog
	_zone_mat.albedo_color = Color(1.0, 0.9, 0.55, a) if inside else Color(0.5, 0.8, 1.0, a)
	if _zone_fill != null:
		var s := 0.35 + 0.65 * ch_prog
		_zone_fill.scale = Vector3(s, 1.0, s)


func _clear_zone() -> void:
	if _zone_root != null and is_instance_valid(_zone_root):
		Fx.ring(stage.fx_root, _zone_root.global_position, ZONE_R * 1.6, Color(1.0, 0.9, 0.55), 0.5)
		_zone_root.queue_free()
	_zone_root = null
	_zone_fill = null
	_zone_mat = null


func _spawn_champion() -> void:
	var ks := _wave_kinds()
	if ks.is_empty():
		ch_champion = null
		return
	var pick: String = str(ks[0])
	var best_hp := -1
	for k in ks:
		var info: Dictionary = Enemy.KINDS[k]
		if bool(info.get("flying", false)):
			continue
		if int(info.get("hp", 0)) > best_hp:
			best_hp = int(info.get("hp", 0))
			pick = k
	var pos: Vector3 = stage._spawn_pos()
	var e: Enemy = stage._spawn_enemy(pick, pos)
	e.make_elite()
	e.max_hp = int(e.max_hp * 1.9)
	e.hp = e.max_hp
	e.atk = int(e.atk * 1.1)
	if e._tag != null:
		e._tag.text = "PEMIMPIN"
		e._tag.modulate = Color(1.0, 0.5, 0.4)
	var beam := MeshInstance3D.new()
	var bm := CylinderMesh.new()
	bm.top_radius = 0.08
	bm.bottom_radius = 0.22
	bm.height = 12.0
	bm.radial_segments = 8
	bm.rings = 1
	beam.mesh = bm
	beam.material_override = Fx._unshaded(Color(1.0, 0.45, 0.35, 0.3))
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	beam.position = Vector3(0, 6.0, 0)
	e.add_child(beam)
	ch_champion = e


# ---------------------------------------------------------------- berkah
## Roll satu berkah: id + tier (0..2). `pre_boss` menaikkan peluang langka/epik.
func _roll_offer(pre_boss: bool) -> void:
	_offer_ids.clear()
	_offer_tiers.clear()
	var pool: Array = []
	for id in BOONS:
		var b: Dictionary = BOONS[id]
		if int(boons.get(id, {}).get("n", 0)) >= MAX_STACK and not bool(b.get("instant", false)):
			continue
		if bool(b.get("need_ult", false)) and not _any_ult_used():
			continue
		if bool(b.get("need_hurt", false)) and not _any_hurt():
			continue
		pool.append(id)
	pool.shuffle()
	var n := mini(3, pool.size())
	for i in n:
		_offer_ids.append(pool[i])
		_offer_tiers.append(_roll_tier(pre_boss))


func _roll_tier(pre_boss: bool) -> int:
	var epic := 8 + rare_bonus * 5 + (6 if pre_boss else 0)
	var rare := 30 + rare_bonus * 6 + (10 if pre_boss else 0)
	var r := _rng.randi() % 100
	if r < epic:
		return 2
	if r < epic + rare:
		return 1
	return 0


func _any_ult_used() -> bool:
	return not stage._ult_used.is_empty()


func _any_hurt() -> bool:
	for ps in stage.party_state:
		if not ps["dead"] and float(ps["hp"]) < float(ps["max"]) * 0.85:
			return true
	return false


func desc_for(id: String, tier: int) -> String:
	var b: Dictionary = BOONS[id]
	var v: int = int(b["v"][tier])
	if id == "kedua":
		return str(b["desc"])
	return str(b["desc"]) % v


func apply(id: String, tier: int) -> void:
	var b: Dictionary = BOONS[id]
	var v: float = float(b["v"][tier])
	var cur: Dictionary = boons.get(id, {"n": 0, "val": 0.0})
	if not bool(b.get("instant", false)):
		cur["n"] = int(cur["n"]) + 1
		cur["val"] = float(cur["val"]) + v
		boons[id] = cur
	match id:
		"emas":
			gold_pct += int(v)
		"jiwa":
			for ps in stage.party_state:
				var add := int(float(ps["max"]) * v / 100.0)
				ps["max"] = int(ps["max"]) + add
				if not ps["dead"]:
					ps["hp"] = mini(int(ps["hp"]) + add, int(ps["max"]))
			var a: Dictionary = stage.party_state[stage.active]
			stage.player.max_hp = int(a["max"])
			stage.player.hp = int(a["hp"])
		"embun":
			for ps in stage.party_state:
				if not ps["dead"]:
					ps["hp"] = mini(int(ps["hp"]) + int(float(ps["max"]) * v / 100.0), int(ps["max"]))
			stage.player.hp = mini(stage.player.hp + int(float(stage.player.max_hp) * v / 100.0), stage.player.max_hp)
		"kedua":
			stage._ult_used.clear()
	if stage.hud != null:
		stage.hud.set_boons(summary())


func summary() -> String:
	var parts: Array = []
	for id in BOONS:
		if boons.has(id):
			parts.append("%s ×%d" % [BOONS[id]["name"], int(boons[id]["n"])])
	return "  ·  ".join(parts)


## Layar pilih berkah. Menjeda stage sampai pemain memilih; dipanggil Stage._advance_wave().
func intermission(pre_boss: bool) -> void:
	if not enabled or stage == null or stage.state == ST_ENDED:
		return
	_dissolve_t = 0.0
	_roll_offer(pre_boss)
	if _offer_ids.is_empty():
		return
	modal = true
	stage._paused = true
	get_tree().paused = true
	if stage.touch != null:
		stage.touch.release_all()
		stage.touch.visible = false
	_build_offer(pre_boss)
	var id: String = await offer_done
	modal = false
	stage._paused = false
	get_tree().paused = false
	if stage.touch != null:
		stage.touch.visible = stage.touch.touch_enabled
	if _offer_ui != null and is_instance_valid(_offer_ui):
		_offer_ui.queue_free()
	_offer_ui = null
	stage.hud.banner("%s" % BOONS[id]["name"], TIER_COLORS[clampi(_last_tier, 0, 2)], 1.0)


var _last_tier := 0


## Pilih kartu ke-i (0..2). Dipakai tombol & bot uji.
func choose(i: int) -> void:
	if not modal or i < 0 or i >= _offer_ids.size():
		return
	var id: String = _offer_ids[i]
	var tier: int = _offer_tiers[i]
	_last_tier = tier
	apply(id, tier)
	Sfx.play("chest", 1.2, -6.0)
	offer_done.emit(id)


func _build_offer(pre_boss: bool) -> void:
	var root := Control.new()
	root.name = "BoonOffer"
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.process_mode = Node.PROCESS_MODE_ALWAYS
	root.theme = UiTheme.get_theme()
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.03, 0.07, 0.78)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(dim)
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(cc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	cc.add_child(v)
	v.add_child(UiTheme.label("Berkah Bintang" if not pre_boss else "Berkah Sebelum Bos", 42, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(UiTheme.label("Pilih satu. Berkah hanya berlaku di stage ini dan bisa bertumpuk.", 20, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_child(row)
	for i in _offer_ids.size():
		var idx := i
		var id: String = _offer_ids[i]
		var tier: int = _offer_tiers[i]
		var b: Dictionary = BOONS[id]
		var col: Color = TIER_COLORS[tier]
		var btn := Button.new()
		btn.focus_mode = Control.FOCUS_NONE
		btn.custom_minimum_size = Vector2(250, 250)
		btn.add_theme_stylebox_override("normal", UiTheme.box(Color(0.06, 0.14, 0.23, 0.97), col, 3, 16, 10))
		btn.add_theme_stylebox_override("hover", UiTheme.box(Color(0.12, 0.25, 0.36, 0.98), UiTheme.GOLD, 4, 16, 10))
		btn.add_theme_stylebox_override("pressed", UiTheme.box(Color(0.04, 0.08, 0.14, 0.98), UiTheme.GOLD, 4, 16, 10))
		var inner := VBoxContainer.new()
		inner.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		inner.offset_left = 12
		inner.offset_right = -12
		inner.offset_top = 12
		inner.offset_bottom = -12
		inner.alignment = BoxContainer.ALIGNMENT_BEGIN
		inner.add_theme_constant_override("separation", 8)
		inner.mouse_filter = Control.MOUSE_FILTER_IGNORE
		btn.add_child(inner)
		var tl := UiTheme.label(str(TIER_NAMES[tier]).to_upper(), 16, col, HORIZONTAL_ALIGNMENT_CENTER)
		tl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		inner.add_child(tl)
		var nl := UiTheme.label(str(b["name"]), 26, UiTheme.TEXT, HORIZONTAL_ALIGNMENT_CENTER)
		nl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		nl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		inner.add_child(nl)
		var dl := UiTheme.label(desc_for(id, tier), 19, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER)
		dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		dl.size_flags_vertical = Control.SIZE_EXPAND_FILL
		dl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		inner.add_child(dl)
		var have := int(boons.get(id, {}).get("n", 0))
		var hl := UiTheme.label(("Dimiliki ×%d" % have) if have > 0 else "Baru", 15, UiTheme.GOOD if have == 0 else UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
		hl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		inner.add_child(hl)
		btn.pressed.connect(func(): choose(idx))
		row.add_child(btn)
	stage.ui.add_child(root)
	_offer_ui = root
