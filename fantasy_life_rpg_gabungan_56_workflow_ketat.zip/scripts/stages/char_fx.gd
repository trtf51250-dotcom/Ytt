class_name CharFx
extends RefCounted
## Efek serang & skill KHAS tiap karakter (semua orisinal, dibuat dari kode, tanpa aset luar):
##   Ren   = es & fajar   (bulan sabit es biru, serpihan es, salju; skill: dua sabit biru-emas)
##   Zeya  = bayangan     (sabit tipis merah muda + bayangan ungu, penutup berbentuk X, kelopak; skill: garis terjang)
##   Lyra  = bintang      (peluru bintang berputar + kerlip ungu)
##   Ember = api          (bola api berdenyut + jejak api; skill: lingkaran api & bekas hangus)
##   Brann = tanah        (retakan tanah, debu, pecahan batu; skill: gempa)
##   Sera  = angin/daun   (panah berjejak angin + daun; skill: cincin angin)
##   Hakuya = bulan pucat & api biru (★6; tebasan iai putih tipis berujung biru, skill: dua tebasan panjang + api biru)
## Hemat: partikel CPU sekali-jalan dengan mesh & material dipakai bersama (cache), mengecil sendiri (tanpa alpha per-partikel),
## jumlah partikel menyesuaikan Pengaturan > Kualitas (Lancar = setengah & tanpa jejak peluru), semua efek membersihkan dirinya.
## Id karakter yang tidak dikenal memakai efek umum (Fx) seperti sebelumnya.

const KNOWN := ["ren", "zeya", "lyra", "ember", "brann", "sera", "hakuya", "vael", "lucien", "wenyu", "kuroha", "aion", "kyomu", "kiriel"]

static var _mesh_cache: Dictionary = {}
static var _curve: Curve = null


static func known(id: String) -> bool:
	return id in KNOWN


static func _q() -> int:
	return Quality.level()


## Skala jumlah partikel menurut kualitas.
static func _n(c: int) -> int:
	match _q():
		0: return maxi(1, int(c * 0.6))
		2: return int(ceil(c * 1.6))
	return int(ceil(c * 1.25))


static func _shrink() -> Curve:
	if _curve == null:
		_curve = Curve.new()
		_curve.add_point(Vector2(0.0, 1.0))
		_curve.add_point(Vector2(0.65, 0.7))
		_curve.add_point(Vector2(1.0, 0.0))
	return _curve


static var _flame_tex: ImageTexture = null
static var _fade: Gradient = null


## Tekstur lidah api halus (setetes air terbalik, ujung meruncing & sedikit meliuk, tepi lembut, inti lebih terang).
static func flame_texture() -> ImageTexture:
	if _flame_tex != null:
		return _flame_tex
	var w := 64
	var h := 96
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	for y in h:
		var ty := float(y) / float(h - 1)                      # 0 = ujung atas, 1 = dasar
		var hw := 0.18 + pow(ty, 0.7) * 0.82                   # melebar ke dasar
		if ty > 0.86:
			hw *= sqrt(maxf(1.0 - pow((ty - 0.86) / 0.14, 2.0), 0.0))
		var shift := sin(ty * 7.0 + 0.6) * 0.14 * (1.0 - ty)   # meliuk
		var top_fade := smoothstep(0.0, 0.42, ty)               # ujung atas memudar halus (bukan runcing keras)
		for x in w:
			var nx := (float(x) - (w - 1) * 0.5) / ((w - 1) * 0.5)
			var d := absf(nx - shift) / maxf(hw, 0.001)
			var a := exp(-d * d * 2.4) * top_fade
			var core := exp(-d * d * 6.0) * smoothstep(0.2, 0.9, ty)
			var v := 0.5 + 0.5 * core
			img.set_pixel(x, y, Color(v, v, v, a))
	_flame_tex = ImageTexture.create_from_image(img)
	return _flame_tex


static func _fade_ramp() -> Gradient:
	if _fade == null:
		_fade = Gradient.new()
		_fade.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
		_fade.colors = PackedColorArray([Color(1, 1, 1, 0.95), Color(1, 1, 1, 0.7), Color(1, 1, 1, 0.0)])
	return _fade


static func _pmesh(kind: String, col: Color, additive: bool) -> Mesh:
	var key := "%s_%s_%s" % [kind, col.to_html(false), additive]
	if _mesh_cache.has(key):
		return _mesh_cache[key]
	var m: Mesh
	match kind:
		"shard":                                   # serpihan memanjang di sumbu Y (disejajarkan ke arah gerak)
			var bm := BoxMesh.new()
			bm.size = Vector3(0.16, 0.7, 0.16)
			m = bm
		"spark":                                   # percikan garis tipis & panjang (garis kecepatan)
			var sk := BoxMesh.new()
			sk.size = Vector3(0.035, 1.0, 0.035)
			m = sk
		"ember":                                   # bara kecil
			var em := SphereMesh.new()
			em.radius = 0.5
			em.height = 1.0
			em.radial_segments = 8
			em.rings = 4
			m = em
		"chip":                                    # pecahan batu
			var bm2 := BoxMesh.new()
			bm2.size = Vector3(0.4, 0.3, 0.35)
			m = bm2
		"flame":                                   # lidah api halus (billboard bertekstur, memudar)
			var fm := QuadMesh.new()
			fm.size = Vector2(0.9, 1.35)
			fm.center_offset = Vector3(0, 0.55, 0)
			m = fm
		"note_a", "note_b", "note_c":              # nota musik (billboard bertekstur)
			var nq := QuadMesh.new()
			nq.size = Vector2(1.0, 1.0)
			m = nq
		"leaf":                                    # daun: pipih
			var qm := QuadMesh.new()
			qm.size = Vector2(0.8, 0.45)
			m = qm
		_:
			var sm := SphereMesh.new()
			sm.radius = 0.5
			sm.height = 1.0
			sm.radial_segments = 6
			sm.rings = 3
			m = sm
	var mat := Fx._unshaded(Color(col.r, col.g, col.b, 1.0), additive)
	if kind == "flame":
		mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		mat.billboard_keep_scale = true
		mat.albedo_texture = flame_texture()
		mat.vertex_color_use_as_albedo = true
		mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR
		mat.no_depth_test = false
	if kind.begins_with("note_"):
		mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		mat.billboard_keep_scale = true
		mat.albedo_texture = UltFx.tex(kind)
		mat.vertex_color_use_as_albedo = true
		mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR
	m.material = mat
	_mesh_cache[key] = m
	return m


## Ledakan partikel serbaguna. kind: sphere / shard / chip / leaf. gravity dalam sumbu Y (positif = naik, mis. api).
static func puff(parent: Node, pos: Vector3, col: Color, count: int, speed: float, size: float, dir: Vector3 = Vector3.UP,
		spread: float = 180.0, gravity: float = -9.0, life: float = 0.5, kind: String = "sphere", additive: bool = true) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.emitting = false
	p.amount = _n(count)
	p.lifetime = life
	p.explosiveness = 1.0
	p.direction = dir
	p.spread = spread
	p.initial_velocity_min = speed * 0.45
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, gravity, 0)
	p.scale_amount_min = size * 0.7
	p.scale_amount_max = size * 1.3
	p.scale_amount_curve = _shrink()
	if kind == "shard" or kind == "spark":
		p.particle_flag_align_y = true
	if kind == "flame":
		p.color_ramp = _fade_ramp()
	if kind == "leaf" or kind == "chip" or kind.begins_with("note_"):
		p.angle_min = 0.0
		p.angle_max = 360.0
		p.angular_velocity_min = -240.0
		p.angular_velocity_max = 240.0
	p.mesh = _pmesh(kind, col, additive)
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	p.get_tree().create_timer(life + 0.4).timeout.connect(p.queue_free)
	return p


## Semburan nota musik (campuran ♪ ♫ ♩) berwarna col.
static func notes(parent: Node, pos: Vector3, col: Color, count: int, speed: float, size: float, dir: Vector3 = Vector3.UP,
		spread: float = 180.0, gravity: float = 1.0, life: float = 1.0) -> void:
	var n := maxi(count, 3)
	var kinds := ["note_a", "note_b", "note_c"]
	var solid := Color(col.r * 0.55, col.g * 0.85, col.b * 0.8)        # lebih pekat agar terbaca di rumput terang
	for i in 3:
		puff(parent, pos, solid, maxi(1, int(round(float(n) / 3.0))), speed, size * 2.0, dir, spread, gravity, life, kinds[i], false)


## Jejak partikel menempel pada peluru (dunia-ruang, mengecil). Dilewati di kualitas "Lancar".
static func trail(host: Node3D, col: Color, amount: int, size: float, life: float, up: float = 0.0, additive: bool = true, kind: String = "sphere") -> void:
	if _q() == 0:
		return
	var t := CPUParticles3D.new()
	t.local_coords = false
	t.amount = amount
	t.lifetime = life
	t.direction = Vector3.UP
	t.spread = 180.0
	t.initial_velocity_min = 0.1
	t.initial_velocity_max = 0.7
	t.gravity = Vector3(0, up, 0)
	t.scale_amount_min = size * 0.7
	t.scale_amount_max = size * 1.2
	t.scale_amount_curve = _shrink()
	t.mesh = _pmesh(kind, col, additive)
	t.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	host.add_child(t)
	t.emitting = true


# ---------------------------------------------------------------- bentuk dasar
## Sabit tebasan yang MENYAPU KE DEPAN (bukan berdiri tegak di atas kepala): busur mendatar mengelilingi pemain pada jarak
## jangkauan, miring diagonal ala ayunan pedang, lalu menyapu dari satu sisi ke sisi lain searah hadap.
## tilt_deg = kemiringan diagonal; flip = arah sapuan dibalik. (forward tidak dipakai lagi; parameter dipertahankan agar panggilan lama tetap valid)
static func crescent(parent: Node, pos: Vector3, yaw: float, radius: float, col: Color, life: float, tilt_deg: float, flip: bool = false,
		band_deg: float = 110.0, thick: float = 0.22, forward: float = 0.5, height: float = 1.0, taper: bool = false) -> void:
	var root := Node3D.new()
	parent.add_child(root)
	root.global_position = Vector3(pos.x, minf(height, 1.0), pos.z)
	var sgn := -1.0 if flip else 1.0
	# arah hadap (yaw) lalu kemiringan diagonal ayunan, digabung dalam SATU node akar (hemat node efek)
	root.basis = Basis(Vector3.UP, yaw) * Basis(Vector3(0, 0, 1), deg_to_rad(clampf(tilt_deg, -30.0, 30.0)) * 0.5)
	var sweep := Node3D.new()
	root.add_child(sweep)
	sweep.rotation.y = -0.6 * sgn
	thick = minf(thick * 1.4, 0.5)
	var r := radius * 0.9
	var tw := root.create_tween()
	tw.set_parallel(true)
	tw.tween_property(sweep, "rotation:y", 0.6 * sgn, life * 0.8).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	for layer in (3 if _q() > 0 else 2):
		var mi := MeshInstance3D.new()
		var tk: float = thick if layer == 0 else (thick * 0.4 if layer == 1 else thick * 1.9)
		var bd := band_deg * 0.6
		mi.mesh = taper_mesh(bd, tk) if taper else Fx.arc_band_mesh(bd, 1.0 - tk, 10)
		var c := col if layer == 0 else (col.lightened(0.7) if layer == 1 else col)
		var mat := Fx._unshaded(Color(c.r, c.g, c.b, 0.92 if layer < 2 else 0.4), layer == 2)
		mi.material_override = mat
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.scale = Vector3.ONE * r * (1.0 if layer == 0 else (1.02 if layer == 1 else 1.07))
		sweep.add_child(mi)
		tw.tween_property(mat, "albedo_color:a", 0.0, life * 0.9).set_delay(life * 0.3)
	tw.chain().tween_callback(root.queue_free)


static var _taper_cache: Dictionary = {}


## Bulan sabit runcing: tebal di tengah, menipis jadi ujung tajam di kedua sisi (jejak katana). Di-cache.
static func taper_mesh(band_deg: float, thick: float, seg: int = 14) -> ArrayMesh:
	var key := "%d_%d_%d" % [int(band_deg), int(thick * 100), seg]
	if _taper_cache.has(key):
		return _taper_cache[key]
	var pts := PackedVector3Array()
	var norms := PackedVector3Array()
	var h := deg_to_rad(band_deg * 0.5)
	for i in seg:
		var t0 := float(i) / seg
		var t1 := float(i + 1) / seg
		var a0 := -h + 2.0 * h * t0
		var a1 := -h + 2.0 * h * t1
		var in0 := 1.0 - thick * pow(sin(PI * t0), 0.85)
		var in1 := 1.0 - thick * pow(sin(PI * t1), 0.85)
		var o0 := Vector3(sin(a0), 0, cos(a0))
		var o1 := Vector3(sin(a1), 0, cos(a1))
		pts.append_array([o0 * in0, o0, o1, o0 * in0, o1, o1 * in1])
		for j in 6:
			norms.append(Vector3.UP)
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = pts
	arrays[Mesh.ARRAY_NORMAL] = norms
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_taper_cache[key] = m
	return m


## Semburan garis percikan memancar (impak / garis kecepatan): satu node partikel, garis tipis berwarna terang.
static func spark_lines(parent: Node, pos: Vector3, dir: Vector3, col: Color, count: int, speed: float, spread: float = 180.0, life: float = 0.2, size: float = 0.7) -> void:
	puff(parent, pos, col, count, speed, size, dir, spread, 0.0, life, "spark", true)


## Bara kecil bersinar yang melayang naik lalu padam.
static func embers(parent: Node, pos: Vector3, col: Color, count: int, spread: float = 180.0, speed: float = 2.5, life: float = 0.9, dir: Vector3 = Vector3.UP) -> void:
	puff(parent, pos, col, count, speed, 0.07, dir, spread, 1.6 if dir == Vector3.UP else 0.3, life, "ember", true)


## Jejak tebasan sungguhan: pita yang mengikuti ujung & pangkal bilah selama serangan/skill, memudar cepat (seperti di video referensi).
class BladeTrail extends Node3D:
	const LIFE := 0.15        # singkat: dulu 0,26 dtk sehingga pita tertinggal terlihat seperti 'salinan pedang' di belakang karakter
	const MAXN := 10
	var blade: Node3D
	var player: Node
	var col_a := Color(0.95, 0.98, 1.0)
	var col_b := Color(0.3, 0.6, 1.0)
	var _im := ImmediateMesh.new()
	var _pts: Array = []          # [{t, a, b}] a = ujung, b = pangkal
	var _mi: MeshInstance3D

	func _ready() -> void:
		top_level = true
		_mi = MeshInstance3D.new()
		_mi.mesh = _im
		_mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var mat := StandardMaterial3D.new()
		mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		mat.vertex_color_use_as_albedo = true
		mat.no_depth_test = false
		_mi.material_override = mat
		add_child(_mi)

	func _process(_dt: float) -> void:
		var now := Time.get_ticks_msec() / 1000.0
		if player == null:
			var n: Node = blade
			while n != null and not (n is Player):
				n = n.get_parent()
			player = n
		var active: bool = player != null and is_instance_valid(player) and float(player.get("_act_t")) > 0.0
		if active and blade != null and blade.is_inside_tree():
			var tf := blade.global_transform
			var tip: Vector3 = tf * Vector3(0, 1.32, 0)
			var base: Vector3 = tf * Vector3(0, 0.95, 0)       # hanya sepertiga ujung bilah (bukan seluruh bilah) -> goresan tipis, bukan bayangan pedang
			if _pts.is_empty() or tip.distance_to(_pts[_pts.size() - 1]["a"]) > 0.04:
				_pts.append({"t": now, "a": tip, "b": base})
		while _pts.size() > 0 and (now - float(_pts[0]["t"]) > LIFE or _pts.size() > MAXN):
			_pts.pop_front()
		_im.clear_surfaces()
		if _pts.size() < 2:
			return
		_im.surface_begin(Mesh.PRIMITIVE_TRIANGLE_STRIP)
		for p in _pts:
			var age := clampf((now - float(p["t"])) / LIFE, 0.0, 1.0)
			var al := pow(1.0 - age, 2.0)
			var ca := col_a
			ca.a = al * 0.8
			var cb := col_b
			cb.a = 0.0
			_im.surface_set_color(ca)
			_im.surface_add_vertex(p["a"])
			_im.surface_set_color(cb)
			_im.surface_add_vertex(p["b"])
		_im.surface_end()


static func attach_blade_trail(blade: Node3D, rig: Node, col_a: Color, col_b: Color) -> void:
	var tr := BladeTrail.new()
	tr.name = "BladeTrail"
	tr.blade = blade
	tr.col_a = col_a
	tr.col_b = col_b
	blade.add_child(tr)


## Katana menyala: lidah api biru kecil sepanjang bilah + bara/percikan yang tertinggal di udara saat pedang diayun
## (dipasang sebagai anak mesh katana; bilah membentang di sumbu Y lokal dari ~0.1 sampai ~1.3).
static func blade_fire(blade: Node3D, col: Color = BLUE, ember_col: Color = Color(0.5, 0.82, 1.0), length: float = 1.2) -> void:
	var fl := CPUParticles3D.new()
	fl.name = "BladeFlame"
	fl.amount = _n(7)
	fl.lifetime = 0.45
	fl.local_coords = false
	fl.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	fl.emission_box_extents = Vector3(0.02, length * 0.42, 0.02)
	fl.position = Vector3(0, 0.1 + length * 0.55, 0)
	fl.direction = Vector3.UP
	fl.spread = 25.0
	fl.initial_velocity_min = 0.15
	fl.initial_velocity_max = 0.5
	fl.gravity = Vector3(0, 1.8, 0)
	fl.scale_amount_min = 0.14
	fl.scale_amount_max = 0.26
	fl.scale_amount_curve = _shrink()
	fl.mesh = _pmesh("flame", col, false)
	fl.color_ramp = _fade_ramp()
	fl.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	blade.add_child(fl)
	var sp := CPUParticles3D.new()
	sp.name = "BladeEmbers"
	sp.amount = _n(12)
	sp.lifetime = 0.8
	sp.local_coords = false
	sp.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	sp.emission_box_extents = Vector3(0.03, length * 0.46, 0.03)
	sp.position = Vector3(0, 0.1 + length * 0.55, 0)
	sp.direction = Vector3.UP
	sp.spread = 180.0
	sp.initial_velocity_min = 0.1
	sp.initial_velocity_max = 0.7
	sp.gravity = Vector3(0, 0.9, 0)
	sp.scale_amount_min = 0.03
	sp.scale_amount_max = 0.07
	sp.scale_amount_curve = _shrink()
	sp.mesh = _pmesh("ember", ember_col, true)
	sp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	blade.add_child(sp)
	fl.emitting = true
	sp.emitting = true


## Garis terjang (kotak tipis) dari -> ke, mengecil & memudar.
static func streak(parent: Node, from: Vector3, to: Vector3, col: Color, width: float, life: float) -> void:
	var d := to - from
	if d.length() < 0.1:
		return
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(width * 1.3, 0.04, 1.0)
	mi.mesh = bm
	var mat := Fx._unshaded(Color(col.r, col.g, col.b, 0.85), true)
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	mi.global_position = Vector3((from.x + to.x) * 0.5, 0.9, (from.z + to.z) * 0.5)
	mi.look_at(Vector3(to.x, 0.9, to.z), Vector3.UP)
	mi.scale = Vector3(1.0, 1.0, d.length())
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale:x", 0.1, life).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	t.tween_property(mat, "albedo_color:a", 0.0, life)
	t.chain().tween_callback(mi.queue_free)


## Retakan tanah memancar dari titik tumbukan (lapisan gelap + garis berpendar).
static func cracks(parent: Node, center: Vector3, radius: float, glow: Color, life: float = 0.6, n: int = 7) -> void:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var mats: Array = []
	for i in _n(n):
		var ang := TAU * float(i) / float(maxi(_n(n), 1)) + rng.randf_range(-0.25, 0.25)
		var ln := radius * rng.randf_range(0.6, 1.0)
		var dirv := Vector3(sin(ang), 0, cos(ang))
		for layer in 2:
			var mi := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(0.34 if layer == 0 else 0.12, 0.02, ln)
			mi.mesh = bm
			var c := Color(0.18, 0.12, 0.08) if layer == 0 else glow
			var mat := Fx._unshaded(Color(c.r, c.g, c.b, 0.9), layer == 1)
			mi.material_override = mat
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			parent.add_child(mi)
			mi.global_position = Vector3(center.x, 0.09 + 0.01 * layer, center.z) + dirv * (ln * 0.5)
			mi.rotation.y = ang
			mi.scale = Vector3(1.0, 1.0, 0.2)
			var t := mi.create_tween()
			t.set_parallel(true)
			t.tween_property(mi, "scale:z", 1.0, life * 0.25).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
			t.tween_property(mat, "albedo_color:a", 0.0, life * 0.6).set_delay(life * 0.4)
			t.chain().tween_callback(mi.queue_free)


## Cakram datar gelap di tanah (bekas hangus) yang memudar.
static func scorch(parent: Node, pos: Vector3, radius: float, life: float = 0.9) -> void:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.0
	cm.bottom_radius = 1.0
	cm.height = 0.02
	cm.radial_segments = 20
	cm.rings = 1
	mi.mesh = cm
	var mat := Fx._unshaded(Color(0.2, 0.08, 0.04, 0.26), false)
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	mi.global_position = Vector3(pos.x, 0.06, pos.z)
	mi.scale = Vector3(radius * 0.4, 1.0, radius * 0.4)
	var t := mi.create_tween()
	t.set_parallel(true)
	t.tween_property(mi, "scale", Vector3(radius, 1.0, radius), life * 0.25).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	t.tween_property(mat, "albedo_color:a", 0.0, life).set_delay(life * 0.2)
	t.chain().tween_callback(mi.queue_free)


## Kilatan "X" kecil (dua batang menyilang) di titik kena.
static func x_flash(parent: Node, pos: Vector3, col: Color, size: float, life: float = 0.16) -> void:
	var root := Node3D.new()
	parent.add_child(root)
	root.global_position = pos
	var mats: Array = []
	for i in 2:
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.07, size, 0.07)
		mi.mesh = bm
		var mat := Fx._unshaded(Color(col.r, col.g, col.b, 1.0), true)
		mi.material_override = mat
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.rotation.z = deg_to_rad(45.0 if i == 0 else -45.0)
		root.add_child(mi)
		mats.append(mat)
	root.scale = Vector3.ONE * 0.4
	var t := root.create_tween()
	t.set_parallel(true)
	t.tween_property(root, "scale", Vector3.ONE * 1.3, life).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	for m in mats:
		t.tween_property(m, "albedo_color:a", 0.0, life)
	t.chain().tween_callback(root.queue_free)


static func _later(parent: Node, delay: float, fn: Callable) -> void:
	if parent == null or not parent.is_inside_tree():
		return
	parent.get_tree().create_timer(delay).timeout.connect(func():
		if is_instance_valid(parent):
			fn.call())


static func _ring_pts(center: Vector3, r: float, n: int) -> Array:
	var out: Array = []
	for i in n:
		var a := TAU * float(i) / float(n)
		out.append(center + Vector3(sin(a), 0, cos(a)) * r)
	return out


# ---------------------------------------------------------------- api biru (Hakuya)
const BLUE := Color(0.18, 0.46, 1.0)
const BLUE_LIGHT := Color(0.62, 0.84, 1.0)


## Semburan lidah api biru yang naik (inti pucat + badan biru tua).
static func blue_flames(parent: Node, pos: Vector3, s: float = 1.0, life: float = 0.9) -> void:
	puff(parent, pos, BLUE, 6, 1.0 * s, 0.9 * s, Vector3.UP, 20.0, 3.0, life, "flame", false)
	puff(parent, pos + Vector3(0, 0.05, 0), BLUE_LIGHT, 4, 1.3 * s, 0.55 * s, Vector3.UP, 16.0, 4.0, life * 0.8, "flame", true)


## Kobaran api biru di tanah yang menyala sebentar (tiga gelombang nyala) + cincin tipis.
static func blue_fire_patch(parent: Node, pos: Vector3, radius: float, waves: int = 2) -> void:
	waves = 1 if _q() == 0 else waves
	Fx.ring(parent, pos, radius, BLUE_LIGHT, 0.5)
	for w in waves:
		var fn := func():
			for pt in _ring_pts(pos, radius * 0.75, 3):
				puff(parent, pt + Vector3(0, 0.1, 0), BLUE, 5, 1.0, 0.85, Vector3.UP, 20.0, 3.0, 0.8, "flame", false)
			blue_flames(parent, pos + Vector3(0, 0.1, 0), 1.3, 0.9)
		if w == 0:
			fn.call()
		else:
			_later(parent, 0.3 * w, fn)


## Aura api biru yang menyala terus di kaki Hakuya (dipasang ke pemain saat karakter dipilih; id lain: aura dilepas).
## Warna & bentuk partikel aura per karakter (kosong = tanpa aura).
static func _aura_cfg(id: String) -> Dictionary:
	match id:
		"hakuya": return {"kind": "flame", "kind2": "flame", "a": BLUE, "b": BLUE_LIGHT}
		"vael": return {"kind": "flame", "kind2": "spark", "a": Color(0.1, 0.75, 1.0), "b": Color(0.75, 0.98, 1.0)}
		"lucien": return {"kind": "ember", "kind2": "ember", "a": Color(0.8, 0.6, 0.2), "b": Color(1.0, 0.9, 0.55)}
		"wenyu": return {"kind": "leaf", "kind2": "leaf", "a": Color(0.8, 0.78, 0.95), "b": Color(0.7, 0.95, 0.85)}
		"kuroha": return {"kind": "sphere", "kind2": "ember", "a": Color(0.18, 0.14, 0.32), "b": Color(0.85, 0.85, 1.0)}
		"aion": return {"kind": "spark", "kind2": "sphere", "a": Color(0.5, 0.72, 1.0), "b": Color(0.85, 0.78, 1.0)}
		"kyomu": return {"kind": "sphere", "kind2": "ember", "a": Color(0.4, 0.16, 0.8), "b": Color(0.85, 0.72, 1.0)}
		"kiriel": return {"kind": "spark", "kind2": "spark", "a": Color(1.0, 0.88, 0.25), "b": Color(1.0, 0.98, 0.8)}
	return {}


static func attach_aura(host: Node3D, id: String) -> void:
	var old := host.get_node_or_null("CharAura")
	if old != null:
		host.remove_child(old)
		old.queue_free()
	var cfg := _aura_cfg(id)
	if cfg.is_empty():
		return
	var root := Node3D.new()
	root.name = "CharAura"
	host.add_child(root)
	root.position = Vector3(0, 0.12, 0)
	var outer := CPUParticles3D.new()
	outer.amount = _n(12)
	outer.lifetime = 0.95
	outer.local_coords = false
	outer.emission_shape = CPUParticles3D.EMISSION_SHAPE_RING
	outer.emission_ring_axis = Vector3.UP
	outer.emission_ring_height = 0.05
	outer.emission_ring_radius = 0.55
	outer.emission_ring_inner_radius = 0.25
	outer.direction = Vector3.UP
	outer.spread = 14.0
	outer.initial_velocity_min = 0.2
	outer.initial_velocity_max = 0.6
	outer.gravity = Vector3(0, 2.2, 0)
	outer.scale_amount_min = 0.3
	outer.scale_amount_max = 0.6
	outer.scale_amount_curve = _shrink()
	outer.mesh = _pmesh(cfg["kind"], cfg["a"], false)
	outer.color_ramp = _fade_ramp()
	outer.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(outer)
	var core := CPUParticles3D.new()
	core.amount = _n(8)
	core.lifetime = 0.7
	core.local_coords = false
	core.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	core.emission_sphere_radius = 0.3
	core.direction = Vector3.UP
	core.spread = 20.0
	core.initial_velocity_min = 0.6
	core.initial_velocity_max = 1.5
	core.gravity = Vector3(0, 3.5, 0)
	core.scale_amount_min = 0.3
	core.scale_amount_max = 0.55
	core.scale_amount_curve = _shrink()
	core.mesh = _pmesh(cfg["kind2"], cfg["b"], true)
	core.color_ramp = _fade_ramp()
	core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(core)
	outer.emitting = true
	core.emitting = true


# ---------------------------------------------------------------- serangan biasa
## Tebasan pedang/belati (attack_kind arc & dagger). idx = urutan pukulan dalam kombo, final = penutup.
static func attack_slash(parent: Node, id: String, pos: Vector3, yaw: float, rng: float, col: Color, idx: int, final: bool) -> void:
	var fwd := Vector3(sin(yaw), 0, cos(yaw))
	var flip := idx % 2 == 0
	match id:
		"ren":
			var ice := Color(0.55, 0.85, 1.0)
			Fx.slash(parent, pos, yaw, rng, 75.0, ice, 0.2, flip, 0.16)
			crescent(parent, pos, yaw, rng * 1.05, ice, 0.22, 48.0 if flip else -48.0, flip, 110.0, 0.22)
			puff(parent, pos + fwd * rng * 0.7 + Vector3(0, 1.0, 0), Color(0.85, 0.96, 1.0), 6, 2.5, 0.12, fwd + Vector3(0, 0.2, 0), 70.0, -1.0, 0.55)
		"zeya":
			var pink := Color(1.0, 0.45, 0.65)
			var shadow := Color(0.42, 0.18, 0.7)
			if final:
				Fx.slash(parent, pos, yaw, rng * 1.15, 120.0, pink, 0.26, true, 0.16)
				crescent(parent, pos, yaw, rng * 1.2, pink, 0.26, 55.0, true, 130.0, 0.2)
				crescent(parent, pos, yaw, rng * 1.2, pink.lightened(0.25), 0.26, -55.0, false, 130.0, 0.2)
				Fx.ring(parent, pos, rng * 1.15, shadow, 0.3)
				puff(parent, pos + fwd * rng * 0.5 + Vector3(0, 1.0, 0), Color(1.0, 0.6, 0.78), 14, 6.0, 0.14, fwd + Vector3(0, 0.3, 0), 75.0, -3.0, 0.65, "leaf", false)
			else:
				Fx.slash(parent, pos, yaw, rng, 55.0, pink, 0.14, flip, 0.14)
				crescent(parent, pos, yaw, rng * 1.1, shadow, 0.2, 28.0 if flip else -28.0, flip, 95.0, 0.34, 0.45)     # bayangan di belakang
				crescent(parent, pos, yaw, rng * 1.05, pink, 0.14, 28.0 if flip else -28.0, flip, 90.0, 0.14)
		"vael":
			var cy := Color(0.2, 0.85, 1.0)
			var wh := Color(0.85, 0.97, 1.0)
			if final:
				Fx.slash(parent, pos, yaw, rng * 1.2, 110.0, cy, 0.3, flip, 0.2)
				crescent(parent, pos, yaw, rng * 1.3, cy, 0.34, 50.0 if flip else -50.0, flip, 140.0, 0.42, 0.5, 1.1, true)
				crescent(parent, pos, yaw, rng * 1.25, wh, 0.26, 50.0 if flip else -50.0, flip, 135.0, 0.24, 0.5, 1.1, true)
				Fx.ring(parent, pos + fwd * rng * 0.6, rng * 0.5, cy, 0.32)
				spark_lines(parent, pos + fwd * rng * 0.7 + Vector3(0, 1.0, 0), fwd, wh, 10, 11.0, 80.0, 0.22)
				embers(parent, pos + fwd * rng * 0.6 + Vector3(0, 1.0, 0), cy, 12, 70.0, 3.0, 0.9, fwd + Vector3(0, 0.15, 0))
			else:
				Fx.slash(parent, pos, yaw, rng, 90.0, cy, 0.22, flip, 0.18)
				crescent(parent, pos, yaw, rng * 1.15, cy, 0.28, 40.0 if flip else -40.0, flip, 120.0, 0.36, 0.5, 1.1, true)
				crescent(parent, pos, yaw, rng * 1.1, wh, 0.2, 40.0 if flip else -40.0, flip, 112.0, 0.2, 0.5, 1.1, true)
				embers(parent, pos + fwd * rng * 0.6 + Vector3(0, 1.0, 0), cy, 6, 70.0, 2.5, 0.8, fwd + Vector3(0, 0.15, 0))
		"kuroha":
			var ink := Color(0.14, 0.1, 0.28)
			var sil := Color(0.9, 0.93, 1.0)
			if final:
				Fx.slash(parent, pos, yaw, rng * 1.15, 95.0, sil, 0.22, flip, 0.12)
				crescent(parent, pos, yaw, rng * 1.25, ink, 0.34, 55.0 if flip else -55.0, flip, 125.0, 0.4, 0.5, 1.1, true)
				crescent(parent, pos, yaw, rng * 1.2, sil, 0.22, 55.0 if flip else -55.0, flip, 120.0, 0.18, 0.5, 1.1, true)
				puff(parent, pos + fwd * rng * 0.6 + Vector3(0, 1.0, 0), ink, 10, 5.0, 0.4, fwd, 60.0, 1.0, 0.6, "sphere", false)
				spark_lines(parent, pos + fwd * rng * 0.6 + Vector3(0, 1.0, 0), fwd, sil, 8, 10.0, 70.0, 0.2)
			else:
				Fx.slash(parent, pos, yaw, rng, 50.0, sil, 0.14, flip, 0.1)
				crescent(parent, pos, yaw, rng * 1.15, ink, 0.24, 32.0 if flip else -32.0, flip, 105.0, 0.3, 0.5, 1.1, true)
				crescent(parent, pos, yaw, rng * 1.1, sil, 0.16, 32.0 if flip else -32.0, flip, 100.0, 0.14, 0.5, 1.1, true)
		"kyomu":
			var pu := Color(0.55, 0.25, 1.0)
			var lav := Color(0.88, 0.8, 1.0)
			var dk := Color(0.16, 0.06, 0.38)
			if final:
				# penutup kombo: silang dua bulan sabit ungu + cincin bayangan + serpihan kristal
				Fx.slash(parent, pos, yaw, rng * 1.15, 125.0, lav, 0.26, true, 0.14)
				crescent(parent, pos, yaw, rng * 1.25, pu, 0.3, 55.0, true, 130.0, 0.36, 0.5, 1.1, true)
				crescent(parent, pos, yaw, rng * 1.25, lav, 0.24, -55.0, false, 130.0, 0.2, 0.5, 1.1, true)
				Fx.ring(parent, pos, rng * 1.1, dk, 0.3)
				puff(parent, pos + fwd * rng * 0.5 + Vector3(0, 1.0, 0), pu, 10, 6.0, 0.14, fwd + Vector3(0, 0.3, 0), 75.0, -3.0, 0.6, "shard", false)
				spark_lines(parent, pos + fwd * rng * 0.7 + Vector3(0, 1.0, 0), fwd, lav, 10, 11.0, 80.0, 0.22)
				embers(parent, pos + fwd * rng * 0.6 + Vector3(0, 1.0, 0), pu, 14, 70.0, 3.0, 1.0, fwd + Vector3(0, 0.15, 0))
			else:
				Fx.slash(parent, pos, yaw, rng, 60.0, pu, 0.15, flip, 0.12)
				crescent(parent, pos, yaw, rng * 1.1, pu, 0.22, 34.0 if flip else -34.0, flip, 105.0, 0.3, 0.5, 1.1, true)
				crescent(parent, pos, yaw, rng * 1.05, lav, 0.16, 34.0 if flip else -34.0, flip, 100.0, 0.14, 0.5, 1.1, true)
				embers(parent, pos + fwd * rng * 0.6 + Vector3(0, 1.0, 0), pu, 6, 70.0, 2.5, 0.8, fwd + Vector3(0, 0.15, 0))
		"hakuya":
			var moon := Color(0.92, 0.96, 1.0)
			var flame := Color(0.3, 0.62, 1.0)
			if final:
				# penutup kombo: tebasan iai panjang + garis lurus + api biru tipis
				Fx.slash(parent, pos, yaw, rng * 1.15, 70.0, moon, 0.24, flip, 0.12)
				crescent(parent, pos, yaw, rng * 1.3, flame, 0.32, 62.0 if flip else -62.0, flip, 120.0, 0.36, 0.55, 1.1, true)
				crescent(parent, pos, yaw, rng * 1.25, moon, 0.26, 62.0 if flip else -62.0, flip, 112.0, 0.22, 0.55, 1.1, true)
				streak(parent, pos + fwd * 0.5, pos + fwd * rng * 1.3, moon, 0.12, 0.28)
				spark_lines(parent, pos + fwd * rng * 0.7 + Vector3(0, 1.0, 0), fwd, BLUE_LIGHT, 10, 11.0, 70.0, 0.22)
				embers(parent, pos + fwd * rng * 0.6 + Vector3(0, 1.0, 0), Color(0.5, 0.82, 1.0), 14, 70.0, 3.0, 1.0, fwd + Vector3(0, 0.15, 0))
			else:
				Fx.slash(parent, pos, yaw, rng, 45.0, moon, 0.16, flip, 0.1)
				crescent(parent, pos, yaw, rng * 1.15, moon, 0.2, 35.0 if flip else -35.0, flip, 105.0, 0.3, 0.5, 1.1, true)
				crescent(parent, pos, yaw, rng * 1.2, flame, 0.24, 35.0 if flip else -35.0, flip, 110.0, 0.4, 0.5, 1.1, true)
				embers(parent, pos + fwd * rng * 0.6 + Vector3(0, 1.0, 0), Color(0.5, 0.82, 1.0), 8, 70.0, 2.5, 0.9, fwd + Vector3(0, 0.15, 0))
		"kiriel":
			# wujud Pedang Petir: tebasan kuning-putih + sambaran zig-zag sepanjang tebasan; penutup kombo lebih lebar dengan hantaman petir
			var yel := Color(1.0, 0.9, 0.3)
			var wht := Color(1.0, 0.98, 0.85)
			Fx.slash(parent, pos, yaw, rng, 90.0 if final else 70.0, wht, 0.2, flip, 0.12)
			crescent(parent, pos, yaw, rng * 1.15, yel, 0.24, 45.0 if flip else -45.0, flip, 115.0, 0.3, 0.5, 1.1, true)
			var c0 := pos + Vector3(0, 1.0, 0)
			StormFx.bolt(parent, c0 + fwd * 0.5, c0 + fwd * rng * (1.3 if final else 1.1) + fwd.cross(Vector3.UP) * (0.4 if flip else -0.4), yel, 0.16, 0.25, 4)
			if final:
				StormFx.strike(parent, pos + fwd * rng * 0.9, yel)
		_:
			Fx.slash(parent, pos, yaw, rng, 75.0, col, 0.22, flip)


## Hantaman Guardian: retakan tanah + debu + pecahan batu di titik jatuh.
static func attack_smash(parent: Node, id: String, pos: Vector3, yaw: float, rng: float, col: Color, idx: int) -> void:
	if id != "brann":
		Fx.slash(parent, pos, yaw, rng, 100.0, col, 0.3, idx % 2 == 0)
		return
	var fwd := Vector3(sin(yaw), 0, cos(yaw))
	var ip := pos + fwd * rng * 0.7
	var big := idx % 3 == 2                                    # pukulan ke-3 = hantaman penutup lebih besar
	var k := 1.35 if big else 1.0
	Fx.slash(parent, pos, yaw, rng, 100.0, Color(1.0, 0.6, 0.3), 0.26, idx % 2 == 0, 0.14)
	cracks(parent, ip, rng * 0.95 * k, Color(1.0, 0.55, 0.2), 0.8, 9 if big else 7)
	Fx.ring(parent, ip, rng * 0.8 * k, Color(1.0, 0.7, 0.4), 0.32)
	Fx.ring(parent, ip, rng * 0.45 * k, Color(1, 0.9, 0.7), 0.2)
	# awan debu membesar keluar + gumpalan gelap yang naik
	puff(parent, ip + Vector3(0, 0.2, 0), Color(0.74, 0.65, 0.5), int(10 * k), 4.2, 0.6, Vector3.UP, 85.0, -0.8, 0.85, "sphere", false)
	puff(parent, ip + Vector3(0, 0.3, 0), Color(0.5, 0.44, 0.38), int(5 * k), 2.2, 0.7, Vector3.UP, 40.0, 1.0, 1.0, "sphere", false)
	# pecahan batu besar terlempar ke atas & depan, jatuh oleh gravitasi
	puff(parent, ip + Vector3(0, 0.2, 0), Color(0.42, 0.37, 0.33), int(9 * k), 8.5, 0.22, fwd * 0.4 + Vector3(0, 1.0, 0), 60.0, -22.0, 0.9, "chip", false)
	puff(parent, ip + Vector3(0, 0.2, 0), Color(0.6, 0.52, 0.42), int(6 * k), 6.0, 0.15, Vector3.UP, 75.0, -20.0, 0.8, "chip", false)
	# percikan kuning-oranye dari benturan logam ke batu
	spark_lines(parent, ip + Vector3(0, 0.3, 0), Vector3.UP, Color(1.0, 0.8, 0.4), int(10 * k), 9.0, 80.0, 0.2, 0.8)
	# gelombang debu susulan (tanah masih bergetar)
	_later(parent, 0.12, func(): Fx.ring(parent, ip, rng * 1.05 * k, Color(0.8, 0.7, 0.55), 0.35))
	_later(parent, 0.14, func(): puff(parent, ip + Vector3(0, 0.15, 0), Color(0.7, 0.62, 0.48), int(6 * k), 5.0, 0.4, Vector3.UP, 88.0, -0.5, 0.7, "sphere", false))


# ---------------------------------------------------------------- skill
## Skill tebasan kerucut (Ren). Karakter lain jatuh ke efek umum.
static func skill_cone(parent: Node, id: String, pos: Vector3, yaw: float, rng: float, col: Color) -> void:
	if id == "vael":
		var fwd2 := Vector3(sin(yaw), 0, cos(yaw))
		var cy := Color(0.2, 0.85, 1.0)
		var wh := Color(0.88, 0.98, 1.0)
		Fx.slash(parent, pos, yaw, rng, 95.0, cy, 0.34, false, 0.22)
		crescent(parent, pos, yaw, rng, cy, 0.36, 40.0, false, 140.0, 0.46, 0.5, 1.1, true)
		_later(parent, 0.06, func(): crescent(parent, pos + fwd2 * rng * 0.3, yaw, rng * 0.9, wh, 0.3, -40.0, true, 140.0, 0.3, 0.5, 1.1, true))
		_later(parent, 0.12, func(): crescent(parent, pos + fwd2 * rng * 0.55, yaw, rng * 0.8, cy, 0.3, 40.0, false, 140.0, 0.36, 0.5, 1.1, true))
		streak(parent, pos + fwd2 * 0.6, pos + fwd2 * rng, wh, 0.5, 0.32)
		Fx.ring(parent, pos + fwd2 * rng * 0.5, rng * 0.4, cy, 0.4)
		spark_lines(parent, pos + fwd2 * rng * 0.5 + Vector3(0, 1.0, 0), fwd2, wh, 14, 14.0, 60.0, 0.28, 1.0)
		puff(parent, pos + fwd2 * rng * 0.5 + Vector3(0, 0.5, 0), cy, 6, 2.5, 0.6, fwd2, 40.0, 1.5, 0.6, "flame", false)
		embers(parent, pos + fwd2 * rng * 0.5 + Vector3(0, 0.9, 0), cy, 14, 70.0, 3.5, 1.0, fwd2 + Vector3(0, 0.15, 0))
		return
	if id != "ren":
		Fx.slash(parent, pos, yaw, rng, 85.0, col, 0.3)
		return
	var fwd := Vector3(sin(yaw), 0, cos(yaw))
	var ice := Color(0.5, 0.85, 1.0)
	var gold := Color(1.0, 0.85, 0.45)
	Fx.slash(parent, pos, yaw, rng, 85.0, gold, 0.32, false, 0.2)
	crescent(parent, pos, yaw, rng, ice, 0.3, 38.0, false, 130.0, 0.2, 0.5)
	_later(parent, 0.07, func(): crescent(parent, pos, yaw, rng * 0.9, gold, 0.28, -38.0, true, 130.0, 0.2, 0.5))
	streak(parent, pos + fwd * 0.6, pos + fwd * rng, gold, 0.35, 0.3)
	puff(parent, pos + fwd * rng * 0.5 + Vector3(0, 0.9, 0), Color(0.9, 0.97, 1.0), 16, 5.0, 0.13, fwd + Vector3(0, 0.3, 0), 70.0, -1.2, 0.8)
	puff(parent, pos + fwd * rng * 0.4 + Vector3(0, 0.9, 0), ice, 8, 7.0, 0.14, fwd, 40.0, -12.0, 0.5, "shard", false)


## Skill iai (Hakuya). phase 0 = tebasan lurus sangat panjang (cabut pedang), phase 1 = tebasan lebar penutup + api biru.
static func skill_iai(parent: Node, id: String, pos: Vector3, yaw: float, rng: float, col: Color, phase: int) -> void:
	if id != "hakuya":
		Fx.slash(parent, pos, yaw, rng, 60.0, col, 0.25, phase == 0)
		return
	var fwd := Vector3(sin(yaw), 0, cos(yaw))
	var moon := Color(0.94, 0.97, 1.0)
	var flame := Color(0.25, 0.55, 1.0)
	if phase == 0:
		streak(parent, pos + fwd * 0.4, pos + fwd * rng, moon, 0.42, 0.3)
		streak(parent, pos + fwd * 0.4, pos + fwd * rng, flame, 0.9, 0.38)
		crescent(parent, pos, yaw, rng * 0.8, moon, 0.26, 8.0, false, 60.0, 0.3, 0.6, 1.1, true)
		spark_lines(parent, pos + fwd * rng * 0.5 + Vector3(0, 0.9, 0), fwd, BLUE_LIGHT, 14, 16.0, 12.0, 0.3, 1.1)
		embers(parent, pos + fwd * rng * 0.5 + Vector3(0, 0.9, 0), Color(0.5, 0.82, 1.0), 16, 70.0, 3.0, 1.1, fwd + Vector3(0, 0.15, 0))
		puff(parent, pos + fwd * 1.0 + Vector3(0, 0.9, 0), flame, 6, 2.5, 0.5, fwd, 35.0, 1.5, 0.6, "flame", false)
		for i in 2:
			blue_flames(parent, pos + fwd * (2.0 + i * rng * 0.35) + Vector3(0, 0.15, 0), 0.9, 0.9)
	else:
		Fx.slash(parent, pos, yaw, rng * 0.7, 80.0, moon, 0.26, true, 0.14)
		crescent(parent, pos, yaw, rng * 0.8, flame, 0.34, 50.0, true, 150.0, 0.4, 0.5, 1.1, true)
		crescent(parent, pos, yaw, rng * 0.76, moon, 0.28, -50.0, false, 150.0, 0.26, 0.5, 1.1, true)
		spark_lines(parent, pos + fwd * rng * 0.4 + Vector3(0, 1.0, 0), fwd, BLUE_LIGHT, 18, 12.0, 70.0, 0.25, 1.0)
		Fx.ring(parent, pos + fwd * rng * 0.35, rng * 0.4, flame, 0.4)
		for i in 5:
			var pt := pos + fwd * (1.2 + i * rng * 0.13)
			puff(parent, pt + Vector3(0, 0.2, 0), flame, 4, 1.4, 0.7, Vector3.UP, 25.0, 3.0, 0.7, "flame", false)
		embers(parent, pos + fwd * rng * 0.4 + Vector3(0, 0.6, 0), Color(0.5, 0.82, 1.0), 22, 70.0, 4.0, 1.2, fwd + Vector3(0, 0.15, 0))
		blue_fire_patch(parent, pos + fwd * rng * 0.45, rng * 0.38)


## Skill menerjang (Zeya). phase 0 = awal terjang, phase 1 = tebasan penutup setelah menerjang.
static func skill_dash(parent: Node, id: String, pos: Vector3, yaw: float, rng: float, col: Color, phase: int) -> void:
	if id == "kuroha":
		var kf := Vector3(sin(yaw), 0, cos(yaw))
		var ink := Color(0.14, 0.1, 0.28)
		var sil := Color(0.92, 0.95, 1.0)
		if phase == 0:
			Fx.slash(parent, pos, yaw, rng, 60.0, sil, 0.2, true, 0.12)
			streak(parent, pos, pos + kf * rng, ink, 1.0, 0.42)
			streak(parent, pos, pos + kf * rng * 0.9, sil, 0.3, 0.3)
			puff(parent, pos + Vector3(0, 0.6, 0), ink, 10, 2.2, 0.55, Vector3.UP, 180.0, 1.0, 0.7, "sphere", false)
		else:
			Fx.slash(parent, pos, yaw, rng, 70.0, sil, 0.2, false, 0.12)
			crescent(parent, pos, yaw, rng, ink, 0.28, 55.0, true, 135.0, 0.34, 0.5, 1.1, true)
			crescent(parent, pos, yaw, rng, sil, 0.24, -55.0, false, 135.0, 0.2, 0.5, 1.1, true)
			x_flash(parent, pos + kf * rng * 0.5 + Vector3(0, 1.0, 0), sil, 1.7, 0.2)
			puff(parent, pos + kf * rng * 0.5 + Vector3(0, 1.0, 0), ink, 12, 5.0, 0.35, Vector3.UP, 180.0, -1.0, 0.7, "sphere", false)
			spark_lines(parent, pos + kf * rng * 0.5 + Vector3(0, 1.0, 0), kf, sil, 10, 11.0, 150.0, 0.22)
		return
	if id == "kyomu":
		var kf2 := Vector3(sin(yaw), 0, cos(yaw))
		var pu2 := Color(0.55, 0.25, 1.0)
		var lav2 := Color(0.9, 0.84, 1.0)
		var dk2 := Color(0.14, 0.05, 0.34)
		if phase == 0:
			Fx.slash(parent, pos, yaw, rng, 60.0, lav2, 0.2, true, 0.12)
			streak(parent, pos, pos + kf2 * rng, dk2, 1.0, 0.42)
			streak(parent, pos, pos + kf2 * rng * 0.9, pu2, 0.34, 0.32)
			puff(parent, pos + Vector3(0, 0.6, 0), pu2, 10, 2.2, 0.5, Vector3.UP, 180.0, 1.0, 0.7, "sphere", false)
		else:
			Fx.slash(parent, pos, yaw, rng, 75.0, lav2, 0.2, false, 0.12)
			crescent(parent, pos, yaw, rng, pu2, 0.3, 55.0, true, 135.0, 0.36, 0.5, 1.1, true)
			crescent(parent, pos, yaw, rng, lav2, 0.24, -55.0, false, 135.0, 0.2, 0.5, 1.1, true)
			x_flash(parent, pos + kf2 * rng * 0.5 + Vector3(0, 1.0, 0), lav2, 1.8, 0.2)
			puff(parent, pos + kf2 * rng * 0.5 + Vector3(0, 1.0, 0), dk2, 12, 5.0, 0.35, Vector3.UP, 180.0, -1.0, 0.7, "sphere", false)
			spark_lines(parent, pos + kf2 * rng * 0.5 + Vector3(0, 1.0, 0), kf2, lav2, 10, 11.0, 150.0, 0.22)
			embers(parent, pos + kf2 * rng * 0.5 + Vector3(0, 1.0, 0), pu2, 14, 180.0, 3.0, 1.0)
		return
	if id != "zeya":
		Fx.slash(parent, pos, yaw, rng, 70.0, col, 0.2, phase == 0)
		return
	var fwd := Vector3(sin(yaw), 0, cos(yaw))
	var pink := Color(1.0, 0.45, 0.65)
	var shadow := Color(0.4, 0.16, 0.62)
	if phase == 0:
		Fx.slash(parent, pos, yaw, rng, 70.0, pink, 0.2, true, 0.14)
		streak(parent, pos, pos + fwd * rng, pink, 0.55, 0.32)
		streak(parent, pos + Vector3(0.0, 0.0, 0.0), pos + fwd * rng * 0.8, shadow, 0.9, 0.4)
		puff(parent, pos + Vector3(0, 0.6, 0), shadow, 10, 2.2, 0.55, Vector3.UP, 180.0, 1.0, 0.7, "sphere", false)    # asap bayangan di titik awal
		crescent(parent, pos, yaw, rng, pink, 0.2, 30.0, true, 100.0, 0.16)
	else:
		Fx.slash(parent, pos, yaw, rng, 70.0, pink.lightened(0.3), 0.2, false, 0.14)
		crescent(parent, pos, yaw, rng, pink, 0.24, 55.0, true, 130.0, 0.18)
		crescent(parent, pos, yaw, rng, pink.lightened(0.3), 0.24, -55.0, false, 130.0, 0.18)
		x_flash(parent, pos + fwd * rng * 0.5 + Vector3(0, 1.0, 0), Color(1.0, 0.75, 0.85), 1.6, 0.2)
		puff(parent, pos + Vector3(0, 1.0, 0), Color(1.0, 0.6, 0.78), 16, 7.0, 0.14, Vector3.UP, 180.0, -4.0, 0.7, "leaf", false)


## Skill gempa/lingkaran: Brann = retakan tanah & debu; Ember = lingkaran api & bekas hangus.
static func skill_shockwave(parent: Node, id: String, pos: Vector3, yaw: float, rng: float, col: Color) -> void:
	if id == "ember":
		var fire := Color(1.0, 0.5, 0.15)
		Fx.ring(parent, pos, rng, fire, 0.55)
		Fx.ring(parent, pos, rng * 0.62, Color(1.0, 0.85, 0.4), 0.4)
		scorch(parent, pos, rng * 0.95, 1.1)
		for pt in _ring_pts(pos, rng * 0.85, 10):
			puff(parent, pt + Vector3(0, 0.15, 0), fire, 4, 2.6, 0.55, Vector3.UP, 25.0, 3.5, 0.75, "sphere", false)
		puff(parent, pos + Vector3(0, 0.3, 0), Color(1.0, 0.8, 0.3), 14, 5.5, 0.3, Vector3.UP, 70.0, 2.5, 0.8, "sphere", false)
		puff(parent, pos + Vector3(0, 0.8, 0), Color(0.25, 0.2, 0.2), 5, 2.0, 0.6, Vector3.UP, 40.0, 2.0, 1.0, "sphere", false)     # asap
	elif id == "brann":
		Fx.ring(parent, pos, rng, Color(1.0, 0.65, 0.3), 0.55)
		Fx.ring(parent, pos, rng * 0.65, Color(0.75, 0.62, 0.45), 0.4)
		cracks(parent, pos, rng * 0.95, Color(1.0, 0.55, 0.2), 0.9, 10)
		for pt in _ring_pts(pos, rng * 0.75, 8):
			puff(parent, pt + Vector3(0, 0.2, 0), Color(0.72, 0.62, 0.48), 2, 2.2, 0.6, Vector3.UP, 60.0, -1.0, 0.8, "sphere", false)
		puff(parent, pos + Vector3(0, 0.3, 0), Color(0.45, 0.4, 0.36), 12, 9.0, 0.2, Vector3.UP, 55.0, -20.0, 0.8, "chip", false)
	else:
		Fx.ring(parent, pos, rng, col, 0.55)
		Fx.slash(parent, pos, yaw, rng * 0.8, 90.0, col, 0.3)


## Skill Vortex (Kyomu): tiga lapis cincin bilah ungu/lavender berputar berlawanan arah di sekitar pemain (naik ke atas seperti pusaran),
## cincin tanah, kabut bayangan, dan bara yang terhisap naik. Hidup ~0,95 dtk lalu menyusut. Sekitar 30 node, tanpa partikel berat.
static func skill_vortex(parent: Node, id: String, pos: Vector3, rng: float, life: float = 0.95) -> void:
	var pu := Color(0.55, 0.25, 1.0)
	var lav := Color(0.9, 0.84, 1.0)
	var dk := Color(0.14, 0.05, 0.34)
	var root := Node3D.new()
	root.name = "VortexFx"
	parent.add_child(root)
	root.global_position = Vector3(pos.x, 0.0, pos.z)
	var layers := [[0.42, 0.3, 10, pu, 1.0], [0.68, 0.95, 8, lav, -1.0], [0.92, 1.6, 7, pu, 1.0], [0.6, 2.2, 5, lav, -1.0]]
	for li in layers.size():
		var ly: Array = layers[li]
		var ring := Node3D.new()
		ring.position.y = float(ly[1])
		root.add_child(ring)
		var n: int = ly[2]
		for i in n:
			var a := TAU * float(i) / float(n)
			var mi := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(0.1, 0.045, rng * 0.34)
			mi.mesh = bm
			mi.material_override = Fx._unshaded(ly[3], true)
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			ring.add_child(mi)
			mi.position = Vector3(cos(a), 0.0, sin(a)) * rng * float(ly[0])
			mi.rotation = Vector3(0.3, -a, 0.0)
		var rt := ring.create_tween()
		rt.tween_property(ring, "rotation:y", TAU * 2.2 * float(ly[4]) * maxf(life / 0.95, 1.0), life)
	var tw := root.create_tween()
	tw.tween_property(root, "scale", Vector3.ONE, 0.18).from(Vector3(0.35, 0.6, 0.35))
	tw.tween_interval(maxf(life - 0.33, 0.1))
	tw.tween_property(root, "scale", Vector3(1.15, 0.02, 1.15), 0.15)
	tw.tween_callback(root.queue_free)
	Fx.ring(parent, Vector3(pos.x, 0.1, pos.z), rng * 0.5, pu, 0.3)
	_later(parent, 0.2, func(): Fx.ring(parent, Vector3(pos.x, 0.1, pos.z), rng * 0.85, lav, 0.35))
	_later(parent, 0.4, func(): Fx.ring(parent, Vector3(pos.x, 0.1, pos.z), rng, dk, 0.4))
	puff(parent, pos + Vector3(0, 0.8, 0), dk, 10, rng * 1.4, 0.5, Vector3.UP, 180.0, 1.0, 0.7, "sphere", false)
	embers(parent, pos + Vector3(0, 0.4, 0), pu, 16, 180.0, 4.0, 1.0, Vector3.UP)
	x_flash(parent, pos + Vector3(0, 1.0, 0), lav, 1.6, 0.2)


## Portal vortex ULT Kyomu: cakram gelap di tanah + pusaran bilah ungu setinggi ~2 m yang berputar selama `life` detik, dengan bara terhisap ke tengah.
static func vortex_portal(parent: Node, pos: Vector3, rng: float, life: float, tint: Color) -> void:
	var disk := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = rng
	cm.bottom_radius = rng
	cm.height = 0.03
	disk.mesh = cm
	disk.material_override = Fx._unshaded(Color(0.1, 0.03, 0.22, 0.85), false)
	disk.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(disk)
	disk.global_position = Vector3(pos.x, 0.05, pos.z)
	var dt := disk.create_tween()
	dt.tween_property(disk, "scale", Vector3.ONE, 0.2).from(Vector3(0.1, 1.0, 0.1))
	dt.tween_interval(maxf(life - 0.45, 0.1))
	dt.tween_property(disk, "scale", Vector3(0.05, 1.0, 0.05), 0.25)
	dt.tween_callback(disk.queue_free)
	skill_vortex(parent, "kyomu", pos, rng, life)
	Fx.ring(parent, Vector3(pos.x, 0.1, pos.z), rng, tint, 0.5)
	embers(parent, pos + Vector3(0, 0.3, 0), tint, 20, rng * 40.0, 3.0, 1.2, Vector3.UP)


## Tambahan Nova Bintang (Lyra): kerlip bintang naik di sekitar lingkaran.
static func skill_nova(parent: Node, id: String, pos: Vector3, rng: float, col: Color) -> void:
	if id == "wenyu":                                  # lagu: nota menyembur membentuk gelombang keluar, bukan lingkaran sihir
		var mint := Color(0.7, 1.0, 0.86)
		var pink := Color(1.0, 0.8, 0.95)
		UltFx.staff_lines(parent, pos, rng * 1.0, mint, 0.9)
		notes(parent, pos + Vector3(0, 0.5, 0), mint, 18, 7.5, 0.7, Vector3.UP, 85.0, 1.5, 1.1)
		notes(parent, pos + Vector3(0, 0.5, 0), pink, 12, 5.0, 0.6, Vector3.UP, 85.0, 1.0, 1.2)
		for pt in _ring_pts(pos, rng * 0.8, 4):
			notes(parent, pt + Vector3(0, 0.3, 0), mint if randi() % 2 == 0 else pink, 3, 2.5, 0.55, Vector3.UP, 30.0, 2.0, 1.0)
		puff(parent, pos + Vector3(0, 0.4, 0), Color(0.95, 0.97, 1.0), 6, 4.0, 0.15, Vector3.UP, 85.0, -1.0, 1.0, "leaf", false)
		return
	Fx.ring(parent, pos, rng, col.lightened(0.3), 0.5)
	Fx.ring(parent, pos, rng * 0.6, Color(1, 1, 1), 0.35)
	if id == "lyra":
		puff(parent, pos + Vector3(0, 0.4, 0), Color(1.0, 1.0, 1.0), 14, 6.0, 0.14, Vector3.UP, 85.0, -1.5, 1.0)
		puff(parent, pos + Vector3(0, 0.4, 0), Color(0.78, 0.55, 1.0), 14, 4.5, 0.18, Vector3.UP, 85.0, -1.0, 1.1, "sphere", false)
		for pt in _ring_pts(pos, rng * 0.8, 6):
			puff(parent, pt + Vector3(0, 0.3, 0), Color(0.9, 0.8, 1.0), 2, 3.0, 0.2, Vector3.UP, 20.0, 2.0, 0.9)
	else:
		Fx.burst(parent, pos + Vector3(0, 0.5, 0), col.lightened(0.5), 26, 7.0, 0.16)


## Awal Hujan Panah (Sera): cincin angin & daun di kaki.
static func skill_volley_start(parent: Node, id: String, pos: Vector3, col: Color) -> void:
	if id == "lucien":
		Fx.ring(parent, pos, 3.0, Color(0.9, 0.72, 0.3), 0.45)
		Fx.ring(parent, pos, 1.8, Color(0.25, 0.2, 0.35), 0.35)
		puff(parent, pos + Vector3(0, 0.6, 0), Color(0.2, 0.15, 0.3), 8, 3.0, 0.5, Vector3.UP, 180.0, 0.5, 0.8, "sphere", false)
		embers(parent, pos + Vector3(0, 0.6, 0), Color(1.0, 0.82, 0.4), 12, 180.0, 3.0, 1.0)
		return
	if id != "sera":
		return
	Fx.ring(parent, pos, 3.2, Color(0.7, 1.0, 0.7), 0.45)
	puff(parent, pos + Vector3(0, 0.6, 0), Color(0.5, 0.85, 0.4), 12, 5.0, 0.18, Vector3.UP, 180.0, -1.5, 0.9, "leaf", false)
	puff(parent, pos + Vector3(0, 0.5, 0), Color(1, 1, 1), 6, 4.0, 0.1, Vector3.UP, 180.0, 0.5, 0.6)


# ---------------------------------------------------------------- peluru
## Ganti tampilan peluru sesuai karakter (dipanggil sebelum peluru dimasukkan ke pohon).
static func decorate_projectile(p: Projectile, kind: String, id: String, col: Color) -> void:
	var light: OmniLight3D = null
	for c in p.get_children():
		if c is OmniLight3D:
			light = c
	if light != null and _q() == 0:
		p.remove_child(light)
		light.free()
		light = null
	match id:
		"kiriel":
			_swap_visual(p)                                # serangan biasa = sambaran petir bergerigi, bukan bola
			p.add_child(StormFx.bolt_visual(Color(1.0, 0.9, 0.3)))
			if light:
				light.light_color = Color(1.0, 0.92, 0.4)
				light.light_energy = 1.8
			trail(p, Color(1.0, 0.9, 0.3), 10, 0.12, 0.3, 0.0, true, "spark")
		"lyra":
			_swap_visual(p)
			var star := _star(Color(0.85, 0.7, 1.0))
			p.add_child(star)
			if light:
				light.light_color = Color(0.78, 0.55, 1.0)
			trail(p, Color(0.78, 0.55, 1.0), 14, 0.2, 0.45, -0.5, false)
			trail(p, Color(1, 1, 1), 8, 0.1, 0.6, -1.0)
		"ember":
			_swap_visual(p)
			var fb := Node3D.new()
			for i in 3:
				var mi := MeshInstance3D.new()
				var sm := SphereMesh.new()
				var rr: float = [0.2, 0.34, 0.5][i]
				sm.radius = rr
				sm.height = rr * 2.0
				sm.radial_segments = 8
				sm.rings = 4
				mi.mesh = sm
				var cc: Color = [Color(1.0, 0.95, 0.6, 1.0), Color(1.0, 0.55, 0.15, 0.8), Color(1.0, 0.3, 0.1, 0.35)][i]
				mi.material_override = Fx._unshaded(cc, true)
				mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				fb.add_child(mi)
			p.add_child(fb)
			var tw := fb.create_tween().set_loops()
			tw.tween_property(fb, "scale", Vector3.ONE * 1.18, 0.12)
			tw.tween_property(fb, "scale", Vector3.ONE * 0.88, 0.12)
			if light:
				light.light_color = Color(1.0, 0.55, 0.2)
				light.light_energy = 1.5
			trail(p, Color(1.0, 0.5, 0.15), 18, 0.4, 0.45, 2.5, false)
			trail(p, Color(1.0, 0.85, 0.3), 7, 0.1, 0.7, -1.0, false)
		"aion":
			_swap_visual(p)
			var shard := ChronoFx.shard_visual()
			p.add_child(shard)
			var sp := shard.create_tween().set_loops()
			sp.tween_property(shard, "rotation:z", TAU, 0.9).from(0.0)
			if light:
				light.light_color = Color(0.5, 0.7, 1.0)
			trail(p, Color(0.45, 0.65, 1.0), 14, 0.2, 0.5, -0.3, false)
			trail(p, Color(0.1, 0.16, 0.5), 8, 0.28, 0.6, -0.6, false)
			trail(p, Color(1.0, 0.92, 0.65), 6, 0.08, 0.5, -1.0)
		"lucien":
			_swap_visual(p)
			if kind == "arrow":
				var bl := MeshInstance3D.new()
				var cm2 := CylinderMesh.new()
				cm2.top_radius = 0.0
				cm2.bottom_radius = 0.1
				cm2.height = 0.7
				cm2.radial_segments = 4
				bl.mesh = cm2
				bl.material_override = Fx._unshaded(Color(0.95, 0.78, 0.35), false)
				bl.rotation.x = -PI * 0.5
				bl.position = Vector3(0, 0, -0.5)
				bl.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				p.add_child(bl)
			else:
				p.add_child(_star(Color(0.95, 0.78, 0.35)))
			if light:
				light.light_color = Color(1.0, 0.8, 0.35)
			trail(p, Color(0.2, 0.14, 0.3), 12, 0.3, 0.45, 0.0, false)
			trail(p, Color(1.0, 0.85, 0.4), 8, 0.1, 0.5, -0.5, true, "ember")
		"wenyu":
			_swap_visual(p)
			var nt := MeshInstance3D.new()                  # peluru = nota musik besar yang bergoyang
			var nq := QuadMesh.new()
			nq.size = Vector2(1.05, 1.05)
			nt.mesh = nq
			nt.material_override = UltFx._mat(Color(0.7, 1.0, 0.86, 1.0), UltFx.tex("note_a" if randi() % 2 == 0 else "note_b"), true, 1)
			nt.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			p.add_child(nt)
			var wob := nt.create_tween().set_loops()
			wob.tween_property(nt, "scale", Vector3(1.18, 0.88, 1.0), 0.16)
			wob.tween_property(nt, "scale", Vector3(0.88, 1.18, 1.0), 0.16)
			if light:
				light.light_color = Color(0.7, 1.0, 0.86)
			trail(p, Color(0.7, 1.0, 0.86), 8, 0.42, 0.7, 0.4, true, "note_c")
			trail(p, Color(1.0, 0.8, 0.95), 5, 0.36, 0.8, 0.6, true, "note_a")
		"sera":
			var head := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.0
			cm.bottom_radius = 0.1
			cm.height = 0.32
			cm.radial_segments = 5
			head.mesh = cm
			head.material_override = Fx._unshaded(Color(0.85, 1.0, 0.85), false)
			head.rotation.x = -PI * 0.5
			head.position = Vector3(0, 0, -0.55)
			head.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			p.add_child(head)
			trail(p, Color(0.6, 1.0, 0.65), 12, 0.13, 0.3, 0.0)
			trail(p, Color(1, 1, 1), 6, 0.08, 0.4, 0.0)


static func _swap_visual(p: Projectile) -> void:
	for c in p.get_children():
		if c is MeshInstance3D:
			p.remove_child(c)
			c.free()


## Bintang 8 sudut yang berputar (dua bidang saling tegak lurus agar terlihat dari kamera mana pun).
static func _star(col: Color) -> Node3D:
	var root := Node3D.new()
	var mat := Fx._unshaded(Color(col.r, col.g, col.b, 0.95), true)
	var core := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.18
	sm.height = 0.36
	sm.radial_segments = 8
	sm.rings = 4
	core.mesh = sm
	core.material_override = Fx._unshaded(Color(1, 1, 1, 1), true)
	core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(core)
	for plane in 2:
		var spin := Node3D.new()
		root.add_child(spin)
		if plane == 1:
			spin.rotation.x = PI * 0.5
		for i in 4:
			var mi := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(0.07, 0.95 if i % 2 == 0 else 0.62, 0.05)
			mi.mesh = bm
			mi.material_override = mat
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			mi.rotation.z = deg_to_rad(45.0 * i)
			spin.add_child(mi)
		var tw := spin.create_tween().set_loops()
		tw.tween_property(spin, "rotation:z" if plane == 0 else "rotation:y", TAU, 0.9 if plane == 0 else 1.3).as_relative()
	return root


# ---------------------------------------------------------------- kena sasaran
## Efek saat musuh terkena pukulan, khas tiap karakter. dir = arah pukulan (menjauhi pemain).
static func hit(parent: Node, id: String, pos: Vector3, dir: Vector3, col: Color, crit: bool) -> void:
	var k := 1.6 if crit else 1.0
	match id:
		"ren":
			puff(parent, pos, Color(0.6, 0.88, 1.0), int(6 * k), 7.0, 0.14, dir, 55.0, -14.0, 0.45, "shard", false)
			puff(parent, pos, Color(0.9, 0.98, 1.0), int(4 * k), 3.0, 0.1, Vector3.UP, 180.0, -2.0, 0.6)
		"zeya":
			x_flash(parent, pos, Color(1.0, 0.6, 0.78), 0.9 * k, 0.15)
			puff(parent, pos, Color(1.0, 0.5, 0.7), int(5 * k), 8.5, 0.09, dir, 45.0, -6.0, 0.35)
			puff(parent, pos, Color(0.4, 0.16, 0.62), 2, 2.0, 0.35, Vector3.UP, 180.0, 1.0, 0.5, "sphere", false)
		"lyra":
			puff(parent, pos, Color(1.0, 1.0, 1.0), int(5 * k), 4.5, 0.1, Vector3.UP, 180.0, -2.0, 0.6)
			puff(parent, pos, Color(0.78, 0.55, 1.0), int(5 * k), 3.5, 0.14, Vector3.UP, 180.0, -1.0, 0.7, "sphere", false)
		"ember":
			puff(parent, pos, Color(1.0, 0.5, 0.15), int(6 * k), 3.2, 0.32, Vector3.UP, 60.0, 4.0, 0.5, "sphere", false)
			puff(parent, pos, Color(1.0, 0.85, 0.3), int(4 * k), 8.0, 0.08, dir, 60.0, -6.0, 0.4, "sphere", false)
			puff(parent, pos + Vector3(0, 0.3, 0), Color(0.3, 0.26, 0.26), 2, 1.5, 0.35, Vector3.UP, 40.0, 1.5, 0.8, "sphere", false)
		"brann":
			puff(parent, pos, Color(0.72, 0.62, 0.48), 4, 2.4, 0.4, Vector3.UP, 90.0, -1.5, 0.6, "sphere", false)
			puff(parent, pos, Color(0.45, 0.4, 0.36), int(4 * k), 5.5, 0.14, dir + Vector3(0, 0.5, 0), 60.0, -16.0, 0.5, "chip", false)
		"kiriel":
			x_flash(parent, pos, Color(1.0, 0.95, 0.6), 1.0 * k, 0.15)
			puff(parent, pos, Color(1.0, 0.9, 0.3), int(6 * k), 8.0, 0.09, dir, 70.0, -6.0, 0.35, "spark")
		"hakuya":
			streak(parent, pos - dir * 0.7, pos + dir * 0.7, Color(0.92, 0.97, 1.0), 0.07 * k, 0.12)
			puff(parent, pos, Color(0.3, 0.6, 1.0), int(4 * k), 2.0, 0.4, Vector3.UP, 60.0, 3.0, 0.45, "flame", false)
			spark_lines(parent, pos, dir, Color(0.8, 0.93, 1.0), int(9 * k), 10.0, 120.0, 0.2, 0.8)
			embers(parent, pos, Color(0.5, 0.82, 1.0), int(6 * k), 120.0, 2.5, 0.7)
		"vael":
			puff(parent, pos, Color(0.2, 0.85, 1.0), int(5 * k), 2.2, 0.4, Vector3.UP, 60.0, 3.0, 0.45, "flame", false)
			spark_lines(parent, pos, dir, Color(0.85, 0.98, 1.0), int(8 * k), 10.0, 110.0, 0.2, 0.8)
			x_flash(parent, pos, Color(0.7, 0.96, 1.0), 0.9 * k, 0.14)
		"lucien":
			x_flash(parent, pos, Color(1.0, 0.85, 0.4), 1.0 * k, 0.16)
			puff(parent, pos, Color(0.2, 0.14, 0.3), 3, 2.0, 0.4, Vector3.UP, 180.0, 1.0, 0.5, "sphere", false)
			embers(parent, pos, Color(1.0, 0.82, 0.4), int(8 * k), 150.0, 3.0, 0.7)
		"wenyu":
			notes(parent, pos, Color(0.7, 1.0, 0.86), int(6 * k), 3.6, 0.5, Vector3.UP, 180.0, 0.5, 0.8)
			notes(parent, pos, Color(1.0, 0.8, 0.95), 3, 2.8, 0.4, Vector3.UP, 180.0, 0.5, 0.7)
			Fx.ring(parent, pos, 0.9 * k, Color(0.7, 1.0, 0.86), 0.22)
		"aion":
			x_flash(parent, pos, Color(0.7, 0.85, 1.0), 0.9 * k, 0.15)
			ChronoFx.ink_burst(parent, pos, Color(0.12, 0.2, 0.6), 1.3 * k, 0.35)
			spark_lines(parent, pos, dir, Color(1.0, 0.92, 0.65), int(5 * k), 8.0, 150.0, 0.18, 0.6)
			Fx.ring(parent, Vector3(pos.x, 0.1, pos.z), 0.9 * k, Color(0.55, 0.75, 1.0), 0.22)
		"kyomu":
			x_flash(parent, pos, Color(0.78, 0.6, 1.0), 1.0 * k, 0.16)
			streak(parent, pos - dir * 0.7, pos + dir * 0.7, Color(0.85, 0.75, 1.0), 0.07 * k, 0.12)
			puff(parent, pos, Color(0.55, 0.25, 1.0), int(5 * k), 7.0, 0.12, dir, 55.0, -10.0, 0.45, "shard", false)
			puff(parent, pos, Color(0.14, 0.06, 0.32), 3, 2.5, 0.45, Vector3.UP, 120.0, 1.0, 0.5, "sphere", false)
		"kuroha":
			streak(parent, pos - dir * 0.7, pos + dir * 0.7, Color(0.92, 0.95, 1.0), 0.07 * k, 0.12)
			puff(parent, pos, Color(0.14, 0.1, 0.28), 3, 2.5, 0.45, Vector3.UP, 120.0, 1.0, 0.5, "sphere", false)
			spark_lines(parent, pos, dir, Color(0.85, 0.88, 1.0), int(7 * k), 9.0, 110.0, 0.18, 0.7)
		"sera":
			puff(parent, pos, Color(0.5, 0.85, 0.4), int(5 * k), 3.0, 0.13, Vector3.UP, 180.0, -1.5, 0.8, "leaf", false)
			puff(parent, pos, Color(1, 1, 1), 3, 4.5, 0.08, dir, 60.0, 0.0, 0.4)
		_:
			Fx.burst(parent, pos, col, 4, 3.0, 0.1)
			Fx.burst(parent, pos, col.lightened(0.4), 6 if crit else 3, 7.5 if crit else 5.5, 0.07, dir, 38.0)
