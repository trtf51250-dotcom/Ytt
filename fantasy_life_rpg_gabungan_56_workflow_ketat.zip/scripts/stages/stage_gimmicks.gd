class_name StageGimmicks
extends Node3D
## Jebakan, rintangan & puzzle untuk stage Adventure (supaya tidak "cuma pukul-pukul musuh"):
##  - JEBAKAN DURI: pelat batu di tanah yang berkedip merah (aba-aba 0,9 dtk) lalu duri menyembul. Kena = damage kecil; musuh biasa juga bisa kena.
##  - BATANG KAYU GELINDING (khusus hutan): jalur merah muncul memotong arena (lewat posisimu), lalu batang kayu menggelinding. Hindari / dodge.
##  - PUZZLE RUNE: tiga rune warna menyala berurutan; injak sesuai urutan. Benar = hadiah emas, EXP & pemulihan HP; salah = sengatan kecil, urutan diulang.
## Semua bahaya BERTELEGRAF (selalu ada aba-aba) dan damage-nya kecil, naik pelan menurut level stage. Hanya ada di stage Adventure biasa
## (bukan bos / co-op / PVP / wilayah jelajah / stage 1-1 / saat bot uji), dibangun malas (lazy) pada gelombang pertama, dan bisa dimatikan
## lewat Pengaturan > Efek > "Jebakan & puzzle". Pemain dilukai lewat Stage._on_enemy_hit supaya DEF, kebal-sesaat (dodge) & getar tetap berlaku.

const ST_FIGHT := 1                     # = Stage.S.FIGHT
const ST_ENDED := 2                     # = Stage.S.ENDED

const THEME_CFG := {
	"forest": {"spikes": 4, "logs": true, "puzzle": true},
	"cave": {"spikes": 4, "logs": false, "puzzle": true},
	"meadow": {"spikes": 2, "logs": false, "puzzle": true},
}
const DEFAULT_CFG := {"spikes": 3, "logs": false, "puzzle": true}

# --- jebakan duri
const TS_IDLE := 0
const TS_WARN := 1
const TS_UP := 2
const WARN_T := 0.9
const UP_T := 0.8
const TRAP_R := 1.15
const TRAP_TRIGGER := 6.5               # jebakan baru "bangun" bila pemain sedekat ini
const PLATE_DARK := Color(0.30, 0.27, 0.27)
const PLATE_RED := Color(1.0, 0.25, 0.2)

# --- batang kayu
const LOG_R := 0.7
const LOG_LEN := 2.6
const LOG_SPEED := 11.0
const LOG_WARN := 1.6
const LOG_HALF_ALONG := 0.9             # setengah ketebalan batang searah gelinding (+ ruang toleransi)
const LOG_HALF_SIDE := 1.45             # setengah panjang batang

# --- puzzle rune
const PUZ_DELAY := 10.0                 # detik setelah gelombang pertama mulai
const PUZ_STEP := 0.9                   # selang antar kedipan
const PUZ_LEAD := 1.2                   # jeda sebelum kedipan pertama
const PUZ_ARMED_MAX := 35.0
const RUNE_R := 1.2
const RUNE_COLORS := [Color(1.0, 0.3, 0.3), Color(0.35, 0.6, 1.0), Color(0.4, 1.0, 0.5)]
const RUNE_NAMES := ["MERAH", "BIRU", "HIJAU"]

var stage: Node
var _built := false
var _t := 0.0
var _R := 25.0
var _theme := ""
var _lvl := 1
var _cfg: Dictionary = {}
var _rng := RandomNumberGenerator.new()

var _spike_mesh: CylinderMesh
var _spike_mat: StandardMaterial3D
var _traps: Array = []

var _log_on := false
var _log_root: Node3D
var _log_pivot: Node3D
var _tele: MeshInstance3D
var _tele_mat: StandardMaterial3D
var _log_state := 0                     # 0 menunggu, 1 aba-aba, 2 menggelinding
var _log_t := 0.0
var _log_dir := Vector3.FORWARD
var _log_start := Vector3.ZERO
var _log_len := 0.0
var _log_sc := 0.0
var _log_hit: Dictionary = {}
var _log_told := false

var _puz_on := false
var _puz_ph := 0                        # 0 menunggu, 1 tampilkan urutan, 2 giliran pemain, 3 selesai
var _puz_t := 0.0
var _puz_clock := 0.0
var _puz_seq: Array = []
var _puz_prog := 0
var _puz_inside := -1
var _puz_lit := -1
var _puz_lit_t := 0.0
var _puz_last_idx := -1
var _puz_spawned := false
var _rune_pos: Array = []
var _runes: Array = []                  # {root, gem, dmat, gmat}


func setup(p_stage: Node) -> void:
	stage = p_stage


func _physics_process(delta: float) -> void:
	if stage == null or not is_instance_valid(stage):
		set_physics_process(false)
		return
	var st := int(stage.state)
	if st == ST_ENDED:
		_shutdown()
		return
	if st != ST_FIGHT or stage.player == null:
		return
	if not _built:
		_build()
	_t += delta
	var pp: Vector3 = stage.player.global_position
	_update_traps(delta, pp)
	if _log_on:
		_update_log(delta, pp)
	if _puz_on:
		_update_puzzle(delta, pp)


# ---------------------------------------------------------------- membangun
func _build() -> void:
	_built = true
	_theme = str(stage.arena.theme)
	_R = float(stage.arena.radius)
	_lvl = maxi(int(stage.sd.recommended_level), 1)
	_cfg = THEME_CFG.get(_theme, DEFAULT_CFG)
	_rng.seed = hash(str(stage.sd.id))
	_puz_on = bool(_cfg["puzzle"])
	if _puz_on:
		_plan_runes()
	_spike_mesh = CylinderMesh.new()
	_spike_mesh.top_radius = 0.0
	_spike_mesh.bottom_radius = 0.17
	_spike_mesh.height = 0.9
	_spike_mesh.radial_segments = 5
	_spike_mesh.rings = 1
	_spike_mat = StandardMaterial3D.new()
	_spike_mat.albedo_color = Color(0.78, 0.8, 0.86)
	_spike_mat.roughness = 0.5
	_spike_mat.metallic = 0.3
	for i in int(_cfg["spikes"]):
		_make_trap(i, int(_cfg["spikes"]))
	if bool(_cfg["logs"]):
		_log_init()
		_log_on = true
		_log_t = 14.0


func _mat_solid(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = c
	return m


func _mat_alpha(c: Color) -> StandardMaterial3D:
	var m := _mat_solid(c)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m


func _flat_dist(a: Vector3, b: Vector3) -> float:
	return Vector2(a.x - b.x, a.z - b.z).length()


func _victims() -> Array:
	var out: Array = []
	for n in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(n):
			continue
		var e := n as Enemy
		if e == null or e.dead or e.is_boss or e.flying or e.puppet:
			continue
		out.append(e)
	return out


func _hurt_enemy(e: Enemy, from: Vector3, frac: float, knock: float) -> void:
	var dmg := maxi(int(e.max_hp * frac), 6)
	e.take_damage(dmg, from, knock)
	Fx.float_text(stage.fx_root, e.global_position + Vector3(0, 1.8, 0), str(dmg), Color(1.0, 0.85, 0.4), 0.9)


func _shutdown() -> void:
	for tr: Dictionary in _traps:
		(tr["spikes"] as Node3D).visible = false
	if _log_root != null:
		_log_root.visible = false
		_tele.visible = false
	set_physics_process(false)


# ---------------------------------------------------------------- jebakan duri
func _make_trap(i: int, n: int) -> void:
	var start_pos := Vector3(0, 0, _R * 0.35)       # titik mulai pemain
	var base_a := _rng.randf() * TAU
	var placed := Vector3.ZERO
	var ok := false
	for attempt in 16:
		var a := base_a + float(i) / float(n) * TAU + _rng.randf_range(-0.5, 0.5) + attempt * 0.25
		var r := _R * _rng.randf_range(0.28, 0.62)
		var p: Vector3 = stage.free_spot(Vector3(cos(a) * r, 0.0, sin(a) * r), 1.2)
		if Vector2(p.x, p.z).length() > _R * 0.7 or stage.spot_blocked(p, 1.2):
			continue
		if _flat_dist(p, start_pos) < 7.0:
			continue
		var clash := false
		for rp: Vector3 in _rune_pos:
			if _flat_dist(p, rp) < 4.5:
				clash = true
		for tr: Dictionary in _traps:
			if _flat_dist(p, tr["pos"]) < 5.5:
				clash = true
		if clash:
			continue
		placed = p
		ok = true
		break
	if not ok:
		return
	var root := Node3D.new()
	root.name = "SpikeTrap%d" % i
	add_child(root)
	root.position = Vector3(placed.x, 0.0, placed.z)
	var plate := MeshInstance3D.new()
	var pm := CylinderMesh.new()
	pm.top_radius = 1.15
	pm.bottom_radius = 1.2
	pm.height = 0.05
	pm.radial_segments = 14
	pm.rings = 1
	plate.mesh = pm
	plate.position.y = 0.05
	var pmat := _mat_solid(PLATE_DARK)
	plate.material_override = pmat
	plate.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(plate)
	var spikes := Node3D.new()
	spikes.position.y = -0.95
	spikes.visible = false
	root.add_child(spikes)
	for k in 7:
		var c := MeshInstance3D.new()
		c.mesh = _spike_mesh
		c.material_override = _spike_mat
		c.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		if k == 0:
			c.position = Vector3(0, 0.45, 0)
		else:
			var ang := float(k) / 6.0 * TAU
			c.position = Vector3(cos(ang) * 0.68, 0.45, sin(ang) * 0.68)
		spikes.add_child(c)
	_traps.append({"pos": root.position, "spikes": spikes, "mat": pmat, "s": TS_IDLE, "t": 2.0 + float(i) * 1.3, "hit": {}})


func _update_traps(delta: float, pp: Vector3) -> void:
	for tr: Dictionary in _traps:
		var s: int = tr["s"]
		var t: float = float(tr["t"]) - delta
		var pos: Vector3 = tr["pos"]
		var spikes: Node3D = tr["spikes"]
		var mat: StandardMaterial3D = tr["mat"]
		if s == TS_IDLE:
			if t <= 0.0:
				t = 0.0
				if _flat_dist(pp, pos) < TRAP_TRIGGER:
					s = TS_WARN
					t = WARN_T
					tr["hit"] = {}
					spikes.visible = true
					spikes.position.y = -0.8
		elif s == TS_WARN:
			mat.albedo_color = PLATE_DARK.lerp(PLATE_RED, 0.5 + 0.5 * sin(_t * 22.0))
			if t <= 0.0:
				s = TS_UP
				t = UP_T
				mat.albedo_color = PLATE_RED
				spikes.position.y = -0.95
				_trap_fire(pos, pp)
		else:
			var el := UP_T - t
			var y := -0.95 + 0.95 * clampf(el / 0.12, 0.0, 1.0)
			if t < 0.22:
				y = -0.95 + 0.95 * clampf(t / 0.22, 0.0, 1.0)
			spikes.position.y = y
			if el > 0.05 and el < 0.6:
				_trap_hits(tr, pos, pp)
			if t <= 0.0:
				s = TS_IDLE
				t = randf_range(2.5, 5.0)
				spikes.visible = false
				mat.albedo_color = PLATE_DARK
		tr["s"] = s
		tr["t"] = t


func _trap_fire(pos: Vector3, pp: Vector3) -> void:
	if _flat_dist(pp, pos) < 14.0:
		Sfx.play("swing", 0.7, -6.0)
	Fx.burst(stage.fx_root, pos + Vector3(0, 0.3, 0), Color(0.85, 0.85, 0.9), 6, 3.0, 0.08)


func _trap_hits(tr: Dictionary, pos: Vector3, pp: Vector3) -> void:
	var hit: Dictionary = tr["hit"]
	if not hit.has(0) and _flat_dist(pp, pos) < TRAP_R + 0.1:
		hit[0] = true
		stage._on_enemy_hit(7 + _lvl * 2, pos)
	for e: Enemy in _victims():
		var id := e.get_instance_id()
		if hit.has(id):
			continue
		if _flat_dist(e.global_position, pos) < TRAP_R + e.hit_radius * 0.4:
			hit[id] = true
			_hurt_enemy(e, pos, 0.2, 3.0)


# ---------------------------------------------------------------- batang kayu menggelinding
func _log_init() -> void:
	_log_root = Node3D.new()
	_log_root.name = "RollingLog"
	_log_root.visible = false
	add_child(_log_root)
	_log_pivot = Node3D.new()
	_log_pivot.position.y = LOG_R
	_log_root.add_child(_log_pivot)
	var bark := StandardMaterial3D.new()
	bark.albedo_color = Color(0.46, 0.3, 0.16)
	bark.roughness = 0.9
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color(0.3, 0.19, 0.1)
	dark.roughness = 0.95
	var body := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = LOG_R
	cm.bottom_radius = LOG_R
	cm.height = LOG_LEN
	cm.radial_segments = 10
	cm.rings = 1
	body.mesh = cm
	body.rotation.z = PI / 2.0                      # sumbu batang searah X; menggelinding ke arah Z lokal
	body.material_override = bark
	body.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_log_pivot.add_child(body)
	for k in 4:
		var th := float(k) / 4.0 * TAU + 0.4
		var rb := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(LOG_LEN + 0.04, 0.12, 0.2)
		rb.mesh = bm
		rb.material_override = dark
		rb.position = Vector3(0, cos(th) * LOG_R, sin(th) * LOG_R)
		rb.rotation.x = th                           # sisi lebar menghadap keluar (radial) -> terlihat berputar
		rb.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_log_pivot.add_child(rb)
	_tele = MeshInstance3D.new()
	var tm := BoxMesh.new()
	tm.size = Vector3(LOG_HALF_SIDE * 2.0 + 0.1, 0.03, 10.0)
	_tele.mesh = tm
	_tele_mat = _mat_alpha(Color(1.0, 0.3, 0.2, 0.12))
	_tele.material_override = _tele_mat
	_tele.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_tele.visible = false
	add_child(_tele)


func _log_plan(pp: Vector3) -> void:
	var c := Vector2(pp.x, pp.z).limit_length(_R * 0.8)
	var a := randf() * TAU
	var d := Vector2(cos(a), sin(a))
	var rr := _R - 1.2
	var b := c.dot(d)
	var disc := b * b - (c.length_squared() - rr * rr)
	if disc <= 4.0:
		_log_t = 2.0
		return
	var sq := sqrt(disc)
	var t0 := -b - sq
	var t1 := -b + sq
	_log_dir = Vector3(d.x, 0.0, d.y)
	_log_start = Vector3(c.x + d.x * t0, 0.0, c.y + d.y * t0)
	_log_len = t1 - t0
	var mid := c + d * ((t0 + t1) * 0.5)
	(_tele.mesh as BoxMesh).size = Vector3(LOG_HALF_SIDE * 2.0 + 0.1, 0.03, _log_len)
	_tele.position = Vector3(mid.x, 0.09, mid.y)
	_tele.rotation.y = atan2(d.x, d.y)
	_tele.visible = true
	_tele_mat.albedo_color = Color(1.0, 0.3, 0.2, 0.12)
	_log_state = 1
	_log_t = LOG_WARN
	if not _log_told:
		_log_told = true
		stage.hud.banner("Batang kayu menggelinding! Menghindar dari jalur merah!", Color(1.0, 0.6, 0.3), 1.8)


func _update_log(delta: float, pp: Vector3) -> void:
	if _log_state == 0:
		_log_t -= delta
		if _log_t <= 0.0 and not stage.player.dead:
			_log_plan(pp)
	elif _log_state == 1:
		_log_t -= delta
		var w := 1.0 - clampf(_log_t / LOG_WARN, 0.0, 1.0)
		_tele_mat.albedo_color = Color(1.0, 0.3, 0.2, 0.12 + 0.4 * w)
		if _log_t <= 0.0:
			_log_state = 2
			_log_sc = 0.0
			_log_hit = {}
			_log_root.visible = true
			_log_root.rotation.y = atan2(_log_dir.x, _log_dir.z)
			_log_root.position = _log_start
			_tele_mat.albedo_color = Color(1.0, 0.3, 0.2, 0.22)
			Sfx.play("boom", 1.3, -10.0)
	else:
		_log_sc += LOG_SPEED * delta
		var pos := _log_start + _log_dir * _log_sc
		_log_root.position = Vector3(pos.x, 0.0, pos.z)
		_log_pivot.rotation.x += LOG_SPEED / LOG_R * delta
		if not _log_hit.has(0) and _log_box(pp, pos, 0.25):
			_log_hit[0] = true
			stage._on_enemy_hit(9 + _lvl * 2, pos)
		for e: Enemy in _victims():
			var id := e.get_instance_id()
			if not _log_hit.has(id) and _log_box(e.global_position, pos, e.hit_radius * 0.5):
				_log_hit[id] = true
				_hurt_enemy(e, pos, 0.3, 6.0)
		if _log_sc >= _log_len:
			_log_state = 0
			_log_t = randf_range(9.0, 14.0)
			_log_root.visible = false
			_tele.visible = false


## Titik q di dalam persegi panjang berorientasi batang (searah gelinding x sumbu batang)?
func _log_box(q: Vector3, pos: Vector3, extra: float) -> bool:
	var dx := q.x - pos.x
	var dz := q.z - pos.z
	var along := dx * _log_dir.x + dz * _log_dir.z
	var side := -dx * _log_dir.z + dz * _log_dir.x
	return absf(along) < LOG_HALF_ALONG + extra and absf(side) < LOG_HALF_SIDE + extra


# ---------------------------------------------------------------- puzzle rune
func _plan_runes() -> void:
	var a0 := _rng.randf() * TAU
	for k in 3:
		var a := a0 + float(k) * TAU / 3.0
		var want := Vector3(cos(a) * _R * 0.5, 0.0, sin(a) * _R * 0.5)
		var p: Vector3 = stage.free_spot(want, 1.3)
		_rune_pos.append(Vector3(p.x, 0.0, p.z))


func _puz_spawn() -> void:
	_puz_spawned = true
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = 0.4
	cone.height = 0.7
	cone.radial_segments = 4
	cone.rings = 1
	for k in 3:
		var col: Color = RUNE_COLORS[k]
		var root := Node3D.new()
		root.name = "Rune%d" % k
		add_child(root)
		root.position = _rune_pos[k]
		var disk := MeshInstance3D.new()
		var dm := CylinderMesh.new()
		dm.top_radius = RUNE_R
		dm.bottom_radius = RUNE_R
		dm.height = 0.04
		dm.radial_segments = 20
		dm.rings = 1
		disk.mesh = dm
		disk.position.y = 0.1
		var dmat := _mat_alpha(Color(col.r, col.g, col.b, 0.3))
		disk.material_override = dmat
		disk.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(disk)
		var gem := Node3D.new()
		gem.position.y = 1.4
		root.add_child(gem)
		var gmat := _mat_solid(col.darkened(0.45))
		for flip in 2:
			var mi := MeshInstance3D.new()
			mi.mesh = cone
			mi.material_override = gmat
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			if flip == 0:
				mi.position.y = 0.35
			else:
				mi.position.y = -0.35
				mi.rotation.x = PI
			gem.add_child(mi)
		_runes.append({"root": root, "gem": gem, "dmat": dmat, "gmat": gmat})
		Fx.ring(stage.fx_root, root.position, 2.2, col, 0.6)


func _puz_set_lit(idx: int) -> void:
	if idx == _puz_lit:
		return
	_puz_lit = idx
	for k in _runes.size():
		var col: Color = RUNE_COLORS[k]
		var on := k == idx
		var r: Dictionary = _runes[k]
		(r["dmat"] as StandardMaterial3D).albedo_color = Color(col.r, col.g, col.b, 0.95 if on else 0.3)
		(r["gmat"] as StandardMaterial3D).albedo_color = col.lightened(0.25) if on else col.darkened(0.45)
		(r["gem"] as Node3D).scale = Vector3.ONE * (1.5 if on else 1.0)


func _rune_at(pp: Vector3) -> int:
	for k in _rune_pos.size():
		if _flat_dist(pp, _rune_pos[k]) < RUNE_R:
			return k
	return -1


func _puz_roll() -> void:
	_puz_seq = []
	var n_len := 3 if _lvl <= 3 else 4
	var prev := -1
	for i in n_len:
		var n := randi() % 3
		while n == prev:
			n = randi() % 3
		_puz_seq.append(n)
		prev = n


func _puz_begin_show() -> void:
	_puz_ph = 1
	_puz_clock = 0.0
	_puz_last_idx = -1
	_puz_prog = 0
	_puz_set_lit(-1)
	stage.hud.banner("Puzzle Rune! Hafalkan urutan cahaya.", Color(0.7, 0.85, 1.0), 1.6)


func _update_puzzle(delta: float, pp: Vector3) -> void:
	if _puz_ph == 0:
		if _t < PUZ_DELAY:
			return
		_puz_t -= delta
		if _puz_t <= 0.0 and not stage.player.dead:
			if not _puz_spawned:
				_puz_spawn()
			_puz_roll()
			_puz_begin_show()
		return
	if _puz_ph == 3:
		return
	for r: Dictionary in _runes:
		(r["gem"] as Node3D).rotation.y += delta * 1.5
	if _puz_ph == 1:
		_puz_clock += delta
		var rel := _puz_clock - PUZ_LEAD
		if rel < 0.0:
			return
		var idx := int(rel / PUZ_STEP)
		if idx >= _puz_seq.size():
			_puz_set_lit(-1)
			_puz_ph = 2
			_puz_prog = 0
			_puz_inside = _rune_at(pp)
			_puz_t = PUZ_ARMED_MAX
			stage.hud.banner("Giliranmu! Injak rune sesuai urutan.", UiTheme.GOOD, 1.4)
			return
		if idx != _puz_last_idx:
			_puz_last_idx = idx
			var ri: int = _puz_seq[idx]
			Sfx.play("pickup", 0.8 + 0.15 * float(ri), -4.0)
			Fx.float_text(stage.fx_root, Vector3(_rune_pos[ri].x, 2.6, _rune_pos[ri].z), "%d. %s" % [idx + 1, RUNE_NAMES[ri]], RUNE_COLORS[ri], 1.0)
		_puz_set_lit(int(_puz_seq[idx]) if fmod(rel, PUZ_STEP) < PUZ_STEP * 0.6 else -1)
		return
	# fase 2: giliran pemain
	if _puz_lit_t > 0.0:
		_puz_lit_t -= delta
		if _puz_lit_t <= 0.0:
			_puz_set_lit(-1)
	_puz_t -= delta
	if _puz_t <= 0.0:
		_puz_set_lit(-1)
		_puz_ph = 0
		_puz_t = 18.0
		Fx.float_text(stage.fx_root, stage.player.global_position + Vector3(0, 2.4, 0), "Rune padam...", Color(0.8, 0.8, 0.9), 1.0)
		return
	var cur := _rune_at(pp)
	if cur == _puz_inside:
		return
	_puz_inside = cur
	if cur < 0 or stage.player.dead:
		return
	if cur == int(_puz_seq[_puz_prog]):
		_puz_prog += 1
		_puz_set_lit(cur)
		_puz_lit_t = 0.4
		Sfx.play("pickup", 1.0 + 0.12 * float(_puz_prog), -3.0)
		if _puz_prog >= _puz_seq.size():
			_puz_solved()
	else:
		_puz_prog = 0
		Fx.ring(stage.fx_root, _rune_pos[cur], 2.0, Color(1.0, 0.3, 0.3), 0.4)
		Fx.float_text(stage.fx_root, stage.player.global_position + Vector3(0, 2.4, 0), "Salah! Ulangi.", UiTheme.BAD, 1.0)
		stage._on_enemy_hit(4 + _lvl, _rune_pos[cur])
		_puz_begin_show()
		_puz_clock = -1.5                             # beri napas sebelum urutan diputar ulang


func _puz_solved() -> void:
	_puz_ph = 3
	var gold := 60 + _lvl * 25
	var xp := 30 + _lvl * 18
	GameState.add_gold(gold)
	GameState.add_exp(xp)
	var pl: Player = stage.player
	pl.heal(int(pl.max_hp * 0.35))
	stage.hud.banner("Puzzle terpecahkan! +%d emas, +%d EXP, HP pulih" % [gold, xp], UiTheme.GOLD, 2.2)
	Sfx.play("chest")
	_puz_set_lit(-1)
	for k in _runes.size():
		var r: Dictionary = _runes[k]
		var root: Node3D = r["root"]
		var col: Color = RUNE_COLORS[k]
		Fx.ring(stage.fx_root, root.position, 3.0, col, 0.6)
		Fx.burst(stage.fx_root, root.position + Vector3(0, 1.4, 0), col, 10, 4.0, 0.12)
		var tw := root.create_tween()
		tw.tween_interval(1.0)
		tw.tween_property(root, "scale", Vector3.ZERO, 0.8)
		tw.tween_callback(root.queue_free)
