class_name StormFx
extends RefCounted
## Efek petir Kiriel: sambaran bergerigi, hantaman dari langit, rantai antar-musuh. Dibangun dari CharFx.streak / x_flash / puff (murah untuk HP low-end).

const YEL := Color(1.0, 0.9, 0.3)
const WHT := Color(1.0, 0.98, 0.85)


## Garis petir bergerigi dari `from` ke `to` (segs ruas, jag = simpangan acak dalam meter).
static func bolt(parent: Node, from: Vector3, to: Vector3, col: Color = YEL, life: float = 0.2, jag: float = 0.45, segs: int = 6) -> void:
	var d := to - from
	var side := d.cross(Vector3.UP)
	if side.length() < 0.01:
		side = Vector3.RIGHT
	side = side.normalized()
	var prev := from
	for i in range(1, segs + 1):
		var t := float(i) / float(segs)
		var p := to if i == segs else from + d * t + side * randf_range(-jag, jag) + Vector3(0, randf_range(-jag, jag) * 0.5, 0)
		CharFx.streak(parent, prev, p, col, 0.13, life)
		CharFx.streak(parent, prev, p, WHT, 0.05, life * 0.8)
		prev = p


## Tampilan peluru serangan biasa Kiriel: SAMBARAN PETIR bergerigi memanjang (sumbu -Z = arah tembak; ekor di belakang), bukan bola.
## Bentuk zig-zag diacak ulang ~16x/dtk supaya berkedip seperti petir sungguhan. Hemat: 2 lapis x 6 ruas (4 ruas di kualitas rendah).
static func bolt_visual(col: Color = YEL) -> Node3D:
	var root := Node3D.new()
	var segs := 4 if Quality.level() == 0 else 6
	var glow := Fx._unshaded(Color(col.r, col.g, col.b, 0.7), true)
	var core := Fx._unshaded(Color(1.0, 0.98, 0.85, 0.95), true)
	var parts: Array = []                                 # [glow_i, core_i] berurutan per ruas
	for i in segs:
		for layer in 2:
			var mi := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(0.2, 0.2, 1.0) if layer == 0 else Vector3(0.07, 0.07, 1.0)
			mi.mesh = bm
			mi.material_override = glow if layer == 0 else core
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			root.add_child(mi)
			parts.append(mi)
	var reshape := func() -> void:
		var pts: Array = []
		for i in segs + 1:
			var z := lerpf(1.7, -0.5, float(i) / float(segs))          # ekor (+Z) -> kepala (-Z)
			var j := 0.0 if (i == 0 or i == segs) else 0.3
			pts.append(Vector3(randf_range(-j, j), randf_range(-j, j) * 0.7, z))
		for i in segs:
			var a: Vector3 = pts[i]
			var b: Vector3 = pts[i + 1]
			var d := b - a
			var seg_len := maxf(d.length(), 0.05)
			var bs := Basis.looking_at(d / seg_len, Vector3.UP) * Basis(Vector3(1, 0, 0), Vector3(0, 1, 0), Vector3(0, 0, seg_len))
			for layer in 2:
				var m: MeshInstance3D = parts[i * 2 + layer]
				m.transform = Transform3D(bs, (a + b) * 0.5)
	reshape.call()
	var tw := root.create_tween().set_loops()
	tw.tween_interval(0.06)
	tw.tween_callback(reshape)
	return root


## Hantaman petir dari langit ke titik p (tanah).
static func strike(parent: Node, p: Vector3, col: Color = YEL) -> void:
	var top := p + Vector3(randf_range(-1.2, 1.2), 9.0, randf_range(-1.2, 1.2))
	bolt(parent, top, p + Vector3(0, 0.1, 0), col, 0.24, 0.8, 9)
	CharFx.x_flash(parent, p + Vector3(0, 0.8, 0), WHT, 1.7, 0.2)
	Fx.ring(parent, p + Vector3(0, 0.05, 0), 2.4, col, 0.35)
	CharFx.puff(parent, p + Vector3(0, 0.3, 0), col, 8, 6.0, 0.1, Vector3.UP, 160.0, -7.0, 0.5, "spark")


## Petir melompat berurutan: from -> pts[0] -> pts[1] ... (titik sudah setinggi badan).
static func chain(parent: Node, from: Vector3, pts: Array, col: Color = YEL) -> void:
	var prev := from
	for p in pts:
		bolt(parent, prev, p as Vector3, col, 0.22, 0.35, 5)
		CharFx.x_flash(parent, p as Vector3, WHT, 0.9, 0.15)
		prev = p as Vector3
