class_name ComboRunner
extends RefCounted
## Menjalankan satu langkah kombo (lihat ComboDefs) saat ayunan "kena": hit detection + efek visual per tipe.
## Dipanggil Stage._on_swing untuk serangan biasa pemain. Efek khas karakter tetap lewat CharFx (attack_slash / attack_smash / hit / decorate_projectile).


static func run(s: Stage, cd: CharacterData, st: Dictionary, origin: Vector3, dir: Vector3) -> void:
	var p: Player = s.player
	var atk := float(GameState.char_stats(p.char_id)["atk"])
	var col := cd.accent.lightened(0.35)
	var typ := String(st.get("t", "arc"))
	var dmg := atk * cd.attack_mult * float(st.get("m", 1.0))
	var kb := float(st.get("k", 3.0))
	var rng := cd.attack_range * float(st.get("r", 1.0))
	var half := float(st.get("h", 75.0))
	var big := bool(st.get("big", p.swing_final))
	var idx := p.swing_idx
	var yaw := atan2(dir.x, dir.z)
	var pos := p.global_position
	var fwd := Vector3(sin(yaw), 0, cos(yaw))
	match typ:
		"arc":
			_slash_fx(s, cd, st, pos, yaw, rng, col, idx, big)
			s._melee(origin, dir, rng, half, dmg, kb, col)
		"cone":                                            # tusukan: garis lurus panjang + percikan di ujung
			var tip := pos + fwd * rng
			CharFx.streak(s.fx_root, pos + fwd * 0.4, tip, col, 0.34, 0.2)
			CharFx.streak(s.fx_root, pos + fwd * 0.4, tip, Color(1, 1, 1), 0.12, 0.16)
			CharFx.spark_lines(s.fx_root, tip + Vector3(0, 0.9, 0), fwd, col.lightened(0.3), 8, 9.0, 40.0, 0.2, 0.8)
			CharFx.x_flash(s.fx_root, tip + Vector3(0, 0.9, 0), Color(1, 1, 1), 0.9, 0.14)
			s._melee(origin, dir, rng, half, dmg, kb, col)
		"spin":                                            # putaran 360°
			Fx.ring(s.fx_root, pos + Vector3(0, 0.1, 0), rng, col, 0.3)
			_slash_fx(s, cd, st, pos, yaw, rng, col, idx, false)
			_slash_fx(s, cd, st, pos, yaw + PI, rng, col, idx + 1, false)
			s._melee(origin, dir, rng, 180.0, dmg, kb, col)
			s.cam.shake(0.05)
		"slam":                                            # hantaman area di depan badan
			var c := pos + fwd * rng * 0.55
			var rad := rng * 0.8
			Fx.ring(s.fx_root, Vector3(c.x, 0.1, c.z), rad, col, 0.4)
			Fx.ring(s.fx_root, Vector3(c.x, 0.1, c.z), rad * 0.55, Color(1, 1, 1), 0.28)
			Fx.burst(s.fx_root, c + Vector3(0, 0.3, 0), col.lightened(0.3), 16, 6.0, 0.14)
			if cd.id == "brann":
				CharFx.attack_smash(s.fx_root, cd.id, pos, yaw, rng, col, 2)
				CharFx.cracks(s.fx_root, c, rad, Color(1.0, 0.65, 0.3), 0.6, 7)
			elif cd.id == "kyomu":
				CharFx.skill_vortex(s.fx_root, cd.id, c, rad, 0.3)
			else:
				_slash_fx(s, cd, st, pos, yaw, rng, col, idx, true)
			s._ult_aoe_slack(c, rad, dmg, kb, col)
			s.cam.shake(0.12)
		"pull":                                            # sedot musuh sekitar ke arah pemain, lalu tebas
			CharFx.skill_vortex(s.fx_root, cd.id, pos, rng * 0.8, 0.35)
			var ts: Array = s._ult_targets(pos, rng + 0.4)
			for e in ts:
				s._hit_any(e, dmg, kb, col)
			for e in ts:
				var en := e as Enemy
				if en == null or en.is_boss or en.dead:
					continue
				var to: Vector3 = pos - en.global_position
				to.y = 0.0
				var d := to.length()
				if d > 1.3:
					en.global_position += to.normalized() * minf(d - 1.3, 1.8)
		"multi":                                           # beberapa tebasan beruntun
			var n := int(st.get("x", 2))
			var gap := float(st.get("gap", 0.12))
			for i in n:
				if i > 0:
					await s.get_tree().create_timer(gap).timeout
					if not _alive(s):
						return
					pos = p.global_position
					dir = p.forward_dir()
					yaw = atan2(dir.x, dir.z)
				_slash_fx(s, cd, st, pos, yaw, rng, col, idx + i, big and i == n - 1)
				s._melee(origin, dir, rng, half, dmg, kb, col)
				if i == n - 1:
					s.cam.shake(0.07)
		"wave":                                            # tebasan + gelombang menembus ke depan
			_slash_fx(s, cd, st, pos, yaw, cd.attack_range, col, idx, true)
			s._melee(origin, dir, cd.attack_range, 80.0, dmg * 0.5, kb, col)
			_wave(s, cd, origin, dir, dmg * 0.5, rng * 3.0, kb, col)
			s.cam.shake(0.08)
		"shot", "twin", "fan", "burst", "echo", "pierce", "big":
			await _ranged(s, cd, st, typ, origin, dir, dmg, kb, col)
		"rain":
			await _rain(s, cd, st, pos, dir, dmg, kb, col)
		"bomb":
			_bombs(s, cd, st, pos, fwd, dmg, kb, col, rng)
		"nova":
			var nr := float(st.get("r", 3.5))
			CharFx.skill_nova(s.fx_root, cd.id, pos, nr, col)
			s._ult_aoe(pos, nr, dmg, kb, col)
			s.cam.shake(0.08)
		"chain":
			_chain(s, cd, st, origin, dir, pos, dmg, kb, col)
		_:
			s._melee(origin, dir, rng, half, dmg, kb, col)


static func _alive(s: Stage) -> bool:
	return is_instance_valid(s) and s.state != Stage.S.ENDED and is_instance_valid(s.player) and not s.player.dead


## Visual tebasan khas karakter (palu Brann pakai hantaman).
static func _slash_fx(s: Stage, cd: CharacterData, st: Dictionary, pos: Vector3, yaw: float, rng: float, col: Color, idx: int, big: bool) -> void:
	if cd.attack_kind == "smash":
		CharFx.attack_smash(s.fx_root, cd.id, pos, yaw, rng, col, int(st.get("a", 1)) - 1)
	else:
		CharFx.attack_slash(s.fx_root, cd.id, pos, yaw, rng, col, idx, big)


static func _spd(cd: CharacterData, kind: String) -> float:
	if kind == "arrow":
		return 24.0
	return 28.0 if cd.id == "kiriel" else 15.0


static func _rng_of(kind: String) -> float:
	return 17.0 if kind == "arrow" else 13.0


## Satu peluru pemain. scale>1 = peluru besar; pierce = menembus; aoe>0 = meledak di titik kena (radius aoe).
static func _proj(s: Stage, cd: CharacterData, kind: String, from: Vector3, dir: Vector3, dmg: float, speed: float, rng: float, col: Color,
		kb: float, sc: float = 1.0, pierce: bool = false, aoe: float = 0.0) -> void:
	var pr := Projectile.make(kind, col)
	pr.target_group = "enemies"
	CharFx.decorate_projectile(pr, kind, cd.id, col)
	s.fx_root.add_child(pr)
	pr.launch(Vector3(from.x, 1.0, from.z) + dir * 0.7, dir, speed, rng)
	if sc != 1.0:
		pr.scale = Vector3.ONE * sc
		pr.hit_radius *= sc
	pr.pierce = pierce
	pr.include_ghosts = s.pvp
	if aoe > 0.0:
		pr.on_hit = func(t: Node) -> void:
			if not is_instance_valid(s):
				return
			var c: Vector3 = pr.global_position if is_instance_valid(pr) else (t as Node3D).global_position
			c.y = 0.0
			Fx.ring(s.fx_root, Vector3(c.x, 0.1, c.z), aoe, col, 0.4)
			Fx.burst(s.fx_root, c + Vector3(0, 0.5, 0), col.lightened(0.3), 18, 7.0, 0.16)
			CharFx.x_flash(s.fx_root, c + Vector3(0, 0.8, 0), Color(1, 1, 0.9), 2.0, 0.2)
			s._ult_aoe_slack(c, aoe, dmg, kb, col)
			s.cam.shake(0.1)
	else:
		pr.on_hit = func(t: Node) -> void:
			if is_instance_valid(s):
				s._hit_any(t, dmg, kb, col)
	Sfx.play("shoot", 1.2 if kind == "arrow" else 0.9, -4.0)


static func _ranged(s: Stage, cd: CharacterData, st: Dictionary, typ: String, origin: Vector3, dir: Vector3, dmg: float, kb: float, col: Color) -> void:
	var kind := cd.attack_kind if cd.attack_kind in ["bolt", "arrow"] else "bolt"
	var spd := _spd(cd, kind)
	var rg := _rng_of(kind)
	var n := int(st.get("x", 1))
	var side := dir.cross(Vector3.UP).normalized()
	if cd.id == "kiriel":
		StormFx.bolt(s.fx_root, origin + dir * 0.3, origin + dir * 1.9, col, 0.12, 0.22, 3)
	match typ:
		"shot":
			_proj(s, cd, kind, origin, dir, dmg, spd, rg, col, kb)
		"twin":
			for sg in [-1.0, 1.0]:
				_proj(s, cd, kind, origin + side * 0.45 * float(sg), dir, dmg, spd, rg, col, kb)
		"fan":
			var sp := float(st.get("sp", 12.0))
			for i in n:
				var a := 0.0 if n <= 1 else lerpf(-sp, sp, float(i) / float(n - 1))
				_proj(s, cd, kind, origin, dir.rotated(Vector3.UP, deg_to_rad(a)), dmg, spd, rg, col, kb)
		"burst", "echo":
			var gap := float(st.get("gap", 0.12))
			for i in n:
				if i > 0:
					await s.get_tree().create_timer(gap).timeout
					if not _alive(s):
						return
					origin = s.player.global_position + Vector3(0, 0.9, 0)
					dir = s.player.forward_dir()
				_proj(s, cd, kind, origin, dir, dmg, spd, rg, col, kb, 1.0 if typ == "burst" else 0.9)
		"pierce":
			_proj(s, cd, kind, origin, dir, dmg, spd * 1.1, rg + 2.0, col, kb, 1.6, true)
			s.cam.shake(0.06)
		"big":
			_proj(s, cd, kind, origin, dir, dmg, spd * 0.75, rg, col, kb, 2.2, false, float(st.get("r", 2.5)))


## Peluru gelombang tebasan menembus (Hakuya): tiga bilah membentuk busur tipis, melesat di sepanjang tanah setinggi pinggang.
static func _wave(s: Stage, cd: CharacterData, origin: Vector3, dir: Vector3, dmg: float, dist: float, kb: float, col: Color) -> void:
	var pr := Projectile.make("bolt", col)
	pr.target_group = "enemies"
	for c in pr.get_children():                      # buang bola bawaan & lampu: gelombang = bidang tipis
		if c is MeshInstance3D or c is OmniLight3D:
			pr.remove_child(c)
			c.free()
	pr.add_child(wave_visual(col))
	s.fx_root.add_child(pr)
	pr.launch(Vector3(origin.x, 1.0, origin.z) + dir * 0.9, dir, 17.0, dist)
	pr.hit_radius = 1.1
	pr.pierce = true
	pr.include_ghosts = s.pvp
	pr.on_hit = func(t: Node) -> void:
		if is_instance_valid(s):
			s._hit_any(t, dmg, kb, col)
	CharFx.trail(pr, col, 14, 0.2, 0.35, 0.5, true, "flame")


static func wave_visual(col: Color) -> Node3D:
	var root := Node3D.new()
	var glow := Fx._unshaded(Color(col.r, col.g, col.b, 0.7), true)
	var core := Fx._unshaded(Color(1, 1, 1, 0.95), true)
	# busur: bilah tengah + dua sayap menekuk ke belakang (arah tembak = -Z)
	var defs := [[Vector3(0, 0, 0), 0.0, 1.5], [Vector3(-0.95, 0, 0.3), 28.0, 1.1], [Vector3(0.95, 0, 0.3), -28.0, 1.1]]
	for d in defs:
		for layer in 2:
			var mi := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(float(d[2]), 0.05, 0.22) if layer == 0 else Vector3(float(d[2]) * 0.9, 0.04, 0.07)
			mi.mesh = bm
			mi.material_override = glow if layer == 0 else core
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			mi.position = d[0]
			mi.rotation_degrees.y = float(d[1])
			root.add_child(mi)
	return root


## Bintang jatuh (Lyra): lingkaran penanda di musuh terdekat, lalu bintang menghantam area.
static func _rain(s: Stage, cd: CharacterData, st: Dictionary, pos: Vector3, dir: Vector3, dmg: float, kb: float, col: Color) -> void:
	var rad := float(st.get("r", 2.3))
	var best: Node3D = null
	var bd := 1e9
	for e in s._ult_targets(pos, cd.attack_range + 1.0):
		var d := (e as Node3D).global_position.distance_to(pos)
		if d < bd:
			bd = d
			best = e
	var tp := (best.global_position if best != null else pos + dir * 4.5)
	tp.y = pos.y
	Fx.magic_circle(s.fx_root, tp, rad, col, 0.4)
	CharFx.puff(s.fx_root, tp + Vector3(0, 5.0, 0), col.lightened(0.3), 8, 12.0, 0.16, Vector3.DOWN, 6.0, 0.0, 0.4, "spark")
	await s.get_tree().create_timer(0.4).timeout
	if not _alive(s):
		return
	Fx.ring(s.fx_root, tp + Vector3(0, 0.1, 0), rad, col, 0.4)
	CharFx.x_flash(s.fx_root, tp + Vector3(0, 0.8, 0), Color(1, 1, 1), 2.0, 0.2)
	CharFx.puff(s.fx_root, tp + Vector3(0, 0.5, 0), col, 14, 6.0, 0.14, Vector3.UP, 180.0, -3.0, 0.6, "spark")
	s._ult_aoe_slack(tp, rad, dmg, kb, col)
	s.cam.shake(0.09)


## Petir berantai (Kiriel): menyambar hingga x musuh terdekat berurutan. Tanpa musuh: sambaran lurus ke depan (hanya visual).
static func _chain(s: Stage, cd: CharacterData, st: Dictionary, origin: Vector3, dir: Vector3, pos: Vector3, dmg: float, kb: float, col: Color) -> void:
	var ts: Array = s._ult_targets(pos, cd.attack_range + 2.0)
	ts.sort_custom(func(a, b): return (a as Node3D).global_position.distance_to(pos) < (b as Node3D).global_position.distance_to(pos))
	var n := mini(int(st.get("x", 3)), ts.size())
	if n <= 0:
		StormFx.bolt(s.fx_root, origin + dir * 0.4, origin + dir * 5.0, col, 0.2, 0.45, 6)
		return
	var pts: Array = []
	for i in n:
		pts.append((ts[i] as Node3D).global_position + Vector3(0, 1.0, 0))
	StormFx.chain(s.fx_root, origin, pts, col)
	for i in n:
		StormFx.strike(s.fx_root, (ts[i] as Node3D).global_position, col)
		s._hit_any(ts[i], dmg, kb, col)
	s.cam.shake(0.09)


# =====================================================================
#  BOM (Zyrax): bom dilempar melengkung ke musuh terdekat, menyala berkedip selama sumbu, lalu meledak di area.
# =====================================================================
## Titik sasaran bom: musuh terdekat dalam `reach` meter (arah hadap diutamakan); tanpa musuh = `fallback` meter di depan.
static func bomb_target(s: Stage, pos: Vector3, fwd: Vector3, reach: float, fallback: float) -> Vector3:
	var best: Vector3 = pos + fwd * fallback
	var bd := reach
	for e in s.get_tree().get_nodes_in_group("enemies"):
		var en := e as Node3D
		if en == null or not is_instance_valid(en) or ("dead" in en and en.dead):
			continue
		var to := en.global_position - pos
		to.y = 0.0
		var d := to.length()
		if d < bd:
			bd = d
			best = en.global_position
	best.y = 0.0
	return best


## Satu langkah kombo bertipe "bomb": x bom (tersebar sp meter di sekitar sasaran), tiap bom meledak radius r setelah sumbu fuse detik.
static func _bombs(s: Stage, cd: CharacterData, st: Dictionary, pos: Vector3, fwd: Vector3, dmg: float, kb: float, col: Color, _rng: float) -> void:
	var n := int(st.get("x", 1))
	var spread := float(st.get("sp", 0.0))
	var radius := float(st.get("r", 2.2))
	var fuse := float(st.get("fuse", 0.5))
	var big := bool(st.get("big", false))
	var tgt := bomb_target(s, pos, fwd, 9.0, 5.0)
	var from := pos + Vector3(0, 1.4, 0) + fwd * 0.4
	for i in n:
		var to := tgt
		if n > 1:
			var a := TAU * float(i) / float(n) + randf() * 0.4
			to = tgt + Vector3(sin(a), 0, cos(a)) * spread
		throw_bomb(s, cd, from, to, dmg, radius, fuse + 0.08 * i, kb, col, big)
	s.cam.shake(0.04)


## Lempar satu bom dari `from` ke titik tanah `to`. Berjalan sendiri (tidak perlu di-await).
static func throw_bomb(s: Stage, cd: CharacterData, from: Vector3, to: Vector3, dmg: float, radius: float, fuse: float, kb: float, col: Color, big: bool = false) -> void:
	var b := _bomb_node(col, 0.3 if big else 0.2)
	s.fx_root.add_child(b)
	b.global_position = from
	var flight := 0.22 + from.distance_to(to) * 0.016
	var tw := b.create_tween()
	tw.tween_method(func(t: float) -> void:
		b.global_position = from.lerp(Vector3(to.x, 0.3, to.z), t) + Vector3(0, sin(t * PI) * 1.8, 0), 0.0, 1.0, flight)
	Sfx.play("shoot", 0.7, -5.0)
	var tele: MeshInstance3D = Fx.telegraph(s.fx_root, to, radius, flight + fuse, col)
	await s.get_tree().create_timer(flight).timeout
	if is_instance_valid(b):                                   # sumbu menyala: bom berdenyut makin cepat
		var core: Node3D = b.get_node_or_null("Core")
		if core:
			var pt := core.create_tween().set_loops(4)
			pt.tween_property(core, "scale", Vector3(1.6, 1.6, 1.6), fuse * 0.12)
			pt.tween_property(core, "scale", Vector3(1.0, 1.0, 1.0), fuse * 0.12)
	await s.get_tree().create_timer(fuse).timeout
	if is_instance_valid(b):
		b.queue_free()
	if is_instance_valid(tele):
		tele.queue_free()
	if not is_instance_valid(s) or s.state == Stage.S.ENDED:
		return
	explode(s, to, radius, dmg, kb, col, big)


static func _bomb_node(col: Color, size: float) -> Node3D:
	var root := Node3D.new()
	root.name = "Bomb"
	root.add_to_group("bombs")                                   # nama kembar diberi akhiran otomatis oleh Godot -> pencarian lewat grup
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = size
	sm.height = size * 2.0
	sm.radial_segments = 10
	sm.rings = 5
	mi.mesh = sm
	mi.material_override = Fx._unshaded(Color(0.07, 0.05, 0.13, 1.0), false)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(mi)
	var core := MeshInstance3D.new()                             # inti menyala (mata X bom Zyrax)
	core.name = "Core"
	var cs := SphereMesh.new()
	cs.radius = size * 0.62
	cs.height = size * 1.24
	cs.radial_segments = 8
	cs.rings = 4
	core.mesh = cs
	core.material_override = Fx._unshaded(Color(col.r, col.g, col.b, 0.85), true)
	core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	core.position = Vector3(0, 0, size * 0.45)
	root.add_child(core)
	return root


## Ledakan bom: cincin + percikan + kilat X + asap, lalu damage area (radius memperhitungkan badan musuh).
static func explode(s: Stage, pos: Vector3, radius: float, dmg: float, kb: float, col: Color, big: bool = false) -> void:
	var g := Vector3(pos.x, 0.1, pos.z)
	Fx.ring(s.fx_root, g, radius, col, 0.45)
	Fx.ring(s.fx_root, g, radius * 0.55, Color(1, 1, 1), 0.3)
	Fx.burst(s.fx_root, g + Vector3(0, 0.4, 0), col.lightened(0.3), 18 if big else 12, 7.0, 0.16)
	CharFx.x_flash(s.fx_root, g + Vector3(0, 0.9, 0), Color(1, 1, 1), radius * 0.9, 0.18)
	CharFx.puff(s.fx_root, g + Vector3(0, 0.3, 0), Color(0.16, 0.1, 0.28), 8, 4.0, 0.5, Vector3.UP, 120.0, 0.0, 0.7, "sphere", false)
	if big:
		CharFx.cracks(s.fx_root, g, radius * 0.9, col, 0.6, 7)
	Sfx.play("boom", 1.0, -3.0)
	if dmg > 0.0:                                                # dmg <= 0: ledakan visual saja (ULTI)
		s._ult_aoe_slack(pos, radius, dmg, kb, col)
	s.cam.shake(0.14 if big else 0.07)
