class_name StageHud
extends Control
## HUD stage: barisan party (ketuk untuk ganti karakter), HP, info gelombang, bar HP bos, tombol Ramuan, tombol jeda + menu jeda, banner tengah.

signal switch_requested(idx: int)
signal potion_requested
signal pause_requested
signal resume_requested
signal retry_requested
signal quit_requested

var stage_minimap: Control
var _party_row: HBoxContainer
var _cards: Array = []
var _sb_card_on: StyleBoxFlat           # PERF: StyleBox kartu aktif/biasa dibuat sekali (dulu 4 objek baru tiap 0,1 dtk)
var _sb_card_off: StyleBoxFlat
var _hp_bar: ProgressBar
var _hp_lbl: Label
var _mp_bar: ProgressBar
var _mp_lbl: Label
var _name_lbl: Label
var _wave_lbl: Label
var _wave_sub: Label
var _boss_box: PanelContainer
var _boss_name: Label
var _boss_bar: ProgressBar
var _potion_btn: Button
var _potion_lbl: Label
var _potion_cd: ProgressBar
var _banner: Label
var _pause_btn: Button
var _pause_panel: Control
var _banner_tween: Tween
var _party_ids: Array = []
var _obj_box: PanelContainer
var _obj_lbl: Label
var _obj_bar: ProgressBar
var _say_box: PanelContainer
var _say_who: Label
var _say_txt: Label
var _say_tween: Tween
var _boon_lbl: Label


func _ready() -> void:
	theme = UiTheme.get_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	UiTheme.apply_safe_area(self)
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_party()
	_build_top()
	_build_potion()
	_build_banner()
	_build_say()
	_build_pause()


func _build_party() -> void:
	var box := VBoxContainer.new()
	box.position = Vector2(10, 10)
	box.add_theme_constant_override("separation", 6)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(box)
	_party_row = HBoxContainer.new()
	_party_row.add_theme_constant_override("separation", 6)
	_party_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(_party_row)
	var info := PanelContainer.new()
	info.add_theme_stylebox_override("panel", UiTheme.box(Color(0.04, 0.10, 0.17, 0.88), UiTheme.GOLD_DARK, 2, 14, 8))
	info.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(info)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 2)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	info.add_child(v)
	_name_lbl = UiTheme.label("", 22, UiTheme.GOLD)
	v.add_child(_name_lbl)
	var hr := HBoxContainer.new()
	hr.add_theme_constant_override("separation", 6)
	hr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hr.add_child(UiIcon.make("heart", Color(1, 0.4, 0.45), 22))
	_hp_bar = UiTheme.bar(Color(0.95, 0.35, 0.4), 1.0, 18.0)
	_hp_bar.custom_minimum_size = Vector2(190, 18)
	_hp_bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hr.add_child(_hp_bar)
	_hp_lbl = UiTheme.label("", 16, UiTheme.TEXT)
	hr.add_child(_hp_lbl)
	v.add_child(hr)
	var mr := HBoxContainer.new()                              # bar mana (MP) tepat di bawah HP
	mr.add_theme_constant_override("separation", 6)
	mr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mr.add_child(UiTheme.label("MP", 15, Color(0.55, 0.75, 1.0)))
	_mp_bar = UiTheme.bar(Color(0.3, 0.55, 1.0), 1.0, 12.0)
	_mp_bar.custom_minimum_size = Vector2(190, 12)
	_mp_bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	mr.add_child(_mp_bar)
	_mp_lbl = UiTheme.label("", 14, UiTheme.TEXT)
	mr.add_child(_mp_lbl)
	v.add_child(mr)
	_boon_lbl = UiTheme.label("", 14, Color(0.95, 0.85, 0.5))
	_boon_lbl.custom_minimum_size = Vector2(300, 0)
	_boon_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_boon_lbl.add_theme_color_override("font_outline_color", Color(0.03, 0.08, 0.14, 0.95))
	_boon_lbl.add_theme_constant_override("outline_size", 5)
	_boon_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_boon_lbl.visible = false
	box.add_child(_boon_lbl)


## Kedipkan bar mana (dipanggil saat skill ditolak karena mana kurang).
func flash_mana() -> void:
	if _mp_bar == null:
		return
	var t := create_tween()
	t.tween_property(_mp_bar, "modulate", Color(1.8, 0.7, 0.7), 0.08)
	t.tween_property(_mp_bar, "modulate", Color(1, 1, 1), 0.25)


func _build_top() -> void:
	var col := VBoxContainer.new()
	col.set_anchors_preset(Control.PRESET_CENTER_TOP)
	col.grow_horizontal = Control.GROW_DIRECTION_BOTH
	col.offset_top = 8
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.alignment = BoxContainer.ALIGNMENT_BEGIN
	add_child(col)
	var pill := PanelContainer.new()                           # info gelombang dalam pelat kaca kristal agar terbaca di atas peta apa pun
	pill.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	pill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pill.add_theme_stylebox_override("panel", UiTheme.box(Color(0.02, 0.06, 0.11, 0.66), Color(UiTheme.GOLD, 0.55), 1, 14, 8))
	col.add_child(pill)
	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 0)
	pv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pill.add_child(pv)
	_wave_lbl = UiTheme.label("", 26, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	_wave_lbl.add_theme_constant_override("outline_size", 4)
	pv.add_child(_wave_lbl)
	_wave_sub = UiTheme.label("", 17, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER)
	_wave_sub.add_theme_constant_override("outline_size", 3)
	pv.add_child(_wave_sub)
	_obj_box = PanelContainer.new()
	_obj_box.custom_minimum_size = Vector2(380, 0)
	_obj_box.add_theme_stylebox_override("panel", UiTheme.box(Color(0.04, 0.10, 0.17, 0.9), Color(0.6, 0.85, 1.0), 2, 12, 6))
	_obj_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_obj_box.visible = false
	col.add_child(_obj_box)
	var ov := VBoxContainer.new()
	ov.add_theme_constant_override("separation", 3)
	ov.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_obj_box.add_child(ov)
	_obj_lbl = UiTheme.label("", 19, Color(0.8, 0.93, 1.0), HORIZONTAL_ALIGNMENT_CENTER)
	ov.add_child(_obj_lbl)
	_obj_bar = UiTheme.bar(Color(0.55, 0.85, 1.0), 0.0, 12.0)
	ov.add_child(_obj_bar)
	_boss_box = PanelContainer.new()
	_boss_box.custom_minimum_size = Vector2(460, 0)
	_boss_box.add_theme_stylebox_override("panel", UiTheme.box(Color(0.1, 0.06, 0.16, 0.9), Color(1, 0.5, 0.4), 2, 12, 8))
	_boss_box.visible = false
	col.add_child(_boss_box)
	var bv := VBoxContainer.new()
	_boss_box.add_child(bv)
	_boss_name = UiTheme.label("", 20, Color(1, 0.75, 0.6), HORIZONTAL_ALIGNMENT_CENTER)
	bv.add_child(_boss_name)
	_boss_bar = UiTheme.bar(Color(0.9, 0.3, 0.3), 1.0, 20.0)
	bv.add_child(_boss_bar)
	_pause_btn = Button.new()
	_pause_btn.focus_mode = Control.FOCUS_NONE
	_pause_btn.custom_minimum_size = Vector2(60, 60)
	_pause_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	_pause_btn.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_pause_btn.offset_left = -70
	_pause_btn.offset_right = -10
	_pause_btn.offset_top = 10
	_pause_btn.offset_bottom = 70
	_pause_btn.add_theme_stylebox_override("normal", UiTheme.box(Color(0.06, 0.14, 0.23, 0.9), UiTheme.GOLD_DARK, 2, 14, 4))
	_pause_btn.add_theme_stylebox_override("pressed", UiTheme.box(Color(0.04, 0.08, 0.14, 0.95), UiTheme.GOLD, 3, 14, 4))
	_pause_btn.add_theme_stylebox_override("hover", UiTheme.box(Color(0.12, 0.25, 0.36, 0.95), UiTheme.GOLD, 2, 14, 4))
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bar_h := HBoxContainer.new()
	bar_h.add_theme_constant_override("separation", 8)
	bar_h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for i in 2:
		var r := ColorRect.new()
		r.color = UiTheme.GOLD
		r.custom_minimum_size = Vector2(8, 26)
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bar_h.add_child(r)
	cc.add_child(bar_h)
	_pause_btn.add_child(cc)
	_pause_btn.pressed.connect(func(): pause_requested.emit())
	add_child(_pause_btn)


func _build_potion() -> void:
	_potion_btn = Button.new()
	_potion_btn.focus_mode = Control.FOCUS_NONE
	_potion_btn.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_potion_btn.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_potion_btn.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_potion_btn.offset_left = -80
	_potion_btn.offset_right = 80
	_potion_btn.offset_top = -92
	_potion_btn.offset_bottom = -18
	_potion_btn.add_theme_stylebox_override("normal", UiTheme.box(Color(0.1, 0.3, 0.25, 0.92), Color(0.5, 0.95, 0.7), 3, 16, 4))
	_potion_btn.add_theme_stylebox_override("pressed", UiTheme.box(Color(0.06, 0.2, 0.16, 0.95), Color(0.7, 1, 0.8), 3, 16, 4))
	_potion_btn.add_theme_stylebox_override("hover", UiTheme.box(Color(0.14, 0.4, 0.32, 0.95), Color(0.7, 1, 0.8), 3, 16, 4))
	_potion_btn.add_theme_stylebox_override("disabled", UiTheme.box(Color(0.06, 0.14, 0.14, 0.8), Color(0.3, 0.35, 0.4), 3, 16, 4))
	var h := HBoxContainer.new()
	h.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 8)
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_potion_btn.add_child(h)
	h.add_child(UiIcon.make("potion", Color(0.55, 1.0, 0.75), 40))
	_potion_lbl = UiTheme.label("Ramuan", 20, UiTheme.TEXT)
	h.add_child(_potion_lbl)
	_potion_btn.pressed.connect(func(): potion_requested.emit())
	add_child(_potion_btn)


func _build_banner() -> void:
	_banner = UiTheme.label("", 58, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	_banner.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_banner.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_banner.offset_top = -170
	_banner.offset_left = -500
	_banner.offset_right = 500
	_banner.add_theme_color_override("font_outline_color", Color(0.03, 0.08, 0.14, 1.0))
	_banner.add_theme_constant_override("outline_size", 14)
	_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_banner.modulate.a = 0.0
	add_child(_banner)


func _build_say() -> void:
	_say_box = PanelContainer.new()
	_say_box.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_say_box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_say_box.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_say_box.offset_left = -330
	_say_box.offset_right = 330
	_say_box.offset_top = -190
	_say_box.offset_bottom = -104
	_say_box.add_theme_stylebox_override("panel", UiTheme.box(Color(0.03, 0.08, 0.14, 0.9), UiTheme.GOLD_DARK, 2, 14, 8))
	_say_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_say_box.modulate.a = 0.0
	add_child(_say_box)
	var sv := VBoxContainer.new()
	sv.add_theme_constant_override("separation", 1)
	sv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_say_box.add_child(sv)
	_say_who = UiTheme.label("", 18, UiTheme.GOLD)
	sv.add_child(_say_who)
	_say_txt = UiTheme.label("", 19, UiTheme.TEXT)
	_say_txt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_say_txt.custom_minimum_size = Vector2(620, 0)
	sv.add_child(_say_txt)


## Baris dialog singkat teman satu tim di tengah pertarungan (tidak menjeda game).
func say(who: String, text: String, secs: float = 4.0) -> void:
	if _say_box == null:
		return
	_say_who.text = who
	_say_txt.text = text
	if _say_tween:
		_say_tween.kill()
	_say_tween = create_tween()
	_say_tween.tween_property(_say_box, "modulate:a", 1.0, 0.2)
	_say_tween.tween_interval(secs)
	_say_tween.tween_property(_say_box, "modulate:a", 0.0, 0.5)


## Tujuan tantangan di bawah info gelombang. text = "" menyembunyikan; frac < 0 menyembunyikan bar.
func set_objective(text: String, frac: float) -> void:
	if _obj_box == null:
		return
	_obj_box.visible = text != ""
	_obj_lbl.text = text
	_obj_bar.visible = frac >= 0.0
	if frac >= 0.0:
		_obj_bar.value = clampf(frac, 0.0, 1.0)


func set_boons(text: String) -> void:
	if _boon_lbl == null:
		return
	_boon_lbl.text = text
	_boon_lbl.visible = text != ""


func _build_pause() -> void:
	_pause_panel = Control.new()
	_pause_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_pause_panel.visible = false
	add_child(_pause_panel)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.03, 0.07, 0.65)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_pause_panel.add_child(dim)
	var p := PanelContainer.new()
	p.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	p.grow_horizontal = Control.GROW_DIRECTION_BOTH
	p.grow_vertical = Control.GROW_DIRECTION_BOTH
	p.custom_minimum_size = Vector2(460, 0)
	_pause_panel.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	p.add_child(v)
	v.add_child(UiTheme.label("Jeda", 38, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	var b1 := UiTheme.accent_button("Lanjutkan", UiTheme.GOLD, Vector2(0, 62))
	b1.pressed.connect(func(): resume_requested.emit())
	v.add_child(b1)
	var b2 := UiTheme.button("Ulangi stage", Vector2(0, 58))
	b2.pressed.connect(func(): retry_requested.emit())
	v.add_child(b2)
	var b3 := UiTheme.button("Menyerah, kembali ke lobi", Vector2(0, 58))
	b3.pressed.connect(func(): quit_requested.emit())
	v.add_child(b3)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("menu_back"):
		get_viewport().set_input_as_handled()
		pause_requested.emit()


# ---------------------------------------------------------------- API
func setup_party(ids: Array) -> void:
	_party_ids = ids
	for c in _party_row.get_children():
		c.queue_free()
	_cards.clear()
	for i in ids.size():
		var idx := i
		var cd := Data.character(ids[i])
		var b := Button.new()
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(72, 80)
		b.add_theme_stylebox_override("normal", UiTheme.box(Color(0.06, 0.14, 0.23, 0.9), UiTheme.GOLD_DARK, 2, 14, 4))
		b.add_theme_stylebox_override("pressed", UiTheme.box(Color(0.04, 0.08, 0.14, 0.95), UiTheme.GOLD, 3, 14, 4))
		b.add_theme_stylebox_override("hover", UiTheme.box(Color(0.12, 0.25, 0.36, 0.95), UiTheme.GOLD, 2, 14, 4))
		b.add_theme_stylebox_override("disabled", UiTheme.box(Color(0.1, 0.1, 0.14, 0.85), Color(0.3, 0.3, 0.4), 2, 14, 4))
		var v := VBoxContainer.new()
		v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		v.alignment = BoxContainer.ALIGNMENT_CENTER
		v.add_theme_constant_override("separation", 3)
		v.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var av := PanelContainer.new()
		av.custom_minimum_size = Vector2(44, 44)
		av.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		av.mouse_filter = Control.MOUSE_FILTER_IGNORE
		av.add_theme_stylebox_override("panel", UiTheme.box(cd.accent.darkened(0.15), Color(1, 1, 1, 0.85), 2, 22, 4))
		var ic := UiIcon.make("character", Color(1, 1, 1), 28)
		ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		av.add_child(ic)
		v.add_child(av)
		var nm := UiTheme.label("%d %s" % [i + 1, cd.display_name], 14, UiTheme.TEXT, HORIZONTAL_ALIGNMENT_CENTER)
		v.add_child(nm)
		var hb := UiTheme.bar(Color(0.95, 0.35, 0.4), 1.0, 8.0)
		hb.custom_minimum_size = Vector2(60, 8)
		hb.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		v.add_child(hb)
		b.add_child(v)
		b.pressed.connect(func(): switch_requested.emit(idx))
		_party_row.add_child(b)
		_cards.append({"btn": b, "bar": hb})


func update_party(states: Array, active: int) -> void:
	for i in mini(states.size(), _cards.size()):
		var st: Dictionary = states[i]
		var b: Button = _cards[i]["btn"]
		var hb: ProgressBar = _cards[i]["bar"]
		hb.value = clampf(float(st["hp"]) / maxf(float(st["max"]), 1.0), 0.0, 1.0)
		b.disabled = bool(st["dead"])
		b.modulate = Color(1.15, 1.1, 0.8) if i == active else Color(1, 1, 1)
		var on := i == active
		if _cards[i].get("on", null) != on:                       # ganti StyleBox hanya saat status aktif berubah
			if _sb_card_on == null:
				_sb_card_on = UiTheme.box(Color(0.13, 0.27, 0.39, 0.95), UiTheme.GOLD, 3, 14, 4)
				_sb_card_off = UiTheme.box(Color(0.06, 0.14, 0.23, 0.9), UiTheme.GOLD_DARK, 2, 14, 4)
			_cards[i]["on"] = on
			b.add_theme_stylebox_override("normal", _sb_card_on if on else _sb_card_off)
	if active >= 0 and active < states.size():
		var a: Dictionary = states[active]
		_name_lbl.text = Data.character(_party_ids[active]).display_name
		_hp_bar.value = clampf(float(a["hp"]) / maxf(float(a["max"]), 1.0), 0.0, 1.0)
		_hp_lbl.text = "%d/%d" % [int(a["hp"]), int(a["max"])]
		var mx: float = maxf(float(Data.character(_party_ids[active]).max_mana), 1.0)
		_mp_bar.value = clampf(float(a.get("mana", mx)) / mx, 0.0, 1.0)
		_mp_lbl.text = "%d" % int(a.get("mana", mx))


func set_wave(cur: int, total: int, remaining: int, boss_phase: bool) -> void:
	if boss_phase:
		_wave_lbl.text = "Pertarungan Bos"
	else:
		_wave_lbl.text = "Gelombang %d / %d" % [cur, total]
	_wave_sub.text = "Musuh tersisa: %d" % remaining


## Mode wilayah jelajah: judul wilayah + keterangan (bukan gelombang).
func set_field(title: String, sub: String) -> void:
	_wave_lbl.text = title
	_wave_sub.text = sub


func set_boss(display_name: String, hp: int, max_hp: int, active: bool) -> void:
	_boss_box.visible = active
	if active:
		_boss_name.text = display_name
		_boss_bar.value = clampf(float(hp) / float(max_hp), 0.0, 1.0)


func set_potion(count: int, label: String, cd_frac: float) -> void:
	_potion_lbl.text = "%s ×%d" % [label, count] if count > 0 else "Tidak ada ramuan"
	_potion_btn.disabled = count <= 0 or cd_frac > 0.0
	_potion_btn.modulate.a = 1.0 if count > 0 else 0.7


var _combo_lbl: Label


## Hitungan combo di sisi kanan layar: n = 0 menyembunyikan. mult = pengali damage saat ini (ditampilkan sebagai persen bonus).
func set_combo(n: int, mult: float, left_frac: float) -> void:
	if _combo_lbl == null:
		_combo_lbl = Label.new()
		_combo_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_combo_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		_combo_lbl.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
		_combo_lbl.offset_left = -260.0
		_combo_lbl.offset_right = -16.0
		_combo_lbl.offset_top = -120.0
		_combo_lbl.offset_bottom = -60.0
		_combo_lbl.add_theme_font_size_override("font_size", 26)
		_combo_lbl.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
		_combo_lbl.add_theme_constant_override("outline_size", 6)
		add_child(_combo_lbl)
	if n < 2:
		_combo_lbl.visible = false
		return
	_combo_lbl.visible = true
	var bonus := int(round((mult - 1.0) * 100.0))
	_combo_lbl.text = "%d COMBO" % n + (("\n+%d%% damage" % bonus) if bonus > 0 else "")
	_combo_lbl.add_theme_color_override("font_color", UiTheme.GOLD if n >= 20 else Color(1, 1, 1))
	_combo_lbl.modulate.a = clampf(0.35 + left_frac, 0.35, 1.0)                 # memudar saat waktu combo hampir habis


func banner(text: String, color: Color = UiTheme.GOLD, secs: float = 1.8) -> void:
	_banner.text = text
	_banner.add_theme_color_override("font_color", color)
	if _banner_tween:
		_banner_tween.kill()
	_banner.modulate.a = 0.0
	_banner.scale = Vector2(1.3, 1.3)
	_banner.pivot_offset = _banner.size * 0.5
	_banner_tween = create_tween()
	_banner_tween.set_parallel(true)
	_banner_tween.tween_property(_banner, "modulate:a", 1.0, 0.25)
	_banner_tween.tween_property(_banner, "scale", Vector2.ONE, 0.25)
	_banner_tween.chain().tween_interval(secs)
	_banner_tween.chain().tween_property(_banner, "modulate:a", 0.0, 0.4)


func show_pause(on: bool) -> void:
	_pause_panel.visible = on


func blocked_rects() -> Array:
	var out: Array = []
	for c: Control in [_party_row, _pause_btn, _potion_btn]:
		out.append(c.get_global_rect().grow(8.0))
	if _pause_panel.visible:
		out.append(get_viewport_rect())
	return out
