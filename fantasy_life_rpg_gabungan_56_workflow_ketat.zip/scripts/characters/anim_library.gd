class_name AnimLibrary
extends RefCounted
## Perpustakaan animasi karakter (rig "ZN RIG V2", 17 tulang). Semua animasi dibuat lewat kode menjadi
## resource `Animation` asli (track rotasi tulang), lalu dimainkan oleh AnimationPlayer / AnimationTree.
## Dengan begini animasi bisa disetel dari kode, dan tetap berupa Animation Godot biasa (bisa dilihat di editor).
##
## Konvensi sudut (euler, radian): untuk lengan x negatif = ayun ke depan/atas; untuk paha x positif = kaki ke belakang.

const MODEL_NODE := "Model/Skeleton3D"        # path skeleton relatif terhadap CharacterRig
const BONES := ["root", "hips", "spine", "chest", "head", "upperarm_l", "forearm_l", "hand_l",
	"upperarm_r", "forearm_r", "hand_r", "thigh_l", "shin_l", "foot_l", "thigh_r", "shin_r", "foot_r"]
const HIPS_REST := Vector3(0, 0.9048, 0)
const FPS := 24.0

static var _lib: AnimationLibrary = null


## Daftar animasi: nama -> [panjang detik, loop?, fungsi pose(u) dengan u dari 0..1]
static var _defs_cache: Dictionary = {}


## Daftar animasi (di-cache: dulu dibangun ulang tiap panggilan, termasuk setiap serangan lewat impact_time()).
static func _defs() -> Dictionary:
	if _defs_cache.is_empty():
		_defs_cache = _build_defs()
	return _defs_cache


static func _build_defs() -> Dictionary:
	return {
		# ---- gerak dasar (bersenjata, dipakai pemain)
		"idle": [4.8, true, func(u): return _p_idle(u, true, 2)],
		"walk": [1.0, true, func(u): return _p_loco(u, 0.5, true)],
		"run": [1.0, true, func(u): return _p_loco(u, 1.0, true)],
		# ---- gerak dasar (tanpa senjata, NPC & monster humanoid)
		"idle_n": [2.4, true, func(u): return _p_idle(u, false)],
		"walk_n": [1.0, true, func(u): return _p_loco(u, 0.42, false)],
		# ---- aksi
		"turn_l": [0.32, false, func(u): return _p_turn(u, 1.0)],
		"turn_r": [0.32, false, func(u): return _p_turn(u, -1.0)],
		"dodge": [0.5, false, func(u): return _p_dodge(u)],
		"attack_sword1": [0.55, false, func(u): return _p_sword(u, 0)],
		"attack_sword2": [0.55, false, func(u): return _p_sword(u, 1)],
		"attack_sword3": [0.8, false, func(u): return _p_sword_finisher(u)],
		"attack_dagger1": [0.3, false, func(u): return _p_dagger(u, 0)],
		"attack_dagger2": [0.3, false, func(u): return _p_dagger(u, 1)],
		"attack_dagger3": [0.52, false, func(u): return _p_dagger(u, 2)],
		"skill_dagger": [0.62, false, func(u): return _p_skill_dagger(u)],
		"attack_staff": [0.6, false, func(u): return _p_staff(u)],
		"attack_staff2": [0.55, false, func(u): return _p_staff2(u)],
		"attack_smash": [0.95, false, func(u): return _p_smash(u)],
		"attack_smash2": [0.85, false, func(u): return _p_smash2(u)],
		"attack_bow": [0.65, false, func(u): return _p_bow(u, false)],
		"attack_bow2": [0.55, false, func(u): return _p_bow(u, false, true)],
		"attack_staff3": [0.85, false, func(u): return _p_staff3(u)],
		"attack_smash3": [1.1, false, func(u): return _p_smash3(u)],
		"attack_bow3": [0.9, false, func(u): return _p_bow3(u)],
		"skill_sword": [0.95, false, func(u): return _p_skill_sword(u)],
		"skill_vortex": [0.95, false, func(u): return _p_skill_vortex(u)],
		"enemy_wind_sword": [2.0, false, func(u): return _p_enemy_wind(u, "sword")],
		"enemy_wind_staff": [2.0, false, func(u): return _p_enemy_wind(u, "staff")],
		"enemy_wind_heavy": [2.0, false, func(u): return _p_enemy_wind(u, "heavy")],
		"enemy_winded": [1.6, false, func(u): return _p_enemy_winded(u)],
		"enemy_roar": [1.3, false, func(u): return _p_enemy_roar(u)],
		"skill_iai": [1.0, false, func(u): return _p_skill_iai(u)],
		"skill_dashcut": [0.8, false, func(u): return _p_skill_dashcut(u)],
		"skill_volley": [1.0, false, func(u): return _p_skill_volley(u)],
		"skill_staff": [1.05, false, func(u): return _p_skill_staff(u)],
		"skill_guard": [1.1, false, func(u): return _p_skill_guard(u)],
		"skill_bow": [0.95, false, func(u): return _p_bow(u, true)],
		"hurt": [0.4, false, func(u): return _p_hurt(u)],
		"death": [1.0, false, func(u): return _p_death(u)],
		"victory": [1.4, true, func(u): return _p_victory(u)],
		# ---- variasi diam NPC
		"idle_cross": [3.0, true, func(u): return _p_cross(u)],
		"idle_hammer": [1.2, true, func(u): return _p_hammer(u)],
		"idle_wave": [2.4, true, func(u): return _p_wave(u)],
		"idle_gesture": [3.0, true, func(u): return _p_gesture(u)],
		"idle_attention": [3.0, true, func(u): return _p_attention(u)],
		"idle_stir": [3.0, true, func(u): return _p_stir(u)],
	}


static func get_library() -> AnimationLibrary:
	if _lib != null:
		return _lib
	_lib = AnimationLibrary.new()
	var defs := _defs()
	for name in defs:
		var d: Array = defs[name]
		var made := _make(d[0], d[1], d[2], not (name.begins_with("enemy_") or name in ["death", "victory"]))
		if name.begins_with("attack_") or name.begins_with("skill_"):
			_polish_attack(made, name)
		_lib.add_animation(name, made)
	if not bake_disabled:
		_load_baked(_lib)
	return _lib


## Animasi hasil anti-tembus (fit), gaya serang, ulti & fidget dihitung SEKALI saat pengembangan (tools/bake_anims.tscn) dan
## disimpan di BAKE_PATH. Di HP file ini hanya dimuat -> tidak ada perhitungan berat saat karakter muncul / saat fidget pertama.
## Bila file tidak ada (atau nama tidak ada di dalamnya) semuanya tetap dihitung saat dibutuhkan seperti sebelumnya.
const BAKE_PATH := "res://resources/anim_baked.res"
static var bake_disabled := false
static var baked_count := 0


static func _load_baked(lib: AnimationLibrary) -> void:
	if not ResourceLoader.exists(BAKE_PATH):
		return
	var b = load(BAKE_PATH)
	if not (b is AnimationLibrary):
		return
	for nm in (b as AnimationLibrary).get_animation_list():
		if lib.has_animation(nm):
			lib.remove_animation(nm)
		lib.add_animation(nm, (b as AnimationLibrary).get_animation(nm))
		baked_count += 1
	var fd: Dictionary = (b as AnimationLibrary).get_meta("fit_done", {})
	for k in fd:
		_fit_done[String(k)] = bool(fd[k])


static func names() -> Array:
	return _defs().keys()


static func _make(length: float, loop: bool, fn: Callable, soft: bool = true) -> Animation:
	var anim := Animation.new()
	anim.length = length
	anim.loop_mode = Animation.LOOP_LINEAR if loop else Animation.LOOP_NONE
	var tracks := {}
	for b in BONES:
		var ti := anim.add_track(Animation.TYPE_ROTATION_3D)
		anim.track_set_path(ti, NodePath("%s:%s" % [MODEL_NODE, b]))
		tracks[b] = ti
	var hip_t := anim.add_track(Animation.TYPE_POSITION_3D)
	anim.track_set_path(hip_t, NodePath("%s:hips" % MODEL_NODE))
	var n := maxi(2, int(ceil(length * FPS)))
	for i in n + 1:
		var u := float(i) / n
		var pose: Dictionary = fn.call(u)
		var tm := u * length
		for b in BONES:
			anim.rotation_track_insert_key(tracks[b], tm, Quaternion.from_euler(pose[b]))
		anim.position_track_insert_key(hip_t, tm, HIPS_REST + Vector3(pose["hx"], pose["bob"], pose["hz"]))
	if soft:
		_overlap(anim, tracks, n, loop)
	return anim


## Follow-through / overlapping action: bagian ujung (lengan bawah, pergelangan, kepala, dada) tertinggal beberapa frame di belakang
## gerakan pangkalnya, jadi pose tidak lagi "patah" kaku dari kunci ke kunci. Pada animasi berulang, lag dihitung melingkar.
## Hanya pose sekunder; bahu/pinggul/kaki (yang menentukan momen impak & langkah) tidak disentuh.
const OVERLAP := {                # tulang: [lag frame, bobot]
	"forearm_l": [1, 0.30], "forearm_r": [1, 0.30], "hand_l": [2, 0.45], "hand_r": [2, 0.45],
	"head": [2, 0.35], "chest": [1, 0.25],
}


static func _overlap(anim: Animation, tracks: Dictionary, n: int, loop: bool) -> void:
	for b in OVERLAP:
		var lag: int = OVERLAP[b][0]
		var wgt: float = OVERLAP[b][1]
		var ti: int = tracks[b]
		var src: Array = []
		for k in n + 1:
			src.append(anim.track_get_key_value(ti, k) as Quaternion)
		for k in n + 1:
			var j := k - lag
			if j < 0:
				j = (j + n) % n if loop else 0
			anim.track_set_key_value(ti, k, (src[k] as Quaternion).slerp(src[j], wgt).normalized())
	if loop:                                         # kunci terakhir = kunci pertama (siklus mulus)
		for b in OVERLAP:
			var ti2: int = tracks[b]
			anim.track_set_key_value(ti2, n, anim.track_get_key_value(ti2, 0))


# =====================================================================
#  Util pose
# =====================================================================
static func _base() -> Dictionary:
	var d := {}
	for b in BONES:
		d[b] = Vector3.ZERO
	d["bob"] = 0.0
	d["hx"] = 0.0
	d["hz"] = 0.0
	return d


static func _mix(a: Dictionary, b: Dictionary, w: float) -> Dictionary:
	var o := {}
	for k in a:
		if a[k] is Vector3:
			o[k] = (a[k] as Vector3).lerp(b[k], w)
		else:
			o[k] = lerpf(a[k], b[k], w)
	return o


static func _ease_out(k: float) -> float:
	return 1.0 - pow(1.0 - clampf(k, 0.0, 1.0), 3.0)


static func _ease_io(k: float) -> float:
	k = clampf(k, 0.0, 1.0)
	return k * k * (3.0 - 2.0 * k)


## Pulihkan ke pose siaga di bagian akhir animasi aksi supaya sambungan ke gerak dasar mulus.
static func _recover(strike: Dictionary, u: float, from_u: float = 0.74, armed: bool = true) -> Dictionary:
	if u <= from_u:
		return strike
	return _mix(strike, _p_idle(0.0, armed), _ease_io((u - from_u) / (1.0 - from_u)))


# =====================================================================
#  Gerak dasar
# =====================================================================
## Gelombang kecil 0..1 berpusat di c (lebar w): dipakai untuk gerak sesekali (melirik, meregang) agar idle tidak monoton.
static func _bump(u: float, c: float, w: float) -> float:
	var x := (u - c) / w
	return exp(-x * x)


## Sinus tertunda yang bernilai 0 pada u = 0, jadi pose awal idle tetap sama (dipakai sebagai pose dasar serangan).
static func _lag(ph: float, lag: float) -> float:
	return sin(ph - lag) + sin(lag)


## Diam: napas (dada & lengan mengikuti napas dengan jeda), berat badan berpindah kaki, kepala melirik sesekali, bahu/tangan terus bergerak halus.
## cycles = jumlah napas per putaran animasi. Semua suku tambahan bernilai 0 pada u = 0.
static func _p_idle(u: float, armed: bool, cycles: int = 1) -> Dictionary:
	var d := _base()
	var ph := u * TAU
	var br := sin(ph * cycles)
	var br2 := _lag(ph * cycles, 0.9)
	var ws := sin(ph)
	var wl := maxf(ws, 0.0)
	var wr := maxf(-ws, 0.0)
	var glance := _bump(u, 0.68, 0.05) - 0.6 * _bump(u, 0.3, 0.06)
	var stretch := _bump(u, 0.42, 0.07)
	d["spine"] = Vector3(0.02 * br - 0.02 * stretch, 0.012 * ws, -0.008 * ws)        # diam = napas halus, bukan menggoyang badan kiri-kanan
	d["chest"] = Vector3(0.025 * br + 0.03 * br2 - 0.05 * stretch, -0.01 * ws, 0.025 * stretch)
	d["head"] = Vector3(-0.03 + 0.02 * br - 0.03 * br2 - 0.08 * stretch, 0.05 * ws - 0.03 * sin(ph * 2.0) - 0.4 * glance, 0.012 * ws)
	d["upperarm_l"] = Vector3(0.12 * _lag(ph, 0.6) + 0.07 * br2, 0, 0.08 + 0.05 * br + 0.05 * br2 + 0.06 * stretch)       # lengan ikut napas & bobot, bukan beku
	d["forearm_l"] = Vector3(-0.15 - 0.10 * br2 - 0.07 * _lag(ph * 2.0, 0.4), 0, 0)
	d["hand_l"] = Vector3(0.05 * br2, 0, 0)
	if armed:
		d["upperarm_r"] = Vector3(-0.3 + 0.08 * _lag(ph, 0.9), 0, -0.1 - 0.05 * br - 0.04 * br2)
		d["forearm_r"] = Vector3(-0.6 - 0.07 * br2 + 0.06 * _lag(ph * 2.0, 0.7), 0, 0)
		d["hand_r"] = Vector3(-0.1 + 0.04 * _lag(ph, 1.4), 0, 0)
	else:
		d["upperarm_r"] = Vector3(0.12 * _lag(ph, 1.1), 0, -0.08 - 0.05 * br - 0.05 * br2)
		d["forearm_r"] = Vector3(-0.15 - 0.10 * br2, 0, 0)
		d["hand_r"] = Vector3(0.1 * br2, -0.05 * _lag(ph, 1.1), 0)
	# berat badan di satu kaki, kaki lain rileks sedikit menekuk
	d["thigh_l"] = Vector3(-0.05 * wr, 0, 0.03 + 0.015 * ws)
	d["thigh_r"] = Vector3(-0.05 * wl, 0, -0.03 + 0.015 * ws)
	d["shin_l"] = Vector3(0.1 * wr, 0, 0)
	d["shin_r"] = Vector3(0.1 * wl, 0, 0)
	d["foot_l"] = Vector3(-(d["thigh_l"].x + d["shin_l"].x), 0, 0)
	d["foot_r"] = Vector3(-(d["thigh_r"].x + d["shin_r"].x), 0, 0)
	d["hips"] = Vector3(0, 0.008 * br + 0.01 * ws, 0.008 * br + 0.008 * ws)
	d["hx"] = 0.003 * ws
	d["bob"] = -0.012 * (0.5 + 0.5 * br)
	return d


# ---- Siklus jalan/lari berbasis IK kaki: telapak yang menapak bergerak mundur dengan kecepatan tetap (tidak meluncur),
#      lutut ditekuk dua-tulang (paha+betis) mengikuti target pergelangan. Panjang tulang dari hero.glb (satuan model).
const LEG_L1 := 0.2898           # paha
const LEG_L2 := 0.4306           # betis
const LEG_Y0 := 0.7204           # jarak sendi pinggul -> pergelangan saat kaki lurus berdiri
## beta = porsi siklus kaki menapak; step = jarak telapak bergeser saat menapak; zc = pusat tapak terhadap pinggul; lift = tinggi angkat kaki.
## bob_amp bertanda: + badan tertinggi di tengah tapak (jalan), - terendah di tengah tapak (lari, ada fase melayang).
const GAIT_WALK := {"beta": 0.56, "step": 0.66, "zc": 0.0, "lift": 0.12, "bob": -0.078, "bob_amp": 0.02, "hip_yaw": 0.10, "chest_yaw": 0.20,
	"arm": 0.45, "elbow": 0.20, "elbow_sw": 0.25, "lean": 0.05, "roll": 0.035, "shift": 0.014, "hz": 0.0}
const GAIT_RUN := {"beta": 0.34, "step": 0.70, "zc": -0.02, "lift": 0.26, "bob": -0.115, "bob_amp": -0.03, "hip_yaw": 0.20, "chest_yaw": 0.34,
	"arm": 0.95, "elbow": 0.95, "elbow_sw": 0.45, "lean": 0.27, "roll": 0.05, "shift": 0.02, "hz": 0.03}
const WALK_STRIDE := 1.1786      # = step / beta : jarak badan maju per siklus (satuan model)
const RUN_STRIDE := 2.0588


## Panjang langkah per siklus (satuan model) pada posisi blend b (0 diam, 0.5 jalan, 1 lari).
static func stride_units(b: float) -> float:
	if b >= 0.5:
		return lerpf(WALK_STRIDE, RUN_STRIDE, (b - 0.5) / 0.5)
	return WALK_STRIDE * maxf(b / 0.5, 0.3)


## Batas kecepatan putar siklus (siklus/detik) supaya langkah tidak terlihat seperti kaki berlari di tempat.
static func cycle_rate_cap(b: float) -> float:
	if b >= 0.5:
		return lerpf(2.5, 3.1, (b - 0.5) / 0.5)
	return lerpf(1.2, 2.5, b / 0.5)


static func _gait(t: float) -> Dictionary:
	var g := {}
	for k in GAIT_WALK:
		g[k] = lerpf(float(GAIT_WALK[k]), float(GAIT_RUN[k]), t)
	return g


## Dua-tulang IK bidang sagital. (z maju, y ke bawah negatif) relatif sendi pinggul -> Vector2(putar paha x, tekuk lutut x).
static func _leg_ik(z: float, y: float) -> Vector2:
	var d := sqrt(z * z + y * y)
	var dmax := (LEG_L1 + LEG_L2) * 0.995
	if d > dmax:
		z *= dmax / d
		y *= dmax / d
		d = dmax
	d = maxf(d, 0.25)
	var phi := atan2(z, -y)
	var delta := acos(clampf((LEG_L1 * LEG_L1 + d * d - LEG_L2 * LEG_L2) / (2.0 * LEG_L1 * d), -1.0, 1.0))
	var k := acos(clampf((LEG_L1 * LEG_L1 + LEG_L2 * LEG_L2 - d * d) / (2.0 * LEG_L1 * LEG_L2), -1.0, 1.0))
	return Vector2(-(phi + delta), PI - k)


## Lintasan pergelangan satu kaki pada fase p (0 = tumit menapak). Return (z, tinggi di atas tanah, kelas fase: 0..1 tapak, 1..2 ayun).
static func _foot_path(p: float, g: Dictionary, st: float, lift_mul: float) -> Vector3:
	var b: float = g["beta"]
	var s: float = float(g["step"]) * st
	var zc: float = g["zc"]
	if p < b:
		var k := p / b
		var toe := maxf(0.0, (k - 0.8) / 0.2)
		return Vector3(zc + s * (0.5 - k), 0.03 * toe * toe, k)
	var k2 := (p - b) / (1.0 - b)
	var m := -0.5 * s * (1.0 - b) / b                # kaki mengikuti kecepatan tanah saat lepas & mendarat (Hermite)
	var z0 := zc - s * 0.5
	var z1 := zc + s * 0.5
	var k3 := k2 * k2 * k2
	var kk := k2 * k2
	var z := (2.0 * k3 - 3.0 * kk + 1.0) * z0 + (k3 - 2.0 * kk + k2) * m + (-2.0 * k3 + 3.0 * kk) * z1 + (k3 - kk) * m
	var y := float(g["lift"]) * lift_mul * pow(maxf(sin(PI * k2), 0.0), 1.2)
	return Vector3(z, y, 1.0 + k2)


## Siklus jalan/lari. run: 0..1 (0.5 jalan, 1.0 lari penuh; di bawah 0.5 langkah mengecil untuk NPC). st = pengali panjang langkah,
## bounce = pengali pantulan/angkat kaki, crouch = badan lebih rendah (negatif) -> lutut ikut menekuk lewat IK.
static func _p_loco(u: float, run: float, armed: bool, st: float = 1.0, bounce: float = 1.0, crouch: float = 0.0) -> Dictionary:
	var d := _base()
	var t := clampf((run - 0.5) / 0.5, 0.0, 1.0)
	var sc := clampf(run / 0.5, 0.0, 1.0)
	var g := _gait(t)
	var b: float = g["beta"]
	var ph := u * TAU
	var a_l := cos(ph)                               # +1 saat tumit kiri menapak
	var a_r := cos(ph - 0.25)                        # ayunan lengan sedikit tertinggal dari kaki
	var mid := cos(ph - PI * b)                      # +1 saat tengah tapak kiri, -1 saat tengah tapak kanan
	var bob: float = float(g["bob"]) * sc + float(g["bob_amp"]) * bounce * sc * cos(2.0 * (ph - PI * b)) + crouch
	var hz: float = g["hz"]
	var lift_mul := clampf(0.6 + 0.4 * bounce, 0.7, 1.4)
	var hip_yaw := -float(g["hip_yaw"]) * sc * a_l
	var roll := float(g["roll"]) * sc * mid
	d["bob"] = bob
	d["hz"] = hz
	d["hx"] = float(g["shift"]) * sc * mid
	d["hips"] = Vector3(0.0, hip_yaw, roll)
	for side in 2:
		var sfx := "l" if side == 0 else "r"
		var hx_off := 0.1488 if side == 0 else -0.1321
		var f := _foot_path(fposmod(u + 0.5 * side, 1.0), g, st * sc, lift_mul)
		# posisi sendi pinggul ikut bergeser karena pinggul memutar/miring
		var zr := f.x - hz + hx_off * sin(hip_yaw)
		var yr := -LEG_Y0 + f.y - bob - hx_off * sin(roll)
		var ik := _leg_ik(zr, yr)
		d["thigh_" + sfx] = Vector3(ik.x, -hip_yaw, -roll + (0.02 if side == 0 else -0.02))   # kaki tetap lurus ke depan walau pinggul memutar
		d["shin_" + sfx] = Vector3(ik.y, 0, 0)
		var w: float = f.z
		var toe := 0.0
		if w < 1.0:
			toe = 0.55 * pow(maxf(0.0, (w - 0.75) / 0.25), 2.0) - 0.18 * pow(maxf(0.0, (0.15 - w) / 0.15), 2.0)
		else:
			var k2 := w - 1.0
			toe = 0.55 * (1.0 - _ease_io(minf(k2 / 0.5, 1.0))) - 0.18 * _ease_io(clampf((k2 - 0.7) / 0.3, 0.0, 1.0))
		d["foot_" + sfx] = Vector3(-(ik.x + ik.y) + toe, 0, 0)
	# tubuh atas: bahu berlawanan arah dengan pinggul, kepala distabilkan, condong sesuai kecepatan
	var cy := float(g["chest_yaw"]) * sc
	var lean := float(g["lean"]) * sc
	d["spine"] = Vector3(lean * 0.6, cy * 0.45 * a_l, -roll * 0.6)
	d["chest"] = Vector3(lean * 0.4, cy * 0.55 * a_l, -roll * 0.3)
	d["head"] = Vector3(-0.03 - lean * 0.7, -0.7 * (hip_yaw + cy * a_l), 0.0)
	var arm := float(g["arm"]) * sc
	var el := float(g["elbow"]) * sc
	var els := float(g["elbow_sw"]) * sc
	d["upperarm_l"] = Vector3(arm * a_l, 0.0, 0.07)
	d["forearm_l"] = Vector3(-(el + els * (0.5 - 0.5 * a_l)), 0, 0)
	if armed:
		d["upperarm_r"] = Vector3(-0.3 - 0.35 * arm * a_l, 0.0, -0.1)
		d["forearm_r"] = Vector3(-(0.6 + 0.25 * t + 0.3 * els * (0.5 + 0.5 * a_l)), 0, 0)
		d["hand_r"] = Vector3(-0.1, 0, 0)
	else:
		d["upperarm_r"] = Vector3(-arm * a_l, 0.0, -0.07)
		d["forearm_r"] = Vector3(-(el + els * (0.5 + 0.5 * a_l)), 0, 0)
	return d


## Berbelok tajam saat diam: kepala memimpin, lalu dada, pinggang, dan kaki menyusul (rig berputar cepat, tubuh "tertinggal" lalu mengejar);
## satu kaki melangkah memutar, lutut menekuk, lengan terbuka menyeimbangkan. dir: +1 kiri, -1 kanan. Berakhir tepat di pose idle.
static func _p_turn(u: float, dir: float) -> Dictionary:
	var d := _p_idle(0.0, true)
	var e := sin(u * PI)
	var l_head := 1.0 - _ease_io(clampf(u / 0.4, 0.0, 1.0))
	var l_chest := 1.0 - _ease_io(clampf(u / 0.6, 0.0, 1.0))
	var l_hips := 1.0 - _ease_io(clampf(u / 0.78, 0.0, 1.0))
	var l_feet := 1.0 - _ease_io(clampf(u / 0.95, 0.0, 1.0))
	var step := sin(clampf((u - 0.08) / 0.62, 0.0, 1.0) * PI)
	d["hips"] = Vector3(0.0, -dir * 0.5 * l_hips, 0.0)
	d["spine"] = Vector3(0.1 * e, -dir * 0.32 * l_chest, -0.1 * dir * e)
	d["chest"] = Vector3(0.0, -dir * 0.22 * l_chest, 0.0)
	d["head"] = Vector3(-0.05, dir * (0.55 * l_head + 0.5 * l_hips + 0.54 * l_chest), 0.0)
	var lead := 0 if dir > 0.0 else 1
	for side in 2:
		var sfx := "l" if side == 0 else "r"
		var sg := 1.0 if side == 0 else -1.0
		var lift := step if side == lead else 0.0
		var thx := -0.4 * e * (1.0 - lift) - 0.55 * lift
		var shx := 0.8 * e * (1.0 - lift) + 1.0 * lift
		var thy := -dir * 0.7 * l_feet + dir * 0.5 * l_hips
		d["thigh_" + sfx] = Vector3(thx, thy, sg * (0.03 + 0.25 * lift))
		d["shin_" + sfx] = Vector3(shx, 0, 0)
		d["foot_" + sfx] = Vector3(-(thx + shx) * (1.0 - 0.5 * lift), 0, 0)
	d["upperarm_l"] = Vector3(0.05, 0, 0.2 + 0.45 * e)
	d["forearm_l"] = Vector3(-0.35, 0, 0)
	d["upperarm_r"] = Vector3(-0.3 - 0.1 * e, 0, -0.15 - 0.4 * e)
	d["forearm_r"] = Vector3(-0.5, 0, 0)
	d["bob"] = -0.055 * e
	return d


## Menghindar / dash (0,5 dtk; gerak dash sungguhan 0,26 dtk = 0..0,52 animasi). Tiga fase:
## 1) dorongan: berjongkok, satu kaki menolak ke belakang, badan menukik; 2) meluncur: badan rendah condong jauh, satu kaki menjangkau ke depan
## dan satu terentang ke belakang, tangan ke belakang untuk keseimbangan; 3) mendarat: lutut meredam, berat pindah ke kaki depan, lengan ke depan menyeimbangkan, bangkit.
static func _p_dodge(u: float) -> Dictionary:
	var ready := _pz({})
	var push := _pz({"upperarm_l": Vector3(0.7, 0, 0.3), "forearm_l": Vector3(-0.5, 0, 0),
		"upperarm_r": Vector3(0.4, 0, -0.3), "forearm_r": Vector3(-0.8, 0, 0),
		"spine": Vector3(0.55, 0.0, 0), "chest": Vector3(0.1, 0, 0), "head": Vector3(-0.35, 0, 0),
		"thigh_l": Vector3(-0.45, 0, 0.1), "thigh_r": Vector3(0.55, 0, -0.1), "shin_l": Vector3(0.75, 0, 0), "shin_r": Vector3(0.35, 0, 0),
		"bob": -0.2, "hz": 0.04})
	var glide := _pz({"upperarm_l": Vector3(1.25, 0, 0.35), "forearm_l": Vector3(-0.4, 0, 0),
		"upperarm_r": Vector3(0.75, 0, -0.3), "forearm_r": Vector3(-0.55, 0, 0), "hand_r": Vector3(-0.1, 0, 0),
		"spine": Vector3(0.95, 0.15, 0), "chest": Vector3(0.14, 0.08, 0), "head": Vector3(-0.75, -0.1, 0),
		"thigh_l": Vector3(-0.95, 0, 0.1), "thigh_r": Vector3(0.8, 0, -0.1), "shin_l": Vector3(0.45, 0, 0), "shin_r": Vector3(0.4, 0, 0),
		"bob": -0.2, "hz": 0.28})
	var land := _pz({"upperarm_l": Vector3(-0.35, 0, 0.55), "forearm_l": Vector3(-0.5, 0, 0),
		"upperarm_r": Vector3(-0.75, 0, -0.25), "forearm_r": Vector3(-0.9, 0, 0),
		"spine": Vector3(0.45, -0.1, 0), "chest": Vector3(0.06, 0, 0), "head": Vector3(-0.2, 0, 0),
		"thigh_l": Vector3(-0.6, 0, 0.12), "thigh_r": Vector3(0.3, 0, -0.1), "shin_l": Vector3(0.9, 0, 0), "shin_r": Vector3(0.55, 0, 0),
		"bob": -0.2, "hz": 0.12})
	return _seq(u, [[0.0, ready, ""], [0.1, push, "io"], [0.24, glide, "out"], [0.5, glide, "io"], [0.68, land, "out"], [1.0, ready, "io"]])


# =====================================================================
#  Serangan & skill — berfase: 1) antisipasi (menarik/menyiapkan)  2) ayunan cepat (snap + overshoot)
#  3) tahan / follow-through  4) pemulihan ke siaga. Tiap animasi = daftar keyframe pose [waktu 0..1, pose, mode].
#  Mode ease: "io" halus, "out" melambat di akhir, "back" cepat lalu melewati target sedikit (kesan tenaga).
# =====================================================================
## Waktu (fraksi panjang animasi) saat serangan benar-benar mengenai. Dipakai pemain untuk menyinkronkan damage & efek.
const IMPACT := {
	"attack_dagger1": 0.36, "attack_dagger2": 0.36, "attack_dagger3": 0.42, "skill_dagger": 0.40,
	"attack_sword1": 0.36, "attack_sword2": 0.36, "attack_staff": 0.40, "attack_smash": 0.52, "attack_bow": 0.46,
	"skill_sword": 0.52, "skill_vortex": 0.42, "skill_staff": 0.58, "skill_guard": 0.62, "skill_bow": 0.50,
	"attack_sword3": 0.52, "attack_staff2": 0.44, "attack_smash2": 0.50, "attack_bow2": 0.34,
	"attack_staff3": 0.48, "attack_smash3": 0.58, "attack_bow3": 0.62,
	"skill_iai": 0.47, "skill_dashcut": 0.42, "skill_volley": 0.34,
}


static func impact_time(anim: String) -> float:
	if anim.begins_with("ult_"):
		return ULT_LEN * ULT_RELEASE
	if anim.contains("#"):                                  # hasil fit anti-tembus: sama dengan animasi dasarnya
		return impact_time(anim.split("#")[0])
	if anim.contains("@"):                                  # varian per karakter: panjang sudah diskalakan, fraksi impak sama dengan dasar
		var parts := anim.split("@")
		return _atk_len(parts[0], parts[1]) * float(IMPACT.get(parts[0], 0.4))
	var d: Array = _defs().get(anim, [0.5])
	return float(d[0]) * float(IMPACT.get(anim, 0.4))


## Senjata tipis tidak butuh dorongan badan: condong, putaran, dan perpindahan pinggul pada pose serangan diredam (lengan tetap penuh),
## sehingga yang bergerak tebasan tangan/pedang, bukan seluruh badan.
static func _damp_body(anim: Animation, base: String = "") -> void:
	var tr := _fit_tracks(anim)
	for k in tr:
		if int(tr[k]) < 0:
			return
	var n := anim.track_get_key_count(tr["hips"])
	var p0: Vector3 = anim.track_get_key_value(tr["pos"], 0)
	var fi: float = float(IMPACT.get(base, 0.4))
	var arm_q0 := {}
	for k in n:
		var pp: Vector3 = anim.track_get_key_value(tr["pos"], k)
		anim.track_set_key_value(tr["pos"], k, p0 + (pp - p0) * Vector3(0.3, 0.5, 0.3))
		var chain_old := Quaternion.IDENTITY
		var chain_new := Quaternion.IDENTITY
		for b in ["hips", "spine", "chest"]:
			var q: Quaternion = anim.track_get_key_value(tr[b], k)
			var e := Basis(q).get_euler()
			var qn := Quaternion.from_euler(Vector3(e.x * 0.3, e.y * 0.6, e.z * 0.5))
			chain_old = chain_old * q
			chain_new = chain_new * qn
			anim.track_set_key_value(tr[b], k, qn)
		# LENGAN GANTIKAN BADAN: putaran badan yang dibuang tadi dipindahkan ke bahu/lengan, sehingga ayunan tetap besar & hidup
		# (pedang tipis memang diayun dengan lengan, bukan dorongan badan). 0 = lengan ikut badan yang diredam, 1 = orientasi lengan
		# terhadap pinggul sama persis seperti pose asli.
		var delta: Quaternion = (chain_new.inverse() * chain_old).normalized()
		var comp := Quaternion.IDENTITY.slerp(delta, ARM_TAKEOVER)
		for b in ["upperarm_r", "upperarm_l"]:
			var qa: Quaternion = anim.track_get_key_value(tr[b], k)
			anim.track_set_key_value(tr[b], k, (comp * qa).normalized())
		# penguatan ayunan lengan (bahu & siku) terhadap kunci pertama: serangan terasa lebih lepas, siku ikut menekuk/mengayun
		for b in ["upperarm_r", "upperarm_l", "forearm_r", "forearm_l"]:
			var qb: Quaternion = anim.track_get_key_value(tr[b], k)
			if k == 0:
				arm_q0[b] = qb
			else:
				var base_q: Quaternion = arm_q0[b]
				var amp: float = ARM_AMP if b.begins_with("upperarm") else ARM_AMP_ELBOW
				anim.track_set_key_value(tr[b], k, base_q.slerp(qb, amp).normalized())
		# jentikan pergelangan tangan tepat di impak (tangan kanan penuh, kiri sedikit) agar ayunan tidak "kayu"
		var u := float(k) / float(maxi(n - 1, 1))
		var bump := exp(-pow((u - fi) / 0.07, 2.0)) - 0.55 * exp(-pow((u - fi - 0.16) / 0.10, 2.0))
		for side in [["hand_r", 0.34], ["hand_l", 0.12]]:
			var qh: Quaternion = anim.track_get_key_value(tr[side[0]], k)
			anim.track_set_key_value(tr[side[0]], k, (Quaternion(Vector3.RIGHT, float(side[1]) * bump) * qh).normalized())


const ARM_TAKEOVER := 0.75
const ARM_AMP := 1.25
const ARM_AMP_ELBOW := 1.6


## Berat badan pada serangan (hanya senjata berat; pedang/katana/dagger/tongkat/busur tidak ikut dorongan badan): sebelum impak badan merunduk & condong ke belakang (antisipasi), tepat di impak pinggul melesat ke depan dan
## badan condong menghantam, lalu mengendap. Lapisan tambahan di atas pose serangan (rotasi pra-kali pada pinggul/tulang belakang/dada/kepala),
## tidak mengubah panjang animasi maupun momen impak. Skala per kelas senjata (busur/tongkat/palu kecil karena pose aslinya sudah condong).
static func _polish_attack(anim: Animation, base: String) -> void:
	var fi: float = float(IMPACT.get(base, 0.4))
	var sc := 0.0                                   # senjata tipis (pedang, katana, dagger, tongkat, busur): badan tidak ikut terdorong
	if base.contains("smash"):
		sc = 0.25                                   # hanya palu berat yang dapat sedikit bobot
	if sc <= 0.0:
		_damp_body(anim, base)
		return
	var tr := _fit_tracks(anim)
	for k in tr:
		if int(tr[k]) < 0:
			return
	var n := anim.track_get_key_count(tr["hips"])
	for k in n:
		var u := float(k) / float(maxi(n - 1, 1))
		var ant := sin(PI * clampf(u / maxf(fi, 0.05), 0.0, 1.0))
		var rise := _sstep(fi - 0.12, fi, u)
		var fall := 1.0 - _sstep(fi, fi + 0.30, u)
		var lunge := rise * fall
		var pos: Vector3 = anim.track_get_key_value(tr["pos"], k)
		pos += Vector3(0.0, (-0.05 * ant - 0.03 * lunge) * sc, (-0.03 * ant + 0.10 * lunge) * sc)
		anim.track_set_key_value(tr["pos"], k, pos)
		var add := {"spine": (-0.10 * ant + 0.14 * lunge) * sc, "chest": (-0.05 * ant + 0.07 * lunge) * sc, "head": (0.05 * ant - 0.08 * lunge) * sc}
		for b in add:
			var q: Quaternion = anim.track_get_key_value(tr[b], k)
			anim.track_set_key_value(tr[b], k, (Quaternion(Vector3.RIGHT, float(add[b])) * q).normalized())


static func _ease_back(k: float) -> float:
	k = clampf(k, 0.0, 1.0)
	var c1 := 1.9
	var c3 := c1 + 1.0
	return 1.0 + c3 * pow(k - 1.0, 3.0) + c1 * pow(k - 1.0, 2.0)


static func _seq(u: float, frames: Array) -> Dictionary:
	if u <= frames[0][0]:
		return frames[0][1]
	for i in range(1, frames.size()):
		var f: Array = frames[i]
		if u <= f[0]:
			var prev: Array = frames[i - 1]
			var k: float = (u - prev[0]) / maxf(f[0] - prev[0], 0.0001)
			var w := k
			match f[2]:
				"io": w = _ease_io(k)
				"out": w = _ease_out(k)
				"back": w = _ease_back(k)
			return _mix(prev[1], f[1], w)
	return frames[frames.size() - 1][1]


## Pose dasar bersenjata dengan penimpaan (kunci -> nilai); legs menjaga kaki tetap menapak.
static func _pz(o: Dictionary, armed: bool = true) -> Dictionary:
	var d := _p_idle(0.0, armed)
	for k in o:
		d[k] = o[k]
	d["foot_l"] = Vector3(-(d["thigh_l"].x + d["shin_l"].x) * 0.6, 0, 0)
	d["foot_r"] = Vector3(-(d["thigh_r"].x + d["shin_r"].x) * 0.6, 0, 0)
	# torsi pinggul: pinggul ikut memutar (seperempat putaran tulang punggung, arah sama) -> gerak tidak kaku, tenaga dari kaki-pinggul-bahu
	if not o.has("hips"):
		var sp: Vector3 = d["spine"]
		d["hips"] = Vector3(0.0, sp.y * 0.25, sp.z * 0.2)
	# perpindahan berat badan: pinggul bergeser ke sisi kaki yang maju (kiri maju -> geser ke kiri)
	if not o.has("hx"):
		d["hx"] = (d["thigh_r"].x - d["thigh_l"].x) * 0.02
	return d


## Tebasan pedang. combo 0: tebasan atas ke bawah; combo 1: sapuan menyilang kanan ke kiri.
static func _p_sword(u: float, combo: int) -> Dictionary:
	var ready := _pz({})
	var ant: Dictionary
	var hit: Dictionary
	if combo == 0:
		ant = _pz({"upperarm_r": Vector3(-0.81, 0.05, 0.11), "forearm_r": Vector3(-0.96, 0, 0), "hand_r": Vector3(0.01, 0, 0),
			"spine": Vector3(-0.28, -0.3, 0), "chest": Vector3(-0.15, -0.15, 0), "head": Vector3(0.12, 0.1, 0),
			"upperarm_l": Vector3(0.3, 0, 0.7), "forearm_l": Vector3(-0.5, 0, 0),
			"thigh_l": Vector3(0.3, 0, 0.08), "thigh_r": Vector3(-0.2, 0, -0.08), "shin_r": Vector3(0.45, 0, 0), "shin_l": Vector3(0.1, 0, 0),
			"bob": -0.06, "hz": -0.05})
		hit = _pz({"upperarm_r": Vector3(-0.51, -0.41, 0.15), "forearm_r": Vector3(-0.63, 0, 0), "hand_r": Vector3(0.3, 0, 0),
			"spine": Vector3(0.55, 0.25, 0), "chest": Vector3(0.15, 0.1, 0), "head": Vector3(-0.4, -0.1, 0),
			"upperarm_l": Vector3(-0.2, 0, 0.5), "forearm_l": Vector3(-0.4, 0, 0),
			"thigh_l": Vector3(-0.6, 0, 0.1), "thigh_r": Vector3(0.3, 0, -0.08), "shin_l": Vector3(0.35, 0, 0), "shin_r": Vector3(0.3, 0, 0),
			"bob": -0.15, "hz": 0.14})
	else:
		ant = _pz({"upperarm_r": Vector3(-0.01, -0.66, 0.5), "forearm_r": Vector3(-0.56, 0, 0), "hand_r": Vector3(0.21, 0, 0),
			"spine": Vector3(0.12, -0.85, 0), "chest": Vector3(0, -0.35, 0), "head": Vector3(-0.1, 0.55, 0),
			"upperarm_l": Vector3(0.2, 0, 0.8), "forearm_l": Vector3(-0.5, 0, 0),
			"thigh_l": Vector3(0.25, 0, 0.1), "thigh_r": Vector3(-0.15, 0, -0.1), "shin_r": Vector3(0.3, 0, 0),
			"bob": -0.07, "hz": -0.04})
		hit = _pz({"upperarm_r": Vector3(-0.34, -0.57, 0.25), "forearm_r": Vector3(-0.63, 0, 0), "hand_r": Vector3(0.3, 0, 0),
			"spine": Vector3(0.3, 0.9, 0), "chest": Vector3(0, 0.38, 0), "head": Vector3(-0.1, -0.55, 0),
			"upperarm_l": Vector3(-0.4, 0, 0.9), "forearm_l": Vector3(-0.4, 0, 0),
			"thigh_r": Vector3(-0.55, 0, -0.1), "thigh_l": Vector3(0.3, 0, 0.1), "shin_r": Vector3(0.3, 0, 0), "shin_l": Vector3(0.3, 0, 0),
			"bob": -0.12, "hz": 0.12})
	var follow := _mix(hit, ready, 0.35)
	# kunci tengah busur: tangan tetap di depan badan & bilah di atas tanah (hasil FK/optimasi: tak menembus badan/kaki)
	var mid := _mix(ant, hit, 0.5)
	if combo == 0:
		mid["upperarm_r"] = Vector3(-0.76, 0.02, 0.2)
		mid["forearm_r"] = Vector3(-0.76, 0, 0)
		mid["hand_r"] = Vector3(0.5, 0, 0)
		follow["upperarm_r"] = Vector3(-0.32, -0.56, 0.44)
		follow["forearm_r"] = Vector3(-0.5, 0, 0)
		follow["hand_r"] = Vector3(0.25, 0, 0)
	else:
		mid["upperarm_r"] = Vector3(-0.46, -0.17, 0.47)
		mid["forearm_r"] = Vector3(-0.51, 0, 0)
		mid["hand_r"] = Vector3(0.67, 0, 0)
		follow["upperarm_r"] = Vector3(-0.3, -0.45, 0.35)
		follow["forearm_r"] = Vector3(-0.6, 0, 0)
		follow["hand_r"] = Vector3(0.3, 0, 0)
	return _seq(u, [[0.0, ready, ""], [0.26, ant, "io"], [0.32, mid, ""], [0.38, hit, "out"], [0.64, follow, "out"], [1.0, ready, "io"]])


## Serangan tongkat: tarik ke belakang lalu hentakkan ke depan (melepas bola sihir).
static func _p_staff(u: float) -> Dictionary:
	var ready := _pz({})
	var ant := _pz({"upperarm_r": Vector3(-0.8, 0.25, -0.3), "forearm_r": Vector3(-1.9, 0, 0), "hand_r": Vector3(-0.5, 0, 0),
		"upperarm_l": Vector3(-0.7, 0, 0.5), "forearm_l": Vector3(-0.6, 0, 0),
		"spine": Vector3(-0.12, -0.4, 0), "chest": Vector3(-0.06, -0.15, 0), "head": Vector3(0.06, 0.2, 0),
		"thigh_l": Vector3(0.15, 0, 0.06), "thigh_r": Vector3(-0.1, 0, -0.06), "bob": -0.04, "hz": -0.05})
	var hit := _pz({"upperarm_r": Vector3(-1.6, -0.05, -0.1), "forearm_r": Vector3(-0.2, 0, 0), "hand_r": Vector3(0.15, 0, 0),
		"upperarm_l": Vector3(-1.2, 0, 0.3), "forearm_l": Vector3(-0.3, 0, 0),
		"spine": Vector3(0.3, 0.22, 0), "chest": Vector3(0.1, 0.1, 0), "head": Vector3(-0.2, -0.1, 0),
		"thigh_l": Vector3(-0.35, 0, 0.06), "thigh_r": Vector3(0.25, 0, -0.06), "shin_r": Vector3(0.25, 0, 0), "bob": -0.08, "hz": 0.08})
	var follow := _mix(hit, ready, 0.3)
	return _seq(u, [[0.0, ready, ""], [0.3, ant, "io"], [0.46, hit, "back"], [0.68, follow, "out"], [1.0, ready, "io"]])


## Hantaman berat dua tangan (Guardian): angkat tinggi (berjinjit), banting, tahan menekan tanah, bangkit.
static func _p_smash(u: float) -> Dictionary:
	var ready := _pz({})
	# 1) mengumpulkan tenaga: berjongkok, palu ditarik ke samping-belakang
	var load_ := _pz({"upperarm_r": Vector3(-1.0, 0.5, -0.5), "upperarm_l": Vector3(-0.9, 0.4, 0.1),
		"forearm_r": Vector3(-0.8, 0, 0), "forearm_l": Vector3(-0.8, 0, 0),
		"spine": Vector3(-0.08, -0.35, 0), "chest": Vector3(0, -0.2, 0), "head": Vector3(0.2, 0.15, 0),
		"thigh_l": Vector3(0.35, 0, 0.18), "thigh_r": Vector3(-0.15, 0, -0.18), "shin_l": Vector3(0.55, 0, 0), "shin_r": Vector3(0.4, 0, 0),
		"bob": -0.14, "hz": -0.04})
	# 2) angkat tinggi, punggung melengkung, berjinjit
	var ant := _pz({"upperarm_r": Vector3(-3.1, 0.1, -0.2), "upperarm_l": Vector3(-2.9, -0.1, 0.25),
		"forearm_r": Vector3(-0.8, 0, 0), "forearm_l": Vector3(-0.8, 0, 0),
		"spine": Vector3(-0.42, 0, 0), "chest": Vector3(-0.15, 0, 0), "head": Vector3(0.35, 0, 0),
		"thigh_l": Vector3(0.1, 0, 0.18), "thigh_r": Vector3(-0.1, 0, -0.18), "bob": 0.05, "hz": -0.1})
	# 3) membanting: badan menukik, satu kaki maju menahan beban
	var hit := _pz({"upperarm_r": Vector3(-0.4, 0.1, -0.2), "upperarm_l": Vector3(-0.38, -0.1, 0.25),
		"forearm_r": Vector3(-0.1, 0, 0), "forearm_l": Vector3(-0.1, 0, 0),
		"spine": Vector3(1.05, 0, 0), "chest": Vector3(0.12, 0, 0), "head": Vector3(-0.65, 0, 0),
		"thigh_l": Vector3(-0.55, 0, 0.16), "thigh_r": Vector3(0.2, 0, -0.16), "shin_l": Vector3(0.45, 0, 0), "shin_r": Vector3(0.7, 0, 0),
		"bob": -0.22, "hz": 0.16})
	# 4) tahan menekan tanah (bergetar sedikit), lalu tarik palu dan bangkit
	var press := _mix(hit, _pz({"spine": Vector3(1.0, 0, 0.04), "head": Vector3(-0.6, 0, 0), "bob": -0.24, "hz": 0.16,
		"upperarm_r": Vector3(-0.45, 0.1, -0.2), "upperarm_l": Vector3(-0.42, -0.1, 0.25), "thigh_l": Vector3(-0.55, 0, 0.16), "thigh_r": Vector3(0.2, 0, -0.16),
		"shin_l": Vector3(0.45, 0, 0), "shin_r": Vector3(0.7, 0, 0)}), 0.6)
	var lift := _mix(hit, ready, 0.55)
	return _seq(u, [[0.0, ready, ""], [0.16, load_, "io"], [0.42, ant, "io"], [0.52, hit, "back"], [0.7, press, "out"],
		[0.86, lift, "io"], [1.0, ready, "io"]])


## Penutup kombo pedang (Vael): menarik badan ke belakang, naik berjinjit dengan pedang di atas kepala, lalu membelah ke bawah
## dengan lunge dalam (berat badan pindah ke kaki depan, pinggang & bahu ikut menukik), tahan sebentar, bangkit.
static func _p_sword_finisher(u: float) -> Dictionary:
	var ready := _pz({})
	var coil := _pz({"upperarm_r": Vector3(-1.6, 0.1, -0.5), "forearm_r": Vector3(-1.2, 0, 0), "hand_r": Vector3(-0.3, 0, 0),
		"spine": Vector3(-0.35, -0.55, 0), "chest": Vector3(-0.2, -0.25, 0), "head": Vector3(0.2, 0.3, 0),
		"upperarm_l": Vector3(0.3, 0, 1.0), "forearm_l": Vector3(-0.5, 0, 0),
		"thigh_l": Vector3(0.35, 0, 0.12), "thigh_r": Vector3(-0.25, 0, -0.12), "shin_r": Vector3(0.55, 0, 0), "shin_l": Vector3(0.15, 0, 0),
		"bob": -0.1, "hz": -0.08})
	var rise := _pz({"upperarm_r": Vector3(-2.5, 0.1, -0.3), "forearm_r": Vector3(-0.7, 0, 0), "hand_r": Vector3(-0.2, 0, 0),
		"spine": Vector3(-0.45, -0.2, 0), "chest": Vector3(-0.2, -0.1, 0), "head": Vector3(0.3, 0.1, 0),
		"upperarm_l": Vector3(0.5, 0, 1.1), "forearm_l": Vector3(-0.3, 0, 0),
		"thigh_l": Vector3(0.0, 0, 0.1), "thigh_r": Vector3(-0.05, 0, -0.1), "bob": 0.04, "hz": -0.06})
	var hit := _pz({"upperarm_r": Vector3(-0.55, -0.3, 0.12), "forearm_r": Vector3(-0.35, 0, 0), "hand_r": Vector3(0.35, 0, 0),
		"spine": Vector3(0.7, 0.3, 0), "chest": Vector3(0.18, 0.12, 0), "head": Vector3(-0.5, -0.12, 0),
		"upperarm_l": Vector3(0.6, 0, 0.7), "forearm_l": Vector3(-0.6, 0, 0),
		"thigh_l": Vector3(-0.75, 0, 0.12), "thigh_r": Vector3(0.4, 0, -0.1), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.3, 0, 0),
		"bob": -0.22, "hz": 0.22})
	var hold := _mix(hit, ready, 0.3)
	hold["upperarm_r"] = Vector3(-0.35, -0.5, 0.3)
	hold["forearm_r"] = Vector3(-0.5, 0, 0)
	hold["hand_r"] = Vector3(0.25, 0, 0)
	return _seq(u, [[0.0, ready, ""], [0.2, coil, "io"], [0.42, rise, "io"], [0.45, rise, ""], [0.52, hit, "back"], [0.74, hold, "out"], [1.0, ready, "io"]])


## Serangan tongkat ke-2: sapuan menyamping (berlawanan arah dengan serangan ke-1), badan memutar dan berat pindah ke kaki kanan.
static func _p_staff2(u: float) -> Dictionary:
	var ready := _pz({})
	var ant := _pz({"upperarm_r": Vector3(-0.9, -0.6, -0.1), "forearm_r": Vector3(-1.1, 0, 0), "hand_r": Vector3(-0.2, 0, 0),
		"upperarm_l": Vector3(-0.8, -0.3, 0.4), "forearm_l": Vector3(-0.7, 0, 0),
		"spine": Vector3(0.05, 0.55, 0), "chest": Vector3(0, 0.2, 0), "head": Vector3(0.0, -0.3, 0),
		"thigh_l": Vector3(-0.1, 0, 0.08), "thigh_r": Vector3(0.15, 0, -0.08), "shin_l": Vector3(0.2, 0, 0), "bob": -0.05, "hz": -0.04})
	var hit := _pz({"upperarm_r": Vector3(-1.2, 0.65, -0.15), "forearm_r": Vector3(-0.4, 0, 0), "hand_r": Vector3(0.1, 0, 0),
		"upperarm_l": Vector3(-1.1, 0.45, 0.3), "forearm_l": Vector3(-0.3, 0, 0),
		"spine": Vector3(0.2, -0.5, 0), "chest": Vector3(0.05, -0.2, 0), "head": Vector3(-0.1, 0.3, 0),
		"thigh_r": Vector3(-0.35, 0, -0.06), "thigh_l": Vector3(0.25, 0, 0.06), "shin_l": Vector3(0.25, 0, 0), "bob": -0.08, "hz": 0.08})
	return _seq(u, [[0.0, ready, ""], [0.28, ant, "io"], [0.44, hit, "back"], [0.66, _mix(hit, ready, 0.3), "out"], [1.0, ready, "io"]])


## Hantaman palu ke-2 (Guardian): sapuan mendatar backhand dengan dua tangan; badan memutar penuh, kuda-kuda lebar menahan momentum.
static func _p_smash2(u: float) -> Dictionary:
	var ready := _pz({})
	var load_ := _pz({"upperarm_r": Vector3(-0.9, 0.95, -0.4), "upperarm_l": Vector3(-0.8, 0.7, 0.2),
		"forearm_r": Vector3(-0.7, 0, 0), "forearm_l": Vector3(-0.7, 0, 0),
		"spine": Vector3(0.05, 0.75, 0), "chest": Vector3(0, 0.35, 0), "head": Vector3(0.1, -0.4, 0),
		"thigh_l": Vector3(0.3, 0, 0.2), "thigh_r": Vector3(-0.2, 0, -0.2), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.4, 0, 0),
		"bob": -0.16, "hz": -0.05})
	var hit := _pz({"upperarm_r": Vector3(-1.25, -0.8, -0.1), "upperarm_l": Vector3(-1.15, -0.9, 0.1),
		"forearm_r": Vector3(-0.3, 0, 0), "forearm_l": Vector3(-0.3, 0, 0),
		"spine": Vector3(0.15, -1.0, 0), "chest": Vector3(0, -0.4, 0), "head": Vector3(-0.1, 0.6, 0),
		"thigh_l": Vector3(-0.5, 0, 0.2), "thigh_r": Vector3(0.35, 0, -0.2), "shin_l": Vector3(0.4, 0, 0), "shin_r": Vector3(0.6, 0, 0),
		"bob": -0.2, "hz": 0.14})
	return _seq(u, [[0.0, ready, ""], [0.18, load_, "io"], [0.34, load_, ""], [0.5, hit, "back"], [0.72, _mix(hit, ready, 0.5), "out"], [1.0, ready, "io"]])


## Penutup kombo tongkat: memutar badan ke belakang sambil menarik tongkat, mengangkatnya tinggi dengan dua tangan (berjinjit),
## lalu menghunjam ke depan dengan badan menukik dan berat pindah ke kaki depan. Lebih besar & lebih berat dari serangan 1-2.
static func _p_staff3(u: float) -> Dictionary:
	var ready := _pz({})
	var coil := _pz({"upperarm_r": Vector3(-1.2, 0.3, -0.6), "forearm_r": Vector3(-1.4, 0, 0), "hand_r": Vector3(-0.3, 0, 0),
		"upperarm_l": Vector3(-1.0, 0.0, 0.5), "forearm_l": Vector3(-0.8, 0, 0),
		"spine": Vector3(-0.2, -0.8, 0), "chest": Vector3(-0.1, -0.35, 0), "head": Vector3(0.1, 0.5, 0),
		"thigh_l": Vector3(0.3, 0, 0.1), "thigh_r": Vector3(-0.2, 0, -0.1), "shin_r": Vector3(0.4, 0, 0), "bob": -0.1, "hz": -0.08})
	var rise := _pz({"upperarm_r": Vector3(-2.6, 0.0, -0.3), "forearm_r": Vector3(-0.5, 0, 0),
		"upperarm_l": Vector3(-2.5, 0.0, 0.35), "forearm_l": Vector3(-0.4, 0, 0),
		"spine": Vector3(-0.4, -0.2, 0), "chest": Vector3(-0.15, -0.1, 0), "head": Vector3(-0.3, 0.1, 0),
		"thigh_l": Vector3(0.05, 0, 0.1), "thigh_r": Vector3(-0.05, 0, -0.1), "bob": 0.08, "hz": -0.06})
	var hit := _pz({"upperarm_r": Vector3(-1.4, -0.1, -0.15), "forearm_r": Vector3(-0.25, 0, 0), "hand_r": Vector3(0.15, 0, 0),
		"upperarm_l": Vector3(-1.3, 0.0, 0.3), "forearm_l": Vector3(-0.3, 0, 0),
		"spine": Vector3(0.6, 0.35, 0), "chest": Vector3(0.12, 0.15, 0), "head": Vector3(-0.35, -0.15, 0),
		"thigh_l": Vector3(-0.6, 0, 0.1), "thigh_r": Vector3(0.35, 0, -0.08), "shin_l": Vector3(0.45, 0, 0), "shin_r": Vector3(0.3, 0, 0), "bob": -0.18, "hz": 0.2})
	return _seq(u, [[0.0, ready, ""], [0.22, coil, "io"], [0.42, rise, "io"], [0.46, rise, ""], [0.54, hit, "back"], [0.76, _mix(hit, ready, 0.35), "out"], [1.0, ready, "io"]])


## Penutup kombo Guardian: berjongkok dalam, palu diangkat setinggi-tingginya dengan punggung melengkung, ditahan sesaat,
## lalu dibanting dengan seluruh badan; tahan menekan tanah lebih lama dari hantaman biasa.
static func _p_smash3(u: float) -> Dictionary:
	var ready := _pz({})
	var squat := _pz({"upperarm_r": Vector3(-1.0, 0.6, -0.6), "upperarm_l": Vector3(-0.9, 0.5, 0.1),
		"forearm_r": Vector3(-0.9, 0, 0), "forearm_l": Vector3(-0.9, 0, 0),
		"spine": Vector3(0.0, -0.5, 0), "chest": Vector3(0, -0.25, 0), "head": Vector3(0.2, 0.2, 0),
		"thigh_l": Vector3(0.45, 0, 0.22), "thigh_r": Vector3(-0.2, 0, -0.22), "shin_l": Vector3(0.7, 0, 0), "shin_r": Vector3(0.55, 0, 0), "bob": -0.22, "hz": -0.05})
	var top := _pz({"upperarm_r": Vector3(-3.25, 0.1, -0.2), "upperarm_l": Vector3(-3.05, -0.1, 0.25),
		"forearm_r": Vector3(-0.7, 0, 0), "forearm_l": Vector3(-0.7, 0, 0),
		"spine": Vector3(-0.55, 0, 0), "chest": Vector3(-0.2, 0, 0), "head": Vector3(0.4, 0, 0),
		"thigh_l": Vector3(0.05, 0, 0.2), "thigh_r": Vector3(-0.05, 0, -0.2), "bob": 0.08, "hz": -0.12})
	var hit := _pz({"upperarm_r": Vector3(-0.4, 0.1, -0.2), "upperarm_l": Vector3(-0.38, -0.1, 0.25),
		"forearm_r": Vector3(-0.1, 0, 0), "forearm_l": Vector3(-0.1, 0, 0),
		"spine": Vector3(0.8, 0, 0), "chest": Vector3(0.14, 0, 0), "head": Vector3(-0.5, 0, 0),
		"thigh_l": Vector3(-0.65, 0, 0.18), "thigh_r": Vector3(0.25, 0, -0.18), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.8, 0, 0), "bob": -0.3, "hz": 0.22})
	var press := _mix(hit, _pz({"spine": Vector3(0.76, 0, 0.05), "head": Vector3(-0.48, 0, 0), "bob": -0.32, "hz": 0.22,
		"upperarm_r": Vector3(-0.45, 0.1, -0.2), "upperarm_l": Vector3(-0.42, -0.1, 0.25), "thigh_l": Vector3(-0.65, 0, 0.18), "thigh_r": Vector3(0.25, 0, -0.18),
		"shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.8, 0, 0)}), 0.6)
	return _seq(u, [[0.0, ready, ""], [0.18, squat, "io"], [0.46, top, "io"], [0.52, top, ""], [0.6, hit, "back"], [0.8, press, "out"],
		[0.92, _mix(hit, ready, 0.55), "io"], [1.0, ready, "io"]])


## Penutup kombo busur: tembakan kuat. Kuda-kuda lebih rendah, tali ditarik penuh dengan badan menahan, tahan sejenak membidik,
## lalu melepas dengan hentakan: badan terdorong mundur (hentakan balik) dan satu kaki bergeser menahan.
static func _p_bow3(u: float) -> Dictionary:
	var ready := _pz({}, false)
	var draw := _pz({"upperarm_l": Vector3(-1.5, -0.15, 0.12), "forearm_l": Vector3(-0.1, 0, 0),
		"upperarm_r": Vector3(-1.55, 0.6, -0.8), "forearm_r": Vector3(-2.1, 0, 0),
		"spine": Vector3(-0.1, 0.5, 0), "chest": Vector3(0, 0.18, 0), "head": Vector3(-0.05, -0.6, 0),
		"thigh_l": Vector3(0.2, 0, 0.14), "thigh_r": Vector3(-0.2, 0, -0.14), "shin_l": Vector3(0.25, 0, 0), "shin_r": Vector3(0.25, 0, 0), "bob": -0.12, "hz": -0.06}, false)
	var rel := _pz({"upperarm_l": Vector3(-1.55, -0.15, 0.12), "forearm_l": Vector3(-0.1, 0, 0),
		"upperarm_r": Vector3(-1.4, 0.3, -1.15), "forearm_r": Vector3(-0.35, 0, 0),
		"spine": Vector3(-0.18, 0.36, 0), "chest": Vector3(-0.05, 0.1, 0), "head": Vector3(-0.08, -0.5, 0),
		"thigh_l": Vector3(0.1, 0, 0.14), "thigh_r": Vector3(-0.3, 0, -0.14), "shin_r": Vector3(0.35, 0, 0), "bob": -0.06, "hz": -0.2}, false)
	return _seq(u, [[0.0, ready, ""], [0.36, draw, "io"], [0.64, draw, "io"], [0.72, rel, "back"], [0.88, _mix(rel, ready, 0.5), "out"], [1.0, ready, "io"]])


## Belati ganda (Assassin): cepat dan lincah. Kuda-kuda rendah; 0 = tebas kanan, 1 = tebas kiri, 2 = penutup (putaran silang + lompat kecil).
static func _dagger_ready() -> Dictionary:
	return _pz({"upperarm_r": Vector3(-0.55, 0.1, -0.15), "forearm_r": Vector3(-1.1, 0, 0), "hand_r": Vector3(-0.1, 0, 0),
		"upperarm_l": Vector3(-0.55, -0.1, 0.15), "forearm_l": Vector3(-1.1, 0, 0),
		"spine": Vector3(0.18, 0, 0), "chest": Vector3(0.04, 0, 0), "head": Vector3(-0.1, 0, 0),
		"thigh_l": Vector3(0.28, 0, 0.12), "thigh_r": Vector3(-0.22, 0, -0.12), "shin_l": Vector3(0.35, 0, 0), "shin_r": Vector3(0.4, 0, 0),
		"bob": -0.09, "hz": 0.0})


static func _p_dagger(u: float, idx: int) -> Dictionary:
	var ready := _dagger_ready()
	if idx == 0:
		var ant := _pz({"upperarm_r": Vector3(-1.3, 0.0, -1.15), "forearm_r": Vector3(-0.6, 0, 0),
			"upperarm_l": Vector3(-0.7, 0, 0.45), "forearm_l": Vector3(-1.0, 0, 0),
			"spine": Vector3(0.22, -0.75, 0), "chest": Vector3(0.04, -0.3, 0), "head": Vector3(-0.08, 0.5, 0),
			"thigh_l": Vector3(0.3, 0, 0.14), "thigh_r": Vector3(-0.25, 0, -0.12), "shin_l": Vector3(0.4, 0, 0), "shin_r": Vector3(0.45, 0, 0),
			"hand_r": Vector3(-0.55, 0, 0), "hand_l": Vector3(-0.25, 0, 0),
			"bob": -0.11, "hz": -0.05})
		var hit := _pz({"upperarm_r": Vector3(-1.0, 0.55, 0.2), "forearm_r": Vector3(-0.15, 0, 0),
			"upperarm_l": Vector3(-0.3, 0, 0.85), "forearm_l": Vector3(-0.9, 0, 0),
			"spine": Vector3(0.35, 0.8, 0), "chest": Vector3(0.04, 0.32, 0), "head": Vector3(-0.08, -0.5, 0),
			"thigh_l": Vector3(0.3, 0, 0.14), "thigh_r": Vector3(-0.55, 0, -0.1), "shin_l": Vector3(0.3, 0, 0), "shin_r": Vector3(0.35, 0, 0),
			"hand_r": Vector3(0.7, 0, 0), "hand_l": Vector3(0.3, 0, 0),             # sentakan pergelangan saat kena
			"bob": -0.12, "hz": 0.16})
		var flow := _mix(hit, ready, 0.18)                                     # ikut-lanjut: badan meluncur lewat titik kena sebelum pulih
		flow["head"] = (flow["head"] as Vector3) + Vector3(0.04, 0.18, 0)
		return _seq(u, [[0.0, ready, ""], [0.2, ant, "io"], [0.38, hit, "back"], [0.48, flow, "out"], [0.68, _mix(hit, ready, 0.55), "io"], [1.0, ready, "io"]])
	if idx == 1:
		var ant2 := _pz({"upperarm_l": Vector3(-1.3, 0.0, 1.15), "forearm_l": Vector3(-0.6, 0, 0),
			"upperarm_r": Vector3(-0.7, 0, -0.45), "forearm_r": Vector3(-1.0, 0, 0),
			"spine": Vector3(0.22, 0.75, 0), "chest": Vector3(0.04, 0.3, 0), "head": Vector3(-0.08, -0.5, 0),
			"thigh_r": Vector3(0.3, 0, -0.14), "thigh_l": Vector3(-0.25, 0, 0.12), "shin_r": Vector3(0.4, 0, 0), "shin_l": Vector3(0.45, 0, 0),
			"hand_l": Vector3(-0.55, 0, 0), "hand_r": Vector3(-0.25, 0, 0),
			"bob": -0.11, "hz": -0.05})
		var hit2 := _pz({"upperarm_l": Vector3(-1.0, -0.55, -0.2), "forearm_l": Vector3(-0.15, 0, 0),
			"upperarm_r": Vector3(-0.3, 0, -0.85), "forearm_r": Vector3(-0.9, 0, 0),
			"spine": Vector3(0.35, -0.8, 0), "chest": Vector3(0.04, -0.32, 0), "head": Vector3(-0.08, 0.5, 0),
			"thigh_r": Vector3(0.3, 0, -0.14), "thigh_l": Vector3(-0.55, 0, 0.1), "shin_r": Vector3(0.3, 0, 0), "shin_l": Vector3(0.35, 0, 0),
			"hand_l": Vector3(0.7, 0, 0), "hand_r": Vector3(0.3, 0, 0),
			"bob": -0.12, "hz": 0.16})
		var flow2 := _mix(hit2, ready, 0.18)
		flow2["head"] = (flow2["head"] as Vector3) + Vector3(0.04, -0.18, 0)
		return _seq(u, [[0.0, ready, ""], [0.2, ant2, "io"], [0.38, hit2, "back"], [0.48, flow2, "out"], [0.68, _mix(hit2, ready, 0.55), "io"], [1.0, ready, "io"]])
	# penutup: menggulung, lalu putaran silang dua belati sambil melompat kecil
	var coil := _pz({"upperarm_r": Vector3(-1.2, 0, -1.7), "forearm_r": Vector3(-0.5, 0, 0),
		"upperarm_l": Vector3(-1.2, 0, 1.7), "forearm_l": Vector3(-0.5, 0, 0),
		"spine": Vector3(0.35, -1.25, 0), "chest": Vector3(0.05, -0.5, 0), "head": Vector3(-0.1, 0.9, 0),
		"thigh_l": Vector3(0.4, 0, 0.2), "thigh_r": Vector3(-0.3, 0, -0.2), "shin_l": Vector3(0.7, 0, 0), "shin_r": Vector3(0.7, 0, 0),
		"bob": -0.2, "hz": -0.06})
	var spin := _pz({"upperarm_r": Vector3(-1.5, 0.5, 0.3), "forearm_r": Vector3(-0.2, 0, 0),
		"upperarm_l": Vector3(-1.5, -0.5, -0.3), "forearm_l": Vector3(-0.2, 0, 0),
		"spine": Vector3(0.1, 1.3, 0), "chest": Vector3(0, 0.55, 0), "head": Vector3(-0.1, -0.9, 0),
		"thigh_l": Vector3(-0.35, 0, 0.18), "thigh_r": Vector3(0.45, 0, -0.18), "shin_l": Vector3(0.55, 0, 0), "shin_r": Vector3(0.8, 0, 0),
		"bob": 0.12, "hz": 0.2})
	var land := _pz({"upperarm_r": Vector3(-0.9, 0.4, 0.2), "forearm_r": Vector3(-0.4, 0, 0),
		"upperarm_l": Vector3(-0.9, -0.4, -0.2), "forearm_l": Vector3(-0.4, 0, 0),
		"spine": Vector3(0.3, 0.9, 0), "chest": Vector3(0, 0.4, 0), "head": Vector3(-0.1, -0.6, 0),
		"thigh_l": Vector3(-0.5, 0, 0.16), "thigh_r": Vector3(0.3, 0, -0.16), "shin_l": Vector3(0.9, 0, 0), "shin_r": Vector3(0.9, 0, 0),
		"bob": -0.22, "hz": 0.12})
	return _seq(u, [[0.0, ready, ""], [0.26, coil, "io"], [0.4, spin, "back"], [0.6, land, "out"], [0.78, _mix(land, ready, 0.5), "io"], [1.0, ready, "io"]])


## Skill Assassin: merunduk, menerjang (badan sejajar tanah), menyilang dua belati, lalu berhenti dengan kuda-kuda.
static func _p_skill_dagger(u: float) -> Dictionary:
	var ready := _dagger_ready()
	var crouch := _pz({"upperarm_r": Vector3(0.4, 0, -0.5), "forearm_r": Vector3(-0.6, 0, 0),
		"upperarm_l": Vector3(0.4, 0, 0.5), "forearm_l": Vector3(-0.6, 0, 0),
		"spine": Vector3(0.6, -0.2, 0), "chest": Vector3(0.1, 0, 0), "head": Vector3(-0.5, 0, 0),
		"thigh_l": Vector3(-0.9, 0, 0.14), "thigh_r": Vector3(-0.9, 0, -0.14), "shin_l": Vector3(1.3, 0, 0), "shin_r": Vector3(1.3, 0, 0),
		"bob": -0.3, "hz": -0.1})
	var dash := _pz({"upperarm_r": Vector3(1.1, 0, -0.35), "forearm_r": Vector3(-0.2, 0, 0),
		"upperarm_l": Vector3(1.1, 0, 0.35), "forearm_l": Vector3(-0.2, 0, 0),
		"spine": Vector3(1.0, 0, 0), "chest": Vector3(0.15, 0, 0), "head": Vector3(-0.8, 0, 0),
		"thigh_l": Vector3(0.8, 0, 0.1), "thigh_r": Vector3(-0.9, 0, -0.1), "shin_l": Vector3(0.7, 0, 0), "shin_r": Vector3(0.9, 0, 0),
		"bob": -0.12, "hz": 0.28})
	var cross := _pz({"upperarm_r": Vector3(-1.45, 0.65, 0.5), "forearm_r": Vector3(-0.25, 0, 0),
		"upperarm_l": Vector3(-1.45, -0.65, -0.5), "forearm_l": Vector3(-0.25, 0, 0),
		"spine": Vector3(0.1, 0.0, 0), "chest": Vector3(-0.1, 0, 0), "head": Vector3(0.05, 0, 0),
		"thigh_l": Vector3(-0.6, 0, 0.16), "thigh_r": Vector3(0.45, 0, -0.16), "shin_l": Vector3(0.4, 0, 0), "shin_r": Vector3(0.6, 0, 0),
		"bob": -0.14, "hz": 0.2})
	return _seq(u, [[0.0, ready, ""], [0.22, crouch, "io"], [0.38, dash, "back"], [0.5, cross, "back"], [0.72, _mix(cross, ready, 0.4), "out"], [1.0, ready, "io"]])


## Panah: tarik tali (antisipasi + bidik), lepas (tangan kanan menyentak), turunkan busur.
static func _p_bow(u: float, skill: bool, quick: bool = false) -> Dictionary:
	var ready := _pz({}, false)
	var draw := _pz({"upperarm_l": Vector3(-1.45, -0.15, 0.12), "forearm_l": Vector3(-0.1, 0, 0),
		"upperarm_r": Vector3(-1.5, 0.55, -0.7), "forearm_r": Vector3(-2.0, 0, 0),
		"spine": Vector3(0, 0.45, 0), "chest": Vector3(0, 0.15, 0), "head": Vector3(-0.05, -0.55, 0),
		"thigh_l": Vector3(0.15, 0, 0.1), "thigh_r": Vector3(-0.15, 0, -0.1), "bob": -0.05, "hz": -0.03}, false)
	var rel := _pz({"upperarm_l": Vector3(-1.5, -0.15, 0.12), "forearm_l": Vector3(-0.1, 0, 0),
		"upperarm_r": Vector3(-1.45, 0.35, -1.05), "forearm_r": Vector3(-0.4, 0, 0),
		"spine": Vector3(0, 0.38, 0), "chest": Vector3(0, 0.12, 0), "head": Vector3(-0.05, -0.5, 0),
		"thigh_l": Vector3(0.1, 0, 0.1), "thigh_r": Vector3(-0.1, 0, -0.1), "bob": -0.03, "hz": -0.08}, false)
	if skill:
		draw["spine"] = Vector3(-0.3, 0.45, 0)
		draw["upperarm_l"] = Vector3(-1.85, -0.15, 0.12)
		draw["bob"] = -0.1
		rel["spine"] = Vector3(-0.2, 0.38, 0)
		rel["upperarm_l"] = Vector3(-1.9, -0.15, 0.12)
		rel["bob"] = 0.06
	var follow := _mix(rel, ready, 0.45)
	if quick:                                   # tembakan cepat (hit ke-2): tarikan lebih pendek, badan sedikit mundur saat melepas
		draw["hz"] = -0.1
		rel["hz"] = -0.14
		return _seq(u, [[0.0, ready, ""], [0.26, draw, "io"], [0.31, draw, "io"], [0.4, rel, "back"], [0.62, follow, "out"], [1.0, ready, "io"]])
	return _seq(u, [[0.0, ready, ""], [0.4, draw, "io"], [0.48 if not skill else 0.46, draw, "io"], [0.58, rel, "back"], [0.78, follow, "out"], [1.0, ready, "io"]])


## Skill pedang: menggulung badan (antisipasi dalam), putaran sapuan lebar, melewati sedikit, lalu menahan dengan kuda-kuda.
static func _p_skill_sword(u: float) -> Dictionary:
	var ready := _pz({})
	var coil := _pz({"upperarm_r": Vector3(-1.25, 0.0, -1.65), "forearm_r": Vector3(-0.5, 0, 0), "hand_r": Vector3(-0.2, 0, 0),
		"spine": Vector3(0.2, -1.35, 0), "chest": Vector3(0, -0.55, 0), "head": Vector3(-0.1, 0.95, 0),
		"upperarm_l": Vector3(-0.3, 0, 0.9), "forearm_l": Vector3(-0.4, 0, 0),
		"thigh_l": Vector3(-0.35, 0, 0.2), "thigh_r": Vector3(0.35, 0, -0.2), "shin_l": Vector3(0.45, 0, 0), "shin_r": Vector3(0.5, 0, 0),
		"bob": -0.17, "hz": -0.05})
	var sweep := _pz({"upperarm_r": Vector3(-1.5, 0.6, 0.25), "forearm_r": Vector3(-0.15, 0, 0), "hand_r": Vector3(0.1, 0, 0),
		"spine": Vector3(0.12, 1.3, 0), "chest": Vector3(0, 0.55, 0), "head": Vector3(-0.1, -0.95, 0),
		"upperarm_l": Vector3(-0.4, 0, 0.95), "forearm_l": Vector3(-0.4, 0, 0),
		"thigh_l": Vector3(-0.45, 0, 0.18), "thigh_r": Vector3(0.4, 0, -0.18), "shin_l": Vector3(0.3, 0, 0), "shin_r": Vector3(0.5, 0, 0),
		"bob": -0.12, "hz": 0.1})
	var settle := _pz({"upperarm_r": Vector3(-1.0, 0.45, 0.1), "forearm_r": Vector3(-0.3, 0, 0),
		"spine": Vector3(0.18, 1.0, 0), "chest": Vector3(0, 0.4, 0), "head": Vector3(-0.1, -0.7, 0),
		"upperarm_l": Vector3(-0.3, 0, 0.8), "forearm_l": Vector3(-0.4, 0, 0),
		"thigh_l": Vector3(-0.4, 0, 0.16), "thigh_r": Vector3(0.35, 0, -0.16), "shin_l": Vector3(0.3, 0, 0), "shin_r": Vector3(0.45, 0, 0),
		"bob": -0.1, "hz": 0.08})
	return _seq(u, [[0.0, ready, ""], [0.34, coil, "io"], [0.42, coil, "io"], [0.62, sweep, "back"], [0.78, settle, "out"], [1.0, ready, "io"]])


## Skill Vortex (Kyomu): merunduk menggulung badan dengan dua bilah menyilang, lalu memuntir badan dengan kedua lengan terentang lebar
## (pusaran bilah), memuntir balik, lalu tegak. Waktu impak 0,42 x 0,95 dtk.
static func _p_skill_vortex(u: float) -> Dictionary:
	var ready := _dagger_ready()
	var coil := _pz({"upperarm_r": Vector3(-1.2, 0.5, 0.6), "forearm_r": Vector3(-0.4, 0, 0), "upperarm_l": Vector3(-1.2, -0.5, -0.6), "forearm_l": Vector3(-0.4, 0, 0),
		"spine": Vector3(0.3, -1.1, 0), "chest": Vector3(0, -0.5, 0), "head": Vector3(0.0, 0.8, 0),
		"thigh_l": Vector3(-0.5, 0, 0.2), "thigh_r": Vector3(-0.5, 0, -0.2), "shin_l": Vector3(0.9, 0, 0), "shin_r": Vector3(0.9, 0, 0), "bob": -0.22, "hz": 0.0})
	var spin1 := _pz({"upperarm_r": Vector3(-0.1, 0.0, -1.5), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(-0.1, 0.0, 1.5), "forearm_l": Vector3(-0.1, 0, 0),
		"spine": Vector3(0.12, 1.5, 0), "chest": Vector3(0, 0.6, 0), "head": Vector3(0.0, -1.0, 0),
		"thigh_l": Vector3(-0.3, 0, 0.3), "thigh_r": Vector3(-0.3, 0, -0.3), "shin_l": Vector3(0.6, 0, 0), "shin_r": Vector3(0.6, 0, 0), "bob": -0.1, "hz": 0.0})
	var spin2 := _pz({"upperarm_r": Vector3(-0.1, 0.0, -1.5), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(-0.1, 0.0, 1.5), "forearm_l": Vector3(-0.1, 0, 0),
		"spine": Vector3(0.12, -1.3, 0), "chest": Vector3(0, -0.5, 0), "head": Vector3(0.0, 0.9, 0),
		"thigh_l": Vector3(-0.3, 0, 0.3), "thigh_r": Vector3(-0.3, 0, -0.3), "shin_l": Vector3(0.6, 0, 0), "shin_r": Vector3(0.6, 0, 0), "bob": -0.1, "hz": 0.0})
	return _seq(u, [[0.0, ready, ""], [0.28, coil, "io"], [0.42, spin1, "back"], [0.62, spin2, "io"], [0.8, _mix(spin1, ready, 0.5), "out"], [1.0, ready, "io"]])


## Skill penyihir: mengangkat tongkat ke langit sambil mengumpulkan tenaga (tubuh naik), tahan sesaat, lalu hunjam.
static func _p_skill_staff(u: float) -> Dictionary:
	var ready := _pz({})
	var gather := _pz({"upperarm_r": Vector3(-3.0, 0, -0.25), "forearm_r": Vector3(-0.35, 0, 0),
		"upperarm_l": Vector3(-2.85, 0, 0.35), "forearm_l": Vector3(-0.3, 0, 0),
		"spine": Vector3(-0.24, 0, 0), "chest": Vector3(-0.1, 0, 0), "head": Vector3(-0.38, 0, 0),
		"thigh_l": Vector3(0.05, 0, 0.1), "thigh_r": Vector3(-0.05, 0, -0.1), "bob": 0.1, "hz": -0.03})
	var peak := _mix(gather, _pz({"bob": 0.13, "spine": Vector3(-0.3, 0, 0), "head": Vector3(-0.45, 0, 0),
		"upperarm_r": Vector3(-3.05, 0, -0.3), "upperarm_l": Vector3(-2.9, 0, 0.4), "forearm_r": Vector3(-0.35, 0, 0), "forearm_l": Vector3(-0.3, 0, 0)}), 1.0)
	var slam := _pz({"upperarm_r": Vector3(-1.2, 0, -0.25), "forearm_r": Vector3(-0.65, 0, 0),
		"upperarm_l": Vector3(-1.15, 0, 0.35), "forearm_l": Vector3(-0.3, 0, 0),
		"spine": Vector3(0.55, 0, 0), "chest": Vector3(0.1, 0, 0), "head": Vector3(0.3, 0, 0),
		"thigh_l": Vector3(-0.3, 0, 0.12), "thigh_r": Vector3(0.2, 0, -0.12), "shin_r": Vector3(0.3, 0, 0), "bob": -0.08, "hz": 0.07})
	var follow := _mix(slam, ready, 0.3)
	return _seq(u, [[0.0, ready, ""], [0.36, gather, "io"], [0.5, peak, "io"], [0.64, slam, "back"], [0.82, follow, "out"], [1.0, ready, "io"]])


## Skill Guardian: berjongkok menyimpan tenaga, melompat dengan tangan di atas, jatuh membanting tanah, tahan, bangkit.
static func _p_skill_guard(u: float) -> Dictionary:
	var ready := _pz({})
	var crouch := _pz({"upperarm_r": Vector3(-1.2, 0, -0.3), "upperarm_l": Vector3(-1.2, 0, 0.3),
		"forearm_r": Vector3(-0.8, 0, 0), "forearm_l": Vector3(-0.8, 0, 0),
		"spine": Vector3(0.35, 0, 0), "head": Vector3(-0.15, 0, 0),
		"thigh_l": Vector3(-0.75, 0, 0.12), "thigh_r": Vector3(-0.75, 0, -0.12), "shin_l": Vector3(1.05, 0, 0), "shin_r": Vector3(1.05, 0, 0),
		"bob": -0.3, "hz": -0.04})
	var air := _pz({"upperarm_r": Vector3(-3.0, 0, -0.2), "upperarm_l": Vector3(-3.0, 0, 0.2),
		"forearm_r": Vector3(-0.5, 0, 0), "forearm_l": Vector3(-0.5, 0, 0),
		"spine": Vector3(-0.22, 0, 0), "head": Vector3(0.1, 0, 0),
		"thigh_l": Vector3(-0.15, 0, 0.1), "thigh_r": Vector3(0.2, 0, -0.1), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.6, 0, 0),
		"bob": 0.4, "hz": 0.05})
	var slam := _pz({"upperarm_r": Vector3(-0.25, 0, -0.2), "upperarm_l": Vector3(-0.25, 0, 0.2),
		"forearm_r": Vector3(-0.1, 0, 0), "forearm_l": Vector3(-0.1, 0, 0),
		"spine": Vector3(0.9, 0, 0), "head": Vector3(-0.4, 0, 0),
		"thigh_l": Vector3(-0.85, 0, 0.12), "thigh_r": Vector3(-0.85, 0, -0.12), "shin_l": Vector3(1.2, 0, 0), "shin_r": Vector3(1.2, 0, 0),
		"bob": -0.3, "hz": 0.1})
	var rise := _mix(slam, ready, 0.5)
	return _seq(u, [[0.0, ready, ""], [0.24, crouch, "io"], [0.36, crouch, "io"], [0.5, air, "out"], [0.64, slam, "back"], [0.82, slam, "out"], [0.92, rise, "io"], [1.0, ready, "io"]])


## Skill iai (Hakuya): kuda-kuda rendah, tangan kiri di sarung & tangan kanan di gagang, hening menahan napas, lalu cabut-tebas kilat
## (badan memuntir, kaki depan menerjang, tangan kiri menarik sarung ke belakang), tahan follow-through, lalu mengibas & menyarungkan kembali.
static func _p_skill_iai(u: float) -> Dictionary:
	var ready := _pz({})
	var stance := _pz({"upperarm_r": Vector3(-0.65, 0.2, -0.2), "forearm_r": Vector3(-1.1, 0, 0), "hand_r": Vector3(-0.2, 0, 0),
		"upperarm_l": Vector3(-0.45, 0.0, 0.3), "forearm_l": Vector3(-1.15, 0, 0),
		"spine": Vector3(0.22, -0.3, 0), "chest": Vector3(0.05, -0.12, 0), "head": Vector3(0.05, 0.15, 0),
		"thigh_l": Vector3(0.4, 0, 0.16), "thigh_r": Vector3(-0.3, 0, -0.16), "shin_l": Vector3(0.55, 0, 0), "shin_r": Vector3(0.55, 0, 0),
		"bob": -0.17, "hz": -0.06})
	var cut := _pz({"upperarm_r": Vector3(-1.35, -0.7, 0.25), "forearm_r": Vector3(-0.15, 0, 0), "hand_r": Vector3(0.2, 0, 0),
		"upperarm_l": Vector3(0.55, 0.0, 0.45), "forearm_l": Vector3(-1.0, 0, 0),
		"spine": Vector3(0.45, 0.8, 0), "chest": Vector3(0.08, 0.35, 0), "head": Vector3(-0.2, -0.55, 0),
		"thigh_l": Vector3(-0.95, 0, 0.14), "thigh_r": Vector3(0.6, 0, -0.14), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.35, 0, 0),
		"bob": -0.22, "hz": 0.32})
	var flick := _mix(cut, _pz({"upperarm_r": Vector3(-0.9, -0.3, 0.2), "forearm_r": Vector3(-0.7, 0, 0), "hand_r": Vector3(0.1, 0, 0),
		"spine": Vector3(0.3, 0.45, 0), "chest": Vector3(0.05, 0.2, 0), "head": Vector3(-0.1, -0.3, 0)}), 0.6)
	return _seq(u, [[0.0, ready, ""], [0.25, stance, "io"], [0.4, stance, "io"], [0.5, cut, "back"], [0.7, cut, "out"], [0.82, flick, "io"], [0.92, _mix(stance, ready, 0.5), "io"], [1.0, ready, "io"]])


## Skill menerjang (Kuroha, dash_cut): menggulung rendah dengan pedang ditarik ke belakang, melesat dengan lunge panjang (badan hampir mendatar,
## kaki belakang terentang), menebas menembus ke depan, lalu meluncur berhenti dengan lutut menekuk dan bangkit.
static func _p_skill_dashcut(u: float) -> Dictionary:
	var ready := _pz({})
	var coil := _pz({"upperarm_r": Vector3(-0.7, -0.5, -0.9), "forearm_r": Vector3(-0.9, 0, 0), "hand_r": Vector3(-0.2, 0, 0),
		"upperarm_l": Vector3(0.6, 0, 0.6), "forearm_l": Vector3(-0.6, 0, 0),
		"spine": Vector3(0.35, -0.9, 0), "chest": Vector3(0.05, -0.35, 0), "head": Vector3(0.0, 0.6, 0),
		"thigh_l": Vector3(0.5, 0, 0.14), "thigh_r": Vector3(-0.35, 0, -0.14), "shin_l": Vector3(0.8, 0, 0), "shin_r": Vector3(0.7, 0, 0),
		"bob": -0.24, "hz": -0.1})
	var dash := _pz({"upperarm_r": Vector3(-1.3, -0.3, -0.2), "forearm_r": Vector3(-0.25, 0, 0), "hand_r": Vector3(0.1, 0, 0),
		"upperarm_l": Vector3(1.2, 0, 0.4), "forearm_l": Vector3(-0.5, 0, 0),
		"spine": Vector3(1.0, -0.2, 0), "chest": Vector3(0.12, -0.1, 0), "head": Vector3(-0.8, 0.1, 0),
		"thigh_l": Vector3(-1.0, 0, 0.1), "thigh_r": Vector3(0.9, 0, -0.1), "shin_l": Vector3(0.4, 0, 0), "shin_r": Vector3(0.35, 0, 0),
		"bob": -0.22, "hz": 0.38})
	var cut := _pz({"upperarm_r": Vector3(-1.2, 0.9, 0.35), "forearm_r": Vector3(-0.15, 0, 0), "hand_r": Vector3(0.2, 0, 0),
		"upperarm_l": Vector3(0.9, 0, 0.7), "forearm_l": Vector3(-0.4, 0, 0),
		"spine": Vector3(0.75, 0.95, 0), "chest": Vector3(0.1, 0.4, 0), "head": Vector3(-0.5, -0.65, 0),
		"thigh_l": Vector3(-0.85, 0, 0.14), "thigh_r": Vector3(0.65, 0, -0.14), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.45, 0, 0),
		"bob": -0.24, "hz": 0.34})
	var slide := _pz({"upperarm_r": Vector3(-0.8, 0.5, 0.1), "forearm_r": Vector3(-0.4, 0, 0),
		"upperarm_l": Vector3(0.3, 0, 0.6), "forearm_l": Vector3(-0.5, 0, 0),
		"spine": Vector3(0.45, 0.5, 0), "chest": Vector3(0.06, 0.2, 0), "head": Vector3(-0.2, -0.3, 0),
		"thigh_l": Vector3(-0.6, 0, 0.14), "thigh_r": Vector3(0.2, 0, -0.14), "shin_l": Vector3(1.0, 0, 0), "shin_r": Vector3(0.7, 0, 0),
		"bob": -0.26, "hz": 0.2})
	return _seq(u, [[0.0, ready, ""], [0.2, coil, "io"], [0.3, coil, "io"], [0.42, dash, "back"], [0.52, cut, "back"], [0.75, slide, "out"], [1.0, ready, "io"]])


## Skill tembakan beruntun tongkat (Lucien, volley): tongkat dibidik lurus ke depan dengan dua tangan, tiga sentakan cepat (badan terdorong tiap tembakan),
## lalu hentakan penutup yang lebih besar dengan kaki depan melangkah, dan tongkat diturunkan.
static func _p_skill_volley(u: float) -> Dictionary:
	var ready := _pz({})
	var aim := _pz({"upperarm_r": Vector3(-1.25, 0.1, -0.2), "forearm_r": Vector3(-0.55, 0, 0), "hand_r": Vector3(-0.1, 0, 0),
		"upperarm_l": Vector3(-1.1, 0.0, 0.3), "forearm_l": Vector3(-0.5, 0, 0),
		"spine": Vector3(-0.02, -0.25, 0), "chest": Vector3(0, -0.1, 0), "head": Vector3(0.0, 0.2, 0),
		"thigh_l": Vector3(0.2, 0, 0.1), "thigh_r": Vector3(-0.15, 0, -0.1), "shin_r": Vector3(0.2, 0, 0), "bob": -0.05, "hz": -0.02})
	var pulse := _pz({"upperarm_r": Vector3(-1.05, 0.1, -0.2), "forearm_r": Vector3(-0.8, 0, 0), "hand_r": Vector3(-0.1, 0, 0),
		"upperarm_l": Vector3(-0.95, 0.0, 0.3), "forearm_l": Vector3(-0.7, 0, 0),
		"spine": Vector3(-0.1, -0.25, 0), "chest": Vector3(-0.05, -0.1, 0), "head": Vector3(0.05, 0.2, 0),
		"thigh_l": Vector3(0.2, 0, 0.1), "thigh_r": Vector3(-0.15, 0, -0.1), "shin_r": Vector3(0.2, 0, 0), "bob": -0.04, "hz": -0.1})
	var thrust := _pz({"upperarm_r": Vector3(-1.5, 0.0, -0.15), "forearm_r": Vector3(-0.15, 0, 0), "hand_r": Vector3(0.1, 0, 0),
		"upperarm_l": Vector3(-1.4, 0.0, 0.25), "forearm_l": Vector3(-0.2, 0, 0),
		"spine": Vector3(0.3, -0.1, 0), "chest": Vector3(0.08, -0.05, 0), "head": Vector3(-0.2, 0.1, 0),
		"thigh_l": Vector3(-0.5, 0, 0.1), "thigh_r": Vector3(0.3, 0, -0.1), "shin_l": Vector3(0.4, 0, 0), "shin_r": Vector3(0.3, 0, 0), "bob": -0.1, "hz": 0.16})
	return _seq(u, [[0.0, ready, ""], [0.22, aim, "io"], [0.3, pulse, "back"], [0.4, aim, "out"], [0.5, pulse, "back"], [0.6, aim, "out"],
		[0.7, pulse, "back"], [0.78, thrust, "back"], [0.92, _mix(thrust, ready, 0.5), "out"], [1.0, ready, "io"]])


## Terkena serangan: badan tersentak ke belakang lalu pulih.
static func _p_hurt(u: float) -> Dictionary:
	var d := _p_idle(0.0, true)
	var h := _ease_out(u / 0.2) * pow(1.0 - u, 1.6)
	d["spine"] = Vector3(-0.38 * h, 0.0, 0.1 * h)
	d["head"] = Vector3(-0.4 * h, 0.0, 0)
	d["upperarm_l"] = Vector3(-0.5 * h, 0, 0.18 + 0.7 * h)
	d["upperarm_r"] = Vector3(-0.3 - 0.5 * h, 0, -0.18 - 0.7 * h)
	d["forearm_l"] = Vector3(-0.15 - 0.5 * h, 0, 0)
	d["forearm_r"] = Vector3(-0.6 - 0.2 * h, 0, 0)
	d["thigh_l"] = Vector3(0.2 * h, 0, 0.03)
	d["thigh_r"] = Vector3(-0.15 * h, 0, -0.03)
	d["bob"] = -0.05 * h
	return d


## Kalah: rebah ke belakang dan tetap di lantai (tidak berulang).
static func _p_death(u: float) -> Dictionary:
	var d := _p_idle(0.0, true)
	var stagger := _ease_out(u / 0.25)
	var fall := _ease_io((u - 0.2) / 0.6)
	d["hips"] = Vector3(-1.5 * fall, 0, 0)
	d["spine"] = Vector3(-0.3 * stagger + 0.15 * fall, 0, 0)
	d["head"] = Vector3(-0.35 * stagger, 0, 0.1 * fall)
	d["upperarm_l"] = Vector3(-0.5 * stagger, 0, 0.25 + 0.9 * fall)
	d["upperarm_r"] = Vector3(-0.3 - 0.5 * stagger, 0, -0.25 - 0.9 * fall)
	d["forearm_l"] = Vector3(-0.3, 0, 0)
	d["forearm_r"] = Vector3(-0.4, 0, 0)
	d["thigh_l"] = Vector3(0.3 * fall, 0, 0.08 * fall)
	d["thigh_r"] = Vector3(0.15 * fall, 0, -0.1 * fall)
	d["shin_l"] = Vector3(0.4 * fall, 0, 0)
	d["shin_r"] = Vector3(0.7 * fall, 0, 0)
	d["bob"] = -0.05 * stagger - 0.66 * fall
	d["hz"] = -0.08 * fall
	return d


## Menang: satu tangan terangkat melambai, tubuh melonjak kecil.
static func _p_victory(u: float) -> Dictionary:
	var d := _p_idle(0.0, false)
	var ph := u * TAU
	d["upperarm_r"] = Vector3(-2.75, 0, -0.35 + 0.1 * sin(ph * 2.0))
	d["forearm_r"] = Vector3(-0.35 + 0.4 * sin(ph * 2.0), 0, 0)
	d["upperarm_l"] = Vector3(-0.2, 0, 0.7)
	d["forearm_l"] = Vector3(-1.5, 0, 0)
	d["spine"] = Vector3(-0.05, 0.12 * sin(ph), 0)
	d["head"] = Vector3(-0.12, 0.2 * sin(ph), 0.05 * sin(ph))
	d["bob"] = absf(sin(ph)) * 0.09
	d["thigh_l"] = Vector3(0, 0, 0.1)
	d["thigh_r"] = Vector3(0, 0, -0.1)
	return d


# =====================================================================
#  Variasi diam NPC
# =====================================================================
static func _p_cross(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var br := sin(u * TAU)
	d["upperarm_l"] = Vector3(-0.35, 0.65, 0.5)
	d["forearm_l"] = Vector3(-1.9, 0, 0)
	d["upperarm_r"] = Vector3(-0.35, -0.65, -0.5)
	d["forearm_r"] = Vector3(-1.9, 0, 0)
	d["head"] = Vector3(-0.02 + 0.02 * br, 0.3 * sin(u * TAU), 0)
	d["thigh_l"] = Vector3(0, 0, 0.07)
	d["thigh_r"] = Vector3(0, 0, -0.07)
	return d


static func _p_hammer(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var k := fmod(u, 1.0)
	var up := _ease_io(k / 0.6)
	var hit := _ease_out((k - 0.6) / 0.15)
	var a := lerpf(-0.9, -2.2, up)
	a = lerpf(a, -0.7, hit)
	d["upperarm_r"] = Vector3(a, 0, -0.15)
	d["forearm_r"] = Vector3(lerpf(-1.3, -1.0, up) * (1.0 - hit) - 0.5 * hit, 0, 0)
	d["hand_r"] = Vector3(-0.2 * hit, 0, 0)
	d["upperarm_l"] = Vector3(-0.8, 0, 0.3)
	d["forearm_l"] = Vector3(-0.9, 0, 0)
	d["spine"] = Vector3(0.15 + 0.18 * hit - 0.08 * up, 0, 0)
	d["head"] = Vector3(0.2 + 0.1 * hit, 0, 0)
	d["bob"] = -0.03 * hit
	return d


static func _p_wave(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var ph := u * TAU
	var lift := _ease_io(minf(u / 0.15, 1.0)) * (1.0 - _ease_io((u - 0.75) / 0.25))
	d["upperarm_r"] = Vector3(lerpf(0.0, -2.6, lift), 0, lerpf(-0.08, -0.55, lift))
	d["forearm_r"] = Vector3(lerpf(-0.15, -0.5, lift) + 0.45 * lift * sin(ph * 5.0), 0, 0)
	d["head"] = Vector3(-0.03, 0.15 * sin(ph) * (1.0 - lift), 0.05 * lift)
	return d


static func _p_gesture(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var ph := u * TAU
	d["upperarm_r"] = Vector3(-0.8 - 0.25 * sin(ph * 2.0), 0.3, -0.35)
	d["forearm_r"] = Vector3(-1.1 + 0.35 * sin(ph * 2.0 + 1.0), 0, 0)
	d["hand_r"] = Vector3(0.2 * sin(ph * 2.0), 0, 0)
	d["upperarm_l"] = Vector3(-0.15, 0, 0.12)
	d["head"] = Vector3(-0.03 + 0.05 * sin(ph * 2.0), 0.25 * sin(ph), 0)
	d["spine"] = Vector3(0.02, 0.08 * sin(ph), 0)
	return d


static func _p_attention(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var br := sin(u * TAU)
	d["upperarm_l"] = Vector3(0, 0, 0.04)
	d["forearm_l"] = Vector3(-0.05, 0, 0)
	d["upperarm_r"] = Vector3(-0.15, 0, -0.04)
	d["forearm_r"] = Vector3(-0.05, 0, 0)
	d["spine"] = Vector3(-0.04 + 0.01 * br, 0, 0)
	d["chest"] = Vector3(-0.03 + 0.015 * br, 0, 0)
	d["head"] = Vector3(0.0, 0.18 * sin(u * TAU), 0)
	d["thigh_l"] = Vector3(0, 0, 0.05)
	d["thigh_r"] = Vector3(0, 0, -0.05)
	return d


## Peramal: kedua tangan melingkar di atas bola kristal.
static func _p_stir(u: float) -> Dictionary:
	var d := _p_idle(u, false)
	var ph := u * TAU
	d["upperarm_l"] = Vector3(-0.85 + 0.1 * sin(ph * 2.0), -0.2, 0.25)
	d["forearm_l"] = Vector3(-1.15 + 0.2 * cos(ph * 2.0), 0, 0)
	d["upperarm_r"] = Vector3(-0.85 + 0.1 * cos(ph * 2.0), 0.2, -0.25)
	d["forearm_r"] = Vector3(-1.15 + 0.2 * sin(ph * 2.0), 0, 0)
	d["head"] = Vector3(0.25, 0.1 * sin(ph), 0)
	d["spine"] = Vector3(0.1, 0, 0)
	return d


# =====================================================================
#  Gaya gerak PER KARAKTER: diam (idle@id), jalan (walk@id), lari (run@id), siaga setelah serangan (ready@id).
#  Dibuat lazy lewat ensure_style(id) agar tidak membebani HP saat game dibuka.
#  hold = tulang yang dipaksa ke pose tertentu (mis. Wenyu memegang seruling di bibir), add = offset tambahan,
#  sway/beat = goyangan pinggul, stride/bounce = pengali langkah & loncatan saat jalan.
# =====================================================================
const READY_BASE := {
	"sword": {"upperarm_r": Vector3(-1.1, 0.2, -0.35), "forearm_r": Vector3(-1.0, 0, 0), "hand_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-0.5, 0, 0.7),
		"forearm_l": Vector3(-0.7, 0, 0), "spine": Vector3(0.12, -0.25, 0), "head": Vector3(0.0, 0.15, 0), "thigh_l": Vector3(0.28, 0, 0.1),
		"thigh_r": Vector3(-0.2, 0, -0.1), "shin_r": Vector3(0.35, 0, 0), "shin_l": Vector3(0.12, 0, 0), "bob": -0.05},
	"staff": {"upperarm_r": Vector3(-0.9, 0.1, -0.3), "forearm_r": Vector3(-1.2, 0, 0), "upperarm_l": Vector3(-0.9, 0, 0.4), "forearm_l": Vector3(-0.9, 0, 0),
		"spine": Vector3(0.05, -0.15, 0), "thigh_l": Vector3(0.18, 0, 0.08), "thigh_r": Vector3(-0.12, 0, -0.08), "shin_r": Vector3(0.2, 0, 0), "bob": -0.03},
	"guard": {"upperarm_l": Vector3(-1.3, 0, 0.2), "forearm_l": Vector3(-1.5, 0, 0), "upperarm_r": Vector3(-0.9, 0, -0.3), "forearm_r": Vector3(-1.0, 0, 0),
		"spine": Vector3(0.2, 0, 0), "head": Vector3(0.1, 0, 0), "thigh_l": Vector3(0.3, 0, 0.2), "thigh_r": Vector3(-0.3, 0, -0.2),
		"shin_r": Vector3(0.5, 0, 0), "shin_l": Vector3(0.2, 0, 0), "bob": -0.1},
	"bow": {"upperarm_l": Vector3(-1.5, 0, 0.1), "forearm_l": Vector3(-0.1, 0, 0), "upperarm_r": Vector3(-1.3, 0.3, -0.6), "forearm_r": Vector3(-1.9, 0, 0),
		"spine": Vector3(0, -0.5, 0), "head": Vector3(0, 0.5, 0), "thigh_l": Vector3(0.1, 0, 0.14), "thigh_r": Vector3(-0.1, 0, -0.14), "bob": -0.04},
	"dagger": {"upperarm_r": Vector3(-0.9, 0.3, -0.4), "forearm_r": Vector3(-1.3, 0, 0), "upperarm_l": Vector3(-0.7, -0.3, 0.5), "forearm_l": Vector3(-1.3, 0, 0),
		"spine": Vector3(0.35, -0.2, 0), "thigh_l": Vector3(0.5, 0, 0.12), "thigh_r": Vector3(-0.35, 0, -0.12), "shin_r": Vector3(0.8, 0, 0), "shin_l": Vector3(0.4, 0, 0), "bob": -0.14},
}

# ---------------------------------------------------------------------
#  POSE GAYA (diam & siaga): sikap "kece" tiap karakter, bukan sekadar memegang senjata tegak di depan badan.
#  att  : cant = miring pinggul (bahu menyeimbangkan ke arah sebaliknya, contrapposto), tilt = kepala miring, chin = dagu
#         (+ menunduk / - mendongak), twist = badan diputar 3/4 (pinggul memutar, dada/kepala menyusul balik), lean = condong badan
#         (+ ke depan), hipx = pinggul bergeser ke samping (satuan model)
#  idle / ready : tulang yang diganti total pada pose itu (sisanya mengikuti gaya dasar STYLES)
#  Arah bilah = sumbu +Z tangan: hand_x positif memutar bilah ke bawah (1.0 ~ 60 derajat ke bawah, 1.9 ~ ke bawah-belakang).
# ---------------------------------------------------------------------
const POSES := {
	# Swordsman: pedang dijuntai rendah di sisi kanan, tangan kiri di pinggang, dagu naik percaya diri
	"ren": {"att": {"cant": 0.07, "tilt": 0.10, "chin": -0.08, "twist": 0.25, "lean": -0.02, "hipx": 0.02},
		"idle": {"upperarm_r": Vector3(-0.2, 0.0, -0.3), "forearm_r": Vector3(-0.45, 0, 0), "hand_r": Vector3(0.8, 0, 0),
			"upperarm_l": Vector3(0.05, 0.0, 0.75), "forearm_l": Vector3(-1.15, 0, 0), "thigh_l": Vector3(0.1, 0, 0.1), "shin_l": Vector3(0.2, 0, 0)},
		"ready": {"upperarm_r": Vector3(-0.85, 0.2, -0.45), "forearm_r": Vector3(-0.9, 0, 0), "hand_r": Vector3(0.5, 0, 0)}},
	# Pendekar cahaya: ujung pedang besar bertumpu di tanah di depan, satu tangan di gagang, badan bersandar santai
	"vael": {"att": {"cant": 0.06, "tilt": -0.10, "chin": 0.12, "twist": 0.2, "lean": -0.05, "hipx": -0.02},
		"idle": {"upperarm_r": Vector3(-0.45, 0.0, -0.15), "forearm_r": Vector3(-0.5, 0, 0), "hand_r": Vector3(1.1, 0, 0),
			"upperarm_l": Vector3(0.05, 0.0, 0.22), "forearm_l": Vector3(-0.25, 0, 0), "thigh_l": Vector3(0.08, 0, 0.12), "shin_l": Vector3(0.15, 0, 0)},
		"ready": {"upperarm_r": Vector3(-0.8, 0.1, -0.3), "forearm_r": Vector3(-1.0, 0, 0), "hand_r": Vector3(0.6, 0, 0),
			"upperarm_l": Vector3(-0.2, 0.0, 0.5), "forearm_l": Vector3(-0.6, 0, 0)}},
	# Samurai putih: katana menjuntai ke bawah, tangan kiri bersandar di pinggang, kepala menunduk tenang
	"hakuya": {"att": {"cant": -0.05, "tilt": 0.12, "chin": 0.14, "twist": -0.2, "lean": 0.0, "hipx": 0.0},
		"idle": {"upperarm_r": Vector3(0.1, 0.0, -0.2), "forearm_r": Vector3(-0.25, 0, 0), "hand_r": Vector3(1.15, 0, 0),
			"upperarm_l": Vector3(0.0, 0.0, 0.4), "forearm_l": Vector3(-0.8, 0, 0)},
		"ready": {}},
	# Samurai kelam: pedang diseret rendah di belakang, badan condong, kepala tertunduk (rambut menutupi)
	"kuroha": {"att": {"cant": 0.08, "tilt": -0.12, "chin": 0.22, "twist": 0.2, "lean": 0.06, "hipx": 0.02},
		"idle": {"upperarm_r": Vector3(0.3, 0.0, -0.2), "forearm_r": Vector3(-0.15, 0, 0), "hand_r": Vector3(1.8, 0, 0),
			"upperarm_l": Vector3(0.0, 0.0, 0.2), "forearm_l": Vector3(-0.4, 0, 0)},
		"ready": {}},
	# Pedang ganda: satu bilah terangkat di belakang bahu, satu rendah di sisi, tubuh melengkung
	"kyomu": {"att": {"cant": 0.1, "tilt": 0.14, "chin": 0.06, "twist": 0.3, "lean": 0.08, "hipx": 0.03},
		"idle": {"upperarm_r": Vector3(-0.3, 0.0, -1.0), "forearm_r": Vector3(-1.5, 0, 0), "hand_r": Vector3(0.2, 0, 0),
			"upperarm_l": Vector3(-0.1, 0.0, 0.45), "forearm_l": Vector3(-0.55, 0, 0), "hand_l": Vector3(0.8, 0, 0)},
		"ready": {}},
	# Mage/Fighter petir (tanpa tongkat): satu telapak terbuka memercikkan listrik di samping pinggul, tangan lain santai, bahu naik-turun lincah
	"kiriel": {"att": {"cant": 0.06, "tilt": 0.1, "chin": -0.05, "twist": 0.2, "lean": 0.03, "hipx": 0.02},
		"idle": {"upperarm_r": Vector3(-0.25, 0.0, -0.3), "forearm_r": Vector3(-0.7, 0, 0), "hand_r": Vector3(0.4, 0, 0),
			"upperarm_l": Vector3(-0.55, 0.0, 0.5), "forearm_l": Vector3(-0.95, 0, 0), "hand_l": Vector3(-0.5, 0, 0)}, "ready": {}},
	# Zyrax (★6)
	"zyrax": {"att": {"cant": 0.06, "tilt": 0.1, "chin": -0.05, "twist": 0.2, "lean": 0.03, "hipx": 0.02},
		"idle": {"upperarm_r": Vector3(-0.25, 0.0, -0.3), "forearm_r": Vector3(-0.7, 0, 0), "hand_r": Vector3(0.4, 0, 0),
			"upperarm_l": Vector3(-0.55, 0.0, 0.5), "forearm_l": Vector3(-0.95, 0, 0), "hand_l": Vector3(-0.5, 0, 0)}, "ready": {}},
	# Midori (★6)
	"midori": {"att": {"cant": 0.1, "tilt": 0.14, "chin": 0.06, "twist": 0.3, "lean": 0.08, "hipx": 0.03},
		"idle": {"upperarm_r": Vector3(-0.3, 0.0, -1.0), "forearm_r": Vector3(-1.5, 0, 0), "hand_r": Vector3(0.2, 0, 0),
			"upperarm_l": Vector3(-0.1, 0.0, 0.45), "forearm_l": Vector3(-0.55, 0, 0), "hand_l": Vector3(0.8, 0, 0)},
		"ready": {}},
	# Assassin: bilah terbalik rendah di sisi, merunduk, kepala miring mengawasi
	"zeya": {"att": {"cant": 0.08, "tilt": 0.12, "chin": 0.08, "twist": 0.25, "lean": 0.06, "hipx": 0.02},
		"idle": {"upperarm_r": Vector3(-0.1, 0.0, -0.35), "forearm_r": Vector3(-0.7, 0, 0), "hand_r": Vector3(0.9, 0, 0),
			"upperarm_l": Vector3(-0.3, 0.0, 0.5), "forearm_l": Vector3(-0.9, 0, 0), "hand_l": Vector3(0.5, 0, 0)},
		"ready": {}},
	# Penyihir: tongkat tegak di sisi, tangan kiri terbuka seperti merapal, dagu terangkat
	"lyra": {"att": {"cant": 0.05, "tilt": 0.10, "chin": -0.12, "twist": 0.2, "lean": -0.02, "hipx": 0.0},
		"idle": {"upperarm_l": Vector3(-0.3, 0.0, 0.6), "forearm_l": Vector3(-0.6, 0, 0), "hand_l": Vector3(-0.4, 0, 0)}, "ready": {}},
	# Tank: dada membusung, kepala menunduk menantang, bahu miring berat
	"brann": {"att": {"cant": 0.06, "tilt": 0.08, "chin": 0.1, "twist": 0.25, "lean": -0.04, "hipx": 0.03}, "idle": {}, "ready": {}},
	# Pemanah: badan menyamping santai, kepala miring mengawasi
	"sera": {"att": {"cant": 0.06, "tilt": 0.10, "chin": -0.05, "twist": 0.15, "lean": 0.0, "hipx": 0.02}, "idle": {}, "ready": {}},
	# Pyromancer: pinggul condong, kepala miring nakal
	"ember": {"att": {"cant": -0.06, "tilt": -0.12, "chin": -0.05, "twist": -0.2, "lean": 0.0, "hipx": -0.02}, "idle": {}, "ready": {}},
	# Bangsawan: tegak dengan dagu terangkat, sedikit memutar
	"lucien": {"att": {"cant": 0.04, "tilt": 0.06, "chin": -0.10, "twist": 0.2, "lean": -0.03, "hipx": 0.0}, "idle": {}, "ready": {}},
	# Peniup seruling: pinggul meliuk, kepala miring mengikuti irama
	"wenyu": {"att": {"cant": 0.08, "tilt": 0.14, "chin": 0.06, "twist": 0.15, "lean": 0.0, "hipx": 0.02}, "idle": {}, "ready": {}},
	# Pengendali waktu: sikap dingin, kepala sedikit mendongak
	"aion": {"att": {"cant": -0.05, "tilt": 0.08, "chin": -0.08, "twist": -0.2, "lean": -0.02, "hipx": -0.02}, "idle": {}, "ready": {}},
}
const STYLE_IDS := ["ren", "lyra", "brann", "sera", "ember", "zeya", "hakuya", "vael", "lucien", "wenyu", "kuroha", "aion", "kyomu", "kiriel", "midori", "zyrax"]
const STYLES := {
	# Swordsman: santai percaya diri, pedang rendah di depan, bobot berpindah kaki
	"ren": {"wc": "sword", "len": 2.6, "sway": 0.06, "bob": -0.01, "beat": 1.0, "stride": 1.0, "bounce": 1.0, "lean": 0.04,
		"hold": {"upperarm_r": Vector3(-0.55, 0.0, -0.15), "forearm_r": Vector3(-0.75, 0, 0)}, "add": {"spine": Vector3(0.03, 0.05, 0)}},
	# Mage: tongkat tegak dua tangan, melayang pelan, kepala menengadah
	"lyra": {"wc": "staff", "len": 3.0, "sway": 0.035, "bob": 0.02, "beat": 1.0, "stride": 0.8, "bounce": 1.3, "lean": -0.02,
		"hold": {"upperarm_r": Vector3(-0.75, 0.0, -0.25), "forearm_r": Vector3(-1.0, 0, 0), "upperarm_l": Vector3(-0.55, 0.0, 0.3), "forearm_l": Vector3(-0.85, 0, 0)},
		"add": {"head": Vector3(-0.1, 0, 0)}},
	# Guardian (tank): kuda-kuda lebar, perisai/lengan depan, napas berat, langkah pendek menghentak
	"brann": {"wc": "guard", "len": 3.4, "sway": 0.02, "bob": -0.05, "beat": 1.0, "stride": 0.72, "bounce": 1.7, "lean": -0.06,
		"hold": {"upperarm_l": Vector3(-0.95, 0.0, 0.25), "forearm_l": Vector3(-1.3, 0, 0), "upperarm_r": Vector3(-0.5, 0.0, -0.3), "forearm_r": Vector3(-0.8, 0, 0)},
		"add": {"thigh_l": Vector3(0, 0, 0.12), "thigh_r": Vector3(0, 0, -0.12), "spine": Vector3(0.06, 0, 0), "head": Vector3(0.05, 0, 0)}},
	# Ranger: berdiri menyamping, tangan busur sedikit terangkat, kepala mengawasi, langkah ringan melenting
	"sera": {"wc": "bow", "len": 2.2, "sway": 0.05, "bob": 0.0, "beat": 1.0, "stride": 1.05, "bounce": 1.2, "lean": 0.05,
		"hold": {"upperarm_l": Vector3(-0.7, 0.0, 0.35), "forearm_l": Vector3(-0.5, 0, 0)},
		"add": {"spine": Vector3(0, -0.2, 0), "head": Vector3(0, 0.25, 0)}},
	# Pyromancer: telapak kiri terbuka memegang api, gelisah bergoyang
	"ember": {"wc": "staff", "len": 1.9, "sway": 0.08, "bob": 0.0, "beat": 2.0, "stride": 1.0, "bounce": 1.1, "lean": 0.02,
		"hold": {"upperarm_l": Vector3(-0.9, 0.0, 0.5), "forearm_l": Vector3(-1.1, 0, 0), "hand_l": Vector3(-0.6, 0, 0)},
		"add": {"head": Vector3(0.0, 0.1, 0.05)}},
	# Assassin: merunduk rendah, lengan rendah siap, langkah cepat dan senyap
	"zeya": {"wc": "dagger", "len": 1.8, "sway": 0.07, "bob": -0.09, "beat": 1.0, "stride": 1.15, "bounce": 0.7, "lean": 0.18,
		"hold": {"upperarm_r": Vector3(-0.5, 0.2, -0.3), "forearm_r": Vector3(-1.0, 0, 0), "upperarm_l": Vector3(-0.4, -0.2, 0.4), "forearm_l": Vector3(-1.0, 0, 0)},
		"add": {"thigh_l": Vector3(0.3, 0, 0.06), "thigh_r": Vector3(-0.2, 0, -0.06), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.4, 0, 0), "spine": Vector3(0.22, 0, 0)}},
	# Samurai putih: tegak tenang, tangan kiri di sarung, langkah meluncur
	"hakuya": {"wc": "sword", "len": 3.2, "sway": 0.015, "bob": 0.0, "beat": 1.0, "stride": 0.95, "bounce": 0.45, "lean": 0.0,
		"hold": {"upperarm_l": Vector3(-0.35, 0.0, 0.2), "forearm_l": Vector3(-1.1, 0, 0), "upperarm_r": Vector3(-0.5, 0.0, -0.1), "forearm_r": Vector3(-1.0, 0, 0)},
		"add": {"head": Vector3(0, 0.06, 0)}},
	# Pendekar cahaya: pedang tegak di depan dada, bangsawan, napas panjang
	"vael": {"wc": "sword", "len": 3.0, "sway": 0.03, "bob": 0.01, "beat": 1.0, "stride": 0.9, "bounce": 0.8, "lean": -0.02,
		"hold": {"upperarm_r": Vector3(-0.95, 0.15, -0.2), "forearm_r": Vector3(-1.3, 0, 0), "upperarm_l": Vector3(-0.2, 0.0, 0.3), "forearm_l": Vector3(-0.5, 0, 0)},
		"add": {"spine": Vector3(-0.03, 0, 0), "head": Vector3(-0.05, 0, 0)}},
	# Bangsawan bertongkat: tongkat menapak, tangan kiri di punggung, langkah rapi berirama
	"lucien": {"wc": "staff", "len": 3.4, "sway": 0.02, "bob": 0.0, "beat": 1.0, "stride": 0.85, "bounce": 0.9, "lean": -0.03,
		"hold": {"upperarm_r": Vector3(-0.35, 0.0, -0.15), "forearm_r": Vector3(-0.45, 0, 0), "upperarm_l": Vector3(0.45, 0.0, 0.15), "forearm_l": Vector3(-0.9, 0, 0)},
		"add": {"spine": Vector3(-0.04, 0, 0), "head": Vector3(0, 0.1, 0)}},
	# Peniup seruling: seruling di bibir, badan meliuk mengikuti irama lagu, langkah seperti menari
	"wenyu": {"wc": "staff", "len": 2.0, "sway": 0.13, "bob": 0.01, "beat": 2.0, "stride": 0.75, "bounce": 1.5, "lean": 0.0,
		"hold": {"upperarm_r": Vector3(-1.25, 0.35, -0.45), "forearm_r": Vector3(-1.95, 0, 0), "upperarm_l": Vector3(-1.15, -0.2, 0.55), "forearm_l": Vector3(-1.85, 0, 0)},
		"add": {"head": Vector3(0.12, 0.0, 0.1), "spine": Vector3(0.0, 0.0, 0.05)}},
	# Pengendali waktu: tongkat jam di tangan kanan, tangan kiri terbuka seperti menahan detik, langkah anggun melayang
	"aion": {"wc": "staff", "len": 2.6, "sway": 0.05, "bob": 0.015, "beat": 1.0, "stride": 0.85, "bounce": 1.1, "lean": -0.02,
		"hold": {"upperarm_r": Vector3(-0.6, 0.0, -0.2), "forearm_r": Vector3(-0.8, 0, 0), "upperarm_l": Vector3(-0.5, 0.0, 0.45), "forearm_l": Vector3(-0.9, 0, 0), "hand_l": Vector3(-0.4, 0, 0)},
		"add": {"head": Vector3(-0.04, 0.05, 0), "spine": Vector3(-0.02, 0, 0)}},
	# Petarung pedang ganda: merunduk ramping, dua bilah rendah di sisi, langkah ringan & cepat
	"kyomu": {"wc": "dagger", "len": 2.4, "sway": 0.06, "bob": -0.1, "beat": 1.0, "stride": 1.2, "bounce": 0.7, "lean": 0.2,
		"hold": {"upperarm_r": Vector3(-0.45, 0.25, -0.35), "forearm_r": Vector3(-0.95, 0, 0), "upperarm_l": Vector3(-0.4, -0.25, 0.4), "forearm_l": Vector3(-0.95, 0, 0)},
		"add": {"thigh_l": Vector3(0.28, 0, 0.1), "thigh_r": Vector3(-0.2, 0, -0.1), "shin_l": Vector3(0.45, 0, 0), "shin_r": Vector3(0.38, 0, 0), "spine": Vector3(0.2, 0, 0), "head": Vector3(0.05, 0, 0)}},
	# Samurai kelam: condong ke depan, tangan di gagang, menekan
	"kiriel": {"wc": "staff", "len": 2.5, "sway": 0.05, "bob": -0.02, "beat": 1.6, "stride": 1.15, "bounce": 1.2, "lean": 0.05,
		"hold": {"upperarm_r": Vector3(-0.6, 0.15, -0.3), "forearm_r": Vector3(-1.0, 0, 0), "upperarm_l": Vector3(-0.7, -0.1, 0.45), "forearm_l": Vector3(-1.0, 0, 0)},
		"add": {"head": Vector3(0.03, 0, 0.04)}},
	# Zyrax (★6)
	"zyrax": {"wc": "staff", "len": 2.5, "sway": 0.05, "bob": -0.02, "beat": 1.6, "stride": 1.15, "bounce": 1.2, "lean": 0.05,
		"hold": {"upperarm_r": Vector3(-0.6, 0.15, -0.3), "forearm_r": Vector3(-1.0, 0, 0), "upperarm_l": Vector3(-0.7, -0.1, 0.45), "forearm_l": Vector3(-1.0, 0, 0)},
		"add": {"head": Vector3(0.03, 0, 0.04)}},
	# Midori (★6)
	"midori": {"wc": "dagger", "len": 2.4, "sway": 0.06, "bob": -0.1, "beat": 1.0, "stride": 1.2, "bounce": 0.7, "lean": 0.2,
		"hold": {"upperarm_r": Vector3(-0.45, 0.25, -0.35), "forearm_r": Vector3(-0.95, 0, 0), "upperarm_l": Vector3(-0.4, -0.25, 0.4), "forearm_l": Vector3(-0.95, 0, 0)},
		"add": {"thigh_l": Vector3(0.28, 0, 0.1), "thigh_r": Vector3(-0.2, 0, -0.1), "shin_l": Vector3(0.45, 0, 0), "shin_r": Vector3(0.38, 0, 0), "spine": Vector3(0.2, 0, 0), "head": Vector3(0.05, 0, 0)}},
	"kuroha": {"wc": "sword", "len": 2.8, "sway": 0.03, "bob": -0.04, "beat": 1.0, "stride": 1.05, "bounce": 0.6, "lean": 0.14,
		"hold": {"upperarm_r": Vector3(-0.6, 0.1, -0.2), "forearm_r": Vector3(-1.1, 0, 0), "upperarm_l": Vector3(-0.3, 0.0, 0.25), "forearm_l": Vector3(-1.0, 0, 0)},
		"add": {"spine": Vector3(0.2, 0, 0), "head": Vector3(0.12, 0, 0), "thigh_l": Vector3(0, 0, 0.07), "thigh_r": Vector3(0, 0, -0.07)}},
}


static func _fix_feet(d: Dictionary) -> void:
	d["foot_l"] = Vector3(-(d["thigh_l"].x + d["shin_l"].x) * 0.6, 0, 0)
	d["foot_r"] = Vector3(-(d["thigh_r"].x + d["shin_r"].x) * 0.6, 0, 0)


static func _style_apply(d: Dictionary, s: Dictionary, hold: bool = true, legs: bool = true) -> void:
	if hold:
		for b in s["hold"]:
			d[b] = s["hold"][b]
	for b in s["add"]:
		var v: Vector3 = s["add"][b]
		if not legs and (b.begins_with("thigh") or b.begins_with("shin")):
			v = Vector3(0, 0, v.z) if b.begins_with("thigh") else Vector3.ZERO      # kaki diatur IK; hanya lebar kuda-kuda yang dipakai
		d[b] = (d[b] as Vector3) + v


## Terapkan POSES[id]: ganti tulang yang disebut, lalu sikap badan (miring pinggul, kepala, putaran 3/4).
static func _pose_apply(d: Dictionary, id: String, kind: String) -> void:
	if not POSES.has(id):
		return
	var P: Dictionary = POSES[id]
	for b in P[kind]:
		d[b] = P[kind][b]
	var a: Dictionary = P["att"]
	var k := 1.0 if kind == "idle" else 1.25
	var cant: float = a["cant"] * k
	var tw: float = a["twist"] * k
	d["hips"] = (d["hips"] as Vector3) + Vector3(0, tw * 0.5, cant)
	d["spine"] = (d["spine"] as Vector3) + Vector3(float(a["lean"]) * 0.6, -tw * 0.3, -cant * 0.8)
	d["chest"] = (d["chest"] as Vector3) + Vector3(float(a["lean"]) * 0.4, -tw * 0.35, -cant * 0.3)
	d["head"] = (d["head"] as Vector3) + Vector3(float(a["chin"]), -tw * 0.1, float(a["tilt"]))
	d["hx"] = float(d["hx"]) + float(a["hipx"])


const IDLE_SWAY := 0.2


## Tangan yang memegang senjata ikut napas: lengan atas naik-turun halus, siku & pergelangan menyusul (dulu beku di pose "hold").
static func _hold_breath(d: Dictionary, s: Dictionary, u: float, k: float = 1.0) -> void:
	var ph := u * TAU
	var br := sin(ph)
	for b in s["hold"]:
		var side := 1.0 if String(b).ends_with("l") else -1.0
		var v: Vector3 = d[b]
		if String(b).begins_with("upperarm"):
			v += Vector3(0.07 * _lag(ph, 0.8), 0, side * 0.03 * br) * k
		elif String(b).begins_with("forearm"):
			v += Vector3(-0.08 * _lag(ph, 1.1) - 0.04 * sin(ph * 2.0 + 0.5), 0, 0) * k
		else:
			v += Vector3(0.06 * _lag(ph, 1.5), 0, 0) * k
		d[b] = v
	# pergelangan tangan pemegang ikut bergerak sedikit meski tidak ada di daftar hold
	for hb in ["hand_r", "hand_l"]:
		if not s["hold"].has(hb) and (s["hold"].has("upperarm_" + hb.right(1))):
			d[hb] = (d[hb] as Vector3) + Vector3(0.07 * _lag(ph, 1.5), 0.03 * br, 0) * k


static func _p_idle_s(u: float, id: String) -> Dictionary:
	var s: Dictionary = STYLES[id]
	var d := _p_idle(u, true)
	_style_apply(d, s)
	_pose_apply(d, id, "idle")
	_hold_breath(d, s, u, 0.35 if id == "wenyu" else 1.0)
	var ph := u * TAU * float(s["beat"])
	var sw := float(s["sway"]) * IDLE_SWAY                  # goyang samping saat diam dibuat sangat halus (sebelumnya terlihat seluruh badan bergoyang)
	d["hips"] = (d["hips"] as Vector3) + Vector3(0, 0.3 * sw * sin(ph), sw * sin(ph))
	d["spine"] = (d["spine"] as Vector3) + Vector3(0, 0.0, -0.6 * sw * sin(ph))
	d["head"] = (d["head"] as Vector3) + Vector3(0, 0.0, 0.5 * sw * sin(ph + 0.8))
	d["bob"] = float(d["bob"]) + float(s["bob"]) + 0.012 * sin(ph)
	_fix_feet(d)
	return d


static func _p_loco_s(u: float, run: float, id: String) -> Dictionary:
	var s: Dictionary = STYLES[id]
	var d := _p_loco(u, run, true, float(s["stride"]), float(s["bounce"]), float(s["bob"]) * 0.6)
	var ph := u * TAU
	_style_apply(d, s, true, false)
	var both: bool = s["hold"].has("upperarm_l") and s["hold"].has("upperarm_r")
	var amp := (0.15 + 0.08 * run) * (0.6 if both else 1.0)       # senjata dua tangan lebih tertahan; satu tangan mengayun lebih bebas
	for b in s["hold"]:                           # tangan pemegang senjata ikut mengayun & siku/pergelangan menyusul langkah (dulu hanya ~3 derajat saat jalan)
		var sg := 1.0 if b.ends_with("l") else -1.0
		if b.begins_with("upperarm"):
			d[b] = (d[b] as Vector3) + Vector3(amp * sin(ph) * sg, 0, 0.02 * sin(ph * 2.0))
		elif b.begins_with("forearm"):
			d[b] = (d[b] as Vector3) + Vector3(-0.10 * amp / 0.15 * (0.5 + 0.5 * sin(ph * 2.0 + 0.6)) * 0.7, 0, 0)
		else:
			d[b] = (d[b] as Vector3) + Vector3(0.1 * sin(ph * 2.0 + 1.0), 0, 0)
	for hb in ["hand_r", "hand_l"]:
		if not s["hold"].has(hb) and s["hold"].has("upperarm_" + hb.right(1)):
			d[hb] = (d[hb] as Vector3) + Vector3(0.1 * sin(ph * 2.0 + 1.0), 0, 0)
	d["spine"] = (d["spine"] as Vector3) + Vector3(float(s["lean"]) * run, 0, 0)
	d["hips"] = (d["hips"] as Vector3) + Vector3(0, 0, float(s["sway"]) * 0.5 * sin(ph))
	if POSES.has(id):                             # sikap kepala khas karakter ikut terbawa saat jalan/lari (kaki & pinggul tidak disentuh)
		var a: Dictionary = POSES[id]["att"]
		var k := 0.6 if run < 0.75 else 0.35
		d["head"] = (d["head"] as Vector3) + Vector3(float(a["chin"]) * k, 0.0, float(a["tilt"]) * k)
	return d


static func _p_ready_s(u: float, id: String) -> Dictionary:
	var s: Dictionary = STYLES[id]
	var d := _p_idle_s(u, id)
	var r: Dictionary = READY_BASE[s["wc"]]
	for b in r:
		d[b] = r[b]
	_pose_apply(d, id, "ready")
	_hold_breath(d, s, u, 0.3 if id == "wenyu" else 0.8)
	var br := sin(u * TAU)
	d["spine"] = (d["spine"] as Vector3) + Vector3(0.02 * br, 0.01 * br, 0)
	d["bob"] = float(d["bob"]) + 0.01 * br
	if id == "wenyu":                                  # tetap memegang seruling meski siaga
		for b in s["hold"]:
			d[b] = s["hold"][b]
	_fix_feet(d)
	return d


static func ensure_style(id: String) -> bool:
	if not STYLES.has(id):
		return false
	var lib := get_library()
	if lib.has_animation("idle@" + id):
		return true
	var s: Dictionary = STYLES[id]
	lib.add_animation("idle@" + id, _make(float(s["len"]), true, func(u): return _p_idle_s(u, id)))
	lib.add_animation("walk@" + id, _make(1.0, true, func(u): return _p_loco_s(u, 0.5, id)))
	lib.add_animation("run@" + id, _make(1.0, true, func(u): return _p_loco_s(u, 1.0, id)))
	lib.add_animation("ready@" + id, _make(2.2, true, func(u): return _p_ready_s(u, id)))
	return true


# =====================================================================
#  Gaya SERANG & SKILL per karakter: dibuat dari animasi dasar kelasnya (attack_sword1, attack_staff, dst.) lalu diberi
#  ciri khas tiap karakter, jadi Hakuya, Kuroha, Vael, dan Ren tidak lagi menebas dengan gerakan yang sama.
#  len     = pengali durasi (kecil = lebih cepat/lincah, besar = lebih berat). Fraksi waktu impak tidak berubah, jadi efek tetap tersinkron.
#  twist   = pengali putaran badan (spine/chest/head sumbu Y) saat ayunan
#  lunge   = pengali dorongan maju pinggul   dip = tambahan merunduk (negatif = lebih rendah)
#  add     = tambahan rotasi tulang (radian) yang aktif di sekitar momen impak (serangan biasa)
#  sk_len / sk_add = sama, khusus animasi skill
#  Belum dilihat di Godot: angka di sini perlu disetel setelah dicoba di game (lihat README).
# =====================================================================
const ATK := {
	# Swordsman: acuan seimbang, sedikit dorongan maju
	"ren": {"len": 1.0, "twist": 1.0, "lunge": 1.15, "dip": 0.0, "add": {}, "sk_len": 1.0, "sk_add": {}},
	# Samurai putih (iai): cepat, tubuh condong rendah, tangan kiri tertahan di sarung, meluncur maju
	"hakuya": {"len": 0.8, "twist": 0.75, "lunge": 1.6, "dip": -0.05,
		"add": {"spine": Vector3(0.14, 0, 0), "upperarm_l": Vector3(0.25, 0.0, -0.25), "forearm_l": Vector3(-0.35, 0, 0), "head": Vector3(0.05, 0, 0)},
		"sk_len": 0.9, "sk_add": {"spine": Vector3(0.1, 0, 0)}},
	# Samurai kelam: berat dan menekan, bahu menghantam, putaran besar
	"kuroha": {"len": 1.12, "twist": 1.35, "lunge": 1.35, "dip": -0.09,
		"add": {"spine": Vector3(0.16, 0, 0), "head": Vector3(0.1, 0, 0), "thigh_l": Vector3(0, 0, 0.08), "thigh_r": Vector3(0, 0, -0.08)},
		"sk_len": 1.1, "sk_add": {"spine": Vector3(0.18, 0, 0), "head": Vector3(0.1, 0, 0)}},
	# Pendekar cahaya: tegak anggun, tebasan rapi, dorongan kecil
	"vael": {"len": 1.0, "twist": 0.85, "lunge": 0.8, "dip": 0.02,
		"add": {"spine": Vector3(-0.1, 0, 0), "head": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(0.15, 0, 0.2)},
		"sk_len": 1.05, "sk_add": {"spine": Vector3(-0.08, 0, 0), "head": Vector3(-0.12, 0, 0)}},
	# Assassin: sangat cepat, rendah, memutar tajam
	"zeya": {"len": 0.85, "twist": 1.2, "lunge": 1.4, "dip": -0.07,
		"add": {"spine": Vector3(0.16, 0, 0), "head": Vector3(0.06, 0, 0)}, "sk_len": 0.9, "sk_add": {"spine": Vector3(0.12, 0, 0)}},
	# Kyomu (pedang ganda): paling lincah, memutar seperti menari, dorongan jauh
	"kyomu": {"len": 0.78, "twist": 1.45, "lunge": 1.45, "dip": -0.09,
		"add": {"spine": Vector3(0.14, 0, 0.1), "head": Vector3(0.05, 0, -0.06), "upperarm_l": Vector3(-0.1, 0, 0.15), "hand_r": Vector3(0.55, 0, 0), "hand_l": Vector3(0.55, 0, 0)},
		"sk_len": 0.92, "sk_add": {"spine": Vector3(0.1, 0, 0.08), "hand_r": Vector3(0.55, 0, 0), "hand_l": Vector3(0.55, 0, 0)}},
	# Mage: lembut mengambang, kepala menengadah, gerakan kecil
	"lyra": {"len": 1.05, "twist": 0.7, "lunge": 0.7, "dip": 0.05,
		"add": {"head": Vector3(-0.15, 0, 0), "spine": Vector3(-0.05, 0, 0)}, "sk_len": 1.0, "sk_add": {"head": Vector3(-0.12, 0, 0)}},
	# Mage/Fighter petir: lemparan telapak bergantian, cepat dan bertenaga
	"kiriel": {"len": 0.85, "twist": 1.1, "lunge": 1.1, "dip": -0.02,
		"add": {"upperarm_l": Vector3(-0.3, 0.0, 0.3), "hand_l": Vector3(-0.4, 0, 0), "spine": Vector3(0.06, 0, 0)},
		"sk_len": 0.95, "sk_add": {"upperarm_l": Vector3(-0.3, 0, 0.3), "hand_l": Vector3(-0.4, 0, 0)}},
	# Zyrax (★6)
	"zyrax": {"len": 0.8, "twist": 1.1, "lunge": 1.1, "dip": -0.02,
		"add": {"upperarm_l": Vector3(-0.3, 0.0, 0.3), "hand_l": Vector3(-0.4, 0, 0), "spine": Vector3(0.06, 0, 0)},
		"sk_len": 0.95, "sk_add": {"upperarm_l": Vector3(-0.3, 0, 0.3), "hand_l": Vector3(-0.4, 0, 0)}},
	# Midori (★6)
	"midori": {"len": 0.56, "twist": 1.45, "lunge": 1.45, "dip": -0.09,
		"add": {"spine": Vector3(0.14, 0, 0.1), "head": Vector3(0.05, 0, -0.06), "upperarm_l": Vector3(-0.1, 0, 0.15), "hand_r": Vector3(0.55, 0, 0), "hand_l": Vector3(0.55, 0, 0)},
		"sk_len": 0.92, "sk_add": {"spine": Vector3(0.1, 0, 0.08), "hand_r": Vector3(0.55, 0, 0), "hand_l": Vector3(0.55, 0, 0)}},
	# Pyromancer: agresif dan cepat, telapak kiri terbuka menyodok
	"ember": {"len": 0.88, "twist": 1.2, "lunge": 1.3, "dip": -0.02,
		"add": {"upperarm_l": Vector3(-0.35, 0.0, 0.35), "forearm_l": Vector3(-0.3, 0, 0), "hand_l": Vector3(-0.4, 0, 0), "spine": Vector3(0.08, 0, 0)},
		"sk_len": 0.95, "sk_add": {"upperarm_l": Vector3(-0.3, 0, 0.3), "hand_l": Vector3(-0.4, 0, 0)}},
	# Pengendali waktu: lambat terukur, tangan terbuka menahan detik
	"aion": {"len": 1.1, "twist": 0.6, "lunge": 0.6, "dip": 0.04,
		"add": {"head": Vector3(-0.1, 0, 0), "hand_l": Vector3(-0.5, 0, 0), "upperarm_l": Vector3(-0.2, 0, 0.25)},
		"sk_len": 1.08, "sk_add": {"head": Vector3(-0.1, 0, 0), "hand_l": Vector3(-0.4, 0, 0)}},
	# Bangsawan bertongkat: kaku presisi, badan tegak
	"lucien": {"len": 1.0, "twist": 0.5, "lunge": 0.65, "dip": 0.0,
		"add": {"spine": Vector3(-0.06, 0, 0), "head": Vector3(0, 0.08, 0)}, "sk_len": 1.0, "sk_add": {"spine": Vector3(-0.06, 0, 0)}},
	# Peniup seruling: meliuk mengikuti irama
	"wenyu": {"len": 1.1, "twist": 0.9, "lunge": 0.8, "dip": 0.03,
		"add": {"spine": Vector3(0, 0, 0.2), "head": Vector3(0.08, 0, 0.15)}, "sk_len": 1.08, "sk_add": {"spine": Vector3(0, 0, 0.18), "head": Vector3(0, 0, 0.12)}},
	# Guardian: hantaman berat, kuda-kuda lebar, bobot ke bawah
	"brann": {"len": 1.18, "twist": 0.9, "lunge": 1.4, "dip": -0.1,
		"add": {"spine": Vector3(0.1, 0, 0), "thigh_l": Vector3(0, 0, 0.1), "thigh_r": Vector3(0, 0, -0.1)},
		"sk_len": 1.1, "sk_add": {"spine": Vector3(0.08, 0, 0)}},
	# Ranger: ringan, kepala mengunci sasaran
	"sera": {"len": 0.9, "twist": 1.0, "lunge": 0.9, "dip": -0.02,
		"add": {"head": Vector3(0, 0.1, 0), "spine": Vector3(0.04, 0, 0)}, "sk_len": 0.95, "sk_add": {"head": Vector3(0, 0.1, 0)}},
}


static func _atk_len(base: String, id: String) -> float:
	var d: Array = _defs().get(base, [0.5])
	var c: Dictionary = ATK.get(id, {})
	return float(d[0]) * float(c.get("sk_len" if base.begins_with("skill_") else "len", 1.0))


static func _sstep(a: float, b: float, x: float) -> float:
	var t := clampf((x - a) / maxf(b - a, 0.0001), 0.0, 1.0)
	return t * t * (3.0 - 2.0 * t)


static func _atk_pose(p: Dictionary, u: float, c: Dictionary, base: String) -> Dictionary:
	var imp := float(IMPACT.get(base, 0.4))
	var skill := base.begins_with("skill_")
	# bobot gaya: puncak di sekitar impak, nol di awal & akhir supaya sambungan ke gerak dasar tetap mulus
	var env := _bump(u, imp, 0.24) * _sstep(0.0, 0.12, u) * (1.0 - _sstep(0.84, 1.0, u))
	var add: Dictionary = c.get("sk_add" if skill else "add", {})
	var legs := false
	for b in add:
		p[b] = (p[b] as Vector3) + (add[b] as Vector3) * env
		if String(b).begins_with("thigh") or String(b).begins_with("shin"):
			legs = true
	var tw := lerpf(1.0, float(c.get("twist", 1.0)), env)
	for b in ["spine", "chest", "head"]:
		var v: Vector3 = p[b]
		p[b] = Vector3(v.x, v.y * tw, v.z)
	p["hz"] = float(p["hz"]) * lerpf(1.0, float(c.get("lunge", 1.0)), env)
	p["bob"] = float(p["bob"]) + float(c.get("dip", 0.0)) * env
	if legs:
		_fix_feet(p)
	return p


## Nama animasi serang/skill khas karakter (dibuat sekali, lalu dipakai ulang). Bila karakter tak punya gaya, kembalikan nama dasar.
static func attack_variant(base: String, id: String) -> String:
	if not ATK.has(id):
		return base
	var defs := _defs()
	if not defs.has(base):
		return base
	var nm := base + "@" + id
	var lib := get_library()
	if not lib.has_animation(nm):
		var d: Array = defs[base]
		var c: Dictionary = ATK[id]
		var fn: Callable = d[2]
		var made := _make(_atk_len(base, id), false, func(u): return _atk_pose(fn.call(u), u, c, base))
		_polish_attack(made, base)
		lib.add_animation(nm, made)
	return nm


# =====================================================================
#  ULTI per jenis (ult_kind): animasi sendiri, bukan animasi skill biasa. Panjang = 1,7 dtk = kunci aksi pemain (Player.do_ult).
#  Fase: 1 PREPARATION (0-0,1..0,3) mengambil posisi khusus  2 CHARGING (0,3-0,35) mengumpulkan energi, tubuh/tangan/kepala/senjata ikut
#  3 EXECUTION+IMPACT (0,43) gerakan pelepasan, sinkron dengan serangan beruntun pertama (Stage._ult_cast menunggu 0,6 dtk = 0,35 animasi)
#  4 CHANNEL (0,56-0,8) pose bertahan khas jenis ULTI, berdenyut a <-> b selama serangan beruntun  5 RECOVERY (0,8-1,0) kembali ke siaga bertahap.
#  Dibuat lazy lewat ensure_ult(kind) supaya pustaka tidak membesar saat game dibuka.
# =====================================================================
const ULT_LEN := 1.7
const ULT_RELEASE := 0.37        # fraksi waktu pelepasan (impak): 0,37 x 1,7 = 0,63 dtk, tepat setelah jeda 0,6 dtk di Stage._ult_cast


## Lima pose kunci per ult_kind: prep, charge, release, a, b. (rotasi tulang dalam radian; x negatif pada lengan = ke depan/atas)
static func _ult_keys(kind: String) -> Dictionary:
	match kind:
		"sword_rain":        # Ren: pedang diacungkan ke langit, badan melengkung, lalu menebas turun; bertahan memerintah hujan pedang
			return {
				"prep": _pz({"upperarm_r": Vector3(-1.6, 0.1, -0.3), "forearm_r": Vector3(-0.8, 0, 0), "upperarm_l": Vector3(0.0, 0, 0.9), "spine": Vector3(-0.1, -0.2, 0), "thigh_l": Vector3(0.2, 0, 0.12), "thigh_r": Vector3(-0.15, 0, -0.12), "bob": -0.05}),
				"charge": _pz({"upperarm_r": Vector3(-2.9, 0.0, -0.2), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-0.3, 0, 1.2), "forearm_l": Vector3(-0.3, 0, 0), "spine": Vector3(-0.32, 0, 0), "chest": Vector3(-0.12, 0, 0), "head": Vector3(-0.4, 0, 0), "thigh_l": Vector3(0.05, 0, 0.12), "thigh_r": Vector3(-0.05, 0, -0.12), "bob": 0.1, "hz": -0.05}),
				"release": _pz({"upperarm_r": Vector3(-0.7, -0.35, 0.1), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(0.6, 0, 0.8), "spine": Vector3(0.6, 0.3, 0), "chest": Vector3(0.12, 0.12, 0), "head": Vector3(-0.4, -0.1, 0), "thigh_l": Vector3(-0.7, 0, 0.12), "thigh_r": Vector3(0.4, 0, -0.1), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.3, 0, 0), "bob": -0.2, "hz": 0.22}),
				"a": _pz({"upperarm_r": Vector3(-2.3, 0.1, -0.25), "forearm_r": Vector3(-0.5, 0, 0), "upperarm_l": Vector3(-0.5, 0, 1.1), "spine": Vector3(-0.15, 0, 0), "head": Vector3(-0.3, 0, 0), "thigh_l": Vector3(-0.2, 0, 0.12), "thigh_r": Vector3(0.1, 0, -0.12), "bob": -0.04, "hz": 0.1}),
				"b": _pz({"upperarm_r": Vector3(-1.7, 0.1, -0.25), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-0.2, 0, 1.0), "spine": Vector3(0.08, 0, 0), "head": Vector3(-0.1, 0, 0), "thigh_l": Vector3(-0.25, 0, 0.12), "thigh_r": Vector3(0.12, 0, -0.12), "bob": -0.08, "hz": 0.12})}
		"pillars":           # Vael: pedang tegak di depan dada, tangan terentang menerima cahaya, bumi ditekan pedang, berdoa
			return {
				"prep": _pz({"upperarm_r": Vector3(-1.0, 0.15, -0.2), "forearm_r": Vector3(-1.3, 0, 0), "upperarm_l": Vector3(-0.4, 0, 0.5), "forearm_l": Vector3(-0.6, 0, 0), "spine": Vector3(-0.05, 0, 0), "bob": 0.0}),
				"charge": _pz({"upperarm_r": Vector3(-1.1, 0.0, -1.3), "forearm_r": Vector3(-0.4, 0, 0), "upperarm_l": Vector3(-0.1, 0, 1.4), "forearm_l": Vector3(-0.2, 0, 0), "spine": Vector3(-0.22, 0, 0), "chest": Vector3(-0.1, 0, 0), "head": Vector3(-0.45, 0, 0), "bob": 0.14, "hz": -0.03}),
				"release": _pz({"upperarm_r": Vector3(-1.3, 0.0, -0.3), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-1.2, 0.0, 0.3), "forearm_l": Vector3(-0.4, 0, 0), "spine": Vector3(0.3, 0, 0), "head": Vector3(-0.1, 0, 0), "thigh_l": Vector3(-0.35, 0, 0.1), "thigh_r": Vector3(0.2, 0, -0.1), "shin_l": Vector3(0.3, 0, 0), "bob": -0.14, "hz": 0.12}),
				"a": _pz({"upperarm_r": Vector3(-1.15, 0.0, -0.15), "forearm_r": Vector3(-0.5, 0, 0), "upperarm_l": Vector3(-1.1, 0.0, 0.15), "forearm_l": Vector3(-0.5, 0, 0), "spine": Vector3(0.22, 0, 0), "head": Vector3(0.2, 0, 0), "thigh_l": Vector3(-0.3, 0, 0.1), "thigh_r": Vector3(0.15, 0, -0.1), "bob": -0.1, "hz": 0.1}),
				"b": _pz({"upperarm_r": Vector3(-1.2, 0.0, -0.15), "forearm_r": Vector3(-0.45, 0, 0), "upperarm_l": Vector3(-1.15, 0.0, 0.15), "forearm_l": Vector3(-0.45, 0, 0), "spine": Vector3(0.16, 0, 0), "head": Vector3(0.12, 0, 0), "thigh_l": Vector3(-0.3, 0, 0.1), "thigh_r": Vector3(0.15, 0, -0.1), "bob": -0.08, "hz": 0.1})}
		"inferno":           # Ember: meremas bola api di antara dua tangan sambil membungkuk, lalu melempar kedua tangan terbuka; menengadah menahan letusan
			return {
				"prep": _pz({"upperarm_r": Vector3(-0.9, 0.3, -0.3), "forearm_r": Vector3(-1.3, 0, 0), "upperarm_l": Vector3(-0.9, -0.3, 0.3), "forearm_l": Vector3(-1.3, 0, 0), "spine": Vector3(0.2, 0, 0), "head": Vector3(0.1, 0, 0), "bob": -0.06}),
				"charge": _pz({"upperarm_r": Vector3(-1.2, 0.4, -0.2), "forearm_r": Vector3(-1.8, 0, 0), "upperarm_l": Vector3(-1.2, -0.4, 0.2), "forearm_l": Vector3(-1.8, 0, 0), "spine": Vector3(0.4, 0, 0), "chest": Vector3(0.1, 0, 0), "head": Vector3(0.3, 0, 0), "thigh_l": Vector3(0.3, 0, 0.14), "thigh_r": Vector3(0.3, 0, -0.14), "shin_l": Vector3(0.6, 0, 0), "shin_r": Vector3(0.6, 0, 0), "bob": -0.18}),
				"release": _pz({"upperarm_r": Vector3(-1.9, 0.0, -1.4), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(-1.9, 0.0, 1.4), "forearm_l": Vector3(-0.1, 0, 0), "spine": Vector3(-0.45, 0, 0), "chest": Vector3(-0.15, 0, 0), "head": Vector3(-0.5, 0, 0), "thigh_l": Vector3(0.1, 0, 0.2), "thigh_r": Vector3(-0.1, 0, -0.2), "bob": 0.08, "hz": -0.08}),
				"a": _pz({"upperarm_r": Vector3(-2.5, 0.0, -0.6), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-2.5, 0.0, 0.6), "forearm_l": Vector3(-0.3, 0, 0), "spine": Vector3(-0.3, 0.05, 0), "head": Vector3(-0.5, 0, 0), "thigh_l": Vector3(0.1, 0, 0.2), "thigh_r": Vector3(-0.1, 0, -0.2), "bob": 0.05}),
				"b": _pz({"upperarm_r": Vector3(-2.3, 0.0, -0.8), "forearm_r": Vector3(-0.4, 0, 0), "upperarm_l": Vector3(-2.3, 0.0, 0.8), "forearm_l": Vector3(-0.4, 0, 0), "spine": Vector3(-0.22, -0.05, 0), "head": Vector3(-0.4, 0, 0), "thigh_l": Vector3(0.1, 0, 0.2), "thigh_r": Vector3(-0.1, 0, -0.2), "bob": 0.02})}
		"inferno_blue", "storm_blade":      # Hakuya (inferno_blue) / Kiriel (storm_blade: tangan terangkat memanggil petir ke genggaman): kuda-kuda iai hening, tebasan cabut ke atas diagonal, pedang teracung berapi biru
			return {
				"prep": _pz({"upperarm_r": Vector3(-0.65, 0.2, -0.2), "forearm_r": Vector3(-1.1, 0, 0), "upperarm_l": Vector3(-0.45, 0.0, 0.3), "forearm_l": Vector3(-1.15, 0, 0), "spine": Vector3(0.2, -0.25, 0), "thigh_l": Vector3(0.35, 0, 0.14), "thigh_r": Vector3(-0.25, 0, -0.14), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.5, 0, 0), "bob": -0.15}),
				"charge": _pz({"upperarm_r": Vector3(-0.7, 0.2, -0.2), "forearm_r": Vector3(-1.15, 0, 0), "upperarm_l": Vector3(-0.5, 0.0, 0.3), "forearm_l": Vector3(-1.2, 0, 0), "spine": Vector3(0.28, -0.4, 0), "chest": Vector3(0.05, -0.15, 0), "head": Vector3(0.08, 0.2, 0), "thigh_l": Vector3(0.45, 0, 0.16), "thigh_r": Vector3(-0.3, 0, -0.16), "shin_l": Vector3(0.6, 0, 0), "shin_r": Vector3(0.6, 0, 0), "bob": -0.2, "hz": -0.06}),
				"release": _pz({"upperarm_r": Vector3(-2.3, -0.5, 0.2), "forearm_r": Vector3(-0.2, 0, 0), "upperarm_l": Vector3(0.6, 0.0, 0.5), "forearm_l": Vector3(-1.0, 0, 0), "spine": Vector3(0.1, 0.8, 0), "chest": Vector3(-0.1, 0.35, 0), "head": Vector3(-0.35, -0.5, 0), "thigh_l": Vector3(-0.8, 0, 0.14), "thigh_r": Vector3(0.5, 0, -0.14), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.3, 0, 0), "bob": -0.16, "hz": 0.28}),
				"a": _pz({"upperarm_r": Vector3(-2.7, -0.2, -0.15), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-0.2, 0.0, 0.9), "forearm_l": Vector3(-0.4, 0, 0), "spine": Vector3(-0.1, 0.4, 0), "head": Vector3(-0.35, -0.2, 0), "thigh_l": Vector3(-0.35, 0, 0.14), "thigh_r": Vector3(0.2, 0, -0.14), "bob": -0.08, "hz": 0.14}),
				"b": _pz({"upperarm_r": Vector3(-2.5, 0.1, -0.2), "forearm_r": Vector3(-0.35, 0, 0), "upperarm_l": Vector3(-0.1, 0.0, 1.0), "forearm_l": Vector3(-0.4, 0, 0), "spine": Vector3(-0.05, -0.2, 0), "head": Vector3(-0.3, 0.2, 0), "thigh_l": Vector3(-0.35, 0, 0.14), "thigh_r": Vector3(0.2, 0, -0.14), "bob": -0.06, "hz": 0.14})}
		"shadow_dragon":     # Kuroha: pedang diseret ke belakang, tubuh memuntir rendah, lalu menebas melepas naga; pedang menunjuk ke depan
			return {
				"prep": _pz({"upperarm_r": Vector3(-0.7, -0.4, -0.8), "forearm_r": Vector3(-0.9, 0, 0), "upperarm_l": Vector3(0.4, 0, 0.5), "spine": Vector3(0.3, -0.5, 0), "chest": Vector3(0, -0.2, 0), "thigh_l": Vector3(0.4, 0, 0.14), "thigh_r": Vector3(-0.3, 0, -0.14), "shin_l": Vector3(0.6, 0, 0), "shin_r": Vector3(0.5, 0, 0), "bob": -0.16}),
				"charge": _pz({"upperarm_r": Vector3(0.2, -0.6, -1.3), "forearm_r": Vector3(-0.6, 0, 0), "upperarm_l": Vector3(0.9, 0, 0.7), "spine": Vector3(0.4, -1.1, 0), "chest": Vector3(0.05, -0.45, 0), "head": Vector3(0.0, 0.7, 0), "thigh_l": Vector3(0.5, 0, 0.16), "thigh_r": Vector3(-0.35, 0, -0.16), "shin_l": Vector3(0.8, 0, 0), "shin_r": Vector3(0.7, 0, 0), "bob": -0.26, "hz": -0.1}),
				"release": _pz({"upperarm_r": Vector3(-1.5, 0.8, 0.3), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(0.9, 0, 0.8), "spine": Vector3(0.7, 1.0, 0), "chest": Vector3(0.1, 0.4, 0), "head": Vector3(-0.5, -0.7, 0), "thigh_l": Vector3(-0.95, 0, 0.14), "thigh_r": Vector3(0.7, 0, -0.14), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.4, 0, 0), "bob": -0.24, "hz": 0.34}),
				"a": _pz({"upperarm_r": Vector3(-1.45, 0.3, 0.05), "forearm_r": Vector3(-0.15, 0, 0), "upperarm_l": Vector3(0.8, 0, 0.7), "spine": Vector3(0.55, 0.5, 0), "head": Vector3(-0.3, -0.35, 0), "thigh_l": Vector3(-0.8, 0, 0.14), "thigh_r": Vector3(0.6, 0, -0.14), "shin_l": Vector3(0.5, 0, 0), "bob": -0.22, "hz": 0.3}),
				"b": _pz({"upperarm_r": Vector3(-1.5, 0.2, 0.05), "forearm_r": Vector3(-0.2, 0, 0), "upperarm_l": Vector3(0.9, 0, 0.75), "spine": Vector3(0.6, 0.4, 0), "head": Vector3(-0.35, -0.3, 0), "thigh_l": Vector3(-0.8, 0, 0.14), "thigh_r": Vector3(0.6, 0, -0.14), "shin_l": Vector3(0.5, 0, 0), "bob": -0.25, "hz": 0.32})}
		"shadow_blades":     # Zeya: kedua belati disilangkan di dada, merunduk dalam, lalu terentang; menari memuntir bergantian ke dua sisi
			return {
				"prep": _pz({"upperarm_r": Vector3(-1.1, 0.5, 0.3), "forearm_r": Vector3(-1.2, 0, 0), "upperarm_l": Vector3(-1.1, -0.5, -0.3), "forearm_l": Vector3(-1.2, 0, 0), "spine": Vector3(0.3, 0, 0), "thigh_l": Vector3(0.35, 0, 0.12), "thigh_r": Vector3(-0.3, 0, -0.12), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.5, 0, 0), "bob": -0.14}),
				"charge": _pz({"upperarm_r": Vector3(-1.4, 0.8, 0.5), "forearm_r": Vector3(-1.5, 0, 0), "upperarm_l": Vector3(-1.4, -0.8, -0.5), "forearm_l": Vector3(-1.5, 0, 0), "spine": Vector3(0.5, 0, 0), "chest": Vector3(0.1, 0, 0), "head": Vector3(0.2, 0, 0), "thigh_l": Vector3(0.5, 0, 0.18), "thigh_r": Vector3(0.45, 0, -0.18), "shin_l": Vector3(0.9, 0, 0), "shin_r": Vector3(0.9, 0, 0), "bob": -0.28}),
				"release": _pz({"upperarm_r": Vector3(-0.3, 0.0, -1.5), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(-0.3, 0.0, 1.5), "forearm_l": Vector3(-0.1, 0, 0), "spine": Vector3(0.15, 1.0, 0), "chest": Vector3(0, 0.45, 0), "head": Vector3(0, -0.7, 0), "thigh_l": Vector3(-0.3, 0, 0.3), "thigh_r": Vector3(-0.3, 0, -0.3), "shin_l": Vector3(0.6, 0, 0), "shin_r": Vector3(0.6, 0, 0), "bob": -0.18}),
				"a": _pz({"upperarm_r": Vector3(-0.2, 0.0, -1.4), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(-0.2, 0.0, 1.4), "forearm_l": Vector3(-0.1, 0, 0), "spine": Vector3(0.15, -1.1, 0), "chest": Vector3(0, -0.5, 0), "head": Vector3(0, 0.8, 0), "thigh_l": Vector3(-0.3, 0, 0.3), "thigh_r": Vector3(-0.3, 0, -0.3), "shin_l": Vector3(0.6, 0, 0), "shin_r": Vector3(0.6, 0, 0), "bob": -0.16}),
				"b": _pz({"upperarm_r": Vector3(-0.2, 0.0, -1.4), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(-0.2, 0.0, 1.4), "forearm_l": Vector3(-0.1, 0, 0), "spine": Vector3(0.15, 1.1, 0), "chest": Vector3(0, 0.5, 0), "head": Vector3(0, -0.8, 0), "thigh_l": Vector3(-0.3, 0, 0.3), "thigh_r": Vector3(-0.3, 0, -0.3), "shin_l": Vector3(0.6, 0, 0), "shin_r": Vector3(0.6, 0, 0), "bob": -0.16})}
		"vortex_gate":       # Kyomu: bilah menunjuk ke bawah sambil merunduk, ditancapkan ke tanah di depan, bertahan berlutut mengendalikan portal
			return {
				"prep": _pz({"upperarm_r": Vector3(-0.5, 0.2, -0.4), "forearm_r": Vector3(-0.6, 0, 0), "upperarm_l": Vector3(-0.5, -0.2, 0.4), "forearm_l": Vector3(-0.6, 0, 0), "spine": Vector3(0.4, 0, 0), "head": Vector3(0.1, 0, 0), "thigh_l": Vector3(0.4, 0, 0.14), "thigh_r": Vector3(-0.3, 0, -0.14), "shin_l": Vector3(0.6, 0, 0), "shin_r": Vector3(0.6, 0, 0), "bob": -0.16}),
				"charge": _pz({"upperarm_r": Vector3(-0.2, 0.3, -0.7), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-0.2, -0.3, 0.7), "forearm_l": Vector3(-0.3, 0, 0), "spine": Vector3(0.65, 0, 0), "chest": Vector3(0.12, 0, 0), "head": Vector3(0.3, 0, 0), "thigh_l": Vector3(0.55, 0, 0.18), "thigh_r": Vector3(0.45, 0, -0.18), "shin_l": Vector3(1.0, 0, 0), "shin_r": Vector3(0.95, 0, 0), "bob": -0.3}),
				"release": _pz({"upperarm_r": Vector3(-1.0, 0.1, -0.35), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(-1.0, -0.1, 0.35), "forearm_l": Vector3(-0.1, 0, 0), "spine": Vector3(0.85, 0, 0), "chest": Vector3(0.1, 0, 0), "head": Vector3(-0.3, 0, 0), "thigh_l": Vector3(-0.7, 0, 0.16), "thigh_r": Vector3(0.45, 0, -0.16), "shin_l": Vector3(0.8, 0, 0), "shin_r": Vector3(0.9, 0, 0), "bob": -0.32, "hz": 0.2}),
				"a": _pz({"upperarm_r": Vector3(-0.95, 0.1, -0.3), "forearm_r": Vector3(-0.15, 0, 0), "upperarm_l": Vector3(-0.95, -0.1, 0.3), "forearm_l": Vector3(-0.15, 0, 0), "spine": Vector3(0.8, 0, 0.04), "head": Vector3(-0.35, 0, 0), "thigh_l": Vector3(-0.7, 0, 0.16), "thigh_r": Vector3(0.45, 0, -0.16), "shin_l": Vector3(0.8, 0, 0), "shin_r": Vector3(0.9, 0, 0), "bob": -0.33, "hz": 0.2}),
				"b": _pz({"upperarm_r": Vector3(-1.0, 0.1, -0.3), "forearm_r": Vector3(-0.15, 0, 0), "upperarm_l": Vector3(-1.0, -0.1, 0.3), "forearm_l": Vector3(-0.15, 0, 0), "spine": Vector3(0.84, 0, -0.04), "head": Vector3(-0.3, 0, 0), "thigh_l": Vector3(-0.7, 0, 0.16), "thigh_r": Vector3(0.45, 0, -0.16), "shin_l": Vector3(0.8, 0, 0), "shin_r": Vector3(0.9, 0, 0), "bob": -0.31, "hz": 0.2})}
		"symphony":          # Wenyu: seruling di bibir, badan meliuk mengikuti irama, tangan menyapu lebar seperti dirigen saat melepas, lalu meliuk bergantian
			return {
				"prep": _pz({"upperarm_r": Vector3(-1.25, 0.35, -0.45), "forearm_r": Vector3(-1.95, 0, 0), "upperarm_l": Vector3(-1.15, -0.2, 0.55), "forearm_l": Vector3(-1.85, 0, 0), "head": Vector3(0.1, 0, 0.08), "spine": Vector3(0, 0, 0.05)}),
				"charge": _pz({"upperarm_r": Vector3(-1.3, 0.35, -0.45), "forearm_r": Vector3(-1.95, 0, 0), "upperarm_l": Vector3(-1.2, -0.2, 0.55), "forearm_l": Vector3(-1.85, 0, 0), "spine": Vector3(-0.12, 0, 0.18), "chest": Vector3(-0.05, 0, 0.08), "head": Vector3(-0.2, 0, 0.15), "thigh_l": Vector3(0.05, 0, 0.12), "thigh_r": Vector3(-0.05, 0, -0.12), "bob": 0.06}),
				"release": _pz({"upperarm_r": Vector3(-1.4, 0.0, -1.5), "forearm_r": Vector3(-0.5, 0, 0), "upperarm_l": Vector3(-1.4, 0.0, 1.5), "forearm_l": Vector3(-0.5, 0, 0), "spine": Vector3(-0.2, 0, 0), "chest": Vector3(-0.1, 0, 0), "head": Vector3(-0.35, 0, 0), "thigh_l": Vector3(0.05, 0, 0.14), "thigh_r": Vector3(-0.05, 0, -0.14), "bob": 0.1}),
				"a": _pz({"upperarm_r": Vector3(-1.25, 0.35, -0.45), "forearm_r": Vector3(-1.95, 0, 0), "upperarm_l": Vector3(-1.15, -0.2, 0.55), "forearm_l": Vector3(-1.85, 0, 0), "spine": Vector3(0.0, 0.15, 0.25), "chest": Vector3(0, 0.1, 0.1), "head": Vector3(0.1, 0.1, 0.2), "thigh_l": Vector3(0.1, 0, 0.16), "thigh_r": Vector3(-0.15, 0, -0.1), "hips": Vector3(0, 0.1, 0.1), "bob": 0.0}),
				"b": _pz({"upperarm_r": Vector3(-1.25, 0.35, -0.45), "forearm_r": Vector3(-1.95, 0, 0), "upperarm_l": Vector3(-1.15, -0.2, 0.55), "forearm_l": Vector3(-1.85, 0, 0), "spine": Vector3(0.0, -0.15, -0.25), "chest": Vector3(0, -0.1, -0.1), "head": Vector3(0.1, -0.1, -0.2), "thigh_l": Vector3(0.15, 0, 0.1), "thigh_r": Vector3(-0.1, 0, -0.16), "hips": Vector3(0, -0.1, -0.1), "bob": 0.0})}
		"starfall":          # Sera: busur diarahkan ke langit, tali ditarik penuh sambil melengkung ke belakang, melepas ke atas; menembak ke atas berulang
			return {
				"prep": _pz({"upperarm_l": Vector3(-1.5, -0.1, 0.1), "forearm_l": Vector3(-0.1, 0, 0), "upperarm_r": Vector3(-1.3, 0.4, -0.5), "forearm_r": Vector3(-1.6, 0, 0), "spine": Vector3(0, 0.4, 0), "head": Vector3(-0.1, -0.4, 0), "thigh_l": Vector3(0.1, 0, 0.14), "thigh_r": Vector3(-0.1, 0, -0.14)}, false),
				"charge": _pz({"upperarm_l": Vector3(-2.7, -0.1, 0.1), "forearm_l": Vector3(-0.1, 0, 0), "upperarm_r": Vector3(-2.3, 0.5, -0.8), "forearm_r": Vector3(-2.0, 0, 0), "spine": Vector3(-0.38, 0.3, 0), "chest": Vector3(-0.12, 0.1, 0), "head": Vector3(-0.6, -0.3, 0), "thigh_l": Vector3(0.15, 0, 0.14), "thigh_r": Vector3(-0.15, 0, -0.14), "bob": -0.05, "hz": -0.06}, false),
				"release": _pz({"upperarm_l": Vector3(-2.8, -0.1, 0.1), "forearm_l": Vector3(-0.1, 0, 0), "upperarm_r": Vector3(-2.0, 0.2, -1.2), "forearm_r": Vector3(-0.4, 0, 0), "spine": Vector3(-0.3, 0.25, 0), "chest": Vector3(-0.1, 0.1, 0), "head": Vector3(-0.6, -0.25, 0), "thigh_l": Vector3(0.1, 0, 0.14), "thigh_r": Vector3(-0.25, 0, -0.14), "shin_r": Vector3(0.3, 0, 0), "bob": 0.0, "hz": -0.16}, false),
				"a": _pz({"upperarm_l": Vector3(-2.75, -0.1, 0.1), "forearm_l": Vector3(-0.1, 0, 0), "upperarm_r": Vector3(-2.3, 0.45, -0.8), "forearm_r": Vector3(-1.9, 0, 0), "spine": Vector3(-0.35, 0.28, 0), "head": Vector3(-0.55, -0.28, 0), "thigh_l": Vector3(0.15, 0, 0.14), "thigh_r": Vector3(-0.15, 0, -0.14), "hz": -0.05}, false),
				"b": _pz({"upperarm_l": Vector3(-2.8, -0.1, 0.1), "forearm_l": Vector3(-0.1, 0, 0), "upperarm_r": Vector3(-2.0, 0.2, -1.2), "forearm_r": Vector3(-0.4, 0, 0), "spine": Vector3(-0.3, 0.25, 0), "head": Vector3(-0.6, -0.25, 0), "thigh_l": Vector3(0.1, 0, 0.14), "thigh_r": Vector3(-0.2, 0, -0.14), "hz": -0.14}, false)}
		"void_requiem":      # Zyrax: tangan kanan menjulang ke langit memanggil lubang hitam, tangan kiri menekan ke bawah; lalu kedua tangan dihentak ke depan-bawah (detonator), berdiri membentang menerima sayap
			return {
				"prep": _pz({"upperarm_r": Vector3(-0.6, 0.2, -0.5), "forearm_r": Vector3(-1.4, 0, 0), "upperarm_l": Vector3(-0.3, 0.0, 0.4), "forearm_l": Vector3(-0.5, 0, 0), "spine": Vector3(0.18, 0, 0), "head": Vector3(0.05, 0, 0), "bob": -0.03}),
				"charge": _pz({"upperarm_r": Vector3(-3.0, 0.0, -0.3), "forearm_r": Vector3(-0.2, 0, 0), "upperarm_l": Vector3(0.45, 0.0, 0.9), "forearm_l": Vector3(-0.3, 0, 0), "spine": Vector3(-0.3, 0, 0), "chest": Vector3(-0.12, 0, 0), "head": Vector3(-0.4, 0, 0), "thigh_l": Vector3(0.05, 0, 0.14), "thigh_r": Vector3(-0.05, 0, -0.14), "bob": 0.05}),
				"release": _pz({"upperarm_r": Vector3(-1.0, 0.0, -0.2), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(-1.0, 0.0, 0.2), "forearm_l": Vector3(-0.1, 0, 0), "spine": Vector3(0.5, 0, 0), "chest": Vector3(0.1, 0, 0), "head": Vector3(0.1, 0, 0), "thigh_l": Vector3(0.25, 0, 0.1), "thigh_r": Vector3(-0.15, 0, -0.1), "bob": -0.08}),
				"a": _pz({"upperarm_r": Vector3(-0.4, 0.0, -1.4), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-0.4, 0.0, 1.4), "forearm_l": Vector3(-0.3, 0, 0), "spine": Vector3(-0.2, 0, 0.04), "head": Vector3(-0.4, 0, 0), "bob": 0.04}),
				"b": _pz({"upperarm_r": Vector3(-0.5, 0.0, -1.3), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-0.5, 0.0, 1.3), "forearm_l": Vector3(-0.3, 0, 0), "spine": Vector3(-0.15, 0, -0.04), "head": Vector3(-0.3, 0, 0), "bob": 0.03}),
			}
		"quake":             # Brann: jongkok dalam, palu setinggi mungkin, banting menghancurkan tanah, menekan sambil bergetar
			return {
				"prep": _pz({"upperarm_r": Vector3(-1.0, 0.5, -0.5), "forearm_r": Vector3(-0.8, 0, 0), "upperarm_l": Vector3(-0.9, 0.4, 0.1), "forearm_l": Vector3(-0.8, 0, 0), "spine": Vector3(0, -0.3, 0), "thigh_l": Vector3(0.35, 0, 0.2), "thigh_r": Vector3(-0.2, 0, -0.2), "shin_l": Vector3(0.6, 0, 0), "shin_r": Vector3(0.45, 0, 0), "bob": -0.18}),
				"charge": _pz({"upperarm_r": Vector3(-3.25, 0.1, -0.2), "forearm_r": Vector3(-0.7, 0, 0), "upperarm_l": Vector3(-3.05, -0.1, 0.25), "forearm_l": Vector3(-0.7, 0, 0), "spine": Vector3(-0.55, 0, 0), "chest": Vector3(-0.2, 0, 0), "head": Vector3(0.4, 0, 0), "thigh_l": Vector3(0.05, 0, 0.2), "thigh_r": Vector3(-0.05, 0, -0.2), "bob": 0.09, "hz": -0.12}),
				"release": _pz({"upperarm_r": Vector3(-0.4, 0.1, -0.2), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(-0.38, -0.1, 0.25), "forearm_l": Vector3(-0.1, 0, 0), "spine": Vector3(1.2, 0, 0), "chest": Vector3(0.14, 0, 0), "head": Vector3(-0.75, 0, 0), "thigh_l": Vector3(-0.65, 0, 0.18), "thigh_r": Vector3(0.25, 0, -0.18), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.8, 0, 0), "bob": -0.3, "hz": 0.22}),
				"a": _pz({"upperarm_r": Vector3(-0.45, 0.1, -0.2), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(-0.42, -0.1, 0.25), "forearm_l": Vector3(-0.1, 0, 0), "spine": Vector3(1.15, 0, 0.05), "head": Vector3(-0.7, 0, 0), "thigh_l": Vector3(-0.65, 0, 0.18), "thigh_r": Vector3(0.25, 0, -0.18), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.8, 0, 0), "bob": -0.32, "hz": 0.22}),
				"b": _pz({"upperarm_r": Vector3(-0.45, 0.1, -0.2), "forearm_r": Vector3(-0.1, 0, 0), "upperarm_l": Vector3(-0.42, -0.1, 0.25), "forearm_l": Vector3(-0.1, 0, 0), "spine": Vector3(1.1, 0, -0.05), "head": Vector3(-0.65, 0, 0), "thigh_l": Vector3(-0.65, 0, 0.18), "thigh_r": Vector3(0.25, 0, -0.18), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.8, 0, 0), "bob": -0.29, "hz": 0.22})}
		"sigil_gold":        # Lucien: tongkat menapak tegak, tangan kiri menggambar lingkaran perhitungan di udara, tongkat dihentakkan, melukis presisi
			return {
				"prep": _pz({"upperarm_r": Vector3(-0.35, 0.0, -0.15), "forearm_r": Vector3(-0.45, 0, 0), "upperarm_l": Vector3(-0.6, 0.0, 0.4), "forearm_l": Vector3(-0.8, 0, 0), "spine": Vector3(-0.04, 0, 0), "head": Vector3(0, 0.1, 0)}),
				"charge": _pz({"upperarm_r": Vector3(-0.45, 0.0, -0.15), "forearm_r": Vector3(-0.5, 0, 0), "upperarm_l": Vector3(-1.55, 0.3, 0.5), "forearm_l": Vector3(-0.3, 0, 0), "hand_l": Vector3(-0.3, 0, 0), "spine": Vector3(-0.06, 0.2, 0), "chest": Vector3(0, 0.1, 0), "head": Vector3(-0.1, 0.2, 0.05), "thigh_l": Vector3(0.1, 0, 0.1), "thigh_r": Vector3(-0.1, 0, -0.1)}),
				"release": _pz({"upperarm_r": Vector3(-1.2, 0.0, -0.2), "forearm_r": Vector3(-0.2, 0, 0), "upperarm_l": Vector3(-1.6, -0.2, 0.3), "forearm_l": Vector3(-0.2, 0, 0), "spine": Vector3(0.2, 0, 0), "head": Vector3(-0.05, 0, 0), "thigh_l": Vector3(-0.35, 0, 0.1), "thigh_r": Vector3(0.2, 0, -0.1), "shin_l": Vector3(0.3, 0, 0), "bob": -0.1, "hz": 0.1}),
				"a": _pz({"upperarm_r": Vector3(-0.45, 0.0, -0.15), "forearm_r": Vector3(-0.5, 0, 0), "upperarm_l": Vector3(-1.6, 0.55, 0.4), "forearm_l": Vector3(-0.3, 0, 0), "hand_l": Vector3(-0.2, 0, 0), "spine": Vector3(-0.05, 0.15, 0), "head": Vector3(-0.1, 0.15, 0), "thigh_l": Vector3(0.1, 0, 0.1), "thigh_r": Vector3(-0.1, 0, -0.1)}),
				"b": _pz({"upperarm_r": Vector3(-0.45, 0.0, -0.15), "forearm_r": Vector3(-0.5, 0, 0), "upperarm_l": Vector3(-1.6, -0.5, 0.3), "forearm_l": Vector3(-0.3, 0, 0), "hand_l": Vector3(-0.2, 0, 0), "spine": Vector3(-0.05, 0.25, 0), "head": Vector3(-0.1, 0.25, 0), "thigh_l": Vector3(0.1, 0, 0.1), "thigh_r": Vector3(-0.1, 0, -0.1)})}
		"chrono":            # Aion: satu telapak terbuka menahan waktu, dua tangan dirapatkan lalu menolak keluar, melebar perlahan seperti waktu membeku
			return {
				"prep": _pz({"upperarm_r": Vector3(-0.6, 0.0, -0.2), "forearm_r": Vector3(-0.8, 0, 0), "upperarm_l": Vector3(-0.7, 0.0, 0.45), "forearm_l": Vector3(-0.9, 0, 0), "hand_l": Vector3(-0.4, 0, 0), "head": Vector3(-0.04, 0.05, 0)}),
				"charge": _pz({"upperarm_r": Vector3(-1.1, 0.0, -0.3), "forearm_r": Vector3(-1.2, 0, 0), "upperarm_l": Vector3(-1.1, 0.0, 0.3), "forearm_l": Vector3(-1.3, 0, 0), "hand_l": Vector3(-0.5, 0, 0), "spine": Vector3(-0.05, 0, 0), "head": Vector3(-0.15, 0, 0), "thigh_l": Vector3(0.1, 0, 0.1), "thigh_r": Vector3(-0.1, 0, -0.1), "bob": 0.03}),
				"release": _pz({"upperarm_r": Vector3(-1.6, 0.0, -0.9), "forearm_r": Vector3(-0.2, 0, 0), "upperarm_l": Vector3(-1.6, 0.0, 0.9), "forearm_l": Vector3(-0.2, 0, 0), "hand_l": Vector3(-0.7, 0, 0), "spine": Vector3(0.1, 0, 0), "head": Vector3(-0.1, 0, 0), "thigh_l": Vector3(-0.3, 0, 0.12), "thigh_r": Vector3(0.15, 0, -0.1), "bob": -0.06, "hz": 0.1}),
				"a": _pz({"upperarm_r": Vector3(-1.5, 0.0, -1.1), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-1.5, 0.0, 1.1), "forearm_l": Vector3(-0.3, 0, 0), "hand_l": Vector3(-0.6, 0, 0), "spine": Vector3(-0.08, 0, 0), "head": Vector3(-0.25, 0, 0), "thigh_l": Vector3(-0.1, 0, 0.14), "thigh_r": Vector3(0.05, 0, -0.14), "bob": 0.02}),
				"b": _pz({"upperarm_r": Vector3(-1.55, 0.0, -1.2), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-1.55, 0.0, 1.2), "forearm_l": Vector3(-0.3, 0, 0), "hand_l": Vector3(-0.7, 0, 0), "spine": Vector3(-0.1, 0, 0), "head": Vector3(-0.3, 0, 0), "thigh_l": Vector3(-0.1, 0, 0.14), "thigh_r": Vector3(0.05, 0, -0.14), "bob": 0.04})}
	# "sigil" (Lyra) dan jenis lain: penyihir melayang, tongkat dua tangan di atas kepala, lalu ayunan melingkar; tangan terentang melayang
	return {
		"prep": _pz({"upperarm_r": Vector3(-1.0, 0.0, -0.25), "forearm_r": Vector3(-1.0, 0, 0), "upperarm_l": Vector3(-0.9, 0.0, 0.35), "forearm_l": Vector3(-0.9, 0, 0), "head": Vector3(-0.1, 0, 0), "bob": 0.04}),
		"charge": _pz({"upperarm_r": Vector3(-3.0, 0.0, -0.25), "forearm_r": Vector3(-0.35, 0, 0), "upperarm_l": Vector3(-2.85, 0.0, 0.35), "forearm_l": Vector3(-0.3, 0, 0), "spine": Vector3(-0.28, 0, 0), "chest": Vector3(-0.1, 0, 0), "head": Vector3(-0.45, 0, 0), "thigh_l": Vector3(0.05, 0, 0.1), "thigh_r": Vector3(-0.05, 0, -0.1), "bob": 0.18, "hz": -0.03}),
		"release": _pz({"upperarm_r": Vector3(-1.2, 0.0, -0.3), "forearm_r": Vector3(-0.5, 0, 0), "upperarm_l": Vector3(-1.1, 0.0, 0.35), "forearm_l": Vector3(-0.3, 0, 0), "spine": Vector3(0.4, 0, 0), "head": Vector3(0.1, 0, 0), "thigh_l": Vector3(-0.3, 0, 0.12), "thigh_r": Vector3(0.2, 0, -0.1), "bob": 0.0, "hz": 0.08}),
		"a": _pz({"upperarm_r": Vector3(-0.8, 0.0, -1.3), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-0.8, 0.0, 1.3), "forearm_l": Vector3(-0.3, 0, 0), "spine": Vector3(-0.12, 0, 0), "head": Vector3(-0.35, 0, 0), "thigh_l": Vector3(0.0, 0, 0.1), "thigh_r": Vector3(0.0, 0, -0.1), "bob": 0.16}),
		"b": _pz({"upperarm_r": Vector3(-0.9, 0.0, -1.2), "forearm_r": Vector3(-0.35, 0, 0), "upperarm_l": Vector3(-0.9, 0.0, 1.2), "forearm_l": Vector3(-0.35, 0, 0), "spine": Vector3(-0.08, 0, 0), "head": Vector3(-0.3, 0, 0), "thigh_l": Vector3(0.0, 0, 0.1), "thigh_r": Vector3(0.0, 0, -0.1), "bob": 0.12})}


static func _p_ult(u: float, kind: String) -> Dictionary:
	var k := _ult_keys(kind)
	var ready := _pz({}, kind != "starfall")
	return _seq(u, [[0.0, ready, ""], [0.1, k["prep"], "io"], [0.3, k["charge"], "io"], [0.35, k["charge"], ""], [ULT_RELEASE + 0.06, k["release"], "back"],
		[0.56, k["a"], "io"], [0.68, k["b"], "io"], [0.8, k["a"], "io"], [0.9, _mix(k["a"], ready, 0.55), "io"], [1.0, ready, "io"]])


## Buat (sekali) animasi ULTI untuk ult_kind. Nama animasi: "ult_" + kind.
static func ensure_ult(kind: String) -> String:
	var nm := "ult_" + kind
	var lib := get_library()
	if not lib.has_animation(nm):
		lib.add_animation(nm, _make(ULT_LEN, false, func(u): return _p_ult(u, kind)))
	return nm


# =====================================================================
#  Pose musuh humanoid / boss (dipakai HumanoidEnemy lewat CharacterRig.play_pose)
#  enemy_wind_*  : kuda-kuda persiapan serangan panjang. Naik dalam ~0,25 dtk lalu ditahan dengan gemetar (tidak berulang).
#                  sword = menarik pedang ke belakang & merunduk; staff = tongkat diangkat, badan menengadah; heavy = bos: senjata
#                  diangkat tinggi dua tangan, badan melengkung, kuda-kuda lebar dan berat.
#  enemy_winded  : terengah setelah menyeruduk (celah untuk membalas): membungkuk, napas naik-turun.
#  enemy_roar    : raungan perubahan fase: kepala mendongak, tangan terentang, dada membusung, gemetar.
# =====================================================================
static func _p_enemy_wind(u: float, kind: String) -> Dictionary:
	var ready := _pz({})
	var hold: Dictionary
	match kind:
		"staff":
			hold = _pz({"upperarm_r": Vector3(-2.35, 0.0, -0.3), "forearm_r": Vector3(-0.5, 0, 0), "upperarm_l": Vector3(-1.9, 0.0, 0.5), "forearm_l": Vector3(-0.6, 0, 0),
				"spine": Vector3(-0.26, 0, 0), "chest": Vector3(-0.1, 0, 0), "head": Vector3(-0.35, 0, 0), "thigh_l": Vector3(0.05, 0, 0.1), "thigh_r": Vector3(-0.05, 0, -0.1), "bob": 0.07})
		"heavy":
			hold = _pz({"upperarm_r": Vector3(-2.7, 0.2, -0.3), "forearm_r": Vector3(-0.5, 0, 0), "upperarm_l": Vector3(-0.6, 0.0, 1.1), "forearm_l": Vector3(-0.4, 0, 0),
				"spine": Vector3(-0.42, -0.3, 0), "chest": Vector3(-0.15, -0.12, 0), "head": Vector3(0.2, 0.1, 0), "thigh_l": Vector3(0.2, 0, 0.26), "thigh_r": Vector3(-0.1, 0, -0.26),
				"shin_l": Vector3(0.35, 0, 0), "shin_r": Vector3(0.35, 0, 0), "bob": -0.1})
		_:
			hold = _pz({"upperarm_r": Vector3(-0.7, -0.5, -0.9), "forearm_r": Vector3(-0.9, 0, 0), "upperarm_l": Vector3(0.5, 0, 0.5), "forearm_l": Vector3(-0.6, 0, 0),
				"spine": Vector3(0.3, -0.6, 0), "chest": Vector3(0.05, -0.22, 0), "head": Vector3(0.0, 0.35, 0), "thigh_l": Vector3(0.4, 0, 0.14), "thigh_r": Vector3(-0.3, 0, -0.14),
				"shin_l": Vector3(0.6, 0, 0), "shin_r": Vector3(0.5, 0, 0), "bob": -0.14})
	var p := _seq(u, [[0.0, ready, ""], [0.12, hold, "io"], [1.0, hold, ""]])
	var trem := _sstep(0.12, 0.3, u)                              # gemetar menahan tenaga setelah pose tercapai
	var t := u * 2.0 * 60.0
	var sp: Vector3 = p["spine"]
	p["spine"] = sp + Vector3(0.0, 0.0, sin(t) * 0.025 * trem)
	var ua: Vector3 = p["upperarm_r"]
	p["upperarm_r"] = ua + Vector3(sin(t * 1.3) * 0.03 * trem, 0.0, 0.0)
	return p


static func _p_enemy_winded(u: float) -> Dictionary:
	var ready := _pz({})
	var tired := _pz({"upperarm_r": Vector3(-0.35, 0.0, -0.15), "forearm_r": Vector3(-0.3, 0, 0), "upperarm_l": Vector3(-0.35, 0.0, 0.15), "forearm_l": Vector3(-0.3, 0, 0),
		"spine": Vector3(0.72, 0, 0), "chest": Vector3(0.12, 0, 0), "head": Vector3(-0.3, 0, 0), "thigh_l": Vector3(0.3, 0, 0.14), "thigh_r": Vector3(0.3, 0, -0.14),
		"shin_l": Vector3(0.55, 0, 0), "shin_r": Vector3(0.55, 0, 0), "bob": -0.15})
	var p := _seq(u, [[0.0, ready, ""], [0.14, tired, "io"], [0.8, tired, ""], [1.0, ready, "io"]])
	var br := sin(u * 7.0 * TAU * 0.5) * 0.05 * _sstep(0.1, 0.25, u) * (1.0 - _sstep(0.8, 1.0, u))     # napas berat
	var sp: Vector3 = p["spine"]
	p["spine"] = sp + Vector3(br, 0.0, 0.0)
	var ch: Vector3 = p["chest"]
	p["chest"] = ch + Vector3(br * 0.8, 0.0, 0.0)
	return p


static func _p_enemy_roar(u: float) -> Dictionary:
	var ready := _pz({})
	var lean := _pz({"spine": Vector3(0.3, 0, 0), "head": Vector3(0.2, 0, 0), "upperarm_r": Vector3(-0.5, 0, -0.5), "upperarm_l": Vector3(-0.5, 0, 0.5),
		"thigh_l": Vector3(0.3, 0, 0.2), "thigh_r": Vector3(0.3, 0, -0.2), "shin_l": Vector3(0.5, 0, 0), "shin_r": Vector3(0.5, 0, 0), "bob": -0.16})
	var roar := _pz({"upperarm_r": Vector3(-0.6, 0.0, -1.55), "forearm_r": Vector3(-0.2, 0, 0), "upperarm_l": Vector3(-0.6, 0.0, 1.55), "forearm_l": Vector3(-0.2, 0, 0),
		"spine": Vector3(-0.5, 0, 0), "chest": Vector3(-0.2, 0, 0), "head": Vector3(-0.65, 0, 0), "thigh_l": Vector3(0.05, 0, 0.26), "thigh_r": Vector3(-0.05, 0, -0.26), "bob": 0.04, "hz": -0.06})
	var p := _seq(u, [[0.0, ready, ""], [0.18, lean, "io"], [0.34, roar, "back"], [0.78, roar, ""], [1.0, ready, "io"]])
	var trem := _sstep(0.3, 0.4, u) * (1.0 - _sstep(0.74, 0.86, u))
	var sp: Vector3 = p["spine"]
	p["spine"] = sp + Vector3(0.0, 0.0, sin(u * 90.0) * 0.04 * trem)
	return p



# =====================================================================
#  ANTI-TEMBUS SENJATA (fit): setiap animasi pemain diperiksa terhadap bentuk badan & kepala; bila senjata menembus,
#  bahu/pergelangan digeser keluar secukupnya, lalu koreksi dihaluskan antar-frame supaya tidak patah.
#  Dijalankan sekali per karakter saat set_style (hasil di-cache di pustaka); animasi yang sudah bersih tidak disentuh.
#  Bentuk badan: elipsoid pinggul->leher (setengah lebar 0,30 x tebal 0,17, satuan model) + elipsoid kepala (0,34 / 0,36 / 0,33),
#  diukur dari mesh hero.glb. Nama hasil: "<dasar>#<id>" untuk animasi bersama (dodge, ult_*), atau diganti di tempat untuk varian "@id".
# =====================================================================
const FIT_MODEL_SCALE := 1.8 / 2.43
const FIT_EPS := 0.004            # tembus yang masih diterima (meter)
const FIT_MARGIN := 1.2          # badan "digemukkan" 12% agar ada celah visual
const FIT_SKIP_HAND := 0.26       # titik senjata dekat tangan (m) tidak dihitung: itu genggamannya
const FIT_OFFS := {               # offset lokal tulang (hero.glb)
	"spine": Vector3(0, 0.31501, 0), "chest": Vector3(0, 0.05496, 0), "head": Vector3(0, 0.54734, 0),
	"ua_r": Vector3(-0.41738, 0.25426, 0.00189), "ua_l": Vector3(0.38929, 0.27130, 0.00189),
	"fa_r": Vector3(0, -0.25485, 0), "fa_l": Vector3(0, -0.27242, 0), "hand": Vector3(0, -0.37788, 0),
}
const FIT_NAMES := ["root", "hips", "spine", "chest", "head", "upperarm_l", "forearm_l", "hand_l", "upperarm_r", "forearm_r", "hand_r"]
static var _fit_done := {}
static var _fit_w_cache := {}


const FIT_WEAPONS := {
	"ren": {
		"r": [Vector3(-0.15, 0.07, 0.02), Vector3(0.15, 0.12, 0.02), Vector3(0.15, 0.07, 0.02), Vector3(-0.15, 0.12, 0.02), Vector3(0, -0.16, 0), Vector3(0, 0.04, 0), Vector3(0, 0.24, 0), Vector3(0, 0.44, 0), Vector3(0, 0.64, 0), Vector3(0, 0.84, 0), Vector3(0, 1.04, 0), Vector3(0, 1.12, 0)],
	},
	"lyra": {
		"r": [Vector3(0.07, 1.22, 0), Vector3(0.05, 1.3, 0.1), Vector3(0.11, 1.3, 0), Vector3(-0.05, 1.3, 0.1), Vector3(-0.11, 1.3, 0), Vector3(-0.07, 1.22, 0), Vector3(-0.05, 1.3, -0.1), Vector3(0.05, 1.3, -0.1), Vector3(0.05, 1.32, 0.09), Vector3(-0.05, 1.32, 0.09), Vector3(-0.05, 1.32, -0.09), Vector3(0.05, 1.32, -0.09), Vector3(-0.11, 1.25, 0.01), Vector3(0.11, 1.27, 0.01), Vector3(-0.01, 1.25, 0.11), Vector3(0.01, 1.25, -0.11), Vector3(0, -0.3, 0), Vector3(0, -0.1, 0), Vector3(0, 0.1, 0), Vector3(0, 0.3, 0), Vector3(0, 0.5, 0), Vector3(0, 0.7, 0), Vector3(0, 0.9, 0), Vector3(0, 1.1, 0), Vector3(0, 1.3, 0), Vector3(0, 1.5, 0), Vector3(0, 1.62, 0)],
	},
	"brann": {
		"r": [Vector3(-0.23, 0.75, 0.15), Vector3(0.23, 1.05, 0.15), Vector3(0.23, 0.75, 0.15), Vector3(-0.23, 1.05, 0.15), Vector3(0.23, 0.75, -0.15), Vector3(-0.23, 1.05, -0.15), Vector3(-0.23, 0.75, -0.15), Vector3(0.23, 1.05, -0.15), Vector3(-0.25, 0.85, 0.16), Vector3(0.25, 0.94, 0.16), Vector3(0.25, 0.85, 0.16), Vector3(-0.25, 0.94, 0.16), Vector3(0.25, 0.85, -0.16), Vector3(-0.25, 0.94, -0.16), Vector3(-0.25, 0.85, -0.16), Vector3(0.25, 0.94, -0.16), Vector3(0, -0.16, 0), Vector3(0, 0.04, 0), Vector3(0, 0.24, 0), Vector3(0, 0.44, 0), Vector3(0, 0.64, 0), Vector3(0, 0.84, 0), Vector3(0, 1.04, 0), Vector3(0, 1.05, 0)],
		"l": [Vector3(0.18, -0.24, 0.1), Vector3(0.23, -0.19, 0.27), Vector3(0.23, -0.24, 0.1), Vector3(0.18, -0.19, 0.27), Vector3(0.23, -0.07, 0.39), Vector3(0.18, -0.07, 0.39), Vector3(0.23, 0.1, 0.44), Vector3(0.18, 0.1, 0.44), Vector3(0.23, 0.27, 0.39), Vector3(0.18, 0.27, 0.39), Vector3(0.23, 0.39, 0.27), Vector3(0.18, 0.39, 0.27), Vector3(0.23, 0.44, 0.1), Vector3(0.18, 0.44, 0.1), Vector3(0.23, 0.39, -0.07), Vector3(0.18, 0.39, -0.07), Vector3(0.23, 0.27, -0.19), Vector3(0.18, 0.27, -0.19), Vector3(0.23, 0.1, -0.24), Vector3(0.18, 0.1, -0.24), Vector3(0.23, -0.07, -0.19), Vector3(0.18, -0.07, -0.19), Vector3(0.23, -0.19, -0.07), Vector3(0.18, -0.19, -0.07), Vector3(0.23, 0.1, 0.1), Vector3(0.31, 0.1, 0.1), Vector3(0.28, 0.06, 0.17), Vector3(0.28, 0.01, 0.1), Vector3(0.28, 0.14, 0.17), Vector3(0.28, 0.19, 0.1), Vector3(0.28, 0.14, 0.03), Vector3(0.28, 0.06, 0.03), Vector3(0.22, 0.06, 0.17), Vector3(0.22, 0.01, 0.1), Vector3(0.22, 0.14, 0.17), Vector3(0.22, 0.19, 0.1), Vector3(0.22, 0.14, 0.03), Vector3(0.22, 0.06, 0.03), Vector3(0.19, 0.1, 0.1), Vector3(0, -0.24, 0), Vector3(0, -0.04, 0), Vector3(0, 0.16, 0), Vector3(0, 0.36, 0), Vector3(0, 0.44, 0)],
	},
	"sera": {
		"l": [Vector3(-0, 0.19, -0.43), Vector3(0.02, 0.26, -0.38), Vector3(-0, 0.27, -0.39), Vector3(0.02, 0.33, -0.33), Vector3(-0, 0.34, -0.34), Vector3(0.02, 0.39, -0.27), Vector3(-0, 0.4, -0.28), Vector3(0.02, 0.44, -0.19), Vector3(-0, 0.45, -0.2), Vector3(0.02, 0.47, -0.12), Vector3(0.02, 0.49, 0.13), Vector3(0, 0.51, 0.14), Vector3(0.02, 0.47, 0.22), Vector3(0.02, 0.44, 0.29), Vector3(0, 0.45, 0.3), Vector3(0.02, 0.39, 0.37), Vector3(0, 0.4, 0.38), Vector3(0.02, 0.33, 0.43), Vector3(0, 0.34, 0.44), Vector3(0.02, 0.26, 0.48), Vector3(0, 0.27, 0.49), Vector3(0.02, 0.18, 0.51), Vector3(0, 0.18, 0.5), Vector3(0, 0.17, 0), Vector3(0, 0.37, 0), Vector3(0, 0.52, 0)],
	},
	"zeya": {
		"r": [Vector3(-0.15, 0.07, 0.02), Vector3(0.15, 0.12, 0.02), Vector3(0.15, 0.07, 0.02), Vector3(-0.15, 0.12, 0.02), Vector3(0, -0.16, 0), Vector3(0, 0.04, 0), Vector3(0, 0.24, 0), Vector3(0, 0.44, 0), Vector3(0, 0.64, 0)],
		"l": [Vector3(-0.15, 0.07, 0.02), Vector3(0.15, 0.12, 0.02), Vector3(0.15, 0.07, 0.02), Vector3(-0.15, 0.12, 0.02), Vector3(0, -0.16, 0), Vector3(0, 0.04, 0), Vector3(0, 0.24, 0), Vector3(0, 0.44, 0), Vector3(0, 0.64, 0)],
	},
	"ember": {
		"r": [Vector3(0.07, 1.22, 0), Vector3(0.05, 1.3, 0.1), Vector3(0.11, 1.3, 0), Vector3(-0.05, 1.3, 0.1), Vector3(-0.11, 1.3, 0), Vector3(-0.07, 1.22, 0), Vector3(-0.05, 1.3, -0.1), Vector3(0.05, 1.3, -0.1), Vector3(0.05, 1.32, 0.09), Vector3(-0.05, 1.32, 0.09), Vector3(-0.05, 1.32, -0.09), Vector3(0.05, 1.32, -0.09), Vector3(-0.11, 1.25, 0.01), Vector3(0.11, 1.27, 0.01), Vector3(-0.01, 1.25, 0.11), Vector3(0.01, 1.25, -0.11), Vector3(0, -0.3, 0), Vector3(0, -0.1, 0), Vector3(0, 0.1, 0), Vector3(0, 0.3, 0), Vector3(0, 0.5, 0), Vector3(0, 0.7, 0), Vector3(0, 0.9, 0), Vector3(0, 1.1, 0), Vector3(0, 1.3, 0), Vector3(0, 1.5, 0), Vector3(0, 1.62, 0)],
	},
	"hakuya": {
		"r": [Vector3(-0.07, 0.09, 0.07), Vector3(0.07, 0.11, 0.07), Vector3(0.07, 0.09, 0.07), Vector3(-0.07, 0.11, 0.07), Vector3(0.07, 0.09, -0.07), Vector3(-0.07, 0.11, -0.07), Vector3(-0.07, 0.09, -0.07), Vector3(0.07, 0.11, -0.07), Vector3(0, -0.26, 0), Vector3(0, -0.06, 0), Vector3(0, 0.14, 0), Vector3(0, 0.34, 0), Vector3(0, 0.54, 0), Vector3(0, 0.74, 0), Vector3(0, 0.94, 0), Vector3(0, 1.14, 0), Vector3(0, 1.34, 0), Vector3(0, 1.4, 0)],
	},
	"vael": {
		"r": [Vector3(-0.1, 0.1, 0.01), Vector3(0.1, 1.45, 0.01), Vector3(0.1, 0.1, 0.01), Vector3(-0.1, 1.45, 0.01), Vector3(-0.09, 1.45, 0.02), Vector3(-0.09, 0.1, 0.02), Vector3(0.09, 0.1, 0.02), Vector3(0.09, 1.45, 0.02), Vector3(0, 1.45, 0.1), Vector3(0, 1.45, -0.1), Vector3(-0.23, 0.06, 0.04), Vector3(0.23, 0.13, 0.04), Vector3(0.23, 0.06, 0.04), Vector3(-0.23, 0.13, 0.04), Vector3(0.23, 0.06, -0.04), Vector3(-0.23, 0.13, -0.04), Vector3(-0.23, 0.06, -0.04), Vector3(0.23, 0.13, -0.04), Vector3(-0.32, 0.11, 0.04), Vector3(-0.2, 0.19, 0.04), Vector3(-0.2, 0.11, 0.04), Vector3(-0.32, 0.19, 0.04), Vector3(-0.2, 0.11, -0.04), Vector3(-0.32, 0.19, -0.04), Vector3(-0.32, 0.11, -0.04), Vector3(-0.2, 0.19, -0.04), Vector3(0.2, 0.11, 0.04), Vector3(0.32, 0.19, 0.04), Vector3(0.32, 0.11, 0.04), Vector3(0.2, 0.19, 0.04), Vector3(0.32, 0.11, -0.04), Vector3(0.2, 0.19, -0.04), Vector3(0.2, 0.11, -0.04), Vector3(0.32, 0.19, -0.04), Vector3(0.01, 0.12, 0.09), Vector3(-0.03, 0.12, 0.07), Vector3(0.01, 0.08, 0.09), Vector3(-0.03, 0.08, 0.07), Vector3(0, -0.29, 0), Vector3(0, -0.09, 0), Vector3(0, 0.11, 0), Vector3(0, 0.31, 0), Vector3(0, 0.51, 0), Vector3(0, 0.71, 0), Vector3(0, 0.91, 0), Vector3(0, 1.11, 0), Vector3(0, 1.31, 0), Vector3(0, 1.51, 0), Vector3(0, 1.65, 0)],
	},
	"lucien": {
		"r": [Vector3(0.15, 1.38, 0.04), Vector3(0.15, 1.3, 0.04), Vector3(0.15, 1.3, -0.04), Vector3(0.15, 1.38, -0.04), Vector3(0.17, 1.38, 0), Vector3(0.19, 1.36, 0.04), Vector3(0.22, 1.36, 0), Vector3(0.12, 1.36, 0), Vector3(0.19, 1.36, -0.04), Vector3(0.2, 1.31, 0.06), Vector3(0.24, 1.31, 0), Vector3(0.1, 1.31, 0), Vector3(0.2, 1.31, -0.06), Vector3(0.19, 1.26, 0.04), Vector3(0.22, 1.26, 0), Vector3(0.15, 1.26, 0.04), Vector3(0.12, 1.26, 0), Vector3(0.15, 1.26, -0.04), Vector3(0.19, 1.26, -0.04), Vector3(0.17, 1.24, 0), Vector3(0.21, 1.21, 0.02), Vector3(0.23, 1.17, 0.01), Vector3(0.18, 1.34, 0.03), Vector3(0, -0.05, 0), Vector3(0, 0.15, 0), Vector3(0, 0.35, 0), Vector3(0, 0.55, 0), Vector3(0, 0.75, 0), Vector3(0, 0.95, 0), Vector3(0, 1.15, 0), Vector3(0, 1.35, 0), Vector3(0, 1.38, 0)],
	},
	"wenyu": {
		"r": [Vector3(0, -0.45, 0), Vector3(0, -0.25, 0), Vector3(0, -0.05, 0), Vector3(0, 0.15, 0), Vector3(0, 0.35, 0), Vector3(0, 0.55, 0), Vector3(0, 0.75, 0), Vector3(0, 0.8, 0)],
	},
	"kuroha": {
		"r": [Vector3(-0.07, 0.09, 0.07), Vector3(0.07, 0.11, 0.07), Vector3(0.07, 0.09, 0.07), Vector3(-0.07, 0.11, 0.07), Vector3(0.07, 0.09, -0.07), Vector3(-0.07, 0.11, -0.07), Vector3(-0.07, 0.09, -0.07), Vector3(0.07, 0.11, -0.07), Vector3(0, -0.26, 0), Vector3(0, -0.06, 0), Vector3(0, 0.14, 0), Vector3(0, 0.34, 0), Vector3(0, 0.54, 0), Vector3(0, 0.74, 0), Vector3(0, 0.94, 0), Vector3(0, 1.14, 0), Vector3(0, 1.34, 0), Vector3(0, 1.4, 0)],
	},
	"aion": {
		"r": [Vector3(0.25, 1.45, 0), Vector3(0.23, 1.56, 0), Vector3(0.21, 1.55, 0.03), Vector3(0.2, 1.45, 0.02), Vector3(0.16, 1.65, 0), Vector3(0.14, 1.63, 0.03), Vector3(-0.16, 1.65, 0), Vector3(-0.14, 1.63, 0.03), Vector3(-0.23, 1.56, 0), Vector3(-0.21, 1.55, 0.03), Vector3(-0.25, 1.45, 0), Vector3(-0.2, 1.45, 0.02), Vector3(-0.23, 1.34, 0), Vector3(-0.21, 1.35, 0.03), Vector3(-0.16, 1.25, 0), Vector3(-0.14, 1.27, 0.03), Vector3(-0.12, 1.3, 0.02), Vector3(0.16, 1.25, 0), Vector3(0.14, 1.27, 0.03), Vector3(0.12, 1.3, 0.02), Vector3(0.23, 1.34, 0), Vector3(0.21, 1.35, 0.03), Vector3(0.11, 1.44, 0.01), Vector3(0, -0.05, 0), Vector3(0, 0.15, 0), Vector3(0, 0.35, 0), Vector3(0, 0.55, 0), Vector3(0, 0.75, 0), Vector3(0, 0.95, 0), Vector3(0, 1.15, 0), Vector3(0, 1.35, 0), Vector3(0, 1.55, 0), Vector3(0, 1.69, 0)],
	},
	"kyomu": {
		"r": [Vector3(0.08, 0.12, 0.02), Vector3(0.08, 0.2, -0.02), Vector3(-0.08, 0.2, 0.02), Vector3(-0.08, 0.237, 0.02), Vector3(0.08, 0.245, 0.02), Vector3(0.08, 0.306, -0.02), Vector3(-0.08, 0.313, 0.02), Vector3(-0.08, 0.367, 0.02), Vector3(0.08, 0.374, 0.02), Vector3(0.08, 0.435, -0.02), Vector3(-0.08, 0.435, 0.02), Vector3(-0.08, 0.496, 0.02), Vector3(0.08, 0.504, 0.02), Vector3(0.08, 0.565, -0.02), Vector3(-0.08, 0.565, 0.02), Vector3(-0.08, 0.626, 0.02), Vector3(0.08, 0.633, 0.02), Vector3(0.08, 0.694, -0.02), Vector3(-0.08, 0.694, 0.02), Vector3(-0.08, 0.755, 0.02), Vector3(0.08, 0.763, 0.02), Vector3(0.08, 0.824, -0.02), Vector3(-0.13, 0.07, 0.04), Vector3(0.13, 0.07, 0.04), Vector3(-0.13, 0.12, 0.04), Vector3(0.13, 0.07, -0.04), Vector3(-0.13, 0.07, -0.04), Vector3(0.13, 0.12, -0.04), Vector3(0.13, 0.12, 0.04), Vector3(-0.13, 0.12, -0.04), Vector3(0, -0.16, 0), Vector3(0, 0.04, 0), Vector3(0, 0.207, 0), Vector3(0, 0.359, 0), Vector3(0, 0.511, 0), Vector3(0, 0.664, 0), Vector3(0, 0.816, 0), Vector3(0, 0.969, 0)],
		"l": [Vector3(0.08, 0.12, 0.02), Vector3(0.08, 0.2, -0.02), Vector3(-0.08, 0.2, 0.02), Vector3(-0.08, 0.237, 0.02), Vector3(0.08, 0.245, 0.02), Vector3(0.08, 0.306, -0.02), Vector3(-0.08, 0.313, 0.02), Vector3(-0.08, 0.367, 0.02), Vector3(0.08, 0.374, 0.02), Vector3(0.08, 0.435, -0.02), Vector3(-0.08, 0.435, 0.02), Vector3(-0.08, 0.496, 0.02), Vector3(0.08, 0.504, 0.02), Vector3(0.08, 0.565, -0.02), Vector3(-0.08, 0.565, 0.02), Vector3(-0.08, 0.626, 0.02), Vector3(0.08, 0.633, 0.02), Vector3(0.08, 0.694, -0.02), Vector3(-0.08, 0.694, 0.02), Vector3(-0.08, 0.755, 0.02), Vector3(0.08, 0.763, 0.02), Vector3(0.08, 0.824, -0.02), Vector3(-0.13, 0.07, 0.04), Vector3(0.13, 0.07, 0.04), Vector3(-0.13, 0.12, 0.04), Vector3(0.13, 0.07, -0.04), Vector3(-0.13, 0.07, -0.04), Vector3(0.13, 0.12, -0.04), Vector3(0.13, 0.12, 0.04), Vector3(-0.13, 0.12, -0.04), Vector3(0, -0.16, 0), Vector3(0, 0.04, 0), Vector3(0, 0.207, 0), Vector3(0, 0.359, 0), Vector3(0, 0.511, 0), Vector3(0, 0.664, 0), Vector3(0, 0.816, 0), Vector3(0, 0.969, 0)],
	},
}


## Titik-titik senjata dalam bingkai pegangan (meter; +Y = bilah), diambil dari mesh senjata asli (tools/clip_probe.gd). {"r": [...], "l": [...]}
static func fit_weapon(id: String) -> Dictionary:
	if _fit_w_cache.has(id):
		return _fit_w_cache[id]
	var src: Dictionary = FIT_WEAPONS.get(id, {})
	var out := {"r": src.get("r", []), "l": src.get("l", []), "slim": float(CharacterLooks.SLIM.get(id, 1.0))}
	_fit_w_cache[id] = out
	return out


# tembus total (meter) pada satu frame. q = {tulang: Quaternion}; P = [kanan a,f,hx,hz, kiri a,f,hx,hz]
static func _fit_pen(q: Dictionary, hp: Vector3, P: PackedFloat32Array, w: Dictionary, only: int = -1) -> float:
	var slim: float = w["slim"]
	var sc_hips := Basis.from_scale(Vector3(slim, 1.0, slim))          # set_slim: pinggul dikecilkan, kepala & tangan dikembalikan
	var sc_inv := Basis.from_scale(Vector3(1.0 / slim, 1.0, 1.0 / slim))
	var t_hips := Transform3D(Basis(q["root"]), Vector3.ZERO) * Transform3D(Basis(q["hips"]) * sc_hips, hp)
	var t_spine := t_hips * Transform3D(Basis(q["spine"]), FIT_OFFS["spine"])
	var t_chest := t_spine * Transform3D(Basis(q["chest"]), FIT_OFFS["chest"])
	var t_head := t_chest * Transform3D(Basis(q["head"]) * sc_inv, FIT_OFFS["head"])
	var ms := FIT_MODEL_SCALE
	var a := t_hips * Vector3(0, 0.05, 0)
	var ab: Vector3 = t_chest * Vector3(0, 0.5, 0) - a
	var abl := ab.length_squared()
	var qh := t_hips.basis.orthonormalized().get_rotation_quaternion()
	var qc := t_chest.basis.orthonormalized().get_rotation_quaternion()
	var hb := t_head.basis.orthonormalized().transposed()
	var rx := 0.30 * slim * FIT_MARGIN
	var rz := 0.17 * slim * FIT_MARGIN
	var hx := 0.34 * FIT_MARGIN
	var hy := 0.36 * FIT_MARGIN
	var hz := 0.33 * FIT_MARGIN
	var total := 0.0
	for side in 2:
		var pts: Array = w["l" if side == 1 else "r"]
		if pts.is_empty() or (only >= 0 and only != side):
			continue
		var s := "l" if side == 1 else "r"
		var os := 1.0 if side == 1 else -1.0
		var o := side * 4
		var uo: Vector3 = FIT_OFFS["ua_" + s]
		var qu := Quaternion(Vector3.BACK, os * P[o]) * Quaternion(Vector3.RIGHT, -P[o + 1]) * (q["upperarm_" + s] as Quaternion)
		var t_ua := t_chest * Transform3D(Basis(qu), uo)
		var t_fa := t_ua * Transform3D(Basis(q["forearm_" + s]), FIT_OFFS["fa_" + s])
		var qhand := Quaternion(Vector3.BACK, P[o + 3]) * Quaternion(Vector3.RIGHT, P[o + 2]) * (q["hand_" + s] as Quaternion)
		var t_hand := t_fa * Transform3D(Basis(qhand) * sc_inv, FIT_OFFS["hand"])
		var hbasis := t_hand.basis.orthonormalized()
		var grip := Vector3(-0.095 if side == 1 else 0.095, -0.10, 0.0)
		var rot90 := Basis(Vector3.RIGHT, PI * 0.5)
		for v in pts:
			var vm: Vector3 = v
			var loc := grip + rot90 * (vm / ms)
			var p := t_hand.origin + hbasis * loc
			if (p - t_hand.origin).length() * ms < FIT_SKIP_HAND:
				continue
			# badan
			var tt := clampf((p - a).dot(ab) / maxf(abl, 0.0001), 0.0, 1.0)
			var c := a + ab * tt
			var fl := Basis(qh.slerp(qc, tt)).transposed() * (p - c)
			var e := sqrt((fl.x / rx) * (fl.x / rx) + (fl.z / rz) * (fl.z / rz))
			if e < 1.0:
				total += (1.0 - e) * 0.17 * ms
			# kepala
			var hl := hb * (p - t_head.origin) - Vector3(0, 0.25, 0)
			var he := sqrt((hl.x / hx) * (hl.x / hx) + (hl.y / hy) * (hl.y / hy) + (hl.z / hz) * (hl.z / hz))
			if he < 1.0:
				total += (1.0 - he) * 0.33 * ms
	return total


## Kembalikan nama animasi yang sudah bebas-tembus untuk karakter id (membuat varian bila perlu). Nama tak dikenal dikembalikan apa adanya.
static func fit(anim_name: String, id: String) -> String:
	var w := fit_weapon(id)
	if w["r"].is_empty() and w["l"].is_empty():
		return anim_name
	if anim_name.contains("#"):
		return anim_name
	var inplace := anim_name.contains("@")
	var target := anim_name if inplace else anim_name + "#" + id
	if _fit_done.has(target):
		return target if (inplace or _fit_done[target]) else anim_name
	var lib := get_library()
	var src: Animation = lib.get_animation(anim_name) if lib.has_animation(anim_name) else null
	if src == null:
		return anim_name
	var res := _fit_anim(src, w)
	if res == null:
		_fit_done[target] = false
		return anim_name
	_fit_done[target] = true
	if inplace:
		lib.remove_animation(anim_name)
		lib.add_animation(anim_name, res)
	else:
		lib.add_animation(target, res)
	return target


static func _fit_tracks(anim: Animation) -> Dictionary:
	var tr := {}
	for b in FIT_NAMES:
		tr[b] = anim.find_track(NodePath("%s:%s" % [MODEL_NODE, b]), Animation.TYPE_ROTATION_3D)
	tr["pos"] = anim.find_track(NodePath("%s:hips" % MODEL_NODE), Animation.TYPE_POSITION_3D)
	return tr


static func _fit_frame(anim: Animation, tr: Dictionary, k: int) -> Array:
	var q := {}
	for b in FIT_NAMES:
		q[b] = anim.track_get_key_value(tr[b], k) as Quaternion
	return [q, anim.track_get_key_value(tr["pos"], k) as Vector3]


## null = tidak ada tembus (animasi dipakai apa adanya); selain itu salinan animasi yang sudah dikoreksi.
static func _fit_anim(src: Animation, w: Dictionary) -> Animation:
	var tr := _fit_tracks(src)
	for k in tr:
		if int(tr[k]) < 0:
			return null
	var n := src.track_get_key_count(tr["hips"])
	var zero := PackedFloat32Array([0, 0, 0, 0, 0, 0, 0, 0])
	var frames: Array = []
	var bad: Array = []
	var any := false
	for k in n:
		var fr := _fit_frame(src, tr, k)
		frames.append(fr)
		var pen := _fit_pen(fr[0], fr[1], zero, w)
		bad.append(pen > FIT_EPS)
		any = any or pen > FIT_EPS
	if not any:
		return null
	var params: Array = []
	for k in n:
		params.append(PackedFloat32Array(zero))
	var loop := src.loop_mode == Animation.LOOP_LINEAR
	for round in 5:
		for k in n:
			if round == 0 and not bad[k]:
				continue
			params[k] = _fit_solve(frames[k], params[k], w)
		# haluskan koreksi antar-frame (dua lintasan [1 2 1]/4), frame yang sudah bersih ikut tertarik tetangganya
		for pass_i in 2:
			var nxt: Array = []
			for k in n:
				var a: PackedFloat32Array = params[(k - 1 + n) % n if loop else maxi(k - 1, 0)]
				var b: PackedFloat32Array = params[k]
				var c: PackedFloat32Array = params[(k + 1) % n if loop else mini(k + 1, n - 1)]
				var o := PackedFloat32Array(zero)
				for i in 8:
					o[i] = 0.25 * a[i] + 0.5 * b[i] + 0.25 * c[i]
				nxt.append(o)
			params = nxt
		var clean := true
		for k in n:
			if _fit_pen(frames[k][0], frames[k][1], params[k], w) > FIT_EPS:
				clean = false
				bad[k] = true
		if clean:
			break
	for k in n:                                           # sisa tembus setelah penghalusan: selesaikan tanpa dihaluskan
		if _fit_pen(frames[k][0], frames[k][1], params[k], w) > FIT_EPS:
			params[k] = _fit_solve(frames[k], params[k], w)
	var out: Animation = src.duplicate(true)
	for k in n:
		var P: PackedFloat32Array = params[k]
		var q: Dictionary = frames[k][0]
		for side in 2:
			var s := "l" if side == 1 else "r"
			var os := 1.0 if side == 1 else -1.0
			var o := side * 4
			if absf(P[o]) + absf(P[o + 1]) + absf(P[o + 2]) + absf(P[o + 3]) < 0.0005:
				continue
			var qu := Quaternion(Vector3.BACK, os * P[o]) * Quaternion(Vector3.RIGHT, -P[o + 1]) * (q["upperarm_" + s] as Quaternion)
			var qhand := Quaternion(Vector3.BACK, P[o + 3]) * Quaternion(Vector3.RIGHT, P[o + 2]) * (q["hand_" + s] as Quaternion)
			out.track_set_key_value(tr["upperarm_" + s], k, qu.normalized())
			out.track_set_key_value(tr["hand_" + s], k, qhand.normalized())
	return out


# cari koreksi terkecil (pencarian serakah per parameter) yang menghilangkan tembus pada satu frame; tiap sisi (tangan) dipecahkan sendiri
static func _fit_solve(fr: Array, start: PackedFloat32Array, w: Dictionary) -> PackedFloat32Array:
	var P := PackedFloat32Array(start)
	var q: Dictionary = fr[0]
	var hp: Vector3 = fr[1]
	var lim := [1.2, 0.7, 1.0, 1.0]
	for side in 2:
		if (w["l" if side == 1 else "r"] as Array).is_empty():
			continue
		var pen := _fit_pen(q, hp, P, w, side)
		var step := 0.07
		for it in 30:
			if pen <= FIT_EPS * 0.5:
				break
			var best_i := -1
			var best_v := 0.0
			var best_pen := 0.0
			var best_score := 0.0
			for k in 4:
				var i := side * 4 + k
				for sgn in [-1.0, 1.0]:
					var nv: float = P[i] + sgn * step
					if absf(nv) > float(lim[k]):
						continue
					var old := P[i]
					P[i] = nv
					var np := _fit_pen(q, hp, P, w, side)
					P[i] = old
					var score := (pen - np) - 0.004 * absf(nv)
					if score > best_score:
						best_score = score
						best_i = i
						best_v = nv
						best_pen = np
			if best_i < 0:
				if step < 0.3:                            # buntu: coba langkah lebih besar
					step *= 2.0
					continue
				break
			P[best_i] = best_v
			pen = best_pen
	return P


# =====================================================================
#  AKSI DIAM ACAK (fidget): saat karakter berdiri diam beberapa detik, ia memainkan satu aksi kecil secara acak (melihat sekeliling,
#  meregang, memutar senjata, memeriksa senjata, merapikan rambut, menghela napas, bergoyang, dsb.), lalu kembali ke pose diam.
#  Tiap karakter punya 4 aksi sesuai kepribadian & senjatanya. Pose dasar = pose diam karakter itu (POSES), jadi awal/akhir menyambung mulus.
#  Dibuat lazy lewat fidgets(id); nama animasi "fid_<jenis>@<id>" (ikut diperiksa anti-tembus lewat fit()).
# =====================================================================
const FIDGETS := {
	"ren": ["twirl", "look", "stretch", "inspect"],
	"lyra": ["tap", "hair", "sigh", "look"],
	"kiriel": ["look", "hair", "tap", "bounce"],
	# Zyrax (★6)
	"zyrax": ["look", "hair", "tap", "bounce"],
	# Midori (★6)
	"midori": ["look", "tap", "sigh", "bounce"],
	"brann": ["shield", "look", "sigh", "tap"],
	"sera": ["hair", "look", "tap", "stretch"],
	"ember": ["bounce", "tap", "hair", "look"],
	"zeya": ["twirl", "look", "tap", "sigh"],
	"hakuya": ["inspect", "sigh", "look", "tap"],
	"vael": ["stretch", "look", "sigh", "tap"],
	"lucien": ["tap", "look", "hair", "sigh"],
	"wenyu": ["tap", "hair", "look", "bounce"],
	"kuroha": ["look", "sigh", "twirl", "inspect"],
	"aion": ["inspect", "look", "sigh", "tap"],
	"kyomu": ["look", "tap", "sigh", "bounce"],
}
const FID_LEN := {"look": 3.2, "stretch": 3.4, "hair": 3.0, "inspect": 3.4, "twirl": 2.4, "tap": 2.0, "shield": 2.4, "bounce": 1.8, "sway": 3.6, "sigh": 2.6}


static func _fid_pose(base: Dictionary, abs_d: Dictionary, add_d: Dictionary) -> Dictionary:
	var d := base.duplicate(true)
	for b in abs_d:
		d[b] = abs_d[b]
	for b in add_d:
		if d[b] is Vector3:
			d[b] = (d[b] as Vector3) + (add_d[b] as Vector3)
		else:
			d[b] = float(d[b]) + float(add_d[b])
	_fix_feet(d)
	return d


## Daftar keyframe [t, abs, add, ease] tiap jenis aksi. F = sisi tangan bebas ("l"; "r" untuk pemanah yang kirinya memegang busur).
static func _fid_keys(kind: String, F: String) -> Array:
	var os := 1.0 if F == "l" else -1.0
	var ua := "upperarm_" + F
	var fa := "forearm_" + F
	match kind:
		"look":                                       # menoleh kiri-kanan; lengan bebas ikut berayun menyeimbangkan badan
			var l1 := {"head": Vector3(-0.04, 0.7, 0.0), "chest": Vector3(0, 0.2, 0), "spine": Vector3(0, 0.1, 0), ua: Vector3(-0.2, 0, 0.06 * os), fa: Vector3(-0.22, 0, 0), "hand_" + F: Vector3(0.1, 0, 0)}
			var l2 := {"head": Vector3(0.0, -0.75, 0.0), "chest": Vector3(0, -0.22, 0), "spine": Vector3(0, -0.1, 0), ua: Vector3(0.12, 0, 0.1 * os), fa: Vector3(-0.1, 0, 0), "hand_" + F: Vector3(-0.08, 0, 0)}
			return [[0.0, {}, {}, ""], [0.2, {}, l1, "io"], [0.42, {}, l1, ""], [0.58, {}, l2, "io"], [0.8, {}, l2, ""], [1.0, {}, {}, "io"]]
		"stretch":
			var up := {ua: Vector3(-2.9, 0.0, 0.3 * os), fa: Vector3(-0.2, 0, 0), "upperarm_" + ("r" if F == "l" else "l"): Vector3(-2.9, 0.0, -0.3 * os), "forearm_" + ("r" if F == "l" else "l"): Vector3(-0.2, 0, 0)}
			var ad := {"spine": Vector3(-0.18, 0, 0), "head": Vector3(-0.3, 0, 0), "chest": Vector3(-0.08, 0, 0), "bob": 0.02}
			return [[0.0, {}, {}, ""], [0.3, up, ad, "io"], [0.62, up, ad, ""], [1.0, {}, {}, "io"]]
		"hair":
			var hd := {ua: Vector3(-1.5, 0.3, 0.65 * os), fa: Vector3(-2.7, 0, 0.0)}
			var ad2 := {"head": Vector3(0.05, 0.0, -0.14 * os), "spine": Vector3(0, 0.0, 0.03 * os)}
			return [[0.0, {}, {}, ""], [0.28, hd, ad2, "io"], [0.4, hd, ad2, ""], [0.48, hd, {"head": Vector3(0.05, 0.0, -0.2 * os)}, "io"],
				[0.7, hd, ad2, ""], [1.0, {}, {}, "io"]]
		"inspect":
			var iu := {"upperarm_r": Vector3(-1.25, 0.25, -0.3), "forearm_r": Vector3(-1.2, 0, 0), "hand_r": Vector3(-0.4, 0, 0)}
			var ia := {"head": Vector3(0.12, -0.3, 0.08), "spine": Vector3(0.05, -0.12, 0)}
			var iu2 := {"upperarm_r": Vector3(-1.25, 0.25, -0.3), "forearm_r": Vector3(-1.2, 0, 0), "hand_r": Vector3(-0.4, 0.9, 0)}
			return [[0.0, {}, {}, ""], [0.25, iu, ia, "io"], [0.45, iu, ia, ""], [0.58, iu2, ia, "io"], [0.78, iu2, ia, ""], [1.0, {}, {}, "io"]]
		"twirl":
			return [[0.0, {}, {}, ""], [0.14, {}, {"upperarm_r": Vector3(-0.35, 0, 0), "forearm_r": Vector3(-0.3, 0, 0)}, "io"],
				[0.32, {}, {"upperarm_r": Vector3(-0.35, 0, 0), "forearm_r": Vector3(-0.3, 0, 0), "hand_r": Vector3(1.5, 0, 0)}, ""],
				[0.46, {}, {"upperarm_r": Vector3(-0.35, 0, 0), "forearm_r": Vector3(-0.3, 0, 0), "hand_r": Vector3(3.0, 0, 0)}, ""],
				[0.6, {}, {"upperarm_r": Vector3(-0.35, 0, 0), "forearm_r": Vector3(-0.3, 0, 0), "hand_r": Vector3(4.5, 0, 0)}, ""],
				[0.74, {}, {"upperarm_r": Vector3(-0.35, 0, 0), "forearm_r": Vector3(-0.3, 0, 0), "hand_r": Vector3(6.2832, 0, 0)}, ""],
				[0.9, {}, {"head": Vector3(-0.08, 0, 0.06)}, "io"], [1.0, {}, {}, "io"]]
		"tap":
			var lift := {"upperarm_r": Vector3(-0.2, 0, 0), "forearm_r": Vector3(-0.1, 0, 0), "head": Vector3(-0.05, 0, 0)}
			var dn := {"upperarm_r": Vector3(0.04, 0, 0), "head": Vector3(0.08, 0, 0), "bob": -0.015}
			return [[0.0, {}, {}, ""], [0.18, {}, lift, "io"], [0.26, {}, dn, "io"], [0.42, {}, lift, "io"], [0.5, {}, dn, "io"],
				[0.66, {}, lift, "io"], [0.74, {}, dn, "io"], [1.0, {}, {}, "io"]]
		"shield":
			var s1 := {"upperarm_l": Vector3(-1.2, 0.2, 0.3), "forearm_l": Vector3(-1.3, 0, 0)}
			var s2 := {"upperarm_l": Vector3(-1.55, 0.2, 0.3), "forearm_l": Vector3(-0.4, 0, 0)}
			var sa := {"spine": Vector3(0.06, 0, 0), "head": Vector3(0.1, 0, 0)}
			return [[0.0, {}, {}, ""], [0.28, s1, {"spine": Vector3(-0.05, 0, 0)}, "io"], [0.4, s2, sa, "back"], [0.55, s2, sa, ""],
				[0.7, s1, {}, "io"], [1.0, {}, {}, "io"]]
		"bounce":
			var dn2 := {"bob": -0.06, "head": Vector3(0.1, 0, 0.05), ua: Vector3(0.18, 0, 0.1 * os), fa: Vector3(-0.2, 0, 0), "hand_" + F: Vector3(0.15, 0, 0)}      # lengan memantul mengikuti badan
			var up2 := {"bob": 0.03, "head": Vector3(-0.08, 0, -0.05), ua: Vector3(-0.3, 0, 0.2 * os), fa: Vector3(-0.45, 0, 0), "hand_" + F: Vector3(-0.2, 0, 0)}
			return [[0.0, {}, {}, ""], [0.12, {}, dn2, "io"], [0.22, {}, up2, "io"], [0.34, {}, dn2, "io"], [0.44, {}, up2, "io"],
				[0.56, {}, dn2, "io"], [0.66, {}, up2, "io"], [1.0, {}, {}, "io"]]
		"sway":
			var a := {"hips": Vector3(0, 0, 0.14), "spine": Vector3(0, 0, -0.1), "head": Vector3(0, 0, -0.12), "hx": 0.04}
			var b := {"hips": Vector3(0, 0, -0.14), "spine": Vector3(0, 0, 0.1), "head": Vector3(0, 0, 0.12), "hx": -0.04}
			return [[0.0, {}, {}, ""], [0.22, {}, a, "io"], [0.5, {}, b, "io"], [0.78, {}, a, "io"], [1.0, {}, {}, "io"]]
		_:                                           # "sigh": tarik napas (lengan terangkat sedikit), lalu menghela: bahu & lengan jatuh lemas
			var in1 := {"chest": Vector3(-0.1, 0, 0), "spine": Vector3(-0.06, 0, 0), "head": Vector3(-0.18, 0, 0), "bob": 0.02, ua: Vector3(-0.12, 0, 0.14 * os), fa: Vector3(-0.1, 0, 0), "hand_" + F: Vector3(-0.1, 0, 0)}
			var ex1 := {"spine": Vector3(0.16, 0, 0), "chest": Vector3(0.06, 0, 0), "head": Vector3(0.32, 0, 0), "bob": -0.04, ua: Vector3(0.14, 0, -0.06 * os), fa: Vector3(0.1, 0, 0), "hand_" + F: Vector3(0.12, 0, 0)}
			var ex2 := {"spine": Vector3(0.12, 0, 0), "chest": Vector3(0.04, 0, 0), "head": Vector3(0.28, 0, 0), "bob": -0.03, ua: Vector3(0.1, 0, -0.04 * os), fa: Vector3(0.06, 0, 0), "hand_" + F: Vector3(0.08, 0, 0)}
			return [[0.0, {}, {}, ""], [0.3, {}, in1, "io"], [0.5, {}, in1, ""], [0.72, {}, ex1, "io"], [0.86, {}, ex2, ""], [1.0, {}, {}, "io"]]


## Nama animasi aksi diam karakter id (dibuat bila belum ada). Kosong bila id tidak dikenal.
static func fidgets(id: String) -> Array:
	if not FIDGETS.has(id) or not STYLES.has(id):
		return []
	var lib := get_library()
	var out: Array = []
	var F := "r" if id == "sera" else "l"
	for kind in FIDGETS[id]:
		var nm := "fid_%s@%s" % [kind, id]
		if not lib.has_animation(nm):
			var base := _p_idle_s(0.0, id)
			var frames: Array = []
			for k in _fid_keys(kind, F):
				frames.append([k[0], _fid_pose(base, k[1], k[2]), k[3]])
			lib.add_animation(nm, _make(float(FID_LEN[kind]), false, func(u): return _seq(u, frames)))
		out.append(nm)
	return out
