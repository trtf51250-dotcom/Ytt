class_name QuestData
extends Resource
## Data satu quest. File .tres ada di res://resources/quests/.
## type: talk (target = id NPC), kill (target = jenis monster, kosong = semua), clear_stage (target = id stage),
##       buy (target = jenis item: weapon/armor/accessory/potion), upgrade, summon (gacha),
##       party (amount = jumlah anggota), level (amount = level akun)

@export var id: String = ""
@export var title: String = ""
@export_multiline var description: String = ""
@export var hint: String = ""
@export var type: String = "kill"
@export var target: String = ""
@export var amount: int = 1
@export var prerequisite: String = ""         # id quest yang harus selesai (claimed) dulu
@export var order: int = 0
@export var reward_gold: int = 0
@export var reward_diamond: int = 0
@export var reward_exp: int = 0
@export var reward_items: PackedStringArray = PackedStringArray()   # "id_item:jumlah"
@export var reward_character: String = ""     # id karakter yang bergabung
@export var region: String = ""              # "" = Kastil (Aurelia), "village" = Desa Fajar: quest hanya tampil di peta masing-masing
