class_name CharacterData
extends Resource
## Data satu karakter yang bisa dimainkan (party). File .tres ada di res://resources/characters/.

@export var id: String = ""
@export var display_name: String = ""
@export var title: String = ""
@export var role: String = ""                 # Swordsman / Mage / Guardian / Ranger
@export var weapon_class: String = "sword"    # sword / staff / guard / bow
@export var anim_style: String = ""          # kosong = ikut weapon_class; "dagger" = belati ganda (Assassin)
@export var skin_path: String = "res://assets/hero/skin_ren.png"
@export var accent: Color = Color(0.5, 0.8, 1.0)
@export_multiline var description: String = ""
@export var motto: String = ""                     # moto hidup, satu kalimat dengan suara si karakter sendiri
@export_multiline var story: String = ""      # cerita singkat; paragraf dipisah baris kosong
@export var unlocked_at_start: bool = false
@export var rarity: int = 3                  # bintang kelangkaan karakter 3..6 (terpisah dari bintang kebangkitan)

@export_group("Stat dasar (level 1) dan pertumbuhan per level")
@export var base_hp: int = 100
@export var base_atk: int = 10
@export var base_def: int = 4
@export var move_speed: float = 5.6
@export var hp_growth: float = 12.0
@export var atk_growth: float = 1.6
@export var def_growth: float = 0.6

@export_group("Serangan biasa")
@export var attack_kind: String = "arc"       # arc (tebas) / dagger (belati cepat) / bolt (bola sihir) / smash (hantam lebar) / arrow (panah)
@export var attack_range: float = 2.6
@export var attack_cooldown: float = 0.45
@export var attack_mult: float = 1.0
@export var combo_hits: int = 2               # jumlah pukulan dalam satu kombo (pukulan terakhir = penutup)
@export var finisher_mult: float = 1.0        # pengali damage pukulan penutup kombo
@export var combo_recovery: float = 0.0       # jeda tambahan setelah penutup kombo (detik)
@export var crit_chance: float = 0.12
@export var armor_pen: float = 0.0            # bagian DEF musuh yang diabaikan (0..1)

@export_group("Mana")
@export var max_mana: float = 100.0
@export var skill_mana_cost: float = 30.0     # biaya mana satu kali skill (ULTI gratis, tetap 1x per match)
@export var mana_regen: float = 3.0           # pemulihan mana per detik (pelan; mana utama datang dari menyerang)
@export var mana_per_attack: float = 3.0      # mana didapat tiap serangan biasa (penutup kombo x1,6)

@export_group("Skill")
@export var skill_name: String = ""
@export var skill_kind: String = "cone"       # cone / dash_cut / vortex / nova / shockwave / volley
@export var skill_cooldown: float = 6.0
@export var skill_mult: float = 2.4
@export var skill_range: float = 4.0
@export var ult_name: String = ""
@export var ult_kind: String = "sigil"
@export var dodge_kind: String = ""           # "" = dash biasa; "teleport" = menghilang-muncul lurus jauh dalam ~0,09 dtk (tanpa berkedip), kebal singkat
@export var ult_mult: float = 8.0
@export var ult_range: float = 11.0
@export var ult_charges: int = 1                # jatah ULTI per match pada bintang kebangkitan MAKSIMUM (default 1); di bawah bintang max selalu 1
@export var ult_form_secs_min: float = 0.0      # ULTI berbentuk "wujud" (mis. pedang petir): lama wujud di bintang kebangkitan 1 (detik); 0 = tanpa wujud
@export var ult_form_secs_max: float = 0.0      # lama wujud di bintang kebangkitan maksimum
