class_name CameraRig
extends Node3D
## Kamera pengikut gaya RPG/Guardian Tales: sudut miring dari atas-belakang, bisa diputar (seret layar / Q-R), zoom (cubit / roda mouse).
## Struktur: CameraRig(posisi mengikuti target) > Yaw > Pitch > Camera3D.

signal changed

var target: Node3D
var cam: Camera3D
var yaw := 0.0                           # radian; 0 = kamera di sisi +Z target, memandang ke -Z
var pitch := deg_to_rad(42.0)
var distance := 12.5
var min_distance := 6.0
var max_distance := 22.0
var min_pitch := deg_to_rad(8.0)
var max_pitch := deg_to_rad(72.0)
var height_offset := 1.5
var focus_node: Node3D = null            # opsional: kamera condong ke node ini (mis. bos tinggi)
var focus_bias := 0.0                    # 0..1 porsi jarak target->focus_node
var focus_lift := 0.0
var follow_speed := 9.0
var rim_radius := 0.0                    # >0: bila kamera melewati jarak ini dari pusat arena, kamera naik (pitch lebih tinggi) agar tidak menembus tajuk pohon tepi arena
var _rim_t := 0.0
var sensitivity := 0.005
var invert_y := false
var auto_center := false

var _yaw_node: Node3D
var _pitch_node: Node3D
var _drag_touch := -1
var _touches := {}
var _pinch_start := 0.0
var _pinch_dist0 := 0.0
var _shake := 0.0
var _shake_t := 0.0                      # fase noise halus untuk getaran (bukan acak per frame)
var fx_scale := 1.0                      # 0..1.5 dari Pengaturan "cam_fx": skala getaran & zoom-pulse (0 = mati, untuk yang mudah pusing)
var _pulse := Vector2.ZERO               # x = kamera maju (m, positif = lebih dekat), y = tambahan FOV (derajat); aditif, tidak mengubah distance/FOV dasar
var _pulse_tw: Tween
var _cine_tw: Tween
# --- tabrakan kamera dengan bangunan padat (bangunan sengaja tidak memudar): bila ada dinding di antara pemain dan kamera,
# kamera ditarik mendekat ke pemain (naik cepat, kembali pelan) alih-alih berada di balik dinding.
var occluders: Array = []                # {"inv": Transform3D dunia->lokal, "box": AABB lokal, "c": pusat dunia, "r": radius}
var _coll_pull := 0.0                    # berapa meter kamera sedang ditarik mendekat
const COLL_MIN := 2.8                    # jarak terdekat kamera ke pemain akibat tabrakan
const COLL_MARGIN := 0.7                 # jarak aman sebelum dinding
# --- bingkai percakapan/adegan: kamera maju sedikit, titik bidik turun supaya tokoh tampil DI ATAS kotak dialog, dan (bila ada
# lawan bicara) kamera memandang keduanya dari samping sehingga tidak ada yang tertutup badan yang lain.
var frame_closer := 1.8                  # meter
var frame_lower := 1.3                   # meter
var _frame_w := 0.0                      # 0..1, kekuatan bingkai (di-tween)
var _frame_other: Node3D = null
var _frame_tw: Tween
var _frame_active := false
var _frame_lock := false                 # input kamera dikunci dari frame_begin sampai pemulihan selesai
var _frame_prev_yaw := 0.0
var enabled := true
var lead_enabled := false                # true: kamera sedikit mendahului arah gerak target (lobi); mati di stage supaya rasa tempur tidak berubah
var kick_enabled := false                # true: FOV melebar halus saat target berlari (lobi)
var _base_fov := 50.0                    # FOV dasar dari Pengaturan; FOV nyata = dasar + _fov_extra
var _fov_extra := 0.0
var _lead := Vector3.ZERO
var blocked_rects: Array = []              # Rect2 layar (sentuhan di sini tidak memutar kamera, mis. joystick/tombol)


func _ready() -> void:
	_yaw_node = Node3D.new()
	_yaw_node.name = "Yaw"
	add_child(_yaw_node)
	_pitch_node = Node3D.new()
	_pitch_node.name = "Pitch"
	_yaw_node.add_child(_pitch_node)
	cam = Camera3D.new()
	cam.name = "Camera"
	cam.fov = 50.0
	cam.near = 0.3
	cam.far = 520.0
	_pitch_node.add_child(cam)
	cam.current = true
	apply_settings()
	_apply_transform()


func apply_settings() -> void:
	distance = 12.5 * float(GameState.setting("cam_zoom"))
	pitch = deg_to_rad(float(GameState.setting("cam_pitch")))
	sensitivity = 0.0035 + 0.0045 * float(GameState.setting("cam_sens"))
	invert_y = bool(GameState.setting("cam_invert_y"))
	_base_fov = float(GameState.setting("cam_fov"))
	var fxv = GameState.setting("cam_fx")
	fx_scale = clampf(float(fxv) if fxv != null else 1.0, 0.0, 1.5)
	cam.fov = _base_fov + _fov_extra
	changed.emit()


func snap_to_target() -> void:
	if target:
		global_position = target.global_position + Vector3(0, height_offset, 0)


func _apply_transform(delta: float = 0.0) -> void:
	var eff_pitch := pitch
	if rim_radius > 0.0:
		var off := Vector3(sin(yaw), 0, cos(yaw)) * distance * cos(pitch)
		var cp := global_position + off
		var over := Vector2(cp.x, cp.z).length() - rim_radius
		var goal := clampf(over / 5.0, 0.0, 1.0)
		_rim_t = lerpf(_rim_t, goal, 1.0 - exp(-6.0 * delta)) if delta > 0.0 else goal
		eff_pitch = lerpf(pitch, maxf(pitch, deg_to_rad(74.0)), _rim_t)
	_yaw_node.rotation.y = yaw
	_pitch_node.rotation.x = -eff_pitch
	var want := maxf(distance - _pulse.x - frame_closer * _frame_w, 2.5)
	var pull := maxf(want - _clear_distance(want, eff_pitch), 0.0)
	if delta <= 0.0:
		_coll_pull = pull
	elif pull > _coll_pull:
		_coll_pull = lerpf(_coll_pull, pull, 1.0 - exp(-16.0 * delta))      # terhalang: tarik cepat (jangan sempat menembus dinding)
	else:
		_coll_pull = lerpf(_coll_pull, pull, 1.0 - exp(-2.5 * delta))       # bebas lagi: lepas pelan (tidak memantul)
	cam.position = Vector3(0, 0, maxf(want - _coll_pull, 2.5))


## Daftarkan bangunan padat sebagai penghalang kamera. Dipanggil sekali setelah dunia selesai dibangun.
func set_occluders_from(buildings: Array) -> void:
	occluders.clear()
	for b in buildings:
		if not (b is Building) or b.mesh_instance == null or b.mesh_instance.mesh == null:
			continue
		if str(b.kind) in ["gate", "fountain", "pond", "portal", "altar", "tent"]:      # rendah / bisa dilewati
			continue
		var box: AABB = b.mesh_instance.mesh.get_aabb()
		var wb: AABB = b.global_transform * box
		if wb.size.y < 2.8:
			continue
		occluders.append({"inv": b.global_transform.affine_inverse(), "box": box, "c": wb.get_center(), "r": wb.size.length() * 0.5})


## Jarak kamera terjauh yang masih punya pandangan bebas ke pemain sepanjang lengan kamera (<= want).
func _clear_distance(want: float, eff_pitch: float) -> float:
	if occluders.is_empty():
		return want
	var cp := cos(eff_pitch)
	var dir := Vector3(sin(yaw) * cp, sin(eff_pitch), cos(yaw) * cp)       # dari pivot ke arah kamera
	var o := global_position
	var best := want
	for oc in occluders:
		var c: Vector3 = oc["c"]
		if o.distance_to(c) > float(oc["r"]) + want:
			continue
		var inv: Transform3D = oc["inv"]
		var t := _ray_box_entry(inv * o, inv.basis * dir, oc["box"], want)
		if t > 0.0 and t - COLL_MARGIN < best:
			best = maxf(t - COLL_MARGIN, COLL_MIN)
	return best


## Titik masuk sinar (a + d*t, 0..max_t) ke kotak; -1 bila tidak kena, atau bila titik awal sudah di dalam kotak.
func _ray_box_entry(a: Vector3, d: Vector3, box: AABB, max_t: float) -> float:
	var t0 := 0.0
	var t1 := max_t
	var lo := box.position
	var hi := box.end
	for i in 3:
		if absf(d[i]) < 0.000001:
			if a[i] < lo[i] or a[i] > hi[i]:
				return -1.0
		else:
			var u0 := (lo[i] - a[i]) / d[i]
			var u1 := (hi[i] - a[i]) / d[i]
			if u0 > u1:
				var tmp := u0
				u0 = u1
				u1 = tmp
			t0 = maxf(t0, u0)
			t1 = minf(t1, u1)
			if t0 > t1:
				return -1.0
	return t0 if t0 > 0.0 else -1.0


## Mulai bingkai percakapan. `other` = lawan bicara (kamera memandang dari samping, titik bidik di antara kalian); null = hanya
## mendekat & menurunkan titik bidik (adegan dialog yang menjeda game). Input kamera dikunci sampai frame_end() selesai.
func frame_begin(other: Node3D = null) -> void:
	if target == null:
		return
	if not _frame_active:
		if not _frame_lock:
			_frame_prev_yaw = yaw                                # bila dipanggil lagi saat pemulihan berjalan, arah asal tetap yang pertama
	_frame_active = true
	_frame_lock = true
	_frame_other = other
	if _frame_tw != null and _frame_tw.is_valid():
		_frame_tw.kill()
	_frame_tw = create_tween()
	_frame_tw.set_parallel(true)
	_frame_tw.set_trans(Tween.TRANS_SINE)
	_frame_tw.set_ease(Tween.EASE_IN_OUT)
	_frame_tw.tween_property(self, "_frame_w", 1.0, 0.55)
	if other != null and is_instance_valid(other):
		var v := other.global_position - target.global_position
		v.y = 0.0
		if v.length() > 0.3:
			# pandangan ~70 derajat terhadap garis tokoh-lawan; pilih sudut terdekat dari arah kamera sekarang (putaran paling kecil, maks ~70 derajat)
			var ang := atan2(v.x, v.z)
			var best := yaw
			var best_d := INF
			for base in [ang, ang + PI]:
				for off in [-1.22, 1.22]:
					var cand: float = base + off
					var dd := absf(angle_difference(yaw, cand))
					if dd < best_d:
						best_d = dd
						best = yaw + angle_difference(yaw, cand)
			_frame_tw.tween_property(self, "yaw", best, 0.7)


## Akhiri bingkai: kamera kembali ke jarak, titik bidik, dan arah semula, lalu input dibuka lagi.
func frame_end() -> void:
	if not _frame_active:
		return
	_frame_active = false
	_frame_other = null
	if _frame_tw != null and _frame_tw.is_valid():
		_frame_tw.kill()
	_frame_tw = create_tween()
	_frame_tw.set_parallel(true)
	_frame_tw.set_trans(Tween.TRANS_SINE)
	_frame_tw.set_ease(Tween.EASE_IN_OUT)
	_frame_tw.tween_property(self, "_frame_w", 0.0, 0.5)
	if absf(angle_difference(yaw, _frame_prev_yaw)) > 0.001:
		_frame_tw.tween_property(self, "yaw", yaw + angle_difference(yaw, _frame_prev_yaw), 0.5)
	_frame_tw.chain().tween_callback(func() -> void: _frame_lock = false)


func shake(amount: float = 0.25) -> void:
	_shake = maxf(_shake, amount * fx_scale)


## Dorongan zoom singkat (benturan/raungan): kamera maju `dist_in` meter dan FOV bertambah `fov_add` derajat dalam `in_s` detik,
## lalu kembali mulus dalam `out_s`. Nilai negatif = mundur / FOV menyempit sebaliknya (maju + FOV kecil = "push-in" tegang;
## mundur + FOV besar = hentakan lepas). Aditif di atas zoom/FOV pemain, jadi pengaturan kamera tidak tertimpa. Selalu kembali ke nol.
func pulse(dist_in: float, fov_add: float, in_s: float = 0.08, out_s: float = 0.45) -> void:
	if fx_scale <= 0.0:
		return
	_kill_pulse()
	_pulse_tw = create_tween()
	_pulse_tw.tween_property(self, "_pulse", Vector2(dist_in, fov_add) * fx_scale, maxf(in_s, 0.01)).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	_pulse_tw.tween_property(self, "_pulse", Vector2.ZERO, maxf(out_s, 0.01)).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


## Tahan pose zoom (mis. pengisian ULTI) sampai pulse_release() dipanggil. Ada batas `max_hold` detik: bila tidak pernah dilepas
## (ULTI terputus, pemain gugur), kamera tetap kembali sendiri.
func pulse_hold(dist_in: float, fov_add: float, in_s: float = 0.35, max_hold: float = 1.2, out_s: float = 0.4) -> void:
	if fx_scale <= 0.0:
		return
	_kill_pulse()
	_pulse_tw = create_tween()
	_pulse_tw.tween_property(self, "_pulse", Vector2(dist_in, fov_add) * fx_scale, maxf(in_s, 0.01)).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	_pulse_tw.tween_interval(max_hold)
	_pulse_tw.tween_property(self, "_pulse", Vector2.ZERO, maxf(out_s, 0.01)).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func pulse_release(out_s: float = 0.4) -> void:
	if _pulse == Vector2.ZERO and (_pulse_tw == null or not _pulse_tw.is_valid()):
		return
	_kill_pulse()
	_pulse_tw = create_tween()
	_pulse_tw.tween_property(self, "_pulse", Vector2.ZERO, maxf(out_s, 0.01)).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func _kill_pulse() -> void:
	if _pulse_tw != null and _pulse_tw.is_valid():
		_pulse_tw.kill()


## True selagi gerakan sinematik (cine_to) berjalan: seretan jari/tombol putar diabaikan agar tidak melawan animasi.
func is_cine_running() -> bool:
	return _frame_lock or (_cine_tw != null and _cine_tw.is_valid() and _cine_tw.is_running())


## Gerakan kamera sinematik (adegan peralihan peta): arah (yaw, lewat jalur terpendek), kemiringan (derajat), jarak, dan FOV dasar
## menuju nilai tujuan dalam `secs` detik dengan kurva halus (default sinus masuk-keluar). Mengembalikan Tween agar bisa ditunggu.
## Gerakan sebelumnya dibatalkan lebih dulu (tidak ada dua tween yang berebut yaw/jarak), dan tujuan dijaga di batas zoom/sudut.
func cine_to(yaw_to: float, pitch_to_deg: float, dist_to: float, fov_to: float, secs: float, trans: int = Tween.TRANS_SINE, ease_type: int = Tween.EASE_IN_OUT) -> Tween:
	if _cine_tw != null and _cine_tw.is_valid():
		_cine_tw.kill()
	dist_to = clampf(dist_to, min_distance, max_distance)
	pitch_to_deg = clampf(pitch_to_deg, rad_to_deg(min_pitch), rad_to_deg(max_pitch))
	var tw := create_tween()
	_cine_tw = tw
	tw.set_parallel(true)
	tw.set_trans(trans)
	tw.set_ease(ease_type)
	tw.tween_property(self, "yaw", yaw + angle_difference(yaw, yaw_to), secs)
	tw.tween_property(self, "pitch", deg_to_rad(pitch_to_deg), secs)
	tw.tween_property(self, "distance", dist_to, secs)
	tw.tween_property(self, "_base_fov", fov_to, secs)
	return tw


## Pose kamera langsung (tanpa animasi): dipakai sebagai kuncian awal adegan sebelum cine_to dijalankan.
func cine_set(yaw_v: float, pitch_deg: float, dist_v: float, fov_v: float) -> void:
	yaw = yaw_v
	pitch = deg_to_rad(pitch_deg)
	distance = dist_v
	_base_fov = fov_v
	cam.fov = _base_fov + _fov_extra


func _process(delta: float) -> void:
	if target:
		var goal := target.global_position + Vector3(0, height_offset, 0)
		if focus_node != null and is_instance_valid(focus_node) and focus_bias > 0.0:
			var d := focus_node.global_position - target.global_position
			d.y = 0.0
			goal += d * focus_bias + Vector3(0, focus_lift, 0)
		if lead_enabled or kick_enabled:
			# kamera mendahului arah gerak (halus, maks 1,6 m) dan FOV melebar sedikit saat berlari: terasa meluncur ke depan, bukan menempel
			var vv = target.get("velocity")
			var tv := Vector3.ZERO
			if vv is Vector3:
				tv = vv
			tv.y = 0.0
			var want := tv * 0.24 if lead_enabled else Vector3.ZERO
			if want.length() > 1.6:
				want = want.normalized() * 1.6
			_lead = _lead.lerp(want, 1.0 - exp(-2.4 * delta))
			goal += _lead
			var kick := clampf((tv.length() - 3.6) / 2.4, 0.0, 1.0) * 3.5 if kick_enabled else 0.0
			_fov_extra = lerpf(_fov_extra, kick, 1.0 - exp(-3.0 * delta))
		elif _fov_extra != 0.0 or _lead != Vector3.ZERO:
			_fov_extra = 0.0
			_lead = Vector3.ZERO
		if _frame_w > 0.001:
			var mid := goal
			if _frame_other != null and is_instance_valid(_frame_other):
				var op := _frame_other.global_position
				mid = goal.lerp(Vector3(op.x, goal.y, op.z), 0.5)           # titik bidik di antara pemain dan lawan bicara
			mid.y -= frame_lower                                            # turun = tokoh naik di layar, di atas kotak dialog
			goal = goal.lerp(mid, _frame_w)
		global_position = global_position.lerp(goal, 1.0 - exp(-follow_speed * delta))
	cam.fov = _base_fov + _fov_extra + _pulse.y
	distance = clampf(distance, min_distance, max_distance)
	pitch = clampf(pitch, min_pitch, max_pitch)
	if enabled and not is_cine_running():
		var rot := Input.get_axis("cam_left", "cam_right")
		if rot != 0.0:
			yaw -= rot * 1.8 * delta
	_apply_transform(delta)
	if _shake > 0.0:
		# peluruhan: getaran kecil bertahan sedikit lebih lama (terlihat), getaran besar cepat reda (tidak membuat pusing)
		_shake = maxf(_shake - delta * lerpf(0.45, 1.5, clampf(_shake / 0.3, 0.0, 1.0)), 0.0)
		_shake_t += delta * 80.0
		# dua sinus tak-sepadan per sumbu = gerak halus tapi tidak berulang, bukan acak per frame (yang tampak bergetar kasar)
		var a := _shake * 0.4
		cam.h_offset = (sin(_shake_t) * 0.6 + sin(_shake_t * 2.31 + 1.7) * 0.4) * a
		cam.v_offset = (sin(_shake_t * 1.27 + 4.1) * 0.6 + sin(_shake_t * 2.93 + 0.6) * 0.4) * a
	elif cam.h_offset != 0.0 or cam.v_offset != 0.0:
		cam.h_offset = 0.0
		cam.v_offset = 0.0


func _blocked(p: Vector2) -> bool:
	for r in blocked_rects:
		if (r as Rect2).has_point(p):
			return true
	return false


func _unhandled_input(event: InputEvent) -> void:
	if not enabled:
		return
	var locked := is_cine_running()           # selama gerakan sinematik: sentuhan baru/seretan/roda diabaikan, tapi lepas-jari tetap diproses agar status sentuhan tidak macet
	if event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			if locked or _blocked(st.position):
				return
			_touches[st.index] = st.position
			if _touches.size() == 1:
				_drag_touch = st.index
			elif _touches.size() == 2:
				_drag_touch = -1
				var pts := _touches.values()
				_pinch_dist0 = (pts[0] as Vector2).distance_to(pts[1])
				_pinch_start = distance
		else:
			_touches.erase(st.index)
			if st.index == _drag_touch:
				_drag_touch = -1
	elif locked:
		return
	elif event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		if not _touches.has(sd.index):
			return
		_touches[sd.index] = sd.position
		if _touches.size() >= 2:
			var pts2 := _touches.values()
			var d := (pts2[0] as Vector2).distance_to(pts2[1])
			if _pinch_dist0 > 10.0:
				distance = clampf(_pinch_start * _pinch_dist0 / maxf(d, 10.0), min_distance, max_distance)
		elif sd.index == _drag_touch:
			yaw -= sd.relative.x * sensitivity
			pitch += sd.relative.y * sensitivity * (-1.0 if invert_y else 1.0)
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		var mm := event as InputEventMouseMotion
		yaw -= mm.relative.x * sensitivity
		pitch += mm.relative.y * sensitivity * (-1.0 if invert_y else 1.0)
	elif event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			distance = clampf(distance - 1.0, min_distance, max_distance)
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			distance = clampf(distance + 1.0, min_distance, max_distance)


## Apakah segmen dari kamera ke titik p memotong AABB dunia (untuk memudarkan bangunan penghalang)?
## end_margin: kotak harus sudah ditembus minimal sekian meter SEBELUM titik p. Dengan begitu pemain yang cuma berdiri di dekat dinding
## (tidak ada bangunan di antara kamera dan pemain) tidak membuat bangunan menjadi tembus pandang.
func segment_hits_aabb(p: Vector3, box: AABB, end_margin: float = 0.0) -> bool:
	var a := cam.global_position
	var d := p - a
	var tmin := 0.0
	var tmax := 1.0 - end_margin / maxf(d.length(), 0.01)
	if tmax <= 0.0:
		return false
	for i in 3:
		var da := d[i]
		var lo := box.position[i]
		var hi := box.position[i] + box.size[i]
		if absf(da) < 0.00001:
			if a[i] < lo or a[i] > hi:
				return false
		else:
			var t1 := (lo - a[i]) / da
			var t2 := (hi - a[i]) / da
			if t1 > t2:
				var tmp := t1
				t1 = t2
				t2 = tmp
			tmin = maxf(tmin, t1)
			tmax = minf(tmax, t2)
			if tmin > tmax:
				return false
	return true
