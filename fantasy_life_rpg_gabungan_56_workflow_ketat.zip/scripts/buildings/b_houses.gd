extends RefCounted
## Rumah warga Aurelia: pondok, rumah kayu dua lantai, rumah menara segi delapan, rumah sayap silang.

const FH := BCommon.FOUND_H
const T_PLASTER := MeshKit.T_PLASTER
const T_TIMBER := MeshKit.T_TIMBER
const T_WOOD := MeshKit.T_WOOD
const T_ROOF := MeshKit.T_ROOF


static func build(b: Building) -> void:
	match b.kind:
		"house_a":
			_cottage(b)
		"house_b":
			_timber_two(b)
		"house_c":
			_round_tower(b)
		"house_d":
			_cross_house(b)


# ---------------------------------------------------------------------
static func _cottage(b: Building) -> void:
	var k := b.kit
	var w := 7.0
	var d := 6.0
	var top := BCommon.shell(b, w, d, 3.1, T_PLASTER, b.wall_color)
	BCommon.gable(b, w, d, top, 2.4, b.roof_color, b.wall_color)
	BCommon.front_door(b, -1.5, d)
	BCommon.front_windows(b, [1.7], FH + 1.7, d, 1.2, 1.3, 0.7, Pal.BLUE, true)
	BCommon.side_windows(b, w, 1.0, [0.0], FH + 1.7)
	BCommon.side_windows(b, w, -1.0, [0.0], FH + 1.7)
	BCommon.chimney_on(b, 2.3, -1.0, top, 2.6)
	Decor.lantern(k, Vector3(-0.45, FH + 2.1, d * 0.5 + 0.3))
	Decor.barrel(k, b.sink, Vector3(w * 0.5 + 0.7, 0, d * 0.5 - 1.0))
	Decor.crate(k, b.sink, Vector3(w * 0.5 + 0.8, 0, d * 0.5 - 2.0), 0.7, 12.0)
	Decor.sack(k, Vector3(-w * 0.5 - 0.6, 0, d * 0.5 - 0.8))
	Decor.flower_patch(k, Vector3(-w * 0.5 + 0.8, 0, d * 0.5 + 1.7), 1.0, 10)
	b.footprint = 6.0
	b.height = top + 2.4


# ---------------------------------------------------------------------
static func _timber_two(b: Building) -> void:
	var k := b.kit
	var w := 8.0
	var d := 7.0
	var h := 6.0
	var top := BCommon.shell(b, w, d, h, T_TIMBER, b.wall_color, 2)
	BCommon.gable(b, w, d, top, 3.0, b.roof_color, b.wall_color, 0.6, T_TIMBER)
	BCommon.front_door(b, -2.0, d)
	BCommon.front_windows(b, [1.8], FH + 1.7, d, 1.2, 1.3, 0.7, Pal.BLUE_DEEP, true)
	BCommon.front_windows(b, [-2.6, 0.0, 2.6], FH + h * 0.5 + 1.5, d, 1.1, 1.25, 0.8, Pal.BLUE_DEEP, true)
	BCommon.side_windows(b, w, 1.0, [-1.5, 1.5], FH + 1.7)
	BCommon.side_windows(b, w, -1.0, [-1.5, 1.5], FH + 1.7)
	BCommon.side_windows(b, w, 1.0, [0.0], FH + h * 0.5 + 1.5)
	BCommon.side_windows(b, w, -1.0, [0.0], FH + h * 0.5 + 1.5)
	# dormer di lereng depan
	var dz := 2.5
	k.box(Vector3(0, top + 1.1, dz - 0.9), Vector3(2.0, 1.5, 1.8), T_PLASTER, b.wall_color, T_PLASTER, b.wall_color, 0.9)
	k.gable_roof(Vector3(0, top + 1.85, dz - 0.9), 2.0, 1.8, 1.0, 0.2, T_ROOF, b.roof_color, T_PLASTER, b.wall_color, false)
	Decor.window(k, 0.0, top + 1.1, dz, 0.8, 0.85, 0.9, Pal.BLUE_DEEP, false)
	BCommon.chimney_on(b, -2.6, -1.4, top, 3.4)
	Decor.lantern(k, Vector3(-0.8, FH + 2.1, d * 0.5 + 0.3))
	Decor.lantern(k, Vector3(w * 0.5 + 0.2, FH + 2.1, d * 0.5 - 0.3))
	Decor.barrel(k, b.sink, Vector3(w * 0.5 + 0.8, 0, d * 0.5 - 1.2))
	Decor.barrel(k, b.sink, Vector3(w * 0.5 + 0.7, 0, d * 0.5 - 2.1), Pal.WOOD_DARK)
	Decor.bench(k, b.sink, Vector3(-w * 0.5 - 0.5, 0, 0.5), 90.0)
	Decor.flower_patch(k, Vector3(2.6, 0, d * 0.5 + 1.9), 1.2, 12)
	b.footprint = 7.0
	b.height = top + 3.2


# ---------------------------------------------------------------------
## Rumah menara segi delapan beratap kerucut (fantasi).
static func _round_tower(b: Building) -> void:
	var k := b.kit
	var r := 4.0
	var h := 6.2
	var apothem := r * cos(PI / 8.0)
	k.push()
	k.yaw(22.5)
	k.cylinder(Vector3.ZERO, r + FUDGE, r + FUDGE, FH, 8, MeshKit.T_BRICK, Pal.STONE, true, MeshKit.T_BRICK, false, 0.85)
	k.cylinder(Vector3(0, FH, 0), r, r, h, 8, T_TIMBER, b.wall_color, true, T_PLASTER, false, 0.8)
	k.cylinder(Vector3(0, FH + h * 0.5, 0), r + 0.08, r + 0.08, 0.22, 8, T_WOOD, Pal.WOOD_DARK, true, T_WOOD, false, 0.9)
	k.cylinder(Vector3(0, FH + h - 0.1, 0), r + 0.1, r + 0.1, 0.22, 8, T_WOOD, Pal.WOOD_DARK, true, T_WOOD, false, 0.9)
	k.spire(Vector3(0, FH + h + 0.05, 0), r + 0.5, 5.0, 8, T_ROOF, b.roof_color, 0.9)
	k.pop()
	var top := FH + h
	k.blob(Vector3(0, top + 5.2, 0), 0.28, MeshKit.T_METAL, Pal.GOLD, 3, 6)
	k.cylinder(Vector3(0, top + 5.0, 0), 0.06, 0.04, 0.8, 5, MeshKit.T_METAL, Pal.GOLD, true)
	b.sink.cyl(k.xf, Vector3.ZERO, r + 0.25, top)
	# pintu di sisi depan (+Z), jendela di sisi lain
	k.push()
	k.move(0, FH, 0)
	Decor.door(k, 0.0, apothem, 1.4, 2.3, false)
	k.pop()
	b.register_door(0.0, apothem, 1.4, 2.3)
	k.box(Vector3(0, 0.1, apothem + 0.6), Vector3(2.4, 0.2, 1.0), MeshKit.T_BRICK, Pal.STONE_DARK, MeshKit.T_BRICK, Pal.STONE, 0.85)
	for j in [1, 2, 3, 4, 5, 6, 7]:
		k.push()
		k.yaw(-45.0 * j)
		Decor.window(k, 0.0, FH + 1.8, apothem, 1.0, 1.25, 0.75, Pal.BLUE_DEEP, j % 2 == 0)
		Decor.window(k, 0.0, FH + 4.4, apothem, 0.9, 1.2, 0.85, Pal.BLUE_DEEP, false)
		k.pop()
	Decor.window(k, 0.0, FH + 4.4, apothem, 0.9, 1.2, 0.85, Pal.BLUE_DEEP, false)
	Decor.lantern(k, Vector3(1.3, FH + 2.1, apothem + 0.3))
	Decor.barrel(k, b.sink, Vector3(2.8, 0, apothem + 0.9))
	Decor.flower_patch(k, Vector3(-2.6, 0, apothem + 1.4), 1.2, 12)
	b.footprint = 6.5
	b.height = top + 5.0


const FUDGE := 0.2


# ---------------------------------------------------------------------
## Rumah besar dengan sayap silang (dua atap pelana tegak lurus).
static func _cross_house(b: Building) -> void:
	var k := b.kit
	var mw := 9.0
	var md := 6.5
	var mh := 3.6
	# badan utama di kiri
	k.push()
	k.move(-2.8, 0, -0.6)
	var top := BCommon.shell(b, mw, md, mh, T_PLASTER, b.wall_color)
	BCommon.gable(b, mw, md, top, 2.5, b.roof_color, b.wall_color)
	BCommon.front_door(b, -1.6, md)
	BCommon.front_windows(b, [1.9], FH + 1.8, md, 1.2, 1.3, 0.7, Pal.BLUE, true)
	BCommon.side_windows(b, mw, -1.0, [0.0], FH + 1.8)
	BCommon.chimney_on(b, -2.6, -1.0, top, 2.8, true)
	k.pop()
	# sayap menjorok ke depan (kanan): punggung atap sepanjang Z
	var ww := 8.5       # panjang sayap (sepanjang Z dunia)
	var wd := 5.4       # lebar sayap (sepanjang X dunia)
	var wcx := 4.4
	var wcz := 0.6
	k.push()
	k.move(wcx, 0, wcz)
	k.yaw(-90.0)         # sumbu X lokal -> +Z dunia
	var top2 := BCommon.shell(b, ww, wd, mh + 0.4, T_PLASTER, b.wall_color)
	BCommon.gable(b, ww, wd, top2, 2.6, b.roof_color, b.wall_color, 0.55)
	k.pop()
	# hiasan di muka depan sayap (z dunia = wcz + ww/2)
	var fz := wcz + ww * 0.5
	k.push()
	k.move(wcx, 0, fz)
	Decor.window(k, 0.0, FH + 1.9, 0.0, 1.4, 1.5, 0.8, Pal.BLUE_DEEP, true)
	Decor.flower_box(k, 0.0, FH + 1.0, 0.0, 1.9)
	BCommon.round_window(k, Vector3(0, top2 + 0.95, 0.04), 0.45, 0.9)
	k.pop()
	# jendela samping sayap
	k.push()
	k.move(wcx, 0, wcz)
	k.yaw(90.0)
	Decor.window(k, -1.5, FH + 1.9, wd * 0.5, 1.1, 1.3, 0.7)
	Decor.window(k, 1.5, FH + 1.9, wd * 0.5, 1.1, 1.3, 0.7)
	k.pop()
	Decor.lantern(k, Vector3(2.4, FH + 2.2, fz + 0.3))
	Decor.barrel(k, b.sink, Vector3(7.6, 0, fz - 0.8))
	Decor.crate(k, b.sink, Vector3(-8.2, 0, 3.0), 0.8, 20.0)
	Decor.fence(k, b.sink, Vector3(-7.4, 0, 5.2), Vector3(0.6, 0, 5.2))
	Decor.flower_patch(k, Vector3(-4.0, 0, 4.8), 1.3, 14)
	b.footprint = 9.0
	b.height = top2 + 2.6
