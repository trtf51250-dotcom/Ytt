class_name HouseInterior
extends Node3D
## Isi rumah warga. Dibuat HANYA saat pemain masuk (satu ruangan, ~1 mesh + 1 tubuh tabrakan + 1 lampu) dan dibuang saat keluar,
## jadi tidak membebani lobi. Terletak jauh di luar peta; dinding depan rendah supaya kamera selalu melihat ke dalam tanpa efek tembus pandang.

const ORIGIN := Vector3(420.0, 0.0, 420.0)
const FOUND := MeshKit.T_WOOD

var interactions: Array = []          # {"id","pos"(global),"action","prompt","radius"}
var spawn := Vector3.ZERO             # titik muncul pemain (global)
var occupant_pos := Vector2.ZERO      # pusat jalan penghuni (global x,z)
var size := Vector2(8.0, 7.0)
var kit: MeshKit
var sink := ColliderSink.new()
var light: OmniLight3D


static func dims(kind: String) -> Vector2:
	match kind:
		"house_b": return Vector2(9.0, 8.0)
		"house_c": return Vector2(8.0, 8.0)
		"house_d": return Vector2(10.0, 8.0)
	return Vector2(8.0, 7.0)


func build(kind: String, seed_value: int, wall: Color, roof: Color) -> void:
	position = ORIGIN
	size = dims(kind)
	var w := size.x
	var d := size.y
	var hh := 3.3
	kit = MeshKit.new(seed_value * 7 + 3)
	var k := kit
	var side := 1.0 if seed_value % 2 == 0 else -1.0                 # sisi tempat tidur; furnitur lain berseberangan
	var wood := Pal.WOOD
	var dark := Pal.WOOD_DARK
	var T_W := MeshKit.T_WOOD
	var T_P := MeshKit.T_PLASTER
	# lantai & dinding
	k.box(Vector3(0, -0.1, 0), Vector3(w + 0.6, 0.2, d + 0.6), T_W, wood.lightened(0.1))
	k.box(Vector3(0, hh * 0.5, -d * 0.5 - 0.15), Vector3(w + 0.6, hh, 0.3), T_P, wall)
	k.box(Vector3(-w * 0.5 - 0.15, hh * 0.5, 0), Vector3(0.3, hh, d), T_P, wall)
	k.box(Vector3(w * 0.5 + 0.15, hh * 0.5, 0), Vector3(0.3, hh, d), T_P, wall)
	var gap := 0.95
	for s in [-1.0, 1.0]:                                                  # dinding depan rendah dengan celah pintu
		var len := w * 0.5 + 0.3 - gap
		k.box(Vector3(s * (gap + len * 0.5), 0.5, d * 0.5 + 0.15), Vector3(len, 1.0, 0.3), T_P, wall, T_W, dark)
	for s in [-1.0, 1.0]:
		k.box_b(Vector3(s * gap, 0, d * 0.5 + 0.15), Vector3(0.2, 2.3, 0.32), T_W, dark)
	k.box(Vector3(0, 0.03, d * 0.5 - 0.5), Vector3(1.6, 0.05, 0.8), MeshKit.T_CLOTH, roof)          # keset
	# papan lis dinding
	k.box(Vector3(0, 0.25, -d * 0.5 + 0.04), Vector3(w, 0.5, 0.08), T_W, dark)
	k.box(Vector3(-w * 0.5 + 0.04, 0.25, 0), Vector3(0.08, 0.5, d), T_W, dark)
	k.box(Vector3(w * 0.5 - 0.04, 0.25, 0), Vector3(0.08, 0.5, d), T_W, dark)
	# jendela di dinding belakang
	Decor.window(k, -side * 2.6 - 0.0, 1.9, -d * 0.5 + 0.0, 1.2, 1.3, 0.8, Pal.BLUE)
	Decor.window(k, side * 0.6, 1.9, -d * 0.5 + 0.0, 1.2, 1.3, 0.8, Pal.BLUE)
	# karpet
	k.box(Vector3(0, 0.025, 0.6), Vector3(3.6, 0.05, 2.6), MeshKit.T_CLOTH, roof.lightened(0.15))
	k.box(Vector3(0, 0.05, 0.6), Vector3(2.8, 0.04, 1.8), MeshKit.T_CLOTH, wall.darkened(0.05))
	# tempat tidur (pojok belakang, sisi "side")
	var bx := side * (w * 0.5 - 1.3)
	var bz := -d * 0.5 + 1.8
	k.box_b(Vector3(bx, 0, bz), Vector3(2.0, 0.45, 3.2), T_W, dark)
	k.box_b(Vector3(bx, 0.45, bz + 0.05), Vector3(1.8, 0.28, 3.0), MeshKit.T_CLOTH, Color(0.95, 0.96, 1.0))
	k.box_b(Vector3(bx, 0.45, bz + 0.55), Vector3(1.82, 0.3, 2.0), MeshKit.T_CLOTH, roof)                # selimut
	k.box_b(Vector3(bx, 0.73, bz - 1.2), Vector3(1.2, 0.2, 0.6), MeshKit.T_CLOTH, Color(1.0, 1.0, 1.0))  # bantal
	k.box_b(Vector3(bx, 0, bz - 1.6), Vector3(2.0, 1.3, 0.14), T_W, dark)
	sink.box(k.xf, Vector3(bx, 0.35, bz), Vector3(2.0, 0.7, 3.2))
	# meja + bangku
	var tx := -side * 1.5
	var tz := 0.2
	k.box_b(Vector3(tx, 0.78, tz), Vector3(1.9, 0.12, 1.1), T_W, wood)
	for lx in [-0.8, 0.8]:
		for lz in [-0.4, 0.4]:
			k.box_b(Vector3(tx + lx, 0, tz + lz), Vector3(0.12, 0.78, 0.12), T_W, dark)
	sink.box(k.xf, Vector3(tx, 0.45, tz), Vector3(1.9, 0.9, 1.1))
	for sx in [-1.0, 1.0]:
		k.cylinder(Vector3(tx + sx * 0.5, 0, tz + 1.0), 0.28, 0.25, 0.5, 8, T_W, wood, true)
	Decor.potion(k, Vector3(tx - 0.4, 0.84, tz), Color(0.4, 0.8, 1.0), 0.8)
	k.box_b(Vector3(tx + 0.3, 0.84, tz + 0.1), Vector3(0.34, 0.1, 0.26), MeshKit.T_CLOTH, Pal.RED)       # buku
	k.cylinder(Vector3(tx + 0.7, 0.84, tz - 0.15), 0.14, 0.12, 0.18, 8, MeshKit.T_METAL, Pal.IRON, true)   # cangkir
	# perapian di dinding belakang
	var hx := -side * (w * 0.5 - 2.6)
	var hz := -d * 0.5 + 0.5
	k.box_b(Vector3(hx, 0, hz), Vector3(2.2, 1.35, 0.9), MeshKit.T_BRICK, Pal.STONE_DARK)
	k.box_b(Vector3(hx, 0.1, hz + 0.43), Vector3(1.2, 0.8, 0.1), MeshKit.T_METAL, MeshKit.glow(Color(1.0, 0.55, 0.2), 1.0))
	k.box_b(Vector3(hx, 1.35, hz - 0.1), Vector3(1.4, hh - 1.35, 0.6), MeshKit.T_BRICK, Pal.STONE_DARK)
	k.box(Vector3(hx, 1.4, hz), Vector3(2.5, 0.12, 1.0), T_W, dark)                                   # rak di atas perapian
	sink.box(k.xf, Vector3(hx, 0.7, hz), Vector3(2.2, 1.4, 0.9))
	k.box_b(Vector3(hx + 0.9, 0.0, hz + 0.9), Vector3(0.5, 0.4, 0.5), T_W, dark)                       # tumpukan kayu bakar
	# rak buku di dinding samping
	var rx := -side * (w * 0.5 - 0.35)
	k.box_b(Vector3(rx, 0, -0.6), Vector3(0.6, 2.1, 2.4), T_W, dark)
	for i in 6:
		var col := Color.from_hsv(float(i) / 6.0, 0.45, 0.95)
		k.box_b(Vector3(rx + side * 0.33, 0.35 + float(i % 3) * 0.6, -1.5 + float(i) * 0.4), Vector3(0.08, 0.34, 0.2), MeshKit.T_CLOTH, col)
	sink.box(k.xf, Vector3(rx, 1.05, -0.6), Vector3(0.6, 2.1, 2.4))
	# pojok depan: tong, peti, tanaman
	Decor.barrel(k, sink, Vector3(-side * (w * 0.5 - 0.8), 0, d * 0.5 - 0.9))
	Decor.crate(k, sink, Vector3(-side * (w * 0.5 - 0.8), 0, d * 0.5 - 2.0), 0.7, 14.0)
	k.cylinder(Vector3(side * (w * 0.5 - 0.7), 0, d * 0.5 - 0.9), 0.3, 0.24, 0.45, 8, MeshKit.T_BRICK, Pal.ORANGE, true)
	k.blob(Vector3(side * (w * 0.5 - 0.7), 0.85, d * 0.5 - 0.9), 0.42, MeshKit.T_LEAVES, Pal.GREEN, 3, 7)
	sink.cyl(k.xf, Vector3(side * (w * 0.5 - 0.7), 0, d * 0.5 - 0.9), 0.35, 0.5)
	# hiasan dinding: lukisan di atas perapian, perisai di atas tempat tidur
	k.box(Vector3(hx, 2.35, hz + 0.28), Vector3(1.2, 0.8, 0.06), T_W, dark)
	k.box(Vector3(hx, 2.35, hz + 0.32), Vector3(1.0, 0.6, 0.04), MeshKit.T_EMBLEM, Color.WHITE)
	if seed_value % 3 != 0:
		Decor.shield(k, Vector3(bx, 2.4, -d * 0.5 + 0.12), 0.4, roof)
	# tabrakan dinding & lantai
	sink.box(k.xf, Vector3(0, -0.2, 0), Vector3(w + 0.6, 0.4, d + 0.6))
	sink.box(k.xf, Vector3(0, hh * 0.5, -d * 0.5 - 0.15), Vector3(w + 0.6, hh, 0.3))
	sink.box(k.xf, Vector3(-w * 0.5 - 0.15, hh * 0.5, 0), Vector3(0.3, hh, d))
	sink.box(k.xf, Vector3(w * 0.5 + 0.15, hh * 0.5, 0), Vector3(0.3, hh, d))
	sink.box(k.xf, Vector3(0, 1.0, d * 0.5 + 0.15), Vector3(w + 0.6, 2.0, 0.3))
	# pasang
	var m := k.build()
	k.apply_materials(m)
	var mi := MeshInstance3D.new()
	mi.name = "Mesh"
	mi.mesh = m
	add_child(mi)
	var body := StaticBody3D.new()
	body.name = "Body"
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	sink.apply_to(body)
	if Quality.interior_light():
		light = OmniLight3D.new()
		light.position = Vector3(0, 2.6, 0.5)
		light.light_color = Color(1.0, 0.83, 0.6)
		light.light_energy = 1.8
		light.omni_range = 12.0
		light.shadow_enabled = false
		add_child(light)
	spawn = ORIGIN + Vector3(0, 0.1, d * 0.5 - 1.6)
	occupant_pos = Vector2(ORIGIN.x + tx * 0.0 - side * 0.0, ORIGIN.z + 1.9)
	interactions.append({"id": "house_exit", "pos": ORIGIN + Vector3(0, 0, d * 0.5 - 0.3), "action": "house_exit", "prompt": "Keluar rumah", "radius": 1.6})
