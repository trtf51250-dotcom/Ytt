class_name BCommon
extends RefCounted
## Helper bersama untuk semua penyusun bangunan: dinding + pondasi, atap, pintu depan, jendela.
## Konvensi: asal lokal = pusat jejak bangunan di tanah, depan menghadap +Z.

const FOUND_H := 0.4          # tinggi pondasi batu
const FOUND_OUT := 0.18       # pondasi sedikit lebih lebar dari dinding

const T_PLASTER := MeshKit.T_PLASTER
const T_TIMBER := MeshKit.T_TIMBER
const T_BRICK := MeshKit.T_BRICK
const T_WOOD := MeshKit.T_WOOD
const T_ROOF := MeshKit.T_ROOF


## Pondasi + dinding (w sepanjang X, d sepanjang Z, h tinggi dinding di atas pondasi). Mengembalikan y puncak dinding.
## floors > 1 menambah balok pembatas lantai. Tabrakan ditambahkan bila collide = true.
static func shell(b: Building, w: float, d: float, h: float, tile: int = T_PLASTER, col: Color = Color.WHITE, floors: int = 1,
		base_col: Color = Pal.STONE, collide: bool = true, posts: bool = true) -> float:
	var k := b.kit
	k.box_b(Vector3.ZERO, Vector3(w + FOUND_OUT * 2.0, FOUND_H, d + FOUND_OUT * 2.0), T_BRICK, base_col, T_BRICK, base_col, 0.85)
	k.box_b(Vector3(0, FOUND_H, 0), Vector3(w, h, d), tile, col, tile, col, 0.8)
	var top := FOUND_H + h
	if posts:
		for sx in [-1.0, 1.0]:
			for sz in [-1.0, 1.0]:
				k.box_b(Vector3(sx * w * 0.5, FOUND_H, sz * d * 0.5), Vector3(0.3, h + 0.06, 0.3), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	if floors > 1:
		for i in range(1, floors):
			var y := FOUND_H + h * float(i) / float(floors)
			k.box(Vector3(0, y, 0), Vector3(w + 0.14, 0.24, d + 0.14), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	k.box(Vector3(0, top - 0.06, 0), Vector3(w + 0.12, 0.2, d + 0.12), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	if collide:
		b.sink.box(k.xf, Vector3(0, (FOUND_H + h) * 0.5, 0), Vector3(w + FOUND_OUT * 2.0, FOUND_H + h, d + FOUND_OUT * 2.0))
	return top


## Atap pelana (punggung sejajar X) di atas dinding setinggi y.
static func gable(b: Building, w: float, d: float, y: float, rh: float, roof: Color, wall: Color, overhang: float = 0.55,
		wall_tile: int = T_PLASTER) -> void:
	b.kit.gable_roof(Vector3(0, y, 0), w, d, rh, overhang, T_ROOF, roof, wall_tile, wall)


## Pintu di muka depan (z = d/2) dengan tangga pendek. x = posisi horizontal.
static func front_door(b: Building, x: float, d: float, w: float = 1.4, h: float = 2.3) -> void:
	var k := b.kit
	k.push()
	k.move(0, FOUND_H, 0)
	Decor.door(k, x, d * 0.5, w, h, false)
	k.pop()
	b.register_door(x, d * 0.5, w, h)
	# anak tangga (rendah, tanpa tabrakan agar pemain tidak tersangkut)
	k.box(Vector3(x, 0.1, d * 0.5 + FOUND_OUT + 0.45), Vector3(w + 1.0, 0.2, 0.9), T_BRICK, Pal.STONE_DARK, T_BRICK, Pal.STONE, 0.85)


## Jendela pada ketinggian y_above (dari tanah) di muka z = d/2 untuk tiap x di xs.
static func front_windows(b: Building, xs: Array, y: float, d: float, w: float = 1.1, h: float = 1.3, emit: float = 0.7,
		shutter: Color = Pal.WOOD_DARK, flowers: bool = false) -> void:
	for x in xs:
		Decor.window(b.kit, x, y, d * 0.5, w, h, emit, shutter)
		if flowers:
			Decor.flower_box(b.kit, x, y - h * 0.5 - 0.3, d * 0.5 + 0.1, w + 0.5)


## Jendela di sisi kiri/kanan (side = +1 kanan, -1 kiri) pada kedalaman z.
static func side_windows(b: Building, w: float, side: float, zs: Array, y: float, win_w: float = 1.0, win_h: float = 1.25, emit: float = 0.7) -> void:
	var k := b.kit
	for z in zs:
		k.push()
		k.yaw(90.0 * side)
		Decor.window(k, -z * side, y, w * 0.5, win_w, win_h, emit)
		k.pop()


## Cerobong di atas atap pelana (posisi x, z lokal; y dasar = puncak dinding).
static func chimney_on(b: Building, x: float, z: float, top_y: float, h: float = 2.8, glow_top: bool = false) -> void:
	Decor.chimney(b.kit, Vector3(x, top_y + 0.3, z), h, glow_top)


## Jendela bulat kecil di dinding gable (menghadap +Z, di bidang z).
static func round_window(k: MeshKit, c: Vector3, r: float = 0.4, emit: float = 0.7) -> void:
	k.push()
	k.move(c.x, c.y, c.z)
	k.pitch(90.0)
	k.cylinder(Vector3(0, 0, 0), r + 0.12, r + 0.12, 0.12, 10, T_WOOD, Pal.WOOD_DARK, true, T_WOOD, false, 1.0)
	k.cylinder(Vector3(0, 0.1, 0), r, r, 0.04, 10, MeshKit.T_WINDOW, MeshKit.glow(Color.WHITE, emit), true, MeshKit.T_WINDOW, false, 1.0)
	k.pop()


## Papan nama kayu menempel di dinding dengan teks Label3D (koordinat c mengikuti transformasi kit saat ini).
static func sign_board(b: Building, c: Vector3, w: float, h: float, text: String, col: Color = Pal.WOOD, font: Color = Color(1.0, 0.93, 0.7),
		label_size: float = 0.012, font_size: int = 64) -> void:
	var k := b.kit
	k.box(c + Vector3(0, 0, -0.02), Vector3(w + 0.24, h + 0.24, 0.12), T_WOOD, Pal.WOOD_DARK, T_WOOD, Pal.WOOD_DARK, 0.9)
	k.box(c + Vector3(0, 0, 0.04), Vector3(w, h, 0.1), T_WOOD, col, T_WOOD, col, 0.9)
	var wp := k.xf * (c + Vector3(0, 0, 0.12))
	var rot := k.xf.basis.get_euler()
	b.add_label(text, wp, label_size, font, Vector3(rad_to_deg(rot.x), rad_to_deg(rot.y), rad_to_deg(rot.z)), font_size)
