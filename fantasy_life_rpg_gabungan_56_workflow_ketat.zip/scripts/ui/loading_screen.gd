class_name LoadingScreen
extends Control
## Layar memuat bergaya layar judul: langit malam + bulan + pegunungan, logo emas "FANTASY LIFE RPG" di kiri, bar kemajuan berpelat emas
## dan kotak tips. Dipakai oleh autoload Flow. Latar digambar SEKALI; hanya bintang/bara yang digambar ulang ~20 fps selagi layar aktif.

const COL_X := 72.0

var _bg: Control
var _fx: Control
var _status: Label
var _pct: Label
var _fill: Panel
var _bar_bg: Panel
var _tip: Label
var _bar_w := 420.0
var _value := 0.0
var _t := 0.0
var _acc := 0.0
var _stars: Array = []
var _embers: Array = []
var _sky_tex: GradientTexture2D
var _vig_tex: GradientTexture2D
var _top_tex: GradientTexture2D


func _init() -> void:
	theme = UiTheme.get_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	for i in 40:
		_stars.append([Vector2(randf(), randf() * 0.5), randf_range(1.0, 2.6), randf() * TAU])
	for i in 14:
		_embers.append([randf_range(0.35, 1.0), randf_range(0.05, 0.14), randf(), randf_range(1.2, 2.0)])
	_sky_tex = _grad(PackedFloat32Array([0.0, 0.45, 0.78, 1.0]), PackedColorArray([Color(0.01, 0.03, 0.09), Color(0.04, 0.10, 0.22), Color(0.30, 0.20, 0.42), Color(0.58, 0.34, 0.36)]), true)
	_vig_tex = _grad(PackedFloat32Array([0.0, 0.55, 1.0]), PackedColorArray([Color(0.01, 0.015, 0.06, 0.86), Color(0.01, 0.015, 0.06, 0.5), Color(0.01, 0.015, 0.06, 0.0)]), false)
	_top_tex = _grad(PackedFloat32Array([0.0, 1.0]), PackedColorArray([Color(0, 0, 0.04, 0.5), Color(0, 0, 0.04, 0.0)]), true)
	_bg = Control.new()
	_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_bg.draw.connect(_draw_bg)
	_bg.resized.connect(_bg.queue_redraw)
	add_child(_bg)
	_fx = Control.new()
	_fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fx.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fx.draw.connect(_draw_fx)
	add_child(_fx)
	_build_layout()
	set_process(false)


# ---------------------------------------------------------------- API untuk Flow
func set_active(on: bool) -> void:
	set_process(on)
	if on:
		_bg.queue_redraw()


func set_status(text: String) -> void:
	_status.text = text


func set_tip(text: String) -> void:
	_tip.text = text


func set_progress(v: float) -> void:
	_value = clampf(v, 0.0, 1.0)
	_fill.size.x = maxf((_bar_w - 8.0) * _value, 0.0)
	_fill.visible = _value > 0.001
	_pct.text = "%d%%" % int(round(_value * 100.0))


func _process(d: float) -> void:
	_t += d
	_status.modulate.a = 0.8 + 0.2 * sin(_t * 5.0)
	_acc += d
	if _acc >= 1.0 / 20.0:
		_acc = 0.0
		_fx.queue_redraw()


# ---------------------------------------------------------------- tata letak (sama dengan layar judul)
func _font(spacing: int, embolden: float = 0.0) -> FontVariation:
	var f := FontVariation.new()
	f.base_font = ThemeDB.fallback_font
	f.spacing_glyph = spacing
	f.variation_embolden = embolden
	return f


func _grad(offs: PackedFloat32Array, cols: PackedColorArray, vertical: bool) -> GradientTexture2D:
	var g := Gradient.new()
	g.offsets = offs
	g.colors = cols
	var t := GradientTexture2D.new()
	t.gradient = g
	t.fill_from = Vector2(0, 0)
	t.fill_to = Vector2(0, 1) if vertical else Vector2(1, 0)
	t.width = 4 if vertical else 256
	t.height = 256 if vertical else 4
	return t


func _logo_line(text: String, size: int, spacing: int) -> Control:
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(0, size * 1.3)
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var f := _font(spacing, 0.6)
	for i in 2:
		var l := Label.new()
		l.text = text
		l.add_theme_font_override("font", f)
		l.add_theme_font_size_override("font_size", size)
		l.add_theme_color_override("font_color", Color(0.85, 0.98, 1.0) if i == 1 else Color(0.06, 0.26, 0.38))
		l.add_theme_color_override("font_outline_color", Color(0.0, 0.05, 0.1, 0.95))
		l.add_theme_constant_override("outline_size", 3 if i == 1 else 8)
		l.position = Vector2(0.0, 0.0 if i == 1 else 4.0)
		holder.add_child(l)
	return holder


func _fade_line(fade_in: bool) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(30, 22)
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.draw.connect(func():
		var w := c.size.x
		var y := c.size.y * 0.5
		var n := 24
		for i in n:
			var f0 := float(i) / n
			var f1 := float(i + 1) / n
			var a := f0 if fade_in else 1.0 - f0
			c.draw_line(Vector2(w * f0, y), Vector2(w * f1, y), Color(UiTheme.GOLD, a * 0.95), 2.0)
			c.draw_line(Vector2(w * f0, y + 5.0), Vector2(w * f1, y + 5.0), Color(UiTheme.GOLD_DARK, a * 0.5), 1.0))
	return c


## Pelat bergaya tombol menu judul: tepi kiri emas tebal.
func _plate(bg: Color, edge: Color, left_w: int, glow: int, mx: int = 26, my: int = 8) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = edge
	s.border_width_left = left_w
	s.border_width_top = 1
	s.border_width_right = 1
	s.border_width_bottom = 1
	s.set_corner_radius_all(5)
	s.content_margin_left = mx
	s.content_margin_right = 18
	s.content_margin_top = my
	s.content_margin_bottom = my
	if glow > 0:
		s.shadow_color = Color(edge, 0.35)
		s.shadow_size = glow
	s.anti_aliasing = true
	return s


func _build_layout() -> void:
	var m := UiTheme.safe_insets()
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 4)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.set_anchors_and_offsets_preset(Control.PRESET_LEFT_WIDE)
	col.offset_left = COL_X + float(m["left"])
	col.offset_right = COL_X + float(m["left"]) + 580.0
	col.offset_top = 16.0
	col.offset_bottom = -16.0
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(col)

	var logo_font := _font(4, 0.6)
	var logo_w := logo_font.get_string_size("FANTASY LIFE", HORIZONTAL_ALIGNMENT_LEFT, -1, 58).x + 12.0
	_bar_w = clampf(logo_w, 380.0, 460.0)

	var header := VBoxContainer.new()
	header.add_theme_constant_override("separation", 0)
	header.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	header.custom_minimum_size = Vector2(logo_w, 0)
	header.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(header)
	header.add_child(_logo_line("FANTASY LIFE", 58, 4))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row.add_child(_fade_line(true))
	var rpg := UiTheme.label("RPG", 26, Color(0.78, 0.9, 1.0), HORIZONTAL_ALIGNMENT_CENTER)
	rpg.add_theme_font_override("font", _font(14, 0.3))
	row.add_child(rpg)
	row.add_child(_fade_line(false))
	header.add_child(row)
	var sub := UiTheme.label("Kota Aurelia menunggumu", 21, Color(0.72, 0.86, 1.0), HORIZONTAL_ALIGNMENT_CENTER)
	sub.add_theme_font_override("font", _font(2))
	header.add_child(sub)

	var sp := Control.new()
	sp.custom_minimum_size = Vector2(0, 40)
	sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(sp)

	# baris status + persen
	var srow := HBoxContainer.new()
	srow.custom_minimum_size = Vector2(_bar_w, 0)
	srow.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	srow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_status = UiTheme.label("Memuat...", 23, Color(0.9, 0.94, 1.0))
	_status.add_theme_font_override("font", _font(2, 0.15))
	_status.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_status.clip_text = true
	srow.add_child(_status)
	_pct = UiTheme.label("0%", 21, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_RIGHT)
	_pct.add_theme_font_override("font", _font(2, 0.15))
	srow.add_child(_pct)
	col.add_child(srow)

	# bar kemajuan
	_bar_bg = Panel.new()
	_bar_bg.custom_minimum_size = Vector2(_bar_w, 26)
	_bar_bg.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_bar_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bar_bg.add_theme_stylebox_override("panel", _plate(Color(0.02, 0.07, 0.14, 0.78), UiTheme.GOLD_DARK, 3, 0, 0, 0))
	col.add_child(_bar_bg)
	_fill = Panel.new()
	_fill.position = Vector2(5, 5)
	_fill.size = Vector2(0, 16)
	_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fs := StyleBoxFlat.new()
	fs.bg_color = Color(0.5, 0.9, 1.0)
	fs.border_color = Color(0.85, 0.98, 1.0)
	fs.border_width_top = 2
	fs.set_corner_radius_all(3)
	fs.shadow_color = Color(UiTheme.GOLD, 0.4)
	fs.shadow_size = 6
	fs.anti_aliasing = true
	_fill.add_theme_stylebox_override("panel", fs)
	_fill.visible = false
	_bar_bg.add_child(_fill)

	var sp2 := Control.new()
	sp2.custom_minimum_size = Vector2(0, 22)
	sp2.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(sp2)

	# kotak tips
	var tipbox := PanelContainer.new()
	tipbox.custom_minimum_size = Vector2(_bar_w, 0)
	tipbox.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	tipbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tipbox.add_theme_stylebox_override("panel", _plate(Color(0.02, 0.07, 0.14, 0.6), Color(UiTheme.GOLD_DARK, 0.7), 3, 0, 18, 10))
	var tv := VBoxContainer.new()
	tv.add_theme_constant_override("separation", 2)
	tv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tipbox.add_child(tv)
	var cap := UiTheme.label("TIPS", 15, UiTheme.GOLD)
	cap.add_theme_font_override("font", _font(5, 0.3))
	tv.add_child(cap)
	_tip = UiTheme.label("", 19, Color(0.78, 0.88, 1.0))
	_tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_tip.custom_minimum_size = Vector2(_bar_w - 40.0, 52)
	tv.add_child(_tip)
	col.add_child(tipbox)


# ---------------------------------------------------------------- latar malam (digambar sekali)
func _ridge(c: Control, s: Vector2, base: float, amp: float, seed_v: float, col: Color) -> void:
	var pts := PackedVector2Array()
	pts.append(Vector2(0, s.y))
	var n := 48
	for i in n + 1:
		var f := float(i) / n
		var h := sin(f * 5.1 + seed_v) * 0.5 + sin(f * 11.3 + seed_v * 2.1) * 0.3 + sin(f * 23.7 + seed_v * 3.7) * 0.2
		pts.append(Vector2(f * s.x, s.y * base - h * amp * s.y))
	pts.append(Vector2(s.x, s.y))
	c.draw_colored_polygon(pts, col)


func _pine(c: Control, x: float, base: float, h: float, col: Color) -> void:
	var w := h * 0.42
	c.draw_rect(Rect2(x - w * 0.04, base - h * 0.1, w * 0.08, h * 0.12), col)
	for i in 4:
		var top := base - h + float(i) * h * 0.2
		var bot := top + h * 0.38
		var hw := w * (0.35 + float(i) * 0.22) * 0.5
		c.draw_colored_polygon(PackedVector2Array([Vector2(x, top), Vector2(x + hw, bot), Vector2(x - hw, bot)]), col)


func _draw_bg() -> void:
	var c := _bg
	var s := c.size
	if s.x < 8.0 or s.y < 8.0:
		return
	var u := s.y
	var rng := RandomNumberGenerator.new()
	rng.seed = 20240
	c.draw_texture_rect(_sky_tex, Rect2(Vector2.ZERO, s), false)
	# bulan + cahaya
	var mp := Vector2(s.x * 0.8, 0.2 * u)
	for i in 9:
		c.draw_circle(mp, u * 0.05 * (1.0 + float(i) * 0.55), Color(0.75, 0.82, 1.0, 0.03))
	c.draw_circle(mp, u * 0.05, Color(0.96, 0.95, 0.86))
	c.draw_circle(mp + Vector2(-0.013, 0.009) * u, u * 0.013, Color(0.85, 0.84, 0.75))
	c.draw_circle(mp + Vector2(0.015, -0.013) * u, u * 0.009, Color(0.86, 0.85, 0.77))
	# pegunungan berlapis + pendar hangat di kaki langit
	_ridge(c, s, 0.62, 0.08, 1.3, Color(0.10, 0.16, 0.27))
	for i in 7:
		c.draw_circle(Vector2(s.x * 0.74, 0.8 * u), u * (0.7 - float(i) * 0.08), Color(1.0, 0.6, 0.25, 0.026))
	_ridge(c, s, 0.74, 0.07, 4.1, Color(0.06, 0.11, 0.20))
	_ridge(c, s, 0.87, 0.05, 7.7, Color(0.03, 0.06, 0.10))
	# pohon latar depan
	var tcol := Color(0.025, 0.03, 0.07)
	for i in 5:
		_pine(c, rng.randf_range(-0.01, 0.2) * s.x, s.y + 0.02 * u, rng.randf_range(0.2, 0.34) * u, tcol)
	for i in 5:
		_pine(c, rng.randf_range(0.62, 1.02) * s.x, s.y + 0.02 * u, rng.randf_range(0.14, 0.3) * u, tcol)
	# vinyet kiri (agar teks terbaca), atas, bawah
	c.draw_texture_rect(_vig_tex, Rect2(0, 0, s.x * 0.62, s.y), false)
	c.draw_texture_rect(_top_tex, Rect2(0, 0, s.x, u * 0.22), false)
	c.draw_texture_rect(_top_tex, Rect2(0, s.y, s.x, -u * 0.16), false)


func _draw_fx() -> void:
	var s := _fx.size
	if s.x < 8.0 or s.y < 8.0:
		return
	var u := s.y
	var t := _t
	for st in _stars:
		var p: Vector2 = st[0]
		var sz: float = st[1]
		var tw := 0.5 + 0.5 * sin(t * (1.2 + sz * 0.5) + float(st[2]))
		var pos := Vector2(p.x * s.x, p.y * s.y)
		var col := Color(1.0, 0.97, 0.88, 0.25 + 0.7 * tw)
		_fx.draw_circle(pos, sz, col)
		if sz > 2.3:
			var l := sz * (3.0 + 3.0 * tw)
			_fx.draw_line(pos - Vector2(l, 0), pos + Vector2(l, 0), Color(col, col.a * 0.5), 1.0)
			_fx.draw_line(pos - Vector2(0, l), pos + Vector2(0, l), Color(col, col.a * 0.5), 1.0)
	for e in _embers:
		var ep := fposmod(t * float(e[1]) + float(e[2]), 1.0)
		var epos := Vector2(float(e[0]) * s.x + sin(t * 0.9 + float(e[2]) * 6.28) * 0.02 * u, lerpf(s.y * 0.97, s.y * 0.3, ep))
		var ea := sin(ep * PI) * (0.6 + 0.4 * sin(t * 4.0 + float(e[2]) * 20.0))
		_fx.draw_circle(epos, float(e[3]) * 3.2, Color(1.0, 0.7, 0.3, ea * 0.12))
		_fx.draw_circle(epos, float(e[3]), Color(1.0, 0.85, 0.5, ea * 0.9))
