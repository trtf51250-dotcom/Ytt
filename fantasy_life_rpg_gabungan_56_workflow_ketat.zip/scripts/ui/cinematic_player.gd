class_name CinematicPlayer
extends CanvasLayer
## Sinematik cerita: panggung 3D kecil (SubViewport dunia sendiri, resolusi penuh layar logis; kualitas Lancar sedikit diturunkan agar ringan di HP) dengan kamera bergerak, aktor
## memakai CharacterRig yang sama dengan di game (pose/animasi per karakter), cahaya/efek sederhana, bar sinematik, kartu judul,
## dan subtitle bergaya film. Data di data/cinematics.json. Ketuk = lanjut baris, "Lewati" = tutup. Baris juga maju otomatis.
##
## Pakai lewat StoryPlayer.play(): adegan di data/story.json yang punya kunci "cine" memutar sinematik ini; bila gagal dimuat,
## kotak dialog biasa tetap dipakai (adegan tidak pernah hilang).

const PATH := "res://data/cinematics.json"
const BAR_TOP := 64.0
const BAND_BOTTOM := 190.0
const NPC_ALIAS := {"orwen": "aion"}                       # tokoh cerita yang tidak punya karakter sendiri memakai model yang cocok

signal finished
signal line_shown(text: String)

static var fast := false                              # hanya uji otomatis: baris maju cepat

static var _data: Dictionary = {}
static var _loaded := false

var _cid := ""
var _spec: Dictionary = {}
var _root: Control
var _vpc: SubViewportContainer
var _vp: SubViewport
var _world: Node3D
var _cam: Camera3D
var _lights: Array[Light3D] = []
var _actors: Dictionary = {}
var _fade: ColorRect
var _bar_top: ColorRect
var _band: Control
var _name: Label
var _text: RichTextLabel
var _title_box: Control
var _tap := false
var _skip := false
var _was_paused := false
var _done := false
var _typing := false
var _tween: Tween
# kamera
var _ca := Vector3.ZERO
var _cb := Vector3.ZERO
var _la := Vector3.ZERO
var _lb := Vector3.ZERO
var _ct := 0.0
var _cdur := 5.0
var _shake := 0.0
var _ease := "sine"                     # kurva gerak kamera per shot: sine | linear | in | out | inout (sine = default lama)
var _fov_a := 42.0
var _fov_b := 42.0
var _roll := 0.0                        # derajat kemiringan di akhir shot
var _arc := 0.0                         # derajat orbit kamera mengelilingi titik pandang selama shot
var _hand := 0.0                        # kekuatan getaran tangan (0 = mati)
var _flicker := 0.0
var _t_total := 0.0
var _moving: Array = []                                      # [{rig, from, to, t, dur}]


static func load_data() -> Dictionary:
	if not _loaded:
		_loaded = true
		var d = JSON.parse_string(FileAccess.get_file_as_string(PATH)) if FileAccess.file_exists(PATH) else null
		if d is Dictionary and d.get("cinematics") is Dictionary:
			_data = d["cinematics"]
	return _data


static func has_cinematic(id: String) -> bool:
	if OS.get_cmdline_user_args().has("--nocine=1"):      # uji: paksa dialog biasa (story_bot)
		return false
	return load_data().has(id)


## Putar sinematik id. Mengembalikan true bila diputar sampai tutup (kembali setelah selesai/dilewati).
static func play(host: Node, id: String) -> void:
	var cp := CinematicPlayer.new()
	cp._cid = id
	cp._spec = load_data()[id]
	host.get_tree().root.add_child.call_deferred(cp)
	await cp.finished
	cp.queue_free()


func _ready() -> void:
	layer = 41
	process_mode = Node.PROCESS_MODE_ALWAYS
	_was_paused = get_tree().paused
	get_tree().paused = true
	_build_ui()
	_build_world()
	_run()


# =====================================================================
#  UI
# =====================================================================
func _build_ui() -> void:
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.theme = UiTheme.get_theme()
	_root.gui_input.connect(_on_input)
	add_child(_root)
	var black := ColorRect.new()
	black.color = Color.BLACK
	black.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	black.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(black)
	_vpc = SubViewportContainer.new()
	_vpc.stretch = true
	_vpc.stretch_shrink = 1                                    # dulu 2: dengan stretch canvas_items itu hanya ~640x360 piksel yang direnggangkan ke layar penuh (sangat buram)
	_vpc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_vpc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_vpc)
	_vp = SubViewport.new()
	_vp.own_world_3d = true
	_vp.msaa_3d = Viewport.MSAA_2X if Quality.level() >= 2 else Viewport.MSAA_DISABLED      # tepi pilar/karakter halus di kualitas Bagus
	if Quality.level() == 0:
		_vp.scaling_3d_scale = 0.75                                                        # perangkat lemah: sedikit lebih ringan, tetap jauh di atas 640x360 lama
	_vp.use_debanding = Quality.level() >= 1                                              # langit/kabut sinematik tanpa garis pita warna
	_vp.handle_input_locally = false
	_vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	_vpc.add_child(_vp)
	# bar atas + pita subtitle bawah (gradasi gelap)
	_bar_top = ColorRect.new()
	_bar_top.color = Color(0, 0, 0, 1)
	_bar_top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_bar_top.offset_bottom = 0.0
	_bar_top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_bar_top)
	_band = Control.new()
	_band.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_band.offset_top = -BAND_BOTTOM
	_band.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_band.modulate.a = 0.0
	_root.add_child(_band)
	var grad := Gradient.new()
	grad.set_color(0, Color(0, 0, 0, 0))
	grad.set_color(1, Color(0.01, 0.015, 0.05, 0.92))
	grad.set_offset(0, 0.0)
	grad.set_offset(1, 0.55)
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	gt.width = 4
	gt.height = 64
	var gr := TextureRect.new()
	gr.texture = gt
	gr.stretch_mode = TextureRect.STRETCH_SCALE
	gr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	gr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_band.add_child(gr)
	var v := VBoxContainer.new()
	v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	v.offset_left = 70
	v.offset_right = -70
	v.offset_top = 44
	v.offset_bottom = -18
	v.add_theme_constant_override("separation", 4)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_band.add_child(v)
	_name = UiTheme.label("", 25, UiTheme.GOLD)
	_name.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_name.add_theme_constant_override("outline_size", 6)
	_name.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(_name)
	_text = RichTextLabel.new()
	_text.bbcode_enabled = false
	_text.scroll_active = false
	_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_text.add_theme_font_size_override("normal_font_size", 23)
	_text.add_theme_color_override("default_color", Color(0.96, 0.97, 1.0))
	_text.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_text.add_theme_constant_override("outline_size", 5)
	_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(_text)
	# kartu judul
	_title_box = Control.new()
	_title_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_title_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_title_box.modulate.a = 0.0
	_root.add_child(_title_box)
	var tv := VBoxContainer.new()
	tv.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	tv.offset_left = -420
	tv.offset_right = 420
	tv.offset_top = -70
	tv.offset_bottom = 70
	tv.alignment = BoxContainer.ALIGNMENT_CENTER
	tv.add_theme_constant_override("separation", 8)
	tv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_title_box.add_child(tv)
	var ch := str(_spec.get("chapter", ""))
	if ch != "":
		var cl := UiTheme.label(ch, 21, UiTheme.SKY, HORIZONTAL_ALIGNMENT_CENTER)
		cl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tv.add_child(cl)
	var tl := UiTheme.label(str(_spec.get("title", "")), 38, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	tl.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.95))
	tl.add_theme_constant_override("outline_size", 10)
	tl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tv.add_child(tl)
	_fade = ColorRect.new()
	_fade.color = Color(0, 0, 0, 1)
	_fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_fade)
	var skip := UiTheme.button("Lewati", Vector2(120, 44))
	skip.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	skip.offset_left = -140
	skip.offset_right = -20
	skip.offset_top = 10
	skip.offset_bottom = 54
	skip.pressed.connect(func(): _skip = true)
	_root.add_child(skip)


func _on_input(ev: InputEvent) -> void:
	if (ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT) or (ev is InputEventScreenTouch and ev.pressed):
		_tap = true


func _unhandled_key_input(ev: InputEvent) -> void:
	if ev is InputEventKey and ev.pressed and ev.keycode in [KEY_SPACE, KEY_ENTER]:
		_tap = true


# =====================================================================
#  Dunia 3D
# =====================================================================
func _mat(c: Color, emit: float = 0.0, rough: float = 0.9) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emit
	return m


func _mesh(parent: Node, mesh: Mesh, pos: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func _box(parent: Node, size: Vector3, pos: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var b := BoxMesh.new()
	b.size = size
	return _mesh(parent, b, pos, mat, rot_deg)


func _cyl(parent: Node, r_top: float, r_bot: float, h: float, pos: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var c := CylinderMesh.new()
	c.top_radius = r_top
	c.bottom_radius = r_bot
	c.height = h
	c.radial_segments = 12
	c.rings = 1
	return _mesh(parent, c, pos, mat, rot_deg)


func _omni(parent: Node, pos: Vector3, col: Color, energy: float, rng: float) -> OmniLight3D:
	var l := OmniLight3D.new()
	l.position = pos
	l.light_color = col
	l.light_energy = energy
	l.omni_range = rng
	l.shadow_enabled = false
	parent.add_child(l)
	_lights.append(l)
	return l


var _dot_cache: GradientTexture2D = null


func _dot_tex() -> GradientTexture2D:
	if _dot_cache == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.set_color(1, Color(1, 1, 1, 0))
		_dot_cache = GradientTexture2D.new()
		_dot_cache.gradient = g
		_dot_cache.fill = GradientTexture2D.FILL_RADIAL
		_dot_cache.fill_from = Vector2(0.5, 0.5)
		_dot_cache.fill_to = Vector2(0.5, 0.0)
		_dot_cache.width = 32
		_dot_cache.height = 32
	return _dot_cache


func _stars(parent: Node, count: int, area: Vector3, col: Color, size: float, up: bool = false) -> void:
	var p := CPUParticles3D.new()
	p.amount = count
	p.lifetime = 8.0
	p.preprocess = 8.0
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = area
	p.gravity = Vector3(0, 0.25 if up else 0.0, 0)
	p.direction = Vector3(0, 1, 0)
	p.spread = 180.0
	p.initial_velocity_min = 0.05
	p.initial_velocity_max = 0.3
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.albedo_color = col
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_texture = _dot_tex()                  # titik bulat lembut, bukan kotak
	q.material = m
	p.mesh = q
	parent.add_child(p)


func _stone_tex(base: Color, vary: float, block: int, mortar: float) -> ImageTexture:
	## Tekstur batu/ubin kecil (dibuat sekali lewat kode, tanpa aset) untuk lantai & dinding.
	var n := 64
	var img := Image.create(n, n, false, Image.FORMAT_RGB8)
	var rng := RandomNumberGenerator.new()
	rng.seed = int(base.r * 255.0) * 31 + block
	var tone := {}
	for y in n:
		for x in n:
			var bx := x / block
			var by := y / block + (bx % 2 if block < 32 else 0)
			var k := Vector2i(bx, by)
			if not tone.has(k):
				tone[k] = 1.0 + rng.randf_range(-vary, vary)
			var c: Color = base * float(tone[k]) * (1.0 + rng.randf_range(-0.05, 0.05))
			if x % block == 0 or y % block == 0:
				c = base * mortar
			c.a = 1.0
			img.set_pixel(x, y, c)
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


func _tex_mat(tex: Texture2D, tile: float, tint: Color = Color.WHITE, emit_col: Color = Color.BLACK, emit: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.albedo_color = tint
	m.uv1_triplanar = true
	m.uv1_scale = Vector3(tile, tile, tile)
	m.roughness = 0.9
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = emit_col
		m.emission_energy_multiplier = emit
	return m


func _sky_env(env: Environment, top: Color, horizon: Color, ground: Color) -> void:
	var sky := Sky.new()
	var pm := ProceduralSkyMaterial.new()
	pm.sky_top_color = top
	pm.sky_horizon_color = horizon
	pm.ground_horizon_color = horizon
	pm.ground_bottom_color = ground
	pm.sun_angle_max = 0.0
	pm.sky_energy_multiplier = 1.0
	sky.sky_material = pm
	sky.radiance_size = Sky.RADIANCE_SIZE_32
	env.sky = sky
	env.background_mode = Environment.BG_SKY


func _build_world() -> void:
	_world = Node3D.new()
	_vp.add_child(_world)
	var set_id := str(_spec.get("set", "plaza"))
	var env := Environment.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.fog_enabled = true
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var sun := DirectionalLight3D.new()
	sun.shadow_enabled = false
	_world.add_child(sun)
	match set_id:
		"cave":
			env.background_mode = Environment.BG_COLOR
			env.background_color = Color(0.03, 0.02, 0.07)
			env.ambient_light_color = Color(0.35, 0.3, 0.6)
			env.ambient_light_energy = 0.6
			env.fog_light_color = Color(0.1, 0.06, 0.2)
			env.fog_density = 0.03
			sun.light_color = Color(0.55, 0.5, 0.95)
			sun.light_energy = 0.4
		"altar":
			_sky_env(env, Color(0.02, 0.01, 0.08), Color(0.22, 0.1, 0.34), Color(0.03, 0.02, 0.06))
			env.ambient_light_color = Color(0.4, 0.3, 0.6)
			env.ambient_light_energy = 0.5
			env.fog_light_color = Color(0.12, 0.06, 0.2)
			env.fog_density = 0.02
			sun.light_color = Color(0.7, 0.6, 1.0)
			sun.light_energy = 0.35
		"tower":
			env.background_mode = Environment.BG_COLOR
			env.background_color = Color(0.1, 0.02, 0.04)
			env.ambient_light_color = Color(0.7, 0.35, 0.4)
			env.ambient_light_energy = 0.55
			env.fog_light_color = Color(0.25, 0.04, 0.08)
			env.fog_density = 0.016
			sun.light_color = Color(1.0, 0.5, 0.45)
			sun.light_energy = 0.5
		_:
			_sky_env(env, Color(0.01, 0.04, 0.12), Color(0.12, 0.27, 0.36), Color(0.02, 0.06, 0.10))
			env.ambient_light_color = Color(0.45, 0.55, 0.95)
			env.ambient_light_energy = 0.65
			env.fog_light_color = Color(0.06, 0.16, 0.24)
			env.fog_density = 0.01
			sun.light_color = Color(0.7, 0.8, 1.0)
			sun.light_energy = 0.7
	sun.rotation_degrees = Vector3(-42, -28, 0)
	var we := WorldEnvironment.new()
	we.environment = env
	_world.add_child(we)
	_cam = Camera3D.new()
	_cam.fov = 42.0
	_cam.far = 140.0
	_world.add_child(_cam)
	_cam.current = true
	match set_id:
		"cave": _set_cave()
		"altar": _set_altar()
		"tower": _set_tower()
		_: _set_plaza()


func _crystal(parent: Node, pos: Vector3, h: float, col: Color, tilt: Vector3 = Vector3.ZERO, energy: float = 1.6) -> void:
	var c := CylinderMesh.new()
	c.top_radius = 0.0
	c.bottom_radius = h * 0.22
	c.height = h
	c.radial_segments = 5
	c.rings = 1
	_mesh(parent, c, pos + Vector3(0, h * 0.5, 0), _mat(col, energy, 0.3), tilt)


## Gugus kristal: satu kristal besar dikelilingi kristal kecil + cahaya di lantai.
func _crystal_cluster(pos: Vector3, h: float, col: Color, rng: RandomNumberGenerator, energy: float = 1.2) -> void:
	_crystal(_world, pos, h, col, Vector3(rng.randf_range(-8, 8), 0, rng.randf_range(-8, 8)), energy)
	for k in 3:
		var a := rng.randf() * TAU
		var r := h * 0.28
		_crystal(_world, pos + Vector3(cos(a) * r, 0, sin(a) * r), h * rng.randf_range(0.35, 0.6), col.lightened(0.15), Vector3(cos(a) * 24.0, 0, sin(a) * 24.0), energy)
	var disc := CylinderMesh.new()
	disc.top_radius = h * 0.55
	disc.bottom_radius = h * 0.55
	disc.height = 0.02
	disc.radial_segments = 12
	var m := _mat(Color(col.r, col.g, col.b, 0.35), 0.8, 1.0)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_mesh(_world, disc, pos + Vector3(0, 0.02, 0), m)


## Rumah kota: dinding batu, atap pelana, pintu, jendela menyala, cerobong.
func _house(pos: Vector3, yaw: float, w: float, h: float, d: float, wall: Material, roof: Material, glow: Material, door: Material) -> void:
	var root := Node3D.new()
	root.position = pos
	root.rotation.y = yaw
	_world.add_child(root)
	_box(root, Vector3(w, h, d), Vector3(0, h * 0.5, 0), wall)
	var rh := w * 0.42
	var pr := PrismMesh.new()
	pr.size = Vector3(w + 0.9, rh, d + 0.9)
	pr.left_to_right = 0.5
	_mesh(root, pr, Vector3(0, h + rh * 0.5, 0), roof)
	_box(root, Vector3(0.7, rh * 0.9, 0.7), Vector3(w * 0.28, h + rh * 0.6, d * 0.2), wall)     # cerobong
	_box(root, Vector3(1.0, 1.9, 0.12), Vector3(0, 0.95, -d * 0.5 - 0.04), door)
	_box(root, Vector3(1.3, 0.14, 0.4), Vector3(0, 2.0, -d * 0.5 - 0.15), roof)                  # kanopi pintu
	var floors := maxi(1, int(h / 2.6))
	for fl in floors:
		var y := 1.2 + float(fl) * 2.5 + (1.0 if fl == 0 else 0.4)
		var nwin := maxi(1, int(w / 2.2))
		for i in nwin:
			var x := (float(i) - float(nwin - 1) * 0.5) * 2.0
			if fl == 0 and absf(x) < 1.1:
				continue
			_box(root, Vector3(0.7, 0.9, 0.1), Vector3(x, y, -d * 0.5 - 0.03), glow)
			_box(root, Vector3(0.9, 0.1, 0.2), Vector3(x, y - 0.5, -d * 0.5 - 0.08), wall)


func _tree(pos: Vector3, h: float, leaf: Material, trunk: Material) -> void:
	_cyl(_world, 0.12, 0.2, h * 0.4, pos + Vector3(0, h * 0.2, 0), trunk)
	for i in 3:
		var r := h * (0.34 - 0.07 * float(i))
		_cyl(_world, 0.0, r, h * 0.42, pos + Vector3(0, h * (0.38 + 0.22 * float(i)), 0), leaf)


func _set_plaza() -> void:
	var cobble := _stone_tex(Color(0.36, 0.38, 0.5), 0.12, 8, 0.55)
	var wall_tex := _stone_tex(Color(0.3, 0.3, 0.42), 0.1, 16, 0.82)
	var stone := _tex_mat(cobble, 0.25)
	var wall := _tex_mat(wall_tex, 0.22)
	var roof := _mat(Color(0.08, 0.19, 0.30), 0.0, 0.8)
	var roof2 := _mat(Color(0.3, 0.14, 0.2), 0.0, 0.8)
	var glow := _mat(Color(1.0, 0.66, 0.26), 1.0)       # jendela hangat (bukan putih silau)
	var door := _mat(Color(0.2, 0.12, 0.1))
	var blue := Color(0.45, 0.75, 1.0)
	# tanah luas (tidak ada tepi terlihat) + jalan melingkar
	_box(_world, Vector3(110, 0.4, 110), Vector3(0, -0.2, 0), _tex_mat(_stone_tex(Color(0.2, 0.28, 0.24), 0.08, 16, 0.8), 0.18))
	_cyl(_world, 11.0, 11.0, 0.12, Vector3(0, 0.05, -2.0), stone)
	_cyl(_world, 6.5, 6.5, 0.16, Vector3(0, 0.08, -7.0), _tex_mat(cobble, 0.4, Color(1.15, 1.15, 1.3)))
	_box(_world, Vector3(4.0, 0.1, 30.0), Vector3(0, 0.05, 16.0), stone)                       # jalan ke arah kamera
	# air mancur + Kristal Bintang melayang
	_cyl(_world, 3.2, 3.5, 0.7, Vector3(0, 0.35, -7), stone)
	_cyl(_world, 2.5, 2.5, 0.2, Vector3(0, 0.78, -7), _mat(Color(0.2, 0.45, 0.85), 0.6, 0.2))
	_cyl(_world, 0.5, 0.7, 1.4, Vector3(0, 1.4, -7), stone)
	_crystal(_world, Vector3(0, 2.3, -7), 3.2, blue, Vector3(0, 0, 0), 1.0)
	_omni(_world, Vector3(0, 3.2, -6.5), blue, 2.4, 22.0)
	_omni(_world, Vector3(0, 1.4, 1.0), Color(0.6, 0.7, 1.0), 0.6, 9.0)
	# lampu jalan
	for i in 6:
		var a := TAU * float(i) / 6.0 + 0.3
		var p := Vector3(cos(a) * 11.0, 0, sin(a) * 11.0 - 2.0)
		_cyl(_world, 0.08, 0.1, 3.4, p + Vector3(0, 1.7, 0), _mat(Color(0.12, 0.19, 0.20)))
		var s := SphereMesh.new()
		s.radius = 0.22
		s.height = 0.44
		_mesh(_world, s, p + Vector3(0, 3.5, 0), _mat(Color(1.0, 0.85, 0.5), 3.0))
		_omni(_world, p + Vector3(0, 3.4, 0), Color(1.0, 0.82, 0.5), 0.9, 8.0)
	# bangunan fantasi yang sama dengan lobi (pondok, rumah kayu dua lantai, rumah menara, rumah sayap silang), melingkar menghadap alun-alun
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var roofs := [Color(0.92, 0.36, 0.32), Color(0.32, 0.55, 0.95), Color(0.95, 0.62, 0.25), Color(0.35, 0.72, 0.62), Color(0.7, 0.45, 0.9)]
	var walls := [Color(1.0, 0.96, 0.88), Color(0.98, 0.9, 0.78), Color(0.9, 0.95, 1.0), Color(1.0, 0.92, 0.92)]
	var kinds := ["house_a", "house_b", "house_c", "house_d"]
	for ring in 2:
		var cnt := 11 if ring == 0 else 15
		for i in cnt:
			var a := TAU * (float(i) + 0.5 * float(ring)) / float(cnt)
			if ring == 0 and absf(wrapf(a - PI * 0.5, -PI, PI)) < 0.3:
				continue                                                                         # celah jalan masuk
			var dd := 19.0 + rng.randf() * 1.5 + float(ring) * 11.0
			var pp := Vector3(cos(a) * dd, 0, sin(a) * dd - 2.0)
			var bd := Building.new()
			bd.kind = kinds[(i + ring * 2) % 4]
			bd.seed_value = 3 + i + ring * 20
			bd.roof_color = roofs[rng.randi() % roofs.size()]
			bd.wall_color = walls[rng.randi() % walls.size()]
			bd.position = pp
			bd.rotation_degrees = Vector3(0, rad_to_deg(atan2(-pp.x, -(pp.z + 2.0))), 0)
			_world.add_child(bd)
	# balai serikat (guild) megah + menara di belakang air mancur
	var gd := Building.new()
	gd.kind = "guild"
	gd.seed_value = 1
	gd.roof_color = Color(0.32, 0.55, 0.95)
	gd.position = Vector3(0, 0, -30.0)
	_world.add_child(gd)
	var tw := Building.new()
	tw.kind = "tower"
	tw.seed_value = 6
	tw.position = Vector3(-17.0, 0, -26.0)
	tw.rotation_degrees = Vector3(0, 35, 0)
	_world.add_child(tw)
	_omni(_world, Vector3(0, 8.0, -22.0), Color(1.0, 0.85, 0.55), 1.0, 14.0)
	# pohon di antara rumah
	var leaf := _mat(Color(0.1, 0.3, 0.26))
	var trunk := _mat(Color(0.25, 0.17, 0.12))
	for i in 14:
		var a := rng.randf() * TAU
		var dd := 13.5 + rng.randf() * 2.0
		if absf(wrapf(a - PI * 0.5, -PI, PI)) < 0.3:
			continue
		_tree(Vector3(cos(a) * dd, 0, sin(a) * dd - 2.0), 2.6 + rng.randf() * 1.6, leaf, trunk)
	# bulan + gunung jauh
	var moon := SphereMesh.new()
	moon.radius = 3.0
	moon.height = 6.0
	var mm := _mat(Color(0.9, 0.95, 1.0), 2.5)
	mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_mesh(_world, moon, Vector3(-26, 30, -90), mm)
	for i in 7:
		var cone := CylinderMesh.new()
		cone.top_radius = 0.0
		cone.bottom_radius = 16.0 + rng.randf() * 8.0
		cone.height = 16.0 + rng.randf() * 12.0
		cone.radial_segments = 7
		_mesh(_world, cone, Vector3(-60.0 + float(i) * 20.0, cone.height * 0.5 - 1.0, -75.0 - rng.randf() * 10.0), _mat(Color(0.05, 0.10, 0.14)))
	_stars(_world, 70, Vector3(14, 6, 14), Color(0.8, 0.9, 1.0, 0.9), 0.09, true)


func _set_cave() -> void:
	var cols := [Color(0.45, 0.6, 1.0), Color(0.7, 0.45, 1.0), Color(0.4, 0.85, 1.0)]
	var rock_tex := _stone_tex(Color(0.2, 0.17, 0.28), 0.18, 16, 0.6)
	var rock := _tex_mat(rock_tex, 0.2)
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	_box(_world, Vector3(70, 0.5, 70), Vector3(0, -0.25, 0), _tex_mat(_stone_tex(Color(0.17, 0.14, 0.24), 0.2, 8, 0.7), 0.2))
	# dinding gua melingkar (pilar batu tidak beraturan) agar tidak ada ruang kosong di belakang
	for i in 26:
		var a := TAU * float(i) / 26.0 + rng.randf() * 0.1
		var dd := 17.0 + rng.randf() * 4.0
		var hh := 9.0 + rng.randf() * 7.0
		var w := 4.0 + rng.randf() * 3.0
		_box(_world, Vector3(w, hh, w), Vector3(cos(a) * dd, hh * 0.5 - 0.5, sin(a) * dd - 2.0), rock, Vector3(rng.randf_range(-5, 5), rad_to_deg(a), rng.randf_range(-5, 5)))
	# langit-langit
	var dome := SphereMesh.new()
	dome.radius = 26.0
	dome.height = 52.0
	dome.radial_segments = 16
	dome.rings = 8
	var dm := _tex_mat(rock_tex, 0.08, Color(0.8, 0.8, 1.0))
	dm.cull_mode = BaseMaterial3D.CULL_FRONT
	_mesh(_world, dome, Vector3(0, 8.0, -2.0), dm)
	# gugus kristal
	for i in 14:
		var a := rng.randf() * TAU
		var dd := 5.5 + rng.randf() * 9.0
		_crystal_cluster(Vector3(cos(a) * dd, 0, sin(a) * dd - 2.0), 1.4 + rng.randf() * 2.8, cols[i % 3], rng, 1.3)
	for i in 6:
		var a := TAU * float(i) / 6.0
		_omni(_world, Vector3(cos(a) * 7.5, 1.6, sin(a) * 7.5 - 2.0), cols[i % 3], 1.3, 10.0)
	for i in 18:
		var a := rng.randf() * TAU
		var dd := 3.0 + rng.randf() * 12.0
		var c := CylinderMesh.new()
		c.top_radius = 0.0
		c.bottom_radius = 0.5 + rng.randf() * 0.4
		c.height = 2.5 + rng.randf() * 3.0
		c.radial_segments = 6
		_mesh(_world, c, Vector3(cos(a) * dd, 11.5 - c.height * 0.5, sin(a) * dd - 2.0), rock, Vector3(180, 0, 0))   # stalaktit
	_stars(_world, 50, Vector3(10, 3, 10), Color(0.7, 0.7, 1.0, 0.8), 0.07, true)


func _set_altar() -> void:
	var purple := Color(0.7, 0.45, 1.0)
	var slab := _stone_tex(Color(0.2, 0.17, 0.3), 0.1, 16, 0.5)
	var stone := _tex_mat(slab, 0.25)
	var dark := _tex_mat(_stone_tex(Color(0.13, 0.11, 0.2), 0.1, 32, 0.6), 0.2)
	var rune := _mat(purple, 1.6)
	_box(_world, Vector3(110, 0.4, 110), Vector3(0, -0.2, 0), dark)
	# altar bertingkat + cincin rune bercahaya
	_cyl(_world, 6.0, 6.4, 0.3, Vector3(0, 0.15, -6), stone)
	_cyl(_world, 4.6, 5.0, 0.3, Vector3(0, 0.45, -6), stone)
	_cyl(_world, 3.2, 3.6, 0.3, Vector3(0, 0.75, -6), stone)
	for rr in [5.7, 4.3, 2.9]:
		var tor := TorusMesh.new()
		tor.inner_radius = rr - 0.05
		tor.outer_radius = rr + 0.05
		tor.rings = 24
		tor.ring_segments = 4
		_mesh(_world, tor, Vector3(0, 0.31 + (5.7 - rr) * 0.107, -6), rune)
	for i in 12:                                                                       # prasasti rune di sekeliling
		var a := TAU * float(i) / 12.0
		_box(_world, Vector3(0.5, 0.05, 0.2), Vector3(cos(a) * 5.0, 0.33, sin(a) * 5.0 - 6.0), rune, Vector3(0, -rad_to_deg(a), 0))
	# pilar bertapak & berkepala, dua kristal kecil melayang di atasnya
	for i in 8:
		var a := TAU * float(i) / 8.0
		if absf(wrapf(a - PI * 0.5, -PI, PI)) < 0.4:
			continue                                                                   # celah di sisi kamera: tanpa ini satu pilar berdiri tepat di antara kamera dan tokoh
		var pp := Vector3(cos(a) * 8.6, 0, sin(a) * 8.6 - 6.0)
		_cyl(_world, 0.55, 0.65, 0.5, pp + Vector3(0, 0.25, 0), dark)
		_cyl(_world, 0.34, 0.4, 5.0, pp + Vector3(0, 3.0, 0), stone)
		_cyl(_world, 0.6, 0.45, 0.5, pp + Vector3(0, 5.75, 0), dark)
		_crystal(_world, pp + Vector3(0, 6.1, 0), 1.1, purple, Vector3.ZERO, 1.6)
	# lengkung runtuh di belakang
	for s in [-1.0, 1.0]:
		_box(_world, Vector3(1.6, 12.0, 1.6), Vector3(s * 5.0, 6.0, -22.0), stone)
	_box(_world, Vector3(12.6, 1.6, 1.8), Vector3(0, 12.4, -22.0), stone)
	_box(_world, Vector3(2.2, 1.2, 1.8), Vector3(-6.0, 10.8, -22.0), stone, Vector3(0, 0, 22))
	_crystal(_world, Vector3(0, 1.0, -6.0), 3.6, purple, Vector3.ZERO, 1.5)
	_omni(_world, Vector3(0, 2.8, -5.0), purple, 1.3, 14.0)
	_omni(_world, Vector3(0, 1.5, 2.0), Color(0.5, 0.55, 1.0), 0.7, 9.0)
	# bulan ungu dan batu melayang
	var moon := SphereMesh.new()
	moon.radius = 5.0
	moon.height = 10.0
	var mm := _mat(Color(0.75, 0.6, 1.0), 2.0)
	mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_mesh(_world, moon, Vector3(22, 26, -80), mm)
	var rng := RandomNumberGenerator.new()
	rng.seed = 9
	for i in 10:
		var rk := SphereMesh.new()
		rk.radius = 0.5 + rng.randf() * 0.9
		rk.height = rk.radius * 1.6
		rk.radial_segments = 6
		rk.rings = 3
		_mesh(_world, rk, Vector3(rng.randf_range(-16, 16), rng.randf_range(4, 12), rng.randf_range(-26, -10)), dark)
	_stars(_world, 80, Vector3(10, 5, 10), Color(0.8, 0.6, 1.0, 0.9), 0.1, true)


func _set_tower() -> void:
	var red := Color(1.0, 0.22, 0.28)
	var brick := _tex_mat(_stone_tex(Color(0.3, 0.09, 0.12), 0.14, 16, 0.5), 0.22)
	var floor_m := _tex_mat(_stone_tex(Color(0.18, 0.06, 0.09), 0.12, 16, 0.45), 0.25)
	var pillar := _tex_mat(_stone_tex(Color(0.36, 0.1, 0.14), 0.08, 32, 0.7), 0.3)
	var cloth := _mat(Color(0.5, 0.04, 0.09))
	_box(_world, Vector3(60, 0.4, 70), Vector3(0, -0.2, -8), floor_m)
	_box(_world, Vector3(3.2, 0.06, 26.0), Vector3(0, 0.04, -4), _mat(Color(0.55, 0.05, 0.1)))      # karpet merah
	# dinding aula, balok langit-langit, jendela lengkung menyala
	for s in [-1.0, 1.0]:
		_box(_world, Vector3(1.0, 16.0, 40.0), Vector3(s * 9.0, 8.0, -8.0), brick)
		for i in 5:
			var z := -20.0 + float(i) * 5.0
			_box(_world, Vector3(0.2, 5.0, 1.6), Vector3(s * 8.4, 8.0, z), _mat(red, 1.2))
			_box(_world, Vector3(0.22, 1.2, 1.2), Vector3(s * 8.4, 10.8, z), _mat(red, 1.2))
			_omni(_world, Vector3(s * 7.0, 7.0, z), Color(1.0, 0.35, 0.3), 0.55, 7.0)
	_box(_world, Vector3(19.0, 16.0, 1.0), Vector3(0, 8.0, -28.0), brick)                         # dinding belakang
	_box(_world, Vector3(19.0, 1.0, 40.0), Vector3(0, 16.0, -8.0), brick)                         # langit-langit
	for i in 6:
		_box(_world, Vector3(19.0, 0.9, 0.9), Vector3(0, 15.2, -24.0 + float(i) * 6.5), pillar)
	# barisan pilar bertapak & berkepala dengan obor
	for i in 6:
		var z := -22.0 + float(i) * 4.4
		for s in [-1.0, 1.0]:
			_box(_world, Vector3(1.3, 0.5, 1.3), Vector3(s * 5.0, 0.25, z), pillar)
			_cyl(_world, 0.4, 0.5, 14.0, Vector3(s * 5.0, 7.5, z), pillar)
			_box(_world, Vector3(1.2, 0.4, 1.2), Vector3(s * 5.0, 14.7, z), pillar)
			_omni(_world, Vector3(s * 4.4, 3.4, z), Color(1.0, 0.4, 0.3), 0.6, 6.0)
			var fl := SphereMesh.new()
			fl.radius = 0.16
			fl.height = 0.4
			_mesh(_world, fl, Vector3(s * 4.5, 3.2, z), _mat(Color(1.0, 0.55, 0.25), 3.0))
	# singgasana bertingkat + spanduk
	for i in 3:
		_box(_world, Vector3(10.0 - 2.0 * float(i), 0.4, 6.0 - 1.2 * float(i)), Vector3(0, 0.2 + 0.4 * float(i), -23.5 + 0.6 * float(i)), pillar)
	_box(_world, Vector3(1.8, 4.2, 0.7), Vector3(0, 3.1, -25.6), pillar)
	_box(_world, Vector3(3.0, 1.0, 0.8), Vector3(0, 5.6, -25.6), pillar)
	for s in [-1.0, 1.0]:
		_box(_world, Vector3(1.6, 7.0, 0.1), Vector3(s * 3.6, 10.0, -27.3), cloth)
	# rantai merah menjulur dari langit-langit
	for i in 8:
		var a := TAU * float(i) / 8.0 + 0.4
		var ch := _cyl(_world, 0.05, 0.05, 15.0, Vector3(cos(a) * 6.5, 8.0, sin(a) * 6.0 - 8.0), _mat(red, 0.8), Vector3(sin(a) * 6.0, 0, -cos(a) * 6.0))
		ch.set_meta("chain", true)
	_omni(_world, Vector3(0, 4.0, -12.0), red, 1.8, 20.0)
	_stars(_world, 60, Vector3(10, 5, 10), Color(1.0, 0.5, 0.5, 0.9), 0.09, true)


# =====================================================================
#  Aktor
# =====================================================================
func _actor(id_in: String) -> CharacterRig:
	var id := str(NPC_ALIAS.get(id_in, id_in))
	if _actors.has(id_in):
		return _actors[id_in]
	var cd = Data.character(id)
	if cd == null:
		return null
	var rig := CharacterRig.new()
	_world.add_child(rig)
	rig.setup(1.8, load(cd.skin_path), true, true)
	rig.set_weapon_class(cd.anim_style if cd.anim_style != "" else cd.weapon_class)
	rig.set_style(id)
	rig.set_skill_kind(cd.skill_kind)
	rig.set_ult_kind(cd.ult_kind)
	CharacterLooks.apply_hero(rig, id)
	rig.fidget_enabled = false
	rig.set_move(0.0)
	_actors[id_in] = rig
	return rig


static func _v3(a, d := Vector3.ZERO) -> Vector3:
	if a is Array and a.size() >= 3:
		return Vector3(float(a[0]), float(a[1]), float(a[2]))
	return d


func _pose(rig: CharacterRig, id_in: String, anim: String, mps: float = -1.0) -> void:
	var id := str(NPC_ALIAS.get(id_in, id_in))
	match anim:
		"idle", "":
			rig.set_move(0.0)
		"walk", "run":
			if mps > 0.1:
				rig.set_move_speed(clampf(mps / 5.8, 0.2, 1.0), mps)   # blend & laju siklus mengikuti jarak/durasi yang ditulis di data
			else:
				rig.set_move(0.45 if anim == "walk" else 1.0)
		"attack1", "attack2", "attack3", "skill", "ult", "hurt", "dodge", "death":
			rig.play_action(anim)
		_:
			if AnimLibrary.fidgets(id).has("fid_%s@%s" % [anim, id]):
				rig.play_fidget("fid_%s@%s" % [anim, id])
			else:
				rig.set_move(0.0)


func _apply_shot(sh: Dictionary) -> void:
	var cam: Dictionary = sh.get("cam", {})
	_ca = _v3(cam.get("a"), Vector3(0, 1.6, 5))
	_cb = _v3(cam.get("b"), _ca)
	_la = _v3(cam.get("la"), Vector3(0, 1.3, 0))
	_lb = _v3(cam.get("lb"), _la)
	_cdur = maxf(float(cam.get("dur", 5.0)), 0.5)
	_ct = 0.0
	_fov_a = float(cam.get("fov", 42.0))
	_fov_b = float(cam.get("fb", _fov_a))
	_ease = str(cam.get("ease", "sine"))
	_roll = float(cam.get("roll", 0.0))
	_arc = float(cam.get("arc", 0.0))
	_hand = float(cam.get("hand", 0.0))
	_cam.fov = _fov_a
	_update_cam(0.0)
	for a in sh.get("actors", []):
		var id := str(a["id"])
		if bool(a.get("hide", false)):
			if _actors.has(id):
				(_actors[id] as Node3D).visible = false
			continue
		var rig := _actor(id)
		if rig == null:
			continue
		rig.visible = true
		if a.has("pos"):
			rig.position = _v3(a["pos"])
		if a.has("yaw"):
			rig.rotation_degrees.y = float(a["yaw"])
		var mps := -1.0
		if a.has("to"):
			var to := _v3(a["to"])
			var dur := float(a.get("dur", _cdur))
			_moving.append({"rig": rig, "from": rig.position, "to": to, "t": 0.0, "dur": dur})
			mps = rig.position.distance_to(to) / maxf(dur, 0.1)         # kecepatan nyata -> langkah kaki disamakan (tidak meluncur)
			if not a.has("yaw"):
				var d := to - rig.position
				rig.rotation.y = atan2(d.x, d.z)
		_pose(rig, id, str(a.get("anim", "idle")), mps)
	for f in sh.get("fx", []):
		_fx(str(f), sh)


func _fx(kind: String, sh: Dictionary) -> void:
	match kind:
		"flicker":
			_flicker = 1.6
		"shake":
			_shake = 0.7
		"flare":
			var fl := ColorRect.new()
			fl.color = Color(1, 1, 1, 0.0)
			fl.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
			fl.mouse_filter = Control.MOUSE_FILTER_IGNORE
			_root.add_child(fl)
			_root.move_child(fl, _fade.get_index())
			var tw := create_tween()
			tw.tween_property(fl, "color:a", 0.85, 0.12)
			tw.tween_property(fl, "color:a", 0.0, 0.9)
			tw.tween_callback(fl.queue_free)
		"mark":                                                    # tanda bintang menyala di tangan Ren
			var rig: CharacterRig = _actors.get("ren")
			if rig:
				var hand := rig.bone_world_position("hand_l")
				var l := _omni(_world, hand, Color(0.55, 0.85, 1.0), 0.0, 4.0)
				l.set_meta("temp", true)
				var tw2 := create_tween()
				tw2.tween_property(l, "light_energy", 3.5, 0.8)
				_burst(hand, Color(0.6, 0.9, 1.0))
		"shard":
			var rig2: CharacterRig = _actors.get("ren")
			if rig2:
				var hand2 := rig2.bone_world_position("hand_r")
				var l2 := _omni(_world, hand2, Color(0.7, 0.35, 1.0), 0.0, 3.5)
				create_tween().tween_property(l2, "light_energy", 2.6, 0.7)
				_burst(hand2, Color(0.75, 0.4, 1.0))
		"pillar":
			var col := Color(0.8, 0.65, 1.0) if str(_spec.get("set", "")) == "altar" else Color(0.7, 0.9, 1.0)
			var pm := _cyl(_world, 0.8, 1.2, 22.0, Vector3(0, 11.0, -3.0), _mat(Color(col.r, col.g, col.b, 0.5), 2.5, 0.2))
			var m: StandardMaterial3D = pm.material_override
			m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			m.albedo_color.a = 0.0
			create_tween().tween_property(m, "albedo_color:a", 0.45, 1.4)
		"chains":                                                  # rantai merah retak dan jatuh
			for c in _world.get_children():
				if c is MeshInstance3D and c.has_meta("chain"):
					var tw3 := create_tween()
					tw3.tween_interval(randf() * 0.8)
					tw3.tween_property(c, "position:y", -14.0, 2.2).set_ease(Tween.EASE_IN)
					tw3.parallel().tween_property(c, "rotation_degrees:z", randf_range(-60, 60), 2.2)
		"king":                                                    # Raja Rantai Merah: sosok raksasa jauh lebih kuat dari siapa pun
			_spawn_king()
		"king_strike":                                             # satu ayunan: raja menghempaskan seluruh party
			if _king == null:
				_spawn_king()
			var tw4 := create_tween()
			tw4.tween_interval(1.4)
			tw4.tween_property(_king_arm, "rotation_degrees:x", -150.0, 0.9).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
			tw4.tween_interval(0.35)
			tw4.tween_property(_king_arm, "rotation_degrees:x", 70.0, 0.22).set_ease(Tween.EASE_IN)
			tw4.tween_callback(_king_impact)
			tw4.tween_property(_king_arm, "rotation_degrees:x", 20.0, 1.6).set_ease(Tween.EASE_OUT)
		"eye":                                                     # mata raksasa terbuka di cakrawala
			var eye := Node3D.new()
			eye.position = Vector3(0, 9.0, -34.0)
			_world.add_child(eye)
			var s := SphereMesh.new()
			s.radius = 5.0
			s.height = 10.0
			var sm := _mesh(eye, s, Vector3.ZERO, _mat(Color(0.95, 0.9, 0.8), 0.9, 0.4))
			sm.scale = Vector3(1.0, 0.01, 0.4)
			var ir := SphereMesh.new()
			ir.radius = 2.2
			ir.height = 4.4
			var im := _mesh(eye, ir, Vector3(0, 0, 3.0), _mat(Color(1.0, 0.15, 0.2), 3.0, 0.3))
			im.scale = Vector3(1.0, 1.0, 0.2)
			var pu := _box(eye, Vector3(0.5, 3.6, 0.3), Vector3(0, 0, 3.8), _mat(Color(0, 0, 0)))
			pu.scale = Vector3(1, 1, 1)
			create_tween().tween_property(sm, "scale", Vector3(1.0, 0.55, 0.4), 2.2).set_ease(Tween.EASE_OUT)
			_omni(_world, Vector3(0, 9.0, -28.0), Color(1.0, 0.2, 0.25), 3.5, 40.0)


var _king: Node3D = null
var _king_arm: Node3D = null


func _king_impact() -> void:
	_shake = 1.6
	_fx("flare", {})
	for id in ["ren", "lyra", "brann"]:
		var rg: CharacterRig = _actors.get(id)
		if rg != null and rg.visible:
			rg.play_action("hurt")


func _spawn_king() -> void:
	if _king != null:
		return
	_king = Node3D.new()
	_king.position = Vector3(0, 0, -9.5)
	_world.add_child(_king)
	var iron := _mat(Color(0.09, 0.07, 0.11), 0.0, 0.5)
	var trim := _mat(Color(0.55, 0.05, 0.1), 0.4, 0.5)
	var red := _mat(Color(1.0, 0.12, 0.15), 3.5, 0.3)
	for sx in [-1.0, 1.0]:                                          # kaki
		_box(_king, Vector3(1.3, 4.2, 1.3), Vector3(sx * 0.95, 2.1, 0), iron)
		_box(_king, Vector3(1.5, 0.5, 2.0), Vector3(sx * 0.95, 0.25, 0.3), trim)
	_box(_king, Vector3(3.8, 3.6, 2.1), Vector3(0, 6.0, 0), iron)    # badan
	_box(_king, Vector3(2.4, 0.5, 2.3), Vector3(0, 4.3, 0), trim)    # sabuk
	_box(_king, Vector3(0.9, 0.9, 0.2), Vector3(0, 6.2, 1.1), _mat(Color(1.0, 0.12, 0.15), 1.6, 0.3))   # inti di dada
	for sx in [-1.0, 1.0]:                                          # bahu berduri
		_box(_king, Vector3(2.0, 1.2, 2.4), Vector3(sx * 2.7, 7.6, 0), iron)
		for k in 3:
			var sp := CylinderMesh.new()
			sp.top_radius = 0.0
			sp.bottom_radius = 0.28
			sp.height = 1.4
			sp.radial_segments = 5
			_mesh(_king, sp, Vector3(sx * (2.3 + 0.45 * float(k)), 8.6, 0), trim, Vector3(0, 0, -sx * 18.0))
	_box(_king, Vector3(1.7, 1.7, 1.7), Vector3(0, 8.4, 0.1), iron)  # kepala
	for k in 5:                                                     # mahkota duri
		var cr := CylinderMesh.new()
		cr.top_radius = 0.0
		cr.bottom_radius = 0.2
		cr.height = 1.2 + 0.3 * float(k % 2)
		cr.radial_segments = 5
		_mesh(_king, cr, Vector3((float(k) - 2.0) * 0.38, 9.7, 0.1), trim)
	for sx in [-1.0, 1.0]:                                          # mata menyala
		_box(_king, Vector3(0.45, 0.16, 0.1), Vector3(sx * 0.42, 8.5, 1.0), red)
	_box(_king, Vector3(6.0, 7.0, 0.1), Vector3(0, 5.5, -1.3), _mat(Color(0.35, 0.03, 0.07)))   # jubah
	_king_arm = Node3D.new()                                        # lengan + pedang raksasa
	_king_arm.position = Vector3(3.0, 7.3, 0.3)
	_king_arm.rotation_degrees = Vector3(20, 0, 0)
	_king.add_child(_king_arm)
	_box(_king_arm, Vector3(1.0, 3.2, 1.0), Vector3(0, -1.6, 0), iron)
	_box(_king_arm, Vector3(0.6, 11.0, 0.16), Vector3(0, -3.4, 1.4), _mat(Color(0.55, 0.55, 0.62), 0.0, 0.25), Vector3(0, 0, 0))
	_box(_king_arm, Vector3(2.2, 0.35, 0.5), Vector3(0, -3.4, 1.4), trim)
	_omni(_king, Vector3(0, 8.5, 3.0), Color(1.0, 0.15, 0.2), 2.4, 14.0)
	_king.scale = Vector3(1, 1, 1)
	# rantai menahan kakinya: dua rantai merah menjulur ke lantai
	for sx in [-1.0, 1.0]:
		var ch := _cyl(_king, 0.06, 0.06, 9.0, Vector3(sx * 4.2, 4.5, 0.5), _mat(Color(1.0, 0.22, 0.28), 1.4), Vector3(0, 0, sx * 14.0))
		ch.set_meta("chain_king", true)


func _burst(pos: Vector3, col: Color) -> void:
	var p := CPUParticles3D.new()
	p.position = pos
	p.amount = 24
	p.lifetime = 1.4
	p.one_shot = true
	p.explosiveness = 0.9
	p.direction = Vector3(0, 1, 0)
	p.spread = 180.0
	p.gravity = Vector3(0, 0.6, 0)
	p.initial_velocity_min = 0.5
	p.initial_velocity_max = 1.6
	var q := QuadMesh.new()
	q.size = Vector2(0.07, 0.07)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.albedo_color = col
	q.material = m
	p.mesh = q
	_world.add_child(p)
	p.emitting = true


# =====================================================================
#  Alur
# =====================================================================
func _update_cam(delta: float) -> void:
	_ct += delta
	var u := clampf(_ct / _cdur, 0.0, 1.0)
	var p := _ease_curve(u)
	var pos := _ca.lerp(_cb, p)
	var look := _la.lerp(_lb, p)
	_t_total += delta
	if _arc != 0.0:                                                                         # orbit pelan mengelilingi titik pandang
		var off := pos - look
		off = off.rotated(Vector3.UP, deg_to_rad(_arc) * p)
		pos = look + off
	if _hand > 0.0:                                                                         # getaran tangan halus (bukan guncangan)
		pos += Vector3(sin(_t_total * 2.3), sin(_t_total * 3.1 + 1.0), sin(_t_total * 1.7 + 2.0)) * 0.018 * _hand
	_cam.fov = lerpf(_fov_a, _fov_b, p)
	pos += Vector3(sin(_t_total * 0.9) * 0.012, sin(_t_total * 1.3) * 0.01, 0.0)          # napas kamera
	if _shake > 0.0:
		_shake = maxf(_shake - delta, 0.0)
		pos += Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * 0.06 * _shake
	if pos.distance_to(look) < 0.05:
		look += Vector3(0, 0, -1)
	_cam.look_at_from_position(pos, look, Vector3.UP)
	if _roll != 0.0:
		_cam.rotate_object_local(Vector3(0, 0, 1), deg_to_rad(_roll) * p)


func _ease_curve(u: float) -> float:
	match _ease:
		"linear":
			return u
		"in":
			return u * u * u
		"out":
			return 1.0 - pow(1.0 - u, 3.0)
		"inout":
			return u * u * u * (u * (u * 6.0 - 15.0) + 10.0)                         # smootherstep: awal & akhir lebih lembut dari sine
	return smoothstep(0.0, 1.0, u)


func _process(delta: float) -> void:
	if _cam == null:
		return
	_update_cam(delta)
	for m in _moving:
		m["t"] += delta
		var u := clampf(float(m["t"]) / maxf(float(m["dur"]), 0.1), 0.0, 1.0)
		var ue: float = _trapezoid(u)                                                    # percepat sebentar, jalan stabil, melambat di akhir
		(m["rig"] as Node3D).position = (m["from"] as Vector3).lerp(m["to"], ue)
		if u >= 1.0 and not m.get("done", false):
			m["done"] = true
			(m["rig"] as CharacterRig).set_move(0.0)
	if _flicker > 0.0:
		_flicker = maxf(_flicker - delta, 0.0)
		for l in _lights:
			if is_instance_valid(l) and not l.has_meta("temp"):
				if not l.has_meta("e0"):
					l.set_meta("e0", l.light_energy)
				l.light_energy = float(l.get_meta("e0")) * (0.15 + 0.85 * absf(sin(_t_total * 31.0))) if _flicker > 0.12 else float(l.get_meta("e0"))


## Profil jarak 0..1 untuk berjalan: 12% awal berakselerasi, 12% akhir melambat, tengahnya laju tetap (terasa seperti langkah, bukan geser).
func _trapezoid(u: float) -> float:
	const A := 0.12
	var v := 1.0 / (1.0 - A)                                  # laju tengah supaya total jarak = 1
	if u < A:
		return 0.5 * v * u * u / A
	if u > 1.0 - A:
		var r := 1.0 - u
		return 1.0 - 0.5 * v * r * r / A
	return 0.5 * v * A + v * (u - A)


func _wait(secs: float) -> void:
	var t := 0.0
	while t < secs and not _skip and not _tap:
		await get_tree().process_frame
		t += get_process_delta_time()
	_tap = false


func _run() -> void:
	var shots: Array = _spec.get("shots", [])
	_t_total = 0.0
	if shots.size() > 0:
		_apply_shot(shots[0])
	_fade.color.a = 1.0
	if str(_spec.get("title", "")) != "":
		var tw := create_tween()
		tw.tween_property(_title_box, "modulate:a", 1.0, 0.9)
		tw.tween_interval(1.4)
		tw.tween_property(_title_box, "modulate:a", 0.0, 0.7)
		await _wait(3.0)
		_tap = false
		if tw.is_valid():
			tw.kill()
		_title_box.modulate.a = 0.0
	var bar := create_tween()
	bar.tween_property(_bar_top, "offset_bottom", BAR_TOP, 0.8)
	create_tween().tween_property(_fade, "color:a", 0.0, 0.9)
	var first := true
	for sh in shots:
		if _skip:
			break
		if not first:
			var dip := create_tween()
			dip.tween_property(_fade, "color:a", 1.0, 0.16)
			await dip.finished
			_apply_shot(sh)
			await get_tree().process_frame
			var up := create_tween()
			up.tween_property(_fade, "color:a", 0.0, 0.22)
		first = false
		var lines: Array = sh.get("lines", [])
		if lines.is_empty():
			await _wait(_cdur)
			continue
		for ln in lines:
			if _skip:
				break
			await _line(ln)
	_finish_async()


func _line(ln: Dictionary) -> void:
	var who := str(ln.get("s", ""))
	_name.text = who
	_name.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_name.add_theme_color_override("font_color", StoryPlayer.COLORS.get(who, UiTheme.GOLD))
	_text.text = str(ln.get("t", ""))
	_text.visible_characters = 0
	create_tween().tween_property(_band, "modulate:a", 1.0, 0.25)
	var n := _text.get_total_character_count()
	_typing = true
	if _tween:
		_tween.kill()
	_tween = create_tween()
	_tween.tween_property(_text, "visible_characters", n, maxf(n * 0.022, 0.1))
	_tween.finished.connect(_typed)
	Sfx.play("dialog", randf_range(0.95, 1.1))
	_tap = false
	var after := 0.0
	var limit := 0.9 if fast else 1.6 + n * 0.045
	line_shown.emit(_text.text)
	while not _skip:
		await get_tree().process_frame
		if _tap:
			_tap = false
			if _typing:
				if _tween:
					_tween.kill()
				_typing = false
				_text.visible_characters = -1
				continue
			break
		if not _typing:
			after += get_process_delta_time()
			if after >= limit:
				break


func _typed() -> void:
	_typing = false
	_text.visible_characters = -1


func _finish_async() -> void:
	if _done:
		return
	_done = true
	if _tween:
		_tween.kill()
	var out := create_tween()
	out.tween_property(_fade, "color:a", 1.0, 0.6)
	out.parallel().tween_property(_band, "modulate:a", 0.0, 0.4)
	await out.finished
	get_tree().paused = _was_paused
	finished.emit()
