class_name GachaReveal
extends Control
## Upacara pemanggilan, 4 babak: (1) glif bintang menyala di layar gelap, satu bintang per tingkat rarity terbaik; (2) terowongan cahaya
## (garis melesat dari tengah); (3) lingkaran sihir berputar mengumpulkan cahaya (warna mengikuti rarity terbaik), kilatan, lalu kartu hasil
## dibuka satu per satu (kartu terbalik -> membalik). Rarity ★4+ mendapat kilau & suara khusus, ★5 ledakan emas + layar bergetar.
## Ketuk di mana saja untuk mempercepat / melewati. Hasil sudah diterapkan ke GameState sebelum overlay ini muncul (melewati aman).

signal finished

const BACK_COL := Color(0.05, 0.12, 0.21)

var results: Array = []
var _best := 1
var _skip := false
var _cards: Array = []
var _revealed := 0
var _done := false
var _tint: Color
var _big_done := false          # hanya hasil ★5+ PERTAMA dalam satu tarikan yang mendapat ledakan penuh
var _flash: ColorRect
var _hint: Label
var _grid: GridContainer
var _btn_row: HBoxContainer
var _alive := true
var _fx: GachaFx


static func tint_for(r: int) -> Color:
	match r:
		6: return Color(1.0, 0.5, 0.65)
		5: return Color(1.0, 0.8, 0.3)
		4: return Color(0.75, 0.5, 1.0)
		3: return Color(0.45, 0.8, 1.0)
		_: return Color(0.6, 0.85, 1.0)


func setup(res: Array) -> void:
	results = res
	for r: Dictionary in res:
		_best = maxi(_best, int(r["rarity"]))
	_tint = tint_for(_best)


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color(0.008, 0.016, 0.04, 0.97)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	_fx = GachaFx.new()
	_fx.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fx.tint = _tint
	_fx.best = _best
	_fx.slots = 6 if _best >= 6 else 5
	add_child(_fx)
	_grid = GridContainer.new()
	_grid.columns = 5 if results.size() > 1 else 1
	_grid.add_theme_constant_override("h_separation", 14)
	_grid.add_theme_constant_override("v_separation", 14)
	_grid.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_grid.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_grid.grow_vertical = Control.GROW_DIRECTION_BOTH
	_grid.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_grid)
	_flash = ColorRect.new()
	_flash.color = Color(1, 1, 1, 0.0)
	_flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_flash)
	_hint = UiTheme.label("Ketuk untuk melewati", 18, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER)
	_hint.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_hint.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_hint.offset_top = -56
	_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_hint)
	_btn_row = HBoxContainer.new()
	_btn_row.add_theme_constant_override("separation", 16)
	_btn_row.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_btn_row.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_btn_row.offset_top = -96
	_btn_row.visible = false
	add_child(_btn_row)
	gui_input.connect(_on_input)
	_play()


func _on_input(ev: InputEvent) -> void:
	if _done:
		return
	if (ev is InputEventMouseButton and ev.pressed) or (ev is InputEventScreenTouch and ev.pressed):
		_skip = true


func _wait(t: float) -> void:
	if _skip or not _alive:
		return
	var tm := get_tree().create_timer(t)
	var elapsed := 0.0
	while elapsed < t and not _skip and _alive and is_inside_tree():
		await get_tree().process_frame
		elapsed += get_process_delta_time()


func _process(delta: float) -> void:
	if _grid:
		_grid.position = (size - _grid.size) / 2.0 - Vector2(0, 26)


## Tingkat kemegahan mengikuti rarity terbaik (supaya ★3 tidak diperlakukan seperti ★5): 0 = ★3 ke bawah (singkat, tenang),
## 1 = ★4, 2 = ★5+ (penuh).
func _tier() -> int:
	return 0 if _best <= 3 else (1 if _best == 4 else 2)


## Babak 1-2: glif bintang menyala (+ terowongan cahaya untuk ★4+). Ketuk = lewati (kartu tetap muncul, hasil tidak berubah).
func _intro() -> void:
	var tier := _tier()
	var g_time: float = [0.7, 1.2, 1.6][tier]
	var w_time: float = [0.0, 0.8, 1.2][tier]
	_fx.mode = GachaFx.GLYPH
	_fx.t = 0.0
	var gt := create_tween()
	gt.tween_property(_fx, "t", 1.0, 0.6).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	if tier >= 1:
		Sfx.play("gacha_charge")                        # gemuruh naik yang memuncak tepat saat ledakan
	var step := g_time / float(_best + 1)
	await _wait(step)
	for k in range(1, _best + 1):
		if _skip or not _alive:
			break
		_fx.lit = k
		_fx.pop = 1.0
		create_tween().tween_property(_fx, "pop", 0.0, 0.35)
		Sfx.play("gacha_star", 0.7 + 0.12 * float(k), -3.0 if tier >= 1 else -9.0)
		await _wait(step)
	if _skip or not _alive:
		_fx.lit = _best
		_fx.mode = GachaFx.NONE
		return
	if tier >= 1:
		_fx.mode = GachaFx.WARP
		_fx.t = 0.0
		var wt := create_tween()
		wt.tween_property(_fx, "t", 1.0, w_time).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
		await _wait(w_time)
	_fx.mode = GachaFx.NONE


func _play() -> void:
	await _intro()
	if not _alive:
		return
	# --- 3) ledakan: gelombang kejut + kilatan + dentuman (kuat sesuai tingkat)
	var tier := _tier()
	_fx.mode = GachaFx.BURST
	_fx.t = 0.0
	create_tween().tween_property(_fx, "t", 1.0, 0.8).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	_flash.color = Color(_tint.lerp(Color(1, 1, 1), 0.6), [0.4, 0.8, 1.0][tier])
	create_tween().tween_property(_flash, "color:a", 0.0, 0.7)
	Sfx.play("gacha_burst", [1.5, 1.0, 0.92][tier], [-7.0, 0.0, 3.0][tier])
	await _wait(0.45)
	if not _alive:
		return
	# sinar emas berputar di belakang kartu untuk hasil terbaik ★5+
	if _best >= 5:
		_fx.mode = GachaFx.RAYS
		_fx.t = 0.0
		create_tween().tween_property(_fx, "t", 1.0, 0.8)
	else:
		_fx.mode = GachaFx.NONE
	# --- kartu
	for r: Dictionary in results:
		var c := _make_card(r)
		_grid.add_child(c)
		_cards.append(c)
	await get_tree().process_frame
	for c: Control in _cards:
		c.pivot_offset = c.size / 2.0
		c.scale = Vector2(0.01, 1.0) if false else Vector2(1, 1)
	for i in _cards.size():
		var c: Control = _cards[i]
		var face: Control = c.get_node("Face")
		var back: Control = c.get_node("Back")
		face.visible = false
		back.visible = true
		c.modulate.a = 0.0
		c.scale = Vector2(0.6, 0.6)
		var ap := create_tween()
		ap.set_parallel(true)
		ap.tween_property(c, "modulate:a", 1.0, 0.25).set_delay(0.04 * i)
		ap.tween_property(c, "scale", Vector2(1, 1), 0.3).set_delay(0.04 * i).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	await _wait(0.6)
	for i in _cards.size():
		await _reveal(i)
		await _wait(0.34 if int(results[i]["rarity"]) < 4 else 0.7)
	_finish()


func _reveal(i: int) -> void:
	var c: Control = _cards[i]
	var r: Dictionary = results[i]
	var rar := int(r["rarity"])
	var face: Control = c.get_node("Face")
	var back: Control = c.get_node("Back")
	c.pivot_offset = c.size / 2.0
	if _skip:
		back.visible = false
		face.visible = true
		_revealed += 1
		return
	var t1 := create_tween()
	t1.tween_property(c, "scale:x", 0.0, 0.1)
	await t1.finished
	back.visible = false
	face.visible = true
	var t2 := create_tween()
	t2.tween_property(c, "scale:x", 1.0, 0.14).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_revealed += 1
	var col := tint_for(rar)
	if rar >= 4:
		Sfx.play("gacha_star", 0.85 + float(rar - 4) * 0.2, -2.0)
		var pop := create_tween()
		pop.tween_property(c, "scale", Vector2(1.1, 1.1), 0.12)
		pop.tween_property(c, "scale", Vector2(1, 1), 0.2)
		_sparkle(c, col, 20 if rar == 4 else (36 if rar == 5 else 56))
	if rar >= 5 and not _big_done:
		_big_done = true
		Sfx.play("gacha_reveal", 1.0, 2.0)
		_flash.color = Color(1.0, 0.9, 0.5, 0.45) if rar == 5 else Color(1.0, 0.7, 0.85, 0.6)
		create_tween().tween_property(_flash, "color:a", 0.0, 0.7)
		var amp := 6.0 * clampf(float(GameState.setting("cam_fx")), 0.0, 1.5)     # ikut pengaturan "Getar & zoom efek"
		if amp > 0.1:
			var sh := create_tween()
			for k in 6:
				sh.tween_property(self, "position", Vector2(randf_range(-amp, amp), randf_range(-amp, amp) * 0.75) * (1.0 - float(k) / 7.0), 0.04)
			sh.tween_property(self, "position", Vector2.ZERO, 0.05)
	elif rar < 4:
		Sfx.play("gacha_card", 0.95 + float(rar) * 0.05, -6.0)


func _sparkle(c: Control, col: Color, count: int) -> void:
	var p := CPUParticles2D.new()
	p.position = c.size / 2.0
	p.one_shot = true
	p.emitting = true
	p.amount = count
	p.lifetime = 0.9
	p.explosiveness = 1.0
	p.direction = Vector2(0, -1)
	p.spread = 180.0
	p.initial_velocity_min = 120.0
	p.initial_velocity_max = 300.0
	p.gravity = Vector2(0, 160)
	p.scale_amount_min = 3.0
	p.scale_amount_max = 7.0
	p.color = col.lightened(0.4)
	c.add_child(p)
	get_tree().create_timer(1.2).timeout.connect(p.queue_free)


func _make_card(r: Dictionary) -> Control:
	var rar := int(r["rarity"])
	var col: Color = UiTheme.RARITY[rar - 1]
	var single := results.size() == 1
	var size := Vector2(320, 350) if single else Vector2(196, 226)
	var root := Control.new()
	root.custom_minimum_size = size
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# punggung kartu
	var back := PanelContainer.new()
	back.name = "Back"
	back.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	back.add_theme_stylebox_override("panel", UiTheme.box(BACK_COL, Color(0.55, 0.85, 1.0, 0.8), 3, 16, 10))
	back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bi := UiIcon.make("star", Color(0.6, 0.9, 1.0, 0.7), int(size.x * 0.4))
	bi.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	bi.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	back.add_child(bi)
	root.add_child(back)
	# muka kartu
	var face := PanelContainer.new()
	face.name = "Face"
	face.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := Color(0.04, 0.09, 0.16).lerp(col, 0.18 + 0.06 * rar)
	face.add_theme_stylebox_override("panel", UiTheme.box(bg, col.lightened(0.15), (4 if rar >= 4 else 2), 16, 10))
	face.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var v := VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 4)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	face.add_child(v)
	var kind := "diamond"
	if r["kind"] == "character":
		kind = "character"
	elif r["kind"] == "item":
		kind = BasePanel.item_icon_kind(Data.item(r["id"]))
	var ic := UiIcon.make(kind, col.lightened(0.1), int(size.x * (0.34 if not single else 0.4)))
	ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(ic)
	var nm := UiTheme.label(str(r["name"]), 20 if not single else 28, UiTheme.TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	nm.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	nm.custom_minimum_size = Vector2(size.x - 28, 0)
	nm.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(nm)
	var st := UiTheme.label("%s  ×%d" % [BasePanel.stars_text(rar, rar), int(r["count"])], 19 if not single else 26, col.lightened(0.2), HORIZONTAL_ALIGNMENT_CENTER)
	st.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(st)
	root.add_child(face)
	return root


func _finish() -> void:
	_done = true
	_skip = true
	_hint.visible = false
	_btn_row.visible = true
	for i in _cards.size():
		var c: Control = _cards[i]
		c.get_node("Back").visible = false
		c.get_node("Face").visible = true
		c.scale = Vector2.ONE
	var ok := UiTheme.button("OK", Vector2(240, 66))
	ok.pressed.connect(func():
		Sfx.play("select")
		_close())
	_btn_row.add_child(ok)
	var again := UiTheme.accent_button("Tarik lagi", UiTheme.GOLD, Vector2(240, 66))
	again.pressed.connect(func():
		Sfx.play("select")
		_close(true))
	_btn_row.add_child(again)


var wants_again := false


func _close(again: bool = false) -> void:
	wants_again = again
	_alive = false
	finished.emit()
	queue_free()


## Gambar efek babak 1-3 (garis dan poligon saja, tanpa aset gambar): glif bintang, terowongan cahaya, sinar berputar.
class GachaFx extends Control:
	enum { NONE, GLYPH, WARP, RAYS, BURST }
	var mode := NONE
	var t := 0.0                        # kemajuan babak 0..1
	var tint := Color(1, 1, 1)
	var best := 3
	var slots := 5
	var lit := 0
	var pop := 0.0                      # denyut bintang yang baru menyala
	var _ang := PackedFloat32Array()
	var _spd := PackedFloat32Array()
	var _spin := 0.0

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		var rng := RandomNumberGenerator.new()
		rng.seed = 7
		for i in 110:
			_ang.append(rng.randf() * TAU)
			_spd.append(rng.randf_range(0.35, 1.0))

	func _process(delta: float) -> void:
		if mode != NONE:
			_spin += delta
			queue_redraw()

	func _draw() -> void:
		var c := size * 0.5 - Vector2(0, 20)
		match mode:
			GLYPH: _draw_glyph(c)
			WARP: _draw_warp(c)
			RAYS: _draw_rays(c)
			BURST: _draw_burst(c)

	func _star(c: Vector2, r: float, col: Color) -> void:
		var q := r * 0.12
		var pts := PackedVector2Array([c + Vector2(0, -r), c + Vector2(q, -q), c + Vector2(r * 0.5, 0), c + Vector2(q, q),
			c + Vector2(0, r), c + Vector2(-q, q), c + Vector2(-r * 0.5, 0), c + Vector2(-q, -q)])
		draw_colored_polygon(pts, col)

	func _draw_glyph(c: Vector2) -> void:
		var h := 170.0 * t
		var a := clampf(t * 1.4, 0.0, 1.0)
		draw_circle(c, h * 0.6, Color(tint, 0.06 * a))
		draw_line(c + Vector2(0, -h), c + Vector2(0, h), Color(tint, 0.55 * a), 2.0, true)
		_star(c, h * 0.62 * (1.0 + 0.08 * sin(_spin * 3.0)), Color(tint.lightened(0.3), 0.95 * a))
		# barisan bintang rarity: menyala satu per satu sampai tingkat terbaik
		var gap := 54.0
		var y := c.y + 170.0 + 56.0
		var x0 := c.x - gap * float(slots - 1) * 0.5
		for i in slots:
			var p := Vector2(x0 + gap * float(i), y)
			if i < lit:
				var sc := 1.0 + (0.7 * pop if i == lit - 1 else 0.0)
				if i == lit - 1:
					draw_circle(p, 30.0 * (1.0 + pop), Color(tint, 0.28 * pop))
				_star(p, 22.0 * sc, tint.lightened(0.35))
			else:
				var r := 18.0
				var q := r * 0.12
				var ring := PackedVector2Array([p + Vector2(0, -r), p + Vector2(q, -q), p + Vector2(r * 0.5, 0), p + Vector2(q, q),
					p + Vector2(0, r), p + Vector2(-q, q), p + Vector2(-r * 0.5, 0), p + Vector2(-q, -q), p + Vector2(0, -r)])
				draw_polyline(ring, Color(tint, 0.3 * a), 2.0, true)

	func _draw_warp(c: Vector2) -> void:
		var p := t
		var maxr := size.length() * 0.6
		var col := tint.lerp(Color(1, 1, 1), 0.45)
		for i in _ang.size():
			var d := Vector2.from_angle(_ang[i])
			var r0 := p * p * maxr * _spd[i] * 0.55 + 6.0
			var r1 := r0 + (14.0 + 300.0 * p) * _spd[i]
			draw_line(c + d * r0, c + d * r1, Color(col, 0.18 + 0.7 * p), 1.5 + 3.0 * p * _spd[i], true)
		draw_circle(c, 14.0 + 90.0 * p, Color(1, 1, 1, 0.12 + 0.5 * p * p))
		draw_arc(c, 46.0 + 26.0 * p, 0.0, TAU, 48, Color(1, 1, 1, 0.8 * p), 3.0, true)

	func _draw_rays(c: Vector2) -> void:
		var R := size.length()
		var n := 14
		for k in n:
			var a := _spin * 0.22 + float(k) * TAU / float(n)
			var w := 0.07
			var pts := PackedVector2Array([c, c + Vector2.from_angle(a - w) * R, c + Vector2.from_angle(a + w) * R])
			draw_colored_polygon(pts, Color(tint, 0.09 * t))
		draw_circle(c, 260.0, Color(tint, 0.06 * t))

	func _draw_burst(c: Vector2) -> void:
		var p := t
		var R := size.length() * 0.7
		var col := tint.lerp(Color(1, 1, 1), 0.45)
		for k in 3:
			var pk := clampf(p * 1.25 - 0.14 * float(k), 0.0, 1.0)
			if pk > 0.0 and pk < 1.0:
				draw_arc(c, 30.0 + R * pow(pk, 0.55), 0.0, TAU, 72, Color(col, (1.0 - pk) * 0.75), 1.0 + 5.0 * (1.0 - pk), true)
		for i in 40:
			var d := Vector2.from_angle(_ang[i])
			var r0 := R * 0.85 * pow(p, 0.6) * _spd[i]
			draw_line(c + d * r0, c + d * (r0 + 36.0 * _spd[i] * (1.0 - p)), Color(1, 1, 1, 1.0 - p), 2.0, true)
		draw_circle(c, 40.0 + 120.0 * (1.0 - p), Color(1, 1, 1, 0.45 * (1.0 - p)))
