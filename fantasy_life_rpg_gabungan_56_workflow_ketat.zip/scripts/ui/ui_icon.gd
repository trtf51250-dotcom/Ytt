class_name UiIcon
extends Control
## Ikon vektor orisinal yang digambar dengan _draw() (tanpa aset gambar). Atur `kind` dan `color`.
## kind: character party inventory equipment quest gacha shop settings adventure gold diamond sword shield potion star lock close check
##       attack skill dodge interact heart bag scroll flag gear arrow_up arrow_down bow staff axe

@export var kind: String = "star":
	set(v):
		kind = v
		queue_redraw()
		if _shadow != null:
			_shadow.kind = v
@export var color: Color = Color(1, 1, 1):
	set(v):
		color = v
		queue_redraw()

const DARK := Color(0.03, 0.07, 0.12, 0.9)

## Bayangan jatuh: salinan ikon yang sama, dihitamkan lewat modulate, digeser sedikit ke kanan-bawah dan digambar di belakang.
## Membuat ikon terangkat dari latar kaca gelap (dan terbaca di atas panel terang). Ikon buatan make() memilikinya otomatis.
var _shadow: UiIcon
var shadowed := true


static func make(k: String, c: Color = Color(1, 1, 1), s: float = 40.0) -> UiIcon:
	var i := UiIcon.new()
	i.kind = k
	i.color = c
	i.custom_minimum_size = Vector2(s, s)
	i.mouse_filter = Control.MOUSE_FILTER_IGNORE
	i._add_shadow()
	return i


func _add_shadow() -> void:
	if not shadowed or _shadow != null:
		return
	_shadow = UiIcon.new()
	_shadow.shadowed = false
	_shadow.kind = kind
	_shadow.color = color
	_shadow.modulate = Color(0.0, 0.03, 0.07, 0.55)
	_shadow.show_behind_parent = true
	_shadow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_shadow.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_shadow)
	_shadow.position = Vector2(1.5, 2.0)


func _p(x: float, y: float) -> Vector2:
	return Vector2(x, y) * size


func _poly(pts: Array, col: Color) -> void:
	var v := PackedVector2Array()
	for p in pts:
		v.append(_p(p[0], p[1]))
	draw_colored_polygon(v, col)


func _circ(x: float, y: float, r: float, col: Color) -> void:
	draw_circle(_p(x, y), r * size.x, col)


func _ln(a: Vector2, b: Vector2, w: float, col: Color) -> void:
	draw_line(_p(a.x, a.y), _p(b.x, b.y), col, w * size.x, true)


func _arc(x: float, y: float, r: float, a0: float, a1: float, w: float, col: Color) -> void:
	draw_arc(_p(x, y), r * size.x, a0, a1, 24, col, w * size.x, true)


func _draw() -> void:
	var c := color
	var d := c.darkened(0.45)
	match kind:
		"character":
			_circ(0.5, 0.3, 0.17, c)
			_poly([[0.18, 0.92], [0.22, 0.6], [0.36, 0.52], [0.64, 0.52], [0.78, 0.6], [0.82, 0.92]], c)
			_poly([[0.42, 0.52], [0.58, 0.52], [0.5, 0.7]], d)
		"party":
			_circ(0.3, 0.32, 0.12, d)
			_poly([[0.08, 0.82], [0.1, 0.55], [0.3, 0.48], [0.5, 0.55], [0.52, 0.82]], d)
			_circ(0.7, 0.32, 0.12, d)
			_poly([[0.48, 0.82], [0.5, 0.55], [0.7, 0.48], [0.9, 0.55], [0.92, 0.82]], d)
			_circ(0.5, 0.28, 0.15, c)
			_poly([[0.22, 0.92], [0.25, 0.6], [0.5, 0.52], [0.75, 0.6], [0.78, 0.92]], c)
		"inventory", "bag":
			_arc(0.5, 0.2, 0.12, PI, TAU, 0.07, d)
			_poly([[0.3, 0.2], [0.7, 0.2], [0.86, 0.46], [0.9, 0.9], [0.1, 0.9], [0.14, 0.46]], c)
			_poly([[0.14, 0.46], [0.86, 0.46], [0.88, 0.62], [0.12, 0.62]], d)
			_poly([[0.42, 0.52], [0.58, 0.52], [0.58, 0.7], [0.42, 0.7]], Color(1.0, 0.86, 0.4))
			_poly([[0.22, 0.72], [0.78, 0.72], [0.8, 0.86], [0.2, 0.86]], c.darkened(0.2))
		"equipment", "shield":
			_poly([[0.5, 0.08], [0.88, 0.2], [0.84, 0.58], [0.5, 0.94], [0.16, 0.58], [0.12, 0.2]], c)
			_poly([[0.5, 0.18], [0.78, 0.27], [0.75, 0.55], [0.5, 0.8], [0.25, 0.55], [0.22, 0.27]], d)
			_ln(Vector2(0.5, 0.25), Vector2(0.5, 0.72), 0.06, c)
			_ln(Vector2(0.32, 0.42), Vector2(0.68, 0.42), 0.06, c)
		"quest", "scroll":
			_poly([[0.22, 0.12], [0.78, 0.12], [0.78, 0.8], [0.22, 0.8]], c)
			_circ(0.22, 0.14, 0.1, c.lightened(0.15))
			_circ(0.78, 0.82, 0.1, c.lightened(0.15))
			for i in 3:
				_ln(Vector2(0.32, 0.3 + i * 0.16), Vector2(0.68, 0.3 + i * 0.16), 0.05, d)
		"gacha", "star":
			var pts: Array = []
			for i in 10:
				var a := -PI / 2.0 + i * PI / 5.0
				var r := 0.42 if i % 2 == 0 else 0.18
				pts.append([0.5 + cos(a) * r, 0.53 + sin(a) * r])
			_poly(pts, c)
			var pts2: Array = []
			for i in 10:
				var a2 := -PI / 2.0 + i * PI / 5.0
				var r2 := 0.2 if i % 2 == 0 else 0.09
				pts2.append([0.5 + cos(a2) * r2, 0.53 + sin(a2) * r2])
			_poly(pts2, c.lightened(0.45))
		"gift":
			_poly([[0.16, 0.38], [0.84, 0.38], [0.84, 0.88], [0.16, 0.88]], c)
			_poly([[0.12, 0.26], [0.88, 0.26], [0.88, 0.4], [0.12, 0.4]], c.lightened(0.2))
			_poly([[0.44, 0.26], [0.56, 0.26], [0.56, 0.88], [0.44, 0.88]], d)
			_circ(0.38, 0.18, 0.1, c.lightened(0.3))
			_circ(0.62, 0.18, 0.1, c.lightened(0.3))
		"shop":
			_poly([[0.12, 0.4], [0.2, 0.14], [0.8, 0.14], [0.88, 0.4]], c)
			for i in 4:
				_poly([[0.12 + i * 0.19, 0.4], [0.2 + i * 0.19, 0.4], [0.2 + i * 0.19, 0.5], [0.12 + i * 0.19, 0.5]], d if i % 2 == 0 else c.lightened(0.2))
			_poly([[0.18, 0.5], [0.82, 0.5], [0.82, 0.88], [0.18, 0.88]], c)
			_poly([[0.4, 0.62], [0.6, 0.62], [0.6, 0.88], [0.4, 0.88]], d)
		"settings", "gear":
			for i in 8:
				var a3 := i * TAU / 8.0
				_poly([[0.5 + cos(a3 - 0.18) * 0.28, 0.5 + sin(a3 - 0.18) * 0.28], [0.5 + cos(a3 - 0.14) * 0.42, 0.5 + sin(a3 - 0.14) * 0.42],
					[0.5 + cos(a3 + 0.14) * 0.42, 0.5 + sin(a3 + 0.14) * 0.42], [0.5 + cos(a3 + 0.18) * 0.28, 0.5 + sin(a3 + 0.18) * 0.28]], c)
			_circ(0.5, 0.5, 0.3, c)
			_circ(0.5, 0.5, 0.13, d)
		"adventure", "flag":
			_ln(Vector2(0.28, 0.1), Vector2(0.28, 0.92), 0.07, c)
			_poly([[0.3, 0.14], [0.88, 0.3], [0.3, 0.52]], c)
			_poly([[0.3, 0.2], [0.7, 0.3], [0.3, 0.42]], d)
		"gold":
			_circ(0.5, 0.5, 0.42, Color(1.0, 0.82, 0.25))
			_circ(0.5, 0.5, 0.32, Color(1.0, 0.92, 0.5))
			_circ(0.5, 0.5, 0.24, Color(0.95, 0.72, 0.15))
			_ln(Vector2(0.5, 0.32), Vector2(0.5, 0.68), 0.07, Color(1.0, 0.92, 0.5))
		"diamond":
			_poly([[0.5, 0.1], [0.86, 0.38], [0.5, 0.92], [0.14, 0.38]], Color(0.4, 0.8, 1.0))
			_poly([[0.5, 0.1], [0.66, 0.38], [0.5, 0.92], [0.34, 0.38]], Color(0.7, 0.92, 1.0))
			_poly([[0.14, 0.38], [0.86, 0.38], [0.66, 0.38], [0.34, 0.38]], Color(1, 1, 1, 0.4))
		"sword", "attack":
			_poly([[0.78, 0.1], [0.9, 0.1], [0.9, 0.22], [0.36, 0.76], [0.24, 0.64]], c)
			_poly([[0.78, 0.1], [0.9, 0.1], [0.9, 0.22], [0.82, 0.14]], c.lightened(0.5))
			_ln(Vector2(0.18, 0.5), Vector2(0.5, 0.82), 0.09, d)
			_ln(Vector2(0.12, 0.88), Vector2(0.3, 0.7), 0.1, d)
			_circ(0.1, 0.9, 0.06, d)
		"bow":
			_arc(0.62, 0.5, 0.4, PI * 0.55, PI * 1.45, 0.09, c)
			_ln(Vector2(0.558, 0.105), Vector2(0.558, 0.895), 0.03, c.lightened(0.5))
			_ln(Vector2(0.3, 0.5), Vector2(0.88, 0.5), 0.04, d)
			_poly([[0.96, 0.5], [0.84, 0.41], [0.84, 0.59]], c.lightened(0.3))
		"staff":
			_ln(Vector2(0.18, 0.88), Vector2(0.68, 0.38), 0.1, d)
			_arc(0.74, 0.3, 0.2, PI * 0.5, PI * 1.5, 0.05, c)
			_circ(0.76, 0.28, 0.16, c)
			_circ(0.76, 0.28, 0.08, c.lightened(0.6))
		"axe":
			_ln(Vector2(0.2, 0.88), Vector2(0.66, 0.42), 0.09, d)
			_poly([[0.5, 0.2], [0.8, 0.08], [0.92, 0.38], [0.62, 0.5]], c)
			_poly([[0.8, 0.08], [0.92, 0.38], [0.86, 0.3]], c.lightened(0.5))
		"ult":
			_poly([[0.5, 0.04], [0.62, 0.38], [0.96, 0.5], [0.62, 0.62], [0.5, 0.96], [0.38, 0.62], [0.04, 0.5], [0.38, 0.38]], c)
			_circ(0.5, 0.5, 0.12, d)
		"skill":
			_poly([[0.56, 0.06], [0.2, 0.56], [0.44, 0.56], [0.36, 0.94], [0.8, 0.4], [0.54, 0.4]], c)
		"dodge":
			for i in 3:
				_poly([[0.12 + i * 0.22, 0.3], [0.34 + i * 0.22, 0.5], [0.12 + i * 0.22, 0.7], [0.2 + i * 0.22, 0.5]], c if i == 2 else c.darkened(0.3 * (2 - i)))
		"interact":
			_poly([[0.3, 0.1], [0.3, 0.8], [0.46, 0.64], [0.58, 0.9], [0.7, 0.84], [0.58, 0.58], [0.8, 0.58]], c)
		"potion":
			_poly([[0.4, 0.1], [0.6, 0.1], [0.6, 0.38], [0.84, 0.76], [0.74, 0.92], [0.26, 0.92], [0.16, 0.76], [0.4, 0.38]], c)
			_poly([[0.3, 0.7], [0.7, 0.7], [0.76, 0.8], [0.7, 0.88], [0.3, 0.88], [0.24, 0.8]], d)
			_ln(Vector2(0.36, 0.1), Vector2(0.64, 0.1), 0.07, Color(0.8, 0.6, 0.35))
		"heart":
			_circ(0.32, 0.36, 0.2, c)
			_circ(0.68, 0.36, 0.2, c)
			_poly([[0.14, 0.46], [0.86, 0.46], [0.5, 0.88]], c)
		"lock":
			_poly([[0.2, 0.44], [0.8, 0.44], [0.8, 0.9], [0.2, 0.9]], c)
			_arc(0.5, 0.44, 0.2, PI, TAU, 0.08, c)
			_circ(0.5, 0.66, 0.07, d)
		"close":
			_ln(Vector2(0.22, 0.22), Vector2(0.78, 0.78), 0.12, c)
			_ln(Vector2(0.78, 0.22), Vector2(0.22, 0.78), 0.12, c)
		"check":
			_ln(Vector2(0.2, 0.55), Vector2(0.42, 0.76), 0.12, c)
			_ln(Vector2(0.42, 0.76), Vector2(0.82, 0.28), 0.12, c)
		"arrow_up":
			_poly([[0.5, 0.16], [0.86, 0.7], [0.14, 0.7]], c)
		"arrow_down":
			_poly([[0.5, 0.84], [0.86, 0.3], [0.14, 0.3]], c)
		_:
			_circ(0.5, 0.5, 0.35, c)
