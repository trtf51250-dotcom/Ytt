extends BasePanel
## Peta kota penuh: titik teleport terbuka, peti (terbuka/belum), area rahasia. Ketuk titik teleport lalu tekan Teleport.

var _map: Minimap
var _info: Label
var _go: Button
var _stats: Label
var _sel := ""


func build() -> void:
	refresh_on = ["explore"]
	var row := hbox(12)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(row)
	_map = Minimap.new()
	_map.follow = false
	_map.lobby = host.context.get("lobby")
	_map.player = host.context.get("player")
	_map.custom_minimum_size = Vector2(560, 380)
	_map.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_map.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_map.waypoint_picked.connect(_on_pick)
	row.add_child(_map)
	var side := vbox(8)
	side.custom_minimum_size = Vector2(250, 0)
	row.add_child(side)
	_stats = wrap_lbl("", 18, UiTheme.TEXT)
	side.add_child(_stats)
	_info = wrap_lbl("Ketuk titik teleport (berlian biru) di peta.", 18, UiTheme.TEXT_DIM)
	_info.size_flags_vertical = Control.SIZE_EXPAND_FILL
	side.add_child(_info)
	_go = btn("Teleport", _teleport, Vector2(0, 60), UiTheme.GOLD)
	_go.disabled = true
	side.add_child(_go)
	side.add_child(btn("Peta Dunia", func(): host.switch_to("world_map"), Vector2(0, 52)))
	side.add_child(wrap_lbl("Peta lengkap = temukan batu teleport, peti, dan area rahasia di sudut kota.", 15, UiTheme.TEXT_DIM))
	refresh()


func refresh() -> void:
	var c := Explore.counts()
	if _stats:
		_stats.text = "Peti: %d/%d\nArea rahasia: %d/%d\nTitik teleport: %d/%d" % [c["chests"], c["chests_total"], c["zones"], c["zones_total"], c["wps"], c["wps_total"]]
	if _map:
		_map.queue_redraw()


func _on_pick(id: String) -> void:
	_sel = id
	for w: Dictionary in Explore.WAYPOINTS:
		if w["id"] == id:
			_info.text = "%s\nSiap teleport." % w["name"]
	_go.disabled = false


func _teleport() -> void:
	var lobby: Node = host.context.get("lobby")
	if _sel == "" or lobby == null:
		return
	var id := _sel
	host.close()
	lobby.teleport_to(id)
