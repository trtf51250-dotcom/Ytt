extends BasePanel
## Karakter: daftar ringkas (kiri) + detail bertab (kanan): Status, Skill, Perlengkapan, Kisah. Tombol aksi selalu terlihat di bawah.
## Dirombak agar ringan di HP:
##  - baris daftar dibuat SEKALI lalu hanya diperbarui / diurutkan ulang (dulu semua baris dibangun ulang di setiap ketukan & sinyal);
##  - mengetuk karakter hanya mengganti panel detail, daftar tidak disentuh;
##  - berpindah tab hanya membangun isi tab itu;
##  - statistik dihitung sekali per perubahan data, bukan tiap ketukan.

const SKILL_TEXT := {
	"cone": "Tebasan kerucut ke depan, menghantam semua musuh dalam jangkauan.",
	"iai": "Cabut pedang: tebasan lurus sangat panjang lalu tebasan lebar yang dibalut api biru.",
	"dash_cut": "Menerjang ke depan (kebal sesaat) dan menyilang dua tebasan beruntun.",
	"nova": "Ledakan sihir di sekitar karakter.",
	"shockwave": "Hantaman keras yang memancarkan gelombang kejut lebar.",
	"volley": "Hujan panah ke arah depan.",
	"bomb_field": "Menjatuhkan 6 bom melingkar di sekitar musuh terdekat + 1 bom besar di tengah; meledak beruntun.",
}
const ATTACK_TEXT := {"arc": "Tebasan melengkung", "dagger": "Kombo belati 3 pukulan cepat", "bolt": "Bola sihir jarak jauh", "smash": "Hantaman lebar", "arrow": "Panah jarak jauh"}
const TABS := [["stat", "Status"], ["skill", "Skill"], ["gear", "Perlengkapan"], ["lore", "Kisah"]]
const SLOT_NAME := {"weapon": "Senjata", "armor": "Armor", "accessory": "Aksesori"}
const SLOT_ICON := {"weapon": "sword", "armor": "shield", "accessory": "star"}
const STAT_COL := {"hp": Color(0.95, 0.45, 0.5), "atk": Color(1.0, 0.7, 0.35), "def": Color(0.55, 0.78, 1.0), "spd": Color(0.45, 0.9, 0.55)}

var selected := ""
var _tab := "stat"
var _ids: Array = []                       # urutan dasar karakter (dipakai sebagai pemutus seri saat mengurutkan)
var _rows := {}                            # id -> {card, name, sub, tag, owned, sel}
var _stats := {}                           # id -> statistik (hanya yang dimiliki), dihitung sekali per perubahan data
var _scale := {"hp": 1, "atk": 1, "def": 1, "spd": 1.0}   # nilai terbesar antar karakter: acuan panjang batang
var _list_dirty := true
var _detail_dirty := true
var _list: VBoxContainer
var _head: VBoxContainer
var _tabbar: HBoxContainer
var _scroll: ScrollContainer
var _body: VBoxContainer
var _foot: HBoxContainer
var _pic: TextureRect


func _init() -> void:
	refresh_on = ["roster", "party", "equipment", "profile", "inventory"]


func build() -> void:
	_ids = Data.character_ids()
	selected = str(args.get("char", GameState.leader()))
	if Data.character(selected) == null and not _ids.is_empty():
		selected = str(_ids[0])
	var row := hbox(14)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(row)
	var sl := scroll_list(330)
	row.add_child(sl[0])
	_list = sl[1]
	var right := PanelContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_stylebox_override("panel", UiTheme.box(Color(0.05, 0.11, 0.18), UiTheme.GOLD_DARK, 2, 14, 14))
	row.add_child(right)
	var inner := hbox(12)
	right.add_child(inner)
	var det := vbox(6)
	det.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_child(det)
	_head = vbox(6)
	det.add_child(_head)
	_tabbar = hbox(8)
	det.add_child(_tabbar)
	var bs := scroll_list(0)
	bs[0].size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll = bs[0]
	_body = bs[1]
	det.add_child(_scroll)
	_foot = hbox(10)
	det.add_child(_foot)
	_pic = TextureRect.new()                              # potret 3D seluruh badan di sisi kanan
	_pic.custom_minimum_size = Vector2(230, 0)
	_pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_pic.clip_contents = true
	inner.add_child(_pic)
	Portraits.changed_signal(self).connect(_set_pic)


## Hanya tandai bagian yang perlu disegarkan; refresh() sendiri digabung satu kali per frame oleh BasePanel.
func _on_state_changed(kind: String) -> void:
	if not _built or not (kind in refresh_on):
		return
	if kind == "roster" or kind == "party":
		_list_dirty = true
	_detail_dirty = true
	queue_refresh()


func refresh() -> void:
	if _detail_dirty:
		_calc_stats()
	if _list_dirty:
		_list_dirty = false
		_sync_list()
	if _detail_dirty:
		_detail_dirty = false
		_fill(true)


# ---------------------------------------------------------------- data
func _calc_stats() -> void:
	_stats.clear()
	_scale = {"hp": 1, "atk": 1, "def": 1, "spd": 1.0}
	for id in _ids:
		if not GameState.is_unlocked(id):
			continue
		var st: Dictionary = GameState.char_stats(id)
		_stats[id] = st
		_scale["hp"] = maxi(int(_scale["hp"]), int(st["hp"]))
		_scale["atk"] = maxi(int(_scale["atk"]), int(st["atk"]))
		_scale["def"] = maxi(int(_scale["def"]), int(st["def"]))
		_scale["spd"] = maxf(float(_scale["spd"]), float(st["spd"]))


func _obtain_hint(id: String) -> String:
	for qid in Data.quest_order:
		if Data.quest(qid).reward_character == id:
			return "Cara mendapatkan: selesaikan quest \"%s\"." % Data.quest(qid).title
	for rr: Array in Gacha.CHAR_POOL.values():
		if id in rr:
			return "Cara mendapatkan: Panggilan Jiwa di Altar Bintang (gacha karakter)."
	if Gacha.EXTRA_CHARS.has(id):
		return "Cara mendapatkan: Panggilan Jiwa di Altar Bintang (peluang kecil per tarikan; naik sementara saat event)."
	return "Karakter ini belum bisa didapat."


# ---------------------------------------------------------------- daftar (kiri)
## Urutan: anggota party (sesuai urutan party), lalu yang dimiliki (bintang kelangkaan tertinggi dulu), lalu yang terkunci.
func _before(a: String, b: String) -> bool:
	var oa := GameState.is_unlocked(a)
	var ob := GameState.is_unlocked(b)
	if oa != ob:
		return oa
	var ra: int = Data.character(a).rarity
	var rb: int = Data.character(b).rarity
	if ra != rb:
		return ra > rb
	return _ids.find(a) < _ids.find(b)


func _sync_list() -> void:
	var order: Array = []
	for p in GameState.party:
		if _ids.has(p) and not order.has(p):
			order.append(p)
	var others: Array = []
	for id in _ids:
		if not order.has(id):
			others.append(id)
	others.sort_custom(_before)
	order.append_array(others)
	for i in order.size():
		var id: String = order[i]
		var owned := GameState.is_unlocked(id)
		var row: Dictionary = _rows.get(id, {})
		if row.is_empty() or bool(row["owned"]) != owned:     # baru, atau status terkunci/terbuka berubah: buat ulang baris ini saja
			if not row.is_empty():
				_list.remove_child(row["card"])
				row["card"].queue_free()
			row = _make_row(id, owned)
			_rows[id] = row
			_list.add_child(row["card"])
		_list.move_child(row["card"], i)
		_update_row(id)


func _make_row(id: String, owned: bool) -> Dictionary:
	var cd := Data.character(id)
	var c := card()
	var r := hbox(10)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.add_child(r)
	var av := PanelContainer.new()
	av.custom_minimum_size = Vector2(46, 46)
	av.mouse_filter = Control.MOUSE_FILTER_IGNORE
	av.add_theme_stylebox_override("panel", UiTheme.box(cd.accent.darkened(0.15) if owned else Color(0.15, 0.27, 0.27), Color(1, 1, 1, 0.8), 2, 23, 4))
	var ic := UiIcon.make("character" if owned else "lock", Color(1, 1, 1), 30)
	ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	av.add_child(ic)
	r.add_child(av)
	var col := vbox(0)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var nm := lbl(cd.display_name, 23, UiTheme.TEXT if owned else UiTheme.TEXT_DIM)
	nm.clip_text = true
	nm.custom_minimum_size = Vector2(90, 0)
	col.add_child(nm)
	var sub := lbl("", 18, UiTheme.GOLD if owned else UiTheme.TEXT_DIM)
	sub.clip_text = true
	sub.custom_minimum_size = Vector2(90, 0)
	col.add_child(sub)
	r.add_child(col)
	var tag := lbl("", 18, UiTheme.SKY)
	tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	r.add_child(tag)
	tap_on(c, _select.bind(id))
	return {"card": c, "sub": sub, "tag": tag, "owned": owned}


func _update_row(id: String) -> void:
	var row: Dictionary = _rows[id]
	var cd := Data.character(id)
	if bool(row["owned"]):
		row["sub"].text = "%s · %s" % [cd.role, stars_text(GameState.stars(id))]
	else:
		row["sub"].text = "%s · Terkunci" % cd.role
	var tag := ""
	if GameState.party.has(id):
		tag = "♛" if id == GameState.leader() else "Party"
	row["tag"].text = tag
	_style_row(id)


## Gaya kartu hanya dibuat ulang bila status terpilihnya benar-benar berubah.
func _style_row(id: String) -> void:
	if not _rows.has(id):
		return
	var row: Dictionary = _rows[id]
	var sel := id == selected
	if row.get("sel", null) == sel:
		return
	row["sel"] = sel
	var cd := Data.character(id)
	var owned: bool = row["owned"]
	var border: Color = UiTheme.GOLD if sel else (cd.accent.darkened(0.2) if owned else Color(0.3, 0.33, 0.45))
	var bg := Color(0.12, 0.25, 0.36) if sel else Color(0.08, 0.16, 0.26)
	row["card"].add_theme_stylebox_override("panel", UiTheme.plate(bg, border, 5, 9, 10, 6))


func _select(id: String) -> void:
	if id == selected:
		return
	var prev := selected
	selected = id
	_style_row(prev)
	_style_row(id)
	_fill(false)


# ---------------------------------------------------------------- detail (kanan)
func _set_pic() -> void:
	if _pic == null or not is_instance_valid(_pic):
		return
	_pic.texture = Portraits.texture(self, selected + "#full")
	_pic.modulate = Color(1, 1, 1) if GameState.is_unlocked(selected) else Color(0.1, 0.1, 0.16, 0.85)


func _fill(keep_scroll: bool = false) -> void:
	_set_pic()
	clear(_head)
	clear(_foot)
	var cd := Data.character(selected)
	if cd == null:
		clear(_body)
		return
	var owned := GameState.is_unlocked(selected)
	_fill_head(cd, owned)
	_build_tabbar(owned)
	_fill_body(cd, owned, keep_scroll)
	_foot.visible = owned
	if owned:
		_fill_foot()


func _fill_head(cd: CharacterData, owned: bool) -> void:
	var top := hbox(12)
	top.add_child(lbl(cd.display_name, 32, UiTheme.GOLD))
	var t := lbl("%s · %s" % [cd.title, cd.role], 18, UiTheme.SKY)
	t.size_flags_vertical = Control.SIZE_SHRINK_END
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.clip_text = true
	top.add_child(t)
	top.add_child(lbl("Langka " + stars_text(cd.rarity, cd.rarity), 18, rarity_color(cd.rarity)))
	_head.add_child(top)
	if not owned:
		return
	var s := GameState.stars(selected)
	var sr := hbox(14)
	sr.add_child(lbl(stars_text(s), 28, UiTheme.GOLD))
	if s < GameState.MAX_STARS:
		var need := GameState.star_up_cost(selected)
		var have := GameState.shards(selected)
		var col := vbox(2)
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		col.add_child(lbl("Pecahan %d/%d" % [have, need], 18, UiTheme.SKY))
		col.add_child(UiTheme.bar(UiTheme.SKY, clampf(float(have) / float(maxi(need, 1)), 0.0, 1.0), 10.0))
		sr.add_child(col)
		var up := btn("Naikkan ★", _on_star_up, Vector2(150, 48))
		up.disabled = have < need
		sr.add_child(up)
	else:
		sr.add_child(lbl("Bintang maksimum", 18, UiTheme.SKY))
	_head.add_child(sr)


func _build_tabbar(owned: bool) -> void:
	_tabbar.visible = owned
	clear(_tabbar)
	if not owned:
		return
	for t in TABS:
		var tid: String = t[0]
		var b := btn(str(t[1]), _set_tab.bind(tid), Vector2(0, 46), UiTheme.GOLD if tid == _tab else Color(0.15, 0.29, 0.40))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_tabbar.add_child(b)


func _set_tab(tid: String) -> void:
	if tid == _tab:
		return
	_tab = tid
	_build_tabbar(true)
	var cd := Data.character(selected)
	if cd != null:
		_fill_body(cd, true, false)


func _fill_body(cd: CharacterData, owned: bool, keep_scroll: bool) -> void:
	if keep_scroll:
		clear(_body)
	else:
		for c in _body.get_children():
			_body.remove_child(c)
			c.queue_free()
		_scroll.scroll_vertical = 0
	if not owned:
		_body.add_child(wrap_lbl(cd.description, 20, UiTheme.TEXT_DIM))
		if cd.motto != "":
			_body.add_child(wrap_lbl("“%s”" % cd.motto, 20, cd.accent.lightened(0.35)))
		_body.add_child(wrap_lbl(_obtain_hint(selected), 20, UiTheme.GOLD))
		_body.add_child(wrap_lbl("Kisah lengkapnya terbuka setelah karakter ini bergabung.", 18, UiTheme.TEXT_DIM))
		return
	match _tab:
		"skill":
			_tab_skill(cd)
		"gear":
			_tab_gear()
		"lore":
			_tab_lore(cd)
		_:
			_tab_stat(cd)


func _stat_bar(name: String, val: String, ratio: float, col: Color, delta: String = "") -> Control:
	var h := hbox(10)
	var a := lbl(name, 20, UiTheme.TEXT_DIM)
	a.custom_minimum_size = Vector2(66, 0)
	h.add_child(a)
	var b := UiTheme.bar(col, clampf(ratio, 0.04, 1.0), 14.0)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(b)
	var v := lbl(val, 22, UiTheme.TEXT)
	v.custom_minimum_size = Vector2(76, 0)
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(v)
	var d := lbl(delta, 18, UiTheme.GOOD)
	d.custom_minimum_size = Vector2(70, 0)
	h.add_child(d)
	return h


## Tab Status: kekuatan + level, batang HP/ATK/DEF/Gerak (angka hijau = tambahan bila naik bintang), lalu deskripsi.
func _tab_stat(cd: CharacterData) -> void:
	var st: Dictionary = _stats.get(selected, {})
	if st.is_empty():
		st = GameState.char_stats(selected)
	var pw := hbox(12)
	pw.add_child(lbl("Kekuatan", 20, UiTheme.TEXT_DIM))
	pw.add_child(lbl(str(st["power"]), 34, UiTheme.GOLD))
	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pw.add_child(sp)
	pw.add_child(lbl("Lv %d" % GameState.level, 26, UiTheme.TEXT))
	_body.add_child(pw)
	var s := GameState.stars(selected)
	var has_next := s < GameState.MAX_STARS
	var ratio := GameState.star_factor(s + 1) / GameState.star_factor(s)
	for k in [["HP", "hp"], ["ATK", "atk"], ["DEF", "def"]]:
		var key: String = k[1]
		var v: int = int(st[key])
		var d := ""
		if has_next:
			d = "+%d" % (int(float(v) * ratio) - v)
		_body.add_child(_stat_bar(str(k[0]), str(v), float(v) / float(maxi(int(_scale[key]), 1)), STAT_COL[key], d))
	_body.add_child(_stat_bar("Gerak", "%.1f" % float(st["spd"]), float(st["spd"]) / maxf(float(_scale["spd"]), 0.1), STAT_COL["spd"]))
	if has_next:
		_body.add_child(wrap_lbl("Angka hijau = tambahan statistik bila naik ke ★%d." % (s + 1), 18, UiTheme.TEXT_DIM))
	_body.add_child(HSeparator.new())
	_body.add_child(wrap_lbl(cd.description, 18, UiTheme.TEXT_DIM))


func _block(title: String, col: Color, line: String, desc: String = "") -> Control:
	var c := card(col.darkened(0.45))
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var v := vbox(2)
	c.add_child(v)
	v.add_child(wrap_lbl(title, 22, col))
	v.add_child(wrap_lbl(line, 18, UiTheme.TEXT))
	if desc != "":
		v.add_child(wrap_lbl(desc, 18, UiTheme.TEXT_DIM))
	return c


## Tab Skill: serangan biasa, skill, ULT. Menampilkan juga kritikal, tembus DEF, biaya mana, dan durasi wujud ULT.
func _tab_skill(cd: CharacterData) -> void:
	var a: PackedStringArray = []
	a.append("Jangkauan %.1f m" % cd.attack_range)
	a.append("Kombo %d pukulan: %s" % [ComboDefs.steps(cd).size(), " → ".join(ComboDefs.names(cd))])
	a.append("Kritikal %d%%" % int(round(cd.crit_chance * 100.0)))
	if cd.armor_pen > 0.0:
		a.append("Tembus DEF %d%%" % int(round(cd.armor_pen * 100.0)))
	_body.add_child(_block("Serangan · %s" % ATTACK_TEXT.get(cd.attack_kind, cd.attack_kind), UiTheme.TEXT, " · ".join(a)))
	var sk := "×%.1f · jeda %.0f dtk · mana %.0f" % [cd.skill_mult, cd.skill_cooldown, cd.skill_mana_cost]
	_body.add_child(_block("Skill · %s" % cd.skill_name, UiTheme.SKY, sk, SKILL_TEXT.get(cd.skill_kind, "")))
	if cd.ult_name != "":
		var u := "×%.1f · %d× per match" % [cd.ult_mult, 1]
		if cd.ult_charges > 1:
			u = "×%.1f · 1× per match (%d× di ★ max)" % [cd.ult_mult, cd.ult_charges]
		if cd.ult_kind == "storm_blade":
			u += " · ★ max: kebal 4 dtk"
		if cd.ult_form_secs_max > 0.0:
			u += " · wujud %.0f–%.0f dtk (naik bersama ★)" % [cd.ult_form_secs_min, cd.ult_form_secs_max]
		_body.add_child(_block("ULT · %s" % cd.ult_name, Color(1.0, 0.6, 0.9), u))


## Tab Perlengkapan: tiga slot (senjata/armor/aksesori). Ketuk slot untuk membuka panel Equipment.
func _tab_gear() -> void:
	var plus := GameState.weapon_plus(selected)
	for slot in GameState.SLOTS:
		var iid := GameState.equipped(selected, slot)
		var it: ItemData = Data.item(iid) if iid != "" else null
		var c := card(rarity_color(it.rarity).darkened(0.25) if it != null else UiTheme.GOLD_DARK)
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var r := hbox(12)
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		c.add_child(r)
		if it != null:
			r.add_child(UiIcon.make(item_icon_kind(it), rarity_color(it.rarity), 44))
		else:
			r.add_child(UiIcon.make(SLOT_ICON[slot], Color(0.5, 0.56, 0.7), 44))
		var col := vbox(0)
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.mouse_filter = Control.MOUSE_FILTER_IGNORE
		col.add_child(lbl(SLOT_NAME[slot], 18, UiTheme.TEXT_DIM))
		if it != null:
			var nm := it.display_name
			if slot == "weapon" and plus > 0:
				nm += " +%d" % plus
			col.add_child(lbl(nm, 22, rarity_color(it.rarity).lightened(0.3)))
			col.add_child(lbl(item_stats(it), 18, UiTheme.TEXT_DIM))
		else:
			col.add_child(lbl("Kosong", 22, UiTheme.TEXT_DIM))
		r.add_child(col)
		tap_on(c, _on_gear)
		_body.add_child(c)
	_body.add_child(wrap_lbl("Ketuk slot atau tombol Ganti Equipment untuk mengganti.", 18, UiTheme.TEXT_DIM))


## Tab Kisah: moto hidup (dalam kotak kutipan) lalu cerita singkat; paragraf dipisah baris kosong di data karakter.
func _tab_lore(cd: CharacterData) -> void:
	if cd.motto == "" and cd.story == "":
		_body.add_child(wrap_lbl("Kisah karakter ini belum ditulis.", 20, UiTheme.TEXT_DIM))
		return
	if cd.motto != "":
		var c := card(cd.accent.darkened(0.3))
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		c.add_child(wrap_lbl("“%s”" % cd.motto, 22, cd.accent.lightened(0.35)))
		_body.add_child(c)
	for para in cd.story.split("\n\n"):
		var t := para.strip_edges()
		if t == "":
			continue
		var l := wrap_lbl(t, 19, UiTheme.TEXT)
		l.add_theme_constant_override("line_spacing", 4)
		_body.add_child(l)


# ---------------------------------------------------------------- aksi
## Tombol kiri menyesuaikan keadaan: sudah pemimpin / jadikan pemimpin / masukkan ke party (bila masih ada slot) / atur di Party.
func _fill_foot() -> void:
	var text := "Jadikan Pemimpin"
	var enabled := true
	if selected == GameState.leader() and GameState.party.has(selected):
		text = "Pemimpin"
		enabled = false
	elif not GameState.party.has(selected):
		text = "Masukkan ke Party" if GameState.party.size() < GameState.PARTY_SIZE else "Atur di Party"
	var lead := btn(text, _on_leader, Vector2(0, 54))
	lead.disabled = not enabled
	lead.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_foot.add_child(lead)
	var eqb := btn("Ganti Equipment", _on_gear, Vector2(0, 54))
	eqb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_foot.add_child(eqb)


func _on_star_up() -> void:
	var cd := Data.character(selected)
	if cd != null and GameState.star_up(selected):
		Sfx.play("shard")
		toast("%s naik ke %d★ (+%d%% statistik)" % [cd.display_name, GameState.stars(selected), int(round(GameState.STAR_STEP * 100.0))])
	else:
		toast("Pecahan jiwa belum cukup.")


func _on_leader() -> void:
	var cd := Data.character(selected)
	if cd == null:
		return
	if GameState.party.has(selected):
		GameState.make_leader(selected)
		toast("%s sekarang memimpin regu." % cd.display_name)
	elif GameState.party.size() < GameState.PARTY_SIZE:
		GameState.set_party_slot(GameState.party.size(), selected)
		toast("%s masuk ke party." % cd.display_name)
	else:
		host.open("party", {})


func _on_gear() -> void:
	host.open("equipment", {"char": selected})
