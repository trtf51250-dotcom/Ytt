extends BasePanel
## Peta Dunia: menghubungkan Kota Aurelia, Desa Fajar dan dua pintu stage (Portal Petualangan & Padang Petualangan).
## Digambar sepenuhnya lewat kode (tanpa aset gambar, tanpa tekstur) dan hanya digambar ulang ~12x/detik selama panel terbuka.
## Ketuk lokasi -> info + progres + tombol pergi. Perpindahan memakai Flow.go_town()/go_village() (layar memuat yang sama dengan papan penunjuk/gerbang).
## Daftar stage mengikuti wilayah aktif (Flow.lobby_map), jadi pintu stage wilayah lain meminta pemain pergi ke kota/desanya dulu.

## kind: "town" | "village" = tempat singgah (bisa dikunjungi); "gate" = pintu daftar stage milik wilayah `region`.
## label: sisi nama dari ikon ("left" | "right" | "below", bawaan "below"), dipilih supaya tidak menimpa jalan.
const LOCS := {
	"aurelia": {"name": "Kota Aurelia", "pos": Vector2(0.50, 0.17), "kind": "town", "region": "town", "label": "left",
		"desc": "Ibu kota berbenteng. Guild, toko senjata & ramuan, tempa, altar bintang, dan kamp party ada di sini. Titik teleport dan peti tersembunyi tersebar di sudut kota."},
	"portal": {"name": "Portal Petualangan", "pos": Vector2(0.82, 0.29), "kind": "gate", "region": "town",
		"desc": "Portal di ujung timur bulevar Aurelia. Pintu menuju stage Adventure utama."},
	"fajar": {"name": "Desa Fajar", "pos": Vector2(0.38, 0.55), "kind": "village", "region": "village", "label": "left",
		"desc": "Desa kecil di luar gerbang selatan Aurelia. Balai Desa, warung, bengkel, ladang, dan kincir angin. Punya quest dan kisah sendiri."},
	"padang": {"name": "Padang Petualangan", "pos": Vector2(0.60, 0.85), "kind": "gate", "region": "village", "label": "right",
		"desc": "Gerbang selatan Desa Fajar menuju padang terbuka. Pintu stage Kisah Desa Fajar."},
}
const ORDER := ["aurelia", "portal", "fajar", "padang"]
## Jalan antar lokasi (koordinat 0..1 relatif ukuran peta).
const ROADS: Array = [
	[Vector2(0.50, 0.17), Vector2(0.47, 0.30), Vector2(0.37, 0.41), Vector2(0.38, 0.55)],      # Aurelia - Desa Fajar (lewat gerbang selatan kota)
	[Vector2(0.50, 0.17), Vector2(0.64, 0.19), Vector2(0.75, 0.24), Vector2(0.82, 0.29)],      # Aurelia - Portal (bulevar timur)
	[Vector2(0.38, 0.55), Vector2(0.44, 0.69), Vector2(0.52, 0.79), Vector2(0.60, 0.85)],      # Desa Fajar - Padang (gerbang selatan desa)
]

var _view: WorldMapView
var _name_l: Label
var _status_l: Label
var _desc_l: Label
var _prog_l: Label
var _quest_l: Label
var _go: Button
var _sel := ""
var _here := "aurelia"


func build() -> void:
	_here = "fajar" if Flow.lobby_map == "village" else "aurelia"
	_sel = _here
	var row := hbox(14)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(row)
	_view = WorldMapView.new()
	_view.setup(LOCS, ORDER, ROADS, _here)
	_view.custom_minimum_size = Vector2(540, 330)
	_view.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_view.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_view.picked.connect(_select)
	row.add_child(_view)
	var side := vbox(8)
	side.custom_minimum_size = Vector2(280, 0)
	row.add_child(side)
	_name_l = lbl("", 30, UiTheme.GOLD)
	side.add_child(_name_l)
	_status_l = lbl("", 18, UiTheme.SKY)
	side.add_child(_status_l)
	_desc_l = wrap_lbl("", 18, UiTheme.TEXT)
	_desc_l.size_flags_vertical = Control.SIZE_EXPAND_FILL
	side.add_child(_desc_l)
	_prog_l = lbl("", 18, UiTheme.TEXT_DIM)
	side.add_child(_prog_l)
	_quest_l = lbl("", 18, UiTheme.TEXT_DIM)
	side.add_child(_quest_l)
	_go = btn("", _act, Vector2(0, 60), UiTheme.GOLD)
	side.add_child(_go)
	if _here == "aurelia":
		side.add_child(btn("Peta Kota & Teleport", func(): host.switch_to("map"), Vector2(0, 48)))
	_select(_sel)


func refresh() -> void:
	if _name_l != null:
		_select(_sel)


## Progres wilayah: [selesai, total] untuk urutan stage wilayah itu.
func _progress(region: String) -> Vector2i:
	var order: Array = Data.village_order if region == "village" else Data.adventure_order
	var done := 0
	for id in order:
		if GameState.stage_cleared(str(id)):
			done += 1
	return Vector2i(done, order.size())


## Quest aktif / siap klaim di wilayah itu (aturan sama dengan panel Quest).
func _quests(region: String) -> Vector2i:
	var vil := region == "village"
	var active := 0
	var ready := 0
	for id in Data.quest_order:
		var q = Data.quest(id)
		if q == null or (q.region == "village") != vil:
			continue
		match GameState.quest_state(id):
			"ready": ready += 1
			"active": active += 1
	return Vector2i(active, ready)


func _select(id: String) -> void:
	if not LOCS.has(id):
		return
	_sel = id
	_view.selected = id
	var info: Dictionary = LOCS[id]
	var region: String = info["region"]
	var kind: String = info["kind"]
	var cur_region := "village" if Flow.lobby_map == "village" else "town"
	_name_l.text = str(info["name"])
	var stage_name := "Kisah Desa Fajar" if region == "village" else "Adventure"
	if id == _here:
		_status_l.text = "Kamu di sini"
	elif kind == "gate":
		_status_l.text = "Pintu stage · %s" % stage_name
	else:
		_status_l.text = ""
	_desc_l.text = str(info["desc"])
	var pr := _progress(region)
	_prog_l.text = "%s: %d / %d stage selesai" % ["Kisah Desa" if region == "village" else "Adventure", pr.x, pr.y]
	var q := _quests(region)
	_quest_l.text = "Quest: %d aktif · %d siap klaim" % [q.x, q.y]
	var hub := "Desa Fajar" if region == "village" else "Kota Aurelia"
	if kind == "gate":
		_go.disabled = false
		_go.text = "Buka daftar stage" if region == cur_region else "Pergi ke %s dulu" % hub
	else:
		_go.disabled = id == _here
		_go.text = "Kamu sedang di sini" if id == _here else "Pergi ke %s" % str(info["name"])


func _act() -> void:
	if not LOCS.has(_sel):
		return
	var info: Dictionary = LOCS[_sel]
	var region: String = info["region"]
	var cur_region := "village" if Flow.lobby_map == "village" else "town"
	if info["kind"] == "gate" and region == cur_region:
		host.switch_to("stage_select", {"adventure": true})
		return
	if region == cur_region and info["kind"] != "gate":
		return                                         # sudah di sini
	host.close()
	if region == "village":
		Flow.go_village()
	else:
		Flow.go_town()


# =====================================================================
#  Tampilan peta (digambar lewat kode)
# =====================================================================
class WorldMapView extends Control:
	signal picked(id: String)

	var selected := ""
	var _locs: Dictionary = {}
	var _order: Array = []
	var _roads: Array = []
	var _here := ""
	var _t := 0.0
	var _acc := 0.0
	var _tap := Vector2.ZERO
	var _trees: Array = []                  # Vector3(x, y, skala) dalam 0..1; dibuat sekali, tidak menimpa jalan/lokasi/danau

	const LAKE_C := Vector2(0.85, 0.72)
	const ASPECT := 1.6                     # koreksi lebar:tinggi saat mengukur jarak di ruang 0..1


	func setup(locs: Dictionary, order: Array, roads: Array, here: String) -> void:
		_locs = locs
		_order = order
		_roads = roads
		_here = here


	func _ready() -> void:
		clip_contents = true
		mouse_filter = Control.MOUSE_FILTER_STOP
		var r := RandomNumberGenerator.new()
		r.seed = 4242
		var tries := 0
		while _trees.size() < 64 and tries < 800:
			tries += 1
			var p := Vector2(r.randf_range(0.03, 0.97), r.randf_range(0.05, 0.97))
			if _clear_of(p):
				_trees.append(Vector3(p.x, p.y, r.randf_range(0.75, 1.2)))


	func _clear_of(p: Vector2) -> bool:
		var q := Vector2(p.x * ASPECT, p.y)
		for id in _order:
			var lp: Vector2 = _locs[id]["pos"]
			if q.distance_to(Vector2(lp.x * ASPECT, lp.y)) < 0.17:
				return false
		for road in _roads:
			var pts: Array = road
			for i in pts.size() - 1:
				var a: Vector2 = pts[i]
				var b: Vector2 = pts[i + 1]
				var c := Geometry2D.get_closest_point_to_segment(q, Vector2(a.x * ASPECT, a.y), Vector2(b.x * ASPECT, b.y))
				if c.distance_to(q) < 0.05:
					return false
		if Vector2((p.x - LAKE_C.x) * ASPECT, p.y - LAKE_C.y).length() < 0.2:
			return false
		return true


	func _process(delta: float) -> void:
		_t += delta
		_acc += delta
		if _acc >= 0.08:                    # ~12x per detik cukup untuk denyut penanda; hemat baterai
			_acc = 0.0
			queue_redraw()


	func _unit() -> float:
		return clampf(minf(size.x / 620.0, size.y / 360.0), 0.7, 1.6)


	func _px(p: Vector2) -> Vector2:
		return Vector2(p.x * size.x, p.y * size.y)


	func _draw() -> void:
		var sz := size
		var u := _unit()
		var top := Color(0.17, 0.38, 0.31)
		var bot := Color(0.11, 0.27, 0.23)
		draw_polygon(PackedVector2Array([Vector2.ZERO, Vector2(sz.x, 0), sz, Vector2(0, sz.y)]), PackedColorArray([top, top, bot, bot]))
		# bukit lembut
		for h in [Vector3(0.14, 0.38, 0.2), Vector3(0.72, 0.52, 0.22), Vector3(0.2, 0.86, 0.18), Vector3(0.9, 0.12, 0.14)]:
			draw_circle(_px(Vector2(h.x, h.y)), h.z * sz.y * 1.3, Color(0.22, 0.46, 0.35, 0.42))
		# danau
		var lake := PackedVector2Array()
		for i in 28:
			var a := i * TAU / 28.0
			lake.append(_px(LAKE_C + Vector2(cos(a) * 0.09, sin(a) * 0.075)))
		draw_colored_polygon(lake, Color(0.25, 0.5, 0.72, 0.85))
		draw_polyline(_close(lake), Color(0.7, 0.88, 1.0, 0.55), 2.0 * u, true)
		# pohon (pinus kecil)
		for t: Vector3 in _trees:
			var c := _px(Vector2(t.x, t.y))
			var s := 7.0 * u * t.z
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, -s * 1.5), c + Vector2(-s, s * 0.6), c + Vector2(s, s * 0.6)]), Color(0.1, 0.3, 0.2))
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, -s * 0.8), c + Vector2(-s * 1.2, s * 1.2), c + Vector2(s * 1.2, s * 1.2)]), Color(0.13, 0.37, 0.25))
		# jalan: tepi gelap + isi pasir
		for road in _roads:
			var rpts: Array = road
			var pts := PackedVector2Array()
			for rp in rpts:
				pts.append(_px(rp))
			draw_polyline(pts, Color(0.3, 0.21, 0.12), 13.0 * u, true)
			draw_polyline(pts, Color(0.8, 0.68, 0.46), 8.0 * u, true)
		# lokasi
		for id in _order:
			_draw_loc(str(id), u)
		# pembatas + kompas
		draw_rect(Rect2(Vector2.ZERO, sz), Color(UiTheme.GOLD, 0.9), false, 3.0)
		var cp := Vector2(34.0 * u, 52.0 * u)
		draw_colored_polygon(PackedVector2Array([cp + Vector2(0, -22 * u), cp + Vector2(-7 * u, 4 * u), cp + Vector2(7 * u, 4 * u)]), UiTheme.GOLD)
		draw_circle(cp + Vector2(0, 4 * u), 3.0 * u, Color(0.06, 0.14, 0.22))
		var f := ThemeDB.fallback_font
		draw_string_outline(f, cp + Vector2(-12, -28 * u), "U", HORIZONTAL_ALIGNMENT_CENTER, 24, int(18 * u), 4, Color(0.02, 0.05, 0.10))
		draw_string(f, cp + Vector2(-12, -28 * u), "U", HORIZONTAL_ALIGNMENT_CENTER, 24, int(18 * u), UiTheme.TEXT)


	func _close(a: PackedVector2Array) -> PackedVector2Array:
		var b := a.duplicate()
		if a.size() > 0:
			b.append(a[0])
		return b


	func _draw_loc(id: String, u: float) -> void:
		var info: Dictionary = _locs[id]
		var p := _px(info["pos"])
		var kind: String = info["kind"]
		var sel := id == selected
		if sel:
			var pulse := 0.5 + 0.5 * sin(_t * 4.0)
			draw_circle(p, 36.0 * u, Color(UiTheme.GOLD, 0.16 + 0.1 * pulse))
			draw_arc(p, 34.0 * u, 0.0, TAU, 40, UiTheme.GOLD, 3.0 * u, true)
		match id:
			"aurelia":
				var w := 50.0 * u
				var h := 28.0 * u
				var stone := Color(0.82, 0.84, 0.92)
				var roof := Color(0.32, 0.55, 0.95)
				draw_rect(Rect2(p.x - w * 0.5, p.y - h * 0.3, w, h * 1.1), stone)
				for dx in [-w * 0.5, w * 0.5 - 13.0 * u]:
					draw_rect(Rect2(p.x + dx, p.y - h * 0.9, 13.0 * u, h * 1.7), stone.darkened(0.08))
					draw_colored_polygon(PackedVector2Array([Vector2(p.x + dx - 2.0 * u, p.y - h * 0.9), Vector2(p.x + dx + 6.5 * u, p.y - h * 1.55), Vector2(p.x + dx + 15.0 * u, p.y - h * 0.9)]), roof)
				draw_rect(Rect2(p.x - 6.0 * u, p.y + h * 0.1, 12.0 * u, h * 0.7), Color(0.22, 0.14, 0.1))
				draw_line(Vector2(p.x, p.y - h * 0.3), Vector2(p.x, p.y - h * 1.25), Color(0.4, 0.28, 0.16), 2.0 * u)
				draw_colored_polygon(PackedVector2Array([Vector2(p.x, p.y - h * 1.25), Vector2(p.x + 13.0 * u, p.y - h * 1.05), Vector2(p.x, p.y - h * 0.85)]), Color(0.95, 0.4, 0.35))
			"fajar":
				var roofs := [Color(0.92, 0.36, 0.32), Color(0.98, 0.64, 0.28), Color(0.64, 0.46, 0.9)]
				for i in 3:
					var hx := p.x + (i - 1) * 19.0 * u
					var hy := p.y + (4.0 if i == 1 else -2.0) * u
					draw_rect(Rect2(hx - 8.0 * u, hy - 3.0 * u, 16.0 * u, 13.0 * u), Color(1.0, 0.95, 0.85))
					draw_colored_polygon(PackedVector2Array([Vector2(hx - 11.0 * u, hy - 3.0 * u), Vector2(hx, hy - 15.0 * u), Vector2(hx + 11.0 * u, hy - 3.0 * u)]), roofs[i])
			"portal":
				var pulse2 := 0.5 + 0.5 * sin(_t * 3.0)
				draw_circle(p, 17.0 * u, Color(0.45, 0.35, 0.9, 0.35 + 0.2 * pulse2))
				draw_arc(p, 20.0 * u, 0.0, TAU, 36, Color(0.65, 0.55, 1.0), 5.0 * u, true)
				draw_arc(p, 11.0 * u, 0.0, TAU, 28, Color(0.9, 0.85, 1.0, 0.8), 2.5 * u, true)
			_:
				# padang: bendera di tanah lapang
				draw_arc(p + Vector2(0, 10.0 * u), 22.0 * u, PI, TAU, 18, Color(0.6, 0.8, 0.4, 0.7), 4.0 * u, true)
				draw_line(p + Vector2(0, 10.0 * u), p + Vector2(0, -22.0 * u), Color(0.4, 0.28, 0.16), 3.0 * u)
				draw_colored_polygon(PackedVector2Array([p + Vector2(0, -22.0 * u), p + Vector2(20.0 * u, -15.0 * u), p + Vector2(0, -8.0 * u)]), Color(0.98, 0.78, 0.3))
		# nama
		var f := ThemeDB.fallback_font
		var fs := int(19.0 * u)
		var nm: String = info["name"]
		var tw := f.get_string_size(nm, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		var tp: Vector2
		match str(info.get("label", "below")):
			"left": tp = Vector2(p.x - 36.0 * u - tw, p.y + 6.0 * u)
			"right": tp = Vector2(p.x + 36.0 * u, p.y + 6.0 * u)
			_: tp = Vector2(p.x - tw * 0.5, p.y + 44.0 * u)
		tp.x = clampf(tp.x, 8.0, maxf(size.x - tw - 8.0, 8.0))          # teks tidak keluar dari peta
		tp.y = clampf(tp.y, float(fs) + 4.0, size.y - 8.0)
		draw_string_outline(f, tp, nm, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 6, Color(0.02, 0.05, 0.10))
		draw_string(f, tp, nm, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, UiTheme.GOLD if sel else UiTheme.TEXT)
		# penanda posisi pemain
		if id == _here:
			var bob := sin(_t * 3.2) * 4.0 * u
			var pin := p + Vector2(0, -46.0 * u + bob)
			draw_colored_polygon(PackedVector2Array([pin + Vector2(-8.0 * u, 0), pin + Vector2(8.0 * u, 0), pin + Vector2(0, 18.0 * u)]), Color(0.95, 0.25, 0.3))
			draw_circle(pin, 9.0 * u, Color(0.95, 0.25, 0.3))
			draw_circle(pin, 3.5 * u, Color(1, 1, 1))


	func _gui_input(e: InputEvent) -> void:
		if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
			if e.pressed:
				_tap = e.position
			elif _tap.distance_to(e.position) < 24.0:
				_pick(e.position)
			accept_event()


	func _pick(pos: Vector2) -> void:
		var best := ""
		var bd := maxf(52.0, 62.0 * _unit())
		for id in _order:
			var d := _px(_locs[id]["pos"]).distance_to(pos)
			if d < bd:
				bd = d
				best = str(id)
		if best != "":
			Sfx.play("select")
			picked.emit(best)
