extends BasePanel
## Co-op & PVP WiFi / Hotspot: buat room (nama + password), cari room di jaringan yang sama, gabung (atau ketik IP host), ruang tunggu, mulai stage bersama.
## Catatan: semua pemain harus tersambung ke WiFi / hotspot yang sama. Host = HP yang membuka room (boleh HP yang menyalakan hotspot).

var _page: Control
var _rooms_box: VBoxContainer
var _members_box: VBoxContainer
var _stage_opt: OptionButton
var _name_edit: LineEdit
var _pw_edit: LineEdit
var _join_pw: LineEdit
var _ip_edit: LineEdit
var _status: Label
var _stage_ids: Array = []
var _last_mode := ""


func _init() -> void:
	refresh_on = ["__none__"]


func build() -> void:
	_page = Control.new()
	_page.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_child(_page)
	Net.rooms_changed.connect(_fill_rooms)
	Net.members_changed.connect(_fill_members)
	Net.state_changed.connect(_on_state)
	Net.join_failed.connect(func(r: String): _say(r, true))
	Net.left_room.connect(func(r: String):
		if r != "":
			Flow.toast(r))
	_on_state()


func _exit_tree() -> void:
	for s in [Net.rooms_changed, Net.members_changed, Net.state_changed]:
		for c in s.get_connections():
			if (c["callable"] as Callable).get_object() == self:
				s.disconnect(c["callable"])
	if Net.mode == "none":
		Net.stop_search()
	elif Net.is_searching():
		Net.stop_search()


func _say(t: String, bad: bool = false) -> void:
	if _status != null and is_instance_valid(_status):
		_status.text = t
		_status.add_theme_color_override("font_color", UiTheme.BAD if bad else UiTheme.TEXT_DIM)
	if bad:
		Flow.toast(t)


func _on_state() -> void:
	var m := Net.mode
	if m == "client" and not Net.connected_ok:
		_say("Menghubungkan...")
		if _last_mode == "client":
			return
	if m == "none":
		_show_menu()
	else:
		if Net.is_searching():
			Net.stop_search()
		_show_lobby()
	_last_mode = m


func _clear_page() -> void:
	for c in _page.get_children():
		c.queue_free()


# ---------------------------------------------------------------- menu: buat / gabung
func _show_menu() -> void:
	_clear_page()
	var root := hbox(16)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_page.add_child(root)
	# --- kiri: buat room
	var left := card(UiTheme.GOLD_DARK, Color(0.06, 0.13, 0.22, 0.95))
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.size_flags_stretch_ratio = 0.9
	root.add_child(left)
	var lv := vbox(10)
	left.add_child(lv)
	lv.add_child(lbl("Buat Room", 28, UiTheme.GOLD))
	lv.add_child(wrap_lbl("Kamu jadi host. Teman di WiFi / hotspot yang sama bisa mencari room-mu.", 17, UiTheme.TEXT_DIM))
	_name_edit = _edit("Nama room", "Room %s" % GameState.player_name)
	lv.add_child(_name_edit)
	_pw_edit = _edit("Password (kosongkan = tanpa password)", "")
	_pw_edit.secret = true
	lv.add_child(_pw_edit)
	lv.add_child(lbl("Mode / Arena:", 20, UiTheme.TEXT))
	_stage_opt = OptionButton.new()
	_stage_opt.custom_minimum_size = Vector2(0, 52)
	_stage_opt.add_theme_font_size_override("font_size", 21)
	_stage_ids.clear()
	var all_ids: Array = Data.room_stage_ids()
	var ordered: Array = []
	for id in all_ids:                       # duel PVP 1 lawan 1 di urutan teratas (mode utama)
		if str(id).begins_with("pvp_"):
			ordered.append(id)
	for id in all_ids:
		if not str(id).begins_with("pvp_"):
			ordered.append(id)
	for id in ordered:
		var pre := "[DUEL 1v1] " if str(id).begins_with("pvp_") else "[CO-OP] "
		_stage_opt.add_item(pre + Data.stage(id).display_name)
		_stage_ids.append(id)
	_stage_opt.select(0)
	lv.add_child(_stage_opt)
	lv.add_child(btn("Buat Room", _do_host, Vector2(0, 60), UiTheme.GOLD))
	var ips := Net.local_ips()
	lv.add_child(wrap_lbl("IP perangkat ini: %s" % (", ".join(ips) if not ips.is_empty() else "tidak terdeteksi (nyalakan WiFi / hotspot)"), 16, UiTheme.TEXT_DIM))
	# --- kanan: gabung
	var right := card(UiTheme.GOLD_DARK, Color(0.06, 0.13, 0.22, 0.95))
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(right)
	var rv := vbox(8)
	right.add_child(rv)
	var head := hbox(10)
	head.add_child(lbl("Gabung Room", 28, UiTheme.GOLD))
	rv.add_child(head)
	_join_pw = _edit("Password room (bila terkunci)", "")
	_join_pw.secret = true
	rv.add_child(_join_pw)
	var sc := TouchScroll.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.custom_minimum_size = Vector2(0, 120)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_rooms_box = vbox(8)
	_rooms_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(_rooms_box)
	rv.add_child(sc)
	var man := hbox(8)
	_ip_edit = _edit("IP host (manual, mis. 192.168.43.1)", "")
	_ip_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	man.add_child(_ip_edit)
	man.add_child(btn("Gabung IP", func(): _do_join(_ip_edit.text.strip_edges(), Net.PORT), Vector2(150, 52)))
	rv.add_child(man)
	_status = wrap_lbl("", 17, UiTheme.TEXT_DIM)
	rv.add_child(_status)
	Net.start_search()
	_fill_rooms()


func _edit(placeholder: String, text: String) -> LineEdit:
	var e := LineEdit.new()
	e.placeholder_text = placeholder
	e.text = text
	e.max_length = 24
	e.custom_minimum_size = Vector2(0, 52)
	e.add_theme_font_size_override("font_size", 21)
	return e


func _fill_rooms() -> void:
	if _rooms_box == null or not is_instance_valid(_rooms_box):
		return
	for c in _rooms_box.get_children():
		c.queue_free()
	if Net.rooms.is_empty():
		_rooms_box.add_child(wrap_lbl("Mencari room di jaringan ini...\nPastikan semua HP di WiFi / hotspot yang sama. Bila tidak muncul, isi IP host manual.", 18, UiTheme.TEXT_DIM))
		return
	for key in Net.rooms:
		var r: Dictionary = Net.rooms[key]
		var c := card(Color(0.5, 0.8, 1.0, 0.8), Color(0.08, 0.19, 0.30, 1.0))
		var h := hbox(10)
		c.add_child(h)
		var info := vbox(2)
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var sd := Data.stage(str(r["stage"]))
		info.add_child(lbl("%s%s" % [r["room"], "  [kunci]" if r["lock"] else ""], 23, UiTheme.TEXT))
		info.add_child(lbl("Host %s · %d/%d · %s%s" % [r["host"], r["n"], r["max"], sd.display_name if sd else "-", " · SUDAH MULAI" if r["started"] else ""], 16, UiTheme.TEXT_DIM))
		h.add_child(info)
		var ip: String = r["ip"]
		var port: int = r["port"]
		var b := btn("Gabung", func(): _do_join(ip, port), Vector2(130, 50))
		b.disabled = bool(r["started"]) or int(r["n"]) >= int(r["max"]) or int(r["ver"]) != Net.VERSION
		h.add_child(b)
		_rooms_box.add_child(c)


func _do_host() -> void:
	if _stage_ids.is_empty():
		_say("Belum ada stage terbuka", true)
		return
	var sid: String = _stage_ids[_stage_opt.selected]
	var err := Net.host_room(_name_edit.text, _pw_edit.text, sid)
	if err != "":
		_say(err, true)


func _do_join(ip: String, port: int) -> void:
	var err := Net.join_room(ip, port, _join_pw.text if _join_pw else "")
	if err != "":
		_say(err, true)
	else:
		_say("Menghubungkan ke %s..." % ip)


# ---------------------------------------------------------------- ruang tunggu
func _show_lobby() -> void:
	_clear_page()
	_stage_opt = null
	var v := vbox(12)
	v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_page.add_child(v)
	var head := card(UiTheme.GOLD, Color(0.07, 0.16, 0.26, 1.0))
	var hv := vbox(4)
	head.add_child(hv)
	hv.add_child(lbl(("Room: %s" % Net.room_name) if Net.connected_ok or Net.is_host() else "Menghubungkan...", 30, UiTheme.GOLD))
	if Net.is_host():
		var ips := Net.local_ips()
		hv.add_child(lbl("Teman bisa mencari room ini otomatis, atau gabung manual ke IP: %s" % (", ".join(ips) if not ips.is_empty() else "-"), 18, UiTheme.TEXT_DIM))
	v.add_child(head)
	var sc := TouchScroll.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_members_box = vbox(8)
	_members_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(_members_box)
	v.add_child(sc)
	var row := hbox(12)
	if Net.is_host():
		row.add_child(lbl("Stage:", 22, UiTheme.TEXT))
		_stage_opt = OptionButton.new()
		_stage_opt.custom_minimum_size = Vector2(300, 54)
		_stage_opt.add_theme_font_size_override("font_size", 21)
		_stage_ids.clear()
		for id in Data.room_stage_ids():
			_stage_opt.add_item(Data.stage(id).display_name)
			_stage_ids.append(id)
		_stage_opt.select(maxi(_stage_ids.find(Net.selected_stage), 0))
		_stage_opt.item_selected.connect(func(i: int): Net.set_stage(_stage_ids[i]))
		row.add_child(_stage_opt)
		var sp := Control.new()
		sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(sp)
		row.add_child(btn("Mulai!", func():
			var e := Net.start_game()
			if e != "":
				Flow.toast(e), Vector2(200, 60), UiTheme.GOLD))
	else:
		var sd := Data.stage(Net.selected_stage)
		row.add_child(lbl("Stage: %s  (menunggu host memulai...)" % (sd.display_name if sd else "-"), 22, UiTheme.TEXT))
		var sp2 := Control.new()
		sp2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(sp2)
	row.add_child(btn("Keluar Room", func(): Net.close_room(""), Vector2(200, 60)))
	v.add_child(row)
	_status = null
	_fill_members()


func _fill_members() -> void:
	if _members_box == null or not is_instance_valid(_members_box):
		return
	for c in _members_box.get_children():
		c.queue_free()
	var ids: Array = Net.members.keys()
	ids.sort()
	for id in ids:
		var m: Dictionary = Net.members[id]
		var c := card(Color(0.5, 0.8, 1.0, 0.6), Color(0.08, 0.19, 0.30, 1.0))
		var h := hbox(12)
		c.add_child(h)
		var cd := Data.character(str(m.get("char", "ren")))
		h.add_child(lbl("%s%s" % [m.get("name", "?"), "  (Host)" if int(id) == 1 else ""], 26, UiTheme.TEXT))
		var sp := Control.new()
		sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(sp)
		h.add_child(lbl(cd.display_name if cd else "-", 22, UiTheme.TEXT_DIM))
		_members_box.add_child(c)
	if Net.mode == "client" and Net.connected_ok:
		_members_box.add_child(wrap_lbl("Kamu terhubung. Host akan memulai permainan.", 18, UiTheme.TEXT_DIM))
