extends BasePanel
## Daftar event berjadwal: yang sedang berlangsung (dengan hitung mundur) dan yang akan datang. Event muncul/hilang otomatis sesuai jam perangkat
## (data/events.json). Event banner punya tombol langsung ke banner gacha-nya.

var _list: VBoxContainer
var _sig := ""
var _labels: Dictionary = {}


func build() -> void:
	var sl := scroll_list(0)
	sl[0].size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(sl[0])
	_list = sl[1]
	var tm := Timer.new()
	tm.wait_time = 1.0
	tm.autostart = true
	tm.timeout.connect(_tick)
	add_child(tm)
	# tandai semua event aktif sebagai sudah dilihat
	GameState.mark_events_seen()


func _signature() -> String:
	return ",".join(LiveEvents.active().map(func(e): return e["id"])) + "|" + ",".join(LiveEvents.upcoming().map(func(e): return e["id"]))


func _tick() -> void:
	if _signature() != _sig:
		refresh()
		return
	for id in _labels:
		var ev := LiveEvents.find(id)
		if not ev.is_empty() and is_instance_valid(_labels[id]):
			_labels[id].text = LiveEvents.countdown_text(ev)


func refresh() -> void:
	_sig = _signature()
	_labels.clear()
	clear(_list)
	var act := LiveEvents.active()
	var up := LiveEvents.upcoming()
	if act.is_empty() and up.is_empty():
		_list.add_child(lbl("Belum ada event saat ini.", 24, UiTheme.TEXT_DIM))
		_list.add_child(wrap_lbl("Event baru akan muncul otomatis di sini pada waktunya.", 18, UiTheme.TEXT_DIM))
		return
	if not act.is_empty():
		_list.add_child(lbl("Sedang berlangsung", 22, UiTheme.GOLD))
		for ev: Dictionary in act:
			_list.add_child(_event_card(ev, true))
	if not up.is_empty():
		_list.add_child(lbl("Akan datang", 22, UiTheme.SKY))
		for ev: Dictionary in up:
			_list.add_child(_event_card(ev, false))


func _event_card(ev: Dictionary, live: bool) -> Control:
	var col := Color(1.0, 0.65, 0.3) if live else Color(0.45, 0.6, 0.95)
	var c := card(col, Color(0.09, 0.16, 0.26))
	var v := vbox(6)
	c.add_child(v)
	var head := hbox(10)
	v.add_child(head)
	var t := lbl(str(ev["title"]), 26, col.lightened(0.25))
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(t)
	var cd := lbl(LiveEvents.countdown_text(ev), 20, Color(1.0, 0.85, 0.4) if live else UiTheme.TEXT_DIM)
	head.add_child(cd)
	_labels[ev["id"]] = cd
	v.add_child(wrap_lbl(str(ev["description"]), 18, UiTheme.TEXT))
	v.add_child(lbl("Periode: %s" % LiveEvents.range_text(ev), 16, UiTheme.TEXT_DIM))
	if ev["type"] == "banner":
		var cdata := Data.character(ev["character"])
		var owned := GameState.is_unlocked(ev["character"])
		v.add_child(lbl("Karakter: %s (%s)%s" % [cdata.display_name, cdata.role, "  — sudah dimiliki" if owned else ""], 18, cdata.accent.lightened(0.3)))
		if live:
			var eid: String = ev["id"]
			var b := btn("Ke Banner Gacha", func():
				host.open("gacha", {"banner": eid}), Vector2(260, 52), UiTheme.GOLD)
			b.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
			v.add_child(b)
	elif ev["type"] == "rate_up":
		var rdata := Data.character(ev["character"])
		var rowned := GameState.is_unlocked(ev["character"])
		v.add_child(lbl("Karakter: %s (%s)%s" % [rdata.display_name, rdata.role, "  — sudah dimiliki" if rowned else ""], 18, rdata.accent.lightened(0.3)))
		v.add_child(lbl("Peluang per tarikan: %s%% (Gacha Karakter standar)" % String.num(float(ev["rate"]) * 100.0, 1).trim_suffix(".0"), 18, Color(1.0, 0.85, 0.4)))
		if live:
			var rb := btn("Ke Gacha Karakter", func():
				host.open("gacha", {}), Vector2(260, 52), UiTheme.GOLD)
			rb.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
			v.add_child(rb)
	return c
