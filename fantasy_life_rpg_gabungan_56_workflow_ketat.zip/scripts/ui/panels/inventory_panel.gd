extends BasePanel
## Inventori: filter jenis, daftar item (jumlah), detail, pasang pada karakter, jual. Ramuan dipakai saat bertarung di stage.

var filter := "all"
var selected := ""
var _confirm_sell := ""
var _filters: HBoxContainer
var _list: VBoxContainer
var _detail: VBoxContainer
const FILTERS := [["all", "Semua"], ["weapon", "Senjata"], ["armor", "Armor"], ["accessory", "Aksesori"], ["potion", "Ramuan"]]


func _init() -> void:
	refresh_on = ["inventory", "equipment", "roster", "currency"]


func build() -> void:
	_filters = hbox(8)
	content.add_child(_filters)
	var row := hbox(14)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(row)
	var sl := scroll_list(470)
	row.add_child(sl[0])
	_list = sl[1]
	var right := PanelContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_stylebox_override("panel", UiTheme.box(Color(0.05, 0.11, 0.18), UiTheme.GOLD_DARK, 2, 14, 14))
	row.add_child(right)
	_detail = vbox(8)
	right.add_child(_detail)


func refresh() -> void:
	clear(_filters)
	for f in FILTERS:
		var key: String = f[0]
		_filters.add_child(btn(f[1], func():
			filter = key
			refresh(), Vector2(130, 48), UiTheme.GOLD if key == filter else Color(0, 0, 0, 0)))
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_filters.add_child(spacer)
	_filters.add_child(lbl("Gold: %d" % GameState.gold, 22, UiTheme.GOLD))
	clear(_list)
	var ids: Array = GameState.inventory.keys()
	ids.sort_custom(func(a, b):
		var x := Data.item(a)
		var y := Data.item(b)
		return x.rarity > y.rarity if x.rarity != y.rarity else x.display_name < y.display_name)
	var n := 0
	var first := ""
	for id in ids:                                       # item pertama yang tampil dipilih otomatis bila belum ada pilihan
		var it0 := Data.item(id)
		if it0 != null and (filter == "all" or it0.type == filter):
			first = id
			break
	if (selected == "" or Data.item(selected) == null or GameState.item_count(selected) <= 0) and first != "":
		selected = first
	for id in ids:
		var it := Data.item(id)
		if it == null or (filter != "all" and it.type != filter):
			continue
		n += 1
		var iid: String = id
		_list.add_child(item_row(it, "×%d" % GameState.item_count(iid), func():
			selected = iid
			_confirm_sell = ""
			refresh(), iid == selected))
	if n == 0:
		_list.add_child(wrap_lbl("Tidak ada item. Beli di toko, kerjakan quest, atau panggil di Altar Bintang.", 20, UiTheme.TEXT_DIM))
	if selected != "" and GameState.item_count(selected) <= 0:
		selected = ""
	_fill_detail()


func _fill_detail() -> void:
	clear(_detail)
	if selected == "":
		_detail.add_child(lbl("Pilih item di sebelah kiri.", 22, UiTheme.TEXT_DIM))
		return
	var it := Data.item(selected)
	_detail.add_child(lbl(it.display_name, 28, rarity_color(it.rarity).lightened(0.3)))
	_detail.add_child(lbl("%s · %s · Dimiliki %d" % [type_name(it.type), stars_text(it.rarity), GameState.item_count(selected)], 18, UiTheme.SKY))
	_detail.add_child(wrap_lbl(it.description, 19, UiTheme.TEXT_DIM))
	_detail.add_child(lbl(item_stats(it), 22, UiTheme.GOLD))
	var sp := Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_detail.add_child(sp)
	if it.type == "potion":
		_detail.add_child(wrap_lbl("Ramuan dipakai saat bertarung di stage (tombol Ramuan). Di lobi HP selalu penuh.", 17, UiTheme.TEXT_DIM))
	else:
		_detail.add_child(lbl("Pasang pada:", 18, UiTheme.TEXT_DIM))
		var pr := HFlowContainer.new()
		pr.add_theme_constant_override("h_separation", 8)
		pr.add_theme_constant_override("v_separation", 8)
		for cid in Data.character_ids():
			if not GameState.is_unlocked(cid) or not GameState.can_equip(cid, selected):
				continue
			var c: String = cid
			pr.add_child(btn(Data.character(c).display_name, func():
				if GameState.equip(c, selected):
					Sfx.play("pickup")
					toast("%s dipasang pada %s." % [it.display_name, Data.character(c).display_name]), Vector2(120, 46)))
		_detail.add_child(pr)
	var price := it.sell_price()
	var danger := price >= 400
	var sell_text := "Jual 1  (+%d gold)" % price
	if danger and _confirm_sell == selected:
		sell_text = "Yakin? Ketuk lagi untuk menjual"
	_detail.add_child(btn(sell_text, func():
		if danger and _confirm_sell != selected:
			_confirm_sell = selected
			refresh()
			return
		if GameState.sell_item(selected):
			Sfx.play("pickup")
			toast("Terjual: %s (+%d gold)" % [it.display_name, price])
		_confirm_sell = "", Vector2(0, 54)))
