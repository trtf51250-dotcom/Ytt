extends BasePanel
## Kumpulan cerita: adegan yang sudah dibaca bisa diputar ulang; yang belum tampil sebagai "???" sampai dimainkan.

var _list: VBoxContainer


func _init() -> void:
	refresh_on = ["story"]


func build() -> void:
	var sl := scroll_list(0)
	sl[0].size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(sl[0])
	_list = sl[1]


func refresh() -> void:
	clear(_list)
	var last_ch := ""
	for sc in Story.scenes():
		var ch := str(sc.get("chapter", ""))
		if ch != "" and ch != last_ch:
			last_ch = ch
			_list.add_child(lbl(ch, 22, UiTheme.GOLD))
		elif ch == "" and last_ch == "" and _list.get_child_count() == 0:
			last_ch = "Prolog"
		var seen := Story.seen(sc["id"])
		var c := card(UiTheme.GOLD_DARK if seen else UiTheme.TEXT_DIM, Color(0.08, 0.16, 0.26) if seen else Color(0.06, 0.12, 0.17))
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var r := hbox(12)
		c.add_child(r)
		var col := vbox(2)
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		r.add_child(col)
		col.add_child(lbl(str(sc["title"]) if seen else "???", 22, UiTheme.TEXT if seen else UiTheme.TEXT_DIM))
		var where := "Lobi" if sc["where"] == "lobby" else ("Wilayah Jelajah" if str(sc.get("stage", "")).begins_with("f_") else "Stage %s" % str(sc.get("stage", "")).replace("_", "-").to_upper())
		col.add_child(lbl(("%s · %d dialog" % [where, (sc["lines"] as Array).size()]) if seen else "Mainkan stage terkait untuk membuka", 15, UiTheme.TEXT_DIM))
		if seen:
			var id: String = sc["id"]
			r.add_child(btn("Baca ulang", func(): StoryPlayer.play(self, id, true), Vector2(170, 50), UiTheme.GOLD))
		_list.add_child(c)
