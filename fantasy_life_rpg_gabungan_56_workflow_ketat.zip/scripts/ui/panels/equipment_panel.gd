extends BasePanel
## Equipment (dirombak total). Tiga kolom yang selalu muat di layar:
##   kiri   = daftar karakter (vertikal, bisa digulir) — dulu tab horizontal yang melebar melewati layar
##   tengah = 3 slot (senjata / armor / aksesori) + stat total
##   kanan  = item yang cocok untuk slot terpilih, dengan SELISIH stat nyata (sudah termasuk bintang & tempaan) dan tanda TERBAIK
## Satu ketukan pada item = pasang. "Pasang Terbaik" memilih item berkekuatan tertinggi untuk ketiga slot sekaligus.
## Semua teks dipotong (clip_text) supaya lebar jendela tidak pernah melebihi layar.

const SLOT_LABEL := {"weapon": "Senjata", "armor": "Armor", "accessory": "Aksesori"}
const CLASS_LABEL := {"sword": "Pedang", "staff": "Tongkat", "guard": "Kapak & Palu", "bow": "Busur"}
const UP := Color(0.5, 0.95, 0.6)
const DOWN := Color(1.0, 0.55, 0.5)

var char_id := ""
var slot := "weapon"
var _sort := "power"                    # "power" (selisih Kekuatan) / "rarity" (kelangkaan)
var _rail_scroll: ScrollContainer
var _rail: VBoxContainer
var _mid: VBoxContainer
var _head: VBoxContainer
var _items: VBoxContainer
var _sel_chip: Control
var _scroll_pending := true


func _init() -> void:
	refresh_on = ["equipment", "inventory", "roster", "profile"]


func build() -> void:
	char_id = str(args.get("char", GameState.leader()))
	var want_slot := str(args.get("slot", "weapon"))
	slot = want_slot if want_slot in GameState.SLOTS else "weapon"
	var row := hbox(14)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(row)
	var rl := scroll_list(240)
	rl[0].custom_minimum_size = Vector2(240, 0)
	row.add_child(rl[0])
	_rail_scroll = rl[0]
	_rail = rl[1]
	var ml := scroll_list(370)
	ml[0].custom_minimum_size = Vector2(370, 0)
	row.add_child(ml[0])
	_mid = ml[1]
	var right := vbox(8)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_child(right)
	_head = vbox(6)
	right.add_child(_head)
	var il := scroll_list()
	il[0].size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_child(il[0])
	_items = il[1]


func refresh() -> void:
	var owned: Array = Data.character_ids().filter(func(i): return GameState.is_unlocked(i))
	if owned.is_empty():
		return
	if not owned.has(char_id):
		char_id = owned[0]
	_build_rail(owned)
	_build_mid()
	_build_right()
	if _scroll_pending:
		_scroll_pending = false
		_scroll_to_selected.call_deferred()


func _scroll_to_selected() -> void:
	await get_tree().process_frame
	if is_inside_tree() and _sel_chip != null and is_instance_valid(_sel_chip) and _rail_scroll != null:
		_rail_scroll.ensure_control_visible(_sel_chip)


## Label satu baris yang dipotong (tidak pernah melebarkan induknya).
func _clip(text: String, size: int, col: Color, min_w: float = 40.0) -> Label:
	var l := lbl(text, size, col)
	l.clip_text = true
	l.custom_minimum_size = Vector2(min_w, 0)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


func _delta_col(v: int) -> Color:
	if v > 0:
		return UP
	if v < 0:
		return DOWN
	return UiTheme.TEXT_DIM


# ------------------------------------------------------------------ kiri: karakter
func _build_rail(owned: Array) -> void:
	clear(_rail)
	_sel_chip = null
	for id in owned:
		var cid: String = id
		var cd := Data.character(cid)
		var sel := cid == char_id
		var c := card(UiTheme.GOLD if sel else cd.accent.darkened(0.2), Color(0.12, 0.25, 0.36) if sel else Color(0.08, 0.16, 0.26))
		var r := hbox(10)
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		c.add_child(r)
		var av := PanelContainer.new()
		av.custom_minimum_size = Vector2(46, 46)
		av.mouse_filter = Control.MOUSE_FILTER_IGNORE
		av.add_theme_stylebox_override("panel", UiTheme.box(cd.accent.darkened(0.15), Color(1, 1, 1, 0.8), 2, 23, 4))
		var ic := UiIcon.make("character", Color(1, 1, 1), 28)
		ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		av.add_child(ic)
		r.add_child(av)
		var col := vbox(0)
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.mouse_filter = Control.MOUSE_FILTER_IGNORE
		col.add_child(_clip(cd.display_name, 22, UiTheme.TEXT, 60))
		col.add_child(_clip("%s  %d" % ["★".repeat(GameState.stars(cid)), int(GameState.char_stats(cid)["power"])], 15, UiTheme.GOLD if sel else UiTheme.TEXT_DIM, 60))
		r.add_child(col)
		tap_on(c, _select_char.bind(cid))
		_rail.add_child(c)
		if sel:
			_sel_chip = c


func _select_char(cid: String) -> void:
	char_id = cid
	refresh()


func _select_slot(sname: String) -> void:
	slot = sname
	refresh()


# ------------------------------------------------------------------ tengah: slot + stat
func _build_mid() -> void:
	clear(_mid)
	var cd := Data.character(char_id)
	_mid.add_child(_clip(cd.display_name, 32, cd.accent.lightened(0.35), 80))
	_mid.add_child(_clip("%s · memakai %s" % [cd.role, CLASS_LABEL.get(cd.weapon_class, cd.weapon_class)], 17, UiTheme.SKY, 80))
	for s in GameState.SLOTS:
		_mid.add_child(_slot_row(s))
	var st := GameState.char_stats(char_id)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	for e: Array in [["HP", st["hp"], Color(0.5, 0.95, 0.6)], ["ATK", st["atk"], Color(1.0, 0.72, 0.45)], ["DEF", st["def"], UiTheme.SKY], ["Kekuatan", st["power"], UiTheme.GOLD]]:
		var box := card(Color(e[2], 0.55), Color(0.06, 0.13, 0.22))
		box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var v := vbox(0)
		v.add_child(_clip(str(e[0]), 15, UiTheme.TEXT_DIM, 40))
		v.add_child(_clip(str(int(e[1])), 28, e[2], 40))
		box.add_child(v)
		grid.add_child(box)
	_mid.add_child(grid)


func _slot_row(sname: String) -> Control:
	var cd := Data.character(char_id)
	var iid := GameState.equipped(char_id, sname)
	var sel := sname == slot
	var row := hbox(8)
	var holder := PanelContainer.new()
	holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	holder.add_theme_stylebox_override("panel", UiTheme.box(Color(0.12, 0.25, 0.36) if sel else Color(0.08, 0.16, 0.26), UiTheme.GOLD if sel else UiTheme.GOLD_DARK, 2, 12, 8))
	tap_on(holder, _select_slot.bind(sname))
	var h := hbox(10)
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(h)
	var v := vbox(0)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(_clip(SLOT_LABEL[sname].to_upper(), 13, UiTheme.GOLD if sel else UiTheme.TEXT_DIM, 40))
	if iid != "":
		var it := Data.item(iid)
		var plus := GameState.weapon_plus(char_id)
		var nm := it.display_name + ((" +%d" % plus) if sname == "weapon" and plus > 0 else "")
		h.add_child(UiIcon.make(item_icon_kind(it), rarity_color(it.rarity), 40))
		v.add_child(_clip(nm, 20, rarity_color(it.rarity).lightened(0.3), 60))
		v.add_child(_clip(item_stats(it), 15, UiTheme.TEXT_DIM, 60))
	else:
		var ik := weapon_icon_kind(cd.weapon_class) if sname == "weapon" else ("shield" if sname == "armor" else "star")
		h.add_child(UiIcon.make(ik, Color(0.4, 0.5, 0.62), 40))
		v.add_child(_clip("(kosong)", 20, UiTheme.TEXT_DIM, 60))
		v.add_child(_clip("Ketuk, lalu pilih item di kanan", 14, UiTheme.TEXT_DIM, 60))
	h.add_child(v)
	row.add_child(holder)
	if iid != "":
		row.add_child(btn("Lepas", _unequip.bind(sname), Vector2(76, 62)))
	return row


func _unequip(sname: String) -> void:
	GameState.unequip(char_id, sname)


# ------------------------------------------------------------------ kanan: item
func _build_right() -> void:
	clear(_head)
	var top := hbox(8)
	top.add_child(_clip("Pilih %s" % SLOT_LABEL[slot].to_lower(), 26, UiTheme.GOLD, 60))
	top.add_child(btn("Pasang Terbaik", _equip_best, Vector2(170, 48), UiTheme.BLUE))
	_head.add_child(top)
	var srt := hbox(8)
	srt.add_child(lbl("Urutkan:", 16, UiTheme.TEXT_DIM))
	srt.add_child(btn("Kekuatan", _set_sort.bind("power"), Vector2(110, 40), UiTheme.GOLD if _sort == "power" else Color(0, 0, 0, 0)))
	srt.add_child(btn("Langka", _set_sort.bind("rarity"), Vector2(96, 40), UiTheme.GOLD if _sort == "rarity" else Color(0, 0, 0, 0)))
	_head.add_child(srt)

	clear(_items)
	var base := GameState.char_stats(char_id)
	var entries: Array = []
	for iid in GameState.inventory.keys():
		var it := Data.item(iid)
		if it == null or it.type != slot or not GameState.can_equip(char_id, iid):
			continue
		var ns := GameState.char_stats_with(char_id, slot, iid)
		entries.append({"id": iid, "it": it, "n": GameState.item_count(iid), "dp": int(ns["power"]) - int(base["power"]),
				"dhp": int(ns["hp"]) - int(base["hp"]), "datk": int(ns["atk"]) - int(base["atk"]), "ddef": int(ns["def"]) - int(base["def"])})
	if entries.is_empty():
		_items.add_child(wrap_lbl("Tidak ada %s yang cocok di inventori. Beli di Toko Senjata (Rowan) atau panggil di Altar Bintang." % SLOT_LABEL[slot].to_lower(), 19, UiTheme.TEXT_DIM))
		return
	var best_dp := -999999
	for e: Dictionary in entries:
		best_dp = maxi(best_dp, int(e["dp"]))
	if _sort == "rarity":
		entries.sort_custom(func(a, b): return a["it"].rarity > b["it"].rarity or (a["it"].rarity == b["it"].rarity and a["dp"] > b["dp"]))
	else:
		entries.sort_custom(func(a, b): return a["dp"] > b["dp"] or (a["dp"] == b["dp"] and a["it"].rarity > b["it"].rarity))
	for e: Dictionary in entries:
		_items.add_child(_gear_row(e, int(e["dp"]) == best_dp and best_dp > 0))


func _gear_row(e: Dictionary, is_best: bool) -> Control:
	var it: ItemData = e["it"]
	var dp: int = e["dp"]
	var c := card(rarity_color(it.rarity).darkened(0.05 if is_best else 0.3), Color(0.1, 0.24, 0.3) if is_best else Color(0.08, 0.16, 0.26))
	var r := hbox(12)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.add_child(r)
	r.add_child(UiIcon.make(item_icon_kind(it), rarity_color(it.rarity), 52))
	var col := vbox(0)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var nr := hbox(8)
	nr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	nr.add_child(_clip(it.display_name, 22, rarity_color(it.rarity).lightened(0.3), 60))
	if is_best:
		var tag := lbl("TERBAIK", 13, Color(1.0, 0.85, 0.4))
		tag.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		nr.add_child(tag)
	col.add_child(nr)
	var cnt := ("   ×%d" % int(e["n"])) if int(e["n"]) > 1 else ""
	col.add_child(_clip("%s%s" % [item_stats(it), cnt], 16, UiTheme.TEXT_DIM, 60))
	col.add_child(_clip(stars_text(it.rarity, it.rarity), 14, rarity_color(it.rarity), 60))
	r.add_child(col)
	var rv := vbox(0)
	rv.custom_minimum_size = Vector2(120, 0)
	rv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var pl := lbl("%+d" % dp if dp != 0 else "±0", 28, _delta_col(dp))
	pl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	rv.add_child(pl)
	var cap := lbl("Kekuatan", 13, UiTheme.TEXT_DIM)
	cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	rv.add_child(cap)
	var parts: PackedStringArray = []
	if int(e["datk"]) != 0:
		parts.append("ATK %+d" % int(e["datk"]))
	if int(e["ddef"]) != 0:
		parts.append("DEF %+d" % int(e["ddef"]))
	if int(e["dhp"]) != 0:
		parts.append("HP %+d" % int(e["dhp"]))
	var dl := _clip(" · ".join(parts) if not parts.is_empty() else "stat sama", 13, UiTheme.TEXT_DIM, 60)
	dl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	rv.add_child(dl)
	r.add_child(rv)
	tap_on(c, _equip.bind(str(e["id"])))
	return c


func _set_sort(k: String) -> void:
	_sort = k
	refresh()


func _equip(iid: String) -> void:
	var before := int(GameState.char_stats(char_id)["power"])
	if GameState.equip(char_id, iid):
		Sfx.play("pickup")
		var after := int(GameState.char_stats(char_id)["power"])
		toast("%s dipasang  ·  Kekuatan %d → %d (%+d)" % [Data.item(iid).display_name, before, after, after - before])


## Pasang item berkekuatan tertinggi di tiap slot (hanya bila benar-benar lebih kuat dari yang terpasang).
func _equip_best() -> void:
	var before := int(GameState.char_stats(char_id)["power"])
	var n := 0
	for s in GameState.SLOTS:
		var best_p := int(GameState.char_stats(char_id)["power"])
		var best_id := ""
		for iid in GameState.inventory.keys():
			var it := Data.item(iid)
			if it == null or it.type != s or not GameState.can_equip(char_id, iid):
				continue
			var p := int(GameState.char_stats_with(char_id, s, iid)["power"])
			if p > best_p:
				best_p = p
				best_id = iid
		if best_id != "" and GameState.equip(char_id, best_id):
			n += 1
	if n == 0:
		toast("Sudah memakai yang terbaik dari inventori.")
		return
	Sfx.play("pickup")
	var after := int(GameState.char_stats(char_id)["power"])
	toast("%d slot diperbarui  ·  Kekuatan %d → %d (%+d)" % [n, before, after, after - before])
