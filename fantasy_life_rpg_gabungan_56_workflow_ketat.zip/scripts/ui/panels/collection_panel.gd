extends BasePanel
## Koleksi: kemajuan karakter yang dimiliki dan item/perlengkapan yang pernah dipegang, dengan bilah kemajuan.

func _init() -> void:
	refresh_on = ["roster", "inventory", "equipment"]


func build() -> void:
	pass


func _bar(title: String, have: int, total: int, col: Color) -> Control:
	var c := card()
	var v := vbox(6)
	c.add_child(v)
	var h := hbox(10)
	h.add_child(lbl(title, 22, UiTheme.TEXT))
	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(sp)
	h.add_child(lbl("%d / %d" % [have, total], 22, col))
	v.add_child(h)
	var pb := ProgressBar.new()
	pb.max_value = maxf(total, 1)
	pb.value = have
	pb.show_percentage = false
	pb.custom_minimum_size = Vector2(0, 16)
	var fg := StyleBoxFlat.new()
	fg.bg_color = col
	fg.set_corner_radius_all(8)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.03, 0.07, 0.13)
	bg.set_corner_radius_all(8)
	pb.add_theme_stylebox_override("fill", fg)
	pb.add_theme_stylebox_override("background", bg)
	v.add_child(pb)
	return c


func refresh() -> void:
	clear(content)
	var gs := GameState
	var ids: Array = Data.character_ids()
	var owned := 0
	for id in ids:
		if gs.is_unlocked(id):
			owned += 1
	content.add_child(_bar("Karakter", owned, ids.size(), Color(0.75, 0.6, 1.0)))
	# item yang pernah dipegang = ada di tas atau sedang dipakai karakter yang dimiliki
	var have := {}
	for iid in gs.inventory:
		if int(gs.inventory[iid]) > 0:
			have[iid] = true
	for id in ids:
		if gs.is_unlocked(id):
			for slot in gs.SLOTS:
				var e := str(gs.equipped(id, slot))
				if e != "":
					have[e] = true
	var by_type := {}
	var tot_type := {}
	for iid in Data.items:
		var it: ItemData = Data.items[iid]
		var t: String = it.type
		tot_type[t] = int(tot_type.get(t, 0)) + 1
		if have.has(iid):
			by_type[t] = int(by_type.get(t, 0)) + 1
	content.add_child(_bar("Semua item", have.size(), Data.items.size(), UiTheme.GOLD))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 10)
	content.add_child(grid)
	for t in tot_type:
		var b := _bar(type_name(t), int(by_type.get(t, 0)), int(tot_type[t]), UiTheme.SKY)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(b)
	var chips := HFlowContainer.new()
	chips.add_theme_constant_override("h_separation", 8)
	chips.add_theme_constant_override("v_separation", 8)
	for id in ids:
		var cd := Data.character(id)
		var own: bool = gs.is_unlocked(id)
		var chip := PanelContainer.new()
		chip.add_theme_stylebox_override("panel", UiTheme.box(Color(0.09, 0.19, 0.30) if own else Color(0.05, 0.10, 0.16), rarity_color(cd.rarity) if own else Color(0.3, 0.34, 0.5), 2, 10, 8))
		chip.add_child(lbl(("%s %s" % [cd.display_name, stars_text(cd.rarity, cd.rarity)]) if own else "??? (%s)" % stars_text(cd.rarity, cd.rarity), 17, UiTheme.TEXT if own else UiTheme.TEXT_DIM))
		chips.add_child(chip)
	content.add_child(chips)
	content.add_child(wrap_lbl("Dapatkan lebih banyak lewat Altar Bintang, Toko, Tempa, dan stage.", 16, UiTheme.TEXT_DIM))
