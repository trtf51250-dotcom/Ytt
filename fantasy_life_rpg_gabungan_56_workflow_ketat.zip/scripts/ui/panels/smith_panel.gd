extends BasePanel
## Blacksmith Tobias: tempa senjata yang sedang dipakai karakter terpilih sampai +10. Tiap tingkat menambah ATK; biaya naik.

var char_id := ""
var _tabs: HBoxContainer
var _body: VBoxContainer


func _init() -> void:
	refresh_on = ["equipment", "currency", "roster"]


func build() -> void:
	char_id = str(args.get("char", GameState.leader()))
	_tabs = hbox(8)
	content.add_child(_tabs)
	var box := PanelContainer.new()
	box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_theme_stylebox_override("panel", UiTheme.box(Color(0.05, 0.11, 0.18), UiTheme.GOLD_DARK, 2, 14, 18))
	content.add_child(box)
	_body = vbox(10)
	box.add_child(_body)


func refresh() -> void:
	clear(_tabs)
	for id in Data.character_ids():
		if not GameState.is_unlocked(id):
			continue
		var cid: String = id
		_tabs.add_child(btn(Data.character(cid).display_name, func():
			char_id = cid
			refresh(), Vector2(130, 48), UiTheme.GOLD if cid == char_id else Color(0, 0, 0, 0)))
	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tabs.add_child(sp)
	var gl := hbox(6)
	gl.add_child(UiIcon.make("gold", Color(1, 1, 1), 30))
	gl.add_child(lbl("%d" % GameState.gold, 24, UiTheme.GOLD))
	_tabs.add_child(gl)
	clear(_body)
	var iid := GameState.equipped(char_id, "weapon")
	if iid == "":
		_body.add_child(lbl("Karakter ini tidak memegang senjata. Pasang dulu di menu Equipment.", 22, UiTheme.TEXT_DIM))
		return
	var it := Data.item(iid)
	var plus := GameState.weapon_plus(char_id)
	var per := maxi(2, int(it.atk * 0.12))
	_body.add_child(lbl("%s%s" % [it.display_name, (" +%d" % plus) if plus > 0 else ""], 34, rarity_color(it.rarity).lightened(0.3)))
	_body.add_child(lbl("Tingkat tempa: %d / 10" % plus, 22, UiTheme.SKY))
	_body.add_child(UiTheme.bar(UiTheme.GOLD, plus / 10.0, 18.0))
	var cur: int = GameState.char_stats(char_id)["atk"]
	_body.add_child(lbl("ATK karakter sekarang: %d" % cur, 24, UiTheme.TEXT))
	if plus >= 10:
		_body.add_child(lbl("Senjata ini sudah mencapai tingkat maksimum.", 22, UiTheme.GOOD))
		return
	var delta := int(per * (1.0 + 0.12 * (GameState.stars(char_id) - 1)))
	_body.add_child(lbl("Tempa ke +%d: ATK +%d (menjadi %d)" % [plus + 1, delta, cur + delta], 22, UiTheme.GOOD))
	var cost := GameState.upgrade_cost(char_id)
	var sp2 := Control.new()
	sp2.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body.add_child(sp2)
	var b := btn("Tempa  (%d gold)" % cost, func():
		if GameState.upgrade_weapon(char_id):
			Sfx.play("break", 0.8)
			Sfx.play("chest", 1.2, -4.0)
			toast("Berhasil! %s menjadi +%d" % [it.display_name, GameState.weapon_plus(char_id)])
		else:
			toast("Gold tidak cukup."), Vector2(0, 66), UiTheme.GOLD)
	b.disabled = GameState.gold < cost
	_body.add_child(b)
	if GameState.gold < cost:
		_body.add_child(lbl("Gold kurang %d." % (cost - GameState.gold), 18, UiTheme.BAD))
