class_name Vignette
extends CanvasLayer
## Vinyet kristal: tepi layar sedikit gelap kehijauan-biru supaya mata tertuju ke tengah dan HUD menyatu dengan dunia.
## Satu TextureRect statis (tanpa shader/ proses per frame). Dimatikan di kualitas Lancar (menghemat fill-rate HP lemah).

static func attach(parent: Node) -> void:
	if parent == null or parent.has_node("Vignette") or Quality.level() < 1:
		return
	var v := Vignette.new()
	v.name = "Vignette"
	v.layer = 1
	parent.add_child(v)
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.6, 1.0])
	g.colors = PackedColorArray([Color(0.0, 0.05, 0.1, 0.0), Color(0.0, 0.05, 0.1, 0.0), Color(0.0, 0.04, 0.09, 0.42 if Quality.level() >= 2 else 0.3)])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.05, 0.5)
	gt.width = 256
	gt.height = 144
	var r := TextureRect.new()
	r.texture = gt
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_SCALE
	r.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(r)
