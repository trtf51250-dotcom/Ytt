# Login Google & simpanan akun (Saved Games)

**Status jujur:** kode game (`autoload/cloud_save.gd`, bungkus akun di `GameState`, tombol di Pengaturan > Data dan Layar Judul) sudah ada dan
bagian bungkus/pulih sudah dites otomatis. Bagian yang bicara ke Google (`cloud_save.gd`) **belum pernah dijalankan di HP**, karena butuh plugin Android
dan akun Google Play Console milikmu. Tanpa plugin, tombol Google nonaktif dan data tetap lokal seperti biasa.

## Langkah
1. **Play Console**: buat aplikasi (paket mis. `com.namamu.fantasylife`). Menu *Play Games Services* > Setup > buat *credentials* tipe Android
   (butuh SHA-1 keystore rilis dan debug). Aktifkan fitur **Saved games** (cadangan permainan). Tambahkan akunmu sebagai penguji.
2. **Plugin**: pasang plugin "Godot Play Game Services" (godot-sdk-integrations/godot-play-game-services, untuk Godot 4.2+) lewat AssetLib atau GitHub,
   aktifkan di Project > Project Settings > Plugins, dan isi *App ID* Play Games di konfigurasinya.
3. **Export Android**: Project > Install Android Build Template, aktifkan *Use Gradle Build*, centang plugin di preset export.
4. Jalankan di HP. Di Pengaturan > Data > "Akun Google": **Masuk dengan Google**, lalu **Simpan sekarang**.
5. **HP baru**: pasang game, Layar Judul > *Pulihkan dari Akun Google* (atau Pengaturan > Pulihkan).

## Bila plugin berbeda versi
Semua nama ada di bagian atas `autoload/cloud_save.gd` (`PLUGIN_NODE`, `SIGNIN_NODE`, `SNAP_NODE`, sinyal `user_authenticated`, `game_saved`, `game_loaded`,
metode `sign_in`, `save_game`, `load_game`). Sesuaikan di sana; bagian lain tidak perlu diubah.

## Perilaku
- Setiap simpan otomatis juga diunggah (jeda minimal 20 dtk), bila sudah masuk Google.
- Data diikat ke **akun** (hash ID pemain Google) dan ditandatangani, bukan ke perangkat; akun lain ditolak.
- Pulihkan saat HP sudah punya data berbeda: **tidak menimpa diam-diam**; ketuk Pulihkan sekali lagi untuk menimpa.
- Hapus data di HP **tidak** menghapus salinan di akun Google.
- Kode cadangan lama (terikat perangkat) tetap ada sebagai cadangan lain.
