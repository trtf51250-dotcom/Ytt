// Bagian bersama shader dunia (world*.gdshader).
// Mesh dibangun oleh MeshKit dengan konvensi:
//   UV      = koordinat tekstur dalam satuan "ulangan petak" (fract() dipakai di shader)
//   UV2.x   = nomor petak (baris * 8 + kolom di world_atlas.png) = nomor lapisan pada array tekstur
//   Atlas dipecah menjadi Texture2DArray oleh WorldMats: tiap petak punya mipmap sendiri & pengulangan mulus (tanpa kebocoran
//   antar petak, tanpa garis sambungan), sehingga permukaan jauh tidak berkedip dan lantai miring tetap tajam (anisotropik).
//   UV2.y   = bobot goyangan angin (0 = kaku)
//   COLOR.rgb = warna pewarna (dikali tekstur), COLOR.a = 1 - kuat emisi (1 = tidak bercahaya)
uniform sampler2DArray atlas : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform float glow = 0.4;          // kuat cahaya emisi (siang kecil, malam besar) - diatur DayNight
uniform float wind = 1.0;

uniform float saturation = 0.9;   // sedikit menurunkan kejenuhan agar warna pastel, tidak neon
uniform float tone = 0.95;         // pengali kecerahan albedo

varying flat float v_tile;

vec3 grade(vec3 c) {
	float l = dot(c, vec3(0.299, 0.587, 0.114));
	return mix(vec3(l), c, saturation) * tone;
}

void world_vertex(inout vec3 vtx, vec2 uv2, mat4 model) {
	if (uv2.y > 0.0) {
		vec3 wp = (model * vec4(vtx, 1.0)).xyz;
		float t = TIME * 1.7 + wp.x * 0.33 + wp.z * 0.29;
		vtx.x += sin(t) * 0.07 * uv2.y * wind;
		vtx.z += cos(t * 0.83) * 0.05 * uv2.y * wind;
	}
}

vec4 world_sample(vec2 uv) {
	float layer = floor(v_tile + 0.5);
	// fract() menjaga angka kecil (presisi di HP); repeat_enable membuat tepi petak tersambung mulus.
	// Turunan dihitung dari uv ASLI (bukan fract) agar tidak melonjak di garis ulangan -> pilihan mipmap benar.
	return textureGrad(atlas, vec3(fract(uv), layer), dFdx(uv), dFdy(uv));
}

void light() {
	// bayangan berundak lembut ala anime: tiga tingkat terang
	float ndl = dot(NORMAL, LIGHT);
	float b = smoothstep(-0.12, 0.2, ndl) * 0.6 + smoothstep(0.5, 0.85, ndl) * 0.4;
	DIFFUSE_LIGHT += LIGHT_COLOR * ATTENUATION * b / PI;
}
