extends Node
## Ukur senjata menembus badan/kepala: tiap animasi tiap karakter disampel, vertex mesh senjata diuji terhadap elipsoid badan & bola kepala.
## Jalankan: godot --headless res://tools/clip_probe.tscn  (env CLIP_IDS=ren,vael  CLIP_VERBOSE=1)

func _verts(n: Node, rel: Transform3D, out: Array) -> void:
	if n is MeshInstance3D and (n as MeshInstance3D).mesh != null:
		var t := rel * (n as MeshInstance3D).transform
		for v in (n as MeshInstance3D).mesh.get_faces():
			out.append(t * v)
	for c in n.get_children():
		if c is Node3D:
			_verts(c, rel * (c as Node3D).transform if not (n is MeshInstance3D and c == n) else rel, out)

func _collect(holder: Node3D) -> Array:
	var out := []
	for c in holder.get_children():
		if c is Node3D:
			_walk(c as Node3D, Transform3D.IDENTITY, out)
	return out

func _walk(n: Node3D, parent_rel: Transform3D, out: Array) -> void:
	var t := parent_rel * n.transform
	if n is MeshInstance3D and (n as MeshInstance3D).mesh != null:
		var faces: PackedVector3Array = (n as MeshInstance3D).mesh.get_faces()
		var step := maxi(1, faces.size() / 400)
		for i in range(0, faces.size(), step):
			out.append(t * faces[i])
	for c in n.get_children():
		if c is Node3D:
			_walk(c as Node3D, t, out)

func _apply(rig: CharacterRig, anim: Animation, tm: float) -> void:
	var sk := rig.skel
	for ti in anim.get_track_count():
		var p := str(anim.track_get_path(ti))
		var bn := p.get_slice(":", 1)
		var bi := sk.find_bone(bn)
		if bi < 0:
			continue
		if anim.track_get_type(ti) == Animation.TYPE_ROTATION_3D:
			sk.set_bone_pose_rotation(bi, anim.rotation_track_interpolate(ti, tm))
		elif anim.track_get_type(ti) == Animation.TYPE_POSITION_3D:
			sk.set_bone_pose_position(bi, anim.position_track_interpolate(ti, tm))

# kedalaman tembus (meter) satu titik terhadap badan/kepala; 0 = di luar
func _depth(sk: Skeleton3D, wp: Vector3, ms: float) -> Vector2:
	var inv := sk.global_transform.affine_inverse()
	var p := inv * wp            # ruang skeleton (satuan model)
	var head := sk.get_bone_global_pose(sk.find_bone("head"))
	var hl := head.affine_inverse() * p - Vector3(0, 0.25, 0.0)
	var he := sqrt((hl.x / 0.34) * (hl.x / 0.34) + (hl.y / 0.36) * (hl.y / 0.36) + (hl.z / 0.33) * (hl.z / 0.33))
	var head_pen := maxf(0.0, 1.0 - he) * 0.33 * ms
	# badan: elipsoid sepanjang pinggul -> leher, dibaca di bingkai chest/hips
	var hips := sk.get_bone_global_pose(sk.find_bone("hips"))
	var chest := sk.get_bone_global_pose(sk.find_bone("chest"))
	var a := hips * Vector3(0, 0.05, 0)
	var b := chest * Vector3(0, 0.50, 0)
	var ab := b - a
	var tt := clampf((p - a).dot(ab) / ab.length_squared(), 0.0, 1.0)
	var c := a + ab * tt
	var fr := hips.basis.slerp(chest.basis, tt)
	var loc := fr.inverse() * (p - c)
	var rx := 0.30 if tt > 0.15 else 0.27
	var rz := 0.17
	var e := sqrt((loc.x / rx) * (loc.x / rx) + (loc.z / rz) * (loc.z / rz))
	var body_pen := maxf(0.0, 1.0 - e) * rz * ms if absf(loc.y) < 0.01 or true else 0.0
	return Vector2(body_pen, head_pen)

func _ready() -> void:
	await get_tree().process_frame
	var only := OS.get_environment("CLIP_IDS")
	var verbose := OS.get_environment("CLIP_VERBOSE") != ""
	var report := {}
	for cid in Data.character_ids():
		if only != "" and not (cid in only.split(",")):
			continue
		var data = Data.character(cid)
		var rig := CharacterRig.new()
		add_child(rig)
		rig.setup(1.8, load(data.skin_path), true, true)
		rig.set_weapon_class(data.anim_style if data.anim_style != "" else data.weapon_class)
		rig.set_style(cid)
		rig.set_skill_kind(data.skill_kind)
		rig.set_ult_kind(data.ult_kind)
		CharacterLooks.apply_hero(rig, cid)
		var names := {}
		for k in rig._anim_nodes:
			names[str(rig._anim_nodes[k].animation)] = k
		for fn in AnimLibrary.fidgets(cid):
			names[AnimLibrary.fit(fn, cid)] = "fidget"
		for bi in 4:
			var bn = rig._space.get_blend_point_node(bi)
			names[str(bn.animation)] = "move"
		var ms := rig.model_scale
		var wr := _collect(rig.weapon_holder)
		var wl := _collect(rig.weapon_holder_l)
		for pr in [["R", wr], ["L", wl]]:
			if pr[1].is_empty(): continue
			var mn := Vector3(1e9, 1e9, 1e9)
			var mx := Vector3(-1e9, -1e9, -1e9)
			for v in pr[1]:
				mn = mn.min(v); mx = mx.max(v)
			var bins := {}
			for v in pr[1]:
				var bk: int = int(floor(v.y / 0.2))
				var e: Vector2 = bins.get(bk, Vector2.ZERO)
				bins[bk] = Vector2(maxf(e.x, absf(v.x)), maxf(e.y, absf(v.z)))
			var ks := bins.keys(); ks.sort()
			var line := ""
			for bk in ks:
				line += " y%.1f:x%.2f,z%.2f" % [bk * 0.2, bins[bk].x, bins[bk].y]
			print("BINS %s %s%s" % [cid, pr[0], line])
			var gen := []
			var seenq := {}
			var ymn := 9.0
			var ymx := -9.0
			for v in pr[1]:
				ymn = minf(ymn, v.y); ymx = maxf(ymx, v.y)
				if absf(v.x) > 0.07 or absf(v.z) > 0.07:
					var key := Vector3(snappedf(v.x, 0.06), snappedf(v.y, 0.06), snappedf(v.z, 0.06))
					if not seenq.has(key):
						seenq[key] = true
						gen.append("Vector3(%.2f, %.2f, %.2f)" % [v.x, v.y, v.z])
			var yy := ymn
			while yy <= ymx + 0.001:
				gen.append("Vector3(0, %.2f, 0)" % yy)
				yy += 0.2
			gen.append("Vector3(0, %.2f, 0)" % ymx)
			print("GEN %s %s [%s]" % [cid, pr[0], ", ".join(gen)])
			print("SPAN %s %s min=%s max=%s" % [cid, pr[0], mn.snapped(Vector3(0.01,0.01,0.01)), mx.snapped(Vector3(0.01,0.01,0.01))])
		for an in names:
			var anim: Animation = rig.player.get_animation(an)
			if anim == null:
				continue
			var worst_b := 0.0
			var worst_h := 0.0
			var at_b := 0.0
			var at_h := 0.0
			var bad := 0
			var ftr := AnimLibrary._fit_tracks(anim)
			var n := anim.track_get_key_count(ftr["hips"]) - 1
			var fw := AnimLibrary.fit_weapon(cid)
			for i in n + 1:
				var tm := anim.track_get_key_time(ftr["hips"], i)
				_apply(rig, anim, tm)
				var sk := rig.skel
				var hb := sk.global_transform * sk.get_bone_global_pose(sk.find_bone("hand_r"))
				var hbl := sk.global_transform * sk.get_bone_global_pose(sk.find_bone("hand_l"))
				var tr_r := hb * rig.weapon_holder.transform
				var tr_l := hbl * rig.weapon_holder_l.transform
				var fb := 0.0
				var fh := 0.0
				for pair in [[wr, tr_r, hb.origin], [wl, tr_l, hbl.origin]]:
					for v in pair[0]:
						var wp: Vector3 = (pair[1] as Transform3D) * (v as Vector3)
						if wp.distance_to(pair[2]) < 0.28:
							continue
						var d := _depth(sk, wp, 1.0 / ms * ms)
						if d.x > fb and OS.get_environment("CLIP_CMP") == an and tm > 0.35 and tm < 0.5:
							print("WORSTV ", v, " depth ", d.x)
						fb = maxf(fb, d.x)
						fh = maxf(fh, d.y)
				if OS.get_environment("CLIP_CMP") != "" and an == OS.get_environment("CLIP_CMP"):
					var fr := AnimLibrary._fit_frame(anim, ftr, i)
					print("CMP %s t=%.2f real=%.3f/%.3f model=%.3f" % [an, tm, fb, fh, AnimLibrary._fit_pen(fr[0], fr[1], PackedFloat32Array([0,0,0,0,0,0,0,0]), fw)])
				if fb > worst_b: worst_b = fb; at_b = tm
				if fh > worst_h: worst_h = fh; at_h = tm
				if fb > 0.03 or fh > 0.03: bad += 1
			report["%s/%s" % [cid, an]] = [worst_b, worst_h, bad, at_b, at_h]
			if verbose or worst_b > 0.03 or worst_h > 0.03:
				print("%-8s %-22s body=%.3f@%.2f head=%.3f@%.2f badframes=%d/%d" % [cid, an, worst_b, at_b, worst_h, at_h, bad, 25])
		rig.queue_free()
	var nb := 0
	for k in report:
		if report[k][0] > 0.03 or report[k][1] > 0.03: nb += 1
	print("CLIP SUMMARY anim_bermasalah=%d dari %d" % [nb, report.size()])
	get_tree().quit()
