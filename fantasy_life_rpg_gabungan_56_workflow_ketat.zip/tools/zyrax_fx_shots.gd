extends RefCounted
## Foto efek Zyrax: teleport, skill Ranjau Void, dan ULTI Void Requiem (butuh renderer: xvfb + opengl3, --shots=DIR).
func run(st: Node3D) -> void:
	var t := st.get_tree()
	st.autoplay = false
	await t.create_timer(0.8).timeout
	for e in t.get_nodes_in_group("enemies"):
		e.queue_free()
	var p: Player = st.player
	p.invuln = 999.0
	GameState.unlock_character("zyrax")
	p.set_character("zyrax")
	p.control_enabled = true
	var B := Vector3(0, 0.1, 0)
	p.global_position = B
	p.facing = 0.0
	var cam := Camera3D.new()
	st.add_child(cam)
	cam.fov = 55.0
	cam.current = true
	cam.global_position = B + Vector3(0, 9.0, -11.0)
	cam.look_at(B + Vector3(0, 1.0, 4.0), Vector3.UP)
	var mons: Array = []
	for i in 5:
		var e: Enemy = st._spawn_enemy("slime", B + Vector3(-6.0 + i * 3.0, 0, 5.0 + (i % 2) * 3.0))
		mons.append(e)
	await t.create_timer(1.2).timeout
	for e in mons:
		e.hp = 99999999
		e.max_hp = 99999999
		e.set_physics_process(false)
	await st._shot("zx_0_idle")
	# teleport
	p._act_t = 0.0
	p.dodge_cd = 0.0
	p.do_dodge()
	await t.create_timer(0.06).timeout
	await st._shot("zx_1_teleport_mid")
	await t.create_timer(0.25).timeout
	await st._shot("zx_2_teleport_after")
	p.global_position = B
	p.velocity = Vector3.ZERO
	p.facing = 0.0
	await t.create_timer(1.0).timeout
	# skill
	p.mana = p.max_mana
	p.skill_cd = 0.0
	p._act_t = 0.0
	p.do_skill()
	await t.create_timer(0.9).timeout
	await st._shot("zx_3_skill_a")
	await t.create_timer(0.7).timeout
	await st._shot("zx_4_skill_b")
	await t.create_timer(1.5).timeout
	# ulti
	p._act_t = 0.0
	st.try_ult()
	for k in 8:
		await t.create_timer(0.4).timeout
		await st._shot("zx_5_ult_%d" % k)
