extends RefCounted
## Kiriel: serangan jarak jauh, skill Petir Berantai, ULTI 2x dengan wujud Pedang Petir (5 dtk di bintang 1, 20 dtk di bintang 5).
##   res://scenes/stages/stage.tscn -- --bot=1 --botscript=kiriel_bot --stage=s1_1 --nocine=1 --fresh [--shots=DIR]
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1

func _lost(mons: Array) -> int:
	var l := 0
	for e in mons:
		l += 100000 - (int(e.hp) if is_instance_valid(e) else 0)
	return l

func _spawn(st: Node3D, base: Vector3) -> Array:
	var t := st.get_tree()
	for e in t.get_nodes_in_group("enemies"):
		e.queue_free()
	await t.create_timer(0.3).timeout
	var mons: Array = []
	for i in 4:
		var e: Enemy = st._spawn_enemy("slime", base + Vector3(-3 + i * 2.0, 0, 4.0 + (i % 2) * 2.0))
		mons.append(e)
	await t.create_timer(1.0).timeout                  # tunggu animasi muncul selesai (musuh tak bisa dilukai saat state spawn)
	for e in mons:
		e.hp = 100000
		e.max_hp = 100000
		e.set_physics_process(false)
	return mons

func run(st: Node3D) -> void:
	var t := st.get_tree()
	st.autoplay = false
	await t.create_timer(0.8).timeout
	var p: Player = st.player
	p.invuln = 0.0
	var base: Vector3 = p.global_position
	GameState.unlock_character("kiriel")
	p.set_character("kiriel")
	p.control_enabled = true
	p.global_position = base
	p.facing = 0.0
	var cd := Data.character("kiriel")
	check("data kiriel", cd != null and cd.rarity == 6 and cd.ult_charges == 2 and cd.attack_kind == "bolt" and cd.ult_kind == "storm_blade")
	check("tanpa tongkat (tidak ada node tongkat)", p.rig.weapon_holder.get_child_count() == 0, "anak weapon_holder=%d" % p.rig.weapon_holder.get_child_count())
	var mons: Array = await _spawn(st, base)
	# --- skill Petir Berantai
	p.mana = p.max_mana
	p.skill_cd = 0.0
	check("skill jalan", p.do_skill())
	await t.create_timer(1.2).timeout
	check("skill melukai musuh", _lost(mons) > 0, "hp hilang=%d" % _lost(mons))
	check("skill kena >1 musuh", mons.filter(func(e): return is_instance_valid(e) and int(e.hp) < 100000).size() > 1)
	# --- ULTI #1 (bintang 1 -> 5 dtk)
	GameState.roster["kiriel"]["stars"] = 1
	p._act_t = 0.0
	mons = await _spawn(st, base)
	check("ulti tersedia", st.ult_available())
	check("bintang 1: jatah ULTI cuma 1x", st._ult_max("kiriel") == 1)
	check("ulti #1 jalan", st.try_ult())
	await t.create_timer(2.6).timeout
	check("wujud pedang aktif", st._form_t > 0.0, "sisa=%.2f" % st._form_t)
	check("bintang 1: TIDAK kebal tambahan", p.immune_t <= 0.0, "immune_t=%.2f" % p.immune_t)
	check("sisa wujud <= 5 dtk (bintang 1)", st._form_t <= 5.0 and st._form_t > 1.5, "sisa=%.2f" % st._form_t)
	check("data jadi jarak dekat", p.data.attack_kind == "arc" and p.data.attack_range < 4.0 and p.data.combo_hits == 3)
	check("pedang petir di tangan", p.rig.weapon_holder.get_node_or_null("StormSword") != null)
	p._act_t = 0.0
	p.attack_cd = 0.0
	await st._shot("kiriel_form")
	var before := _lost(mons)
	for i in 3:
		p.attack_cd = 0.0
		p._act_t = 0.0
		p.do_attack()
		await t.create_timer(0.35).timeout
	check("tebasan jarak dekat melukai", _lost(mons) > before, "hp hilang=%d" % _lost(mons))
	await t.create_timer(3.0).timeout
	check("wujud habis -> kembali jarak jauh", st._form_t <= 0.0 and p.data.attack_kind == "bolt" and p.rig.weapon_holder.get_node_or_null("StormSword") == null, "attack_kind=%s" % p.data.attack_kind)
	# --- ULTI #2 (bintang 5 -> 20 dtk), lalu jatah habis
	check("bintang 1: ulti ke-2 ditolak", not st.ult_available())
	GameState.roster["kiriel"]["stars"] = GameState.MAX_STARS
	p._act_t = 0.0
	check("bintang max: jatah ULTI 2x", st._ult_max("kiriel") == 2)
	check("ulti #2 tersedia", st.ult_available())
	check("ulti #2 jalan", st.try_ult())
	await t.create_timer(2.6).timeout
	check("wujud bintang 5 ~20 dtk", st._form_t > 15.0 and st._form_t <= 20.0, "sisa=%.2f" % st._form_t)
	check("bintang max: kebal 4 dtk aktif", p.immune_t > 2.0 and p.immune_t <= 4.0, "immune_t=%.2f" % p.immune_t)
	p.invuln = 0.0
	var hp0 := p.hp
	check("kebal menolak serangan apa pun", not p.take_damage(999, p.global_position + Vector3(1, 0, 0)) and p.hp == hp0)
	await t.create_timer(4.0).timeout
	check("kebal habis setelah 4 dtk", p.immune_t <= 0.0 and p._immune_aura == null)
	p.invuln = 0.0
	check("setelah kebal habis, damage masuk lagi", p.take_damage(1, p.global_position + Vector3(1, 0, 0)))
	p._act_t = 0.0
	p._act_t = 0.0
	check("ulti #3 ditolak", not st.ult_available() and not st.try_ult())
	st._exit_blade_form()
	check("keluar wujud manual aman", p.data.attack_kind == "bolt")
	print("SUMMARY fails=", fails)
