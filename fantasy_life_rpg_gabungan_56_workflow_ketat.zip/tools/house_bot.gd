extends RefCounted
## Bot: pintu rumah bisa dibuka -> masuk ke interior (ada isinya & penghuni) -> keluar kembali; interior dibuang setelahnya (ringan).
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func _wait(l: Node3D, cond: Callable, cap: float = 6.0) -> void:
	var t := 0.0
	while not cond.call() and t < cap:
		await l.get_tree().process_frame
		t += l.get_tree().root.get_process_delta_time()
func run(l: Node3D) -> void:
	var tree := l.get_tree()
	await tree.create_timer(1.0).timeout
	l.hud.visible = true
	var doors := 0
	var b: Building = null
	for x in l.world.buildings:
		if x.has_door:
			doors += 1
			if b == null:
				b = x
	check("rumah punya pintu yang bisa dibuka", doors >= 12, "n=%d" % doors)
	await tree.create_timer(0.5).timeout
	print("INFO luar draw calls=", RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME), " tris=", RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME))
	var nodes0 := tree.root.get_child_count()
	var mesh0 := 0
	# dekati pintu -> target interaksi "Buka pintu"
	var door_w: Vector3 = b.to_global(b.door_pos + Vector3(0, -0.4, 1.3))
	l.player.global_position = Vector3(door_w.x, 0.1, door_w.z)
	await tree.process_frame
	await tree.process_frame
	var t: Dictionary = l._find_target()
	check("dekat pintu: tombol 'Buka pintu'", str(t.get("prompt", "")) == "Buka pintu", str(t.get("prompt", "")))
	l._try_interact()
	await _wait(l, func(): return l.interior != null and not l._house_busy)
	check("interior terbentuk", l.interior != null)
	if l.interior == null:
		print("CHECK SUMMARY fails=", fails); tree.quit(); return
	var p: Vector3 = l.player.global_position
	var o := HouseInterior.ORIGIN
	check("pemain berada di dalam ruangan", absf(p.x - o.x) < l.interior.size.x * 0.5 and absf(p.z - o.z) < l.interior.size.y * 0.5, str(p))
	check("lobi luar disembunyikan (ringan)", not l.world.visible)
	check("pemain bisa bergerak lagi", l.player.control_enabled)
	var homes := 0
	for v in l.villagers:
		if is_instance_valid(v) and v.visible and v._def.get("home", false) and v.global_position.distance_to(p) < 6.0:
			homes += 1
	check("penghuni ada di dalam rumah", homes == 1, "n=%d" % homes)
	var info := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
	await tree.create_timer(0.5).timeout
	info = RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
	var tris := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME)
	print("INFO interior draw calls=", info, " tris=", tris)
	l.hud.visible = false
	l.touch.visible = false
	await tree.create_timer(0.4).timeout
	info = RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
	tris = RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME)
	print("INFO interior tanpa UI calls=", info, " tris=", tris)
	await l._shot("interior_" + b.kind)
	l.hud.visible = true
	check("interior ringan: adegan 3D < 60 draw call (luar ~200)", info < 60, "calls=%d tris=%d" % [info, tris])
	# target keluar
	l.player.global_position = Vector3(o.x, 0.1, o.z + l.interior.size.y * 0.5 - 0.9)
	await tree.process_frame
	await tree.process_frame
	t = l._find_target()
	check("ada tombol keluar", str(t.get("prompt", "")) == "Keluar rumah", str(t.get("prompt", "")))
	# tidak bisa menembus dinding belakang: sinar dari dalam ke belakang kena tabrakan
	var q := PhysicsRayQueryParameters3D.create(o + Vector3(0, 1.0, 0), o + Vector3(0, 1.0, -l.interior.size.y), 0xFFFFFFFF)
	check("dinding interior padat", not l.get_world_3d().direct_space_state.intersect_ray(q).is_empty())
	l._try_interact()
	await _wait(l, func(): return l.interior == null and not l._house_busy)
	check("interior dibuang saat keluar", l.interior == null and l.get_node_or_null("Interior") == null)
	await tree.process_frame
	check("lobi tampil lagi", l.world.visible)
	var back: Vector3 = l.player.global_position
	check("pemain kembali di depan pintu", back.distance_to(Vector3(door_w.x, 0.1, door_w.z)) < 3.0, "jarak=%.1f" % back.distance_to(Vector3(door_w.x, 0.1, door_w.z)))
	check("kontrol pemain pulih", l.player.control_enabled)
	var occ_left := 0
	for v in l.villagers:
		if is_instance_valid(v) and v.global_position.x > 300.0:
			occ_left += 1
	check("penghuni dalam rumah dibuang", occ_left == 0)
	await tree.create_timer(1.0).timeout
	check("tidak ada simpul bocor", tree.root.get_child_count() == nodes0, "%d -> %d" % [nodes0, tree.root.get_child_count()])
	print("CHECK SUMMARY fails=", fails)
	tree.quit()
