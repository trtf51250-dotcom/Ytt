extends Node
## Uji cepat: data (.tres) dan GameState termuat benar. Jalankan:
##   godot --headless --path . res://tools/test_data.tscn
func _ready() -> void:
	var ok := true
	print("karakter=", Data.characters.size(), " item=", Data.items.size(), " quest=", Data.quests.size(), " stage=", Data.stages.size())
	ok = ok and Data.characters.size() == 16 and Data.items.size() >= 29 and Data.quests.size() == 29 and Data.stages.size() == 39 and Data.stage_order.size() == 27 and Data.pvp_arenas.size() == 4
	for id in Data.items:
		var it: ItemData = Data.items[id]
		if it.display_name == "" or it.sell_price() <= 0:
			ok = false
			print("item rusak: ", id)
	# ekonomi: tiap tingkat bintang punya harga seragam, tidak ada jual > beli (celah untung), dan jual naik seiring bintang
	var tier := {}
	for id in Data.items:
		var it2: ItemData = Data.items[id]
		if it2.buy_price > 0:
			if it2.sell_price() > it2.buy_price / 2:
				ok = false
				print("ekonomi: jual > separuh beli: ", id)
			if it2.type == "weapon":
				var key := str(it2.rarity)
				if tier.has(key) and tier[key] != it2.buy_price:
					ok = false
					print("ekonomi: harga senjata ", key, "* tidak seragam: ", id, " ", it2.buy_price, " vs ", tier[key])
				tier[key] = it2.buy_price
	var prev := 0
	for r in range(1, 6):
		var probe := ItemData.new()
		probe.rarity = r
		probe.buy_price = 0
		if probe.sell_price() <= prev:
			ok = false
			print("ekonomi: harga jual tidak naik pada ", r, "*")
		prev = probe.sell_price()
	# alur Adventure: tiap stage petualangan + wilayah jelajah tepat sekali; wilayah tepat setelah stage pembukanya; langkah berikutnya maju berurutan
	var ao: Array = Data.adventure_order
	if ao.size() != Data.stage_order.size() + Data.field_ids.size() or ao.size() != Dictionary(ao.reduce(func(a, i): a[i] = true; return a, {})).size():
		ok = false
		print("adventure_order tidak lengkap/duplikat: ", ao.size())
	for fid in Data.field_ids:
		if ao.find(fid) != ao.find(Data.stage(fid).unlock_after) + 1:
			ok = false
			print("wilayah tidak tepat setelah stage pembukanya: ", fid)
	var saved: Dictionary = GameState.stages.duplicate(true)
	GameState.stages = {}
	var walked := 0
	while GameState.adventure_next() != "" and walked < 200:
		var nid := GameState.adventure_next()
		if nid != ao[walked]:
			ok = false
			print("urutan Adventure salah di langkah ", walked, ": ", nid, " != ", ao[walked])
			break
		GameState.stages[nid] = {"cleared": true, "stars": 3}
		walked += 1
	if walked != ao.size():
		ok = false
		print("Adventure tidak habis: ", walked, "/", ao.size())
	GameState.stages = saved
	for id in Data.quests:
		var q: QuestData = Data.quests[id]
		if q.hint == "":
			ok = false
			print("quest tanpa hint: ", id)
	for id in Data.stages:
		var s: StageData = Data.stages[id]
		print(id, " first_clear_diamond=", s.first_clear_diamond, " waves=", s.waves.size())
		# tiap jenis musuh/bos yang dirujuk harus terdaftar; rantai buka kunci harus valid
		for w in s.waves:
			for k in w:
				if not Enemy.KINDS.has(str(k)):
					ok = false
					print("musuh tak dikenal di ", id, ": ", k)
		if s.boss != "" and not Enemy.KINDS.has(s.boss):
			ok = false
			print("bos tak dikenal di ", id, ": ", s.boss)
		if s.unlock_after != "" and not Data.stages.has(s.unlock_after):
			ok = false
			print("unlock_after tak valid di ", id)
		if not ["meadow", "forest", "cave", "boss", "lair", "abyss", "temple", "chains", "fajar", "lumbung", "mist", "grove"].has(s.theme):
			ok = false
			print("tema tak dikenal di ", id, ": ", s.theme)
	# urutan stage: Bab 4-5 setelah bab 3
	var ix: Array = Data.stage_order
	ok = ok and ix.find("s3_boss") < ix.find("s4_1") and ix.find("s4_boss") < ix.find("s5_1") and ix.find("s5_boss") < ix.find("s6_1") and ix.back() == "s6_boss"
	# rarity karakter: Hakuya ★6; Vael & Lucien ★5; Wenyu & Kuroha ★4; lainnya ★3-4
	for id in Data.characters:
		var cd: CharacterData = Data.characters[id]
		var want := {"hakuya": 6, "vael": 5, "lucien": 5, "wenyu": 4, "kuroha": 4, "aion": 5, "kyomu": 6, "kiriel": 6, "midori": 6, "zyrax": 6}
		var want6: bool = id == "hakuya"
		if (want.has(id) and cd.rarity != want[id]) or (not want.has(id) and (cd.rarity < 3 or cd.rarity > 4)):
			ok = false
			print("rarity salah: ", id, " ", cd.rarity)
	GameState.new_game()
	var party0: int = GameState.party.size()
	GameState.unlock_character("hakuya")
	# kekuatan: setiap ★6 (Hakuya, Kiriel, Kyomu) harus lebih kuat dari SEMUA karakter ★5-; Hakuya & Kiriel tidak boleh di bawah Kyomu
	var hp_pow: int = int(GameState.char_stats("hakuya")["power"])
	var max_low := 0
	var pow6 := {}
	for id in Data.characters:
		GameState.unlock_character(id)
		var pw: int = int(GameState.char_stats(id)["power"])
		print("  kekuatan ", id, "=", pw, " (hakuya=", hp_pow, ")")
		if (Data.characters[id] as CharacterData).rarity >= 6:
			pow6[id] = pw
		else:
			max_low = maxi(max_low, pw)
	for id in pow6:
		if int(pow6[id]) <= max_low:
			ok = false
			print("★6 harus lebih kuat dari semua ★5-: ", id, " ", pow6[id], " <= ", max_low)
	# animasi serang/skill khas tiap karakter: semua karakter punya gaya, dan varian benar-benar terbentuk dengan panjang & impak wajar
	for id in Data.characters:
		if not AnimLibrary.ATK.has(id):
			ok = false
			print("karakter tanpa gaya serang: ", id)
			continue
		for base in ["attack_sword1", "attack_sword3", "attack_staff", "attack_staff3", "attack_smash", "attack_smash3", "attack_bow", "attack_bow3", "attack_dagger1", "skill_sword", "skill_staff", "skill_iai", "skill_dashcut", "skill_volley", "dodge"]:
			var nm: String = AnimLibrary.attack_variant(base, id)
			var anim: Animation = AnimLibrary.get_library().get_animation(nm)
			if anim == null or anim.length <= 0.1 or AnimLibrary.impact_time(nm) >= anim.length:
				ok = false
				print("varian serang rusak: ", nm)
	for id in Data.characters:                       # ULTI: tiap karakter punya animasi ULTI sendiri yang terbentuk & impaknya wajar
		var uk: String = (Data.characters[id] as CharacterData).ult_kind
		var un: String = AnimLibrary.ensure_ult(uk)
		var ua: Animation = AnimLibrary.get_library().get_animation(un)
		if ua == null or absf(ua.length - AnimLibrary.ULT_LEN) > 0.01 or AnimLibrary.impact_time(un) >= ua.length:
			ok = false
			print("animasi ULTI rusak: ", id, " ", un)
	for id in Data.characters:                       # mana: biaya skill harus muat di mana maksimum
		var mcd: CharacterData = Data.characters[id]
		if mcd.max_mana <= 0.0 or mcd.skill_mana_cost > mcd.max_mana:
			ok = false
			print("mana tidak valid: ", id)
	for pn in ["enemy_wind_sword", "enemy_wind_staff", "enemy_wind_heavy", "enemy_winded", "enemy_roar"]:    # pose musuh humanoid/boss
		if not AnimLibrary.get_library().has_animation(pn):
			ok = false
			print("pose musuh hilang: ", pn)
	print("party=", GameState.party, " power=", GameState.party_power(), " quests aktif=", GameState.quests.keys())
	print("stat ren=", GameState.char_stats("ren"))
	ok = ok and party0 == 3
	print("HASIL: ", "LULUS" if ok else "GAGAL")
	get_tree().quit(0 if ok else 1)
