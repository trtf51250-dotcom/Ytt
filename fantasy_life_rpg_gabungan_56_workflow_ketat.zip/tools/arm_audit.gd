extends Node
## Audit gerak lengan: untuk tiap karakter & animasi aksi, hitung jangkauan rotasi (derajat, deviasi maks dari kunci pertama) tiap lengan.
## Lengan "diam" = tangan/siku hampir tidak bergerak. Hasil: baris ARM <id> <node> R=<upper/fore/hand> L=<...> lalu ARM SUMMARY.
const NODES := ["Attack1", "Attack2", "Attack3", "Skill", "Ult"]
const BONES := {"r": ["upperarm_r", "forearm_r", "hand_r"], "l": ["upperarm_l", "forearm_l", "hand_l"]}

func _range(an: Animation, bone: String) -> float:
	var best := 0.0
	for ti in an.get_track_count():
		if an.track_get_type(ti) != Animation.TYPE_ROTATION_3D:
			continue
		if str(an.track_get_path(ti)).get_slice(":", 1) != bone:
			continue
		var q0: Quaternion = an.track_get_key_value(ti, 0)
		for k in an.track_get_key_count(ti):
			var q: Quaternion = an.track_get_key_value(ti, k)
			best = maxf(best, rad_to_deg(q0.angle_to(q)))
	return best

func _ready() -> void:
	var tex := ImageTexture.create_from_image(Image.create(4, 4, false, Image.FORMAT_RGBA8))
	var weak := 0
	var total := 0
	for id in Data.character_ids():
		var d = Data.characters[id]
		var rig := CharacterRig.new()
		add_child(rig)
		rig.setup(1.8, tex, true, true)
		rig.set_weapon_class(d.anim_style if d.anim_style != "" else d.weapon_class)
		rig.set_style(id)
		rig.set_skill_kind(d.skill_kind)
		rig.set_ult_kind(d.ult_kind)
		for nd in NODES:
			if not rig._anim_nodes.has(nd):
				continue
			var an: Animation = rig.player.get_animation(String(rig._anim_nodes[nd].animation))
			var line := "ARM %s %s [%s]" % [id, nd, String(rig._anim_nodes[nd].animation)]
			var flags := ""
			for side in ["r", "l"]:
				var parts := []
				var mx := 0.0
				for b in BONES[side]:
					var v := _range(an, b)
					mx = maxf(mx, v)
					parts.append("%d" % int(v))
				line += "  %s=%s" % [side.to_upper(), "/".join(parts)]
				if mx < 25.0:
					flags += " %s-DIAM" % side.to_upper()
			total += 1
			if flags != "":
				weak += 1
			print(line, flags)
		rig.queue_free()
	print("ARM SUMMARY anim=", total, " dengan_lengan_diam=", weak)
	get_tree().quit()
