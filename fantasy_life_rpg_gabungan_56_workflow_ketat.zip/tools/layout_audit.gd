extends Node3D
## Audit tata letak kota (headless): pohon/lampu/prop menimpa jalan atau bangunan, bangunan menimpa jalan/bangunan lain,
## pintu depan jauh dari jalan, titik penting tidak terjangkau. Keluaran: baris ISSUE ... dan ringkasan.
var world: LobbyWorld
var issues: Array = []

func _ready() -> void:
	world = LobbyWorld.new()
	add_child(world)
	world.build()
	await get_tree().create_timer(0.5).timeout
	await get_tree().physics_frame
	await get_tree().physics_frame
	run()
	get_tree().quit()

func _shapes_2d(body_root: Node) -> Array:
	var out: Array = []
	for n in body_root.find_children("*", "CollisionShape3D", true, false):
		var cs: CollisionShape3D = n
		var gt := cs.global_transform
		var sx := gt.basis.x.length()
		var sz := gt.basis.z.length()
		var sy := gt.basis.y.length()
		if cs.shape is BoxShape3D:
			var s: Vector3 = (cs.shape as BoxShape3D).size
			var ax := Vector2(gt.basis.x.x, gt.basis.x.z).normalized()
			var az := Vector2(gt.basis.z.x, gt.basis.z.z).normalized()
			out.append({"t": "box", "c": Vector2(gt.origin.x, gt.origin.z), "ax": ax, "az": az, "hx": s.x * sx * 0.5, "hz": s.z * sz * 0.5, "top": gt.origin.y + s.y * sy * 0.5})
		elif cs.shape is CylinderShape3D:
			var cy: CylinderShape3D = cs.shape
			out.append({"t": "cyl", "c": Vector2(gt.origin.x, gt.origin.z), "r": cy.radius * sx, "h": cy.height * sy, "top": gt.origin.y + cy.height * sy * 0.5})
	return out

static func _dist_to_shape(p: Vector2, s: Dictionary) -> float:
	if s["t"] == "cyl":
		return p.distance_to(s["c"]) - float(s["r"])
	var d: Vector2 = p - (s["c"] as Vector2)
	var lx: float = absf(d.dot(s["ax"])) - float(s["hx"])
	var lz: float = absf(d.dot(s["az"])) - float(s["hz"])
	if lx > 0.0 and lz > 0.0:
		return sqrt(lx * lx + lz * lz)
	return maxf(lx, lz)

func _shape_pts(s: Dictionary) -> Array:
	var pts: Array = []
	if s["t"] == "cyl":
		var r: float = s["r"]
		for i in 8:
			var a := i * TAU / 8.0
			pts.append((s["c"] as Vector2) + Vector2(cos(a), sin(a)) * r)
		return pts
	for ix in [-1.0, -0.5, 0.0, 0.5, 1.0]:
		for iz in [-1.0, -0.5, 0.0, 0.5, 1.0]:
			if absf(ix) < 1.0 and absf(iz) < 1.0:
				continue
			pts.append((s["c"] as Vector2) + (s["ax"] as Vector2) * float(s["hx"]) * ix + (s["az"] as Vector2) * float(s["hz"]) * iz)
	return pts

func add(kind: String, msg: String, pos: Vector2) -> void:
	issues.append({"k": kind, "m": msg, "p": pos})
	print("ISSUE %s (%.1f, %.1f) %s" % [kind, pos.x, pos.y, msg])

func run() -> void:
	var bshapes: Array = []     # {kind, idx, shapes}
	for b in world.buildings:
		var ab: AABB = b.global_transform * b.mesh_instance.mesh.get_aabb()
		bshapes.append({"kind": b.kind, "pos": Vector2(b.global_position.x, b.global_position.z), "shapes": _shapes_2d(b), "b": b, "rect": Rect2(ab.position.x, ab.position.z, ab.size.x, ab.size.z)})
	var wb := world.get_node("WorldBody")
	var wshapes := _shapes_2d(wb)
	print("buildings=", bshapes.size(), " world shapes=", wshapes.size(), " trees(inside)=", world.tree_positions.size())

	# info bangunan: kotak tabrakan (dunia) vs mesh (AABB dunia) -> melihat bagian yang bisa ditembus
	for e in bshapes:
		var b3: Building = e["b"]
		var mn := Vector2(1e9, 1e9); var mx := Vector2(-1e9, -1e9)
		for sh in e["shapes"]:
			if sh["t"] != "box" or float(sh["top"]) < 1.5:
				continue
			for pt in _shape_pts(sh) + [sh["c"]]:
				mn = mn.min(pt); mx = mx.max(pt)
		var aabb: AABB = b3.global_transform * b3.mesh_instance.mesh.get_aabb()
		print("BLD %s pos=(%.1f,%.1f) yaw=%.0f col=[%.1f..%.1f x %.1f..%.1f] mesh=[%.1f..%.1f x %.1f..%.1f] fp=%.1f" % [b3.kind, b3.global_position.x, b3.global_position.z, b3.rotation_degrees.y, mn.x, mx.x, mn.y, mx.y, aabb.position.x, aabb.end.x, aabb.position.z, aabb.end.z, b3.footprint])
	# 1) bangunan menimpa jalan (permukaan batu = lebar/2 + 0.35)
	for e in bshapes:
		if e["kind"] in ["fountain", "gate", "portal"]:
			continue
		for s in e["shapes"]:
			if s["t"] != "box" or float(s["top"]) < 2.0:
				continue
			for p in _shape_pts(s):
				var dr := world.dist_to_roads(p)
				if dr < -0.0 and not _is_path_only(p):
					add("BLD_ON_ROAD", "%s menimpa jalan (%.1f m)" % [e["kind"], dr], e["pos"])
					break
	# 2) bangunan saling tumpuk
	for i in bshapes.size():
		for j in range(i + 1, bshapes.size()):
			var a: Dictionary = bshapes[i]
			var b2: Dictionary = bshapes[j]
			var hit := false
			for sa in a["shapes"]:
				if sa["t"] != "box" or float(sa["top"]) < 2.0:
					continue
				for pt in _shape_pts(sa):
					for sb in b2["shapes"]:
						if sb["t"] == "box" and float(sb["top"]) >= 2.0 and _dist_to_shape(pt, sb) < 0.5:
							hit = true
			if hit:
				add("BLD_OVERLAP", "%s x %s" % [a["kind"], b2["kind"]], a["pos"])
	# 3) pohon & lampu: di atas jalan / terlalu dekat bangunan
	var n_tree := 0
	var n_lamp := 0
	for s in wshapes:
		if s["t"] != "cyl":
			continue
		var c: Vector2 = s["c"]
		var h: float = s["h"]
		var r: float = s["r"]
		var is_tree: bool = absf(h - 3.0) < 0.05 and r > 0.3
		var is_lamp: bool = absf(h - 3.4) < 0.05 and absf(r - 0.26) < 0.02
		if not (is_tree or is_lamp):
			continue
		var dr2 := world.dist_to_roads(c)
		if is_tree:
			n_tree += 1
			var sc := r / 0.5
			if dr2 < 0.4:
				add("TREE_ON_ROAD", "batang pohon di jalan (%.1f)" % dr2, c)
			var canopy := 2.5 * sc
			for e in bshapes:
				if e["kind"] in ["gate", "fountain"]:
					continue
				if (e["rect"] as Rect2).grow(1.6).has_point(c):
					add("TREE_IN_MESH", "pohon terlalu dekat/di dalam bangunan %s" % e["kind"], c)
					break
			for e in bshapes:
				for sb in e["shapes"]:
					if sb["t"] == "box" and float(sb["top"]) >= 2.0 and _dist_to_shape(c, sb) < canopy - 0.4:
						add("TREE_IN_BLD", "kanopi pohon menembus %s (%.1f m)" % [e["kind"], _dist_to_shape(c, sb)], c)
						break
		else:
			n_lamp += 1
			for e in bshapes:
				if (e["rect"] as Rect2).grow(0.4).has_point(c) and not (e["kind"] in ["gate", "fountain"]):
					add("LAMP_IN_MESH", "lampu di dalam bangunan %s" % e["kind"], c)
					break
			if dr2 < -0.1:
				add("LAMP_ON_ROAD", "lampu di atas jalan (%.1f)" % dr2, c)
			for e in bshapes:
				for sb in e["shapes"]:
					if sb["t"] == "box" and float(sb["top"]) >= 2.0 and _dist_to_shape(c, sb) < 0.8:
						add("LAMP_IN_BLD", "lampu menempel %s" % e["kind"], c)
						break
	print("trees=", n_tree, " lamps=", n_lamp)
	# 4) pintu depan jauh dari jalan (tidak nyambung)
	for e in bshapes:
		var b: Building = e["b"]
		var fwd := Vector3(sin(b.rotation.y), 0, cos(b.rotation.y))
		var front := Vector2(b.global_position.x, b.global_position.z) + Vector2(fwd.x, fwd.z) * b.footprint * 0.62
		var dfront := world.dist_to_roads(front)
		if dfront > 5.0 and not (e["kind"] in ["fountain", "pond", "altar"]):
			add("FRONT_FAR", "%s: depan %.1f m dari jalan" % [e["kind"], dfront], e["pos"])
	# 4b) rumah: jumlah, penghuni, tidak menimpa titik penting, jarak antar bangunan, urutan rumus
	var houses: Array = []
	for e in bshapes:
		if str(e["kind"]).begins_with("house_"):
			houses.append(e)
	print("houses=", houses.size(), " residents=", NpcDefs.RESIDENTS.size())
	if houses.size() < 28:
		add("HOUSE_FEW", "rumah hanya %d (target >= 28)" % houses.size(), Vector2.ZERO)
	if NpcDefs.RESIDENTS.size() < houses.size():
		add("HOUSE_NO_RESIDENT", "penghuni %d < rumah %d" % [NpcDefs.RESIDENTS.size(), houses.size()], Vector2.ZERO)
	var pts_of_interest: Array = []
	for c in Explore.CHESTS:
		pts_of_interest.append([str(c["id"]), c["pos"]])
	for w in Explore.WAYPOINTS:
		pts_of_interest.append([str(w["id"]), w["pos"]])
	for k in LobbyLayout.NPC_SPOTS:
		pts_of_interest.append([str(k), LobbyLayout.NPC_SPOTS[k]])
	for h in houses:
		for poi in pts_of_interest:
			if (h["rect"] as Rect2).grow(2.0).has_point(poi[1]):
				add("HOUSE_ON_POINT", "rumah menimpa titik penting %s" % poi[0], h["pos"])
	for i in bshapes.size():
		for j in range(i + 1, bshapes.size()):
			var ra: Rect2 = bshapes[i]["rect"]
			var rb: Rect2 = bshapes[j]["rect"]
			if ra.size == Vector2.ZERO or rb.size == Vector2.ZERO:
				continue
			var gx := maxf(maxf(ra.position.x - rb.end.x, rb.position.x - ra.end.x), 0.0)
			var gz := maxf(maxf(ra.position.y - rb.end.y, rb.position.y - ra.end.y), 0.0)
			if Vector2(gx, gz).length() < 1.0:
				add("MESH_TOO_CLOSE", "%s dan %s berjarak %.2f m" % [bshapes[i]["kind"], bshapes[j]["kind"], Vector2(gx, gz).length()], bshapes[i]["pos"])
	# 4c) portal harus padat: sinar tegak lurus bidang pusaran harus mengenai tabrakan (dulu bisa ditembus)
	for e in bshapes:
		if e["kind"] != "portal":
			continue
		var pb: Building = e["b"]
		var pf := Vector3(sin(pb.rotation.y), 0, cos(pb.rotation.y))
		var ctr := pb.global_position + Vector3(0, 2.0, 0)
		var rq := PhysicsRayQueryParameters3D.create(ctr + pf * 5.0, ctr - pf * 5.0, 1)
		var hit := get_world_3d().direct_space_state.intersect_ray(rq)
		if hit.is_empty():
			add("PORTAL_NOT_SOLID", "sinar menembus pusaran portal tanpa terhalang", e["pos"])
		else:
			print("portal padat: sinar kena di ", hit["position"])
	# 5) titik interaksi & NPC terjangkau dari spawn (flood fill 1 m)
	var x0 := int(LobbyLayout.BOUNDS_MIN.x); var x1 := int(LobbyLayout.BOUNDS_MAX.x)
	var z0 := int(LobbyLayout.BOUNDS_MIN.y); var z1 := int(LobbyLayout.BOUNDS_MAX.y)
	var blk := {}
	var space := get_world_3d().direct_space_state
	for z in range(z0, z1 + 1):
		for x in range(x0, x1 + 1):
			var q := PhysicsShapeQueryParameters3D.new()
			var sp := SphereShape3D.new(); sp.radius = 0.45
			q.shape = sp; q.transform = Transform3D(Basis(), Vector3(x, 1.0, z)); q.collision_mask = 1
			blk[Vector2i(x, z)] = not space.intersect_shape(q, 1).is_empty()
	var seen := {}
	var st: Array = [Vector2i(int(LobbyLayout.SPAWN.x), int(LobbyLayout.SPAWN.z))]
	seen[st[0]] = true
	while not st.is_empty():
		var cc: Vector2i = st.pop_back()
		for d in [Vector2i(1,0), Vector2i(-1,0), Vector2i(0,1), Vector2i(0,-1)]:
			var nn: Vector2i = cc + d
			if nn.x < x0 or nn.x > x1 or nn.y < z0 or nn.y > z1 or seen.has(nn) or blk[nn]:
				continue
			seen[nn] = true
			st.push_back(nn)
	for it in world.interactions:
		var ip := Vector2i(roundi(it["pos"].x), roundi(it["pos"].z))
		var ok := false
		for dx in range(-2, 3):
			for dz in range(-2, 3):
				if seen.has(ip + Vector2i(dx, dz)):
					ok = true
		if not ok:
			add("UNREACHABLE", "interaksi %s tak terjangkau" % str(it["id"]), Vector2(it["pos"].x, it["pos"].z))
	for k in LobbyLayout.NPC_SPOTS:
		var sp2: Vector2 = LobbyLayout.NPC_SPOTS[k]
		if not seen.has(Vector2i(roundi(sp2.x), roundi(sp2.y))):
			add("NPC_BLOCKED", "NPC %s di titik padat/tak terjangkau" % k, sp2)
	# peta ASCII 2 m/char
	var f := FileAccess.open("/tmp/audit_map.txt", FileAccess.WRITE)
	for z in range(z0, z1 + 1, 2):
		var line := "%4d " % z
		for x in range(x0, x1 + 1, 2):
			var c2 := Vector2i(x, z)
			var dr3 := world.dist_to_roads(Vector2(x, z))
			var ch := "."
			if blk[c2]: ch = "#"
			elif not seen.has(c2): ch = "o"
			elif dr3 < 0.0: ch = "-"
			line += ch
		f.store_line(line)
	f.close()
	var counts := {}
	for i in issues:
		counts[i["k"]] = int(counts.get(i["k"], 0)) + 1
	print("SUMMARY ", counts)
	var real := 0
	for i in issues:
		if i["k"] == "BLD_ON_ROAD" and (i["m"] as String).begins_with("guild"):
			continue          # ujung jalan menuju guild bulat pada alat ukur; jalan aslinya berhenti di depan guild
		real += 1
	print("CHECK ", "PASS " if real == 0 else "FAIL ", "tata letak kota: %d masalah nyata" % real)

func _is_path_only(p: Vector2) -> bool:
	# titik hanya menimpa jalan setapak rumah (bukan jalan besar): abaikan
	for r in world.road_lines:
		if r.get("path", false):
			continue
		if LobbyWorld.dist_to_polyline(p, r["pts"]) - float(r["w"]) * 0.5 < 0.0:
			return false
	return true
