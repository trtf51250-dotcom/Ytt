extends RefCounted
func run(st: Node3D) -> void:
	var t := st.get_tree()
	st.autoplay = false
	await t.create_timer(0.8).timeout
	for e in t.get_nodes_in_group("enemies"):
		e.queue_free()
	var p: Player = st.player
	GameState.unlock_character("zyrax")
	p.set_character("zyrax")
	p.control_enabled = true
	await t.create_timer(0.5).timeout
	for ang in [0.0, PI, PI * 0.5, -PI * 0.5]:
		p.global_position = Vector3(0, 0.1, 0)
		p.velocity = Vector3.ZERO
		p.facing = ang
		p._act_t = 0.0
		p.dodge_cd = 0.0
		await t.create_timer(0.2).timeout
		var p0 := p.global_position
		var ok := p.do_dodge()
		var log := []
		for i in 12:
			await t.physics_frame
			log.append("%.1f" % p.global_position.distance_to(p0))
		print("PROBE ang=%.2f ok=%s dash_t=%.3f speed=%.1f dist=%s" % [ang, ok, p._dash_t, p._dash_speed, log])
		await t.create_timer(1.0).timeout
