extends RefCounted
## Uji StageRun (Berkah Bintang, tantangan stage, dialog tengah pertarungan).
##   -- --bot=1 --botscript=run_bot --stage=s1_2 --fresh [--shots=DIR]
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func _wait_until(st: Node3D, cond: Callable, max_frames: int) -> bool:
	var t := st.get_tree()
	for i in max_frames:
		if cond.call():
			return true
		await t.physics_frame
	return cond.call()
func run(st: Node3D) -> void:
	var t := st.get_tree()
	await t.create_timer(1.0).timeout
	st._wave_timer = -1.0                      # alur gelombang diambil alih bot
	st.autoplay = true
	st.install_run()
	var r: StageRun = st.run
	check("StageRun terpasang", r != null)
	# --- rencana tantangan per stage
	var sdx := Data.stage("s1_2")
	check("rencana 1-2 = lingkaran segel di gelombang 2", StageRun.plan_for(sdx).get(1, "") == "zone", str(StageRun.plan_for(sdx)))
	check("rencana 1-3 = bertahan di gelombang terakhir", StageRun.plan_for(Data.stage("s1_3")).get(2, "") == "survive")
	check("rencana 1-4 = pemimpin pasukan", StageRun.plan_for(Data.stage("s1_4")).get(2, "") == "hunt")
	check("stage 1-1 & bos tanpa tantangan", StageRun.plan_for(Data.stage("s1_1")).is_empty() and StageRun.plan_for(Data.stage("s1_boss")).is_empty())
	check("desa v1_2 punya tantangan", StageRun.plan_for(Data.stage("v1_2")).has(1))
	# --- semua berkah/tier bisa diterapkan tanpa error & deskripsi terformat
	for id in StageRun.BOONS:
		for tier in 3:
			var d := r.desc_for(id, tier)
			if d == "" or d.contains("%d") or d.contains("%s"):
				check("deskripsi %s/%d" % [id, tier], false, d)
	r.apply("fajar", 1)
	r.apply("tameng", 2)
	r.apply("jiwa", 0)
	check("Bilah Fajar +13%", absf(r.dmg_mult() - 1.13) < 0.001, str(r.dmg_mult()))
	check("Tameng Bintang -17%", absf(r.taken_mult() - 0.83) < 0.001, str(r.taken_mult()))
	check("ringkasan berkah terisi", r.summary().contains("Bilah Fajar"), r.summary())
	# --- layar pilih berkah: stage dijeda, kartu bisa dipilih, lalu lanjut
	var before: int = r.boons.size()
	var tw := Time.get_ticks_msec()
	r.intermission(false)
	await _wait_until(st, func(): return r.modal, 30)
	check("layar berkah menjeda stage", r.modal and t.paused and st._paused)
	check("ada 3 pilihan", r._offer_ids.size() == 3, str(r._offer_ids))
	check("tombol jeda dikunci saat memilih", (func():
		st._toggle_pause()
		return t.paused and r.modal).call())
	if st.get("hud") != null and DisplayServer.get_name() != "headless" and OS.get_cmdline_user_args().is_empty():
		pass
	r.choose(1)
	await t.process_frame
	check("memilih membuka jeda", (not r.modal) and (not t.paused) and (not st._paused))
	check("berkah baru tercatat", r.boons.size() >= before)
	# --- tantangan LINGKARAN SEGEL
	st._pending = 0
	for e in t.get_nodes_in_group("enemies"):
		e.queue_free()
	r.plan = {0: "zone", 1: "survive", 2: "hunt"}
	st.state = 1
	st._start_wave(0)
	await _wait_until(st, func(): return r._zone_root != null, 30)
	check("lingkaran segel muncul", r.ch_type == "zone" and r._zone_root != null)
	check("tantangan menahan penutupan gelombang", r.blocks_wave_end())
	st.player.invuln = 999.0
	var prog0: float = r.ch_prog
	st.player.global_position = Vector3(r.ch_pos.x, 0.1, r.ch_pos.z)
	await _wait_until(st, func(): return r.ch_prog > prog0 + 0.05, 120)
	check("progres naik saat berdiri di lingkaran", r.ch_prog > prog0 + 0.05, str(r.ch_prog))
	var g0: int = GameState.gold
	var guard := 0
	while not r.ch_done and guard < 1500:
		guard += 1
		st.player.global_position = Vector3(r.ch_pos.x, 0.1, r.ch_pos.z)
		await t.physics_frame
	check("lingkaran selesai", r.ch_done and GameState.gold > g0, "prog=%s" % r.ch_prog)
	check("lingkaran dibersihkan", r._zone_root == null)
	await _wait_until(st, func(): return t.get_nodes_in_group("enemies").is_empty(), 240)
	check("sisa musuh buyar setelah tantangan", t.get_nodes_in_group("enemies").is_empty())
	check("gelombang boleh ditutup lagi", not r.blocks_wave_end())
	st._wave_timer = -1.0
	# --- tantangan BERTAHAN
	r.ch_type = ""
	st._start_wave(1)
	await t.create_timer(0.3).timeout
	check("bertahan aktif dengan hitung mundur", r.ch_type == "survive" and r.ch_time > 0.0 and not r.ch_done, "t=%.1f" % r.ch_time)
	r.ch_time = 0.2                                         # percepat
	await _wait_until(st, func(): return r.ch_done, 60)
	check("bertahan selesai saat waktu habis", r.ch_done)
	await _wait_until(st, func(): return t.get_nodes_in_group("enemies").is_empty(), 240)
	st._wave_timer = -1.0
	# --- tantangan PEMIMPIN PASUKAN
	r.ch_type = ""
	st._start_wave(2)
	await t.create_timer(0.5).timeout
	check("pemimpin pasukan muncul", r.ch_type == "hunt" and r.ch_champion != null and is_instance_valid(r.ch_champion) and r.ch_champion.elite)
	if r.ch_champion != null and is_instance_valid(r.ch_champion):
		await _wait_until(st, func(): return r.ch_champion == null or not is_instance_valid(r.ch_champion) or r.ch_champion.state != "spawn", 200)
	if r.ch_champion != null and is_instance_valid(r.ch_champion):
		r.ch_champion.take_damage(99999999, st.player.global_position, 0.0)
	await _wait_until(st, func(): return r.ch_done, 120)
	check("pemimpin tumbang = tantangan selesai", r.ch_done)
	st._wave_timer = -1.0                                   # jangan lanjut ke gelombang berikutnya selama uji
	await _wait_until(st, func(): return t.get_nodes_in_group("enemies").is_empty(), 900)
	check("pasukan buyar", t.get_nodes_in_group("enemies").is_empty(), " ".join(t.get_nodes_in_group("enemies").map(func(e): return "%s/%s/dead=%s/boss=%s" % [e.kind, e.state, e.dead, e.is_boss])) + " dt=%.1f pend=%d st=%s" % [r._dissolve_t, st._pending, str(st.state)])
	# --- dialog tengah pertarungan
	var barks := Story.barks("s1_2")
	check("ada dialog tengah pertarungan untuk 1-2", barks.size() >= 3, str(barks.size()))
	check("rare_bonus naik dari tantangan", r.rare_bonus >= 3, str(r.rare_bonus))
	print("CHECK SUMMARY fails=", fails)
