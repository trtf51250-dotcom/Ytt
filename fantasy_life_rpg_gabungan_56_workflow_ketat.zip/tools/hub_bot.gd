extends RefCounted
## Uji penghubung cerita: setelah s5_boss & v1_boss selesai, lobi kota memutar "a_return", peta Desa memutar "v_hub" (masing-masing sekali).
## Jalankan:  -- --bot=1 --story=1 --nocine=1 --botscript=hub_bot --fresh   (tambahkan --map=village untuk peta desa; lihat Flow.lobby_map)
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1
func _sp(l: Node) -> StoryPlayer:
	for c in l.get_tree().root.get_children():
		if c is StoryPlayer: return c
	return null
func run(l: Node3D) -> void:
	var t := l.get_tree()
	await t.create_timer(0.8).timeout
	var sp := _sp(l)
	if sp != null: sp.finish() if sp.has_method("finish") else sp.queue_free()
	t.paused = false
	for c in l.get_tree().root.get_children():
		if c is StoryPlayer: c.queue_free()
	Story.mark_seen("prolog"); Story.mark_seen("v_prolog")
	GameState.stages["s5_boss"] = {"cleared": true, "stars": 1}
	GameState.stages["v1_boss"] = {"cleared": true, "stars": 1}
	var want := "v_hub" if str(l.get("map_id")) == "village" else "a_return"
	l._opening_sequence()
	await t.create_timer(1.0).timeout
	sp = _sp(l)
	check("setelah s5_boss selesai, lobi %s memutar %s" % [str(l.get("map_id")), want], sp != null and sp._scene["id"] == want, "" if sp == null else str(sp._scene["id"]))
	if sp != null: sp.queue_free()
	t.paused = false
	Story.mark_seen(want)
	l._opening_sequence()
	await t.create_timer(0.6).timeout
	check("tidak diputar ulang (sekali saja)", _sp(l) == null)
	if want != "v_hub":
		# peta Desa: v_prolog sudah dibaca, jadi hanya v_hub yang tampil
		l.set("map_id", "village")
		l._opening_sequence()
		await t.create_timer(1.0).timeout
		sp = _sp(l)
		check("peta desa memutar v_hub", sp != null and sp._scene["id"] == "v_hub", "" if sp == null else str(sp._scene["id"]))
		if sp != null: sp.queue_free()
		t.paused = false
	print("CHECK SUMMARY fails=", fails)
	t.quit(fails)
