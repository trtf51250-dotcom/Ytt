extends RefCounted
## Foto dekat Kyomu: wajah (depan), badan (samping), pose menyerang (pedang tembus badan?).  --botscript=kyomu_look_bot --shots=/dir
func run(st: Node3D) -> void:
	var t := st.get_tree()
	await t.create_timer(0.8).timeout
	for e in t.get_nodes_in_group("enemies"): e.queue_free()
	var p: Player = st.player
	GameState.unlock_character("kyomu")
	p.set_character("kyomu")
	p.invuln = 999.0
	p.global_position = Vector3(0, 0.1, 0)
	p.facing = 0.0
	st.cam.snap_to_target()
	var cam := Camera3D.new()
	st.add_child(cam)
	cam.fov = 40.0
	cam.current = true
	await t.create_timer(1.5).timeout
	var views := {"front": [Vector3(0, 1.5, 3.2), Vector3(0, 1.4, 0)], "side": [Vector3(3.4, 1.4, 0.2), Vector3(0, 1.1, 0)], "back": [Vector3(0, 1.5, -3.4), Vector3(0, 1.2, 0)], "face": [Vector3(0.4, 1.62, 1.6), Vector3(0, 1.55, 0)]}
	for v in views:
		p.global_position = Vector3(0, 0.1, 0)
		p.facing = 0.0
		cam.global_position = views[v][0]
		cam.look_at(views[v][1], Vector3.UP)
		await t.create_timer(0.25).timeout
		p.global_position = Vector3(0, 0.1, 0)
		await t.process_frame
		await st._shot("ky_idle_" + v)
	var d: Enemy = st._spawn_enemy("slime", Vector3(0, 0, 2.2))
	await t.create_timer(1.0).timeout
	d.hp = 99999999; d.max_hp = 99999999
	d.set_physics_process(false)
	d.global_position = Vector3(0, 0, 2.2)
	for act in ["atk1", "atk2", "atk3", "skill"]:
		p.attack_cd = 0.0; p.skill_cd = 0.0; p._act_t = 0.0
		p.global_position = Vector3(0, 0.1, 0)
		Engine.time_scale = 0.12
		if act == "skill": p.do_skill()
		else:
			p._combo = {"atk1": 0, "atk2": 1, "atk3": 2}[act]
			p.do_attack()
		var imp: float = p.rig.action_impact("skill" if act == "skill" else "attack1")
		var el := 0.0
		var marks := [imp * 0.5, imp, imp + 0.08]
		var mi := 0
		cam.global_position = Vector3(3.0, 1.6, 1.0)
		cam.look_at(Vector3(0, 1.2, 0.8), Vector3.UP)
		while el < imp + 0.2:
			await t.process_frame
			el += st.get_process_delta_time()
			if mi < marks.size() and el >= marks[mi]:
				await st._shot("ky_%s_%d" % [act, mi])
				mi += 1
		Engine.time_scale = 1.0
		await t.create_timer(1.5).timeout
	print("CHECK SUMMARY fails=0")
	t.quit(0)
