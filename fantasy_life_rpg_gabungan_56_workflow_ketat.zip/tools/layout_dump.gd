extends Node3D
## Dump geometri kota (bangunan, jalan, pohon, titik penting) ke JSON agar bisa digambar sebagai peta atas.
## Jalankan: godot --headless --path . res://tools/layout_dump.tscn -- /tmp/layout.json
var world: LobbyWorld

func _ready() -> void:
	world = LobbyWorld.new()
	add_child(world)
	world.build()
	await get_tree().physics_frame
	var out := {"buildings": [], "roads": [], "trees": [], "explore": [], "walls": [LobbyLayout.WALL_MIN.x, LobbyLayout.WALL_MIN.y, LobbyLayout.WALL_MAX.x, LobbyLayout.WALL_MAX.y], "plaza_r": LobbyLayout.PLAZA_R}
	for i in world.buildings.size():
		var b: Building = world.buildings[i]
		var r := Rect2()
		if i < world.mesh_rects.size() + 2 and b.mesh_instance != null and not (b.kind in ["gate", "fountain"]):
			var ab: AABB = b.global_transform * b.mesh_instance.mesh.get_aabb()
			r = Rect2(ab.position.x, ab.position.z, ab.size.x, ab.size.z)
		var cols: Array = []
		for n in b.find_children("*", "CollisionShape3D", true, false):
			var cs: CollisionShape3D = n
			var gt := cs.global_transform
			if cs.shape is BoxShape3D:
				var s: Vector3 = (cs.shape as BoxShape3D).size
				cols.append({"t": "box", "c": [gt.origin.x, gt.origin.z], "ax": [gt.basis.x.x, gt.basis.x.z], "az": [gt.basis.z.x, gt.basis.z.z], "hx": s.x * gt.basis.x.length() * 0.5, "hz": s.z * gt.basis.z.length() * 0.5, "top": gt.origin.y + s.y * gt.basis.y.length() * 0.5})
			elif cs.shape is CylinderShape3D:
				var cy: CylinderShape3D = cs.shape
				cols.append({"t": "cyl", "c": [gt.origin.x, gt.origin.z], "r": cy.radius * gt.basis.x.length(), "top": gt.origin.y + cy.height * gt.basis.y.length() * 0.5})
		out["buildings"].append({"kind": b.kind, "pos": [b.global_position.x, b.global_position.z], "yaw": b.rotation_degrees.y, "rect": [r.position.x, r.position.y, r.size.x, r.size.y], "cols": cols, "door": b.has_door})
	for r in world.road_lines:
		var pts: Array = []
		for p in r["pts"]:
			pts.append([p.x, p.y])
		out["roads"].append({"pts": pts, "w": r["w"], "path": r.get("path", false), "cap": r.get("cap", false)})
	for t in world.tree_positions:
		out["trees"].append([t.x, t.y])
	for c in Explore.CHESTS:
		out["explore"].append({"k": "chest", "id": c["id"], "p": [c["pos"].x, c["pos"].y]})
	for w in Explore.WAYPOINTS:
		out["explore"].append({"k": "wp", "id": w["id"], "p": [w["pos"].x, w["pos"].y]})
	for z in Explore.ZONES:
		out["explore"].append({"k": "zone", "id": z["id"], "p": [z["pos"].x, z["pos"].y], "r": z["r"]})
	for k in LobbyLayout.NPC_SPOTS:
		out["explore"].append({"k": "npc", "id": k, "p": [LobbyLayout.NPC_SPOTS[k].x, LobbyLayout.NPC_SPOTS[k].y]})
	for it in world.interactions:
		out["explore"].append({"k": "act", "id": it["id"], "p": [it["pos"].x, it["pos"].z], "r": it["radius"]})
	var path := "/tmp/layout.json"
	for a in OS.get_cmdline_user_args():
		path = a
	var f := FileAccess.open(path, FileAccess.WRITE)
	f.store_string(JSON.stringify(out))
	f.close()
	print("dump ok -> ", path, " buildings=", world.buildings.size(), " roads=", world.road_lines.size())
	get_tree().quit()
