extends Node
## Audit goyang samping saat diam: jangkauan posisi pinggul (cm) sumbu X dan Z, dan putaran miring (derajat) pinggul/tulang belakang
## pada idle/ready dan fidget tiap karakter. Baris SWAY <id> <anim> hipsX=<cm> hipsZ=<cm> rollHips=<deg> rollSpine=<deg> yawSpine=<deg>
func _ready() -> void:
	var lib := AnimLibrary.get_library()
	var tex := ImageTexture.create_from_image(Image.create(4, 4, false, Image.FORMAT_RGBA8))
	for id in Data.character_ids():
		AnimLibrary.fidgets(id)
		var names := ["idle@" + id, "ready@" + id]
		for f in AnimLibrary.fidgets(id):
			names.append(f)
		for nm in names:
			var n2 := AnimLibrary.fit(nm, id)
			if not lib.has_animation(n2):
				continue
			var an := lib.get_animation(n2)
			var out := "SWAY %s %s len=%.1f" % [id, nm, an.length]
			var ti := an.find_track(NodePath("%s:hips" % AnimLibrary.MODEL_NODE), Animation.TYPE_POSITION_3D)
			if ti >= 0:
				var mn := Vector3(1e9, 1e9, 1e9)
				var mx := Vector3(-1e9, -1e9, -1e9)
				for k in an.track_get_key_count(ti):
					var v: Vector3 = an.track_get_key_value(ti, k)
					mn = mn.min(v)
					mx = mx.max(v)
				out += " hipsX=%d hipsZ=%d" % [int((mx.x - mn.x) * 100.0), int((mx.z - mn.z) * 100.0)]
			for b in ["hips", "spine"]:
				var tr := an.find_track(NodePath("%s:%s" % [AnimLibrary.MODEL_NODE, b]), Animation.TYPE_ROTATION_3D)
				if tr < 0:
					continue
				var rmn := 1e9
				var rmx := -1e9
				var ymn := 1e9
				var ymx := -1e9
				for k in an.track_get_key_count(tr):
					var e := Basis(an.track_get_key_value(tr, k) as Quaternion).get_euler()
					rmn = minf(rmn, e.z)
					rmx = maxf(rmx, e.z)
					ymn = minf(ymn, e.y)
					ymx = maxf(ymx, e.y)
				out += " roll%s=%d yaw%s=%d" % [b, int(rad_to_deg(rmx - rmn)), b, int(rad_to_deg(ymx - ymn))]
			print(out)
	get_tree().quit()
