#!/usr/bin/env python3
"""Membuat suara upacara gacha (orisinal, prosedural, stereo 44,1 kHz): assets/audio/gacha_*.wav.

  gacha_charge  2,4 dtk  gemuruh + desau naik yang memuncak (pengumpulan energi)
  gacha_star    1,3 dtk  lonceng kristal (dimainkan dengan pitch naik tiap bintang menyala)
  gacha_burst   3,0 dtk  dentuman: sub-bass jatuh + retakan + gemerlap + akor, dengan gema ruang
  gacha_reveal  3,2 dtk  paduan nada megah + arpeggio lonceng naik (hanya untuk hasil bintang 5+)
  gacha_card    0,6 dtk  desau lembut + kilau kecil (kartu biasa dibuka)

Jalankan:  python3 tools/gen_gacha_audio.py
"""
import os
import struct

import numpy as np
from numpy.fft import irfft, rfft

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "audio")
RNG = np.random.default_rng(2024)


def t_of(d):
    return np.arange(int(SR * d)) / SR


def exp_env(t, tau):
    return np.exp(-t / tau)


def attack(t, a):
    return np.clip(t / a, 0.0, 1.0) ** 2


def band_noise(n, lo, hi):
    """Derau putih disaring pita [lo, hi] Hz lewat FFT (tanpa scipy)."""
    x = RNG.standard_normal(n)
    X = rfft(x)
    f = np.fft.rfftfreq(n, 1.0 / SR)
    m = np.ones_like(f)
    if lo > 0:
        m *= 1.0 / (1.0 + (lo / np.maximum(f, 1.0)) ** 4)
    if hi < SR / 2:
        m *= 1.0 / (1.0 + (f / hi) ** 4)
    y = irfft(X * m, n)
    return y / (np.max(np.abs(y)) or 1.0)


def sweep_noise(d, f0, f1, bands=14):
    """Derau yang pitanya menyapu dari f0 ke f1 (campuran pita dengan selubung bergeser)."""
    t = t_of(d)
    n = len(t)
    out = np.zeros(n)
    fc = np.geomspace(f0, f1, bands)
    pos = np.linspace(0.0, 1.0, bands)
    x = t / d
    for c, p in zip(fc, pos):
        env = np.exp(-((x - p) ** 2) / (2 * 0.09 ** 2))
        out += band_noise(n, c * 0.7, c * 1.4) * env
    return out / (np.max(np.abs(out)) or 1.0)


def reverb(x, rt=1.8, wet=0.3, lp=7000.0):
    """Gema ruang: konvolusi dengan respons impuls derau meluruh. x: (n, 2)."""
    n_ir = int(SR * rt)
    t = np.arange(n_ir) / SR
    out = np.zeros_like(x)
    for ch in range(2):
        ir = RNG.standard_normal(n_ir) * np.exp(-t * (6.9 / rt))
        IR = rfft(ir)
        f = np.fft.rfftfreq(n_ir, 1.0 / SR)
        IR *= 1.0 / (1.0 + (f / lp) ** 2)
        ir = irfft(IR, n_ir)
        ir /= np.sqrt(np.sum(ir ** 2))
        n = len(x) + n_ir
        y = irfft(rfft(x[:, ch], n) * rfft(ir, n), n)[: len(x)]
        out[:, ch] = y
    return x * (1.0 - wet * 0.5) + out * wet


def stereo(mono_l, mono_r=None):
    if mono_r is None:
        mono_r = mono_l
    return np.stack([mono_l, mono_r], axis=1)


def fade_out(x, d=0.05):
    n = int(SR * d)
    x[-n:] *= np.linspace(1.0, 0.0, n)[:, None]
    return x


def master(x, peak=0.97, drive=1.4):
    x = np.tanh(x * drive) / np.tanh(drive)
    x = x / (np.max(np.abs(x)) or 1.0) * peak
    return x


def save(name, x):
    pcm = (np.clip(x, -1, 1) * 32767).astype("<i2").tobytes()
    fmt = struct.pack("<HHIIHH", 1, 2, SR, SR * 4, 4, 16)
    chunks = b"fmt " + struct.pack("<I", len(fmt)) + fmt + b"data" + struct.pack("<I", len(pcm)) + pcm
    riff = b"RIFF" + struct.pack("<I", 4 + len(chunks)) + b"WAVE" + chunks
    with open(os.path.join(OUT, name + ".wav"), "wb") as f:
        f.write(riff)
    print("%-14s %.2f dtk  %d KB" % (name, len(x) / SR, len(riff) // 1024))


def bell(f, d, tau, idx=2.5, ratio=3.5, amp=1.0, t0=0.0, total=None):
    """Lonceng FM: karier f, pemodulasi f*ratio dengan indeks meluruh."""
    n = int(SR * (total or d))
    t = np.arange(n) / SR - t0
    on = t >= 0
    tt = np.where(on, t, 0.0)
    mod = np.sin(2 * np.pi * f * ratio * tt) * idx * np.exp(-tt / (tau * 0.5))
    y = np.sin(2 * np.pi * f * tt + mod) * np.exp(-tt / tau) * np.minimum(tt / 0.004, 1.0)
    return np.where(on, y, 0.0) * amp


# ---------------------------------------------------------------------------------------------------------------------
def make_charge():
    d = 2.4
    t = t_of(d)
    n = len(t)
    x = t / d
    rise = x ** 2.2
    rum = band_noise(n, 30, 180) * (0.25 + 0.9 * rise)
    sw_l = sweep_noise(d, 200, 7000) * (0.05 + 0.75 * rise)
    sw_r = sweep_noise(d, 200, 7000) * (0.05 + 0.75 * rise)
    f = 110.0 * (8.0 ** x)
    ph = 2 * np.pi * np.cumsum(f) / SR
    tone = np.sin(ph) * rise * 0.35 + np.sin(ph * 2.0 + 0.4) * rise * 0.18
    trem = 0.75 + 0.25 * np.sin(2 * np.pi * (4 + 14 * x) * t)
    sh = np.zeros(n)
    for k in range(10):
        ff = RNG.uniform(2500, 8000)
        sh += np.sin(2 * np.pi * ff * t + RNG.uniform(0, 6)) * (rise ** 2) * 0.05
    L = (rum * 0.8 + sw_l + tone * trem + sh) * attack(t, 0.15)
    R = (rum * 0.8 + sw_r + tone * trem + sh * 0.9) * attack(t, 0.15)
    y = fade_out(stereo(L, R), 0.04)
    y = reverb(y, 1.2, 0.2)
    return master(y, 0.9, 1.1)


def make_star():
    d = 1.3
    n = int(SR * d)
    y = bell(1046.5, d, 0.55, 2.2, 3.5, 1.0, 0.0, d)
    y += bell(1046.5 * 2.0, d, 0.35, 1.2, 2.0, 0.45, 0.0, d)
    y += bell(1046.5 * 3.01, d, 0.2, 0.6, 1.0, 0.25, 0.0, d)
    tick = band_noise(n, 5000, 12000) * exp_env(np.arange(n) / SR, 0.012) * 0.25
    L = y + tick
    R = np.roll(y, 40) + tick * 0.8
    out = reverb(stereo(L, R), 1.6, 0.35)
    return master(fade_out(out, 0.06), 0.9, 1.0)


def make_burst():
    d = 3.0
    t = t_of(d)
    n = len(t)
    f = 38.0 + 62.0 * np.exp(-t / 0.18)
    sub = np.sin(2 * np.pi * np.cumsum(f) / SR) * exp_env(t, 0.9) * 1.3
    sub += np.sin(2 * np.pi * np.cumsum(f * 2.0) / SR) * exp_env(t, 0.35) * 0.35
    # speaker HP tidak memutar < 150 Hz: jenuhkan sub supaya punya harmonik 150-600 Hz yang terdengar "menghantam"
    sub = np.tanh(sub * 2.6) * 0.75
    body = band_noise(n, 90, 900) * exp_env(t, 0.45) * 1.5
    thump = np.sin(2 * np.pi * np.cumsum(150.0 + 120.0 * np.exp(-t / 0.1)) / SR) * exp_env(t, 0.28) * 0.9
    crack = band_noise(n, 2500, 14000) * exp_env(t, 0.07) * 1.1
    mid = band_noise(n, 400, 3500) * exp_env(t, 0.3) * 1.0
    # gemerlap kristal yang jatuh
    sh = np.zeros(n)
    for k in range(26):
        ff = RNG.uniform(1500, 9000)
        t0 = RNG.uniform(0.0, 0.7)
        tau = RNG.uniform(0.25, 0.9)
        sh += bell(ff, 2.5, tau, 0.8, 2.7, RNG.uniform(0.03, 0.09), t0, d)
    # akor megah (C-G-C-E-G) dengan sedikit detune
    chord = np.zeros(n)
    for fr in (130.8, 196.0, 261.6, 329.6, 392.0, 523.3):
        for dt in (-1.2, 0.0, 1.3):
            chord += np.sin(2 * np.pi * (fr + dt) * t) * 0.05
    chord *= attack(t, 0.12) * exp_env(t, 1.4)
    L = sub + thump + body + crack + mid + sh * 1.0 + chord
    R = sub + thump + body * 0.95 + crack * 0.9 + mid + np.roll(sh, 300) + chord
    y = stereo(L, R)
    y = reverb(y, 2.2, 0.4, 6000.0)
    y = fade_out(y, 0.15)
    return master(y, 0.98, 1.8)


def make_reveal():
    d = 3.2
    t = t_of(d)
    n = len(t)
    pad = np.zeros(n)
    notes = (261.6, 329.6, 392.0, 523.3, 659.3, 784.0)
    for i, fr in enumerate(notes):
        vib = 1.0 + 0.004 * np.sin(2 * np.pi * (5.0 + 0.3 * i) * t + i)
        for dt in (-1.5, 0.0, 1.5):
            ph = 2 * np.pi * np.cumsum((fr + dt) * vib) / SR
            pad += (np.sin(ph) + 0.35 * np.sin(2 * ph) + 0.15 * np.sin(3 * ph)) * 0.035
    pad *= attack(t, 0.5) * np.where(t < 2.2, 1.0, np.exp(-(t - 2.2) / 0.35))
    arp = np.zeros(n)
    for i, fr in enumerate((523.3, 659.3, 784.0, 1046.5, 1318.5, 1568.0)):
        arp += bell(fr, 2.5, 0.9, 1.5, 3.5, 0.28, 0.25 + 0.09 * i, d)
    sub = np.sin(2 * np.pi * 55.0 * t) * exp_env(t, 0.8) * attack(t, 0.01) * 0.6
    sparkle = band_noise(n, 6000, 14000) * (np.exp(-((t - 0.4) ** 2) / 0.05)) * 0.12
    L = pad + arp + sub + sparkle
    R = pad * 0.95 + np.roll(arp, 220) + sub + np.roll(sparkle, 90)
    y = reverb(stereo(L, R), 2.4, 0.4, 6500.0)
    return master(fade_out(y, 0.2), 0.95, 1.2)


def make_card():
    d = 0.6
    t = t_of(d)
    n = len(t)
    sw = sweep_noise(d, 800, 9000, 10) * np.sin(np.pi * np.clip(t / 0.3, 0, 1)) * (t < 0.32) * 0.5
    ping = bell(1568.0, d, 0.18, 1.0, 3.5, 0.55, 0.15, d)
    thump = np.sin(2 * np.pi * 120.0 * t) * exp_env(t, 0.06) * 0.35
    y = stereo(sw + ping + thump, np.roll(sw, 80) + np.roll(ping, 25) + thump)
    y = reverb(y, 0.9, 0.25)
    return master(fade_out(y, 0.05), 0.8, 1.0)


if __name__ == "__main__":
    save("gacha_charge", make_charge())
    save("gacha_star", make_star())
    save("gacha_burst", make_burst())
    save("gacha_reveal", make_reveal())
    save("gacha_card", make_card())
