#!/usr/bin/env python3
"""Pembangun naskah: menulis data/story.json (dialog + barks) dan data/cinematics.json (sinematik 3D) dari tools/story_src_*.py.
Adegan yang tidak ditimpa tetap dipakai apa adanya dari story.json yang ada. Jalankan dari akar proyek:  python3 tools/gen_story.py"""
import json, os, sys
sys.path.insert(0, os.path.dirname(__file__))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ST = json.load(open(os.path.join(ROOT, "data/story.json")))
CI = json.load(open(os.path.join(ROOT, "data/cinematics.json")))
scenes = {s["id"]: s for s in ST["scenes"]}
order = [s["id"] for s in ST["scenes"]]
barks = ST.get("barks", {})
cines = CI["cinematics"]

def S(id, lines, title=None, chapter=None, where=None, stage=None, when=None, cine=None, after=None):
    """Timpa/buat adegan. lines = [(pembicara, teks[, opsi])]; opsi = {"anim","fx","show","pos","cam"}."""
    sc = scenes.get(id, {"id": id, "title": "", "chapter": "", "where": where or "stage"})
    if title is not None: sc["title"] = title
    if chapter is not None: sc["chapter"] = chapter
    if where: sc["where"] = where
    if stage: sc["stage"] = stage; sc["when"] = when or "intro"
    if cine is not None:
        if cine: sc["cine"] = cine
        else: sc.pop("cine", None)
    sc["lines"] = [{"s": l[0], "t": l[1]} for l in lines]
    scenes[id] = sc
    if id not in order:
        if after and after in order: order.insert(order.index(after) + 1, id)
        else: order.append(id)
    sc["_raw"] = lines
    return sc

POS = {"ren": (0, 0, 0), "lyra": (-2.3, 0, 0.6), "brann": (2.4, 0, 0.6), "orwen": (-4.5, 0, 1.4), "lucien": (-4.5, 0, 1.4),
       "wenyu": (4.6, 0, 1.4), "kuroha": (-3.6, 0, -1.3), "kyomu": (3.8, 0, -1.3), "vael": (5.6, 0, -0.3), "sera": (-5.6, 0, 0.1)}
NAME2ID = {"Ren": "ren", "Lyra": "lyra", "Brann": "brann", "Master Orwen": "orwen", "Wenyu": "wenyu", "Kuroha": "kuroha", "Kyomu": "kyomu",
           "Lucien": "lucien", "Vael": "vael", "Sera": "sera"}

def C(id, set_, cast, title="", chapter="", fx=None, anim=None, wide=None):
    """Bangun sinematik dari baris adegan `id`. cast = id aktor yang ikut; aktor muncul saat pertama bicara kecuali ada di `start`.
    fx = {indeks_baris: [fx...]}, anim = {indeks_baris: {id: anim}}, wide = set indeks baris yang diambil dengan kamera lebar."""
    fx = fx or {}; anim = anim or {}; wide = wide or set()
    raw = scenes[id]["_raw"]
    present = set()
    shots = []
    for i, ln in enumerate(raw):
        who, text = ln[0], ln[1]
        aid = NAME2ID.get(who)
        if aid and aid in cast: present.add(aid)
        is_wide = (aid is None) or (i in wide) or i == 0
        actors = []
        for a in cast:
            if a not in present:
                actors.append({"id": a, "hide": True}); continue
            an = (anim.get(i, {}) or {}).get(a, "idle")
            actors.append({"id": a, "anim": an, "pos": list(POS[a]), "yaw": 180})
        if is_wide:
            cx = 0.0
            cam = {"a": [cx - 1.2, 2.5, 9.6], "la": [0, 1.5, 0], "fov": 46, "dur": 8.0, "b": [cx + 0.6, 2.0, 7.2], "lb": [0, 1.5, 0], "ease": "inout", "fb": 42}
        else:
            sx, _, sz = POS[aid]
            side = 1.0 if sx <= 0 else -1.0
            cam = {"a": [sx + side * 1.0, 1.55, sz + 3.3], "la": [sx, 1.45, sz], "fov": 40, "dur": 6.0, "b": [sx + side * 0.5, 1.5, sz + 2.6],
                   "lb": [sx, 1.45, sz], "ease": "inout", "arc": 6 * side, "hand": 0.5, "fb": 37}
            for a in actors:
                if a["id"] == aid and "anim" in a and a["anim"] == "idle" and ln[2:] and "anim" in ln[2]:
                    a["anim"] = ln[2]["anim"]
        shot = {"cam": cam, "actors": actors, "lines": [{"s": who, "t": text}]}
        f = list(fx.get(i, []))
        if f: shot["fx"] = f
        # gabung baris berurutan pembicara sama & tanpa fx ke satu shot
        if shots and not f and shots[-1]["lines"][-1]["s"] == who and len(shots[-1]["lines"]) < 2 and "fx" not in shots[-1] and not is_wide:
            shots[-1]["lines"].append({"s": who, "t": text}); continue
        shots.append(shot)
    cines[id] = {"set": set_, "title": title or scenes[id].get("title", ""), "chapter": chapter, "shots": shots}
    scenes[id]["cine"] = id

def B(stage_id, rows):
    """Dialog tengah pertarungan: rows = [(kunci, pembicara, teks)]."""
    barks[stage_id] = [{"k": k, "s": s, "t": t} for k, s, t in rows]

import story_src_a, story_src_b, story_src_c
for m in (story_src_a, story_src_b, story_src_c):
    m.build(S, C, B, scenes)

out = []
for i in order:
    sc = dict(scenes[i]); sc.pop("_raw", None)
    out.append(sc)
ST["scenes"] = out
ST["barks"] = barks
ST["version"] = 3
json.dump(ST, open(os.path.join(ROOT, "data/story.json"), "w"), ensure_ascii=False, indent=1)
json.dump(CI, open(os.path.join(ROOT, "data/cinematics.json"), "w"), ensure_ascii=False, indent=1)
print("adegan:", len(out), "sinematik:", len(cines), "stage ber-bark:", len(barks))
