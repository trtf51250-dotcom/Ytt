@echo off
rem Ekspor APK RILIS langsung dari Godot di Windows tanpa GitHub.
rem   tools\ekspor_apk.bat            -> build\fantasy_life_rpg.apk
rem Atur dulu (sekali): GODOT=C:\path\Godot_v4.3-stable_win64.exe  (atau taruh godot di PATH)
rem                     ANDROID_HOME=C:\Android\Sdk   JAVA_HOME=C:\Program Files\Java\jdk-17
rem PENTING: ini RILIS. Template debug jauh lebih lambat di HP.
setlocal
cd /d "%~dp0.."
if "%GODOT%"=="" set GODOT=godot
if "%KS_PASS%"=="" set KS_PASS=android
if "%KEYSTORE%"=="" set KEYSTORE=keystore\fantasy_life.keystore

where "%GODOT%" >nul 2>&1 || (echo GAGAL: Godot tidak ditemukan. Isi variabel GODOT. & exit /b 1)
if not exist "%APPDATA%\Godot\export_templates\4.3.stable\android_release.apk" (
  echo GAGAL: Export template 4.3 belum terpasang. Godot - Editor - Manage Export Templates - Download and Install.
  exit /b 1
)
where keytool >nul 2>&1 || (echo GAGAL: JDK 17 belum terpasang atau belum ada di PATH. & exit /b 1)
if "%ANDROID_HOME%"=="" (echo GAGAL: ANDROID_HOME belum diisi ^(folder Android SDK^). & exit /b 1)
if not exist "%ANDROID_HOME%\build-tools" (echo GAGAL: Android SDK tidak lengkap ^(build-tools tidak ada^). & exit /b 1)

if not exist "%APPDATA%\Godot\editor_settings-4.3.tres" (
  > "%APPDATA%\Godot\editor_settings-4.3.tres" echo [gd_resource type="EditorSettings" format=3]
  >> "%APPDATA%\Godot\editor_settings-4.3.tres" echo [resource]
  >> "%APPDATA%\Godot\editor_settings-4.3.tres" echo export/android/android_sdk_path = "%ANDROID_HOME:\=/%"
  >> "%APPDATA%\Godot\editor_settings-4.3.tres" echo export/android/java_sdk_path = "%JAVA_HOME:\=/%"
)

if not exist keystore mkdir keystore
if not exist "%KEYSTORE%" (
  keytool -genkeypair -v -keyalg RSA -keysize 2048 -validity 10000 -alias fantasylife -keystore "%KEYSTORE%" -storepass %KS_PASS% -keypass %KS_PASS% -dname "CN=Fantasy Life RPG,O=gt,C=ID" >nul
  echo Keystore baru dibuat: %KEYSTORE% ^(password: %KS_PASS%^). SIMPAN berkas ini.
)
set GODOT_ANDROID_KEYSTORE_RELEASE_PATH=%CD%\%KEYSTORE%
set GODOT_ANDROID_KEYSTORE_RELEASE_USER=fantasylife
set GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD=%KS_PASS%

if not exist build mkdir build
echo == Impor aset
"%GODOT%" --headless --path . --import >nul 2>&1
echo == Bake animasi
"%GODOT%" --headless --path . res://tools/bake_anims.tscn
echo == Ekspor APK ^(RILIS^)
"%GODOT%" --headless --path . --export-release "Android" build\fantasy_life_rpg.apk
if not exist build\fantasy_life_rpg.apk (echo GAGAL: APK tidak terbentuk. Baca pesan error di atas. & exit /b 1)
echo SELESAI: build\fantasy_life_rpg.apk
