extends RefCounted
## Bot: suara langkah kaki pemain (batu di jalan, rumput di taman, kayu di rumah), berhenti saat diam; jalan luar gerbang & ujung jalan tertata.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func _count_steps(l: Node3D, name: String, secs: float) -> int:
	var tree := l.get_tree()
	var n := 0
	var last := float(Sfx._last_play.get(name, -10.0))
	var t := 0.0
	while t < secs:
		await tree.physics_frame
		t += 1.0 / 60.0
		var cur := float(Sfx._last_play.get(name, -10.0))
		if cur != last:
			n += 1
			last = cur
	return n
func run(l: Node3D) -> void:
	var tree := l.get_tree()
	await tree.create_timer(1.0).timeout
	for n in ["step_stone", "step_grass", "step_wood"]:
		check("suara %s termuat" % n, Sfx._sounds.has(n))
	var pl = l.player
	# permukaan
	check("jalan utama = batu", l._surface_at(Vector3(0, 0, 45)) == "stone", l._surface_at(Vector3(0, 0, 45)))
	check("alun-alun = batu", l._surface_at(Vector3(5, 0, 5)) == "stone")
	check("taman = rumput", l._surface_at(Vector3(40, 0, 40)) == "grass", l._surface_at(Vector3(40, 0, 40)))
	# berjalan di jalan batu lurus ke depan (kamera yaw 0: layar atas = -Z)
	l.cam.yaw = 0.0
	pl.global_position = Vector3(0, 0.1, 80)
	await tree.create_timer(0.3).timeout
	Input.action_press("move_up")
	await tree.create_timer(0.5).timeout
	var n_stone: int = await _count_steps(l, "step_stone", 1.5)
	check("berlari di jalan batu: langkah terdengar teratur", n_stone >= 4 and n_stone <= 12, "n=%d / 1,5 dtk" % n_stone)
	Input.action_release("move_up")
	await tree.create_timer(0.8).timeout
	var n_idle: int = await _count_steps(l, "step_stone", 1.0)
	check("diam: tidak ada langkah", n_idle == 0, "n=%d" % n_idle)
	# rumput
	pl.global_position = Vector3(40, 0.1, 40)
	await tree.create_timer(0.3).timeout
	Input.action_press("move_right")
	await tree.create_timer(0.4).timeout
	var n_grass: int = await _count_steps(l, "step_grass", 1.2)
	check("berjalan di rumput: bunyi rumput", n_grass >= 3, "n=%d" % n_grass)
	Input.action_release("move_right")
	# permukaan ujung jalan samping & setapak ke pintu
	check("lingkaran ujung jalan samping tercatat sebagai jalan", l.world.dist_to_roads(Vector2(-60, -72)) < 0.0, str(l.world.dist_to_roads(Vector2(-60, -72))))
	var doors_ok := 0
	var doors := 0
	for b in l.world.buildings:
		if b.has_door:
			doors += 1
			var dg: Vector3 = b.to_global(b.door_pos + Vector3(0, -0.4, 1.55))
			if l.world.dist_to_roads(Vector2(dg.x, dg.z)) < 1.6:
				doors_ok += 1
	check("setapak: titik di depan tiap pintu menyatu dengan jalan/setapak", doors_ok == doors, "%d/%d" % [doors_ok, doors])
	print("CHECK SUMMARY fails=", fails)
	tree.quit()
