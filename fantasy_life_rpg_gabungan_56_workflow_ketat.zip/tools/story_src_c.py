"""Naskah bagian C: Bab 5 (Menara Rantai Merah), kepulangan ke Aurelia, Bab 6 (Lagu yang Belum Selesai) dan epilog."""

LAGU_1 = "Tidurlah, bintang kecil, fajar belum jauh. Yang pergi akan pulang di dalam namamu."
LAGU_2 = "Yang hilang tak hilang bila ada yang menyebut. Simpan aku di sela dua tarikan napas."
LAGU_3 = "Dan bila sunyi menelan semua yang kau cinta, nyanyikan aku, dan kami semua kembali."


def build(S, C, B, scenes):
    # ------------------------------------------------------------------ BAB 5
    S("s5_1_intro", [
        ("Narator", "Rantai-rantai merah sebesar pohon melilit kaki menara, bergetar mengikuti detak yang entah milik siapa."),
        ("Vael", "Jangan lewat pintu depan, rantainya menyerap tenaga. Aku sudah menebas rantai ini tiga tahun, dan baru satu sisi menara yang longgar."),
        ("Brann", "Pemuda bertanduk dengan pedang segede pintu. Kau siapa?"),
        ("Vael", "Vael. Aku dulu ksatria di bawah menara ini. Aku lolos dari rantainya. Yang lain belum."),
        ("Lyra", "Berarti Ksatria Rantai itu bukan penjaganya. Mereka tahanannya."),
        ("Ren", "Apa pun itu, kita naik sampai ke puncak."),
    ], title="Kaki Menara", chapter="Bab 5: Menara Rantai Merah")
    S("s5_2_intro", [
        ("Narator", "Lorong menara tak berujung. Rantai bergantungan dari langit-langit gelap, dan setiap mata rantainya berdenyut merah."),
        ("Brann", "Kalian merasakannya? Rantai ini menyerap tenaga kita tiap kali bergerak."),
        ("Lyra", "Seseorang memakai Kehampaan untuk mengikat semuanya. Ksatria, pengikut, bahkan Uranos. Semuanya boneka."),
        ("Ren", "Kalau begitu putuskan dulu pasukan pengawalnya. Setelah itu baru dia."),
    ], title="Lorong Belenggu")
    S("s5_2_outro", [
        ("Narator", "Di ujung lorong, di antara rantai yang menggantung, seorang pria berjubah biru malam terduduk. Monokelnya retak, dan di pangkuannya ada buku catatan tebal."),
        ("Lyra", "Guru..."),
        ("Lucien", "Lyra? Tulisan tanganmu ada di buku ini. Aku membaca halaman terakhir tiap hari supaya tak lupa kau ada. Maaf, aku tidak ingat nama keluargamu."),
        ("Lyra", "Tidak apa-apa. Aku punya bukumu juga. Aku bawakan semua yang tak sempat kau tulis."),
        ("Lucien", "Dengar, ini penting. Kaedros bukan pembuat Kehampaan. Ia Penjaga yang gagal menyelamatkan Yang Menyanyi. Rantainya adalah kesedihannya."),
        ("Ren", "Kaedros."),
        ("Lucien", "Nama yang sudah lama tak diucapkan. Bebaskan aku dulu, anak muda, lututku sudah lama menyerah."),
    ], title="Guru yang Terbelenggu", stage="s5_2", when="outro")
    S("s5_3_intro", [
        ("Narator", "Pintu besi dililit rantai merah berlapis-lapis. Dari baliknya terdengar langkah ksatria yang tak terhitung."),
        ("Lyra", "Ruang cadangan sang Raja. Kalau kita bersihkan, pasukannya melemah."),
        ("Vael", "Tiap ksatria di sini pernah kukenal namanya. Jangan sampai ada yang kulupakan."),
    ], title="Ruang Gembok")
    S("s5_boss_intro", [
        ("Narator", "Di puncak menara, takhta berduri berdiri di atas karpet merah. Sesosok raksasa bermahkota duri bangkit perlahan. Rantai berderak di sekujur tubuhnya, dan udara menekan dada siapa pun yang menatapnya."),
        ("Raja Rantai Merah", "Tiga segel telah terbuka, dan kau datang membawa kuncinya. Betapa rapinya takdir."),
        ("Ren", "Kau Yang Mengikat. Kau Kaedros."),
        ("Raja Rantai Merah", "Nama itu bukan milik makhluk berantai sepertiku lagi. Tapi ya. Aku mengikat Kehampaan, dan mengikat dunia, supaya tak ada lagi yang hilang."),
        ("Lyra", "Dengan membekukan semua orang?"),
        ("Raja Rantai Merah", "Beku itu aman. Yang kau lawan ini hanya bayangan rantaiku. Goreslah ia, dan aku mungkin sudi menemuimu."),
    ], title="Takhta Rantai Merah")
    S("s5_boss_outro", [
        ("Narator", "Bayangan itu retak dari dada hingga bahu. Rantai merahnya jatuh berdenting, satu per satu, lalu padam."),
        ("Brann", "Kita menang? Beneran menang?"),
        ("Raja Rantai Merah", "Kau memecahkan salinanku. Tiga ratus tahun tak ada yang bisa. Aku mulai berharap lagi, dan aku benci itu."),
        ("Ren", "Keluarlah! Bicara langsung!"),
        ("Raja Rantai Merah", "Belum. Kau belum menjawab pertanyaan paling sederhana: apa yang kau pertahankan? Kekuatan tanpa jawaban akan patah di tanganku."),
        ("Lyra", "Dan ini tak sampai satu persen kekuatan aslinya. Aku bisa membaca tekanannya."),
        ("Raja Rantai Merah", "Pulanglah, cari jawabanmu. Kembali tanpa itu, kupatahkan kuncimu. Kembali dengannya, mungkin kau lebih berguna hidup."),
        ("Narator", "Lantai menara membuka. Rantai merah menarik mereka turun dan menurunkan mereka pelan di depan gerbang Aurelia, bersama pria berjubah biru dengan buku di dekapannya."),
        ("Ren", "Apa yang kupertahankan? Aku harus menemukan jawabannya."),
    ], title="Pertanyaan yang Sederhana", cine="s5_boss_outro")
    C("s5_boss_outro", "tower", ["ren", "lyra", "brann"], title="Pertanyaan yang Sederhana", chapter="Bab 5",
      fx={0: ["king", "shake"], 2: ["shake"], 7: ["flare"]}, anim={0: {"ren": "hurt"}})

    # ------------------------------------------------------------------ Kepulangan
    S("a_return", [
        ("Narator", "Aurelia fajar. Master Orwen berlari menuruni tangga alun-alun, dan berhenti begitu melihat pria berjubah biru di samping Ren."),
        ("Master Orwen", "Lucien. Sebelas tahun."),
        ("Lucien", "Enam belas, Orwen. Kau menyembunyikan anak itu dari kami selama enam belas tahun."),
        ("Master Orwen", "Ren, tanda itu milik Yang Menyanyi. Aku tahu sejak malam kutemukan kau. Aku takut jika kau tahu, kau akan pergi ke menara itu sendirian."),
        ("Ren", "Aku sudah pergi, Guru. Dan aku pulang."),
        ("Master Orwen", "Dan masih hidup. Itu lebih dari yang kuharapkan."),
        ("Lucien", "Tiga jalan: Penanggung, Pengikat, Penyanyi. Dua yang pertama gagal karena memikul sendirian. Yang Menyanyi satu-satunya yang berbagi. Segelnya dipegang lewat lagu yang diingat banyak orang."),
        ("Wenyu", "Dua bait pertama sudah kunyanyikan padamu, Ren. Bait ketiga ada di tangan Kaedros, atau di suatu tempat dalam menara itu."),
        ("Ren", "Yang Menyanyi. Siapa namanya?"),
        ("Lucien", "Selene. Dan Kaedros adalah kakaknya. Ia tak sanggup melihat adiknya menghilang ditelan Kehampaan. Maka ia mengikat semuanya supaya tak ada lagi yang hilang."),
        ("Ren", "Pertanyaannya: apa yang kupertahankan. Aku tahu jawabannya sekarang. Bukan segel. Orang-orang yang mengingatku, dan orang-orang yang akan kuingat."),
        ("Master Orwen", "Kalau begitu panggil mereka semua. Menara itu terlalu tinggi untuk didaki sendirian."),
    ], title="Pulang ke Aurelia", where="lobby", cine="a_return")
    C("a_return", "plaza", ["ren", "lyra", "brann", "orwen", "lucien", "wenyu"], title="Pulang ke Aurelia", chapter="Bab 5 · Interlude", fx={3: ["mark"], 10: ["mark"]})

    # ------------------------------------------------------------------ BAB 6
    S("s6_1_intro", [
        ("Narator", "Kali ini mereka masuk lewat pintu depan, bersama banyak orang. Vael menebas rantai di kanan, Kuroha menjaga sisi kiri, Kyomu menyelinap di depan, dan Sera mengawasi dari tangga atas."),
        ("Vael", "Aku belum selesai menebas ini. Hari ini aku punya bantuan."),
        ("Kuroha", "Satu rantai, satu wajah."),
        ("Lucien", "Lihat wajah di balik helm mereka. Itu warga kota lama yang dibekukan. Tebaslah rantainya, bukan orangnya."),
        ("Ren", "Kita naik bersama."),
    ], title="Tangga Ingatan", stage="s6_1", chapter="Bab 6: Lagu yang Belum Selesai")
    S("s6_1_outro", [
        ("Narator", "Satu Ksatria Rantai berlutut. Helmnya jatuh, dan di baliknya seorang perempuan muda mengerjap pelan."),
        ("Prajurit Terbebas", "Apakah... sudah pagi? Aku sedang menunggu seseorang di pasar."),
        ("Lyra", "Sudah pagi. Siapa namamu? Aku catat."),
    ], title="Yang Terbangun", stage="s6_1", when="outro")
    S("s6_2_intro", [
        ("Narator", "Sebuah taman di tengah menara, tempat waktu berhenti. Kelopak bunga menggantung di udara, dan seekor kupu-kupu membeku di tengah kepak."),
        ("Lucien", "Taman ini dijaga persis seperti hari Selene menghilang. Kaedros tak membiarkan sehelai pun jatuh."),
        ("Wenyu", "Dengar. Bait ketiga ada di sini, aku bisa merasakannya."),
        ("Ren", "Ayo. Sekarang."),
    ], title="Taman yang Berhenti", stage="s6_2")
    S("s6_2_outro", [
        ("Narator", "Tanda di tangan Ren menyala, dan taman beku berbisik. Sosok perempuan bercahaya muncul sesaat di antara kelopak yang menggantung, bernyanyi tanpa suara."),
        ("Ren", "Itu perempuan di pecahan yang kulihat dulu. Dia Selene."),
        ("Wenyu", LAGU_1),
        ("Wenyu", LAGU_2),
        ("Ren", "Bait ketiganya... aku mengenalnya. Aku selalu mengenalnya. Hanya belum pernah mengingatnya sampai sekarang."),
    ], title="Suara di Antara Kelopak", stage="s6_2", when="outro")
    S("s6_3_intro", [
        ("Narator", "Gerbang terakhir. Ratusan ksatria rantai berbaris tanpa suara di tangga menuju takhta."),
        ("Sera", "Aku tutup jalan belakang. Siapa pun yang lolos, kubuat jera."),
        ("Kuroha", "Pergilah, anak bintang. Kami menahan di sini."),
        ("Kyomu", "Jangan salah paham. Aku tidak bertarung demi dunia. Aku bertarung demi wajah yang ingin kuingat lagi."),
        ("Vael", "Naiklah. Aku sudah menebas rantai ini tiga tahun. Mari kita selesaikan hari ini."),
    ], title="Gerbang Takhta", stage="s6_3")
    S("s6_3_outro", [
        ("Narator", "Gerbang takhta terbuka sendiri. Di balik pintu, udara hangat dan sunyi seperti taman yang lama ditinggal."),
        ("Lyra", "Ren, apa pun yang terjadi di dalam, aku mencatat semuanya. Aku tidak akan lupa."),
        ("Brann", "Dan aku di depanmu. Kau tahu itu."),
    ], title="Pintu yang Terbuka", stage="s6_3", when="outro")
    S("s6_boss_intro", [
        ("Narator", "Takhta berduri itu kosong, sampai sosok raksasa bermahkota duri melangkah keluar dari bayangan. Kali ini rantainya tidak berderak. Ia hanya diam, seperti orang yang menunggu seseorang selama tiga ratus tahun."),
        ("Kaedros", "Kau kembali. Jawabanmu?"),
        ("Ren", "Yang kupertahankan adalah orang-orang yang pernah hilang di tanganku, dan orang-orang yang belum kuingat. Bukan dunia yang tak berubah. Dunia yang saling mengingat."),
        ("Kaedros", "Kata-kata murahan, anak bintang. Selene juga bilang begitu, sampai Kehampaan menghapus namanya dari lidahku."),
        ("Ren", "Jawabanku bukan kata-kata. Ia sedang menaiki tanggamu, Kaedros."),
        ("Kaedros", "Kalau begitu patahkan aku, dan lihat apakah kau sanggup menanggung kehilangan yang kuhindari."),
        ("Lyra", "Dia serius kali ini. Semuanya, hati-hati!"),
    ], title="Kaedros, Penjaga yang Tersisa", stage="s6_boss", cine="s6_boss_intro")
    C("s6_boss_intro", "tower", ["ren", "lyra", "brann"], title="Kaedros, Penjaga yang Tersisa", chapter="Bab 6", fx={0: ["king"], 5: ["shake"]})
    S("s6_boss_outro", [
        ("Narator", "Rantai merah retak satu demi satu. Kaedros berlutut, mahkota durinya jatuh, dan menara bergetar seperti hendak runtuh."),
        ("Kaedros", "Aku hanya ingin satu hari lagi. Satu hari bersamanya."),
        ("Ren", "Dia tidak ingin kau menyimpannya sendirian, Kaedros. Itu isi lagunya."),
        ("Wenyu", "Ren, sekarang. Aku mainkan dua bait pertama. Nyanyikan yang ketiga."),
        ("Ren", LAGU_3),
        ("Narator", "Tanda di tangan Ren menyala, lalu terbelah menjadi benang cahaya. Satu menyambung ke Lyra, satu ke Brann, satu ke Master Orwen di kejauhan, dan ribuan lainnya menjalar ke seluruh Eldoria, ke setiap orang yang pernah disebut namanya dalam buku Lyra."),
        ("Kaedros", "Selene. Suaramu. Kau selalu lebih berani dariku."),
        ("Narator", "Rantai merah di seluruh menara berubah menjadi cahaya. Para Ksatria Rantai terbangun, mengerjap, memanggil nama masing-masing. Untuk pertama kali dalam tiga ratus tahun, sebuah taman gugur kelopaknya."),
        ("Kaedros", "Ingatlah aku sebagai kakak yang terlambat, anak Selene. Dan jangan memikul semuanya sendirian."),
        ("Ren", "Tidak akan. Aku punya terlalu banyak orang untuk dibagi."),
    ], title="Lagu yang Selesai", stage="s6_boss", when="outro", cine="s6_boss_outro")
    C("s6_boss_outro", "tower", ["ren", "lyra", "brann", "wenyu"], title="Lagu yang Selesai", chapter="Bab 6",
      fx={0: ["shake", "chains"], 4: ["mark", "flare", "pillar"], 5: ["flare"], 7: ["chains"]})

    # ------------------------------------------------------------------ Epilog
    S("a_epilogue", [
        ("Narator", "Aurelia, tiga pekan kemudian. Kristal Bintang di bawah air mancur bersinar tenang dan mantap, tak lagi berkedip. Alun-alun penuh warga yang membawa lampion, dan di setiap lampion tertulis sebuah nama."),
        ("Doran", "Brann! Nak, bantu Ayah memasang lampion ini. Yang ini tulisannya jelek, tapi aku mengingat isinya."),
        ("Brann", "Itu namaku, Yah. Dan memang tulisanmu jelek."),
        ("Lucien", "Lyra, kau menulis semua ini? Dua ribu tiga ratus halaman?"),
        ("Lyra", "Satu orang, satu halaman. Itu janjiku. Aku bahkan menulis halaman untuk Uranos, dan untuk Mirel."),
        ("Master Orwen", "Ren. Ke sinilah. Ada yang ingin kuberikan: sepotong kain dari selimutmu malam Bintang Jatuh itu, yang kusimpan enam belas tahun."),
        ("Ren", "Ada sulaman di tepinya. Bintang kecil, dan satu kata: 'Selene'. Jadi dia benar-benar..."),
        ("Master Orwen", "Orang yang menitipkanmu ke kota ini agar aman. Dan ia berhasil, nak. Kau adalah buktinya."),
        ("Wenyu", "Aku akan menyanyikan lagu itu di tiap kota. Sampai semua orang mengenalnya. Itu cara segel ini tetap hidup."),
        ("Ren", "Tandaku hangat lagi. Bukan dari kristal ini, tapi dari jauh. Dari arah barat..."),
        ("Lyra", "Aku sudah menyiapkan buku baru. Halaman pertama sudah kuberi judul."),
        ("Ren", "Apa judulnya?"),
        ("Lyra", "'Bersambung.'"),
    ], title="Epilog: Seribu Lampion", where="lobby", cine="a_epilogue")
    C("a_epilogue", "plaza", ["ren", "lyra", "brann", "orwen", "lucien", "wenyu"], title="Seribu Lampion", chapter="Tamat · Musim Pertama", fx={0: ["flare"], 9: ["mark"]})

    # ------------------------------------------------------------------ dialog tengah pertarungan: Bab 5-6
    B("s5_1", [("w0", "Vael", "Rantai itu menyerap tenaga. Jangan berdiri lama di dekatnya."), ("hunt", "Vael", "Yang bermahkota itu pemimpinnya. Tebas dia, dan sisanya lepas!"), ("done", "Vael", "Satu rantai putus. Menara ini tak bisa menahan kita."), ("low", "Brann", "Ren, minum ramuan!")])
    B("s5_2", [("w0", "Lyra", "Rantai merah menyerap tenaga. Bergeraklah terus!"), ("zone", "Lyra", "Lingkaran segel! Berdiri di dalamnya sampai rantai di sekitarnya putus!"), ("done", "Lyra", "Aku merasa Guru Lucien dekat. Ayo!"), ("low", "Brann", "Ren, mundur!")])
    B("s5_3", [("w0", "Vael", "Tiap ksatria di sini pernah kukenal namanya."), ("survive", "Vael", "Bertahan sampai gemboknya patah!"), ("done", "Vael", "Gembok patah. Pasukan Raja melemah."), ("low", "Lyra", "Tahan!")])
    B("s5_boss", [("boss", "Raja Rantai Merah", "Ayo, perlihatkan jawabanmu."), ("low", "Lyra", "Itu cuma bayangannya! Jangan menyerah!")])
    B("s6_1", [("w0", "Kuroha", "Tebas rantainya, bukan orangnya."), ("zone", "Lucien", "Lingkaran segel itu ciptaan Selene! Berdiri di dalamnya!"), ("done", "Lyra", "Aku catat tiap nama yang terbangun."), ("low", "Vael", "Mundur, Ren!")])
    B("s6_2", [("w0", "Wenyu", "Bait ketiga ada di sini. Tunggu sebentar lagi."), ("survive", "Wenyu", "Aku memainkan lagunya! Bertahanlah sampai nadanya selesai!"), ("done", "Wenyu", "Dia mendengarkan. Aku merasakannya."), ("low", "Brann", "Ren!")])
    B("s6_3", [("w0", "Sera", "Aku tutup jalan belakang. Maju terus!"), ("hunt", "Kyomu", "Jenderal rantai bertanda merah. Habisi dia dulu."), ("done", "Kuroha", "Gerbang takhta terbuka."), ("low", "Lyra", "Ren, pulihkan dirimu!")])
    B("s6_boss", [("boss", "Kaedros", "Tunjukkan padaku."), ("low", "Brann", "Ren, jangan menyerah! Kami di sini!")])
