#!/usr/bin/env python3
"""Membuat tekstur kulit (skin) karakter & NPC dari assets/hero/skin.png (rig ZN RIG V2 milikmu).

Setiap varian mewarnai ulang bagian rambut, rompi, baju dalam, celana, dan dasi tanpa mengubah relief
(kecerahan asli dipertahankan). Rambut MC dibuat gradasi putih -> biru.

Pakai:  python3 tools/gen_skins.py
Butuh:  pip install pillow numpy
"""
import os
import colorsys
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "assets", "hero", "skin.png")
OUT = os.path.join(HERE, "..", "assets", "hero")

im = Image.open(SRC).convert("RGBA")
A = np.array(im).astype(np.float64) / 255.0
H, W = 64, 64
RGB = A[:H, :, :3]
ALPHA = A[:H, :, 3]


def rgb_to_hsv(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    mx = rgb.max(-1)
    mn = rgb.min(-1)
    d = mx - mn
    m = d > 1e-9
    safe = np.where(m, d, 1)
    rc = (mx - r) / safe
    gc = (mx - g) / safe
    bc = (mx - b) / safe
    h = np.where(mx == r, bc - gc, np.where(mx == g, 2.0 + rc - bc, 4.0 + gc - rc))
    h = np.where(m, (h / 6.0) % 1.0, 0.0)
    s = np.where(mx > 1e-9, d / np.where(mx > 1e-9, mx, 1), 0)
    return np.stack([h, s, mx], -1)


HSV = rgb_to_hsv(RGB)
hh, ss, vv = HSV[..., 0] * 360, HSV[..., 1], HSV[..., 2]
yy = np.arange(H)[:, None] * np.ones((1, W))
xx = np.ones((H, 1)) * np.arange(W)[None, :]
head_zone = yy < 16
skin_like = (hh > 10) & (hh < 45) & (ss > 0.08) & (vv > 0.5)
silver = (ss < 0.22) & (vv > 0.35) & ~skin_like
red_like = ((hh < 14) | (hh > 335)) & (ss > 0.35)
opaque = ALPHA > 0.1


def rect(x0, y0, x1, y1):
    m = np.zeros((H, W), bool)
    m[y0:y1, x0:x1] = True
    return m


# Tata letak skin standar 64x64 (gaya Minecraft): kepala di atas, lalu kaki kanan | badan | lengan kanan,
# dan baris bawah berisi kaki kiri & lengan kiri; baris 32-48 / 48-64 berisi lapisan luar (overlay).
HEAD = rect(0, 0, 64, 16)
LEGS = rect(0, 16, 16, 48) | rect(16, 48, 32, 64) | rect(0, 48, 16, 64)
TORSO = rect(16, 16, 40, 48)
ARMS = rect(40, 16, 56, 48) | rect(32, 48, 48, 64) | rect(48, 48, 64, 64)
# sepatu = 4 baris terbawah sisi kaki
SHOES = rect(0, 28, 16, 32) | rect(0, 44, 16, 48) | rect(16, 60, 32, 64) | rect(0, 60, 16, 64)

M_HAIR = HEAD & silver & opaque
M_TIE = TORSO & red_like & opaque
M_SHIRT = (TORSO & silver & ~red_like | ARMS & ~skin_like) & opaque
M_VEST = TORSO & ~skin_like & ~red_like & ~silver & opaque
M_PANTS = LEGS & ~SHOES & opaque
M_SHOES = LEGS & SHOES & opaque


def hexc(s):
    s = s.lstrip("#")
    return np.array([int(s[i:i + 2], 16) / 255.0 for i in (0, 2, 4)])


def tint(out, mask, target, gain=0.9, floor=0.35):
    """Warnai piksel `mask` dengan warna `target` (RGB 0..1), pertahankan relief kecerahan asli."""
    if target is None or not mask.any():
        return
    ref = np.median(vv[mask]) if mask.any() else 0.5
    ref = max(ref, 0.05)
    relief = np.clip(vv / ref, 0.0, 2.2)
    f = np.clip(1.0 + (relief - 1.0) * gain, floor, 1.6)
    col = np.clip(target[None, None, :] * f[..., None], 0.0, 1.0)
    out[mask] = col[mask]


def gradient_hair(out, c_dark, c_mid, c_light, bias_y=0.0):
    """Rambut: dipetakan dari kecerahan asli ke palet gelap->tengah->terang, ditambah gradasi vertikal ke warna gelap."""
    m = M_HAIR
    lum = vv.copy()
    lo, hi = np.percentile(lum[m], 5), np.percentile(lum[m], 98)
    t = np.clip((lum - lo) / max(hi - lo, 1e-6), 0, 1)
    # ujung rambut (baris bawah tiap muka kepala) lebih biru
    ys = np.where(yy >= 8, (yy - 8) / 8.0, 0.0)
    t = np.clip(t - bias_y * ys, 0, 1)
    c = np.where(t[..., None] < 0.5,
                 c_dark[None, None, :] * (1 - t[..., None] * 2) + c_mid[None, None, :] * (t[..., None] * 2),
                 c_mid[None, None, :] * (1 - (t[..., None] - 0.5) * 2) + c_light[None, None, :] * ((t[..., None] - 0.5) * 2))
    out[m] = np.clip(c, 0, 1)[m]


def apply_detail(o, motif, acc, acc2=None, weave=0.05):
    """Detail kain generik untuk skin polos: tenunan halus, jahitan, tepi/hem bergaris, dan motif per karakter pada rompi/baju/celana.
    motif: stars | leaf | flame | cloud | pin | rivets | lattice | wave | none. Hanya piksel berwarna kain yang diubah (kulit & rambut tidak)."""
    acc = hexc(acc) if isinstance(acc, str) else acc
    acc2 = hexc(acc2) if isinstance(acc2, str) else (acc2 if acc2 is not None else np.clip(acc * 0.6, 0, 1))
    cloth = (M_VEST | M_SHIRT | M_PANTS) & opaque
    rng = np.random.RandomState(5)
    for y in range(H):
        for x in range(W):
            if not cloth[y, x]:
                continue
            c = o[y, x].copy()
            c = c * (1.0 - weave * ((x + y) % 2))                    # tenunan kain
            if y % 4 == 3:
                c = c * 0.93                                         # garis jahitan melintang halus
            c = c * (1.0 + (rng.rand() - 0.5) * 0.04)
            o[y, x] = np.clip(c, 0, 1)
    def put(x, y, col, a=0.85, only=None):
        if 0 <= x < W and 0 <= y < H and cloth[y, x] and (only is None or only[y, x]):
            o[y, x] = np.clip(o[y, x] * (1 - a) + col * a, 0, 1)
    for y in range(16, H):
        for x in range(W):
            if not cloth[y, x]:
                continue
            if motif == "stars":
                if (x * 7 + y * 13) % 23 == 0:
                    put(x, y, acc); put(x - 1, y, acc, 0.55); put(x + 1, y, acc, 0.55); put(x, y - 1, acc, 0.55); put(x, y + 1, acc, 0.55)
            elif motif == "leaf":
                if (x + 2 * y) % 9 == 0:
                    put(x, y, acc); put(x + 1, y + 1, acc2, 0.7)
            elif motif == "flame":
                if (x * 3 + y) % 8 in (0, 1) and y % 4 in (0, 1):
                    put(x, y, acc, 0.8)
                if (x * 3 + y) % 8 == 0 and y % 4 == 0:
                    put(x, y, acc2, 0.9)
            elif motif == "cloud":
                if (y % 8 == 2 and x % 8 in (2, 3, 4, 5)) or (y % 8 == 3 and x % 8 in (1, 6)):
                    put(x, y, acc, 0.75)
            elif motif == "pin":
                if x % 4 == 0:
                    put(x, y, acc, 0.4)
            elif motif == "rivets":
                if x % 5 == 2 and y % 5 == 2:
                    put(x, y, acc, 0.95); put(x, y + 1, acc2, 0.7)
            elif motif == "lattice":
                if (x + y) % 5 == 0 or (x - y) % 5 == 0:
                    put(x, y, acc, 0.35)
            elif motif == "wave":
                if (y % 6 == 2 and (x + (y // 6) * 3) % 6 in (0, 1, 2)) or (y % 6 == 3 and (x + (y // 6) * 3) % 6 == 3):
                    put(x, y, acc, 0.6)
    # tepi bergaris: baris paling atas/bawah tiap blok kain jadi garis aksen (kerah, hem, manset)
    for y in range(16, H - 1):
        for x in range(W):
            if cloth[y, x] and not cloth[y + 1, x]:
                put(x, y, acc2, 0.8)                                  # tepi bawah
            if cloth[y, x] and not cloth[y - 1, x] and y > 17:
                put(x, y, acc, 0.5)                                   # tepi atas
    # jahitan tengah depan badan (x 23/24) & kancing
    for y in range(20, 32):
        if cloth[y, 23] and cloth[y, 24]:
            o[y, 23] = np.clip(o[y, 23] * 0.82, 0, 1)
            if y % 3 == 0:
                o[y, 24] = np.clip(acc, 0, 1)



def make(name, hair=None, vest=None, shirt=None, pants=None, shoes=None, tie=None, hair_grad=None, paint=None, detail=None):
    o = RGB.copy()
    if hair_grad is not None:
        gradient_hair(o, *hair_grad)
    elif hair is not None:
        tint(o, M_HAIR, hexc(hair), 1.1)
    tint(o, M_VEST, hexc(vest) if vest else None, 0.9)
    tint(o, M_SHIRT, hexc(shirt) if shirt else None, 0.7)
    tint(o, M_PANTS, hexc(pants) if pants else None, 0.9, 0.5)
    tint(o, M_SHOES, hexc(shoes) if shoes else None, 0.9, 0.5)
    tint(o, M_TIE, hexc(tie) if tie else None, 0.9)
    if detail is not None:
        apply_detail(o, *detail)
    if paint is not None:
        paint(o)
    out = np.concatenate([np.concatenate([o, ALPHA[..., None]], -1), A[H:, :, :]], 0)
    Image.fromarray((np.clip(out, 0, 1) * 255).astype(np.uint8), "RGBA").save(os.path.join(OUT, f"skin_{name}.png"))
    print("skin_%s.png" % name)


# ---------------------------------------------------------------- party
# Ren (MC): rambut putih-biru, baju putih, celana biru tua, sepatu putih, bros emas
make("ren",
     hair_grad=(hexc("3b74e8"), hexc("d4e8ff"), hexc("ffffff"), 0.55),
     vest="#3f73e6", shirt="#f6f9ff", pants="#243a82", shoes="#eef4ff", tie="#f2c14e", detail=("stars", "#ffe39a", "#f2c14e"))
# Lyra: penyihir ungu
make("lyra", hair="#b58cff", vest="#6c3fc4", shirt="#f1e6ff", pants="#352060", shoes="#e8d8ff", tie="#ffd45e", detail=("stars","#ffe9a8","#ffd45e"))
# Brann: pengawal, zirah oranye-baja
make("brann", hair="#7a3a1c", vest="#d4622a", shirt="#9aa4b4", pants="#4a3426", shoes="#5a4a3e", tie="#f2c14e", detail=("rivets","#f4ead2","#3a2a1c"))
# Sera: pemanah hijau
make("zeya", hair="#e8456a", vest="#3a2a4a", shirt="#d8d0e0", pants="#2a2030", shoes="#1c1620", tie="#ff7a9a", detail=("lattice","#ff7a9a","#e8456a"))  # pendekar bayangan (bonus login)
make("ember", hair="#ff7a3a", vest="#8a2a1a", shirt="#ffe0b0", pants="#3a1a14", shoes="#2a1a14", tie="#ffd45e", detail=("flame","#ffb347","#ffe08a"))  # penyihir api (karakter event contoh)


def paint_hakuya(o):
    """Samurai ★6: haori putih bermotif silang hitam, kimono dalam gelap, obi hitam, pembalut lengan hitam dengan X putih,
    hakama hitam berlipit, sepatu hitam (tata letak skin standar 64x64; hanya piksel yang buram yang dicat)."""
    rng = np.random.RandomState(7)
    WHITE = hexc("f4f6fb"); GREY = hexc("c9cfdb"); BLACK = hexc("16161c"); INK = hexc("26262e"); PLEAT = hexc("34343e")

    def put(x, y, c, jitter=0.04):
        if 0 <= x < 64 and 0 <= y < 64 and ALPHA[y, x] > 0.1:
            o[y, x] = np.clip(c * (1.0 - jitter + rng.rand() * jitter * 2), 0, 1)

    def fill(x0, y0, x1, y1, c, jitter=0.04):
        for y in range(y0, y1):
            for x in range(x0, x1):
                put(x, y, c, jitter)

    # ---- badan (16,16): kanan 16-20, depan 20-28, kiri 28-32, belakang 32-40; tinggi 20-32
    fill(16, 20, 40, 32, WHITE)
    fill(16, 29, 40, 32, BLACK, 0.02)                    # obi hitam
    for x in range(20, 28):                              # kimono dalam gelap berbentuk V di depan
        d = abs(x - 23.5)
        for y in range(20, 29):
            if d < 0.5 + (y - 20) * 0.0 + (1.8 if y < 24 else 1.0) * (1.0 - (y - 20) / 9.0) + 0.5:
                put(x, y, INK, 0.03)
    for y in range(20, 29):
        put(23, y, INK); put(24, y, INK)
    for (cx, cy) in [(21, 24), (26, 24), (35, 24), (38, 24)]:      # motif silang hitam di dada & punggung
        for dx, dy in [(0, 0), (-1, -1), (1, -1), (-1, 1), (1, 1)]:
            put(cx + dx, cy + dy, BLACK, 0.02)
    fill(16, 28, 40, 29, GREY, 0.02)                     # tepi bawah haori

    # ---- lengan: kanan (40,16), kiri (32,48); muka: kanan,depan,kiri,belakang selebar 4, tinggi 12
    for (ox, oy) in [(40, 16), (32, 48)]:
        for f in range(4):
            x0 = ox + f * 4
            fill(x0, oy + 4, x0 + 4, oy + 10, WHITE)        # lengan atas (lengan lebar haori)
            fill(x0, oy + 10, x0 + 4, oy + 16, BLACK, 0.02)  # pembalut lengan hitam
            fill(x0, oy + 9, x0 + 4, oy + 10, GREY, 0.02)
            for k in range(4):                               # X putih di pembalut
                put(x0 + k, oy + 11 + k, WHITE, 0.0)
                put(x0 + 3 - k, oy + 11 + k, WHITE, 0.0)
            put(x0 + 1, oy + 6, BLACK, 0.0); put(x0 + 2, oy + 6, BLACK, 0.0)     # motif kecil
            put(x0 + 1, oy + 7, BLACK, 0.0); put(x0 + 2, oy + 5, BLACK, 0.0)
        fill(ox + 4, oy + 16 - 1, ox + 8, oy + 16, BLACK)
    # ---- kaki: kanan (0,16), kiri (16,48): hakama hitam berlipit + sepatu hitam
    for (ox, oy) in [(0, 16), (16, 48)]:
        fill(ox, oy + 4, ox + 16, oy + 13, BLACK, 0.03)
        for f in range(4):
            x0 = ox + f * 4
            for y in range(oy + 4, oy + 13):
                put(x0 + 1, y, PLEAT, 0.02)
            put(x0 + 2, oy + 8, hexc("4a4a56"), 0.0); put(x0 + 1, oy + 10, hexc("4a4a56"), 0.0)
        fill(ox, oy + 13, ox + 16, oy + 16, hexc("0e0e12"), 0.02)
    # ---- rambut kepala: putih keperakan bergaris abu (garis vertikal seperti helai rambut)
    for y in range(0, 16):
        for x in range(0, 64):
            if ALPHA[y, x] > 0.1 and not (skin_like[y, x]) and (o[y, x].mean() > 0.55):
                s = 0.93 + 0.07 * np.sin(x * 1.7 + y * 0.35) + (rng.rand() - 0.5) * 0.05
                o[y, x] = np.clip(np.array([0.93, 0.95, 0.99]) * s, 0, 1)


make("hakuya", hair_grad=(hexc("b6c0d4"), hexc("e8edf7"), hexc("ffffff"), 0.3), vest="#1c1c24", shirt="#f3f5fa", pants="#24242c", shoes="#14141a", tie="#9fb4d6", paint=paint_hakuya)  # samurai ★6 (haori putih, hakama hitam)
# Karakter baru (referensi gambar): Vael ★5, Lucien ★5, Wenyu ★4, Kuroha ★4
make("vael", hair_grad=(hexc("9fb8d8"), hexc("e6f0ff"), hexc("ffffff"), 0.3), vest="#e9eff9", shirt="#161a26", pants="#161a26", shoes="#1c2230", tie="#37d8ff", detail=("lattice","#9fc4ff","#cfe4ff"))      # hoodie putih, celana hitam, tali cyan
make("lucien", hair="#16204a", vest="#1a2244", shirt="#262c40", pants="#12162a", shoes="#0e1020", tie="#d9b25a", detail=("pin","#8c9ad0","#c9a85c"))                                                  # mantel hitam list emas
make("wenyu", hair="#202028", vest="#c4c0d6", shirt="#ecebf4", pants="#8a88a0", shoes="#3b3e4a", tie="#8fd8b8", detail=("cloud","#ffffff","#8fd8b8"))                                                   # hanfu abu-putih ala tinta
make("kuroha", hair="#f1f4fa", vest="#14141b", shirt="#20202a", pants="#101016", shoes="#101014", tie="#cfd8e8", detail=("lattice","#8aa0c8","#cfd8e8"))                                                  # mantel hitam list putih, rambut putih pendek
make("aion", hair_grad=(hexc("b8c2d6"), hexc("eef1f8"), hexc("ffffff"), 0.3), vest="#f2f3f8", shirt="#e8ebf2", pants="#17171e", shoes="#121218", tie="#2bb8aa")      # pengendali waktu: mantel putih, celana balon hitam, simpul teal
def paint_kyomu(o):
    """Kyomu (虚): bertubuh ramping. Atasan hitam tanpa lengan + masker/kerah hitam menutup separuh wajah bawah, lengan telanjang dengan
    pembalut & sarung tangan hitam, tato retakan hitam bermata ungu di lengan kiri, sabuk hitam bergem ungu, celana hitam bercorak
    camo/api ungu-lavender, sepatu hitam-putih bergem ungu, anting salib hitam. Hanya piksel buram yang dicat."""
    rng = np.random.RandomState(11)
    BLACK = hexc("0e0e13"); INK = hexc("17171f"); PUR = hexc("7b3be0"); DPUR = hexc("3a1a78"); LAV = hexc("c9bff2"); WHITE = hexc("f1eefc")
    SILVER = hexc("b9bfd0"); GEM = hexc("a56bff")
    SKINC = np.median(RGB[skin_like & HEAD & (yy >= 8)], axis=0) if (skin_like & HEAD & (yy >= 8)).any() else hexc("f0c9a8")

    def put(x, y, c, jitter=0.04):
        if 0 <= x < 64 and 0 <= y < 64 and ALPHA[y, x] > 0.1:
            o[y, x] = np.clip(c * (1.0 - jitter + rng.rand() * jitter * 2), 0, 1)

    def fill(x0, y0, x1, y1, c, jitter=0.04):
        for y in range(y0, y1):
            for x in range(x0, x1):
                put(x, y, c, jitter)

    # ---- kepala: masker hitam di separuh bawah wajah (depan baris 13-15, pipi samping dekat depan), anting salib di sisi kiri
    # (topeng hitam di baris 13-15 dihapus: tepat di bawah mata -> wajah tampak hitam)
    for (dx, dy) in [(0, 0), (-1, 1), (0, 1), (1, 1), (0, 2)]:
        put(20 + dx, 10 + dy, BLACK, 0.0)
    # ---- badan (16,16): kanan 16-20, depan 20-28, kiri 28-32, belakang 32-40; baris 20-32
    fill(16, 20, 40, 32, BLACK, 0.035)
    fill(16, 20, 40, 22, INK, 0.03)                                  # kerah tinggi
    fill(16, 29, 40, 32, INK, 0.02)                                  # sabuk
    for x in range(16, 40):
        put(x, 29, DPUR, 0.0)                                        # garis ungu tipis di tepi atas sabuk
    put(23, 30, GEM, 0.0); put(24, 30, GEM, 0.0); put(23, 31, PUR, 0.0); put(24, 31, PUR, 0.0)   # gem wajik di gesper
    for y in range(24, 29):                                          # kerutan kain halus
        put(18, y, INK, 0.0); put(30, y, INK, 0.0)
    # ---- lengan: kanan (40,16), kiri (32,48); 4 muka selebar 4, baris +4..+16
    for (ox, oy) in [(40, 16), (32, 48)]:
        for f in range(4):
            x0 = ox + f * 4
            fill(x0, oy + 4, x0 + 4, oy + 12, SKINC, 0.025)         # lengan telanjang
            fill(x0, oy + 12, x0 + 4, oy + 16, BLACK, 0.03)         # pembalut + sarung tangan hitam
            fill(x0, oy + 11, x0 + 4, oy + 12, DPUR, 0.0)
            put(x0 + 1, oy + 13, PUR, 0.0)
    # tato retakan + mata ungu di lengan kiri (32,48): muka dalam 32-35, depan 36-39, luar 40-43, belakang 44-47
    web = [(36, 53), (37, 54), (39, 53), (38, 54), (36, 57), (37, 56), (39, 57), (38, 56), (37, 58), (38, 59), (36, 60), (39, 60),
           (40, 52), (41, 53), (42, 54), (43, 55), (40, 56), (41, 57), (42, 58), (43, 59), (41, 55), (42, 56), (40, 58), (41, 59),
           (42, 60), (43, 61), (40, 60), (41, 61), (44, 56), (45, 57), (44, 58), (45, 59)]
    for (wx, wy) in web:
        put(wx, wy, BLACK, 0.0)
    for (dx, dy, c) in [(0, 0, PUR), (1, 0, PUR), (0, 1, PUR), (1, 1, DPUR)]:
        put(37 + dx, 55 + dy, c, 0.0)
    put(37, 55, hexc("e9d9ff"), 0.0)                                 # kilau mata
    put(38, 56, BLACK, 0.0)                                          # pupil
    # ---- kaki: kanan (0,16), kiri (16,48): celana hitam longgar, api ungu-lavender menjalar dari ujung bawah, camo gelap halus, tambalan lavender
    def noise(x, y, k):
        return (np.sin(x * 0.85 + k) + np.sin(y * 0.55 - x * 0.3 + k * 2.0) + np.sin((x + y) * 0.42 + k * 3.0) + 0.6 * np.sin(x * 1.7 - y * 1.1)) / 3.6
    for (ox, oy) in [(0, 16), (16, 48)]:
        ph = 0.0 if ox == 0 else 1.7
        top, bot = oy + 4, oy + 11                                   # baris celana: top..bot (bot = baris terbawah celana)
        for f in range(4):
            x0 = ox + f * 4
            for y in range(top, bot + 1):
                for x in range(x0, x0 + 4):
                    n = noise(x, y, 1.3 + ph)
                    c = BLACK
                    if n > 0.3:
                        c = DPUR                                       # camo gelap halus
                    if n > 0.62:
                        c = PUR
                    put(x, y, c, 0.05)
            for x in range(x0, x0 + 4):                              # lidah api dari ujung celana naik ke atas
                h = 3 + int(round(2.2 * (np.sin(x * 1.9 + ph) + 1.0) / 1.0 * 0.5 + 1.4 * np.sin(x * 0.7 + ph * 2)))
                h = max(2, min(7, h))
                for d in range(h):
                    y = bot - d
                    c = PUR if d < h - 1 else DPUR
                    if d < h - 2 and (x + d) % 3 != 0:
                        c = GEM if d < 2 else PUR
                    if d == 0:
                        c = LAV
                    put(x, y, c, 0.04)
                if h >= 4:
                    put(x, bot - h + 1, DPUR, 0.0)                    # ujung api gelap = lidah runcing
            for (px, py) in [(x0 + 1, top + 1), (x0 + 2, top + 1), (x0 + 1, top + 2)]:
                if f in (1, 3):
                    put(px, py, LAV, 0.03)                             # tambalan lavender di paha
            fill(x0, oy + 12, x0 + 4, oy + 15, BLACK, 0.03)         # sepatu hitam
            fill(x0, oy + 15, x0 + 4, oy + 16, WHITE, 0.02)         # sol putih
            put(x0, oy + 14, LAV, 0.0); put(x0 + 3, oy + 14, LAV, 0.0)
        put(ox + 5, oy + 13, GEM, 0.0); put(ox + 6, oy + 13, GEM, 0.0); put(ox + 5, oy + 12, PUR, 0.0); put(ox + 6, oy + 12, PUR, 0.0)   # gem sepatu


make("kyomu", hair_grad=(hexc("b0a6dc"), hexc("e6e2f8"), hexc("ffffff"), 0.25), vest="#0e0e13", pants="#0e0e13", shoes="#0e0e13", paint=paint_kyomu)   # ★5 petarung pedang ganda bayangan ungu

make("kiriel", hair_grad=(hexc("1a2255"), hexc("5a78e8"), hexc("ffe65a"), 0.0), vest="#f1f3ff", shirt="#20285a", pants="#1a1f3a", shoes="#e8c84a", tie="#ffe34a", detail=("stars", "#ffe66a", "#2a3a8a"))   # ★6 petir ramping: jaket putih-biru, rambut navy berujung kuning


def _patchy(o, mask, base, dark, accent, seed, density=0.34, glow_every=0):
    """Kain bermotif tambalan blok piksel (gaya Minecraft): warna dasar + bercak gelap kotak 2x2 + garis aksen menyala."""
    rng = np.random.RandomState(seed)
    for y in range(H):
        for x in range(W):
            if not mask[y, x]:
                continue
            blk = ((x // 2) * 73856093 ^ (y // 2) * 19349663 ^ seed * 83492791) % 1000 / 1000.0
            c = dark if blk < density else base
            c = c * (0.93 + rng.rand() * 0.1)
            if glow_every and (y % glow_every == 0) and blk > 0.8:
                c = accent
            o[y, x] = np.clip(c, 0, 1)


def paint_midori(o):
    """Midori (One For All) ★6: mantel putih bertambal hitam, baju & celana hitam, garis energi biru menyala, sepatu putih-hitam."""
    WHITE = hexc("f1f1ff"); DARK = hexc("12121c"); BLUE = hexc("3aa6ff"); LAV = hexc("c4c4ee")
    coat = (TORSO | ARMS) & opaque & ~skin_like
    _patchy(o, coat, WHITE, DARK, BLUE, 3, 0.30, 7)
    _patchy(o, LEGS & ~SHOES & opaque, DARK, hexc("2a2a3a"), BLUE, 5, 0.22)
    _patchy(o, LEGS & SHOES & opaque, WHITE, DARK, BLUE, 9, 0.35)
    for y in range(H):                                   # garis energi biru di sisi lengan & sabuk dada
        for x in range(W):
            if ARMS[y, x] and opaque[y, x] and not skin_like[y, x] and (x + y) % 11 == 0:
                o[y, x] = BLUE
    for x in range(20, 28):                              # baju dalam hitam di dada depan
        for y in range(20, 32):
            if opaque[y, x] and not skin_like[y, x] and 22 <= x <= 25:
                o[y, x] = DARK
    for y in (30, 31):                                   # sabuk
        for x in range(20, 40):
            if opaque[y, x] and not skin_like[y, x]:
                o[y, x] = DARK if x % 4 else BLUE


def paint_zyrax(o):
    """Zyrax ★6 (bom): jubah hitam dengan retakan merah-cyan neon, kaos putih di dalam, celana hitam bergaris ungu."""
    BLACK = hexc("0c0c14"); INK = hexc("191926"); RED = hexc("e8214e"); CYAN = hexc("3fd4ff"); PUR = hexc("6a34e0"); WHITE = hexc("f2f2fa")
    coat = (TORSO | ARMS) & opaque & ~skin_like
    _patchy(o, coat, BLACK, INK, RED, 11, 0.38, 6)
    _patchy(o, LEGS & ~SHOES & opaque, BLACK, INK, PUR, 13, 0.3)
    _patchy(o, LEGS & SHOES & opaque, hexc("14141e"), WHITE, CYAN, 17, 0.3)
    for y in range(H):                                   # retakan neon merah/cyan di jubah
        for x in range(W):
            if (TORSO | ARMS | LEGS)[y, x] and opaque[y, x] and not skin_like[y, x]:
                h = (x * 31 + y * 17) % 37
                if h == 0:
                    o[y, x] = RED
                elif h == 1 and y % 2:
                    o[y, x] = CYAN
                elif h == 2 and x % 3 == 0:
                    o[y, x] = PUR
    for x in range(22, 26):                              # kaos putih di dada depan
        for y in range(20, 30):
            if opaque[y, x] and not skin_like[y, x]:
                o[y, x] = WHITE * (0.9 + 0.1 * ((x + y) % 2))
    for y in (30, 31):
        for x in range(20, 40):
            if opaque[y, x] and not skin_like[y, x]:
                o[y, x] = BLACK if x % 5 else CYAN


make("midori", hair_grad=(hexc("06241d"), hexc("0f4a3a"), hexc("2a8a6a"), 0.2), vest="#f1f1ff", shirt="#12121c", pants="#12121c", shoes="#f1f1ff", paint=paint_midori)   # ★6 kecepatan: One For All
make("zyrax", hair_grad=(hexc("b8b8e0"), hexc("e8e8fa"), hexc("ffffff"), 0.15), vest="#0c0c14", shirt="#0c0c14", pants="#0c0c14", shoes="#14141e", paint=paint_zyrax)   # ★6 bom: bayangan neon

make("sera", hair="#9ad85a", vest="#3f8f4a", shirt="#f4ecd0", pants="#5a4a2c", shoes="#6b5632", tie="#e8563a", detail=("leaf","#d8f09a","#2c6a34"))

# ---------------------------------------------------------------- NPC
make("orwen", hair="#e8ecf5", vest="#a82a3a", shirt="#f2e8d0", pants="#3a2a4a", shoes="#2a2030", tie="#f2c14e")   # Guild Master
make("mira", hair="#c06a3a", vest="#2a9a90", shirt="#fff0d8", pants="#6a4a36", shoes="#f0e0c0", tie="#ffd45e")    # pedagang
make("tobias", hair="#3a2418", vest="#7a4a2a", shirt="#8e8e96", pants="#3a3a42", shoes="#2a2a30", tie="#5a5a62")  # pandai besi
make("elio", hair="#f4f4f4", vest="#2f6a4a", shirt="#f6efc0", pants="#2a4a3a", shoes="#3a2e24", tie="#f2c14e")    # cendekiawan
make("rowan", hair="#404858", vest="#4a6a9a", shirt="#b8c6dc", pants="#26303f", shoes="#202630", tie="#f2c14e")   # penjaga gerbang
make("pip", hair="#f0b24a", vest="#f2d24a", shirt="#ffffff", pants="#3f6ab8", shoes="#8a5a38", tie="#e8563a")     # anak kota
make("selin", hair="#2a1a4a", vest="#b03a9a", shirt="#d8c0f0", pants="#2a1a46", shoes="#2a1a3a", tie="#7fe0ff")   # peramal
make("kael", hair="#1c1c24", vest="#c8443a", shirt="#f4f4f4", pants="#34343c", shoes="#202024", tie="#f2c14e")    # instruktur
make("town1", hair="#8a5a3a", vest="#6a8ac8", shirt="#f4ecd8", pants="#5a4a3a", shoes="#4a3a2a", tie="#d84a4a")
make("town2", hair="#d8c08a", vest="#c88a8a", shirt="#ffffff", pants="#4a5a7a", shoes="#3a3030", tie="#ffd45e")


# ---------------------------------------------------------------- musuh humanoid (Bab 4-5)
make("e_cultist", hair="#1a1018", vest="#241018", shirt="#3a1620", pants="#140a10", shoes="#0e0709", tie="#ff3040")        # pengikut berkerudung
make("e_mage", hair="#2a1848", vest="#3a2064", shirt="#241540", pants="#160e2a", shoes="#100a1e", tie="#c070ff")           # penyihir bayangan
make("e_knight", hair="#555560", vest="#4a4e5c", shirt="#282a34", pants="#22242c", shoes="#16171c", tie="#ff3040")        # ksatria rantai
make("e_ronin", hair="#e0e0ea", vest="#2a1a16", shirt="#8a2018", pants="#1a1210", shoes="#120c0a", tie="#ff5030")          # ronin bayangan
make("e_uranos", hair="#e8e0f4", vest="#2a1648", shirt="#5a2a8a", pants="#1a0e30", shoes="#120a22", tie="#ffd45e")         # Uranos, penyihir berkerudung
make("e_chainking", hair="#c8c8d0", vest="#3a0c12", shirt="#18181e", pants="#120a0e", shoes="#0c0708", tie="#ff2030")      # Raja Rantai Merah


# ---------------------------------------------------------------- musuh bab Desa Fajar
make("e_arunika", hair="#dff3c4", vest="#2f6a45", shirt="#6aa65a", pants="#264a34", shoes="#1b3024", tie="#f6e27a")         # Arunika, Penjaga Hutan Fajar
