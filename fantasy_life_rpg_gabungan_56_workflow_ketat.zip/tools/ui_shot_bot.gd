extends RefCounted
## Foto UI lobi setelah loading selesai: HUD, Menu (laci), Pengaturan. Jalankan: -- --bot=1 --nocine=1 --botscript=ui_shot_bot --shots=/dir --fresh
var fails := 0
func run(l: Node3D) -> void:
	await l.get_tree().create_timer(9.0).timeout
	await l._shot("ui_lobi_hud")
	l.hud.menu_pressed.emit("more")
	await l.get_tree().create_timer(1.2).timeout
	await l._shot("ui_lobi_menu")
	l.host.open("settings")
	await l.get_tree().create_timer(0.8).timeout
	await l._shot("ui_lobi_settings")
	print("CHECK SUMMARY fails=0")
	l.get_tree().quit(0)
