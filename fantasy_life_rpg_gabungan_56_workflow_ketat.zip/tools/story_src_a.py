"""Naskah bagian A: Prolog, Bab 1 (Aurelia, padang, hutan, gua, Golem), selingan Desa Fajar. Tema besar seri: INGATAN & JANJI."""

def ins(scenes, sid, idx, lines):
    """Sisipkan baris ke adegan yang sudah ada (tanpa mengubah sisanya)."""
    sc = scenes[sid]
    new = [{"s": a, "t": b} for a, b in lines]
    sc["lines"][idx:idx] = new
    sc["_raw"] = [(l["s"], l["t"]) for l in sc["lines"]]


def build(S, C, B, scenes):
    # ------------------------------------------------------------------ PROLOG
    S("prolog", [
        ("Narator", "Eldoria, malam ketiga bulan Tanam. Kota Aurelia tak pernah gelap, sebab di bawah air mancur alun-alunnya tertanam Kristal Bintang yang bersinar siang dan malam."),
        ("Narator", "Kristal itu menahan Kehampaan, kabut hitam yang tidak membakar dan tidak menghancurkan. Ia hanya menghapus. Dan sejak tiga malam lalu, cahayanya mulai berkedip."),
        ("Narator", "Di tepi air mancur, seorang magang Serikat Bintang Fajar menghabiskan giliran jaganya. Namanya Ren. Ia yatim sejak bayi, dan tak seorang pun tahu dari mana tanda bintang di tangannya berasal."),
        ("Ren", "Berkedip lagi. Tiga malam berturut-turut, dan sepertinya cuma aku yang memperhatikan.", {"anim": "sigh"}),
        ("Ren", "Tandaku hangat tiap kali cahayanya meredup. Dan di sela dengung kristal itu ada nada samar, seperti lagu pengantar tidur. Aku selalu mengira itu mimpi."),
        ("Master Orwen", "Sudah kuduga kau masih di sini. Jaga malammu selesai sejak lonceng ketiga, Ren."),
        ("Ren", "Kristalnya berkedip, Guru. Guru juga melihatnya, kan?"),
        ("Master Orwen", "Aku melihatnya. Dan laporan dari tambang membuatku tak bisa tidur. Tiga rombongan penambang tidak pulang dari Gua Kristal. Yang pulang selamat tidak mengingat nama istri mereka sendiri."),
        ("Lyra", "Guru! Lendir hitam dari gua sudah kuperiksa. Kehampaan tidak merusak, ia menghapus: nama, wajah, kenangan. Segel di bawah kota dilemahkan dari dalam, dan pelakunya sengaja."),
        ("Brann", "Rombongan ketiga dipandu ayahku, Doran. Dia hafal tiap lorong gua itu. Kalau ada yang mau mencari, aku jalan duluan. Perisaiku sudah siap."),
        ("Master Orwen", "Ini bukan perintah. Serikat menerima kontrak penyelidikan Gua Kristal. Lyra dan Brann sudah mengajukan diri. Kau boleh menolak, Ren."),
        ("Ren", "Aku tidak tahu siapa orang tuaku, Guru. Aku tahu rasanya tidak punya ingatan tentang asal sendiri. Kalau ada yang sedang kehilangan itu, aku tak mau diam."),
        ("Master Orwen", "Tanda itu sudah ada di tanganmu sejak kutemukan kau di depan kristal ini, malam Bintang Jatuh enam belas tahun lalu. Aku selalu takut suatu hari ia memanggilmu pergi."),
        ("Ren", "Kalau ia memanggil, aku ingin tahu siapa yang memanggil."),
        ("Master Orwen", "Kalau begitu siapkan bekalmu di toko dan bengkel, lalu masuki Portal Petualangan di sisi timur alun-alun. Mulailah dari Padang Gerbang."),
        ("Lyra", "Satu hal, Ren. Setiap orang yang kita tolong, kucatat namanya di buku ini. Kehampaan boleh menghapus kepala mereka, tapi tidak halaman bukuku."),
        ("Ren", "Aku tidak tahu siapa diriku sebenarnya. Tapi kali ini aku akan mencari tahu, dan aku akan mengingat setiap orang di sepanjang jalan."),
    ], title="Prolog: Cahaya yang Redup", chapter="Bab 1: Fajar di Aurelia", where="lobby", cine="prolog")
    C("prolog", "plaza", ["ren", "orwen", "lyra", "brann"], title="Anak Bintang", chapter="Prolog · Bab 1: Fajar di Aurelia",
      fx={4: ["mark", "flicker"], 7: ["shake"]}, anim={3: {"ren": "sigh"}})

    # ------------------------------------------------------------------ BAB 1
    S("s1_1_intro", [
        ("Narator", "Padang di luar gerbang biasanya ramai pedagang. Pagi ini gerobak-gerobak ditinggal begitu saja, dagangannya masih tertata, dan lendir hitam merayap dari utara."),
        ("Lyra", "Dagangannya utuh, pedagangnya tidak ada. Mereka tidak dirampok, Ren. Mereka dilupakan lebih dulu."),
        ("Ren", "Tandaku makin hangat ke arah utara. Kita bersihkan padang ini dulu, supaya jalan ke gua aman."),
    ], title="Padang di Luar Gerbang")
    S("s1_1_outro", [
        ("Narator", "Slime terakhir mencair. Di balik gerobak yang terguling, seorang pedagang tua duduk memeluk karung kosong."),
        ("Pak Salman", "Aku sedang menunggu seseorang... tapi siapa ya? Namaku juga tadi masih ada."),
        ("Lyra", "Pak Salman, pedagang kain. Tertulis di papan gerobakmu, Pak. Kami antar ke kota."),
        ("Brann", "Dia selamat, tapi separuh dirinya tertinggal di padang ini."),
        ("Ren", "Kalau lendir sekecil itu bisa menghapus orang sebanyak ini, aku tak mau membayangkan apa yang ada di gua."),
    ], title="Yang Tertinggal di Padang", stage="s1_1", when="outro")

    S("f_plains_intro", [
        ("Narator", "Di luar jalan setapak, Padang Angin membentang tanpa batas. Rumputnya berdesir seakan membisikkan sesuatu, dan jejak lendir hitam bercabang ke segala arah."),
        ("Lyra", "Wilayah bebas, tanpa gelombang. Bersihkan jejaknya, buka peti-petinya, dan cari tanda rombongan yang lewat."),
        ("Brann", "Jangan melamun, Ren. Rumput setinggi ini bisa menyembunyikan apa saja."),
    ], title="Padang Angin")
    S("f_plains_outro", [
        ("Narator", "Padang Angin kembali tenang. Semua jejak lendir bertemu di satu arah: hutan di timur. Di jejak terakhir tersangkut sebuah papan nama kayu: Rombongan Tambang III."),
        ("Brann", "Itu tulisan ayahku. Doran, pemandu. Dia sempat lewat sini."),
        ("Lyra", "Papan ini dibuang dengan sengaja. Seseorang meninggalkan jejak supaya kita menyusulnya."),
        ("Ren", "Kalau begitu kita menyusul."),
    ], title="Jejak yang Bertemu")

    S("s1_2_intro", [
        ("Narator", "Hutan kehilangan suaranya. Tidak ada burung, hanya jamur berbintik hitam yang mengembang dan mengempis seperti bernapas."),
        ("Lyra", "Kehampaan merambat lewat spora. Jangan hirup dalam-dalam, dan jangan biarkan mereka menembak dari jarak dekat."),
        ("Brann", "Dulu ini tempatku bermain. Sekarang bahkan angin pun diam."),
        ("Ren", "Dengar... spora-spora itu seperti berbisik. Mereka menyebut nama-nama."),
        ("Lyra", "Aku mendengarnya juga. Mereka mengulang nama orang yang sudah mereka telan. Catat semuanya, Ren, jangan sampai ada yang terlewat."),
    ], title="Hutan yang Berbisik")
    S("s1_2_outro", [
        ("Narator", "Jamur terakhir layu. Di antara spora yang menguap, satu bisikan terakhir terdengar jelas: \"Brann.\""),
        ("Brann", "Itu suara ayahku. Dia memanggilku, bukan melupakanku."),
        ("Lyra", "Berarti nama itu belum terhapus, hanya tersembunyi. Ingatan yang dibagikan meninggalkan jejak lebih dalam daripada yang disimpan sendirian."),
        ("Ren", "Ke gua. Sekarang."),
    ], title="Nama yang Dipanggil", stage="s1_2", when="outro")

    S("s1_3_intro", [
        ("Narator", "Kristal biru di dinding meneteskan cairan hitam, pelan, seperti air mata. Kelelawar bergelantungan di langit-langit tanpa suara."),
        ("Brann", "Ayahku bilang kristal di sini bernyanyi kalau malam. Dulu aku tak percaya."),
        ("Ren", "Aku mendengarnya. Nadanya sama dengan yang kudengar dari kristal di alun-alun."),
        ("Lyra", "Naik tiga, turun dua, berhenti sebelum selesai. Seperti lagu yang kehabisan napas. Kucatat."),
    ], title="Kristal yang Menangis")
    S("s1_3_outro", [
        ("Narator", "Kelelawar terakhir jatuh. Di lantai gua, sebuah lentera tambang masih hangat, apinya kecil tapi hidup."),
        ("Brann", "Lentera ayahku. Dia baru lewat sini. Mereka masih hidup, Ren!"),
        ("Ren", "Berarti kita belum terlambat. Ayo."),
    ], title="Lentera yang Masih Hangat", stage="s1_3", when="outro")

    S("s1_4_intro", [
        ("Narator", "Cahaya redup dari langit jatuh ke padang. Slime di sana berkilau aneh, seperti menelan pecahan kristal."),
        ("Lyra", "Pecahan Kristal Bintang yang retak. Kalau Kehampaan memakainya, dia bisa menghapus jauh lebih cepat."),
        ("Ren", "Kita kumpulkan sebelum itu terjadi."),
    ], title="Padang Bintang Jatuh")
    S("s1_4_outro", [
        ("Narator", "Ren memungut satu pecahan bercahaya. Begitu menyentuh telapaknya, tandanya menyala, dan sekilas ia melihat: seorang perempuan bernyanyi di atas kota kecil, tangannya bersinar seperti tangan Ren."),
        ("Ren", "Aku melihat seseorang bernyanyi. Aku tidak mengenalnya, tapi aku tahu lagu yang ia nyanyikan."),
        ("Lyra", "Pecahan menyimpan ingatan orang terakhir yang menyentuhnya. Kalau itu bukan ingatanmu, berarti ingatan siapa?"),
        ("Ren", "Aku belum tahu. Tapi aku akan mencari tahu."),
    ], title="Ingatan yang Bukan Milikku", stage="s1_4", when="outro")

    S("s1_boss_intro", [
        ("Narator", "Di inti gua, Golem Kristal berdiri diam. Serpihan hitam tertancap di dadanya dan berdenyut. Tubuh batunya penuh retakan, tapi tak satu pun menembus dada, seolah ia melindungi sesuatu di sana."),
        ("Brann", "Penjaga gua. Dulu ia menjaga para penambang. Sekarang matanya kosong."),
        ("Lyra", "Serpihan Hampa menguasainya. Lepaskan serpihan itu dan ia akan kembali tenang."),
        ("Golem Kristal", "...Lindungi... jangan... biarkan... masuk..."),
        ("Ren", "Maafkan kami, Penjaga. Kami akan membebaskanmu."),
    ], title="Penjaga yang Tercemar")
    S("s1_boss_outro", [
        ("Narator", "Golem itu runtuh pelan. Serpihan hitam di dadanya lepas dan jatuh ke tangan Ren. Dadanya terbuka seperti kelopak, dan di dalam kristal bening, belasan penambang tertidur dalam cahaya biru."),
        ("Brann", "Mereka semua di sini. Ia menyembunyikan mereka dari Kehampaan."),
        ("Lyra", "Penjaga itu tidak pernah menyerang siapa pun. Ia mengurung mereka supaya aman. Dan kita menyerangnya."),
        ("Golem Kristal", "...Terima kasih... sudah... pulang."),
        ("Doran", "Hmm? Nak... kau mirip seseorang yang selalu kuingat, tapi namanya... pergi."),
        ("Brann", "Namaku Brann, Yah. Aku anakmu. Kalau perlu seribu kali, seribu kali kuperkenalkan diri.", {"anim": "sigh"}),
        ("Doran", "Brann. Nama yang bagus. Ayo, ceritakan dari awal."),
        ("Ren", "Serpihan ini dingin sekali. Dan berbisik: 'Altar... di bawah... nyanyikan...' Suaranya seperti perempuan."),
        ("Lyra", "Serpihan itu membawa ingatan yang jauh lebih tua dari gua ini. Kita perlu orang yang tahu sejarah para Penjaga."),
    ], title="Serpihan yang Berbisik", cine="s1_boss_outro")
    C("s1_boss_outro", "cave", ["ren", "lyra", "brann"], title="Serpihan yang Berbisik", chapter="Bab 1",
      fx={0: ["flare"], 7: ["shard"]}, anim={5: {"brann": "sigh"}})

    # ------------------------------------------------------------------ Aurelia -> Desa Fajar
    S("a_to_village", [
        ("Narator", "Aurelia menyambut para penambang pulang. Doran dikelilingi tetangga yang menangis, dan Brann berdiri di sampingnya, memperkenalkan diri berulang-ulang dengan sabar."),
        ("Master Orwen", "Serpihan itu bicara soal altar dan para Penjaga. Pengetahuan seperti itu tak ada di perpustakaan Serikat, tapi seseorang masih menyimpannya: Mbah Kerto di Desa Fajar."),
        ("Master Orwen", "Lagi pula Pak Wiryo mengirim kabar. Ada kabut aneh di ladang mereka. Kalau Kehampaan sudah sampai ke sana, kita harus tahu."),
        ("Ren", "Kami berangkat. Lewat jalan raya selatan?"),
        ("Master Orwen", "Ya, sehari berjalan. Bawa bekal, dan jangan melupakan Desa itu. Mereka pernah melupakan sesuatu yang penting."),
        ("Lyra", "Aku bawa bukuku."),
        ("Brann", "Aku bawa perisai. Ayahku... sedang diajari Ibu cara makan sup lagi. Dia aman."),
    ], title="Kabar dari Desa Fajar", where="lobby", after="s1_boss_outro")

    # ------------------------------------------------------------------ Selingan: Desa Fajar (naskah lama dipertahankan, disisipi benang cerita)
    ins(scenes, "v_prolog", 2, [
        ("Narator", "Ren, Lyra, dan Brann tiba setelah matahari condong. Di gerbang desa, Master Orwen titip pesan lewat burung merpati: 'Tanyakan pada Mbah Kerto tentang tiga Penjaga.'"),
    ])
    ins(scenes, "v1_2_intro", 4, [
        ("Narator", "Dari kejauhan terdengar seruling. Nadanya naik tiga, turun dua, lalu berhenti, persis nada yang Ren kenal dari kristal."),
        ("Ren", "...naik tiga, turun dua. (tanpa sadar bersenandung)"),
        ("Wenyu", "Berhenti di situ. Dari mana kau tahu lagu itu? Hanya keluargaku yang mengenalnya, dan lagunya tak pernah selesai."),
        ("Ren", "Aku mendengarnya dari kristal. Di gua, di alun-alun, di mana-mana."),
        ("Wenyu", "Namaku Wenyu. Kalau lagu itu memanggilmu, izinkan aku ikut. Sudah lama aku mencari ujungnya."),
    ])
    ins(scenes, "v1_3_intro", 3, [
        ("Narator", "Sebatang anak panah menancap tepat di depan sepatu Brann."),
        ("Sera", "Jangan injak lumut itu. Itu sesajen terakhir yang masih dirawat seseorang."),
        ("Brann", "Kau siapa?"),
        ("Sera", "Sera, pemburu dari hutan Aurelia. Kabut ini mengacaukan arah, jadi aku memetakan jalannya. Ikuti panahku, jangan ikuti kakimu."),
    ])
    ins(scenes, "v1_boss_intro", 6, [
        ("Wenyu", "Aku akan memainkan lagunya sepanjang pertarungan. Dia tidak butuh lebih banyak pedang. Dia butuh didengar."),
    ])
    ins(scenes, "v1_boss_outro", 5, [
        ("Wenyu", "Dia berhenti bergerak saat lagunya sampai. Jadi lagu ini bukan sekadar lagu."),
        ("Arunika", "Lagu itu... dulu Sang Penyanyi menyanyikannya di atas hutan ini ketika aku masih tunas. Kau membawa sisa nadanya, anak bintang."),
        ("Arunika", "Carilah Penjaga yang mengikat. Dialah yang menyimpan ujung lagu itu, dan tangisannya yang terakhir."),
    ])
    S("v_hub", [
        ("Narator", "Pagi setelah Arunika kembali tenang, warga Desa Fajar berbaris ke tepi hutan membawa Sedekah Bumi: nasi tumpeng, jagung bakar, dan bunga dari ladang yang baru bertunas."),
        ("Pak Wiryo", "Kami hampir lupa cara berterima kasih. Tidak ada kabut yang bisa mencuri hal itu lagi, Nak. Kami menuliskannya di papan balai desa."),
        ("Mbah Kerto", "Duduklah, anak bintang. Kau bertanya soal tiga Penjaga. Kata orang tua dulu: ada yang menanggung, ada yang mengikat, ada yang menyanyi."),
        ("Mbah Kerto", "Yang menanggung memikul Kehampaan dalam tubuhnya. Yang mengikat menahan dunia dengan rantai. Yang menyanyi... lagunya dibawa angin, dan dilupakan orang."),
        ("Wenyu", "Dua bait pertama sudah kuingat. Bait ketiga tidak pernah diajarkan nenekku."),
        ("Ren", "Kalau begitu kita carikan. Terima kasih, Mbah. Aku akan kembali ke gua, ke altar, ke mana pun jejaknya."),
    ], title="Persimpangan Fajar", where="lobby")

    # ------------------------------------------------------------------ Dialog tengah pertarungan: Bab 1 & Desa
    B("s1_1", [("w0", "Lyra", "Slime biasa, tapi jangan remehkan lendirnya. Jaga jarak."), ("w1", "Brann", "Mereka makin banyak. Ren, biar aku di depan!"), ("low", "Lyra", "HP-mu menipis. Mundur dan minum ramuan!"), ("done", "Ren", "Padang aman. Tapi ini baru permulaan.")])
    B("s1_2", [("w0", "Brann", "Hutan ini dulu tempat bermainku. Sekarang tak kukenali."), ("w1", "Lyra", "Nama-nama itu... jangan dengarkan terlalu lama, nanti pusing."),
               ("zone", "Lyra", "Lingkaran cahaya itu segel kecil. Berdiri di dalamnya sampai penuh, aku tahan sisanya!"), ("done", "Ren", "Segelnya hidup. Kita masih punya harapan."), ("low", "Brann", "Jangan nekat, Ren!")])
    B("s1_3", [("w0", "Ren", "Lagu itu lagi. Dari dalam kristal."), ("w1", "Lyra", "Kelelawar kristal menyerang lewat suara. Hati-hati!"), ("survive", "Brann", "Tahan sampai kristalnya berhenti menangis! Jangan mundur!"), ("done", "Brann", "Itu lentera ayahku. Kita sudah dekat."), ("low", "Lyra", "Ren, kau berdarah. Pulihkan dirimu!")])
    B("s1_4", [("w0", "Lyra", "Pecahan Kristal berkilau di tubuh mereka. Rebut sebelum Kehampaan memakainya."), ("w1", "Brann", "Yang bercahaya itu paling kuat. Incar dulu!"), ("hunt", "Ren", "Pemimpinnya bertanda merah. Tumbangkan dia dan semuanya buyar!"), ("done", "Ren", "Pecahan ini menyimpan sesuatu. Nanti kulihat."), ("low", "Lyra", "Pakai ramuan, Ren!")])
    B("s1_boss", [("boss", "Ren", "Penjaga... kami tak ingin melukaimu."), ("low", "Brann", "Tahan! Dia melindungi sesuatu di dadanya!")])
    B("v1_1", [("w0", "Pak Wiryo", "Hati-hati di ladang, Nak. Kabutnya tebal sekali!"), ("w1", "Lyra", "Mereka datang dari arah hutan."), ("low", "Brann", "Tahan, Ren!"), ("done", "Ren", "Ladang aman. Kita lanjut ke jalan setapak.")])
    B("v1_2", [("w0", "Wenyu", "Dengar? Lagunya menarik mereka. Hati-hati."), ("zone", "Wenyu", "Aku memainkan nada penyegel. Berdirilah di lingkaran sampai penuh!"), ("done", "Wenyu", "Nadanya sampai. Ia menjawab."), ("low", "Lyra", "Pulihkan dirimu!")])
    B("v1_3", [("w0", "Sera", "Ikuti panahku, dan jangan injak sesajen!"), ("survive", "Sera", "Bertahanlah sampai kabut menipis! Aku menutup jalur belakang!"), ("done", "Sera", "Selesai. Kau lumayan, anak bintang."), ("low", "Brann", "Ren, mundur sebentar!")])
    B("v1_4", [("w0", "Pak Wiryo", "Lumbung itu persediaan terakhir kami!"), ("hunt", "Lyra", "Pemimpinnya yang bermata hijau, itu yang mengendalikan sisanya."), ("done", "Brann", "Lumbung aman. Jagungnya terselamatkan."), ("low", "Lyra", "HP-mu!")])
    B("v1_boss", [("boss", "Wenyu", "Aku mulai memainkannya. Dengarkan, Arunika."), ("low", "Lyra", "Dia tidak berniat membunuh. Bertahan saja!")])
