extends RefCounted
## Bot: keutuhan Bab Desa "Kabut di Fajar": stage, rantai buka-kunci, cerita, quest, varian musuh, pemisahan dari alur Kastil.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func run(_l: Node3D) -> void:
	var ids := ["v1_1", "v1_2", "v1_3", "v1_4", "v1_boss"]
	check("village_order berisi 5 stage berurutan", Data.village_order == ids, str(Data.village_order))
	var prev := ""
	for id in ids:
		var sd: StageData = Data.stage(id)
		check("stage %s ada" % id, sd != null)
		if sd == null:
			continue
		check("%s unlock_after benar" % id, sd.unlock_after == prev, sd.unlock_after)
		check("%s bab desa" % id, sd.chapter == "Bab Desa: Kabut di Fajar")
		check("%s cerita intro" % id, Story.for_stage(id, "intro") != "")
		for wv in sd.waves:
			for k in wv:
				check("%s musuh '%s' dikenal" % [id, k], Enemy.KINDS.has(k))
		prev = id
	check("v1_boss bos Arunika", Data.stage("v1_boss").boss == "arunika")
	check("Arunika punya HP", Enemy.KINDS.has("arunika") and int(Enemy.KINDS["arunika"]["hp"]) > 1000)
	check("v1_boss cerita outro", Story.for_stage("v1_boss", "outro") != "")
	check("prolog desa ada", Story.get_scene("v_prolog").size() > 0)
	# terpisah dari alur Kastil
	for id in Data.stage_order:
		check("stage kastil %s bukan desa" % id, not Data.is_village_stage(id))
	for id in Data.adventure_order:
		check("adventure_order %s bukan desa" % id, not Data.is_village_stage(id))
	# quest
	var qs: Array = []
	for q in Data.quests.values():
		if q.region == "village":
			qs.append(q)
	check("8 quest desa", qs.size() == 8, str(qs.size()))
	for q in qs:
		if q.prerequisite != "":
			check("prasyarat %s valid" % q.id, Data.quests.has(q.prerequisite) and Data.quests[q.prerequisite].region == "village")
		if q.type == "clear_stage":
			check("target %s valid" % q.id, Data.stage(q.target) != null)
		for it in q.reward_items:
			check("hadiah item %s ada" % it, Data.items.has(str(it).split(":")[0]))
	# alur: dari desa, adventure_next = v1_1 bila belum ada yang selesai
	Flow.lobby_map = "village"
	pass
	check("adventure_next desa = v1_1", GameState.adventure_next() == "v1_1", GameState.adventure_next())
	Flow.lobby_map = "town"
	check("adventure_next kastil bukan desa", not Data.is_village_stage(GameState.adventure_next()), GameState.adventure_next())
	# varian musuh: spawn & tint
	for k in ["dew_slime", "crow", "wilt_mushroom", "mist_slime", "thorn_mushroom"]:
		check("varian %s berinduk" % k, Enemy.KINDS[k].has("base") and Enemy.KINDS.has(Enemy.KINDS[k]["base"]))
	print("CHECK SUMMARY fails=", fails)
