extends Node
## Membuat res://resources/anim_baked.res: semua animasi karakter yang sudah di-fit (anti-tembus), gaya serang, ulti, dan fidget.
## Jalankan ulang setiap kali pose/senjata/gaya di anim_library.gd diubah:
##   godot --headless --path . res://tools/bake_anims.tscn
## (tanpa file ini game tetap jalan, hanya menghitung semuanya saat runtime -> patah di HP).

func _ready() -> void:
	AnimLibrary.bake_disabled = true
	var t0 := Time.get_ticks_msec()
	var tex := ImageTexture.create_from_image(Image.create(4, 4, false, Image.FORMAT_RGBA8))
	for id in Data.character_ids():
		var d = Data.characters[id]
		var rig := CharacterRig.new()
		add_child(rig)
		rig.setup(1.8, tex, true, true)
		rig.set_weapon_class(d.anim_style if d.anim_style != "" else d.weapon_class)
		rig.set_style(id)
		rig.set_skill_kind(d.skill_kind)
		rig.set_ult_kind(d.ult_kind)
		for n in AnimLibrary.fidgets(id):
			AnimLibrary.fit(n, id)
		rig.queue_free()
	var lib := AnimLibrary.get_library()
	var out := AnimationLibrary.new()
	var done := {}
	for nm in lib.get_animation_list():
		var s := String(nm)
		if s.contains("@") or s.contains("#") or s.begins_with("ult_"):
			out.add_animation(nm, lib.get_animation(nm))
	for k in AnimLibrary._fit_done:
		done[String(k)] = AnimLibrary._fit_done[k]
	out.set_meta("fit_done", done)
	var err := ResourceSaver.save(out, AnimLibrary.BAKE_PATH, ResourceSaver.FLAG_COMPRESS)
	print("BAKE anim=", out.get_animation_list().size(), " fit_done=", done.size(), " err=", err, " ms=", Time.get_ticks_msec() - t0)
	get_tree().quit(0 if err == OK else 1)
