extends RefCounted
## Uji dua gacha terpisah (karakter vs perlengkapan): isi hasil, peluang, pity terpisah, banner hanya untuk gacha karakter, tab di panel.
var lobby: Node3D
var fails := 0
func check(name: String, ok: bool, detail: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", name, "  ", detail)
	if not ok:
		fails += 1
func _w(s: float) -> void:
	await lobby.get_tree().create_timer(s).timeout
func run(l: Node3D) -> void:
	lobby = l
	await _w(0.6)
	var gs := GameState
	gs.diamonds = 10000000
	# --- gacha item: 1500 tarikan
	var kinds := {}
	var rar := {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
	var bad3 := 0
	var n_item := 1500
	gs.pity_item = 0
	for i in n_item:
		var r: Dictionary = Gacha.pull(1, "", "item")[0]
		kinds[r["kind"]] = int(kinds.get(r["kind"], 0)) + 1
		rar[int(r["rarity"])] += 1
		if int(r["rarity"]) == 3 and Data.item(r["id"]).type == "potion":
			bad3 += 1
	check("gacha item: hanya memberi item (tanpa karakter/pecahan)", kinds.keys() == ["item"], str(kinds))
	check("gacha item: ★3 = perlengkapan (bukan ramuan)", bad3 == 0 and rar[3] > 0, "★3=%d" % rar[3])
	check("gacha item: ★5 ≈ 2% + pity (1-5%)", rar[5] >= n_item * 0.01 and rar[5] <= n_item * 0.05, "★5=%d/%d" % [rar[5], n_item])
	check("gacha item: ★1/★2 ≈ 30% (±6 poin)", absf(rar[1] / float(n_item) - 0.30) < 0.06 and absf(rar[2] / float(n_item) - 0.30) < 0.06, "★1=%d ★2=%d" % [rar[1], rar[2]])
	# --- gacha karakter: 1500 tarikan
	var kc := {}
	var chars := {}
	var rc := {3: 0, 4: 0, 5: 0, 6: 0}
	gs.pity = 0
	gs.set_fake_now("2026-12-01T12:00:00")   # di luar event rate_up -> Ember pada peluang dasar 0,4%
	var ember_n := 0
	var kiriel_n := 0
	for i in n_item:
		var r2: Dictionary = Gacha.pull(1, "", "char")[0]
		kc[r2["kind"]] = int(kc.get(r2["kind"], 0)) + 1
		rc[int(r2["rarity"])] += 1
		chars[r2["id"]] = true
		if r2["id"] == "ember" and int(r2["rarity"]) == 4:
			ember_n += 1
		if r2["id"] == "kiriel" and int(r2["rarity"]) == 6:
			kiriel_n += 1
	check("gacha karakter: hanya karakter / pecahan (tanpa item)", not kc.has("item") and (kc.has("character") or kc.has("shards")), str(kc))
	check("gacha karakter: Ember keluar di peluang dasar ≈ 0,4% (1-20 dari 1500)", ember_n >= 1 and ember_n <= 20, "ember=%d/%d" % [ember_n, n_item])
	check("gacha karakter: Kiriel ★6 keluar di peluang dasar ≈ 0,4% (1-20 dari 1500)", kiriel_n >= 1 and kiriel_n <= 20, "kiriel=%d/%d" % [kiriel_n, n_item])
	check("gacha karakter: Hakuya ★6, Sera/Zeya/Lyra ★4, Ren/Brann ★3 bisa keluar", gs.is_unlocked("hakuya") and gs.is_unlocked("sera") and gs.is_unlocked("zeya") and gs.is_unlocked("lyra"))
	check("gacha karakter: ★5 (Vael/Lucien) ≈ 3,5% (2-6%)", rc[5] >= n_item * 0.02 and rc[5] <= n_item * 0.06, "★5=%d/%d" % [rc[5], n_item])
	check("gacha karakter: Vael & Lucien bisa didapat", gs.is_unlocked("vael") or gs.is_unlocked("lucien"))
	check("gacha karakter: ★6 ≈ 1.5% + pity (1-5%)", rc[6] >= n_item * 0.01 and rc[6] <= n_item * 0.05, "★6=%d/%d" % [rc[6], n_item])
	check("gacha karakter: ★3 ≈ 82% (±6 poin)", absf(rc[3] / float(n_item) - 0.82) < 0.06, "★3=%d" % rc[3])
	# --- event rate_up Ember: 2% per tarikan selama 25-26 Nov, lalu kembali 0,4%
	gs.set_fake_now("2026-11-24T23:59:00")
	check("sebelum rate_up: peluang Ember & Kiriel 0,4%", is_equal_approx(Gacha.extra_rate("ember"), 0.004) and is_equal_approx(Gacha.extra_rate("kiriel"), 0.004))
	gs.set_fake_now("2026-11-25T12:00:00")
	check("saat rate_up: peluang Ember & Kiriel 2%", is_equal_approx(Gacha.extra_rate("ember"), 0.02) and is_equal_approx(Gacha.extra_rate("kiriel"), 0.02))
	gs.pity = 0
	var boost_n := 0
	var boost_k := 0
	for i in n_item:
		var rb: Dictionary = Gacha.pull(1, "", "char")[0]
		if rb["id"] == "ember" and int(rb["rarity"]) == 4:
			boost_n += 1
		if rb["id"] == "kiriel" and int(rb["rarity"]) == 6:
			boost_k += 1
	check("saat rate_up: Ember ≈ 2% (12-55 dari 1500)", boost_n >= 12 and boost_n <= 55, "ember=%d/%d" % [boost_n, n_item])
	check("saat rate_up: Kiriel ★6 ≈ 2% (12-55 dari 1500)", boost_k >= 12 and boost_k <= 55, "kiriel=%d/%d" % [boost_k, n_item])
	gs.set_fake_now("2026-11-26T23:59:00")
	check("hari ke-2 masih 2%", is_equal_approx(Gacha.extra_rate("ember"), 0.02))
	gs.set_fake_now("2026-11-27T00:00:00")
	check("setelah 2 hari: Ember & Kiriel kembali 0,4%", is_equal_approx(Gacha.extra_rate("ember"), 0.004) and is_equal_approx(Gacha.extra_rate("kiriel"), 0.004))
	gs.set_fake_now("")
	# --- pity terpisah
	gs.pity = 79
	gs.pity_item = 5
	var rr: Dictionary = Gacha.pull(1, "", "char")[0]
	check("pity karakter 79 -> ★6 & pity item tidak berubah", int(rr["rarity"]) == 6 and gs.pity == 0 and gs.pity_item == 5, "pity=%d item=%d" % [gs.pity, gs.pity_item])
	gs.pity = 7
	gs.pity_item = 49
	rr = Gacha.pull(1, "", "item")[0]
	check("pity item 49 -> ★5 & pity karakter tidak berubah", int(rr["rarity"]) == 5 and gs.pity_item == 0 and gs.pity == 7, "pity=%d item=%d" % [gs.pity, gs.pity_item])
	var d0 := gs.diamonds
	check("banner event tidak bisa dipakai di gacha item (tanpa potong diamond)", Gacha.pull(1, "ev_ember_fest", "item").is_empty() and gs.diamonds == d0)
	# --- panel: dua tab
	lobby.host.open("gacha")
	await _w(0.5)
	var panel = lobby.host.current
	check("panel: dua tab gacha", panel._pool_tabs.get_child_count() == 2 and panel._pool == "char")
	await lobby._shot("gacha_tab_char")
	panel._pool_tabs.get_child(1).emit_signal("pressed")
	await _w(0.4)
	check("tab item: pool item & peluang 5 baris", panel._pool == "item")
	await lobby._shot("gacha_tab_item")
	var p0: int = gs.pity_item
	panel._do(1)
	await _w(0.3)
	var rv: GachaReveal = panel._reveal
	check("tarik di tab item menghasilkan item", rv != null and rv.results.size() == 1 and rv.results[0]["kind"] == "item", str(rv.results if rv else ""))
	check("pity item bertambah / reset (bukan pity karakter)", gs.pity_item != p0 or int(rv.results[0]["rarity"]) == 5)
	rv._skip = true
	await _w(2.0)
	rv._btn_row.get_children()[0].emit_signal("pressed")
	await _w(0.3)
	panel._pool_tabs.get_child(0).emit_signal("pressed")
	await _w(0.4)
	check("kembali ke tab karakter", panel._pool == "char")
	panel._do(1)
	await _w(0.3)
	rv = panel._reveal
	check("tarik di tab karakter menghasilkan karakter/pecahan", rv != null and rv.results[0]["kind"] in ["character", "shards"], str(rv.results if rv else ""))
	rv._skip = true
	await _w(2.0)
	print("BOT DONE fails=", fails)
	lobby.get_tree().quit(fails)
