extends RefCounted
## Uji panel Peta Dunia: terbuka dari lobi (kota / desa), memilih tiap lokasi tanpa galat, tangkapan layar ke --shots.
##   -- --bot=1 --botscript=worldmap_bot --fresh [--map=village] [--shots=DIR]
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1
func run(l: Node3D) -> void:
	var t := l.get_tree()
	await t.create_timer(1.0).timeout
	l.host.open("world_map")
	await t.create_timer(0.8).timeout
	check("panel peta dunia terbuka", l.host.has_method("open") and _find(l.host) != null)
	var wm = _find(l.host)
	if wm != null:
		for id in wm._view._locs.keys():
			wm._select(id)
			await t.create_timer(0.15).timeout
		check("semua lokasi bisa dipilih", true, str(wm._view._locs.keys()))
	var d := ""
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--shots="): d = a.substr(8)
	if d != "":
		await RenderingServer.frame_post_draw
		l.get_viewport().get_texture().get_image().save_png(d + "/worldmap_%s.png" % str(l.get("map_id")))
	print("CHECK SUMMARY fails=", fails)
func _find(n: Node):
	if n.get_script() != null and str(n.get_script().resource_path).ends_with("world_map_panel.gd"): return n
	for c in n.get_children():
		var r = _find(c)
		if r != null: return r
	return null
