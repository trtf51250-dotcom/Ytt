extends RefCounted
## Bot: peta Desa Fajar -> dunia terbangun, NPC (±20) bisa diajak bicara, rumah bisa dimasuki, lengkung gerbang bekerja, ringan (draw call).
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func _calls() -> int:
	return RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
func run(l: Node3D) -> void:
	var tree := l.get_tree()
	await tree.create_timer(1.2).timeout
	check("peta aktif = desa", l.map_id == "village" and l.world is VillageWorld)
	check("tanpa ExploreWorld (ringan)", l.explore == null)
	var sp := Vector2(l.player.global_position.x, l.player.global_position.z)
	check("spawn dekat gerbang utara", sp.distance_to(Vector2(0, -64)) < 3.0, str(sp))
	var houses := 0
	var doors := 0
	for b in l.world.buildings:
		if str(b.kind).begins_with("house_"):
			houses += 1
			if b.has_door:
				doors += 1
	check("±12 rumah, semua berpintu", houses == 12 and doors == 12, "rumah=%d pintu=%d" % [houses, doors])
	var n: int = l.villagers.size()
	check("NPC desa ±20 (anggaran kualitas)", n >= 10 and n <= 24, "n=%d level=%d" % [n, Quality.level()])
	var named := {}
	for v in l.villagers:
		named[v.display_name] = true
	check("NPC bernama unik", named.size() == n, "unik=%d dari %d" % [named.size(), n])
	# tak ada NPC/rumah yang menembus bangunan atau berada di luar batas
	var bad := 0
	for v in l.villagers:
		var p: Vector2 = Vector2(v.global_position.x, v.global_position.z)
		if p.x < VillageLayout.BOUNDS_MIN.x or p.x > VillageLayout.BOUNDS_MAX.x or p.y < VillageLayout.BOUNDS_MIN.y or p.y > VillageLayout.BOUNDS_MAX.y:
			bad += 1
			print("INFO luar batas: ", v.display_name, " ", p)
		for b in l.world.buildings:
			var bb: AABB = b.world_aabb
			if bb.size.x < 60.0 and bb.grow(-0.3).has_point(Vector3(v.global_position.x, 1.0, v.global_position.z)):
				bad += 1
				print("INFO dalam bangunan: ", v.display_name, " ", p, " ", b.kind, " ", b.position)
	check("NPC tidak di dalam bangunan / di luar batas", bad == 0, "bad=%d" % bad)
	# aksi fungsional
	var acts := {}
	for d in NpcDefs.VILLAGE_NPCS:
		for a in d.get("actions", []):
			acts[a["action"]] = true
	for need in ["quests", "adventure", "shop:item", "shop:sell", "smith", "go_town"]:
		check("aksi tersedia: " + need, acts.has(need))
	# bicara dengan Kepala Desa
	var elder: Villager = null
	for v in l.villagers:
		if v.display_name == "Pak Wiryo":
			elder = v
	check("Kepala Desa ada", elder != null)
	if elder != null:
		l.player.global_position = elder.global_position + Vector3(0, 0.06, 1.6)
		await tree.process_frame
		await tree.process_frame
		var t: Dictionary = l._find_target()
		check("dekat Kepala Desa: bisa bicara", str(t.get("prompt", "")).begins_with("Bicara dengan"), str(t.get("prompt", "")))
		l._try_interact()
		await tree.create_timer(0.3).timeout
		check("dialog terbuka", l.dialogue.is_open)
		var dlg: Dictionary = elder.dialogue()
		var has_q := false
		for c in dlg["start"]["choices"]:
			if c.get("action", "") == "quests":
				has_q = true
		check("dialog punya pilihan Quest", has_q)
		l.dialogue.close()
		await tree.create_timer(0.2).timeout
	# lengkung gerbang
	var gt := false
	var ga := false
	for it in l.world.interactions:
		if it["id"] == "gate_town":
			gt = true
			check("gerbang utara -> go_town", it["action"] == "go_town")
		if it["id"] == "gate_adventure":
			ga = true
			check("gerbang selatan -> adventure", it["action"] == "adventure")
	check("kedua lengkung ada", gt and ga)
	# rumah: masuk lalu keluar
	var hb: Building = null
	for b in l.world.buildings:
		if b.has_door:
			hb = b
			break
	var dw: Vector3 = hb.to_global(hb.door_pos + Vector3(0, -0.4, 1.3))
	l.player.global_position = Vector3(dw.x, 0.1, dw.z)
	await tree.process_frame
	await tree.process_frame
	var t2: Dictionary = l._find_target()
	check("pintu rumah desa bisa dibuka", str(t2.get("prompt", "")) == "Buka pintu", str(t2.get("prompt", "")))
	l._try_interact()
	var tt := 0.0
	while (l.interior == null or l._house_busy) and tt < 6.0:
		await tree.process_frame
		tt += 0.016
	check("interior rumah desa terbentuk", l.interior != null)
	if l.interior != null:
		var home_ok := false
		for v in l.villagers:
			if is_instance_valid(v) and v.visible and v._def.get("home", false) and v.global_position.distance_to(l.player.global_position) < 6.0:
				home_ok = true
		check("penghuni desa ada di dalam", home_ok)
		l._exit_house()
		tt = 0.0
		while (l.interior != null or l._house_busy) and tt < 6.0:
			await tree.process_frame
			tt += 0.016
		check("keluar rumah", l.interior == null and l.world.visible)
	# ringan: jalan ke alun-alun lalu ukur draw call
	l.player.global_position = Vector3(0, 0.1, 6)
	l.hud.visible = false
	l.touch.visible = false
	l.cam.snap_to_target()
	await tree.create_timer(0.6).timeout
	l.daynight.hour = 11.0
	await tree.create_timer(0.4).timeout
	var c1 := _calls()
	print("INFO desa alun-alun draw calls=", c1, " tris=", RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME))
	await l._shot("desa_alun")
	l.player.global_position = Vector3(30, 0.1, 40)
	l.cam.snap_to_target()
	await tree.create_timer(0.6).timeout
	var c2 := _calls()
	print("INFO desa ladang draw calls=", c2)
	await l._shot("desa_ladang")
	l.player.global_position = Vector3(2, 0.1, -48)
	l.cam.snap_to_target()
	await tree.create_timer(0.5).timeout
	await l._shot("desa_rumah_utara")
	l.player.global_position = Vector3(-4, 0.1, 30)
	l.cam.snap_to_target()
	await tree.create_timer(0.5).timeout
	await l._shot("desa_rumah_selatan")
	l.player.global_position = Vector3(-14, 0.1, -3)
	l.cam.snap_to_target()
	await tree.create_timer(0.5).timeout
	await l._shot("desa_warung")
	l.player.global_position = Vector3(0, 0.1, -62)
	l.cam.snap_to_target()
	await tree.create_timer(0.6).timeout
	await l._shot("desa_gerbang")
	l.player.global_position = Vector3(0, 0.1, 10)
	l.cam.distance = l.cam.max_distance
	l.cam.pitch = deg_to_rad(70.0)
	l.cam.snap_to_target()
	await tree.create_timer(0.6).timeout
	await l._shot("desa_atas")
	for b in l.world.buildings:
		if not str(b.kind).begins_with("house_"):
			print("INFO aabb ", b.kind, " ", b.world_aabb)
	var oc := Camera3D.new()
	l.add_child(oc)
	oc.fov = 60.0
	oc.far = 800.0
	oc.global_position = Vector3(0, 175, 40)
	oc.rotation_degrees = Vector3(-86, 0, 0)
	oc.make_current()
	await tree.create_timer(0.8).timeout
	await l._shot("desa_peta")
	check("ringan: draw call desa < 260", maxi(c1, c2) < 260, "c1=%d c2=%d" % [c1, c2])
	print("CHECK SUMMARY fails=", fails)
	tree.quit()
