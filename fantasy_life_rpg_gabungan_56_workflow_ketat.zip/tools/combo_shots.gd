extends RefCounted
## Tangkapan layar langkah kombo tiap karakter (butuh renderer): --shots=DIR [--only=id]
func run(st: Node3D) -> void:
	var t := st.get_tree()
	st.autoplay = false
	await t.create_timer(0.8).timeout
	var p: Player = st.player
	p.invuln = 0.0
	var base: Vector3 = p.global_position
	var only := ""
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--only="):
			only = a.substr(7)
	for id in Data.character_ids():
		if only != "" and id != only:
			continue
		GameState.unlock_character(id)
		p.set_character(id)
		p.control_enabled = true
		p.global_position = base
		p.facing = 0.0
		for e in t.get_nodes_in_group("enemies"):
			e.queue_free()
		await t.create_timer(0.3).timeout
		var mons: Array = []
		for i in 3:
			var e: Enemy = st._spawn_enemy("slime", base + Vector3(-1.6 + i * 1.6, 0, 2.6 + (i % 2) * 1.5))
			mons.append(e)
		await t.create_timer(1.0).timeout
		for e in mons:
			e.hp = 100000
			e.max_hp = 100000
			e.set_physics_process(false)
		st.cam.pitch = deg_to_rad(55.0)
		st.cam.distance = 11.0
		st.cam.snap_to_target()
		var n := ComboDefs.steps(Data.character(id)).size()
		for i in n:
			p._act_t = 0.0
			p.attack_cd = 0.0
			p.do_attack()
			if i >= n - 2:
				await t.create_timer(0.38).timeout
				await st._shot("combo_%s_%d" % [id, i + 1])
				await t.create_timer(0.5).timeout
			else:
				await t.create_timer(0.7).timeout
	print("SUMMARY fails=0")
