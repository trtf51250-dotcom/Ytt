#!/usr/bin/env bash
# Ekspor APK RILIS langsung dari Godot di komputer (Linux/macOS) tanpa GitHub.
#   bash tools/ekspor_apk.sh            -> build/fantasy_life_rpg.apk
#   bash tools/ekspor_apk.sh --no-bake  -> lewati hitung ulang animasi (pakai resources/anim_baked.res yang ada)
# Variabel opsional: GODOT=/path/ke/godot  ANDROID_HOME=...  JAVA_HOME=...  KEYSTORE=...  KS_PASS=...
# PENTING: ini RILIS. Template "debug" Godot jauh lebih lambat di HP (itu penyebab lag di build sebelumnya).
set -euo pipefail
cd "$(dirname "$0")/.."
GODOT="${GODOT:-godot}"
VER="4.3"
BAKE=1; [ "${1:-}" = "--no-bake" ] && BAKE=0
die() { echo "GAGAL: $*" >&2; exit 1; }

command -v "$GODOT" >/dev/null 2>&1 || die "Godot tidak ditemukan. Pasang Godot $VER (standar, bukan .NET) lalu jalankan: GODOT=/path/ke/godot bash tools/ekspor_apk.sh"
"$GODOT" --version | grep -q "^$VER" || echo "PERINGATAN: versi Godot bukan $VER ($("$GODOT" --version)); proyek ini diuji di $VER."

case "$(uname -s)" in
  Darwin) DATA="$HOME/Library/Application Support/Godot"; CFG="$DATA" ;;
  *)      DATA="${XDG_DATA_HOME:-$HOME/.local/share}/godot"; CFG="${XDG_CONFIG_HOME:-$HOME/.config}/godot" ;;
esac

# 1) Export template
TPL="$DATA/export_templates/$VER.stable"
[ -f "$TPL/android_release.apk" ] || die "Export template Godot $VER belum terpasang.
  Buka Godot -> menu Editor -> Manage Export Templates -> Download and Install (butuh internet sekali). Folder yang dicari: $TPL"

# 2) Java & Android SDK
command -v keytool >/dev/null 2>&1 || die "JDK 17 belum terpasang (keytool tidak ada). Pasang OpenJDK 17."
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[ -n "$SDK" ] && [ -d "$SDK/build-tools" ] && [ -d "$SDK/platforms" ] || die "Android SDK belum terpasang / ANDROID_HOME belum diisi.
  Pasang Android command-line tools lalu: sdkmanager \"platform-tools\" \"build-tools;34.0.0\" \"platforms;android-34\" \"cmdline-tools;latest\""
JAVA="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v keytool)")")")}"

# 3) Pengaturan editor Godot (hanya dibuat bila belum ada; kalau sudah ada, atur lewat Editor Settings -> Export -> Android)
mkdir -p "$CFG"
ES="$CFG/editor_settings-$VER.tres"
if [ ! -f "$ES" ]; then
  cat > "$ES" <<EOT
[gd_resource type="EditorSettings" format=3]
[resource]
export/android/android_sdk_path = "$SDK"
export/android/java_sdk_path = "$JAVA"
export/android/shutdown_adb_on_exit = true
EOT
  echo "Membuat pengaturan editor: $ES"
elif ! grep -q "android_sdk_path" "$ES"; then
  echo "PERINGATAN: $ES sudah ada tapi belum berisi path Android SDK. Isi di Godot: Editor Settings -> Export -> Android (Android SDK Path & Java SDK Path)."
fi

# 4) Keystore (dibuat otomatis sekali; berkas *.keystore tidak ikut ke Git)
KS="${KEYSTORE:-keystore/fantasy_life.keystore}"
KS_PASS="${KS_PASS:-android}"
if [ ! -f "$KS" ]; then
  mkdir -p "$(dirname "$KS")"
  keytool -genkeypair -v -keyalg RSA -keysize 2048 -validity 10000 -alias fantasylife -keystore "$KS" \
    -storepass "$KS_PASS" -keypass "$KS_PASS" -dname "CN=Fantasy Life RPG,O=gt,C=ID" >/dev/null
  echo "Keystore baru dibuat: $KS (password: $KS_PASS). SIMPAN berkas ini: APK versi berikutnya harus memakai keystore yang sama agar bisa menimpa pemasangan lama."
fi
export GODOT_ANDROID_KEYSTORE_RELEASE_PATH="$(cd "$(dirname "$KS")" && pwd)/$(basename "$KS")"
export GODOT_ANDROID_KEYSTORE_RELEASE_USER="${KS_ALIAS:-fantasylife}"
export GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD="$KS_PASS"

# 5) Impor, bake animasi, ekspor rilis
mkdir -p build
echo "== Impor aset"; "$GODOT" --headless --path . --import >/dev/null 2>&1 || true
if [ "$BAKE" = 1 ]; then echo "== Bake animasi"; "$GODOT" --headless --path . res://tools/bake_anims.tscn | tail -n 2 || true; fi
echo "== Ekspor APK (RILIS)"
"$GODOT" --headless --path . --export-release "Android" build/fantasy_life_rpg.apk
[ -s build/fantasy_life_rpg.apk ] || die "APK tidak terbentuk. Baca pesan error Godot di atas."
echo "SELESAI: build/fantasy_life_rpg.apk ($(du -h build/fantasy_life_rpg.apk | cut -f1)). Salin ke HP lalu pasang (izinkan 'sumber tidak dikenal')."
