extends RefCounted
## Film-strip satu animasi: tiap frame dipasang langsung ke skeleton lalu difoto. Env: STRIP_ID, STRIP_ANIMS (Attack1,Attack2,Skill,...),
## STRIP_FR (pecahan waktu "0,.15,.3"), POSE_YAW/POSE_DIST/POSE_PITCH. Hasil: strip_<id>_<node>_<n>.png
var lobby: Node3D
func _w(s: float) -> void:
	await lobby.get_tree().create_timer(s, true, false, true).timeout
func run(l: Node3D) -> void:
	lobby = l
	await _w(0.5)
	var pl: Player = lobby.player
	var cid := OS.get_environment("STRIP_ID")
	GameState.unlock_character(cid)
	GameState.set_party_slot(0, cid)
	await _w(0.9)
	lobby.cam.min_distance = 1.5
	lobby.cam.min_pitch = deg_to_rad(-5.0)
	lobby.cam.distance = float(OS.get_environment("POSE_DIST")) if OS.get_environment("POSE_DIST") != "" else 4.2
	lobby.cam.pitch = deg_to_rad(float(OS.get_environment("POSE_PITCH")) if OS.get_environment("POSE_PITCH") != "" else 8.0)
	lobby.cam.yaw = deg_to_rad(float(OS.get_environment("POSE_YAW")) if OS.get_environment("POSE_YAW") != "" else 150.0)
	await _w(0.8)
	var rig: CharacterRig = pl.rig
	AnimLibrary.fidgets(cid)
	rig.tree.active = false
	var fr := OS.get_environment("STRIP_FR").split(",") if OS.get_environment("STRIP_FR") != "" else PackedStringArray(["0", "0.15", "0.3", "0.45", "0.6", "0.8", "1.0"])
	for nd in OS.get_environment("STRIP_ANIMS").split(","):
		var an: Animation = rig.player.get_animation(AnimLibrary.fit(nd, cid)) if (nd.begins_with("fid_") or nd.contains("@")) else rig.player.get_animation(String(rig._anim_nodes[nd].animation))
		var k := 0
		for f in fr:
			var tm := an.length * float(f)
			for ti in an.get_track_count():
				var bn := str(an.track_get_path(ti)).get_slice(":", 1)
				var bi := rig.skel.find_bone(bn)
				if bi < 0: continue
				if an.track_get_type(ti) == Animation.TYPE_ROTATION_3D:
					rig.skel.set_bone_pose_rotation(bi, an.rotation_track_interpolate(ti, tm))
				elif an.track_get_type(ti) == Animation.TYPE_POSITION_3D:
					rig.skel.set_bone_pose_position(bi, an.position_track_interpolate(ti, tm))
			await _w(0.12)
			await lobby._shot("strip_%s_%s_%d" % [cid, nd, k])
			k += 1
	print("SUMMARY fails=0")
