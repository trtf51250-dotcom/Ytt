extends RefCounted
## Uji menu "Menu" (hub): tombol di HUD, lencana, kartu membuka panel yang benar.
var lobby: Node3D
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1
func run(l: Node3D) -> void:
	lobby = l
	await lobby.get_tree().create_timer(0.8).timeout
	await lobby._shot("menu_hud")
	var hud: Hud = lobby.hud
	check("tombol Menu ada, tombol lama tidak ada", hud._buttons.has("more") and not hud._buttons.has("login") and not hud._buttons.has("daily") and not hud._buttons.has("event"))
	check("lencana Menu > 0 (hadiah login siap)", hud.more_badge_count() > 0 and hud._badges["more"].visible, str(hud.more_badge_count()))
	hud.menu_pressed.emit("more")
	await lobby.get_tree().process_frame
	var dr: Control = lobby.host.current._drawer
	check("laci mulai dari luar layar kanan (offset_left > 100 di awal)", dr.offset_left > 100.0, "%.0f" % dr.offset_left)
	await lobby.get_tree().create_timer(0.1).timeout
	await lobby._shot("menu_slide_mid")
	await lobby.get_tree().create_timer(0.7).timeout
	check("panel Menu terbuka", lobby.host.current_id == "more")
	check("laci berhenti di posisi akhir (offset 0)", absf(dr.offset_left) < 1.0)
	await lobby._shot("menu_more")
	# tombol panah kembali -> meluncur keluar lalu tertutup
	lobby.host.current._close_anim()
	await lobby.get_tree().process_frame
	check("saat menutup: animasi keluar berjalan, panel belum hilang", lobby.host.is_open() and lobby.host.current._closing)
	await lobby.get_tree().create_timer(0.5).timeout
	check("menu tertutup setelah animasi", not lobby.host.is_open())
	lobby.host.open("more")
	await lobby.get_tree().create_timer(0.6).timeout
	for id in ["login", "daily", "event", "profile", "stats", "collection", "guide", "support"]:
		lobby.host.open("more")
		await lobby.get_tree().create_timer(0.4).timeout
		lobby.host.open(id)
		await lobby.get_tree().create_timer(0.4).timeout
		check("kartu -> panel %s" % id, lobby.host.current_id == id)
		if id in ["stats", "collection", "guide"]:
			await lobby._shot("panel_" + id)
	GameState.claim_login()
	lobby.host.open("more")
	await lobby.get_tree().create_timer(0.5).timeout
	check("klaim login -> lencana login hilang", not GameState.login_claimable())
	print("CHECK SUMMARY fails=", fails)
