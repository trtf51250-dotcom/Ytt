extends RefCounted
## Ukur beban skrip per frame (headless): TIME_PROCESS/PHYSICS rata-rata, jumlah node, dan skrip terbanyak.
func run(root: Node3D) -> void:
	var t := root.get_tree()
	await t.create_timer(2.0).timeout
	var n := 0
	var sp := 0.0
	var sph := 0.0
	for i in 240:
		await t.process_frame
		sp += Performance.get_monitor(Performance.TIME_PROCESS)
		sph += Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS)
		n += 1
	print("COST process_ms=%.3f physics_ms=%.3f nodes=%d objects=%d" % [sp / n * 1000.0, sph / n * 1000.0, int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT)), int(Performance.get_monitor(Performance.OBJECT_COUNT))])
	var counts := {}
	var stack: Array = [t.root]
	var procs := 0
	while not stack.is_empty():
		var x: Node = stack.pop_back()
		if x.is_processing() or x.is_physics_processing():
			procs += 1
			var s = x.get_script()
			var key: String = (s as Script).resource_path.get_file() if s != null else x.get_class()
			counts[key] = int(counts.get(key, 0)) + 1
		for c in x.get_children():
			stack.push_back(c)
	var keys := counts.keys()
	keys.sort_custom(func(a, b): return counts[a] > counts[b])
	print("COST nodes_processing=", procs)
	for k in keys.slice(0, 12):
		print("COST   ", k, " x", counts[k])

	# eksperimen: matikan semua rig NPC/warga, ukur lagi (selisih = biaya animasi NPC)
	var rigs: Array = []
	var st2: Array = [t.root]
	while not st2.is_empty():
		var y: Node = st2.pop_back()
		if y is CharacterRig and not (y.get_parent() is Player):
			rigs.append(y)
		for c in y.get_children():
			st2.push_back(c)
	for r in rigs:
		(r as Node).process_mode = Node.PROCESS_MODE_DISABLED
	await t.create_timer(0.5).timeout
	var sp2 := 0.0
	var sph2 := 0.0
	for i in 240:
		await t.process_frame
		sp2 += Performance.get_monitor(Performance.TIME_PROCESS)
		sph2 += Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS)
	print("COST tanpa_rig_npc(%d) process_ms=%.3f physics_ms=%.3f" % [rigs.size(), sp2 / 240.0 * 1000.0, sph2 / 240.0 * 1000.0])
