extends RefCounted
## Uji aksi diam acak: berdiri diam ~25 dtk -> harus ada aksi (state Wind) beberapa kali & tidak berulang berturut-turut; bergerak harus memutusnya.
var lobby: Node3D
var fails := 0
func _w(s: float) -> void:
	await lobby.get_tree().create_timer(s, true, false, true).timeout
func _check(ok: bool, msg: String) -> void:
	if not ok:
		fails += 1
		print("CHECK FAIL ", msg)
func run(l: Node3D) -> void:
	lobby = l
	await _w(0.8)
	var rig: CharacterRig = lobby.player.rig
	var seen := []
	var t := 0.0
	var prev := ""
	while t < 26.0:
		await _w(0.1)
		t += 0.1
		var st := rig.current_state()
		if st == "Wind" and prev != "Wind":
			seen.append(rig._fid_last)
		prev = st
	print("FIDGET terlihat: ", seen)
	_check(seen.size() >= 2, "minimal 2 aksi diam dalam 26 dtk (dapat %d)" % seen.size())
	for i in range(1, seen.size()):
		_check(seen[i] != seen[i - 1], "aksi sama berturut-turut: " + str(seen[i]))
	# bergerak memutus aksi
	rig.play_fidget()
	await _w(0.6)
	_check(rig.current_state() == "Wind", "aksi diam mulai")
	lobby.player.set_physics_process(false)          # supaya kecepatan buatan tidak ditimpa fisika pemain
	rig.set_move_speed(1.0, 5.0)
	await _w(0.5)
	_check(rig.current_state() != "Wind", "bergerak memutus aksi diam (state=%s)" % rig.current_state())
	# menyerang saat aksi berjalan: tidak macet
	rig.set_move_speed(0.0, 0.0)
	lobby.player.set_physics_process(true)
	rig.play_fidget()
	await _w(0.5)
	lobby.player._act_t = 0.0
	lobby.player.attack_cd = 0.0
	lobby.player.do_attack()
	await _w(0.3)
	_check(rig.current_state().begins_with("Attack"), "serangan memutus aksi diam (state=%s)" % rig.current_state())
	await _w(2.5)
	_check(rig.current_state() == "Move", "kembali ke Move setelah serangan (state=%s)" % rig.current_state())
	print("SUMMARY fails=%d" % fails)
