extends Node
## Foto layar judul: tanpa data, dengan data, kode perangkat lain (ditolak tanpa blokir). Menulis ke user:// (dibersihkan di akhir). Jalankan tanpa --fresh.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok: fails += 1
func _shot(name: String) -> void:
	var dir := ""
	for x in OS.get_cmdline_user_args():
		if x.begins_with("--shots="): dir = x.substr(8)
	if dir != "":
		get_viewport().get_texture().get_image().save_png("%s/%s.png" % [dir, name])
func _titles() -> Array:
	var out: Array = []
	for b in get_tree().root.find_children("*", "Button", true, false):
		if (b as Button).is_visible_in_tree(): out.append((b as Button).text)
	return out
func _open() -> Node:
	var t: Node = load("res://scenes/title.tscn").instantiate()
	add_child(t)
	await get_tree().create_timer(0.6).timeout
	return t
func _ready() -> void:
	var gs := GameState
	gs.delete_save(); DirAccess.remove_absolute(ProjectSettings.globalize_path(gs.LEGACY_SANCTION_PATH))
	var t := await _open()
	var tx := _titles()
	check("tanpa data: Mulai Bermain + Pulihkan, TANPA Lanjutkan/Hapus", "Mulai Bermain" in tx and "Pulihkan dari Kode Cadangan" in tx and not ("Lanjutkan" in tx) and not ("Hapus Data" in tx), str(tx))
	await _shot("title_kosong")
	t.queue_free(); await get_tree().process_frame
	gs.start_new_game(); gs.player_name = "Gt"; gs.level = 7; gs.save_game()
	t = await _open()
	tx = _titles()
	check("ada data: Lanjutkan + Mulai Baru + Hapus Data, TANPA Pulihkan", "Lanjutkan" in tx and "Mulai Baru" in tx and "Hapus Data" in tx and not ("Pulihkan dari Kode Cadangan" in tx), str(tx))
	await _shot("title_ada_data")
	check("tidak ada kata SV/slot/dunia di tombol", not tx.any(func(s): return s.contains("SV") or s.to_lower().contains("slot") or s.to_lower().contains("dunia")), str(tx))
	t.queue_free(); await get_tree().process_frame
	# kode dari perangkat lain: ditolak, TANPA layar blokir; menu tetap normal
	gs.flag_cheat("other_device", "uji")
	t = await _open()
	tx = _titles()
	check("ada temuan deteksi: menu tetap normal (Lanjutkan + Mulai Baru), tidak ada layar blokir", "Lanjutkan" in tx and "Mulai Baru" in tx, str(tx))
	check("tidak ada teks 'DIBLOKIR' di layar judul", not (get_tree().root.find_children("*", "Label", true, false).any(func(l): return (l as Label).text.to_upper().contains("DIBLOKIR"))))
	await _shot("title_ada_temuan")
	t.queue_free(); await get_tree().process_frame
	gs.delete_save(); gs._cheat_pending.clear(); DirAccess.remove_absolute(ProjectSettings.globalize_path(gs.LEGACY_SANCTION_PATH))
	print("CHECK SUMMARY fails=", fails)
	get_tree().quit()
