extends RefCounted
## Kombo serangan biasa semua karakter (ComboDefs + ComboRunner): tiap karakter memainkan satu putaran kombo penuh ke 4 musuh; cek tiap langkah jalan,
## melukai musuh, tidak ada error, dan DPS kombo baru ≈ DPS pola lama (±25%).
##   scenes/stages/stage.tscn -- --bot=1 --botscript=combo_bot --stage=s1_1 --nocine=1 --fresh [--only=kiriel]
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1

func _lost(mons: Array) -> int:
	var l := 0
	for e in mons:
		l += 100000 - (int(e.hp) if is_instance_valid(e) else 0)
	return l

func _spawn(st: Node3D, base: Vector3) -> Array:
	var t := st.get_tree()
	for e in t.get_nodes_in_group("enemies"):
		e.queue_free()
	await t.create_timer(0.3).timeout
	var mons: Array = []
	for i in 4:
		var e: Enemy = st._spawn_enemy("slime", base + Vector3(-1.5 + i * 1.0, 0, 2.0 + (i % 2) * 1.2))
		mons.append(e)
	await t.create_timer(1.0).timeout
	for e in mons:
		e.hp = 100000
		e.max_hp = 100000
		e.set_physics_process(false)
	return mons

func _old_dps(cd: CharacterData) -> float:
	var n := maxi(cd.combo_hits, 1)
	var tot := 0.0
	for i in n:
		var fin := i == n - 1 and n > 1
		tot += cd.finisher_mult if (fin and cd.attack_kind == "dagger") else 1.0
	return tot / (cd.attack_cooldown * n + (cd.combo_recovery if n > 1 else 0.0))

func run(st: Node3D) -> void:
	var t := st.get_tree()
	st.autoplay = false
	await t.create_timer(0.8).timeout
	var p: Player = st.player
	p.invuln = 0.0
	var base: Vector3 = p.global_position
	var only := ""
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--only="):
			only = a.substr(7)
	var ids: Array = []
	for cid in Data.character_ids():
		if only == "" or cid == only:
			ids.append(cid)
	for id in ids:
		GameState.unlock_character(id)
		p.set_character(id)
		p.control_enabled = true
		p.global_position = base
		p.facing = 0.0
		var cd := Data.character(id)
		var steps: Array = ComboDefs.steps(cd)
		var names := ComboDefs.names(cd)
		check(id + " kombo >= 3 langkah", steps.size() >= 3, "langkah=%d (%s)" % [steps.size(), " > ".join(names)])
		var cyc := ComboDefs.cycle(cd)
		var ratio := (cyc.x / cyc.y) / _old_dps(cd)
		print("DPS ", id, " baru=", snappedf(cyc.x / cyc.y, 0.01), " lama=", snappedf(_old_dps(cd), 0.01), " rasio=", snappedf(ratio, 0.01))
		check(id + " DPS kombo baru dalam 0.75-1.25x lama", ratio > 0.75 and ratio < 1.25, "rasio=%.2f" % ratio)
		var mons: Array = await _spawn(st, base)
		var seen_anims: Array = []
		for i in steps.size():
			var before := _lost(mons)
			if bool((steps[i] as Dictionary).get("need_dash", false)):      # langkah wajib-dash: dash dulu (Midori)
				p.dodge_cd = 0.0
				p.do_dodge()
				await t.create_timer(0.4).timeout
			p._act_t = 0.0
			p.attack_cd = 0.0
			var ok := p.do_attack()
			if not ok:
				check(id + " langkah %d jalan" % (i + 1), false, "do_attack ditolak")
				continue
			await t.create_timer(1.5 if String((steps[i] as Dictionary).get("t", "")) == "bomb" else 0.9).timeout     # bom: terbang + sumbu
			var got := _lost(mons) - before
			check(id + " langkah %d (%s) melukai" % [i + 1, names[i]], got > 0, "hp hilang=%d" % got)
		check(id + " kombo berputar ke langkah 1", p._combo == 0, "_combo=%d" % p._combo)
		await t.create_timer(0.3).timeout
	print("SUMMARY fails=", fails)
