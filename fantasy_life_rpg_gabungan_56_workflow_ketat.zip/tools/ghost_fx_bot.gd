extends RefCounted
## Uji efek LAWAN (GhostFx): untuk tiap karakter, tiap langkah kombo, skill, dan ULTI dimainkan lewat hantu CoopGhost;
## memeriksa bahwa efek benar-benar muncul (node baru di fx_root), tanpa error, dan animasi hantu berjalan. Juga uji status wujud pedang & kebal.
##   res://scenes/stages/stage.tscn -- --bot=1 --botscript=ghost_fx_bot --stage=pvp_meadow --nocine=1 --fresh [--shots=DIR]
var fails := 0


func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1


## Tunggu `dur` detik sambil mencatat puncak jumlah node efek baru (efek bisa hilang sebelum jendela habis).
func _peak(t: SceneTree, fx: Node3D, n0: int, dur: float) -> int:
	var st := fx.get_parent() as Stage
	var peak := 0
	var k := int(dur / 0.05)
	for i in k:
		await t.create_timer(0.05).timeout
		if st != null and st.state == Stage.S.ENDED:
			st.state = Stage.S.FIGHT   # stage uji tanpa musuh bisa 'menang' sendiri; ini hanya menguji efek hantu
		peak = maxi(peak, fx.get_child_count() - n0)
	return peak


func run(st: Node3D) -> void:
	var t := st.get_tree()
	st.autoplay = false
	await t.create_timer(0.8).timeout
	var p: Player = st.player
	p.global_position = Vector3(0, 0.1, 0)
	var g := CoopGhost.new()
	st.add_child(g)
	g.setup(900, "ren", "Lawan")
	g.global_position = Vector3(0, 0.1, 6.0)
	g.apply(g.global_position, PI, 0.0, "ren", 100, 100, false, false)
	await t.create_timer(0.2).timeout
	var fx: Node3D = st.fx_root
	st.state = Stage.S.FIGHT
	var ids: Array = Data.character_ids()
	check("ada karakter untuk diuji", ids.size() >= 16, "jumlah=%d" % ids.size())
	for id in ids:
		var cd: CharacterData = Data.character(id)
		g.apply(g.global_position, PI, 0.0, id, 100, 100, false, false)
		g.rig.rotation.y = PI
		var steps: Array = ComboDefs.steps(cd)
		# --- tiap langkah kombo
		for i in steps.size():
			var n0 := fx.get_child_count()
			g.play("attack:%d:%.3f" % [i, PI])
			var made: int = await _peak(t, fx, n0, 1.4)
			check("%s kombo %d (%s) memunculkan efek" % [id, i + 1, String((steps[i] as Dictionary).get("t", "arc"))], made > 0, "node baru=%d" % made)
		# --- skill
		var n1 := fx.get_child_count()
		g.play("skill:0:%.3f" % PI)
		var sk: int = await _peak(t, fx, n1, 1.3)
		check("%s skill (%s) memunculkan efek" % [id, cd.skill_kind], sk > 0, "puncak node baru=%d" % sk)
		# --- ULTI: efek bertahap (peringatan, pengisian, sambaran, penutup)
		var n2 := fx.get_child_count()
		var peak := 0
		g.play("ult:0:%.3f" % PI)
		peak = await _peak(t, fx, n2, 3.5)
		check("%s ULTI (%s) memunculkan efek" % [id, cd.ult_kind], peak >= 3, "puncak node baru=%d" % peak)
		await t.create_timer(2.5).timeout
	# --- status: wujud pedang & kebal
	g.apply(g.global_position, PI, 0.0, "kiriel", 100, 100, false, false)
	g.set_form(true)
	check("hantu Kiriel wujud pedang: pedang petir terpasang", g.rig.weapon_holder.get_node_or_null("StormSword") != null)
	check("hantu Kiriel wujud pedang: serangan jadi jarak dekat", GhostFx.eff_data(g).attack_kind == "arc")
	g.set_form(false)
	check("hantu Kiriel kembali normal: pedang petir terlepas", g.rig.weapon_holder.get_node_or_null("StormSword") == null)
	g.set_immune(true)
	check("hantu kebal: selubung muncul", g._aura != null)
	g.set_immune(false)
	await t.create_timer(0.1).timeout
	check("hantu tidak kebal: selubung hilang", g._aura == null)
	# --- paket lama tanpa nomor langkah/arah tidak merusak
	g.apply(g.global_position, PI, 0.0, "ren", 100, 100, false, false)
	g.play("attack")
	g.play("dodge")
	await t.create_timer(0.5).timeout
	check("paket aksi lama ('attack' polos) tetap aman", is_instance_valid(g))
	print("CHECK SUMMARY fails=", fails)
