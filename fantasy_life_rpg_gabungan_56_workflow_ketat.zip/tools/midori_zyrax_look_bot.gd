extends RefCounted
## Foto dekat Midori & Zyrax dari depan/samping/belakang + bom meledak (butuh renderer: xvfb + opengl3, --shots=DIR).
func run(st: Node3D) -> void:
	var t := st.get_tree()
	await t.create_timer(0.8).timeout
	for e in t.get_nodes_in_group("enemies"):
		e.queue_free()
	var p: Player = st.player
	p.invuln = 999.0
	var B: Vector3 = p.global_position
	var cam := Camera3D.new()
	st.add_child(cam)
	cam.fov = 45.0
	cam.current = true
	for id in ["midori", "zyrax"]:
		GameState.unlock_character(id)
		p.set_character(id)
		p.global_position = B
		p.facing = 0.0
		await t.create_timer(1.2).timeout
		var views := {"front": B + Vector3(0.6, 1.7, 3.4), "side": B + Vector3(3.4, 1.5, 0.3), "back": B + Vector3(-0.5, 1.8, -3.6)}
		for v in views:
			cam.global_position = views[v]
			cam.look_at(B + Vector3(0, 1.15, 0), Vector3.UP)
			await t.create_timer(0.3).timeout
			await st._shot("%s_%s" % [id, v])
	# bom Zyrax meledak
	var d: Enemy = st._spawn_enemy("slime", B + Vector3(0, 0, 4.0))
	await t.create_timer(1.0).timeout
	d.hp = 99999999
	d.max_hp = 99999999
	d.set_physics_process(false)
	d.global_position = B + Vector3(0, 0, 4.0)
	p.attack_cd = 0.0
	p._act_t = 0.0
	p._combo = 2
	p.do_attack()
	p.global_position = B
	cam.global_position = B + Vector3(3.0, 3.0, -1.0)
	cam.look_at(B + Vector3(0, 0.6, 3.5), Vector3.UP)
	for tt in [0.65, 0.35]:
		await t.create_timer(tt).timeout
		await st._shot("zyrax_bom_%d" % int(tt * 100))
	print("SUMMARY fails=0")
