extends SceneTree
## Audit semua klip: jangkauan rotasi (derajat) lengan kiri/kanan, tangan, kaki, tulang belakang. Tandai klip dengan lengan nyaris diam.
const G := {"armR": ["upperarm_r", "forearm_r", "hand_r"], "armL": ["upperarm_l", "forearm_l", "hand_l"], "leg": ["thigh_l", "thigh_r"], "spine": ["spine", "chest"]}
func _range(an: Animation, bone: String) -> float:
	var best := 0.0
	for ti in an.get_track_count():
		if an.track_get_type(ti) != Animation.TYPE_ROTATION_3D: continue
		if str(an.track_get_path(ti)).get_slice(":", 1) != bone: continue
		var q0: Quaternion = an.track_get_key_value(ti, 0)
		for k in an.track_get_key_count(ti):
			best = maxf(best, rad_to_deg(q0.angle_to(an.track_get_key_value(ti, k))))
	return best
func _init() -> void:
	var AL = load("res://scripts/characters/anim_library.gd")
	var lib: AnimationLibrary = AL.get_library()
	var n := 0
	for nm in lib.get_animation_list():
		var an := lib.get_animation(nm)
		var r := {}
		for g in G:
			var m := 0.0
			for b in G[g]: m = maxf(m, _range(an, b))
			r[g] = m
		var flag := ""
		if r["armR"] < 6.0 and r["armL"] < 6.0: flag += " ARM-DIAM"
		elif r["armR"] < 6.0: flag += " R-DIAM"
		elif r["armL"] < 6.0: flag += " L-DIAM"
		if flag != "": n += 1
		print("CLIP %-30s len=%.2f R=%3d L=%3d leg=%3d sp=%3d%s" % [nm, an.length, r["armR"], r["armL"], r["leg"], r["spine"], flag])
	print("CLIP SUMMARY flagged=", n, " of ", lib.get_animation_list().size())
	quit()
