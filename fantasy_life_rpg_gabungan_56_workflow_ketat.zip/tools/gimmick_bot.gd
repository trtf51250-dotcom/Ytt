extends RefCounted
## Uji jebakan & puzzle (StageGimmicks) di stage hutan. Bot menonaktifkan gimmick otomatis, jadi bot memasangnya sendiri.
##   -- --bot=1 --botscript=gimmick_bot --stage=s1_2 --fresh
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func run(st: Node3D) -> void:
	var t := st.get_tree()
	await t.create_timer(1.0).timeout
	var g := StageGimmicks.new()
	g.name = "Gimmicks"
	st.add_child(g)
	g.setup(st)
	st.autoplay = true
	Engine.time_scale = 3.0
	var hp0: int = st.player.hp
	var t0 := Time.get_ticks_msec()
	# pantau ~70 detik waktu-game
	while (Time.get_ticks_msec() - t0) < 24000 and st.state != 2:
		await t.physics_frame
	check("gimmick terbangun", g._built, "")
	check("jebakan duri terbuat", g._traps.size() > 0, "n=%d" % g._traps.size())
	check("batang kayu aktif di hutan", g._log_on, "")
	check("puzzle rune berjalan", g._puz_spawned and g._runes.size() == 3, "ph=%d" % g._puz_ph)
	# selesaikan puzzle: tunggu fase giliran pemain lalu injak rune berurutan
	st.autoplay = false
	var guard := 0
	while g._puz_ph != 2 and guard < 3000 and st.state != 2:
		guard += 1
		await t.physics_frame
	if g._puz_ph == 2:
		var gold0: int = GameState.gold
		for idx in g._puz_seq:
			st.player.global_position = Vector3(g._rune_pos[idx].x, 0.1, g._rune_pos[idx].z)
			for i in 6:
				await t.physics_frame
			st.player.global_position = Vector3(0, 0.1, 0)
			for i in 4:
				await t.physics_frame
		check("puzzle terpecahkan (hadiah emas masuk)", g._puz_ph == 3 and GameState.gold > gold0, "ph=%d" % g._puz_ph)
	else:
		check("puzzle mencapai fase giliran pemain", false, "ph=%d" % g._puz_ph)
	Engine.time_scale = 1.0
	check("stage masih jalan / pemain valid", is_instance_valid(st.player), "")
	print("CHECK SUMMARY fails=", fails)
