#!/usr/bin/env python3
"""Membuat suara langkah kaki pemain: step_stone (jalan batu), step_grass (rumput), step_wood (lantai kayu rumah).
Jalankan: python3 tools/gen_steps.py -> assets/audio/step_*.wav (pendek, mono 22 kHz; ringan di HP)."""
import os, struct
import numpy as np

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "audio")
SR = 22050
RNG = np.random.default_rng(11)


def write_wav(name, data):
    data = np.asarray(data, dtype=np.float64)
    data = data / (np.max(np.abs(data)) or 1.0) * 0.8
    pcm = (data * 32767).astype("<i2").tobytes()
    fmt = struct.pack("<HHIIHH", 1, 1, SR, SR * 2, 2, 16)
    chunks = b"fmt " + struct.pack("<I", len(fmt)) + fmt + b"data" + struct.pack("<I", len(pcm)) + pcm
    with open(os.path.join(OUT, name + ".wav"), "wb") as f:
        f.write(b"RIFF" + struct.pack("<I", 4 + len(chunks)) + b"WAVE" + chunks)


def lp(x, a):
    y = np.zeros_like(x)
    s = 0.0
    for i, v in enumerate(x):
        s += a * (v - s)
        y[i] = s
    return y


def env(n, k):
    return np.exp(-np.arange(n) / SR * k)


# batu: ketukan tajam pendek + sedikit "tik" frekuensi menengah
n = int(SR * 0.11)
t = np.arange(n) / SR
x = lp(RNG.standard_normal(n), 0.55) * env(n, 55) + 0.5 * np.sin(2 * np.pi * 900 * t) * env(n, 90)
write_wav("step_stone", x)
# rumput: desir lembut (noise terfilter), tanpa ketukan
n = int(SR * 0.16)
x = lp(RNG.standard_normal(n), 0.18) * env(n, 22) * (1 - np.exp(-np.arange(n) / SR * 120))
write_wav("step_grass", x)
# kayu: "tok" rendah berongga
n = int(SR * 0.13)
t = np.arange(n) / SR
x = np.sin(2 * np.pi * 170 * t) * env(n, 38) + 0.5 * np.sin(2 * np.pi * 330 * t) * env(n, 60) + 0.35 * lp(RNG.standard_normal(n), 0.4) * env(n, 70)
write_wav("step_wood", x)
print("ok")
