extends RefCounted
## Bot: akses ke Desa Fajar dari kota (dialog penjaga gerbang + papan penunjuk), kota tetap utuh, lalu pindah peta betulan.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func run(l: Node3D) -> void:
	var tree := l.get_tree()
	if Engine.has_meta("desa_akses_dari_kota"):
		# bot dijalankan ulang oleh scene desa setelah pindah peta: periksa hasilnya
		await tree.create_timer(1.0).timeout
		check("pindah ke peta desa", Flow.lobby_map == "village" and str(l.get("map_id")) == "village" and l.world is VillageWorld, str(Flow.lobby_map))
		check("pemain muncul di gerbang utara desa", Vector2(l.player.global_position.x, l.player.global_position.z).distance_to(Vector2(0, -64)) < 3.0)
		Flow.lobby_map = "town"
		Engine.remove_meta("desa_akses_dari_kota")
		print("CHECK SUMMARY fails=", fails)
		return
	await tree.create_timer(1.0).timeout
	check("mulai di kota", l.map_id == "town" and l.world is LobbyWorld and not (l.world is VillageWorld))
	check("kota masih punya ExploreWorld", l.explore != null)
	var dlg: Dictionary = NpcDefs.dialogue("gate_guard")
	var has := false
	for c in dlg["start"]["choices"]:
		if c.get("action", "") == "go_village":
			has = true
	check("penjaga gerbang kota menawarkan 'Pergi ke Desa Fajar'", has)
	var sign_ok := false
	for it in l.world.interactions:
		if it["id"] == "sign_village" and it["action"] == "go_village":
			sign_ok = true
	check("papan penunjuk di luar gerbang kota -> desa", sign_ok)
	Engine.set_meta("desa_akses_dari_kota", true)
	l._run_action("go_village")
	await tree.create_timer(30.0).timeout   # scene diganti; instans bot baru yang melaporkan
