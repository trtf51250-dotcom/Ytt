extends Node
## Uji sinematik: memutar tiap sinematik (CINE_IDS, pisah koma; bawaan semua) dengan baris cepat dan menyimpan tangkapan layar tiap baris
## ke CINE_OUT/<id>_<n>.png. Mencetak "CINE <id> selesai dalam X dtk, baris=N" dan "CINE SUMMARY".
var _out := ""
var _n := 0
var _cur := ""

func _shot(_t: String) -> void:
	await get_tree().create_timer(0.55, true, false, true).timeout
	var img := get_viewport().get_texture().get_image()
	img.save_png("%s/%s_%02d.png" % [_out, _cur, _n])
	_n += 1

func _ready() -> void:
	_out = OS.get_environment("CINE_OUT")
	DirAccess.make_dir_recursive_absolute(_out)
	CinematicPlayer.fast = true
	var ids: Array = OS.get_environment("CINE_IDS").split(",") if OS.get_environment("CINE_IDS") != "" else CinematicPlayer.load_data().keys()
	var ok := 0
	for id in ids:
		_cur = id
		_n = 0
		var t0 := Time.get_ticks_msec()
		if OS.get_environment("CINE_VIA_STORY") == "1":
			# jalur sungguhan game: StoryPlayer.play -> CinematicPlayer; harus menandai adegan sudah dibaca
			GameState.flags.erase("story_" + id)
			await StoryPlayer.play(self, id)
			print("CINE ", id, " seen=", Story.seen(id))
			_n = 1
		else:
			var cp := CinematicPlayer.new()
			cp._cid = id
			cp._spec = CinematicPlayer.load_data()[id]
			cp.line_shown.connect(_shot)
			get_tree().root.add_child.call_deferred(cp)
			await cp.finished
			cp.queue_free()
		get_tree().paused = false
		print("CINE ", id, " selesai dalam ", (Time.get_ticks_msec() - t0) / 1000.0, " dtk, tangkapan=", _n)
		if _n > 0:
			ok += 1
	print("CINE SUMMARY ok=", ok, " dari ", ids.size())
	get_tree().quit()
