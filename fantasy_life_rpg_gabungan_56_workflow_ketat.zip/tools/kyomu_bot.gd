extends RefCounted
## Uji asap Kyomu di stage: ganti ke Kyomu, kombo serangan 3x, skill Vortex, ULT Gerbang Vortex, tanpa error skrip.
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1
func run(st: Node3D) -> void:
	var t := st.get_tree()
	await t.create_timer(1.0).timeout
	var p: Player = st.player
	p.set_character("kyomu")
	await t.create_timer(0.5).timeout
	check("karakter Kyomu terpasang", p.char_id == "kyomu" and p.data != null, str(p.char_id))
	check("rig punya gaya animasi kyomu", AnimLibrary.STYLE_IDS.has("kyomu"))
	var hits := 0
	for i in 3:
		if p.do_attack():
			hits += 1
		await t.create_timer(0.55).timeout
	check("kombo serangan berjalan", hits >= 1, "hits=%d" % hits)
	var sk: bool = p.do_skill()
	await t.create_timer(1.2).timeout
	check("skill Vortex dapat dipakai", sk, "skill_kind=%s" % str(p.data.skill_kind))
	var ult: bool = st.call("try_ult")
	await t.create_timer(3.2).timeout
	check("ULT Gerbang Vortex dapat dipakai", ult, "ult_kind=%s" % str(p.data.ult_kind))
	check("stage masih berjalan setelah semua efek", is_instance_valid(p) and not p.dead)
	print("SUMMARY fails=", fails)
