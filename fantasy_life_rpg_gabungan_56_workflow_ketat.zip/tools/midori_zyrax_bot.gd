extends RefCounted
## Midori (kecepatan: 2 serangan -> WAJIB dash -> penutup) & Zyrax (bom). Uji gerbang dash, bom, skill, ULTI.
##   res://scenes/stages/stage.tscn -- --bot=1 --botscript=midori_zyrax_bot --stage=s1_1 --nocine=1 --fresh
var fails := 0
func check(n: String, ok: bool, d: String = "") -> void:
	print("CHECK ", "PASS " if ok else "FAIL ", n, "  ", d)
	if not ok:
		fails += 1

func _lost(mons: Array) -> int:
	var l := 0
	for e in mons:
		l += 100000 - (int(e.hp) if is_instance_valid(e) else 0)
	return l

func _spawn(st: Node3D, base: Vector3) -> Array:
	var t := st.get_tree()
	for e in t.get_nodes_in_group("enemies"):
		e.queue_free()
	await t.create_timer(0.3).timeout
	var mons: Array = []
	for i in 4:
		var e: Enemy = st._spawn_enemy("slime", base + Vector3(-3 + i * 2.0, 0, 3.0 + (i % 2) * 1.5))
		mons.append(e)
	await t.create_timer(1.0).timeout
	for e in mons:
		e.hp = 100000
		e.max_hp = 100000
		e.set_physics_process(false)
	return mons

func _hit(p: Player, t: SceneTree) -> void:
	p.attack_cd = 0.0
	p._act_t = 0.0
	p.do_attack()
	await t.create_timer(0.3).timeout

func run(st: Node3D) -> void:
	var t := st.get_tree()
	st.autoplay = false
	await t.create_timer(0.8).timeout
	var p: Player = st.player
	p.invuln = 0.0
	var base: Vector3 = p.global_position
	for id in ["midori", "zyrax"]:
		GameState.unlock_character(id)
	var hints: Array = []
	p.combo_hint.connect(func(s: String) -> void: hints.append(s))
	# ================= MIDORI =================
	p.set_character("midori")
	p.control_enabled = true
	p.global_position = base
	p.facing = 0.0
	var cd := Data.character("midori")
	check("data midori ★6 cepat", cd != null and cd.rarity == 6 and cd.attack_cooldown <= 0.16)
	var steps: Array = ComboDefs.steps(cd)
	check("kombo 3 langkah, langkah 3 wajib dash", steps.size() == 3 and not bool(steps[0].get("need_dash", false)) and not bool(steps[1].get("need_dash", false)) and bool(steps[2].get("need_dash", false)))
	var mons: Array = await _spawn(st, base)
	# 1) TANPA dash: serang 3x -> kombo tidak berjalan (tetap langkah 1-2, tidak pernah penutup)
	var lost0 := _lost(mons)
	var finisher_seen := false
	p._pending_swing.clear()
	for i in 6:
		p.attack_cd = 0.0
		p._act_t = 0.0
		p.do_attack()
		for ps in p._pending_swing:
			if ps.get("kind", "") == "attack" and bool(ps.get("final", false)):
				finisher_seen = true
		await t.create_timer(0.3).timeout
	check("tanpa dash: penutup TIDAK pernah keluar", not finisher_seen)
	check("tanpa dash: muncul petunjuk 'Dash dulu!'", "Dash dulu!" in hints, str(hints))
	check("tanpa dash: tetap melukai (pukulan 1-2)", _lost(mons) > lost0)
	# 2) DENGAN dash: serang 2x -> dash -> serang = penutup
	await t.create_timer(1.0).timeout
	p._combo = 0
	p._dash_credit = 0.0
	hints.clear()
	await _hit(p, t)
	await _hit(p, t)
	check("setelah 2 serangan: petunjuk DASH!", "DASH!" in hints, str(hints))
	p.dodge_cd = 0.0
	check("dash jalan", p.do_dodge())
	check("dash membuka kredit kombo", p._dash_credit > 0.0 and "KOMBO SIAP!" in hints, str(hints))
	await t.create_timer(0.35).timeout
	p.attack_cd = 0.0
	p._act_t = 0.0
	p._pending_swing.clear()
	var before := _lost(mons)
	p.do_attack()
	var fin := false
	for ps in p._pending_swing:
		if ps.get("kind", "") == "attack" and bool(ps.get("final", false)):
			fin = true
	check("setelah dash: penutup Detroit Smash keluar", fin)
	await t.create_timer(1.0).timeout
	check("penutup melukai musuh", _lost(mons) > before, "hp hilang=%d" % (_lost(mons) - before))
	check("kredit dash habis dipakai", p._dash_credit <= 0.0)
	# 3) kecepatan: 2 pukulan dalam < 0.5 dtk
	p._combo = 0
	var tm := Time.get_ticks_msec()
	p.attack_cd = 0.0
	p._act_t = 0.0
	p.do_attack()
	await t.create_timer(0.17).timeout
	check("pukulan ke-2 bisa keluar < 0.4 dtk", p.attack_cd <= 0.01 or p._act_t <= 0.15, "cd=%.2f act=%.2f" % [p.attack_cd, p._act_t])
	# 4) skill & ulti Midori
	await t.create_timer(1.0).timeout
	mons = await _spawn(st, base)
	p.mana = p.max_mana
	p.skill_cd = 0.0
	check("skill Midori jalan", p.do_skill())
	await t.create_timer(1.2).timeout
	check("skill Midori melukai", _lost(mons) > 0, "hp=%d" % _lost(mons))
	p._act_t = 0.0
	mons = await _spawn(st, base)
	check("ulti Midori tersedia", st.ult_available())
	check("ulti Midori jalan", st.try_ult())
	await t.create_timer(3.0).timeout
	check("ulti Midori melukai", _lost(mons) > 0, "hp=%d" % _lost(mons))
	await st._shot("midori")

	# ================= ZYRAX =================
	await t.create_timer(1.5).timeout
	p.invuln = 0.0
	p._act_t = 0.0
	p.set_character("zyrax")
	p.global_position = base
	p.facing = 0.0
	cd = Data.character("zyrax")
	check("data zyrax ★6 bom", cd != null and cd.rarity == 6 and cd.skill_kind == "bomb_field")
	steps = ComboDefs.steps(cd)
	check("kombo zyrax tipe bom", steps.size() == 3 and steps.all(func(s): return s["t"] == "bomb"))
	check("Zyrax: dash teleport & ULTI void_requiem", cd.dodge_kind == "teleport" and cd.ult_kind == "void_requiem")
	p._act_t = 0.0
	p.dodge_cd = 0.0
	p.facing = 0.0
	var tp0: Vector3 = p.global_position
	# coba 4 arah (arena bisa punya dinding/rintangan di satu sisi); ambil lompatan terjauh
	var tmoved := 0.0
	var tp_ok := false
	for fa in [0.0, PI * 0.5, PI, PI * 1.5]:
		p.global_position = tp0
		p.velocity = Vector3.ZERO
		p._act_t = 0.0
		p.dodge_cd = 0.0
		p.facing = fa
		if p.do_dodge():
			tp_ok = true
		await t.create_timer(0.35).timeout
		tmoved = maxf(tmoved, p.global_position.distance_to(tp0))
		await t.create_timer(0.5).timeout
	check("teleport jalan", tp_ok)
	check("teleport melompat >= 5 m dalam ~0,1 dtk (arah terbaik)", tmoved >= 5.0, "jarak=%.1f" % tmoved)
	check("badan tetap terlihat (tidak berkedip)", p.rig.visible)
	p.global_position = tp0
	p.dodge_cd = 0.0
	mons = await _spawn(st, base)
	before = _lost(mons)
	await _hit(p, t)
	var bombs: Array = t.get_nodes_in_group("bombs")
	check("serangan melempar bom (node Bom ada)", bombs.size() >= 1, "bom=%d" % bombs.size())
	await t.create_timer(1.2).timeout
	check("bom meledak & melukai", _lost(mons) > before, "hp hilang=%d" % (_lost(mons) - before))
	await t.create_timer(0.8).timeout
	check("bom hilang setelah meledak", t.get_nodes_in_group("bombs").size() == 0)
	before = _lost(mons)
	p._combo = 2
	await _hit(p, t)
	await t.create_timer(1.6).timeout
	check("penutup 3 Bom Void Besar melukai", _lost(mons) > before, "hp hilang=%d" % (_lost(mons) - before))
	p.mana = p.max_mana
	p.skill_cd = 0.0
	mons = await _spawn(st, base)
	check("skill Ranjau Void jalan", p.do_skill())
	var maxb := 0
	for i in 20:                                          # skill baru melempar saat impak animasi -> pantau jumlah bom tertinggi
		await t.create_timer(0.1).timeout
		maxb = maxi(maxb, t.get_nodes_in_group("bombs").size())
	check("skill menjatuhkan >= 8 bom sekaligus", maxb >= 8, "maks bom=%d" % maxb)
	check("jangkauan skill/ULTI Zyrax besar (★6)", cd.skill_range >= 9.0 and cd.ult_range >= 16.0, "skill=%.1f ult=%.1f" % [cd.skill_range, cd.ult_range])
	await t.create_timer(1.2).timeout
	check("skill melukai >1 musuh", mons.filter(func(e): return is_instance_valid(e) and int(e.hp) < 100000).size() >= 1, "terluka=%d" % mons.filter(func(e): return is_instance_valid(e) and int(e.hp) < 100000).size())
	p._act_t = 0.0
	mons = await _spawn(st, base)
	check("ulti Zyrax jalan", st.try_ult())
	await t.create_timer(1.0).timeout
	check("ulti Zyrax: sayap bayangan muncul", p.rig.get_node_or_null("VoidWings") != null)
	await t.create_timer(2.2).timeout
	check("ulti Zyrax melukai", _lost(mons) > 0, "hp=%d" % _lost(mons))
	await st._shot("zyrax")
	print("SUMMARY fails=", fails)
