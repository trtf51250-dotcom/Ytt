#!/usr/bin/env python3
"""Emblem dada Kyomu: aksara 虚 + tulisan KYOMU, putih piksel di atas transparan -> assets/hero/kyomu_emblem.png (31x34).
Pakai:  python3 tools/gen_kyomu_emblem.py   (butuh pillow + font CJK, mis. Noto Sans CJK)"""
import os
from PIL import Image, ImageDraw, ImageFont
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "assets", "hero", "kyomu_emblem.png")
W, H = 31, 34
img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
cands = ["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"]
fp = next((c for c in cands if os.path.exists(c)), None)
if fp is None:
    raise SystemExit("font CJK tidak ditemukan")
font = ImageFont.truetype(fp, 25)
g = Image.new("L", (30, 30), 0)
ImageDraw.Draw(g).text((15, 13), "虚", font=font, fill=255, anchor="mm")
for y in range(30):
    for x in range(30):
        if g.getpixel((x, y)) > 110:
            img.putpixel((x, y), (245, 242, 255, 255))
L = {
 "K": ["#...#", "#..#.", "###..", "#..#.", "#...#"], "Y": ["#...#", ".#.#.", "..#..", "..#..", "..#.."],
 "O": [".###.", "#...#", "#...#", "#...#", ".###."], "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#"],
 "U": ["#...#", "#...#", "#...#", "#...#", ".###."],
}
x0, y0 = 1, 28
for i, ch in enumerate("KYOMU"):
    for r, row in enumerate(L[ch]):
        for c, v in enumerate(row):
            if v == "#":
                img.putpixel((x0 + i * 6 + c, y0 + r), (245, 242, 255, 255))
img.save(OUT)
print("kyomu_emblem.png")
