"""Naskah bagian B: Bab 2 (Bayang di Kedalaman), Bab 3 (Altar Kehampaan: boss), Bab 4 (Kuil Bayangan)."""


def build(S, C, B, scenes):
    # ------------------------------------------------------------------ BAB 2
    S("s2_1_intro", [
        ("Narator", "Di bawah Gua Kristal, lorong menyala merah oleh bara yang bukan api. Udara berat, dan dinding seperti menahan napas."),
        ("Brann", "Panas, berat, dan sunyi. Aku lebih suka monster yang berisik."),
        ("Lyra", "Serpihan di tanganmu bergetar, Ren. Kita di jalur yang benar."),
        ("Ren", "Aku bisa mendengar lagu itu lebih jelas. Makin dalam, makin utuh. Tapi selalu putus di nada yang sama."),
    ], title="Lorong Bayangan", chapter="Bab 2: Bayang di Kedalaman")
    S("s2_1_outro", [
        ("Narator", "Di dinding lorong tergores sebaris tulisan tangan yang rapi."),
        ("Lyra", "Aku kenal tulisan ini. Guru Lucien."),
        ("Lyra", "'Kehampaan menelan yang disimpan sendirian. Ingat bersama-sama.' Ia lewat sini setahun lalu, dan sengaja menuliskannya untuk dibaca seseorang."),
        ("Brann", "Untukmu."),
        ("Lyra", "...Untuk siapa pun yang cukup keras kepala untuk mengikutinya."),
    ], title="Tulisan di Dinding", stage="s2_1", when="outro")
    S("s2_2_intro", [
        ("Narator", "Retakan bara menjalar di lantai jurang. Panasnya terasa, tetapi tidak ada asap, tidak ada abu."),
        ("Lyra", "Ini bukan api. Ini bekas Kehampaan yang terbakar sendiri. Guruku menulis soal ini sebelum ia menghilang meneliti segel. Namanya Lucien, dan dialah yang mengajariku mencatat semuanya."),
        ("Ren", "Dan kau tak pernah cerita."),
        ("Lyra", "Aku belum punya jawabannya. Aku tidak suka menyerahkan cerita yang belum selesai."),
        ("Brann", "Kalau begitu kita selesaikan bersama. Satu langkah dulu: keluar dari jurang ini hidup-hidup."),
    ], title="Bara yang Bukan Api")
    S("s2_3_intro", [
        ("Narator", "Di ujung lorong berdiri gerbang batu setinggi tiga manusia. Dari baliknya terdengar dengusan berat dan getaran yang merambat ke kaki."),
        ("Brann", "Itu pasti sarangnya. Siapkan ramuan, kita tidak tahu apa yang menunggu."),
        ("Ren", "Apa pun itu, ingat: ia korban, bukan musuh. Kita pulang bertiga, atau tidak sama sekali."),
        ("Lyra", "Setuju. Dan kalau aku mulai bicara terlalu banyak soal teori, tolong ingatkan aku untuk menghindar."),
    ], title="Sebelum Sarang")
    S("s2_4_intro", [
        ("Narator", "Pos penambang lama masih berasap. Di dinding, ada tanda tangan yang dikenali Brann: tiga garis dan satu titik."),
        ("Brann", "Tanda ayahku untuk 'pos aman'. Dia pernah mengajariku menandainya. Sekarang tempat ini justru jadi sarang."),
        ("Lyra", "Berarti Kehampaan lebih dulu sampai daripada pesan ayahmu. Bersihkan, dan tanda itu berarti lagi."),
    ], title="Reruntuhan Bara")
    S("s2_boss_intro", [
        ("Narator", "Sebuah raungan mengguncang sarang. Penguasa Gua, makhluk raksasa pelindung urat kristal, menatap kalian dengan mata berbara."),
        ("Brann", "Ia melindungi urat kristal terakhir di wilayah ini. Itu sebabnya Kehampaan mengincarnya."),
        ("Ren", "Ia bukan musuh kita. Tapi kita harus menenangkannya sebelum ia menghancurkan urat itu."),
        ("Lyra", "Kalau ia murka, ia memanggil kelelawar. Fokus, jangan kepung dirinya!"),
    ], title="Sarang Penguasa Gua")
    S("s2_boss_outro", [
        ("Narator", "Bara di mata sang Penguasa padam. Di balik tubuhnya, dinding sarang memperlihatkan prasasti kuno."),
        ("Lyra", "Aksara Penjaga Pertama! 'Tiga memikul segel: Yang Menanggung, Yang Mengikat, Yang Menyanyi. Segel berdiri selama ketiganya setia pada janji.'"),
        ("Brann", "Setia pada janji. Dan sekarang?"),
        ("Lyra", "Sisanya terkikis. Hanya satu baris yang terbaca: 'Yang Menyanyi pergi lebih dulu. Lagunya tidak selesai.'"),
        ("Ren", "Lagu yang tidak selesai. Itu lagu dari kristal. Serpihan ini ingin pulang ke altarnya, dan tandaku menunjuk ke sana."),
        ("Brann", "Kalau begitu kita antar. Ke ujung mana pun."),
    ], title="Prasasti di Dinding", cine="s2_boss_outro")
    C("s2_boss_outro", "cave", ["ren", "lyra", "brann"], title="Prasasti di Dinding", chapter="Bab 2", fx={1: ["mark"], 4: ["shard"]})

    # ------------------------------------------------------------------ BAB 3 (s3_1..s3_3 tetap); bos ditulis ulang
    S("s3_boss_intro", [
        ("Narator", "Lantai gua menghilang. Sebuah altar melayang di atas kehampaan, dikelilingi tengkorak-tengkorak yang berputar pelan."),
        ("Dewa Wither", "Kalian membawa serpihanku... setelah ribuan tahun..."),
        ("Lyra", "Ia bicara! Dewa Wither adalah Yang Menanggung, Penjaga Pertama. Ia menelan Kehampaan ke dalam tubuhnya agar kota bisa berdiri."),
        ("Dewa Wither", "Segel melemah dan aku kehilangan diriku. Hentikan aku sebelum Kehampaan menelan dunia."),
        ("Ren", "Kami tidak akan membiarkanmu sendirian. Bertahanlah, kami akan menyegelnya kembali!"),
    ], title="Altar Kehampaan", cine="s3_boss_intro")
    C("s3_boss_intro", "altar", ["ren", "lyra", "brann"], title="Altar Kehampaan", chapter="Bab 3", fx={0: ["pillar"], 1: ["shake"]})
    S("s3_boss_outro", [
        ("Narator", "Dewa Wither jatuh berlutut. Tengkorak-tengkorak di sekelilingnya lenyap menjadi cahaya, dan Kehampaan surut dari altar."),
        ("Dewa Wither", "Terima kasih, anak bintang. Tandamu milik Yang Menyanyi. Ia menitipkan sebagian segelnya pada garis keturunannya."),
        ("Ren", "Yang Menyanyi? Itu... keluargaku?"),
        ("Dewa Wither", "Aku tidak tahu. Ingatanku pun dimakan. Tapi tanda itu tidak pernah salah memilih."),
        ("Dewa Wither", "Satu peringatan. Yang Mengikat memilih membuat dunia tak pernah berubah, supaya tak ada yang hilang lagi. Ia sudah lama kehilangan sesuatu. Waspadalah."),
        ("Lyra", "Yang Mengikat. Sebuah menara merah di utara. Catatan guruku menyebutnya."),
        ("Narator", "Dewa Wither lenyap menjadi cahaya, dan untuk pertama kalinya kristal di bawah Aurelia berhenti berkedip. Namun di kejauhan, sebuah kuil merah mulai bersinar dalam gelap."),
        ("Ren", "Seseorang melemahkan segel dari luar. Kita belum selesai."),
    ], title="Segel yang Baru", cine="s3_boss_outro")
    C("s3_boss_outro", "altar", ["ren", "lyra", "brann"], title="Segel yang Baru", chapter="Bab 3", fx={1: ["flare", "mark"], 6: ["pillar"]})

    # ------------------------------------------------------------------ BAB 4
    S("s4_1_intro", [
        ("Narator", "Jauh di utara Aurelia, kabut membuka dan memperlihatkan gerbang pagoda merah. Di tiap tiang berdiri sosok bertopeng putih tanpa wajah."),
        ("Lyra", "Tarekat Topeng Putih. Mereka memuja Kehampaan, dan merekalah yang melemahkan segel dari luar."),
        ("Brann", "Pelakunya bersembunyi di sini. Biar aku yang di garis depan."),
        ("Pengikut Berkerudung", "Anak bintang telah datang! Mata Kehampaan akan terbuka malam ini!"),
        ("Kyomu", "Bukan malam ini. Kalau kalian mau hidup, ikuti aku dan jangan bicara terlalu keras."),
        ("Ren", "Siapa kau?"),
        ("Kyomu", "Kyomu. Aku dulu memakai topeng itu. Sekarang separuh wajahku sendiri sudah tak kuingat."),
        ("Brann", "Kita percaya padanya?"),
        ("Kyomu", "Tidak. Tapi tidak ada orang lain yang tahu jalan ke aula utama."),
    ], title="Gerbang Kuil Merah", chapter="Bab 4: Kuil Bayangan", cine="s4_1_intro")
    C("s4_1_intro", "tower", ["ren", "lyra", "brann", "kyomu"], title="Gerbang Kuil Merah", chapter="Bab 4: Kuil Bayangan", fx={0: ["shake"]})
    S("s4_2_intro", [
        ("Narator", "Halaman dalam dipenuhi ribuan lentera. Di tengahnya, seorang samurai berjubah hitam menahan tiga ronin sekaligus, tebasannya tenang seperti orang berdoa."),
        ("Kuroha", "Kalian terlambat dua tarikan napas. Tak apa. Aku Kuroha, dari timur. Ronin berjubah merah itu dulu guruku."),
        ("Lyra", "Ksatria Rantai dan ronin tidak mundur selangkah pun. Seseorang mengikat mereka pada kehendaknya."),
        ("Brann", "Kau mau kami bantu memutus rantai itu?"),
        ("Kuroha", "Aku tidak butuh ingatan untuk menebas. Tapi aku ingin mengingat wajah guruku. Itu saja."),
        ("Ren", "Kalau begitu kita putus satu per satu."),
    ], title="Seribu Lentera")
    S("s4_3_intro", [
        ("Narator", "Aula utama kuil. Ratusan pengikut berlutut sambil membisikkan doa, dan tiap doa menghapus satu nama dari kepala mereka."),
        ("Kyomu", "Satu nama per doa. Pada akhirnya yang tersisa hanya topeng. Itu yang mereka sebut kedamaian."),
        ("Lyra", "Uranos. Penyihir yang diusir Serikat karena ingin menukar dunia dengan Kehampaan."),
        ("Ren", "Dia ada di balik pintu terakhir. Ayo."),
    ], title="Aula Bayangan")
    S("s4_4_intro", [
        ("Narator", "Lorong doa panjang bergema. Pengikut yang masih setengah sadar berjalan lamban, topengnya retak."),
        ("Ren", "Kita tidak perlu melukai yang tak menyerang. Tapi yang menghalangi, kita singkirkan."),
    ], title="Lorong Doa")
    S("s4_4_outro", [
        ("Narator", "Topeng-topeng retak berjatuhan. Belasan wajah tanpa nama menatap kosong ke arah kalian."),
        ("Kyomu", "Beri mereka nama apa saja. Nama pertama selalu cukup. Namaku sendiri cuma kata untuk 'hampa'. Tapi sekarang ada yang memanggilnya, dan itu sudah cukup."),
        ("Lyra", "Aku catat. Satu nama, satu halaman. Itu janjiku."),
    ], title="Nama Pertama", stage="s4_4", when="outro")
    S("s4_boss_intro", [
        ("Narator", "Di singgasana kuil, seorang penyihir berkerudung berdiri membelakangi cahaya. Lingkaran sihir berputar pelan di belakang kepalanya."),
        ("Uranos", "Akhirnya kunci hidup itu datang sendiri. Aku tak perlu mencarimu lagi, Ren."),
        ("Ren", "Kau yang melemahkan segel dan membuat Dewa Wither menderita selama ini?"),
        ("Uranos", "Aku hanya membuka pintu yang sudah retak. Istri dan anakku diambil wabah, dan hanya Kehampaan yang menawarkan akhir dari rasa sakit itu."),
        ("Ren", "Itu bukan akhir. Itu cuma berhenti merasakannya."),
        ("Uranos", "Apa bedanya? Mata Kehampaan... terbukalah."),
        ("Lyra", "Jangan tatap matanya terlalu lama, atau sihirnya menelan pikiranmu!"),
    ], title="Uranos, Penyihir Kehampaan")
    S("s4_boss_outro", [
        ("Narator", "Uranos terjatuh, kerudungnya terlepas. Lingkaran sihir di belakangnya retak satu per satu lalu padam."),
        ("Uranos", "Kalian pikir akulah dalangnya? Aku hanya pembuka pintu. Yang memegang kuncinya adalah Dia di menara."),
        ("Kyomu", "Rantai merah di leher Uranos. Itu berasal dari sana. Dia hanya boneka yang tahu dirinya boneka."),
        ("Ren", "Kau kehilangan. Aku mengerti. Tapi bukan dengan melupakan, Uranos."),
        ("Uranos", "Kehampaan mulai... melepaskan. Aku... ingat sekarang. Namanya Mirel. Katakan pada siapa pun... namanya Mirel."),
        ("Narator", "Tubuh Uranos memudar menjadi debu ungu. Dari balik kuil, sebuah menara raksasa terlihat membelah langit, dililit rantai merah menyala."),
        ("Lyra", "Mirel. Kucatat, Uranos. Satu halaman penuh."),
        ("Ren", "Tandaku bergetar kuat sekali. Dia memanggilku. Aku sudah lama bertanya siapa diriku. Mungkin jawabannya menunggu di puncak sana."),
        ("Kuroha", "Aku ikut sampai guruku terlepas."),
    ], title="Rantai di Balik Kerudung", cine="s4_boss_outro")
    C("s4_boss_outro", "tower", ["ren", "lyra", "brann", "kyomu", "kuroha"], title="Rantai di Balik Kerudung", chapter="Bab 4", fx={1: ["shake"], 5: ["king"]})

    # ------------------------------------------------------------------ dialog tengah pertarungan: Bab 2-4
    B("s2_1", [("w0", "Lyra", "Bara ini tidak membakar, tapi musuhnya menyukainya."), ("w1", "Brann", "Lorongnya menyempit. Jangan mundur ke dinding!"), ("low", "Ren", "Aku masih bisa... tapi sebaiknya minum ramuan."), ("done", "Lyra", "Itu tulisan tangan Guru Lucien. Aku yakin.")])
    B("s2_2", [("w0", "Lyra", "Retakan bara bisa muncul di bawahmu. Selalu bergerak!"), ("zone", "Lyra", "Segel kecil di lantai. Berdiri di dalamnya, aku tahan mereka!"), ("done", "Brann", "Kau luar biasa, Lyra."), ("low", "Brann", "Ren, mundur!")])
    B("s2_3", [("w0", "Brann", "Gerbang itu bergetar. Sarangnya makin dekat."), ("survive", "Ren", "Tahan sampai gerbang berhenti bergetar!"), ("done", "Lyra", "Aman. Tarik napas dulu."), ("low", "Lyra", "Jangan paksa!")])
    B("s2_4", [("w0", "Brann", "Tanda ayahku masih ada di dinding. Pos ini bisa aman lagi."), ("hunt", "Lyra", "Yang bersinar jingga itu pemimpinnya. Tumbangkan dia dulu!"), ("done", "Brann", "Beres. Tanda ayahku berarti lagi."), ("low", "Ren", "Aku butuh ramuan!")])
    B("s2_boss", [("boss", "Ren", "Tenanglah, Penguasa. Kami bukan musuhmu."), ("low", "Lyra", "Dia memanggil kelelawar! Jangan kepung!")])
    B("s3_1", [("w0", "Lyra", "Jalan menuju altar. Hawa Kehampaan makin pekat."), ("zone", "Lyra", "Lingkaran segel! Berdiri di dalamnya sampai terisi!"), ("done", "Ren", "Retakan itu bernapas. Kita harus cepat."), ("low", "Brann", "Tahan, Ren!")])
    B("s3_2", [("w0", "Brann", "Jembatan ini kuat selama kau dekat, Ren. Jangan menjauh!"), ("survive", "Lyra", "Serpihan jembatan akan stabil sebentar lagi. Bertahan!"), ("done", "Lyra", "Seberang jurang. Kita sampai."), ("low", "Brann", "Jangan jatuh!")])
    B("s3_3", [("w0", "Lyra", "Gema para pencari. Mereka tidak bermaksud jahat."), ("hunt", "Ren", "Pemimpinnya bergema paling keras. Tumbangkan dia!"), ("done", "Ren", "Mereka akan kuingat. Semuanya."), ("low", "Lyra", "Minum ramuan!")])
    B("s3_boss", [("boss", "Ren", "Bertahanlah, Wither. Kami di sini."), ("low", "Brann", "Jiwa-jiwanya memanggil! Hindari!")])
    B("s4_1", [("w0", "Kyomu", "Topeng tanpa wajah. Mereka tak punya yang bisa kau lukai selain topengnya."), ("zone", "Kyomu", "Lingkaran segel di lantai. Berdiri di situ, aku yang menahan mereka."), ("done", "Kyomu", "Kau tidak payah."), ("low", "Brann", "Ren, mundur!")])
    B("s4_2", [("w0", "Kuroha", "Yang berjubah merah itu bagianku."), ("survive", "Kuroha", "Bertahanlah! Lentera ini akan padam satu per satu."), ("done", "Kuroha", "Satu rantai putus. Masih banyak."), ("low", "Lyra", "Ren, minum ramuan!")])
    B("s4_3", [("w0", "Lyra", "Dengar doa mereka? Itu yang menghapus nama."), ("zone", "Kyomu", "Berdiri di lingkaran, segel membuat doa mereka pecah."), ("done", "Kyomu", "Doa mereka retak. Bagus."), ("low", "Brann", "Tahan!")])
    B("s4_4", [("w0", "Ren", "Kita tidak melukai yang tak menyerang."), ("hunt", "Kyomu", "Pemimpinnya yang bertanduk. Habisi dia dan sisanya buyar."), ("done", "Lyra", "Aku catat nama-nama mereka nanti."), ("low", "Lyra", "Ren!")])
    B("s4_boss", [("boss", "Uranos", "Mata Kehampaan... terbukalah."), ("low", "Lyra", "Jangan tatap matanya!")])
