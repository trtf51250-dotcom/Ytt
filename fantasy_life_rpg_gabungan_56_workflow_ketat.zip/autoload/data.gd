extends Node
## Autoload "Data": memuat semua resource (.tres) karakter, item, quest, dan stage sekali saja.

const CHAR_ORDER := ["ren", "lyra", "brann", "sera", "zeya", "ember", "hakuya", "vael", "lucien", "wenyu", "kuroha", "aion", "kyomu", "kiriel", "midori", "zyrax"]

var characters: Dictionary = {}     # id -> CharacterData
var items: Dictionary = {}          # id -> ItemData
var quests: Dictionary = {}         # id -> QuestData
var stages: Dictionary = {}         # id -> StageData
var quest_order: Array = []         # id quest terurut
var field_ids: Array = []           # wilayah jelajah bebas (id berawalan f_), terpisah dari stage petualangan
var stage_order: Array = []         # id stage petualangan terurut (tanpa arena PVP)
var adventure_order: Array = []     # alur Adventure berurutan: stage petualangan dengan wilayah jelajah disisipkan setelah stage pembukanya
var village_order: Array = []       # alur cerita Desa Fajar (stage berawalan v<angka>_), terpisah dari alur Kastil/Aurelia
var pvp_arenas: Array = []          # id arena PVP (awalan "pvp_")


func _ready() -> void:
	_load_dir("res://resources/characters", characters)
	_load_dir("res://resources/items", items)
	_load_dir("res://resources/quests", quests)
	_load_dir("res://resources/stages", stages)
	quest_order = quests.keys()
	quest_order.sort_custom(func(a, b): return quests[a].order < quests[b].order)
	stage_order = stages.keys()
	stage_order.sort_custom(func(a, b): return stages[a].id < stages[b].id)
	pvp_arenas = stage_order.filter(func(i): return str(i).begins_with("pvp_"))
	field_ids = stage_order.filter(func(i): return str(i).begins_with("f_"))
	village_order = stage_order.filter(func(i): return is_village_stage(str(i)))
	village_order.sort_custom(func(a, b): return stages[a].order_key() < stages[b].order_key())
	stage_order = stage_order.filter(func(i): return not str(i).begins_with("pvp_") and not str(i).begins_with("f_") and not is_village_stage(str(i)))
	adventure_order = []
	for sid in stage_order:
		adventure_order.append(sid)
		for fid in field_ids:
			if stages[fid].unlock_after == sid:
				adventure_order.append(fid)
	if characters.is_empty() or items.is_empty():
		push_error("Data: resource kosong. Jalankan tools/generate_resources.gd (lihat README).")


func _load_dir(dir: String, into: Dictionary) -> void:
	# Pada build ekspor, file .tres tampil sebagai ".tres.remap": buang akhiran itu.
	for f in DirAccess.get_files_at(dir):
		var n := f.trim_suffix(".remap")
		if not n.ends_with(".tres"):
			continue
		var res: Resource = load("%s/%s" % [dir, n])
		if res != null and "id" in res:
			into[res.id] = res


## Stage cerita Desa Fajar: id berawalan "v" + angka (v1_1 ... v1_boss).
static func is_village_stage(id: String) -> bool:
	return id.length() > 2 and id[0] == "v" and id[1].is_valid_int()


func character(id: String) -> CharacterData:
	return characters.get(id)


func item(id: String) -> ItemData:
	return items.get(id)


func quest(id: String) -> QuestData:
	return quests.get(id)


func stage(id: String) -> StageData:
	return stages.get(id)


func character_ids() -> Array:
	var out: Array = []
	for id in CHAR_ORDER:
		if characters.has(id):
			out.append(id)
	return out


func shop_items(shop: String) -> Array:
	var out: Array = []
	for id in items:
		var it: ItemData = items[id]
		if it.shop == shop and it.buy_price > 0:
			out.append(it)
	out.sort_custom(func(a, b): return a.buy_price < b.buy_price)
	return out


func gacha_pool(rarity: int) -> Array:
	var out: Array = []
	for id in items:
		var it: ItemData = items[id]
		if it.in_gacha and it.rarity == rarity:
			out.append(it)
	return out


## Perlengkapan (senjata/armor/aksesori) dengan bintang tertentu, untuk hadiah gacha item.
func equipment_by_rarity(rarity: int) -> Array:
	var out: Array = []
	for id in items:
		var it: ItemData = items[id]
		if it.rarity == rarity and it.type in ["weapon", "armor", "accessory"]:
			out.append(it)
	return out


## Senjata awal (rarity 1) untuk kelas senjata tertentu.
func starter_weapon(weapon_class: String) -> String:
	for id in items:
		var it: ItemData = items[id]
		if it.type == "weapon" and it.rarity == 1 and it.weapon_class == weapon_class:
			return id
	return ""


## Daftar stage yang bisa dipilih di room multiplayer: stage petualangan yang terbuka + arena PVP.
func room_stage_ids() -> Array:
	var out: Array = []
	for id in stage_order:
		if GameState.stage_unlocked(id):
			out.append(id)
	return out + pvp_arenas
