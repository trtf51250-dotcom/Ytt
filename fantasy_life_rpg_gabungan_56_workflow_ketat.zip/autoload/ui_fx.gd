extends Node
## UI_FX: umpan balik sentuh untuk SEMUA tombol, tanpa mengubah kode panel satu per satu.
## Setiap Button yang masuk ke pohon scene menciut sedikit saat ditekan dan memantul halus saat dilepas, sehingga menu terasa
## merespons. Hanya Button yang disentuh (SlantTile, kartu gacha, dan Control lain punya animasi sendiri dan tidak diubah).
## Nonaktif pada bot/uji (--bot=1) dan bila tombol memberi meta "no_fx".

const PRESS_SCALE := Vector2(0.94, 0.94)
const DOWN_TIME := 0.07
const UP_TIME := 0.18

var _on := true


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS                 # tetap hidup saat game dijeda (menu)
	_on = UiTheme.animations_on()
	if _on:
		get_tree().node_added.connect(_on_node_added)


func _on_node_added(n: Node) -> void:
	if n is Button and not n.has_meta("ui_fx") and not n.has_meta("no_fx"):
		n.set_meta("ui_fx", true)
		var b := n as Button
		b.button_down.connect(_down.bind(b))
		b.button_up.connect(_up.bind(b))
		b.visibility_changed.connect(_reset_if_hidden.bind(b))   # disembunyikan saat ditekan -> button_up tak datang; jangan tertinggal menciut


func _kill(b: Button) -> void:
	if b.has_meta("ui_fx_tw"):
		var old = b.get_meta("ui_fx_tw")
		if old is Tween and old.is_valid():
			old.kill()


func _reset_if_hidden(b: Button) -> void:
	if is_instance_valid(b) and not b.is_visible_in_tree() and b.scale != Vector2.ONE:
		_kill(b)
		b.scale = Vector2.ONE


func _down(b: Button) -> void:
	if not is_instance_valid(b) or b.disabled:
		return
	_kill(b)
	b.pivot_offset = b.size * 0.5
	var tw := b.create_tween()
	b.set_meta("ui_fx_tw", tw)
	tw.tween_property(b, "scale", PRESS_SCALE, DOWN_TIME).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)


func _up(b: Button) -> void:
	if not is_instance_valid(b):
		return
	_kill(b)
	var tw := b.create_tween()
	b.set_meta("ui_fx_tw", tw)
	tw.tween_property(b, "scale", Vector2.ONE, UP_TIME).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
