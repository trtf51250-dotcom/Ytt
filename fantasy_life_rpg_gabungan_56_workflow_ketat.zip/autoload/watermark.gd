extends CanvasLayer
## Watermark "Yumantara Official": teks tipis semi-transparan di pojok kiri-bawah layar, tampil di SEMUA scene (judul, lobi, stage, loading).
## Tidak menangkap sentuhan (mouse_filter IGNORE) sehingga tidak mengganggu kontrol. Ubah TEXT / ALPHA di bawah bila perlu.

const TEXT := "Yumantara Official"
const ALPHA := 0.4
const FONT_SIZE := 16
const MARGIN := 14.0

var _label: Label


func _init() -> void:
	layer = 100                                  # di atas HUD (10), panel (20), dan cerita (40)
	process_mode = Node.PROCESS_MODE_ALWAYS      # tetap tampil saat game dijeda


func _ready() -> void:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	_label = Label.new()
	_label.text = TEXT
	_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var m := UiTheme.safe_insets()               # hormati poni/notch & gesture bar
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_label.anchor_left = 0.0
	_label.anchor_right = 0.0
	_label.anchor_top = 1.0
	_label.anchor_bottom = 1.0
	_label.offset_left = MARGIN + float(m["left"])
	_label.offset_right = MARGIN + float(m["left"]) + 260.0
	_label.offset_top = -(MARGIN + 22.0 + float(m["bottom"]))
	_label.offset_bottom = -(MARGIN + float(m["bottom"]))
	_label.add_theme_font_size_override("font_size", FONT_SIZE)
	_label.add_theme_color_override("font_color", Color(1, 1, 1, ALPHA))
	_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, ALPHA * 0.9))
	_label.add_theme_constant_override("outline_size", 3)
	root.add_child(_label)
