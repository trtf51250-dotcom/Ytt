extends Node
## Autoload "GameState": seluruh data pemain (profil, mata uang, roster, party, inventori, equipment,
## quest, progres stage), pengaturan, serta simpan/muat. Semua UI & sistem membaca/menulis lewat sini.

signal changed(kind: String)   # "profile" "currency" "inventory" "equipment" "party" "quest" "stage" "settings" "roster"
signal cheat_detected(kind: String, msg: String)   # deteksi kecurangan (hanya peringatan; tidak ada blokir)
signal autosaved                                    # simpan otomatis berhasil (untuk indikator kecil)

# ---- penyimpanan: SATU file save saja (tanpa slot SV, tanpa cadangan .bak). Hapus file = progres benar-benar hilang.
const SAVE_PATH := "user://save.dat"
const LEGACY_SANCTION_PATH := "user://sanction.dat"   # sisa sistem blokir lama: dihapus otomatis saat game dibuka (TIDAK ada blokir akun lagi)
const DEVICE_KEY_PATH := "user://device.key"      # hanya dipakai bila perangkat tidak memberi ID (terhapus bersama data aplikasi)
const WORLD_NAME := "Aurelia"
var save_path := ""                # "" = belum memulai (tidak menulis ke disk)
const SETTINGS_PATH := "user://fantasy_life_settings.json"
const SAVE_VERSION := 1
const LOGIN_DAYS := 3
## Hadiah per hari (hari ke-3 = karakter Zeya). Satu hari kalender = satu klaim; tidak harus berturut-turut.
const LOGIN_REWARDS := [
	{"gold": 1000, "diamonds": 100, "items": {"p_small": 3}, "label": "1.000 Emas, 100 Berlian, 3 Ramuan Kecil"},
	{"gold": 1500, "diamonds": 150, "items": {"p_big": 2}, "label": "1.500 Emas, 150 Berlian, 2 Ramuan Besar"},
	{"gold": 0, "diamonds": 200, "items": {}, "character": "zeya", "label": "Karakter Zeya + 200 Berlian"},
]
const START_GOLD := 800            # modal awal dunia baru
const START_DIAMONDS := 1000       # = 1 tarikan 10x + 1 tarikan tunggal
const PARTY_SIZE := 4
const MAX_LEVEL := 50
const SLOTS := ["weapon", "armor", "accessory"]
const GACHA_SINGLE := 100
const GACHA_TEN := 900
const SHARDS_PER_STAR := 10
const MAX_STARS := 5
const STAR_STEP := 0.12                 # tambahan statistik per bintang kebangkitan (pengali dasar)

# ---- identitas (offline): ID dibuat sekali & tidak bisa diubah dari dalam game; nama boleh diganti
const NAME_MAX := 14
var player_id := ""               # mis. FL-7K3M-Q9XA ; ACAK saat dunia baru dibuat, disimpan DI DALAM save (hapus save = ID baru)
# ---- profil
var player_name := "Ren"
var level := 1
var exp := 0
var gold := START_GOLD
var diamonds := START_DIAMONDS
# ---- koleksi
var roster: Dictionary = {}       # id karakter -> {"stars": int, "shards": int}
var party: Array = []             # id karakter, indeks 0 = pemimpin
var inventory: Dictionary = {}    # id item -> jumlah (item yang TIDAK sedang dipakai)
var equipment: Dictionary = {}    # id karakter -> {"weapon","armor","accessory": id item, "weapon_plus": int}
# ---- progres
var quests: Dictionary = {}       # id quest -> {"state": "active"|"ready"|"claimed", "progress": int}
var stages: Dictionary = {}       # id stage -> {"cleared": bool, "stars": int}
var flags: Dictionary = {}
var stats: Dictionary = {"kills": 0, "stages_cleared": 0, "pulls": 0, "gold_spent": 0, "upgrades": 0, "pvp_win": 0, "pvp_loss": 0, "pvp_draw": 0, "pvp_kills": 0}
var pity := 0               # pity gacha KARAKTER
var pity_item := 0          # pity gacha ITEM (terpisah)
var play_time := 0.0
var login_days := 0               # jumlah hari hadiah login yang sudah diambil (0..LOGIN_DAYS)
var login_last := ""              # tanggal "YYYY-MM-DD" hadiah terakhir diambil
var daily := {"date": "", "m": [], "bonus": false}   # misi harian: m = [{kind, need, p, c}]
var ach: Dictionary = {}          # id pencapaian yang sudah diklaim -> true
# ---- runtime (tidak disimpan)
var current_stage_id := ""
var last_result: Dictionary = {}
var settings: Dictionary = {}

var _save_queued := false
var _loaded_ok := false
var seen_unix := 0                  # waktu (detik unix UTC) tertinggi yang pernah tercatat di save -> deteksi jam diputar mundur
var _cheat_pending: Array = []      # temuan sebelum ada save (mis. impor kode dari layar judul); masuk ke save pada simpan berikutnya
var _cheat_toasted: Dictionary = {} # jenis temuan yang sudah diberitahukan di sesi ini (tidak diulang-ulang)
var _autosave_t := 0.0
var _last_save_ok := false
var _ind: PanelContainer
var _ind_tw: Tween
var _fake_date := ""               # hanya uji otomatis (--fresh --date=YYYY-MM-DD)
var _fake_now := ""               # hanya uji otomatis (--fresh --now=YYYY-MM-DDTHH:MM): memalsukan jam perangkat untuk event berjadwal
var _volatile := false             # uji otomatis (--fresh): mulai dari data baru dan tidak menulis ke disk


func _ready() -> void:
	_default_settings()
	_load_settings()
	_volatile = OS.get_cmdline_user_args().has("--fresh")
	_clear_legacy_sanction()
	if _volatile:
		new_game()
	else:
		_purge_legacy()
		save_path = ""
		new_game()                     # data kosong di memori; tidak ditulis sampai pemain menekan Mulai/Lanjutkan
	if _volatile:
		for a in OS.get_cmdline_user_args():
			if a.begins_with("--now="):
				_fake_now = a.substr(6)
			if a.begins_with("--date="):
				_fake_date = a.substr(7)
			if a.begins_with("--level="):
				level = clampi(int(a.substr(8)), 1, MAX_LEVEL)      # hanya untuk uji otomatis (--fresh)
	else:
		_build_autosave_indicator()


func _process(delta: float) -> void:
	play_time += delta
	_autosave_tick(delta)


# =====================================================================
#  Pengaturan
# =====================================================================
func _default_settings() -> void:
	settings = {
		"music": 0.7, "sfx": 0.9,
		"quality": -1,             # -1 Otomatis (deteksi perangkat), 0 Lancar, 1 Sedang, 2 Bagus
		"view_dist": 0,            # jarak render: 0 otomatis (6/9/12 chunk menurut perangkat), 1=6, 2=9, 3=12 chunk
		"res_scale": 0,            # skala resolusi 3D manual: 0 Otomatis, 1..6 = 50/60/70/80/90/100%
		"aa": 0,                   # anti-aliasing: 0 Otomatis (ikut kualitas), 1 Mati, 2 MSAA 2x, 3 MSAA 4x
		"dyn_res": true, "gfx_v": 4,            # resolusi 3D dinamis: turun otomatis bila FPS < ~53 (UI tetap tajam)
		"show_fps": false,
		"autosave": true, "autosave_idx": 1,      # simpan otomatis berkala: idx 0=30 dtk, 1=1 mnt, 2=2 mnt, 3=5 mnt
		"joy_size": 1.0, "joy_opacity": 0.6, "joy_fixed": false,
		"btn_size": 1.0,
		"cam_zoom": 0.82, "cam_pitch": 42.0, "cam_yaw": 0.0, "cam_sens": 0.5, "cam_invert_y": false, "cam_fov": 50.0, "cam_fx": 1.0,
		"shadows": true, "gimmicks": true, "run_boons": true, "hit_stop2": false, "left_handed": false, "vibrate": true, "force_touch": false,
		"sky_life": true, "cloud_shadows": false,
		"time_mode": 0,             # 0 otomatis, 1 siang, 2 senja, 3 malam
	}


func setting(k: String):
	return settings.get(k)


func set_setting(k: String, v, save: bool = true) -> void:
	settings[k] = v
	if save:
		_save_settings()
	changed.emit("settings")


## Simpan pengaturan ke disk (dipanggil setelah geser slider selesai).
func flush_settings() -> void:
	_save_settings()


func _load_settings() -> void:
	if not FileAccess.file_exists(SETTINGS_PATH):
		return
	var f := FileAccess.open(SETTINGS_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed = JSON.parse_string(f.get_as_text())
	f.close()
	if parsed is Dictionary:
		for k in parsed:
			if settings.has(k):
				settings[k] = parsed[k]
		if int(parsed.get("gfx_v", 0)) < 4:          # save lama: pindah ke Otomatis + resolusi dinamis (perbaikan lag di HP)
			settings["quality"] = -1
			settings["dyn_res"] = true
			settings["cloud_shadows"] = false
			settings["gfx_v"] = 4
			_save_settings()


func _save_settings() -> void:
	var f := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(settings))
		f.close()


# =====================================================================
#  Permainan baru / simpan / muat
# =====================================================================
func new_game() -> void:
	seen_unix = 0
	player_id = _make_id()
	player_name = "Ren"
	level = 1
	exp = 0
	gold = START_GOLD
	diamonds = START_DIAMONDS
	roster = {}
	party = []
	inventory = {"p_small": 3}
	equipment = {}
	quests = {}
	stages = {}
	flags = {}
	stats = {"kills": 0, "stages_cleared": 0, "pulls": 0, "gold_spent": 0, "upgrades": 0, "pvp_win": 0, "pvp_loss": 0, "pvp_draw": 0, "pvp_kills": 0}
	pity = 0
	pity_item = 0
	play_time = 0.0
	login_days = 0
	login_last = ""
	daily = {"date": "", "m": [], "bonus": false}
	ach = {}
	for id in Data.character_ids():
		if Data.character(id).unlocked_at_start:
			_unlock_silent(id)
	_activate_quests()
	save_game()
	changed.emit("roster")
	changed.emit("profile")


func _unlock_silent(id: String) -> void:
	if roster.has(id):
		return
	roster[id] = {"stars": 1, "shards": 0}
	var cd := Data.character(id)
	equipment[id] = {"weapon": Data.starter_weapon(cd.weapon_class), "armor": "a_cloth", "accessory": "", "weapon_plus": 0}
	if party.size() < PARTY_SIZE:
		party.append(id)


# =====================================================================
#  Bonus login 3 hari
# =====================================================================
## Waktu "sekarang" dalam detik (jam dinding lokal perangkat, dihitung seolah UTC agar bisa dibandingkan dengan jadwal event).
func now_local() -> float:
	if _fake_now != "":
		return LiveEvents.parse_time(_fake_now)
	return Time.get_unix_time_from_datetime_dict(Time.get_datetime_dict_from_system(false))


func set_fake_now(s: String) -> void:
	_fake_now = s


func today() -> String:
	if _fake_date != "":
		return _fake_date
	if _fake_now != "":
		return _fake_now.substr(0, 10)
	return Time.get_date_string_from_system()


func login_claimable() -> bool:
	return login_days < LOGIN_DAYS and login_last != today()


## Beri hadiah hari berikutnya. Mengembalikan {} bila belum bisa, atau data hadiah yang diberikan.
func claim_login() -> Dictionary:
	if not login_claimable():
		return {}
	check_clock()
	var rw: Dictionary = LOGIN_REWARDS[login_days]
	if int(rw.get("gold", 0)) > 0:
		add_gold(int(rw["gold"]))
	if int(rw.get("diamonds", 0)) > 0:
		add_diamonds(int(rw["diamonds"]))
	for id in rw.get("items", {}):
		add_item(id, int(rw["items"][id]))
	var got_char := false
	if rw.has("character"):
		got_char = unlock_character(str(rw["character"]))
	login_days += 1
	login_last = today()
	changed.emit("login")
	queue_save()
	return {"day": login_days, "reward": rw, "new_character": got_char}


# ---- event berjadwal: penanda "sudah dilihat" (untuk titik merah di HUD)
func unseen_event_count() -> int:
	var seen: Array = flags.get("seen_events", [])
	var n := 0
	for e in LiveEvents.active():
		if not seen.has(e["id"]):
			n += 1
	return n


func mark_events_seen() -> void:
	var seen: Array = flags.get("seen_events", [])
	for e in LiveEvents.active():
		if not seen.has(e["id"]):
			seen.append(e["id"])
	flags["seen_events"] = seen
	changed.emit("events")
	queue_save()


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


## Ringkasan save untuk layar judul: {} bila tidak ada, {"corrupt": true} bila rusak.
func save_info() -> Dictionary:
	if not has_save():
		return {}
	var d = _read_json_file(SAVE_PATH)
	if not (d is Dictionary):
		return {"corrupt": true}
	return {"name": str(d.get("name", "?")), "level": int(d.get("level", 1)), "play_time": float(d.get("play_time", 0.0)),
		"saved_at": str(d.get("saved_at", "")), "stages": int(d.get("stats", {}).get("stages_cleared", 0)) if d.get("stats") is Dictionary else 0}


## Mulai dunia baru (menimpa save yang ada). ID pemain baru acak.
func start_new_game() -> void:
	save_path = SAVE_PATH
	new_game()
	save_game()


## Muat save. false bila tidak ada / rusak.
func continue_game() -> bool:
	if not has_save():
		return false
	var prev := save_path
	save_path = SAVE_PATH
	if load_game():
		return true
	save_path = prev
	return false


## Hapus SEMUA data permainan di perangkat ini: file save (+ sisa file sementara/lama).
func delete_save() -> void:
	_remove_file(SAVE_PATH)
	_remove_file(SAVE_PATH + ".tmp")
	_purge_legacy()
	save_path = ""
	new_game()


func _remove_file(path: String) -> void:
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(path))


## Sisa sistem lama: slot SV 1-3, cadangan .bak, file identitas, meta. Save slot yang terakhir dimainkan dipindah menjadi save tunggal
## (sekali saja), lalu SEMUA sisa dihapus agar tidak ada data yang "menempel" di perangkat.
func _purge_legacy() -> void:
	if _volatile:
		return
	var old := ["user://fantasy_life_save.json", "user://meta.json", "user://identity.json"]
	for i in range(1, 4):
		for suf in ["", ".bak", ".tmp"]:
			old.append("user://save_slot_%d.json%s" % [i, suf])
	if not has_save():
		var last := 0
		var meta = _read_json_file("user://meta.json")
		if meta is Dictionary:
			last = int(meta.get("last_slot", 0))
		var cands: Array = []
		if last >= 1 and last <= 3:
			cands.append("user://save_slot_%d.json" % last)
		cands.append_array(["user://save_slot_1.json", "user://save_slot_2.json", "user://save_slot_3.json", "user://fantasy_life_save.json"])
		var pick = null
		for c in cands:
			var d = _read_json_file(c)
			if d is Dictionary and d.get("roster", null) is Dictionary:
				pick = d
				break
		if pick != null:
			pick["id"] = _make_id()
			pick.erase("world")
			pick.erase("slot")
			_write_atomic(SAVE_PATH, JSON.stringify(pick))
	for f in old:
		_remove_file(f)


# ---------------------------------------------------------------- perangkat & deteksi kecurangan (offline)
var _install_key_cache := ""


## Hash satu arah dari ID perangkat (tidak bisa dibalik). Dipakai mengikat kode cadangan ke perangkat ini.
func device_hash() -> String:
	var raw := OS.get_unique_id()
	if raw == "":
		raw = _install_key()
	return ("FLDEV|" + raw).sha256_text().substr(0, 20)


func _install_key() -> String:
	if _install_key_cache != "":
		return _install_key_cache
	if not _volatile and FileAccess.file_exists(DEVICE_KEY_PATH):
		_install_key_cache = FileAccess.get_file_as_string(DEVICE_KEY_PATH).strip_edges()
	if _install_key_cache == "":
		_install_key_cache = "%d|%d|%d" % [Time.get_unix_time_from_system(), Time.get_ticks_usec(), randi()]
		if not _volatile:
			var f := FileAccess.open(DEVICE_KEY_PATH, FileAccess.WRITE)
			if f:
				f.store_string(_install_key_cache)
				f.close()
	return _install_key_cache


## Sisa sistem blokir lama: hapus catatannya supaya perangkat yang pernah "diblokir" langsung bebas. Tidak ada blokir lagi.
func _clear_legacy_sanction() -> void:
	if not _volatile:
		_remove_file(LEGACY_SANCTION_PATH)


# ---- deteksi kecurangan: HANYA dicatat + peringatan singkat, game tetap berjalan normal (lihat scripts/systems/cheat_guard.gd)
## Catat temuan. kind: "tamper" | "clock_back" | "anomaly" | "other_device". Tidak memblokir apa pun.
func flag_cheat(kind: String, detail: String = "") -> void:
	var now_u := int(Time.get_unix_time_from_system())
	var entry := {"k": kind, "t": Time.get_datetime_string_from_system(false, true), "u": now_u, "d": detail.substr(0, 60)}
	var lg: Array = flags.get("cheat_log", [])
	for i in range(lg.size() - 1, -1, -1):       # jenis sama dalam 1 jam terakhir tidak dicatat ulang
		var e = lg[i]
		if e is Dictionary:
			if now_u - int(e.get("u", 0)) >= 3600:
				break                                # entri lebih lama dari 1 jam (urut waktu): sisanya pasti lebih lama
			if str(e.get("k", "")) == kind:
				return
	if save_path == "":
		_cheat_pending.append(entry)
	else:
		_append_cheat(entry)
	if not _cheat_toasted.has(kind):
		_cheat_toasted[kind] = true
		cheat_detected.emit(kind, str(CheatGuard.TEXT.get(kind, "Terdeteksi kecurangan.")))


func _append_cheat(entry: Dictionary) -> void:
	var lg: Array = flags.get("cheat_log", [])
	lg.append(entry)
	while lg.size() > CheatGuard.LOG_MAX:
		lg.remove_at(0)
	flags["cheat_log"] = lg


func _merge_pending_cheats() -> void:
	if _cheat_pending.is_empty():
		return
	for e in _cheat_pending:
		_append_cheat(e)
	_cheat_pending.clear()


func cheat_log() -> Array:
	return flags.get("cheat_log", []) as Array


## Jam diputar mundur? (memakai waktu unix UTC, jadi ganti zona waktu tidak dihitung). Dipanggil saat muat, simpan otomatis, klaim login.
func check_clock() -> void:
	if _volatile:
		return
	var now_u := int(Time.get_unix_time_from_system())
	if CheatGuard.clock_rolled_back(seen_unix, now_u):
		flag_cheat("clock_back", "mundur %d dtk" % (seen_unix - now_u))
	seen_unix = maxi(seen_unix, now_u)


func queue_save() -> void:
	if _save_queued:
		return
	_save_queued = true
	get_tree().create_timer(1.5).timeout.connect(func():
		_save_queued = false
		save_game())


func save_game() -> void:
	_last_save_ok = false
	if _volatile or save_path == "":
		return
	_merge_pending_cheats()
	seen_unix = maxi(seen_unix, int(Time.get_unix_time_from_system()))
	var d := {
		"version": SAVE_VERSION, "id": player_id, "saved_at": Time.get_datetime_string_from_system(false, true), "name": player_name, "level": level, "exp": exp, "gold": gold, "diamonds": diamonds,
		"roster": roster, "party": party, "inventory": inventory, "equipment": equipment,
		"quests": quests, "stages": stages, "flags": flags, "stats": stats, "pity": pity, "pity_item": pity_item, "play_time": play_time,
		"login_days": login_days, "login_last": login_last, "daily": daily, "ach": ach, "seen": seen_unix,
	}
	d["sig"] = CheatGuard.signature(d)       # tanda tangan isi save: edit di luar game akan terdeteksi saat dimuat (hanya dicatat)
	if not _write_atomic(save_path, JSON.stringify(d)):
		push_warning("Gagal menyimpan %s" % save_path)
	else:
		_last_save_ok = true
		var cs := get_node_or_null("/root/CloudSave")
		if cs != null and cs.has_method("upload") and cs.call("signed_in"):
			cs.call_deferred("upload", true)          # simpan berkala ke akun Google (dibatasi jedanya di CloudSave)


# ---------------------------------------------------------------- simpan aman (file sementara -> verifikasi -> cadangan -> ganti nama)
## Tulis ke path.tmp, baca ulang & cocokkan, lalu ganti nama tmp -> path. Tidak ada salinan cadangan yang tertinggal di perangkat.
func _write_atomic(path: String, text: String) -> bool:
	var tmp := path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(text)
	f.flush()
	f.close()
	if FileAccess.get_file_as_string(tmp) != text:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(tmp))
		return false
	var g_tmp := ProjectSettings.globalize_path(tmp)
	var g_path := ProjectSettings.globalize_path(path)
	if DirAccess.rename_absolute(g_tmp, g_path) != OK:
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(g_path)
		if DirAccess.rename_absolute(g_tmp, g_path) != OK:
			return false
	return true


func _read_json_file(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		return null
	var j := JSON.new()
	if j.parse(FileAccess.get_file_as_string(path)) != OK:
		return null
	return j.data if j.data is Dictionary else null


func load_game() -> bool:
	if save_path == "":
		return false
	var d = _read_json_file(save_path)
	if not (d is Dictionary):
		return false
	var sig_state := CheatGuard.verify(d)                                  # 0 cocok, 1 save lama tanpa tanda tangan, 2 DIUBAH
	var odd := CheatGuard.anomalies(d, MAX_LEVEL, MAX_STARS)                # nilai mustahil (dicek sebelum dibersihkan)
	seen_unix = maxi(0, int(d.get("seen", 0)))
	player_id = str(d.get("id", "")) if _id_valid(str(d.get("id", ""))) else _make_id()
	player_name = str(d.get("name", "Ren"))
	level = clampi(int(d.get("level", 1)), 1, MAX_LEVEL)
	exp = int(d.get("exp", 0))
	gold = int(d.get("gold", 0))
	diamonds = int(d.get("diamonds", 0))
	roster = {}
	for id in d.get("roster", {}):
		var r = d["roster"][id]
		if r is Dictionary and Data.characters.has(id):
			roster[id] = {"stars": clampi(int(r.get("stars", 1)), 1, MAX_STARS), "shards": int(r.get("shards", 0))}
	party = []
	for id in d.get("party", []):
		if roster.has(id) and not party.has(id) and party.size() < PARTY_SIZE:
			party.append(id)
	inventory = {}
	for id in d.get("inventory", {}):
		if Data.items.has(id) and int(d["inventory"][id]) > 0:
			inventory[id] = int(d["inventory"][id])
	equipment = {}
	for id in d.get("equipment", {}):
		var e = d["equipment"][id]
		if not (e is Dictionary):
			continue
		equipment[id] = {"weapon": str(e.get("weapon", "")), "armor": str(e.get("armor", "")),
			"accessory": str(e.get("accessory", "")), "weapon_plus": int(e.get("weapon_plus", 0))}
	quests = {}
	for id in d.get("quests", {}):
		if Data.quests.has(id):
			var q = d["quests"][id]
			if not (q is Dictionary):
				continue
			quests[id] = {"state": str(q.get("state", "active")), "progress": int(q.get("progress", 0))}
	stages = {}
	for id in d.get("stages", {}):
		var s = d["stages"][id]
		if not (s is Dictionary):
			continue
		stages[id] = {"cleared": bool(s.get("cleared", false)), "stars": int(s.get("stars", 0))}
	flags = d["flags"] if d.get("flags") is Dictionary else {}
	var st: Dictionary = d["stats"] if d.get("stats") is Dictionary else {}
	for k in stats:
		stats[k] = int(st.get(k, 0))
	pity = int(d.get("pity", 0))
	pity_item = int(d.get("pity_item", 0))
	play_time = float(d.get("play_time", 0.0))
	login_days = clampi(int(d.get("login_days", 0)), 0, LOGIN_DAYS)
	login_last = str(d.get("login_last", ""))
	var dd = d.get("daily", {})
	daily = {"date": "", "m": [], "bonus": false}
	if dd is Dictionary:
		daily["date"] = str(dd.get("date", ""))
		daily["bonus"] = bool(dd.get("bonus", false))
		for m in dd.get("m", []):
			if m is Dictionary and Missions.KIND_TEXT.has(str(m.get("kind", ""))):
				daily["m"].append({"kind": str(m["kind"]), "need": maxi(1, int(m.get("need", 1))), "p": maxi(0, int(m.get("p", 0))), "c": bool(m.get("c", false))})
	ach = {}
	var aa = d.get("ach", {})
	if aa is Dictionary:
		for k in aa:
			ach[str(k)] = true
	if roster.is_empty():
		return false
	if party.is_empty():
		party.append(roster.keys()[0])
	for rid in roster:                                  # karakter tanpa data equipment (save lama/rusak) -> equip()/stat tidak error
		if not equipment.has(rid):
			var cdr := Data.character(rid)
			equipment[rid] = {"weapon": Data.starter_weapon(cdr.weapon_class), "armor": "a_cloth", "accessory": "", "weapon_plus": 0}
	_activate_quests()
	_loaded_ok = true
	if sig_state == 2:
		flag_cheat("tamper")
	if not odd.is_empty():
		flag_cheat("anomaly", ",".join(PackedStringArray(odd)))
	check_clock()
	return true


# =====================================================================
#  Profil, mata uang, EXP
# =====================================================================
func exp_needed(lv: int) -> int:
	return 60 + 40 * (lv - 1) + 6 * (lv - 1) * (lv - 1)


func add_exp(n: int) -> int:
	var gained_levels := 0
	if level >= MAX_LEVEL:
		return 0
	exp += n
	while level < MAX_LEVEL and exp >= exp_needed(level):
		exp -= exp_needed(level)
		level += 1
		gained_levels += 1
	if level >= MAX_LEVEL:
		exp = 0
	changed.emit("profile")
	if gained_levels > 0:
		report_event("level", "", level)
	queue_save()
	return gained_levels


func add_gold(n: int) -> void:
	gold += n
	changed.emit("currency")
	queue_save()


func spend_gold(n: int) -> bool:
	if gold < n:
		return false
	gold -= n
	stats["gold_spent"] += n
	daily_add("spend", n)
	changed.emit("currency")
	queue_save()
	return true


func add_diamonds(n: int) -> void:
	diamonds += n
	changed.emit("currency")
	queue_save()


func spend_diamonds(n: int) -> bool:
	if diamonds < n:
		return false
	diamonds -= n
	changed.emit("currency")
	queue_save()
	return true


# =====================================================================
#  Roster & party
# =====================================================================
func is_unlocked(id: String) -> bool:
	return roster.has(id)


func unlock_character(id: String) -> bool:
	if roster.has(id) or not Data.characters.has(id):
		return false
	_unlock_silent(id)
	changed.emit("roster")
	changed.emit("party")
	changed.emit("equipment")
	report_event("party", "", party.size())
	queue_save()
	return true


func stars(id: String) -> int:
	return int(roster.get(id, {}).get("stars", 1))


func shards(id: String) -> int:
	return int(roster.get(id, {}).get("shards", 0))


## Pengali statistik untuk n bintang (1★ = 1,0). Dipakai char_stats_with dan pratinjau di panel Karakter.
func star_factor(n: int) -> float:
	return 1.0 + STAR_STEP * (n - 1)


func star_up_cost(id: String) -> int:
	return SHARDS_PER_STAR * stars(id)


func star_up(id: String) -> bool:
	if not roster.has(id) or stars(id) >= MAX_STARS:
		return false
	var cost := star_up_cost(id)
	if shards(id) < cost:
		return false
	roster[id]["shards"] -= cost
	roster[id]["stars"] += 1
	changed.emit("roster")
	queue_save()
	return true


func add_shards(id: String, n: int) -> void:
	if roster.has(id):
		roster[id]["shards"] += n
		changed.emit("roster")
		queue_save()


func leader() -> String:
	return party[0] if not party.is_empty() else "ren"


## Taruh karakter id pada slot party (0..3). Bila sudah ada di slot lain, posisinya ditukar.
func set_party_slot(slot: int, id: String) -> void:
	if not roster.has(id) or slot < 0 or slot >= PARTY_SIZE:
		return
	var old_idx := party.find(id)
	if slot >= party.size():
		# slot kosong: party selalu terisi berurutan, jadi tambahkan di belakang
		if old_idx >= 0:
			return
		party.append(id)
	elif old_idx >= 0 and old_idx != slot:
		var tmp = party[slot]
		party[slot] = id
		party[old_idx] = tmp
	elif party[slot] == id:
		return                         # sudah di slot itu: tidak ada yang berubah (hemat simpan & segarkan UI)
	else:
		party[slot] = id
	changed.emit("party")
	report_event("party", "", party.size())
	queue_save()


func remove_from_party(id: String) -> bool:
	if party.size() <= 1 or not party.has(id):
		return false
	party.erase(id)
	changed.emit("party")
	queue_save()
	return true


func make_leader(id: String) -> void:
	var i := party.find(id)
	if i > 0:
		party.remove_at(i)
		party.insert(0, id)
		changed.emit("party")
		queue_save()


# =====================================================================
#  Inventori & equipment
# =====================================================================
func item_count(id: String) -> int:
	return int(inventory.get(id, 0))


func add_item(id: String, n: int = 1) -> void:
	if not Data.items.has(id):
		return
	inventory[id] = item_count(id) + n
	changed.emit("inventory")
	queue_save()


func remove_item(id: String, n: int = 1) -> bool:
	if item_count(id) < n:
		return false
	inventory[id] = item_count(id) - n
	if inventory[id] <= 0:
		inventory.erase(id)
	changed.emit("inventory")
	queue_save()
	return true


func can_equip(char_id: String, item_id: String) -> bool:
	var it := Data.item(item_id)
	var cd := Data.character(char_id)
	if it == null or cd == null:
		return false
	match it.type:
		"weapon":
			return it.weapon_class == cd.weapon_class
		"armor", "accessory":
			return true
	return false


func equipped(char_id: String, slot: String) -> String:
	return str(equipment.get(char_id, {}).get(slot, ""))


func equip(char_id: String, item_id: String) -> bool:
	if not roster.has(char_id) or not can_equip(char_id, item_id) or item_count(item_id) < 1:
		return false
	var it := Data.item(item_id)
	var slot := it.type
	var e: Dictionary = equipment[char_id]
	var old: String = e.get(slot, "")
	inventory[item_id] = item_count(item_id) - 1
	if inventory[item_id] <= 0:
		inventory.erase(item_id)
	if old != "":
		inventory[old] = item_count(old) + 1
	e[slot] = item_id
	changed.emit("inventory")
	changed.emit("equipment")
	queue_save()
	return true


func unequip(char_id: String, slot: String) -> bool:
	var old := equipped(char_id, slot)
	if old == "":
		return false
	equipment[char_id][slot] = ""
	inventory[old] = item_count(old) + 1
	changed.emit("inventory")
	changed.emit("equipment")
	queue_save()
	return true


func buy_item(item_id: String, n: int = 1) -> bool:
	var it := Data.item(item_id)
	if it == null or it.buy_price <= 0:
		return false
	if not spend_gold(it.buy_price * n):
		return false
	add_item(item_id, n)
	report_event("buy", it.type, n)
	return true


func sell_item(item_id: String, n: int = 1) -> bool:
	var it := Data.item(item_id)
	if it == null or not remove_item(item_id, n):
		return false
	add_gold(it.sell_price() * n)
	return true


# ---- upgrade senjata (Blacksmith)
func weapon_plus(char_id: String) -> int:
	return int(equipment.get(char_id, {}).get("weapon_plus", 0))


func upgrade_cost(char_id: String) -> int:
	var p := weapon_plus(char_id)
	var it := Data.item(equipped(char_id, "weapon"))
	var r := it.rarity if it else 1
	return 80 * (p + 1) * (p + 1) + 60 * r * (p + 1)


func upgrade_weapon(char_id: String) -> bool:
	if equipped(char_id, "weapon") == "" or weapon_plus(char_id) >= 10:
		return false
	if not spend_gold(upgrade_cost(char_id)):
		return false
	equipment[char_id]["weapon_plus"] += 1
	stats["upgrades"] += 1
	changed.emit("equipment")
	report_event("upgrade", "", 1)
	queue_save()
	return true


# ---- stat karakter
func char_stats(char_id: String) -> Dictionary:
	return char_stats_with(char_id)


## Sama dengan char_stats, tetapi slot `ov_slot` dianggap berisi `ov_item` ("" = kosong) tanpa mengubah data apa pun.
## Dipakai Equipment untuk menampilkan selisih stat nyata sebelum item dipasang.
func char_stats_with(char_id: String, ov_slot: String = "", ov_item: String = "") -> Dictionary:
	var cd := Data.character(char_id)
	if cd == null:
		return {"hp": 1, "atk": 1, "def": 0, "spd": 5.0, "power": 1}
	var lv := level - 1
	var star_mult := star_factor(stars(char_id))
	var hp := (cd.base_hp + cd.hp_growth * lv)
	var atk := (cd.base_atk + cd.atk_growth * lv)
	var df := (cd.base_def + cd.def_growth * lv)
	var e: Dictionary = equipment.get(char_id, {})
	for slot in SLOTS:
		var it := Data.item(ov_item if slot == ov_slot else str(e.get(slot, "")))
		if it:
			hp += it.hp
			atk += it.atk
			df += it.def
			if slot == "weapon":
				atk += int(e.get("weapon_plus", 0)) * maxi(2, int(it.atk * 0.12))
	hp *= star_mult
	atk *= star_mult
	df *= star_mult
	var power := int(hp * 0.2 + atk * 4.0 + df * 3.0)
	return {"hp": int(hp), "atk": int(atk), "def": int(df), "spd": cd.move_speed, "power": power}


func party_power() -> int:
	var p := 0
	for id in party:
		p += char_stats(id)["power"]
	return p


# =====================================================================
#  Quest
# =====================================================================
func quest_state(id: String) -> String:
	## "locked" | "active" | "ready" | "claimed"
	if quests.has(id):
		return quests[id]["state"]
	return "locked"


func quest_progress(id: String) -> int:
	return int(quests.get(id, {}).get("progress", 0))


func _activate_quests() -> void:
	for id in Data.quest_order:
		if quests.has(id):
			continue
		var qd: QuestData = Data.quest(id)
		if qd.prerequisite == "" or quest_state(qd.prerequisite) == "claimed":
			var prog := 0
			if qd.type == "party":
				prog = party.size()
			elif qd.type == "level":
				prog = level
			var state := "active"
			if prog >= qd.amount:
				state = "ready"
			quests[id] = {"state": state, "progress": mini(prog, qd.amount)}


func report_event(kind: String, target: String = "", amount: int = 1) -> void:
	daily_add(kind, amount)
	var touched := false
	for id in quests:
		var q: Dictionary = quests[id]
		if q["state"] != "active":
			continue
		var qd: QuestData = Data.quest(id)
		if qd == null or qd.type != kind:
			continue
		if qd.target != "" and qd.target != target:
			continue
		if kind == "party" or kind == "level":
			q["progress"] = maxi(int(q["progress"]), amount)
		else:
			q["progress"] += amount
		q["progress"] = mini(int(q["progress"]), qd.amount)
		if q["progress"] >= qd.amount:
			q["state"] = "ready"
		touched = true
	if touched:
		changed.emit("quest")
		queue_save()


func ready_quest_count() -> int:
	var n := 0
	var vil: bool = Flow.lobby_map == "village"
	for id in quests:
		if quests[id]["state"] == "ready":
			var qd: QuestData = Data.quest(id)
			if qd == null or (qd.region == "village") == vil:        # hanya quest peta yang sedang dibuka
				n += 1
	return n


func claim_quest(id: String) -> Dictionary:
	## Mengembalikan ringkasan hadiah, atau {} bila belum bisa di-claim.
	if quest_state(id) != "ready":
		return {}
	var qd: QuestData = Data.quest(id)
	var got := {"gold": qd.reward_gold, "diamond": qd.reward_diamond, "exp": qd.reward_exp,
		"items": [], "character": qd.reward_character, "levels": 0}
	quests[id]["state"] = "claimed"
	if qd.reward_gold > 0:
		add_gold(qd.reward_gold)
	if qd.reward_diamond > 0:
		add_diamonds(qd.reward_diamond)
	for entry in qd.reward_items:
		var parts := entry.split(":")
		var iid := parts[0]
		var cnt := int(parts[1]) if parts.size() > 1 else 1
		add_item(iid, cnt)
		got["items"].append([iid, cnt])
	if qd.reward_character != "":
		unlock_character(qd.reward_character)
	if qd.reward_exp > 0:
		got["levels"] = add_exp(qd.reward_exp)
	_activate_quests()
	changed.emit("quest")
	queue_save()
	return got


# =====================================================================
#  Stage
# =====================================================================
func stage_cleared(id: String) -> bool:
	return bool(stages.get(id, {}).get("cleared", false))


## Langkah Adventure berikutnya: langkah pertama (urutan Data.adventure_order) yang sudah terbuka tetapi belum selesai. "" = tamat.
func _region_order() -> Array:
	return Data.village_order if Flow.lobby_map == "village" else Data.adventure_order


func adventure_next() -> String:
	for id in _region_order():
		if stage_unlocked(id) and not stage_cleared(id):
			return str(id)
	return ""


## Langkah yang sudah selesai (urut Adventure), untuk mengulang/farming.
func adventure_cleared() -> Array:
	return _region_order().filter(func(i): return stage_cleared(str(i)))


func stage_unlocked(id: String) -> bool:
	var sd := Data.stage(id)
	if sd == null:
		return false
	return sd.unlock_after == "" or stage_cleared(sd.unlock_after)


## Dipanggil saat stage selesai. result: {"win": bool, "kills": int, "time": float, "stars": int}
func finish_stage(id: String, result: Dictionary) -> Dictionary:
	var sd := Data.stage(id)
	var out := {"win": bool(result.get("win", false)), "gold": 0, "exp": 0, "diamond": 0, "levels": 0,
		"first_clear": false, "kills": int(result.get("kills", 0)), "stars": int(result.get("stars", 0)),
		"time": float(result.get("time", 0.0))}
	if sd == null:
		return out
	if out["win"]:
		var first := not stage_cleared(id)
		out["first_clear"] = first
		out["gold"] = sd.reward_gold
		out["exp"] = sd.reward_exp
		out["diamond"] = sd.reward_diamond + (sd.first_clear_diamond if first else 0)
		var rec: Dictionary = stages.get(id, {"cleared": false, "stars": 0})
		rec["cleared"] = true
		rec["stars"] = maxi(int(rec["stars"]), out["stars"])
		stages[id] = rec
		stats["stages_cleared"] += 1
		add_gold(out["gold"])
		add_diamonds(out["diamond"])
		out["levels"] = add_exp(out["exp"])
		changed.emit("stage")
		report_event("clear_stage", id, 1)
	else:
		# kalah: hadiah hiburan kecil
		out["gold"] = int(sd.reward_gold * 0.2)
		out["exp"] = int(sd.reward_exp * 0.25)
		add_gold(out["gold"])
		out["levels"] = add_exp(out["exp"])
	last_result = out
	queue_save()
	return out


## Catat hasil duel PVP: result "win" / "loss" / "draw" + jumlah kill di duel itu. Mengembalikan rekor terbaru.
func record_pvp(result: String, kills: int) -> Dictionary:
	match result:
		"win":
			stats["pvp_win"] += 1
		"loss":
			stats["pvp_loss"] += 1
		_:
			stats["pvp_draw"] += 1
	stats["pvp_kills"] += maxi(kills, 0)
	save_game()
	return {"win": stats["pvp_win"], "loss": stats["pvp_loss"], "draw": stats["pvp_draw"]}


func add_kills(kind: String, n: int = 1) -> void:
	stats["kills"] += n
	report_event("kill", kind, n)


func time_string() -> String:
	var s := int(play_time)
	return "%d:%02d:%02d" % [s / 3600, (s / 60) % 60, s % 60]


# =====================================================================
#  Identitas offline: ID acak per dunia (di dalam save); nama bisa diubah, ID tidak
# =====================================================================
const _ID_CHARS := "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


func _make_id() -> String:
	# ACAK (waktu + penghitung + acak) -> hash -> 8 karakter tanpa huruf mirip (I,O,0,1). Tidak diturunkan dari perangkat.
	var h := ("%d|%d|%d|%d" % [Time.get_unix_time_from_system() * 1000.0, Time.get_ticks_usec(), randi(), randi()]).sha256_buffer()
	var out := ""
	for i in 8:
		out += _ID_CHARS[h[i] % _ID_CHARS.length()]
	return "FL-%s-%s" % [out.substr(0, 4), out.substr(4, 4)]


func _id_valid(id: String) -> bool:
	var r := RegEx.new()
	r.compile("^FL-[A-Z2-9]{4}-[A-Z2-9]{4}$")
	return r.search(id) != null


## Bersihkan & validasi nama. Kembalikan "" jika tidak valid.
func clean_name(raw: String) -> String:
	var n := raw.strip_edges().replace("\n", " ")
	while n.contains("  "):
		n = n.replace("  ", " ")
	if n.length() > NAME_MAX:
		n = n.substr(0, NAME_MAX).strip_edges()
	return n


func rename_player(raw: String) -> bool:
	var n := clean_name(raw)
	if n.length() < 2:
		return false
	player_name = n
	changed.emit("profile")
	save_game()
	return true


# =====================================================================
#  Misi harian & pencapaian
# =====================================================================
func daily_refresh() -> void:
	var t := today()
	if str(daily.get("date", "")) == t and (daily["m"] as Array).size() == 3:
		return
	daily = {"date": t, "m": [], "bonus": false}
	for m in Missions.daily_for(t):
		daily["m"].append({"kind": m["kind"], "need": m["need"], "p": 0, "c": false})
	changed.emit("daily")
	queue_save()


func daily_add(kind: String, n: int) -> void:
	daily_refresh()
	var hit := false
	for m in daily["m"]:
		if m["kind"] == kind and int(m["p"]) < int(m["need"]):
			m["p"] = mini(int(m["need"]), int(m["p"]) + n)
			hit = true
	if hit:
		changed.emit("daily")
		queue_save()


func daily_ready_count() -> int:
	daily_refresh()
	var n := 0
	var all_c := true
	for m in daily["m"]:
		if int(m["p"]) >= int(m["need"]) and not m["c"]:
			n += 1
		if not m["c"]:
			all_c = false
	if all_c and not daily["bonus"]:
		n += 1
	return n


func daily_claim(i: int) -> bool:
	daily_refresh()
	if i < 0 or i >= (daily["m"] as Array).size():
		return false
	var m: Dictionary = daily["m"][i]
	if m["c"] or int(m["p"]) < int(m["need"]):
		return false
	m["c"] = true
	add_gold(Missions.DAILY_GOLD)
	add_diamonds(Missions.DAILY_DIAMOND)
	changed.emit("daily")
	queue_save()
	return true


func daily_bonus_claim() -> bool:
	daily_refresh()
	if daily["bonus"]:
		return false
	for m in daily["m"]:
		if not m["c"]:
			return false
	daily["bonus"] = true
	add_diamonds(Missions.BONUS_DIAMOND)
	add_item(Missions.BONUS_ITEM, Missions.BONUS_ITEM_N)
	changed.emit("daily")
	queue_save()
	return true


func ach_value(src: String) -> int:
	match src:
		"level": return level
		"chars": return roster.size()
		_: return int(stats.get(src, 0))


func ach_state(a: Dictionary) -> String:
	if ach.has(a["id"]):
		return "claimed"
	return "ready" if ach_value(a["src"]) >= int(a["need"]) else "active"


func ach_ready_count() -> int:
	var n := 0
	for a in Missions.ACH:
		if ach_state(a) == "ready":
			n += 1
	return n


func ach_claim(id: String) -> bool:
	for a in Missions.ACH:
		if a["id"] == id and ach_state(a) == "ready":
			ach[id] = true
			add_diamonds(int(a["dia"]))
			if int(a["gold"]) > 0:
				add_gold(int(a["gold"]))
			changed.emit("daily")
			queue_save()
			return true
	return false


# =====================================================================
#  Simpan otomatis: berkala (pengaturan Data) + saat game ke latar belakang / ditutup (di bawah)
# =====================================================================
const AUTOSAVE_SECS := [30.0, 60.0, 120.0, 300.0]


func autosave_interval() -> float:
	var i := clampi(int(setting("autosave_idx")), 0, AUTOSAVE_SECS.size() - 1)
	return float(AUTOSAVE_SECS[i])


func _autosave_tick(delta: float) -> void:
	if _volatile or save_path == "" or not bool(setting("autosave")):
		_autosave_t = 0.0
		return
	_autosave_t += delta
	if _autosave_t >= autosave_interval():
		_autosave_t = 0.0
		autosave_now()


## Simpan otomatis sekarang (juga dipanggil berkala). Menampilkan indikator kecil bila berhasil.
func autosave_now() -> void:
	check_clock()
	save_game()
	if _last_save_ok:
		autosaved.emit()
		_show_autosave_indicator()


func _build_autosave_indicator() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 90
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	_ind = PanelContainer.new()
	_ind.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ind.add_theme_stylebox_override("panel", UiTheme.box(Color(0.05, 0.07, 0.18, 0.78), Color(UiTheme.GOLD_DARK, 0.9), 2, 12, 8))
	var l := Label.new()
	l.text = "Tersimpan otomatis"
	l.add_theme_font_size_override("font_size", 16)
	l.add_theme_color_override("font_color", UiTheme.TEXT)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ind.add_child(l)
	_ind.modulate.a = 0.0
	_ind.visible = false
	layer.add_child(_ind)


func _show_autosave_indicator() -> void:
	if _ind == null or not is_instance_valid(_ind):
		return
	_ind.visible = true
	_ind.reset_size()
	var m := UiTheme.safe_insets()
	_ind.position = Vector2(get_viewport().get_visible_rect().size.x - _ind.size.x - 14.0 - float(m["right"]), 8.0 + float(m["top"]))
	if _ind_tw:
		_ind_tw.kill()
	_ind.modulate.a = 0.0
	_ind_tw = _ind.create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	_ind_tw.tween_property(_ind, "modulate:a", 1.0, 0.15)
	_ind_tw.tween_interval(1.0)
	_ind_tw.tween_property(_ind, "modulate:a", 0.0, 0.45)
	_ind_tw.tween_callback(func(): _ind.visible = false)


# =====================================================================
#  Simpan otomatis saat game ke latar belakang / ditutup
# =====================================================================
func _notification(what: int) -> void:
	if what in [NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_WM_CLOSE_REQUEST, NOTIFICATION_WM_GO_BACK_REQUEST]:
		save_game()


# =====================================================================
#  Cadangan lewat kode teks: FLSAVE2:<base64(gzip(json))>:<HMAC-SHA256>
#  Kode bertanda tangan (tidak bisa diedit) dan BISA dipulihkan di perangkat lain untuk pindah HP; tidak ada penolakan/sanksi.
#  (Hash perangkat pembuat tetap dicatat di kode, hanya informasi.)
#  Pemulihan hanya boleh bila TIDAK ada save di perangkat (hapus data dulu), sehingga kode tidak bisa dipakai memutar balik progres.
#  CATATAN KEAMANAN: game ini offline. Kunci tanda tangan tertanam di aplikasi, jadi cukup untuk mencegah edit/bagi biasa,
#  tetapi bukan perlindungan terhadap orang yang membongkar aplikasi. Deteksi "ID sama dimainkan di dua HP" yang sebenarnya
#  hanya mungkin dengan server.
# =====================================================================
const CODE_PREFIX := "FLSAVE2"
const CODE_MAX_CHARS := 3_000_000
const _KEY_A := "Fl-Aurelia|"
const _KEY_B := "7Kq2mZ|bind-device|v2"


func _code_mac(text: String) -> String:
	var key := (_KEY_A + _KEY_B + "|" + CODE_PREFIX).to_utf8_buffer()
	return Crypto.new().hmac_digest(HashingContext.HASH_SHA256, key, text.to_utf8_buffer()).hex_encode().substr(0, 32)


func export_code() -> String:
	if save_path != "":
		save_game()
	var d = _read_json_file(SAVE_PATH)
	if not (d is Dictionary):
		return ""
	var text := JSON.stringify({"v": 2, "save": d, "dev": device_hash(), "id": str(d.get("id", player_id)), "ts": int(Time.get_unix_time_from_system())})
	var packed := text.to_utf8_buffer().compress(FileAccess.COMPRESSION_GZIP)
	return "%s:%s:%s" % [CODE_PREFIX, Marshalls.raw_to_base64(packed), _code_mac(text)]


## Kembalikan {"ok", "msg", "cheat"?}. Hanya berhasil bila tidak ada save, kode sah, dan kode dibuat di perangkat ini.
func import_code(code: String) -> Dictionary:
	if has_save():
		return {"ok": false, "msg": "Sudah ada data permainan. Hapus data dulu sebelum memulihkan dari kode."}
	var c := code.strip_edges().replace("\n", "").replace("\r", "").replace(" ", "")
	if c.length() > CODE_MAX_CHARS:
		return {"ok": false, "msg": "Kode terlalu besar."}
	var parts := c.split(":")
	if parts.size() == 3 and parts[0] == "FLSAVE1":
		return {"ok": false, "msg": "Kode versi lama tidak didukung. Kode kini terikat ke perangkat."}
	if parts.size() != 3 or parts[0] != CODE_PREFIX:
		return {"ok": false, "msg": "Itu bukan kode cadangan Fantasy Life."}
	var raw := Marshalls.base64_to_raw(parts[1])
	if raw.is_empty():
		return {"ok": false, "msg": "Kode rusak atau terpotong."}
	var bytes := raw.decompress_dynamic(8_000_000, FileAccess.COMPRESSION_GZIP)
	if bytes.is_empty():
		return {"ok": false, "msg": "Kode rusak atau terpotong."}
	var text := bytes.get_string_from_utf8()
	if _code_mac(text) != parts[2]:
		return {"ok": false, "msg": "Kode tidak sah (diubah atau terpotong)."}
	var pl = JSON.parse_string(text)
	if not (pl is Dictionary) or not (pl.get("save", null) is Dictionary):
		return {"ok": false, "msg": "Isi kode tidak dikenali."}
	var d: Dictionary = pl["save"]
	if int(d.get("version", 0)) < 1 or int(d.get("version", 0)) > SAVE_VERSION:
		return {"ok": false, "msg": "Versi save tidak didukung."}
	if not (d.get("roster", null) is Dictionary) or not (d.get("stats", null) is Dictionary) or not (d.get("inventory", null) is Dictionary):
		return {"ok": false, "msg": "Data save tidak lengkap."}
	# Kode dari perangkat lain DITERIMA (pindah HP). Tidak dianggap kecurangan dan tidak ada sanksi apa pun.
	d["id"] = str(pl.get("id", "")) if _id_valid(str(pl.get("id", ""))) else _make_id()
	if _volatile:
		return {"ok": true, "msg": "OK (mode uji, tidak ditulis)."}
	if not _write_atomic(SAVE_PATH, JSON.stringify(d)):
		return {"ok": false, "msg": "Gagal menulis data."}
	return {"ok": true, "msg": "Data dipulihkan (ID %s)." % d["id"]}

# =====================================================================
#  CADANGAN AKUN (Google): isi save diikat ke AKUN (hash ID pemain Google), bukan ke perangkat, sehingga bisa dipulihkan di HP baru
#  setelah masuk dengan akun yang sama. Dipakai oleh autoload CloudSave. Tanda tangan HMAC sama seperti kode cadangan.
# =====================================================================
const ACCT_PREFIX := "FLACCT1"


func _acct_hash(acct_id: String) -> String:
	return ("FLACCT|" + acct_id).sha256_text().substr(0, 20)


## Bungkus save sekarang untuk akun `acct_id`. "" bila belum ada data.
func account_blob(acct_id: String, flush: bool = true) -> String:
	if acct_id == "":
		return ""
	if flush and save_path != "":
		save_game()
	var d = _read_json_file(SAVE_PATH)
	if not (d is Dictionary):
		return ""
	var text := JSON.stringify({"v": 1, "save": d, "acct": _acct_hash(acct_id), "id": str(d.get("id", player_id)), "ts": int(Time.get_unix_time_from_system())})
	var packed := text.to_utf8_buffer().compress(FileAccess.COMPRESSION_GZIP)
	return "%s:%s:%s" % [ACCT_PREFIX, Marshalls.raw_to_base64(packed), _code_mac(text)]


## Baca bungkus akun: {"ok", "msg", "save"?, "info"?{name, level, play_time, saved_at, stages}}. Tidak menulis apa pun.
func read_account_blob(blob: String, acct_id: String) -> Dictionary:
	var parts := blob.strip_edges().split(":")
	if parts.size() != 3 or parts[0] != ACCT_PREFIX:
		return {"ok": false, "msg": "Data akun tidak dikenali."}
	var raw := Marshalls.base64_to_raw(parts[1])
	var bytes := raw.decompress_dynamic(8_000_000, FileAccess.COMPRESSION_GZIP) if not raw.is_empty() else PackedByteArray()
	if bytes.is_empty():
		return {"ok": false, "msg": "Data akun rusak atau terpotong."}
	var text := bytes.get_string_from_utf8()
	if _code_mac(text) != parts[2]:
		return {"ok": false, "msg": "Data akun tidak sah (diubah atau terpotong)."}
	var pl = JSON.parse_string(text)
	if not (pl is Dictionary) or not (pl.get("save", null) is Dictionary):
		return {"ok": false, "msg": "Isi data akun tidak dikenali."}
	if str(pl.get("acct", "")) != _acct_hash(acct_id):
		return {"ok": false, "msg": "Data ini milik akun Google lain."}
	var d: Dictionary = pl["save"]
	if int(d.get("version", 0)) < 1 or int(d.get("version", 0)) > SAVE_VERSION:
		return {"ok": false, "msg": "Versi save tidak didukung (perbarui game)."}
	if not (d.get("roster", null) is Dictionary) or not (d.get("stats", null) is Dictionary) or not (d.get("inventory", null) is Dictionary):
		return {"ok": false, "msg": "Data save tidak lengkap."}
	d["id"] = str(pl.get("id", "")) if _id_valid(str(pl.get("id", ""))) else _make_id()
	return {"ok": true, "msg": "OK", "save": d, "info": {"name": str(d.get("name", "?")), "level": int(d.get("level", 1)), "play_time": float(d.get("play_time", 0.0)),
		"saved_at": str(d.get("saved_at", "")), "stages": int(d.get("stats", {}).get("stages_cleared", 0))}}


## Pulihkan dari akun. Bila di perangkat sudah ada data: tanpa `force` hanya mengembalikan {"conflict": true, local, cloud} agar pemain memilih;
## dengan `force` menimpa data lokal. Tidak pernah menimpa diam-diam.
func restore_account_blob(blob: String, acct_id: String, force: bool = false) -> Dictionary:
	var r := read_account_blob(blob, acct_id)
	if not r["ok"]:
		return r
	if has_save() and not force:
		return {"ok": false, "conflict": true, "msg": "Data di perangkat ini berbeda dari data akun.", "local": save_info(), "cloud": r["info"]}
	if _volatile:
		return {"ok": true, "msg": "OK (mode uji, tidak ditulis).", "info": r["info"]}
	if not _write_atomic(SAVE_PATH, JSON.stringify(r["save"])):
		return {"ok": false, "msg": "Gagal menulis data."}
	return {"ok": true, "msg": "Data akun dipulihkan (ID %s)." % r["save"]["id"], "info": r["info"]}
