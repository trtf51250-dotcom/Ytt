extends Node
## Simpanan akun Google (Play Games Services - Saved Games) lewat plugin Android pihak ketiga.
## PENTING: Godot tidak punya login Google bawaan. Tanpa plugin terpasang, semua fungsi di sini aman & tidak berbuat apa-apa
## (status "plugin belum terpasang"); data tetap lokal. Langkah pemasangan: docs/GOOGLE_LOGIN_SETUP.md.
## Kode adapter ini ditulis menurut API plugin "godot-play-game-services" (v3) dan BELUM diuji di perangkat: nama
## node/sinyal ada di satu tempat (konstanta di bawah) agar mudah disesuaikan bila plugin berbeda versi.
signal status_changed
signal finished(ok: bool, msg: String)

const SNAPSHOT_NAME := "fantasy_life_save"
const PLUGIN_NODE := "GodotPlayGameServices"      # nama autoload yang dibuat plugin
const SIGNIN_NODE := "SignInClient"
const SNAP_NODE := "SnapshotsClient"
const OVERWRITE_MIN_GAP := 20.0                    # detik antar unggahan otomatis

var account_id := ""                               # ID pemain Google (kosong bila belum masuk)
var account_name := ""
var busy := false
var last_msg := ""
var _last_up := -999.0
var _pending_blob := ""


func plugin_available() -> bool:
	return OS.get_name() == "Android" and _root_node(PLUGIN_NODE) != null


func signed_in() -> bool:
	return account_id != ""


## Teks status singkat untuk UI.
func status_text() -> String:
	if OS.get_name() != "Android":
		return "Login Google hanya tersedia di Android."
	if not plugin_available():
		return "Plugin Google Play Games belum terpasang di build ini (lihat docs/GOOGLE_LOGIN_SETUP.md)."
	if busy:
		return "Menghubungi Google..."
	if signed_in():
		return "Masuk sebagai %s" % (account_name if account_name != "" else "akun Google")
	return "Belum masuk akun Google."


func _root_node(n: String) -> Node:
	var ml := Engine.get_main_loop()
	return (ml as SceneTree).root.get_node_or_null(n) if ml is SceneTree else null


func _client(n: String) -> Object:
	var root := _root_node(n)
	if root != null:
		return root
	# sebagian versi plugin memasang client sebagai child dari node utama plugin
	var main := _root_node(PLUGIN_NODE)
	return main.get_node_or_null(n) if main != null else null


func _set_status(msg: String) -> void:
	last_msg = msg
	status_changed.emit()


## Masuk ke akun Google. Hasil lewat sinyal status_changed / finished.
func sign_in() -> void:
	if not plugin_available():
		finished.emit(false, status_text())
		return
	var c := _client(SIGNIN_NODE)
	if c == null:
		finished.emit(false, "Client SignIn plugin tidak ditemukan.")
		return
	busy = true
	_set_status("Masuk...")
	if c.has_signal("user_authenticated") and not c.is_connected("user_authenticated", _on_auth):
		c.connect("user_authenticated", _on_auth)
	if c.has_method("sign_in"):
		c.call("sign_in")
	elif c.has_method("is_authenticated"):
		c.call("is_authenticated")
	else:
		busy = false
		finished.emit(false, "Versi plugin tidak dikenali (tidak ada sign_in).")


func _on_auth(ok) -> void:
	busy = false
	if ok == true or (ok is Dictionary and ok.get("is_authenticated", false)):
		var c := _client(SIGNIN_NODE)
		# ID pemain: tergantung versi plugin; coba beberapa cara, jangan crash bila tidak ada
		var id := ""
		if c != null and c.has_method("get_player_id"):
			id = str(c.call("get_player_id"))
		if id == "" and c != null and "player_id" in c:
			id = str(c.get("player_id"))
		account_id = id
		account_name = str(c.call("get_player_name")) if c != null and c.has_method("get_player_name") else ""
		if account_id == "":
			_set_status("Masuk berhasil tetapi ID akun tidak terbaca; cadangan akun dinonaktifkan.")
		else:
			_set_status("Masuk sebagai %s" % (account_name if account_name != "" else "akun Google"))
	else:
		account_id = ""
		_set_status("Gagal masuk akun Google.")
	finished.emit(signed_in(), last_msg)


## Unggah save sekarang ke akun. `auto` = dipanggil berkala (dibatasi jedanya).
func upload(auto: bool = false) -> void:
	if not signed_in() or busy:
		if not auto:
			finished.emit(false, "Belum masuk akun Google." if not signed_in() else "Sedang sibuk.")
		return
	var now := Time.get_ticks_msec() / 1000.0
	if auto and now - _last_up < OVERWRITE_MIN_GAP:
		return
	var blob := GameState.account_blob(account_id, false)
	if blob == "":
		if not auto:
			finished.emit(false, "Belum ada data untuk disimpan.")
		return
	var c := _client(SNAP_NODE)
	if c == null or not c.has_method("save_game"):
		finished.emit(false, "Client Saved Games plugin tidak ditemukan.")
		return
	_last_up = now
	busy = true
	_set_status("Menyimpan ke akun Google...")
	if c.has_signal("game_saved") and not c.is_connected("game_saved", _on_saved):
		c.connect("game_saved", _on_saved)
	c.call("save_game", SNAPSHOT_NAME, "Fantasy Life RPG", blob.to_utf8_buffer())


func _on_saved(ok, _name = "", _desc = "") -> void:
	busy = false
	_set_status("Tersimpan di akun Google." if ok == true else "Gagal menyimpan ke akun Google (data lokal aman).")
	finished.emit(ok == true, last_msg)


## Unduh save dari akun; hasil dikirim lewat sinyal `downloaded(blob)` (kosong bila tidak ada).
signal downloaded(blob: String)


func download() -> void:
	if not signed_in() or busy:
		downloaded.emit("")
		return
	var c := _client(SNAP_NODE)
	if c == null or not c.has_method("load_game"):
		finished.emit(false, "Client Saved Games plugin tidak ditemukan.")
		downloaded.emit("")
		return
	busy = true
	_set_status("Mengambil data dari akun Google...")
	if c.has_signal("game_loaded") and not c.is_connected("game_loaded", _on_loaded):
		c.connect("game_loaded", _on_loaded)
	c.call("load_game", SNAPSHOT_NAME, true, 1)


func _on_loaded(snapshot, _name = "") -> void:
	busy = false
	var blob := ""
	if snapshot != null:
		var content = snapshot.get("content") if snapshot is Object and "content" in snapshot else null
		if content is PackedByteArray and not content.is_empty():
			blob = content.get_string_from_utf8()
	_set_status("Data akun ditemukan." if blob != "" else "Belum ada data tersimpan di akun ini.")
	downloaded.emit(blob)
