#!/usr/bin/env bash
# Kirim proyek ke GitHub supaya APK dibangun otomatis (GitHub Actions: .github/workflows/build-apk.yml).
# Pemakaian:  bash kirim_ke_github.sh https://github.com/USERNAME/NAMA-REPO.git
# Prasyarat: repo kosong sudah dibuat di GitHub, dan git sudah login (token/SSH). Bisa dari Termux.
set -e
URL="${1:?Isi URL repo: bash kirim_ke_github.sh https://github.com/USERNAME/NAMA-REPO.git}"
cd "$(dirname "$0")"
[ -d .git ] || git init -q
git add -A
git commit -qm "Fantasy Life RPG" || true
git branch -M main
git remote remove origin 2>/dev/null || true
git remote add origin "$URL"
git push -u origin main
echo "Selesai. Buka tab Actions di repo -> 'Build APK'. APK ada di Artifacts setelah build selesai (±10-15 menit)."
echo "Untuk rilis (APK game + admin di halaman Releases):  git tag v0.1.0 && git push origin v0.1.0"
