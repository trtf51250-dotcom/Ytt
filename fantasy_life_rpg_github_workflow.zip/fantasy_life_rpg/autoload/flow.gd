extends CanvasLayer
## Autoload "Flow": perpindahan scene dengan fade + layar "Memuat...", dan notifikasi singkat (toast).

const SCENE_TITLE := "res://scenes/title.tscn"
const SCENE_LOBBY := "res://scenes/lobby/lobby.tscn"
const SCENE_STAGE := "res://scenes/stages/stage.tscn"

var _fade: ColorRect
var _label: Label
var _busy := false
var _toast_box: PanelContainer
var _toast_label: Label
var _toast_tween: Tween


func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	_fade = ColorRect.new()
	_fade.color = Color(0.05, 0.07, 0.16, 1.0)
	_fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.modulate.a = 0.0
	add_child(_fade)
	_label = Label.new()
	_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_label.add_theme_font_size_override("font_size", 28)
	_label.add_theme_color_override("font_color", Color(0.85, 0.93, 1.0))
	_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.add_child(_label)
	_bar = ProgressBar.new()
	_bar.show_percentage = false
	_bar.min_value = 0.0
	_bar.max_value = 100.0
	_bar.anchor_left = 0.5
	_bar.anchor_right = 0.5
	_bar.anchor_top = 0.62
	_bar.anchor_bottom = 0.62
	_bar.offset_left = -190.0
	_bar.offset_right = 190.0
	_bar.offset_bottom = 12.0
	_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.12, 0.16, 0.32)
	bg.set_corner_radius_all(6)
	var fg := StyleBoxFlat.new()
	fg.bg_color = Color(0.95, 0.76, 0.3)
	fg.set_corner_radius_all(6)
	_bar.add_theme_stylebox_override("background", bg)
	_bar.add_theme_stylebox_override("fill", fg)
	_fade.add_child(_bar)
	_load_speed()

	_toast_box = PanelContainer.new()
	_toast_box.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_toast_box.position = Vector2(0, 86)
	_toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.08, 0.11, 0.24, 0.92)
	sb.border_color = Color(0.95, 0.76, 0.3)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(14)
	sb.content_margin_left = 22
	sb.content_margin_right = 22
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10
	_toast_box.add_theme_stylebox_override("panel", sb)
	_toast_label = Label.new()
	_toast_label.add_theme_font_size_override("font_size", 22)
	_toast_label.add_theme_color_override("font_color", Color(1, 1, 1))
	_toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_box.add_child(_toast_label)
	_toast_box.modulate.a = 0.0
	add_child(_toast_box)


func is_busy() -> bool:
	return _busy


## Kecepatan pemuatan menyesuaikan HP: waktu muat rata-rata (EMA) disimpan di perangkat dan dipakai untuk memilih lama fade
## serta lama menahan layar "Memuat" sampai bingkai stabil, sehingga HP lambat tidak menampilkan patah-patah saat scene baru muncul.
const SPEED_FILE := "user://device_speed.cfg"
var _bar: ProgressBar
var _load_ms := -1.0


func _load_speed() -> void:
	var cf := ConfigFile.new()
	if cf.load(SPEED_FILE) == OK:
		_load_ms = float(cf.get_value("load", "ms", -1.0))


func _save_speed() -> void:
	var cf := ConfigFile.new()
	cf.set_value("load", "ms", _load_ms)
	cf.save(SPEED_FILE)


## 0 = HP cepat, 1 = HP lambat (dari rata-rata waktu muat dan tingkat grafis).
func speed_slow() -> float:
	var sl := 0.35 if _load_ms < 0.0 else clampf((_load_ms - 250.0) / 1500.0, 0.0, 1.0)
	if Perf.level() == 0:
		sl = maxf(sl, 0.5)
	return sl


func _set_progress(v: float, text: String, dots: int = 0) -> void:
	if _bar:
		_bar.value = maxf(_bar.value, v)
	_label.text = text + ".".repeat(dots)


## Tunggu sampai beberapa bingkai berturut-turut cukup halus (atau batas waktu) agar layar muat baru dibuka saat sudah stabil.
func _wait_settled(cap_s: float) -> void:
	var limit_ms := 40.0 if Perf.level() == 0 else 28.0
	var good := 0
	var t0 := Time.get_ticks_msec()
	while good < 4 and float(Time.get_ticks_msec() - t0) < cap_s * 1000.0:
		await get_tree().process_frame
		if get_process_delta_time() * 1000.0 <= limit_ms:
			good += 1
		else:
			good = 0


## Pindah scene dengan fade. Mengembalikan setelah scene baru dimuat.
func goto(path: String, text: String = "Memuat...") -> void:
	if _busy:
		return
	if GameState.banned and path != SCENE_TITLE:      # akun diblokir: hanya layar judul yang boleh dibuka
		path = SCENE_TITLE
	_busy = true
	var base := text.trim_suffix("...")
	var slow := speed_slow()
	var t_start := Time.get_ticks_msec()
	_fade.mouse_filter = Control.MOUSE_FILTER_STOP
	if _bar:
		_bar.value = 0.0
	_set_progress(0.0, base, 3)
	var t := create_tween()
	t.tween_property(_fade, "modulate:a", 1.0, lerpf(0.22, 0.1, slow))
	await t.finished
	await get_tree().process_frame
	# muat scene di thread terpisah supaya layar tidak membeku dan progres terlihat
	var packed: PackedScene = null
	if ResourceLoader.load_threaded_request(path) == OK:
		var prog: Array = []
		var deadline := Time.get_ticks_msec() + 10000
		var tick := 0
		while Time.get_ticks_msec() < deadline:
			var st := ResourceLoader.load_threaded_get_status(path, prog)
			if not prog.is_empty():
				_set_progress(float(prog[0]) * 60.0, base, (tick / 12) % 4)
			if st == ResourceLoader.THREAD_LOAD_LOADED:
				packed = ResourceLoader.load_threaded_get(path) as PackedScene
				break
			if st == ResourceLoader.THREAD_LOAD_FAILED or st == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
				break
			tick += 1
			await get_tree().process_frame
	_set_progress(70.0, base, 3)
	await get_tree().process_frame
	var err := OK
	if packed != null:
		err = get_tree().change_scene_to_packed(packed)
	else:
		err = get_tree().change_scene_to_file(path)
	if err != OK:
		# gagal memuat: buka kembali layar & lepaskan kunci supaya game tidak macet di layar "Memuat"
		var tf := create_tween()
		tf.tween_property(_fade, "modulate:a", 0.0, 0.2)
		await tf.finished
		_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_busy = false
		toast("Gagal memuat scene.", 2.5)
		return
	_set_progress(85.0, base, 3)
	await get_tree().process_frame
	await get_tree().process_frame
	await _wait_settled(lerpf(0.6, 2.2, slow))
	var load_ms := float(Time.get_ticks_msec() - t_start)
	_load_ms = load_ms if _load_ms < 0.0 else lerpf(_load_ms, load_ms, 0.5)
	_save_speed()
	_set_progress(100.0, base, 0)
	# HP cepat: tahan layar sebentar agar teks sempat terbaca; HP lambat: langsung buka
	var shown := float(Time.get_ticks_msec() - t_start) / 1000.0
	var min_show := lerpf(0.35, 0.0, slow)
	if shown < min_show:
		await get_tree().create_timer(min_show - shown).timeout
	var t2 := create_tween()
	t2.tween_property(_fade, "modulate:a", 0.0, lerpf(0.3, 0.15, slow))
	await t2.finished
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_busy = false


func go_lobby() -> void:
	goto(SCENE_LOBBY, "Kembali ke Aurelia...")


func start_stage(stage_id: String) -> void:
	GameState.current_stage_id = stage_id
	var sd := Data.stage(stage_id)
	goto(SCENE_STAGE, "Menuju %s..." % (sd.display_name if sd else "stage"))


## Notifikasi singkat di atas layar.
func toast(text: String, seconds: float = 2.0) -> void:
	_toast_label.text = text
	_toast_box.reset_size()
	_toast_box.position.x = (get_viewport().get_visible_rect().size.x - _toast_box.size.x) * 0.5
	if _toast_tween:
		_toast_tween.kill()
	_toast_box.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(seconds)
	_toast_tween.tween_property(_toast_box, "modulate:a", 0.0, 0.4)
