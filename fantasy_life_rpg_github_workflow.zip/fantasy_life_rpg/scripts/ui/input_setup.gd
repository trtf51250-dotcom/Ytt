class_name InputSetup
extends RefCounted
## Mendaftarkan aksi input (keyboard, gamepad) lewat kode agar project.godot tetap ringkas. Sentuhan ditangani TouchControls.

const ACTIONS := {
	"move_left": [KEY_A, KEY_LEFT],
	"move_right": [KEY_D, KEY_RIGHT],
	"move_up": [KEY_W, KEY_UP],
	"move_down": [KEY_S, KEY_DOWN],
	"attack": [KEY_J, KEY_SPACE],
	"skill": [KEY_K],
	"ult": [KEY_U],
	"dodge": [KEY_L, KEY_SHIFT],
	"interact": [KEY_E, KEY_F],
	"cam_left": [KEY_Q],
	"cam_right": [KEY_R],
	"menu_back": [KEY_ESCAPE],
	"switch_1": [KEY_1],
	"switch_2": [KEY_2],
	"switch_3": [KEY_3],
	"switch_4": [KEY_4],
}
const PAD := {
	"attack": JOY_BUTTON_X,
	"skill": JOY_BUTTON_Y,
	"ult": JOY_BUTTON_RIGHT_SHOULDER,
	"dodge": JOY_BUTTON_B,
	"interact": JOY_BUTTON_A,
	"menu_back": JOY_BUTTON_START,
}


static func ensure() -> void:
	for a in ACTIONS:
		if not InputMap.has_action(a):
			InputMap.add_action(a, 0.25)
			for k in ACTIONS[a]:
				var ev := InputEventKey.new()
				ev.physical_keycode = k
				InputMap.action_add_event(a, ev)
	for a in PAD:
		var ev := InputEventJoypadButton.new()
		ev.button_index = PAD[a]
		InputMap.action_add_event(a, ev)
	var axes := {"move_left": [JOY_AXIS_LEFT_X, -1.0], "move_right": [JOY_AXIS_LEFT_X, 1.0], "move_up": [JOY_AXIS_LEFT_Y, -1.0], "move_down": [JOY_AXIS_LEFT_Y, 1.0]}
	for a in axes:
		var ev2 := InputEventJoypadMotion.new()
		ev2.axis = axes[a][0]
		ev2.axis_value = axes[a][1]
		InputMap.action_add_event(a, ev2)


## Vektor gerak keyboard/gamepad (x kanan, y bawah) dengan panjang <= 1.
static func keyboard_vector() -> Vector2:
	return Input.get_vector("move_left", "move_right", "move_up", "move_down")
