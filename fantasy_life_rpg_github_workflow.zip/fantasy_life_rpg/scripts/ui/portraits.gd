class_name Portraits
extends Node
## Studio potret: merender setengah badan tiap karakter 3D sekali ke tekstur (SubViewport transparan), lalu disimpan di cache.
## Pemakaian: Portraits.texture(host, id) -> Texture2D atau null (belum siap). Sambungkan ke Portraits.changed untuk menyegarkan UI.

signal changed

const SIZE := Vector2i(256, 320)
static var _inst: Portraits
static var _cache: Dictionary = {}
var _queue: Array[String] = []
var _busy := false
var _tries: Dictionary = {}


## key = id (setengah badan 256x320) atau id + "#full" (seluruh badan 220x440, untuk kartu slot tinggi).
static func texture(host: Node, id: String) -> Texture2D:
	if _cache.has(id):
		return _cache[id]
	if _inst == null or not is_instance_valid(_inst):
		_inst = Portraits.new()
		_inst.name = "PortraitStudio"
		host.get_tree().root.add_child.call_deferred(_inst)
	_inst._enqueue(id)
	return null


static func changed_signal(host: Node) -> Signal:
	if _inst == null or not is_instance_valid(_inst):
		_inst = Portraits.new()
		_inst.name = "PortraitStudio"
		host.get_tree().root.add_child.call_deferred(_inst)
	return _inst.changed


func _enqueue(id: String) -> void:
	if not _queue.has(id) and not _cache.has(id):
		_queue.append(id)
	if not _busy and is_inside_tree():
		_run()


func _ready() -> void:
	if not _queue.is_empty() and not _busy:
		_run()


func _run() -> void:
	_busy = true
	while not _queue.is_empty():
		var id: String = _queue.pop_front()
		if _cache.has(id):
			continue
		var tex := await _render(id)
		if tex != null:
			_cache[id] = tex
			changed.emit()
		elif _tries.get(id, 0) < 4:                       # render pertama kadang kosong (shader belum siap): coba lagi
			_tries[id] = _tries.get(id, 0) + 1
			_queue.append(id)
	_busy = false


func _render(key: String) -> Texture2D:
	var full := key.ends_with("#full")
	var id := key.replace("#full", "")
	var cd := Data.character(id)
	if cd == null:
		return null
	var vp := SubViewport.new()
	vp.size = Vector2i(220, 440) if full else SIZE
	vp.transparent_bg = true
	vp.own_world_3d = true
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(vp)
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_CLEAR_COLOR
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.8, 0.84, 0.98)
	e.ambient_light_energy = 0.7
	env.environment = e
	vp.add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-35, -30, 0)
	sun.light_energy = 0.95
	vp.add_child(sun)
	var rig := CharacterRig.new()
	vp.add_child(rig)
	rig.setup(1.8, load(cd.skin_path), false, true)
	CharacterLooks.apply_hero(rig, id)
	rig.set_style(id)
	rig.set_move(0.0)
	rig.rotation_degrees.y = 18.0
	var cam := Camera3D.new()
	cam.fov = 28.0
	vp.add_child(cam)
	if full:
		cam.position = Vector3(0.0, 1.0, 4.4)
		cam.look_at(Vector3(0.0, 0.9, 0.0))
	else:
		cam.position = Vector3(0.0, 1.3, 3.1)
		cam.look_at(Vector3(0.0, 1.22, 0.0))
	cam.current = true
	for i in 4 + 6 * int(_tries.get(key, 0)):
		await get_tree().process_frame
	var img := vp.get_texture().get_image()
	vp.queue_free()
	if img == null or img.is_empty() or _is_blank(img):
		return null
	return ImageTexture.create_from_image(img)


static func _is_blank(img: Image) -> bool:
	for y in range(0, img.get_height(), 8):
		for x in range(0, img.get_width(), 8):
			if img.get_pixel(x, y).a > 0.05:
				return false
	return true
