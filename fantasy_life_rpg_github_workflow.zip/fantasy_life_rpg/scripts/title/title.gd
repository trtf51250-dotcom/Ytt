extends Control
## Layar judul: Lanjutkan / Permainan Baru / Pengaturan. Semua UI dibuat lewat kode.

var host: PanelHost
var _box: VBoxContainer
var _msg: Label
var _confirm_del := false
var _confirm_new := false
var _t := 0.0
var _stars: Array = []


func _ready() -> void:
	InputSetup.ensure()
	theme = UiTheme.get_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	Sfx.music("music_main")
	for i in 60:
		_stars.append([Vector2(randf(), randf() * 0.8), randf_range(1.0, 3.0), randf() * TAU])

	var title := UiTheme.label("FANTASY LIFE RPG", 64, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	title.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	title.position.y = 70
	title.custom_minimum_size = Vector2(900, 0)
	title.offset_left = -450
	title.offset_right = 450
	add_child(title)
	var sub := UiTheme.label("Kota Aurelia menunggumu", 26, UiTheme.SKY, HORIZONTAL_ALIGNMENT_CENTER)
	sub.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	sub.offset_left = -450
	sub.offset_right = 450
	sub.position.y = 160
	add_child(sub)

	_box = VBoxContainer.new()
	_box.add_theme_constant_override("separation", 12)
	_box.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_box.offset_left = -230
	_box.offset_right = 230
	_box.offset_top = -50
	_box.offset_bottom = 290
	add_child(_box)
	_msg = UiTheme.label("", 17, UiTheme.SKY, HORIZONTAL_ALIGNMENT_CENTER)
	_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_msg.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_msg.offset_left = -420
	_msg.offset_right = 420
	_msg.offset_top = -120
	_msg.offset_bottom = -50
	add_child(_msg)
	var ver := UiTheme.label("Prototipe • Godot 4.3", 16, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER)
	ver.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	ver.offset_top = -34
	add_child(ver)

	host = PanelHost.new()
	add_child(host)
	_build_menu()
	var a := OS.get_cmdline_user_args()
	if a.has("--bot=1"):
		call_deferred("_bot")


func _process(d: float) -> void:
	_t += d
	queue_redraw()


func _draw() -> void:
	var s := size
	var steps := 24
	for i in steps:
		var f := float(i) / steps
		draw_rect(Rect2(0, s.y * f, s.x, s.y / steps + 1), Color(0.05, 0.08, 0.22).lerp(Color(0.36, 0.28, 0.5), f * f))
	for st in _stars:
		var p: Vector2 = st[0]
		var tw := 0.5 + 0.5 * sin(_t * 2.0 + float(st[2]))
		draw_circle(Vector2(p.x * s.x, p.y * s.y), float(st[1]), Color(1, 1, 0.9, 0.3 + 0.6 * tw))
	draw_colored_polygon(PackedVector2Array([Vector2(0, s.y), Vector2(0, s.y * 0.84), Vector2(s.x * 0.3, s.y * 0.76), Vector2(s.x * 0.6, s.y * 0.86), Vector2(s.x, s.y * 0.78), Vector2(s.x, s.y)]), Color(0.08, 0.12, 0.2))


func _build_menu() -> void:
	for c in _box.get_children():
		c.queue_free()
	if GameState.banned:
		var bl := UiTheme.label("AKUN DIBLOKIR", 38, UiTheme.BAD, HORIZONTAL_ALIGNMENT_CENTER)
		_box.add_child(bl)
		var why := UiTheme.label(str(GameState.ban_info.get("reason", "")), 18, UiTheme.TEXT, HORIZONTAL_ALIGNMENT_CENTER)
		why.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_box.add_child(why)
		_box.add_child(UiTheme.label("ID: %s" % str(GameState.ban_info.get("id", "?")), 20, UiTheme.GOLD, HORIZONTAL_ALIGNMENT_CENTER))
		_box.add_child(UiTheme.label("Pada %s" % str(GameState.ban_info.get("at", "")).replace("T", " "), 15, UiTheme.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER))
		return
	var info := GameState.save_info()
	var has: bool = not info.is_empty() and not bool(info.get("corrupt", false))
	if has:
		var secs := int(info["play_time"])
		_box.add_child(UiTheme.label("%s · Lv %d · Stage selesai %d · %d j %d m" % [info["name"], info["level"], info["stages"], secs / 3600, (secs % 3600) / 60], 17, UiTheme.SKY, HORIZONTAL_ALIGNMENT_CENTER))
		var go := UiTheme.accent_button("Lanjutkan", UiTheme.GOLD, Vector2(0, 64))
		go.pressed.connect(_continue)
		_box.add_child(go)
		var nw := UiTheme.button("Mulai Baru" if not _confirm_new else "Yakin? Data lama HILANG", Vector2(0, 52))
		nw.pressed.connect(func():
			if _confirm_new:
				_new_game()
			else:
				_confirm_new = true
				_build_menu())
		_box.add_child(nw)
	else:
		if info.get("corrupt", false):
			_box.add_child(UiTheme.label("Data permainan rusak.", 18, UiTheme.BAD, HORIZONTAL_ALIGNMENT_CENTER))
		var st0 := UiTheme.accent_button("Mulai Bermain", UiTheme.GOLD, Vector2(0, 64))
		st0.pressed.connect(_new_game)
		_box.add_child(st0)
		var im := UiTheme.button("Pulihkan dari Kode Cadangan", Vector2(0, 52))
		im.pressed.connect(_import)
		_box.add_child(im)
	var st := UiTheme.button("Pengaturan", Vector2(0, 52))
	st.pressed.connect(func(): host.open("settings"))
	_box.add_child(st)
	if not info.is_empty():
		var del := UiTheme.button("Hapus Data" if not _confirm_del else "Yakin? Hilang selamanya", Vector2(0, 46))
		del.add_theme_color_override("font_color", UiTheme.BAD)
		del.pressed.connect(func():
			if _confirm_del:
				_confirm_del = false
				GameState.delete_save()
				_msg.text = "Data dihapus dari perangkat ini."
			else:
				_confirm_del = true
			_build_menu())
		_box.add_child(del)


func _new_game() -> void:
	GameState.start_new_game()
	Flow.goto(Flow.SCENE_LOBBY, "Memasuki %s..." % GameState.WORLD_NAME)


func _continue() -> void:
	if GameState.continue_game():
		Flow.goto(Flow.SCENE_LOBBY, "Memasuki %s..." % GameState.WORLD_NAME)
	else:
		_msg.text = "Data tidak bisa dimuat."


func _import() -> void:
	var r := GameState.import_code(DisplayServer.clipboard_get())
	if r.get("banned", false):
		_msg.text = str(r["msg"])
	elif r["ok"]:
		_msg.text = str(r["msg"])
	else:
		_msg.text = "Gagal: %s (salin dulu kode cadangan, lalu ketuk Pulihkan)" % r["msg"]
	_build_menu()


func _bot() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	var dir := ""
	for x in OS.get_cmdline_user_args():
		if x.begins_with("--shots="):
			dir = x.substr(8)
	if dir != "":
		get_viewport().get_texture().get_image().save_png(dir + "/title.png")
	await Flow.goto(Flow.SCENE_LOBBY)
	print("CHECK title->lobby: ", get_tree().current_scene.name)
	get_tree().quit()
