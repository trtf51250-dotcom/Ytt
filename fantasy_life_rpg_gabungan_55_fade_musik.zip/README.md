# Fantasy Life RPG — Lobi Kota Fantasi 3D (Godot 4.3, GDScript)

Prototipe RPG Android landscape: lobi kota fantasi 3D bergaya anime yang bisa dijelajahi, menu lengkap,
dialog NPC, dan fondasi petualangan (pilih stage → party → pertarungan → hasil → kembali ke lobi).
Seluruh aset (model, tekstur, ikon, suara, UI) dibuat sendiri lewat kode/skrip di proyek ini — tidak ada
aset berhak cipta dari game lain. Nuansa lobi terinspirasi umum dari game gacha-RPG, tetapi karakter,
peta, nama, dan UI semuanya orisinal.

## Gabungan 55: bug fade-in lagu (ditemukan audit versi 54)
- **Bug nyata**: bila lagu masih dimuat di thread, fade-in sudah jalan lebih dulu; saat lagu akhirnya mulai, volume diatur -60 dB dan lagu tertinggal senyap. Perbaikan: fade-in dibuat BARU setelah `play()` di `_start_music`. Diuji di Godot: lagu normal, jalur tertunda, dan ganti lagu semuanya mencapai volume target (0 dB / 4,7 dB untuk music_main).
- `|| true` di langkah impor workflow sengaja dipertahankan hanya untuk kode keluar Godot (kadang non-nol saat menutup); kegagalan sebenarnya ditangkap oleh pemeriksaan log + folder `.godot/imported` tepat di bawahnya. Pola log itu tebakan dan belum pernah dijalankan di GitHub.
- FPS governor: tidak diubah lagi sejak 53.

## Gabungan 54: lanjutan audit (dari audit versi 53)
- **Lagu**: bila masih dimuat di thread, `_start_music` menunggu dengan timer (tidak memblok bingkai), maks ~4 dtk lalu muat biasa. Diuji: lagu village main.
- **Impor aset di workflow**: `|| true` dihapus. Build gagal bila log impor memuat error atau `.godot/imported` kosong. Ini juga penyebab mungkin error atlas `get_image on null` bila aset tak terimpor. (Pola error di log adalah tebakan; belum dijalankan di GitHub.)
- **APK debug cadangan dihapus**: bila ekspor rilis gagal, job gagal tanpa APK. Tidak ada lagi APK debug yang bisa terbawa.
- Kunci 30 FPS: tetap ada (melindungi audio di HP berat) tetapi dilepas otomatis (lihat 53).

## Gabungan 53: audit lag/audio (dari temuan asisten lain, dicek di kode)
- **Kunci 30 FPS** (`perf.gd`): benar ada, dan sebelumnya PERMANEN sampai pemain ke Pengaturan. Kini dilepas otomatis setelah 40 dtk untuk mencoba 60 lagi; bila kunci lagi, tahan 2x lebih lama (maks 300 dtk). Tidak menurunkan kualitas grafis tambahan. Diuji di `perf_test`.
- **Lagu dimuat saat pertama diputar** (`sfx.gd`): benar. Kini 9 lagu dimuat di thread latar sejak boot (`ResourceLoader.load_threaded_request`); lagu pertama tidak lagi memuat di frame gameplay. Diuji: 9 lagu terdaftar, lagu village langsung main.
- **Fallback debug di workflow**: benar bisa diam-diam menghasilkan APK debug. Kini bila ekspor RILIS gagal, job GAGAL (merah) dengan pesan jelas; APK debug tetap diunggah hanya sebagai cadangan.
- **Kunci `.jks` di repo**: peringatan itu benar bila repo PUBLIK. Pakai repo privat, atau isi Secrets dengan kunci pribadi.
- **Belum terukur**: apakah ini penyebab lag/audio putus di HP-mu (Infinix). Tidak ada pengukuran di HP; butuh uji langsung.

## Gabungan 52: porting ke APK, kunci tanda tangan tetap
- **Masalah yang ditemukan:** workflow lama membuat keystore debug BARU di tiap build, jadi tiap APK bertanda tangan beda. HP menolak memasang di atas versi lama (harus uninstall = data hilang) dan ID perangkat bisa berubah. Sekarang semua build memakai satu kunci tetap `signing/fantasylife_debug.jks` (alias `androiddebugkey`, sandi `android`, berlaku 100 tahun), sehingga APK baru bisa menimpa yang lama dan data tetap ada. Sidik jari (SHA-1) dicetak di log Actions untuk Play Console. SHA-1 kunci ini: `82:CD:68:9C:2E:CB:63:7A:BD:29:F4:44:3D:7E:61:94:73:D6:8B:DF`.
- Kunci ini kunci debug yang ikut di repo: cukup untuk dipasang langsung (sideload). Untuk Play Store / rilis publik, isi Secrets `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEY_ALIAS`, `ANDROID_KEYSTORE_PASSWORD` dengan kunci pribadimu. JANGAN ganti kunci setelah ada pemain, kalau tidak update ditolak.
- `exclude_filter` ekspor kini juga membuang `signing/*` dan `docs/*` dari APK.
- Peringatan: build lama (kunci acak) tidak bisa ditimpa oleh build ini; sekali ini harus uninstall. SALIN KODE CADANGAN DULU. Setelah itu aman.
- Belum diuji: workflow belum pernah dijalankan (tidak ada akses GitHub/Android SDK di sini); YAML hanya divalidasi sintaksnya.

## Gabungan 51: kode cadangan bisa pindah HP
- Kode cadangan dari perangkat lain kini DITERIMA (sebelumnya ditolak). Tidak ada sanksi/blokir/temuan. Jangan bagikan kodenya ke orang lain (isinya seluruh data). Jalur aman terikat akun = Akun Google (lihat 50).
- Diuji: `save_test` (kode perangkat lain diterima, tanpa temuan).

## Gabungan 50: simpanan akun Google + cadangan akun (tudung Zyrax tipis di 49)
- **Tudung Zyrax**: dibuat tipis & pas di kepala/badan (lapisan tebal dibuang).
- **Akun Google**: autoload `CloudSave`, bungkus save terikat AKUN (`GameState.account_blob/read_account_blob/restore_account_blob`), tombol di Pengaturan > Data dan Layar Judul, simpan otomatis ke akun bila sudah masuk. Konflik data tidak menimpa diam-diam.
- **Diuji**: bungkus/pulih akun (akun lain ditolak, MAC salah, terpotong, konflik, HP baru) di `save_test`; panel Pengaturan & judul dimuat tanpa error.
- **BELUM diuji**: login & Saved Games Google sungguhan (butuh plugin + Play Console milikmu). Panduan: `docs/GOOGLE_LOGIN_SETUP.md`. Tanpa plugin tombol nonaktif.

## Gabungan 48: perbaikan Zyrax (kerudung sedang, teleport tanpa kedip) + error atlas (versi ini)
- **Kerudung Zyrax**: sebelumnya saya salah baca ("bukan gede banget, bukan tipis") dan membuatnya raksasa. Lalu atas permintaan: tudung dibuat TIPIS & pas di kepala/badan (lapisan tebal dibuang, telinga & bahu dikecilkan).
- **Teleport**: jarak 6 m, jeda 0,9 dtk. Momentum diperbaiki (tidak meluncur lewat tujuan) dan tidak lagi berkedip (pakai `immune_t`, bukan `invuln` yang mengedipkan badan).
- **Error `world_mats.gd _build_array ... get_image on null`** (muncul bila proyek dijalankan sebelum impor aset selesai): `WorldMats` kini punya cadangan (muat langsung dari file, atau gambar abu-abu) + peringatan, tidak crash. Bila masih terjadi di editor: tutup, hapus folder `.godot`, buka ulang, tunggu impor selesai.
- **Diuji sungguhan di Godot 4.3 (headless)**: test_data, unit_test, save_test, bot kombo/kiriel/kyomu, `midori_zyrax_bot` (teleport 6,7 m, badan terlihat, 8 bom, sayap ULTI), `ghost_fx_bot` (16 karakter: semua kombo/skill/ULTI lawan muncul).
- **Belum teruji**: rasa main di HP (jarak teleport, keterbacaan efek), foto efek ULTI/teleport (kamera foto tidak menangkap Zyrax), uji dua perangkat PVP/co-op.

## Gabungan 47: Zyrax — dash teleport & ULTI baru (menggantikan "46")
- **Dash = teleport** (khusus Zyrax, `CharacterData.dodge_kind = "teleport"`): melesat ~7 m dalam 0,09 dtk (±5 bingkai; tetap diblok tembok oleh fisika), kebal 0,45 dtk, jeda 0,9 dtk. **Tanpa berkedip**: badan tidak disembunyikan/ditampilkan dan tidak ada kilatan warna; tidak memutar animasi guling. Efek: portal lambang X + cincin + serpihan di titik awal dan tiba, dua garis jejak. Lawan PVP melihat portal yang sama dan hantunya menyusul cepat (`CoopGhost.warp_t`). Kode: `Player.do_dodge`, `ZyraxFx.teleport`.
- **ULTI Void Requiem dirancang ulang** karena versi sebelumnya terlalu mirip ULTI lain (hujan benda dari langit + pilar + cincin). Sekarang berdasarkan motif Zyrax (kubus bermata X, lubang hitam, piksel): (1) **animasi ULTI sendiri** (tangan kanan menjulang memanggil, tangan kiri menekan, hentak ke depan-bawah, membentang; `AnimLibrary._ult_keys("void_requiem")`, dibangun saat runtime); (2) **lubang hitam** (inti hitam + selubung ungu + cakram cyan berputar) terbentuk di atas kepala sambil menyedot serpihan kubus, sayap bayangan mengembang; (3) 7 **Ranjau X Void**: lambang X menyala di lantai bawah musuh, kubus kecil muncul dari tanah, meledak jadi balok X menyapu lantai + serpihan piksel (bukan jatuh dari langit); (4) penutup: lubang hitam runtuh lalu **mekar jadi X raksasa** 8 sinar + serpihan ke segala arah. Tidak ada pilar/hujan cahaya. `ult_kind` Zyrax kini `void_requiem` (dulu `inferno`).
- Angka tetap: jangkauan ULTI 16, ledakan ranjau 4,6, damage ULTI sama seperti sebelumnya; skill Ranjau Void jangkauan 9 (kubus raksasa jatuh di tengah, tetap).
- **Belum teruji**: Godot tidak ada di sini; hanya cek sintaks. Kenyamanan teleport (jarak 7 m, jeda 0,9) dan keterbacaan efek di HP belum dicoba; pose animasi ULTI baru belum dilihat (kemungkinan perlu disesuaikan agar senjata/tangan tak tembus). `midori_zyrax_bot` diperbarui (cek teleport >= 5 m & badan tetap terlihat) tetapi belum dijalankan. Efek "Summon" dari gambar referensi belum dibuat.

---

## Gabungan 45: PVP — efek skill, ULTI & gerakan lawan kini terlihat (versi ini)
**Masalah**: di PVP, kita hampir tidak melihat apa pun saat lawan menyerang. Penyebabnya (di kode): hantu lawan (`CoopGhost`) hanya memainkan efek versi dasar — kombo dianggap 2 langkah umum (padahal tiap karakter punya kombo sendiri), sebagian skill tidak punya efek, dan **ULTI hanya berupa satu cincin + teks**; wujud Pedang Petir Kiriel dan kebalnya juga tak tampak. Sebaliknya hal yang sama berlaku buat lawan yang melihat kita.
**Perbaikan** (semuanya visual; damage tetap dihitung di penyerang seperti sebelumnya, jadi keseimbangan tidak berubah):
- `scripts/stages/ghost_fx.gd` (baru, `GhostFx`): mencerminkan efek sisi penyerang memakai pustaka efek yang sama (CharFx/UltFx/StormFx/ChronoFx).
  - **Kombo**: tiap langkah kombo tiap karakter (arc, cone, spin, slam, pull, multi, wave, **bom Zyrax**, peluru shot/twin/fan/burst/echo/pierce/big, rain, nova, chain) lengkap dengan animasi serang yang benar per langkah.
  - **Skill**: semua 10 jenis (**bomb_field Zyrax** — bom + telegraf area ledakan kelihatan oleh korban; cone, dash_cut 2 tebasan, iai 2 tebasan, nova + lingkaran antisipasi, shockwave, vortex, chrono, chain_bolt, volley 7 panah).
  - **ULTI**: ke-12 `ult_kind` memakai fase yang sama dengan pemiliknya — pengisian, 7 sambaran, penutup; naga bayangan (Kuroha), Gerbang Vortex (Kyomu), Pedang Petir (Kiriel). Sambaran jatuh pada kita bila kita dalam jangkauan (sesuai yang dihitung penyerang).
  - **Peringatan ULTI**: cincin jarak bahaya, banner "AWAS! ULT <nama>" bila kita dalam jangkauan, dan getar kamera yang mengecil menurut jarak — supaya ULTI bisa dihindari.
  - **Pewaktuan**: efek muncul saat animasi "kena" (bukan saat tombol ditekan); arah mengikuti arah serang penyerang (setelah bantuan bidik).
  - **Peluru** lawan di PVP berhenti saat mengenai kita (di co-op melewati rekan). Menghindar kini punya kepulan jejak.
- Jaringan: aksi dikirim sebagai `jenis:langkah:arah` (mis. `attack:2:1.571`); penerima lama yang mengerti `attack` polos tetap aman. Status pemain (`pstate`) bertambah 2 kolom: wujud Pedang Petir dan kebal total — hantu memasang pedang petir dan **selubung petir kebal** (jelas kenapa serangan kita tidak melukai). Paket 10 kolom lama tetap diterima.
- `Stage.ult_tint()` (baru): satu sumber warna ULTI untuk pemilik dan lawan (menggantikan blok warna di `_ult_cast`; hasil identik). `Stage.ghost_fx` kini hanya meneruskan ke `GhostFx`.
- Digabung dengan Gabungan 44 Midori + Zyrax (basis sama, gabungan 43): `Stage.ult_tint` memuat warna ULTI Midori/Zyrax; lawan kini melihat bom Zyrax (ledakan visual, damage tetap di penyerang). Kombo Midori yang wajib-dash tidak mengirim aksi bila ditolak, jadi lawan tak melihat serangan palsu.
- Alat uji: `tools/ghost_fx_bot.gd` — memainkan tiap langkah kombo, skill, dan ULTI semua karakter lewat hantu dan memeriksa efek muncul; plus uji wujud pedang/kebal dan paket lama. Jalankan: `stage.tscn -- --bot=1 --botscript=ghost_fx_bot --stage=pvp_meadow --nocine=1 --fresh`.
- **Belum teruji**: Godot tidak tersedia di lingkungan penyusunan — hanya cek sintaks GDScript (gdparse) dan pencocokan nama fungsi yang dipakai. `ghost_fx_bot` belum pernah dijalankan; dua HP/hotspot sungguhan belum dicoba; beban efek ganda (efek kita + efek lawan) di HP kelas bawah belum diukur; keterbacaan banner/cincin peringatan belum dinilai di layar HP.

---

## Gabungan 44: Midori (★6 kecepatan) + Zyrax (★6 bom) dari spin gacha (versi ini)
Basis = `fantasy_life_rpg_gabungan_43_kombo_karakter.zip` (versi stabil). Dua karakter baru bergaya skin Minecraft dari gambar referensi, masuk kolam ★6 gacha (kolam ★6 kini Hakuya, Kyomu, Midori, Zyrax; karakter total 16).
- **Midori** (Hero, One For All, tipe KECEPATAN, tangan kosong): `attack_cooldown` 0,15 dtk (tercepat). Kombo 3 langkah: **Smash Kilat ×2 lalu WAJIB 1× dash** sebelum **Detroit Smash** (rentetan 5 pukulan) keluar. Tanpa dash, serangan ke-3 menolak jalan dan kombo diulang dari pukulan pertama (muncul teks "Dash dulu!"; setelah 2 pukulan muncul "DASH!", setelah dash "KOMBO SIAP!"). Jendela menekan serang sesudah dash 1,6 dtk. Skill Full Cowling: Smash Beruntun (`dash_cut`, jeda 3,8 dtk). ULTI Detroit Smash 100% (`quake`, efek biru).
- **Zyrax** (Bomber, tipe BOM): serangan biasa melempar bom melengkung ke musuh terdekat; sumbu menyala lalu meledak di area. Kombo: Bom Lempar ×2, lalu 3 Bom Void Besar. Skill **Ranjau Void** (`bomb_field`): 6 bom melingkar + 1 bom besar di tengah, meledak beruntun. ULTI Void Requiem (`inferno`, tiap sambaran disertai ledakan Void ungu).
- Kode: gerbang dash di `Player.do_attack/do_dodge` (kunci `need_dash` di `ComboDefs`); bom di `ComboRunner` (tipe langkah `bomb`, `throw_bomb`, `explode`; bom ada di grup `bombs`); skill `bomb_field` di `Stage._on_swing`. Model: `CharacterLooks._midori/_zyrax`, skin/mata dari `gen_skins.py` & `gen_eyes_box.py` (file kyomu tidak diubah), animasi di `AnimLibrary` (Midori meniru gaya Kyomu tapi serangan 0,56 dtk; Zyrax meniru gaya Kiriel).
- Teruji otomatis (headless): `test_data` LULUS (16 karakter, ★6 > ★5: Midori 160, Zyrax 161), `unit_test`, `save_test`, `combo_bot` semua karakter 0 gagal (DPS Midori 0,81×, Zyrax 1,06× pola lama), `kiriel_bot`, `kyomu_bot`, **`midori_zyrax_bot` baru** (0 gagal: tanpa dash penutup tak pernah keluar, dengan dash keluar, bom meledak, skill menjatuhkan 7 bom, ULTI melukai). `midori_zyrax_look_bot` (butuh xvfb) menghasilkan foto depan/samping/belakang.
- Catatan uji: `charfx_bot` (Zeya puncak node 161 > 160) dan `fidget_bot` gagal ringan saat dijalankan headless di sini; keduanya menyangkut karakter lama dan belum dibandingkan dengan basis murni.
- **Belum teruji**: rasa bermain di HP Android, keseimbangan angka (bukan hasil playtest), efek co-op/PVP untuk bom (lawan belum melihat visual bom Zyrax), cinematic gacha khusus kedua karakter (memakai alur umum), animasi ULTI/skill khas (memakai animasi yang sudah ada).

---

## Gabungan 43: Kiriel (★6 petir) + Kyomu naik ★6 (versi ini)
- **Kiriel** (Mage/Fighter ★6, ramping, tanpa tongkat). Serangan biasa = bola petir jarak jauh. Skill **Petir Berantai**: sambaran melompat ke hingga 5 musuh terdekat (jangkauan 9), musuh terdekat disambar sekali lagi. Skin, mata, rambut, jaket putih-navy dibuat lewat `tools/gen_skins.py` / `gen_eyes_box.py`.
- **ULTI Pedang Petir** (`ult_kind = storm_blade`): 7 sambaran badai lalu Pedang Petir muncul di tangan. Selama wujud ini serangan jadi tebasan jarak dekat berkombo 3 (jangkauan 3,3; ×1,5 damage, penutup ×2,4, kritikal +15%, tembus DEF 40%); setelah habis kembali ke bola petir. Durasi mengikuti bintang kebangkitan: 5 dtk (★1) → 20 dtk (★5), linear. **Bisa dipakai 2x per match** (field baru `ult_charges`; pemakaian ke-2 menyegarkan durasi). Karakter lain tetap 1x.
- Gacha: kolam ★6 sekarang Hakuya, Kiriel, Kyomu. **Kyomu naik ke ★6** (stat dinaikkan; power 157 > semua ★5, Kiriel 159, Hakuya 159).
- Perbaikan sumber: `gen_skins.py` tidak lagi menggambar topeng hitam Kyomu (penyebab wajah hitam) agar regenerasi tidak membawanya kembali. `eye_kyomu.png` hasil sunting manual (jangan jalankan ulang `gen_eyes_box.py` ke assets tanpa memeriksanya).
- Teruji otomatis: `test_data` (LULUS, aturan ★6 > ★5), `unit_test`, `save_test`, `kiriel_bot` (baru; 0 gagal: skill kena banyak musuh, ULTI #1 5 dtk, ULTI #2 ~20 dtk, ULTI #3 ditolak, kembali jarak jauh), `ult_bot`, `run_bot`, `stage_bot`, `party_bot`, `gacha_bot`, `gacha_split_bot`, `clip_probe` Kiriel (0 tembus). `charfx_bot` melebihi batas waktu 10 menit di lingkungan ini dan belum dituntaskan.
- **Belum teruji**: rasa bermain di HP Android; keseimbangan "OP" (angka dipilih wajar, bukan hasil playtest); wujud pedang memakai animasi sword karakter Ren sehingga gerakan serangnya belum khas Kiriel; efek multiplayer/PVP untuk ULTI Kiriel (lawan hanya melihat efek ULT umum).

---

## Gabungan 42: animasi, gameplay, misi (versi ini)
- **Animasi Kyomu**: serangan dagger 1 dan 2 kini punya sentakan pergelangan (siap-tarik, lalu hentak saat kena) dan gerak lanjutan (kepala dan badan meluncur lewat titik kena sebelum pulih). Dicek lewat render pose; `clip_probe` Kyomu 0 animasi bermasalah. Animasi karakter lain tidak diubah.
- **Luput Sempurna**: menghindar (dodge) tepat saat serangan musuh akan kena memberi +2 combo, mempercepat dodge berikutnya 0,4 dtk, dan gerak lambat 0,3 dtk (solo, bila opsi hit-stop menyala). Jeda 1,2 dtk antar pemicu. CATATAN: kodenya dimuat dan stage/run/ult/combat_cost bot lulus, tetapi pemicunya sendiri belum diuji otomatis; rasa jendela waktunya belum dicoba di perangkat.
- **4 misi sampingan baru** (`qk_kelelawar`, `qk_jamur`, `qk_rantai`, `qk_ronin`): misi kalahkan musuh berantai dengan hadiah emas, EXP, berlian, dan item. Total misi 29. Jumlah misi di `test_data` diperbarui 25 → 29. Perlu dicoba main untuk menilai keseimbangan hadiah.
- Tidak ditambah dialog/bab baru pada putaran ini.

---

## Gabungan 41: Gabungan 40 + perbaikan Kyomu (versi ini)

Basis = `fantasy_life_rpg_gabungan_40.zip` (gacha + suara). Ditambah perbaikan Kyomu dari putaran sebelumnya; file Kyomu tidak bentrok dengan gabungan 40 (hanya `skin_kyomu.png`, `eye_kyomu.png`, `character_looks.gd`, `anim_library.gd`, `tools/kyomu_look_bot.gd`).

### Perbaikan Kyomu (wajah, pedang, animasi)
- Wajah hitam: topeng hitam di tekstur kulit (`skin_kyomu.png`, baris y=13–15) tepat di bawah mata, dan kelopak mata di `eye_kyomu.png` terlalu tebal. Keduanya diperbaiki; kerah juga diturunkan. Diperiksa lewat render depan.
- Pedang tembus: bilah dipendekkan (1.05 → 0.8), titik uji tembus `FIT_WEAPONS["kyomu"]` diskalakan ulang, dan pergelangan tangan dimiringkan ke depan-bawah saat serangan/skill. `tools/clip_probe.gd` melaporkan 0 dari 19 animasi bermasalah untuk Kyomu.
- Catatan jujur: yang diperiksa hanya render pose statis + ukur tembus; gerakan hidup di perangkat Android belum diuji. Pose serangan 1 masih membuat dua bilah bersilang di depan dada (tidak menembus badan menurut ukuran, tapi dekat).

---

## Gabungan 40: Gacha lebih wajar + suara menggelegar (versi ini)

**Efek.** Kemegahan kini bertingkat menurut rarity terbaik: ★3 ke bawah singkat dan tenang (glif 0,7 dtk, tanpa terowongan, kilatan kecil); ★4 menengah; hanya ★5+ yang penuh (terowongan cahaya, dentuman, sinar berputar). Lingkaran sihir bertekstur rendah dibuang (terlihat ramai/dipaksakan), diganti gelombang kejut + percikan yang digambar kode. Glif dibersihkan. Pada tarikan 10x, ledakan penuh dan getar layar hanya untuk ★5+ PERTAMA; berikutnya cukup denting. Getar layar mengikuti pengaturan "Getar & zoom efek".
**Suara** (baru, stereo 44,1 kHz, dibuat `tools/gen_gacha_audio.py`, tanpa aset luar): `gacha_charge` (gemuruh naik), `gacha_star` (lonceng kristal, pitch naik per bintang), `gacha_burst` (dentuman: sub-bass jatuh dijenuhkan agar terdengar di speaker HP + retakan + gemerlap + akor + gema ruang), `gacha_reveal` (paduan nada + arpeggio untuk ★5+), `gacha_card` (kartu biasa). Dibanding `boom` lama, dentuman baru ~7 dB lebih keras (RMS) dan punya energi 150-2000 Hz (boom lama 95% di bawah 150 Hz, nyaris tak terdengar di speaker HP). Terdaftar di `Sfx.SFX_NAMES`; bila file belum terimpor, cadangan ke suara lama otomatis (FALLBACK).
Belum diuji di Godot dan belum didengar di HP nyata: jalankan CI `--import` atau buka di editor agar .wav baru terimpor; atur volume lewat `Sfx.play(nama, pitch, dB)` di `gacha_reveal.gd` bila terlalu keras.

---

## Gabungan 39: Animasi gacha baru

`scripts/ui/gacha_reveal.gd` diperluas (bukan sistem kedua; `GachaPanel` dan bot lama tetap memakainya). Urutan baru: (1) glif bintang menyala di layar gelap, satu bintang per tingkat rarity terbaik, nadanya naik; (2) terowongan cahaya, garis melesat dari tengah; (3) lingkaran sihir lama; (4) kilatan lalu kartu dibalik satu per satu. Untuk ★5+ ada sinar berputar di belakang kartu. Semuanya digambar lewat kode (kelas dalam `GachaFx`), tanpa aset gambar atau video. Ketuk = lewati; hasil tarikan sudah diterapkan sebelum animasi, jadi melewati aman. Durasi intro: sekitar 1,9 dtk (best ★3 ke bawah) sampai 2,8 dtk (★4+). Kartu hasil lebih besar, teks 19-28, tombol OK/Tarik lagi memakai gaya tema. Panel Gacha: warna Kristal, kartu hasil sedikit lebih tinggi.
Belum diuji di Godot: periksa `gacha_bot` (tangkapan layar gacha_charge/flash/cards_back) dan bandingkan rasanya di HP.

---

## Gabungan 38: Pengaturan dirapikan

`scripts/ui/panels/settings_panel.gd`, hanya tata letak (kunci pengaturan dan perilaku tidak berubah):
- Slider dan pilihan memakai kartu bertumpuk: nama + petunjuk di atas, kontrol selebar kartu di bawah (dulu kolom kiri dipatok 330 px sehingga slider sempit dan petunjuk panjang menumpuk).
- Tombol pilihan (kualitas, resolusi, AA, dst) berbaris dengan `HFlowContainer` dan turun baris otomatis; yang terpilih terisi warna aksen. Penjelasan pilihan kini di dalam kartu yang sama.
- Saklar AKTIF/MATI tetap di kanan, petunjuk di kiri dengan teks membungkus.
- Judul bagian: batang aksen + teks 27, jarak antar-kelompok lebih lega. Teks bantu minimal 18, tombol tinggi 60, tab 23, grid Uji Animasi 3 kolom.
- Belum diuji di Godot: jalankan `settings_bot` (tangkapan layar tiap tab) dan lihat tab Grafis serta Data.

---

## Gabungan 37: UI Kristal + penyempurnaan UI v4

**Gabungan.** Basis = `fantasy_life_rpg_gabungan_36.zip` (UI Kristal Aurelia: palet cyan, sudut diagonal, vinyet, bot tangkapan layar). Ditambah perombakan UI v4 yang tidak bentrok; warna Kristal tetap dipakai, tidak diganti.

**Dari v4 yang dimasukkan.**
- Tema: teks dasar 24, tombol minimal tinggi 56, tidak ada label di bawah 18 (`UiTheme.MIN_FONT`), tombol aksen berlatar penuh dengan teks gelap (`UiTheme.INK`), garis tepi 1 px pada keadaan biasa.
- `autoload/ui_fx.gd` (baru, terdaftar di `project.godot`): semua tombol menciut saat ditekan dan memantul saat dilepas (mati pada `--bot=1`; tombol dengan meta `no_fx` dikecualikan).
- Bingkai menu: jendela memudar + membesar halus saat dibuka, bayangan, tombol tutup lebih besar.
- Dialog: masuk dengan geser naik, menghormati area aman (notch), teks 27, tombol pilihan 60.
- HUD lobi: profil, pelacak quest, dan minimap dalam satu kolom kiri (`_left`, tersusun otomatis), menu 86 px dengan label 19, tombol Start 310x74, teks lebih besar. API publik HUD tidak berubah.

**Belum diuji di sini** (tidak ada Godot di lingkungan penyusunan). Jalankan `tools/` bot yang biasa (panel_bot, hud_perf_bot, layout_audit, ui_shot_bot) dan cek HUD lobi, 3-4 menu, dialog NPC, serta teks yang meluber akibat batas 18.

---

## Poles grafis (lanjutan UI Kristal)

- **Ikon & UI art:** semua ikon buatan `UiIcon.make()` kini punya bayangan jatuh (salinan dihitamkan, digeser kanan-bawah) agar terangkat dari panel kaca.
- **Dunia/layar:** vinyet kristal (`scripts/ui/vignette.gd`) di stage dan lobi pada kualitas Sedang/Bagus (mati di Lancar untuk hemat fill-rate). Efeknya halus.
- **Karakter, musuh, efek skill:** diaudit lewat tangkapan layar; sudah memakai cel-shading, rim light, hit-stop, dan efek khas per karakter, jadi **tidak diubah** pada putaran ini. Outline karakter sengaja tidak ditambahkan: model bergaya kubus bernormal keras membuat teknik outline "hull" retak di sudut, dan menambah beban HP lemah.
- **Diuji:** test_data, unit_test, save_test, perf_test, run_bot, story_bot, hub_bot, panel_bot, ult_bot, hud_perf_bot lulus. `stage_bot` kadang gagal "result matches expectation" (1 dari 3 putaran) karena bot kalah di stage; belum saya pastikan apakah itu juga terjadi sebelum perubahan grafis.
- **Belum:** pengukuran FPS di HP nyata; efek vinyet dan bayangan ikon di layar kecil.

---

## UI "Kristal Aurelia" + gabungan Grafis v3 (versi ini)

**Gabungan.** `fantasy_life_rpg_grafis_v3.zip` ternyata sudah berbasis proyek rombak sebelumnya (cerita Bab 1-6 + Berkah Bintang), ditambah perbaikan grafis: resolusi 3D lebih tajam (`Perf`), sinematik resolusi penuh, kamera dengan tabrakan bangunan, bingkai percakapan, dan getar/zoom efek (Pengaturan → "Getar & zoom efek"). Tidak ada konflik; ZIP itu dipakai sebagai basis.

**UI baru.**
- Palet: kaca gelap kehijauan-biru + aksen cyan-perak (`UiTheme.GOLD/GOLD_DARK` kini berarti "aksen utama"; uang tetap emas lewat `UiTheme.COIN`). Panel, tombol, tab, slider, scroll mengikuti otomatis.
- Bentuk: sudut diagonal (kiri-atas & kanan-bawah membulat besar, dua lainnya hampir tajam).
- Kontrol sentuh: tombol aksi heksagon kristal, joystick dengan empat penanda arah dan kenop heksagon.
- HUD stage: info gelombang dalam pelat kaca, tombol jeda dan kartu party diperkecil; HUD lobi, Menu, judul, loading, toast, dan minimap diselaraskan.
- Tidak ada fitur/tombol baru, hanya tampilan; tata letak dan fungsi sama.

**Diuji (Linux, layar virtual):** test_data, unit_test, save_test, perf_test, layout_audit, run_bot (2x), story_bot, hub_bot, panel_bot, menu_bot, adventure_flow_bot, settings_bot, stage_bot; dicek lewat tangkapan layar: HUD stage, HUD lobi, Menu, panel Party. **Belum:** tampilan di HP nyata (ukuran sentuh/keterbacaan di layar kecil), panel lain satu per satu secara visual, dan layar judul setelah perubahan warna tombol.
`run_bot` pernah gagal karena slime kecil muncul setelah pembersihan; sudah diperbaiki.

---

## Rombak Besar: Gabungan + Cerita Ulang + Gameplay Berkah (versi ini)

**Gabungan.** `fantasy_life_rpg_gabungan_35.zip` dan `fantasy_life_rpg_update.zip` disatukan di satu proyek (35 stage → 39, 24 quest → 25).

**Cerita ditulis ulang (tokoh utama: Ren).** 6 bab + prolog + epilog, 69 adegan, 15 sinematik 3D, dan dialog tengah-pertarungan ("bark") untuk 32 stage.
Alur: Prolog Aurelia → Bab 1 Golem yang menjaga penambang → interlude Desa Fajar → Bab 2 prasasti tiga Penjaga → Bab 3 Dewa Wither → Bab 4 Uranos & motifnya → Bab 5 Menara Rantai Merah (bayangan Raja Rantai) → kepulangan ke Aurelia → **Bab 6 "Lagu yang Belum Selesai"** (stage 6-1…6-3 + bos Kaedros, penutup sinematik Ren menyanyikan bait ketiga) → epilog.
Naskah ada di `tools/story_src_a/b/c.py`; `python3 tools/gen_story.py` membangun `data/story.json` dan `data/cinematics.json`.

**Gameplay tidak monoton.** Modul `scripts/stages/stage_run.gd`:
- **Berkah Bintang**: 14 berkah, pilih 1 dari 3 di sela gelombang (bisa menumpuk hingga 4×).
- **Tantangan stage**: Lingkaran Segel (berdiri di lingkaran), Bertahan (hitung mundur), Pemimpin Pasukan (kalahkan jenderal elit). Hadiah: gold/EXP, pemulihan, bonus langka.
- Tidak aktif di bos, wilayah jelajah, PVP, co-op; bisa dimatikan di Pengaturan → "Berkah & tantangan".

**Diuji (Linux, headless + layar virtual; bukan di HP):** test_data, unit_test, save_test, perf_test, layout_audit, run_bot (berkah/tantangan/bark), story_bot, story_stage_bot (1-B dan 6-B), hub_bot (kota & desa), bab_desa_bot, village_bot, adventure_flow_bot, stage_bot, dan pemutaran 15 sinematik. Semua lulus pada putaran terakhir; `run_bot` pernah sekali gagal karena waktu tunggu terlalu pendek (sudah diperbaiki).
**Belum diuji:** pertarungan penuh Kaedros sampai kalah oleh pemain nyata, keseimbangan level Bab 6 (angka level/HP/ATK adalah perkiraan), tampilan di HP Android, performa di perangkat nyata, dan seluruh stage Bab 2-5 dimainkan manual. Teks dan sinematik baru belum dibaca ulang oleh penutur bahasa Indonesia lain, jadi typo mungkin ada.
Catatan: stage 2-2…4-3 tertentu tidak punya adegan penutup (sengaja, dari data asli).

---

## Cara membuka & menjalankan
1. Pasang **Godot 4.3** (atau 4.3+ stabil) — versi *Standard* (GDScript), bukan .NET.
2. Ekstrak ZIP, buka Godot → **Import** → pilih `project.godot`.
3. Tunggu impor aset pertama kali selesai, lalu tekan **F5** (scene utama: `scenes/title.tscn`).
4. Renderer: **GL Compatibility** (sudah diatur) supaya ringan di Android.

### Godot Android Editor (di HP)
1. Pasang Godot 4.3 Android Editor, salin folder proyek ke penyimpanan HP, lalu **Import** `project.godot`.
2. Jalankan langsung dengan tombol ▶ (editor Android dapat menjalankan proyek di perangkat yang sama).
3. Ekspor APK: *Project → Export → Android*. Preset sudah ada (`export_presets.cfg`, arm64-v8a,
   paket `com.fantasylife.rpg.lobby`). Isi keystore debug jika diminta (atau matikan *Signed*), lalu *Export Project*.
   Jika templat ekspor belum ada, editor akan menawarkan untuk mengunduhnya.

> Catatan jujur: proyek ini **belum pernah diekspor ke APK / dijalankan di perangkat Android** oleh saya.
> Pengujian dilakukan di Linux (headless + layar virtual). Performa di HP nyata belum diukur.

## Dukung Developer
- Panel **Dukung Developer** (`scripts/ui/panels/support_panel.gd`) membuka halaman Saweria developer: https://saweria.co/Yumantara
- Pintu masuk: kartu **Dukung Dev** di Menu, tombol **Dukung Developer** di layar Judul (kanan-bawah), dan Pengaturan → Data → "Dukung developer".
- Tautan & fungsi pembuka ada di `scripts/systems/support.gd` (`Support.URL`); bila browser gagal dibuka, tautan disalin ke papan klip.
- Dukungan sukarela dan tidak memberi item/keuntungan di dalam game.

## Watermark
- Teks **"Yumantara Official"** tampil semi-transparan di pojok kiri-bawah layar pada semua scene (`autoload/watermark.gd`, autoload `Watermark`, layer 100, tidak menangkap sentuhan). Ubah `TEXT` / `ALPHA` / `FONT_SIZE` di file itu.

## Perbaikan bug (review kode)
- `autoload/game_state.gd` `flag_cheat`: pengecekan "jenis sama dalam 1 jam tidak dicatat ulang" sebelumnya hanya memeriksa entri terakhir (ada `break` tanpa syarat), sehingga catatan bisa terduplikasi bila jenisnya berselang-seling. Kini memeriksa semua entri dalam 1 jam terakhir.
- `load_game`: tahan terhadap save rusak/hasil edit (isi roster/equipment/quests/stages/flags/stats bertipe salah tidak lagi menyebabkan error skrip), dan karakter di roster yang tidak punya data equipment otomatis diberi equipment awal (mencegah error di `equip()`).
- Belum diuji di Godot (tidak ada Godot di lingkungan ini).

## Perbaikan multiplayer / server host
(Server = HP host lewat WiFi/hotspot, ENet; tidak ada server internet.)
- Duel PVP tidak bisa dimulai sendirian (sebelumnya host bisa menekan Mulai tanpa lawan lalu menunggu 150 dtk). Kini: "Duel butuh 2 pemain".
- Koneksi yang tidak mengirim autentikasi dalam 6 detik dikeluarkan (tidak lagi menahan slot room).
- Autentikasi ganda dari peer yang sama diabaikan (sebelumnya bisa membuat peer sah ditolak "Room penuh" lalu diputus).
- Nama pemain dari client dirapikan (kosong -> "Pemain"), ID karakter tak dikenal -> "ren".
- Paket jaringan tidak lengkap (status pemain, snapshot musuh, meta) diabaikan, tidak lagi menyebabkan error indeks.
- Damage dari client dibatasi (1..99999; PVP 0..9999; knockback 0..30).
- Gabung manual boleh mengetik `IP:port` (mis. `192.168.43.1:47778`); port divalidasi.
- Belum diuji dengan dua perangkat/Godot (tidak ada Godot di lingkungan ini). Uji dengan `tools/coop_test.gd`.

## Kontrol
| Aksi | Sentuh (Android) | Keyboard | Gamepad |
|---|---|---|---|
| Gerak (8 arah) | Joystick kiri (melayang/tetap, diatur di Pengaturan) | WASD / panah | Stik kiri |
| Serang | Tombol kanan-bawah | J / Spasi | X |
| Skill | Tombol biru | K | Y |
| Hindar (dodge) | Tombol hijau | L / Shift | B |
| Interaksi / bicara | Tombol kuning (menyala bila ada target) | E / F | A |
| Kamera | Seret layar di luar kontrol (putar), cubit (zoom) | Q / R | – |
| Ganti karakter (di stage) | Ketuk kartu karakter di kiri-atas | 1–4 | – |
| Kembali / jeda | Tombol Back Android | Esc | Start |

Mode tangan kidal, ukuran tombol, ukuran/opasitas joystick, getar, dan grafis ada di **Pengaturan**.

## Isi game
- **Lobi "Aurelia"**: plaza dengan air mancur, guild, portal, toko senjata/armor, toko ramuan, pandai besi,
  area quest/NPC, rumah, taman, jalan, gerbang kota, area party. Siklus siang-malam.
- **Karakter utama** model blok-anime (bukan kapsul) dengan animasi Idle/Walk/Run/Turn/Attack/Skill/Damage/Death.
- **NPC (8 + 4 warga berjalan)**: Orwen (Guild Master), Rowan (Pedagang), Mira (Ramuan), Tobias (Pandai Besi),
  Selin (Info), Kael (Party), Elio (Penjaga Gerbang), Pip (Pendeta); dialog bercabang.
- **UI**: profil + Lv, HP, gold, diamond; tombol Character, Party, Inventory, Equipment, Quest, Gacha, Shop,
  Settings, Start Adventure — semuanya membuka panel yang berfungsi.
- **Petualangan**: pilih stage (5 stage: padang, hutan, gua, bos Golem Kristal, dan bos baru Penguasa Gua di arena "Sarang Penguasa Gua"), pilih/atur party,
  gelombang monster (slime, kelelawar, jamur, 2 bos masing-masing 2 fase), ramuan, jeda, layar hasil (menang/kalah,
  bintang 1–3, hadiah), kembali ke lobi. Progres tersimpan.
- **Sistem**: gacha (rate 2/10/28/30/30 %, pity 50, 10× menjamin ≥4★), tempa senjata, jual-beli, equipment,
  quest dengan klaim hadiah, simpan/muat (JSON di `user://`).

## Update: tombol "Lanjut", UI hasil baru, anti-nyangkut
- **Layar hasil** (`scripts/stages/stage_result.gd`): tata letak baru (kartu Waktu/Monster/Gold/EXP/Diamond, bintang animasi) dan tombol **Lanjut ▶** ke stage berikutnya (hanya solo, menang, dan stage berikutnya sudah terbuka). Urutan mengikuti `Data.stage_order`.
- **Monster nyangkut** (`scripts/stages/enemy.gd`): sebelumnya musuh mengejar lurus sehingga tersangkut batu/pilar. Sekarang: deteksi mandek ±0,4 dtk → geser menyamping menyusuri rintangan → bila berulang 3× dipindah ke titik kosong 4,5–8 m dari pemain. Musuh yang jatuh/keluar arena juga otomatis diselamatkan.
- **Map arena** (`scripts/stages/arena.gd`, `stage.gd`): tengah arena (72% radius) kini bebas batu/pilar/stalagmit; rintangan hanya di cincin tepi dan menjauhi 6 titik spawn tetap. Monster muncul di titik-titik tsb (bukan acak lagi), jadi tidak bisa lahir di dalam batu.
- **Mode SUSAH** (semua stage): HP musuh biasa ×3,3 / bos ×2,3, serangan ×1,45 / ×1,3, lebih gesit (+12% / +8%), aba-aba kroco lebih singkat, pulih lebih cepat, jeda antar-serangan lebih pendek, jumlah musuh per gelombang ×1,3, peluang elit lebih tinggi. AI kroco membidik ke depan arah gerak pemain dan mengapit dari sisi berbeda. Semua angka ada di konstanta atas `enemy.gd` dan `WAVE_COUNT_MULT` di `stage.gd`.
- Belum diuji di Godot oleh saya (tidak ada Godot di lingkungan ini) — mohon uji manual.

## Konsep & jalan cerita (diperbarui)
- **Tema utama: menjaga vs mengurung.** Para Penjaga Segel punya dua cara melindungi dunia dari Kehampaan: *menanggung* (Dewa Wither memikulnya di tubuhnya) atau *mengikat* (Raja Rantai Merah, yang akhirnya menjadikan perlindungan sebagai penjara). Ren, si Anak Bintang, menjadi jalan ketiga: menjaga tanpa mengurung.
- **Asal tanda Ren:** ia ditemukan bayi di atas Kristal Bintang oleh Master Orwen, jadi tandanya adalah kunci segel yang baru.
- **Lyra:** gurunya hilang saat meneliti segel; petunjuknya bersambung dari 2-2 ke Tarekat Topeng Putih di Bab 4. **Brann:** putra penambang Gua Kristal, jadi tiap stage gua punya arti pribadi baginya.
- **Adegan baru** (`data/story.json`): 1-2 Hutan yang Berbisik, 1-3 Kristal yang Menangis, 2-2 Bara yang Bukan Api, 2-3 Sebelum Sarang. Sebelumnya stage-stage ini tanpa cerita.
- **Perbaikan kesinambungan:** Raja Rantai Merah kini "Penjaga yang tersisa" (bukan "yang pertama", agar tidak bentrok dengan Dewa Wither), dan Wither menabur petunjuk tentang penjaga yang memilih jalan "mengikat".

## Logika tembus / tidak tembus (diperbarui)
- **Padat (menghalangi pemain & musuh darat):** batu, kristal, pilar, stalagmit, batang pohon, pagar, bangunan, bangku, peti, tong, dinding arena. Tajuk pohon sengaja tembus (hanya batangnya yang padat).
- **Lunak / tembus:** semak dan hamparan bunga/rumput (bisa diterobos, tidak membuat tersangkut). Kristal kini punya tabrakan (dulu bisa ditembus padahal tampak padat).
- **Rintangan rendah (puncak < 1,25 m)** punya layer sendiri (16): musuh **terbang** (kelelawar) melintas di atasnya, musuh darat & pemain tetap terhalang. Rintangan tinggi menghalangi semua.
- **Peluru** (bolt/batu/panah) kini tertahan rintangan tinggi (pilar, pohon, dinding) dan melewati yang rendah.
- Kode: `collider_sink.gd` (pemisahan layer), `decor.gd` (semak tanpa tabrakan), `arena.gd` (kristal padat di cincin tepi), `projectile.gd` (raycast), `enemy.gd`/`player.gd` (mask).

## Struktur folder
```
autoload/      Data, GameState (simpan/muat), Sfx, Flow (pindah scene + toast)
scenes/        title.tscn, lobby/lobby.tscn, stages/stage.tscn
scripts/
  lobby/       lobby.gd, lobby_world.gd, lobby_layout.gd, day_night.gd
  buildings/   bangunan prosedural
  characters/  rig, animasi, tampilan karakter
  player/ npc/ camera/ title/
  stages/      stage.gd, enemy.gd, arena.gd, fx, proyektil, HUD, hasil
  ui/          tema, ikon, HUD, dialog, kontrol sentuh, panel_host + panels/
  systems/     gacha, quality, mesh_kit, material dunia
resources/     data karakter, item, quest, stage (.tres)
shaders/       toon_flat.gdshader dll.
assets/        audio (dibuat skrip), tekstur, material, model
tools/         skrip uji/bot & pembuat aset (tidak ikut di APK)
```

## Status jujur
### Berfungsi (sudah diuji — hasil nyata, bukan perkiraan)
Diuji di Godot 4.3 Linux, headless / layar virtual (xvfb), renderer OpenGL3:
- `tools/test_data.tscn`: data 4 karakter, 33 item, 12 quest, 5 stage termuat — **LULUS**.
- `panel_bot`: klaim quest (+200 gold), beli senjata & ramuan, pasang equipment, tempa +1, party, gacha ×10
  (900 diamond, ≥4★) — semua pemeriksaan lulus.
- `stage_bot` (bot bermain otomatis): menang di s1_1, s1_2, s1_3, s1_boss, dan s2_boss; rekor tersimpan; jalur
  **kalah** (`--lose=1`) menampilkan layar KALAH dengan hadiah hiburan.
- `flow_bot`: lobi → Pilih Stage → Mulai → stage → hasil → "Kembali ke Lobi" → lobi — semua pemeriksaan lulus.
- Layar judul tampil dan berpindah ke lobi.
- Tangkapan layar lobi, HUD, dialog, panel, dan tiap tema stage sudah dilihat langsung.

### Lagu utama
`assets/audio/music_main.mp3` ("obsesius", dibuat pengguna dengan Suno, 3:25) dipakai sebagai lagu layar judul dan lobi, berulang otomatis.
Intro-nya sengaja sangat pelan (piano minimalis) sehingga detik-detik pertama terdengar nyaris sunyi; ini bukan bug. Bila gagal dimuat,
`sfx.gd` memakai `music_village`. Pastikan kamu berhak memakai lagu ini jika game dipublikasikan.

### Animasi kroco (slime, kelelawar, jamur)
Digerakkan kode di `enemy.gd` (`_animate_slime/_bat/_mushroom`): slime melompat dengan tekan-regang (squash & stretch) dan menekuk sebelum menerkam;
kelelawar mengangkat sayap saat aba-aba, merapatkannya saat menukik, dan miring saat mengitari; jamur bergoyang berjalan, menggembung bergetar,
lalu kempis setelah menyemprot spora. Semua punya kedutan saat terkena pukulan, "pop" saat muncul, dan kematian khas
(slime menguap, kelelawar jatuh berputar, jamur pecah). Dilihat lewat lembar kontak `tools/minion_sheet.gd` (rekaman potongan gambar per 0,14 s).
Belum dinilai: kenyamanan/kehalusan gerak di HP dan perasaan "juicy" oleh pemain sungguhan.

### Adventure Bab 2 dan tata kota
- Stage baru: 2-1 Lorong Bayangan (gua, Lv 8), 2-2 Jurang Bara (sarang, Lv 8), 2-3 Gerbang Sarang (sarang, Lv 9, 4 gelombang), lalu 2-B Penguasa Gua.
  Berurutan: tiap stage terbuka setelah yang sebelumnya selesai. Daftar Pilih Stage kini dikelompokkan per bab.
  Bot menang di 2-1 dan 2-2; 2-3 pernah dikalahkan bot pada versi pertama (terlalu berat) sehingga jumlah monster dikurangi; setelah itu bot menang di 2-3 (Lv 9).
- Lobi ditata ulang (`lobby_layout.gd`): jalan utama selatan-utara, bulevar timur-barat (kamp party di ujung barat, portal di ujung timur),
  dua jalan samping, bangunan selalu menghadap jalan, pohon berjajar di tepi jalan. Dilihat lewat foto atas (`tools/lobby_overview.gd`).
  NPC dipindah ke depan bangunannya dan menghadap jalan. Belum dijalani/diperiksa langsung dengan karakter di setiap sudut kota.

### Bos Penguasa Gua (stage 2-B, ditambahkan dari model GLB buatan pengguna)
- Model `assets/boss/cave_monster_rigged.glb` + `scripts/stages/monster_rig.gd` + `scenes/stages/monster_rig.tscn`
  (6 animasi: Idle, Walking, Attack, HitReaction, Death, Roar) dipasang sebagai musuh `cave_beast` di `enemy.gd`.
- Serangan: **Cakar** (area di depan), **Seruduk** (melesat lurus, lalu terengah), **Raungan** (gelombang kejut). Fase 2 di HP 50 %:
  lebih cepat, meraung, dan memanggil 2 kelelawar. Tiap serangan punya lingkaran peringatan merah/oranye.
- Arena baru bertema `lair` (`arena.gd`): lantai batu gelap, retakan bara menyala, stalagmit, kristal oranye. Stage `resources/stages/s2_boss.tres`
  (Lv rekomendasi 10, terbuka setelah 1-B).
- Sinkronisasi animasi (`enemy.gd`, `_animate_beast`): puncak gerakan klip (cakar menghantam di 0,6 s, raungan penuh di 1,0 s) disetel jatuh tepat
  saat serangan mengenai; klip tidak lagi dimulai ulang saat serangan; seruduk menahan pose bersiap lalu berlari; jalan memakai kecepatan klip 1,6×.
  Diukur otomatis oleh `tools/anim_check.gd` (selisih posisi klip < 0,2 s). Kaki masih sedikit "meluncur" saat bos berlari karena klip jalan
  dibuat untuk langkah lebih pendek dari kecepatan gerak bos.
- Suara bos (dibuat skrip `tools/gen_boss_audio.py`): raungan, geraman, desir cakar, benturan cakar, gemuruh seruduk, tabrakan,
  gelombang kejut, langkah berat (juga dipakai golem), kesakitan, kematian, plus musik `music_lair` untuk stage 2-B.
  Pengujian otomatis (`tools/sfx_probe.gd`) memastikan ke-10 efek benar-benar terpicu saat pertarungan dan musik yang terpasang `music_lair`.
  Bila file suara baru gagal dimuat, `autoload/sfx.gd` memakai suara lama sebagai cadangan (dan mencatat peringatan di log) supaya tidak senyap; suara bos panjang punya pemutar khusus agar tidak terpotong.
  **Saya tidak bisa mendengar hasilnya** — kualitas/keras-pelannya belum dinilai telinga manusia; volume per efek diatur di `enemy.gd` (`_sfx(...)`).
- Yang sudah dilihat langsung lewat tangkapan layar: bos muncul, tiap serangan (windup + strike), kena pukul, fase 2, dan mati.
  Bot menang di stage ini. **Belum** dinilai: keseimbangan dan kesesuaian waktu animasi dengan momen serangan oleh manusia
  (waktu serangan diset kira-kira; mungkin perlu disetel), serta performa model di HP.

### Karakter baru Zeya + bonus login 3 hari
- **Zeya** (Pendekar Bayangan, kelas Assassin): pedang, serangan arc cepat (jeda 0,32 dtk, jangkauan 2,4), skill "Tebasan Bayangan" (kerucut ×2,8, jeda 5,5 dtk), HP/ATK/DEF dasar 95/14/3, gerak 6,6.
  Hanya didapat dari bonus login (tidak ada di gacha). Skin dibuat `tools/gen_skins.py`, perlengkapan (jubah, ikat kepala, sabuk) di `character_looks.gd`.
- **Bonus login 3 hari**: tombol "Hadiah" di HUD kanan atas (titik merah bila ada hadiah) dan panel terbuka otomatis saat masuk lobi bila ada hadiah.
  Satu klaim per hari kalender (jam perangkat), tidak harus berturut-turut. Hari 1: 1.000 emas + 100 berlian + 3 Ramuan Kecil;
  hari 2: 1.500 emas + 150 berlian + 2 Ramuan Besar; hari 3: Zeya + 200 berlian. Progres tersimpan di file simpanan.
- Diuji (bot `tools/login_bot.gd`, tanggal dipalsukan lewat `--date`/`_fake_date`): ketiga hadiah diterima sesuai jumlah, klaim ganda di hari sama ditolak,
  jeda seminggu tetap bisa klaim, setelah selesai tidak bisa klaim lagi, Zeya terbuka dengan senjata awal, progres bertahan setelah simpan lalu muat ulang proses.
  Tampilan panel, tombol, dan model 3D Zeya dilihat lewat tangkapan layar.
- Belum diuji: pergantian tanggal nyata di HP (hanya tanggal palsu), perubahan jam perangkat/zona waktu (pemain bisa memajukan jam untuk klaim lebih cepat; tidak ada pengecekan server),
  dan Zeya dipakai bertarung di stage (tidak dijalankan khusus untuk Zeya).

### Animasi serang & skill berfase
- Semua animasi serang/skill (pedang ×2 kombo, tongkat, hantam Guardian, panah, dan skill tiap kelas) ditulis ulang dengan fase jelas:
  **antisipasi** (menarik/menggulung badan) → **ayunan cepat** (melewati target sedikit agar bertenaga) → **tahan/follow-through** → **pemulihan** ke siaga.
  Skill Guardian: jongkok → lompat → banting; skill penyihir: kumpulkan tenaga (badan naik) → hunjam; skill pedang: gulung badan → sapuan putar.
- Damage, efek tebasan, dan suara "swing" kini jatuh tepat di momen impak animasi (`AnimLibrary.IMPACT`), bukan waktu tetap. Karakter juga terdorong sedikit
  ke depan saat tebasan mengenai (mundur sedikit untuk tembakan), dan berkilau warna aksen saat mengumpulkan tenaga skill.
- Diuji (`tools/attack_sheet.gd`, waktu diperlambat): untuk 5 karakter × (serangan 1, serangan 2, skill) sinyal damage jatuh dalam 0,08 dtk dari waktu impak animasi
  (selisih terukur 0,00–0,02 dtk). Lembar frame tiap fase dilihat langsung untuk pedang dan hantam; bot stage 1-1 tetap menang 3 bintang.
- Belum dicoba: rasa/ritme animasi di tangan sungguhan (HP), dan efek lunge terhadap tabrakan di sudut sempit; kesan "kaku" bersifat subjektif — sesuaikan angka pose di `anim_library.gd` bila perlu.

### Efek skill Nova Bintang (Lyra)
- Saat Lyra mengumpulkan tenaga, **lingkaran sihir bintang** (cincin rune, heptagram, bintang segi lima) muncul di tanah di atas piringan biru gelap lembut,
  dua lapisannya berputar berlawanan arah dan bintang-bintang kecil naik. Tepat di momen damage, lingkaran berdenyut terang, dua cincin gelombang
  melebar, dan percikan bintang menyebar, lalu memudar. Tekstur dibuat prosedural oleh `tools/gen_magic_circle.py` (`assets/fx/magic_*.png`, orisinal).
- Diuji lewat `tools/nova_shots.gd` (stage 1-1, waktu diperlambat): tangkapan layar tiap fase dilihat langsung; denyut mengikuti waktu impak animasi (0,61 dtk).
  Efek ini hanya untuk skill bertipe `nova`; skill karakter lain belum diberi efek baru. Performa efek di HP belum diukur.

### Upacara gacha
- Tarikan kini diawali **lingkaran sihir** yang berputar mengumpulkan cahaya (warna mengikuti rarity terbaik: emas ★5, ungu ★4, biru lainnya), kilatan, lalu
  kartu hasil muncul **terbalik** dan dibuka satu per satu dengan efek membalik. ★4+ mendapat kilau partikel & suara khusus; ★5 ledakan emas + layar bergetar.
  Ketuk di mana saja untuk melewati. Setelah selesai ada tombol **OK** dan **Tarik lagi** (mengulang jumlah tarikan yang sama bila diamond cukup).
  Penghitung pity kini berupa bar dan teks "★5 pasti dalam N tarikan lagi". Peluang, harga, dan pity TIDAK diubah (tetap 2/10/28/30/30 %, pity 50).
- Diuji (`tools/gacha_bot.gd`, tarik 10× dengan pity 49): diamond berkurang 900, tarikan pertama ★5 dan pity ter-reset, 10 hasil, lewati lewat ketukan membuka semua kartu,
  tombol OK menutup, tarik 1×, "Tarik lagi" memulai tarikan baru; tangkapan layar tiap tahap dilihat langsung. `panel_bot` lama tetap dijalankan ulang.
- Belum diuji: ketukan jari asli di HP, dan kenyamanan tempo animasi (bisa disetel lewat angka waktu di `scripts/ui/gacha_reveal.gd`).

### Tanggal & jam dunia nyata
- Di tengah atas HUD lobi kini ada dua baris: "Jam kota HH:MM" (jam siang-malam dalam game) dan di bawahnya **tanggal + jam dunia nyata** dari jam perangkat
  (zona waktu lokal), mis. "Selasa, 3 November 2026 · 09:40", dalam bahasa Indonesia; diperbarui terus. Diuji (`tools/clock_bot.gd`): teks cocok dengan jam sistem
  sandbox, dua contoh format tetap benar, dan tangkapan layar dilihat. Zona waktu HP asli belum diuji.

### Event berjadwal (muncul & hilang sesuai tanggal/jam)
- Semua event ada di **`data/events.json`** — tambah/ubah di sana, tidak perlu menyentuh kode. Tiap event: `id`, `type` (`"banner"` = banner gacha karakter terbatas),
  `title`, `description`, `start`, `end` (format `"YYYY-MM-DD HH:MM"`, atau `"YYYY-MM-DD"` = mulai 00:00 / selesai 23:59), `character` (id karakter), `featured_share`
  (peluang hasil ★5 menjadi karakter event, mis. 0.5). Waktu mengikuti **jam perangkat pemain**.
- Selama event aktif: tombol **Event** muncul di HUD (titik merah bila belum dilihat; panel Event ikut terbuka otomatis saat masuk lobi jika tidak ada hadiah login),
  panel Event menampilkan hitung mundur, dan panel Gacha mendapat tab **"Event: <karakter>"**. Event yang belum mulai tampil di "Akan datang".
- Setelah `end` lewat: tombol Event hilang, banner hilang dari Gacha (panel yang sedang terbuka menutup banner sendiri dan memberi tahu), dan **karakter event tidak bisa
  ditarik lagi** (banner menolak tarikan tanpa memotong diamond). Karakter yang sudah dimiliki tetap dimiliki. Karakter event tidak ada di banner standar.
  Bila karakter event sudah dimiliki saat menarik lagi, hasilnya Pecahan Jiwa ×10.
- Contoh yang disertakan: **"Festival Bara: Ember"** (3–10 November 2026), karakter contoh **Ember** (Penyihir Bara, tongkat/bola api). Ganti tanggal/karakter sesuai kebutuhan;
  karakter baru dibuat seperti Zeya/Ember (`resources/characters/*.tres`, skin di `tools/gen_skins.py`, tampilan di `character_looks.gd`, daftar di `Data.CHAR_ORDER`).
- Diuji (`tools/event_bot.gd`, jam dipalsukan dengan `GameState.set_fake_now`/`--now=`): sebelum event (tidak aktif, "akan datang", banner menolak tarikan, tombol tersembunyi),
  tepat saat mulai (aktif, tombol + titik merah muncul), hitung mundur (contoh "Sisa 5 hari 11 jam" benar), Ember didapat lewat banner (dan jadi Pecahan ×10 saat kedua kali),
  banner standar tidak pernah memberi Ember (300 tarikan), setelah event berakhir (event hilang, tarikan ditolak tanpa potong diamond, panel gacha menutup banner, tombol hilang,
  Ember yang sudah dimiliki tetap ada). Tangkapan layar dilihat.
- Belum diuji: pergantian waktu sungguhan saat game terbuka berjam-jam di HP; pemain bisa memajukan jam perangkat untuk membuka event lebih awal (tidak ada pengecekan server);
  `data/events.json` ikut terkemas di APK sehingga mengubah jadwal butuh ekspor ulang; Ember dipakai bertarung di stage (hanya data & tampilan diperiksa).

### Belum diuji / belum ada
- **APK & perangkat Android nyata**: belum diekspor, performa/FPS di HP belum diukur.
- **Sentuhan multi-touch asli**: logika joystick/tombol ditulis dan dipakai lewat emulasi mouse,
  tetapi belum dicoba dengan jari sungguhan.
- Keseimbangan (balance) bos dan kesulitan hanya dicek dengan bot yang bermain sempurna.
- Tampilan siang/malam di berbagai jam belum ditinjau satu per satu.
- Tombol "Lanjutkan"/"Permainan Baru" di judul diuji hanya untuk jalur "Mulai Bermain" (data baru).

### Keterbatasan / belum diimplementasikan
- Tidak ada **minimap**.
- Boneka latihan belum memberi umpan balik pukulan.
- Mode multiplayer/co-op **tidak ada**; "party 4 karakter" = 4 slot party (mode solo, ganti karakter
  langsung). Saat mulai baru hanya 3 karakter yang terbuka (karakter ke-5, Zeya, dari bonus login); karakter ke-4 (Sera) didapat sebagai hadiah quest menyelesaikan stage 1-1 (alur klaim quest ini diuji lewat quest lain; hadiah Sera sendiri belum diuji langsung).
- Ikon senjata di UI berupa pedang untuk semua kelas senjata.
- Model/animasi sederhana (blok prosedural); suara dibuat sintetis oleh skrip.
- Stage hanya 5; tidak ada cerita panjang, PvP, guild online, atau toko uang asli.

## Regenerasi aset (opsional)
`tools/gen_audio.py`, `gen_textures.py`, `gen_skins.py` membuat audio/tekstur; hanya perlu jika ingin
mengubah aset. Proyek sudah menyertakan hasilnya.

## Menjalankan uji sendiri
```
GODOT=/path/ke/godot
$GODOT --headless --path . res://tools/test_data.tscn
mkdir -p /tmp/shots
xvfb-run -a -s "-screen 0 1280x720x24" $GODOT --path . --rendering-driver opengl3 scenes/stages/stage.tscn \
  -- --bot=1 --botscript=stage_bot --stage=s1_1 --shots=/tmp/shots --fresh
```
Flag uji: `--bot=1 --botscript=<nama di tools/> --shots=<folder> --fresh --stage=<id> --level=N --lose=1 --speed=N`.

## Bos baru: Dewa Wither (stage 3-B "Altar Kehampaan")
- Model: `assets/boss/wither_god_rigged.glb` (kiriman pengguna). GLB hanya membawa animasi Idle; klip cast/slam/roar/hit/death dibuat lewat kode (`scripts/stages/wither_rig.gd`).
- Serangan: hujan sihir (rain), tembakan bola (volley), gelombang nova; fase 2 saat HP ≤ 50%.
- Peta baru: tema "abyss" (lingkaran sihir, kubus melayang) + musik `music_abyss`. Kamera otomatis mundur & condong ke bos.
- Diuji: bot stage s3_boss (bos muncul, 3 serangan jalan, bos bisa mati), test_data LULUS.
- BELUM diuji: perangkat/APK asli, performa, keseimbangan oleh manusia, suara didengar manusia. Efek suara memakai ulang efek bos lama.

## Identitas pemain (offline)
- ID `FL-XXXX-XXXX` = hash SHA-256 satu arah dari ID perangkat (tidak bisa dibalik jadi ID aslinya), jadi sama lagi walau data game dihapus. Hanya bila perangkat tidak memberi ID, dipakai ID acak yang disimpan di `user://identity.json`. Tidak ada fitur ubah ID di game. Nama bisa diganti (2–14 huruf) lewat ketuk profil di HUD. Profil TIDAK menampilkan (dan kode tidak menyimpan) merek/model HP, OS, atau tanggal mulai.
- Batasan jujur: karena offline, tidak ada yang divalidasi server; pemain yang paham file bisa mengubah save-nya. ID bisa berubah bila ID perangkat berubah (reset pabrik / tanda tangan APK beda). Pengamanan sungguhan butuh server (belum ada).
- Diuji: tools/profile_bot (format, unik, rename, panel). Belum diuji di HP asli.

## Satu save, tanpa slot SV (menggantikan "3 slot simpan & nama dunia")
- **Slot SV 1–3 dan nama dunia dihapus.** Layar judul: *Mulai Bermain* / *Lanjutkan* / *Mulai Baru* (konfirmasi) / *Pulihkan dari Kode Cadangan* (hanya bila tidak ada data) / *Hapus Data* (konfirmasi) / *Pengaturan*.
- **Satu file** `user://save.dat`. **Tidak ada `.bak`**, tidak ada file identitas, tidak ada meta. Menulis memakai `save.dat.tmp` sementara yang langsung diganti nama (tidak tertinggal). **Hapus data = progres benar-benar hilang dari perangkat** dan ID pemain berubah.
- **ID pemain ACAK** saat dunia baru dimulai dan disimpan DI DALAM save (bukan lagi turunan ID perangkat; tidak "menempel" ke HP setelah data dihapus).
- Android: `user_data_backup/allow=false` sudah ada di `export_presets.cfg` (cadangan otomatis Google tidak memulihkan data yang sudah dihapus).
- **Migrasi sekali jalan**: bila ada sisa sistem lama, slot yang terakhir dimainkan menjadi save tunggal (ID baru), lalu SEMUA sisa (`save_slot_*.json`, `.bak`, `identity.json`, `meta.json`) dihapus. Slot lain TIDAK dimigrasikan.

## Cadangan lewat kode: terikat perangkat + deteksi berbagi
- Pengaturan → Data → "Salin kode cadangan". Format `FLSAVE2:<base64(gzip(json))>:<HMAC-SHA256>`; memuat hash satu arah ID perangkat (`device_hash()`, tak bisa dibalik) dan ID pemain.
- **Pemulihan hanya jika tidak ada save** di perangkat (hapus data dulu) → kode tidak bisa dipakai memutar balik progres atau menggandakan akun di perangkat yang sama.
- Kode diubah/terpotong/versi lama (`FLSAVE1`) → ditolak (tanpa blokir).
- **Kode dari perangkat lain dipulihkan di sini → DITOLAK dan dicatat sebagai temuan (`other_device`). TIDAK ada blokir akun** (sistem blokir `user://sanction.dat` dihapus; file lamanya dibersihkan otomatis saat game dibuka, jadi perangkat yang dulu "diblokir" langsung bebas). Layar judul tetap normal.
- **BATAS YANG JUJUR (game offline):** (1) tidak ada server, jadi \"ID yang sama dimainkan di dua HP pada waktu berbeda\" **tidak bisa dideteksi secara global**. (2) Kunci tanda tangan tertanam di aplikasi: cukup untuk menangkap edit/bagi biasa, bukan terhadap orang yang membongkar aplikasi. (3) [DIUBAH di Gabungan 51: kode dari HP lain kini DITERIMA untuk pindah HP.] (4) Bila ID perangkat Android berubah (reset pabrik / tanda tangan APK berbeda) kode lama dianggap dari perangkat lain.
- Diuji: `tools/save_test` (cek: tanpa sisa file, ID, ekspor→hapus→pulihkan, impor saat ada save ditolak, MAC salah/terpotong/FLSAVE1 ditolak, kode perangkat lain → ditolak + dicatat TANPA blokir, file blokir lama dibersihkan, deteksi cheat, simpan otomatis, migrasi sisa lama) dan `tools/title_bot` (tombol per kondisi + foto). Belum diuji di HP asli (`OS.get_unique_id()` Android, clipboard Android).

## Misi harian, pencapaian & kehidupan lobi
- **Misi Harian** (tombol "Misi" di HUD kanan): 3 misi baru tiap tanggal (kalahkan monster, selesaikan stage, + satu dari summon/upgrade/habiskan gold), dipilih deterministik dari tanggal. Tiap misi 300 gold + 20 diamond; semua selesai = bonus 100 diamond + 2 Ramuan Kecil. Reset saat tanggal berganti (memakai jam perangkat, jadi bisa dicurangi dengan mengubah jam HP — game ini offline).
- **Pencapaian** (12 buah, sekali seumur hidup): kill, stage, summon, level, jumlah karakter, upgrade. Tersimpan di save.
- **Lobi hidup**: kupu-kupu di siang hari, kunang-kunang di malam hari (18 sprite di sekitar pemain; mati di kualitas "Lancar").
- **Area aman layar**: HUD, HUD stage, dan kontrol sentuh dimundurkan dari notch/lubang kamera (`UiTheme.safe_insets`). Logika diuji dengan angka; BELUM dicoba di HP bernotch asli.
- **Paket regresi**: `tools/run_all.sh` (set `GODOT=/path/godot`) menjalankan uji: data, unit, save, judul, profil, misi, panel, stage 1-1, bos Wither. Hasil terakhir: 8/8 lulus di mesin ini (bukan di HP).
- Belum dikerjakan: stage/musuh/karakter baru, hewan berjalan di lobi, preset ekspor APK belum dibuild (butuh template ekspor Godot + keystore).

## Tombol "Menu" (hub)
- Tombol Hadiah, Misi, dan Event yang terpisah di kanan HUD digabung jadi satu tombol **Menu** (lencana = jumlah hal yang siap diambil). Menu membuka 4 kartu: Hadiah Login 3 Hari, Misi & Pencapaian, Event, Profil & ID. Diuji dengan `tools/menu_bot` (tombol, lencana, tiap kartu membuka panel yang benar).

## Keamanan data simpanan
- **Simpan aman**: tulis ke `save.dat.tmp` → dibaca ulang & dicocokkan → diganti nama jadi `save.dat`. Bila game mati saat menulis, file utama lama tetap utuh. Tidak ada cadangan `.bak` (sengaja: data yang dihapus tidak boleh hidup lagi). Konsekuensi: file save yang rusak = tidak bisa dimuat (layar judul: "Data permainan rusak", ketuk Mulai Bermain).
- **Simpan otomatis** langsung saat game dijeda/pindah ke latar belakang, kehilangan fokus, tombol kembali, atau ditutup (selain simpan berkala tiap perubahan).
- BELUM diuji di Android: pemicu NOTIFICATION_APPLICATION_PAUSED asli saat aplikasi ke latar belakang (diuji dengan memanggil notifikasinya langsung), clipboard Android (batas ukuran kode ±550 karakter di save awal; save panjang lebih besar), dan rename file di penyimpanan Android.

## Keseimbangan bos & bidik otomatis (hasil ukur bot)
- **Bidik otomatis**: saat menyerang/skill, karakter menghadap musuh terdekat dalam jangkauan (kecuali joystick diarahkan >100° ke arah lain). Sebelumnya pukulan bisa meleset terus bila pemain berdiri diam; ditemukan lewat bot yang macet di bos 1-B (2 dari 10 run macet sebelum perbaikan; 8 dari 8 selesai sesudahnya — sampel kecil).
- **Dewa Wither** dibuat lebih besar (skala 1.4), lebih terang (warna + cahaya ungu), kamera condong ke bos; HP 1000 (x skala bab), atk 28, def 5.
- Hasil bot (stage_bot, speed 3, tiap angka = 2–3 run, semuanya menang; "pingsan" = anggota party yang kalah dari 3):
  - 3-B Wither: Lv 12 (rekomendasi) 70–79 dtk, 1–2 pingsan · Lv 8 ≈100 dtk, 2 pingsan · Lv 15 ≈60–66 dtk, 2 pingsan.
  - 2-B Penguasa Gua Lv 10: ≈51–56 dtk, 0–1 pingsan · 1-B Golem Lv 7: ≈49–59 dtk, 0 pingsan.
  - Party Lv 1 kalah di 2-B dan 3-B (di luar rekomendasi level; stage terkunci sampai stage sebelumnya selesai).
- Catatan jujur: bot bukan manusia (ia menghindar hanya saat bos bersiap dan tidak pernah salah tekan). Pemain sungguhan kemungkinan lebih sering pingsan; keseimbangan akhir butuh uji main manusia di HP.

## Jalan cerita
- Naskah orisinal di `data/story.json`: 9 adegan (42 dialog) — Prolog di lobi (Kristal Bintang meredup, Kehampaan melemahkan segel), lalu pembuka stage 1-1/1-B/2-1/2-B/3-B dan penutup bos 1-B/2-B/3-B (Golem tercemar → serpihan berbisik → prasasti Penjaga Pertama → Dewa Wither yang ternyata penjaga segel). Bab 4-5 ditambahkan (lihat bagian "Update besar: Bab 4-5" di bawah).
- Pemutar `StoryPlayer`: kotak dialog dengan nama berwarna, teks mengetik, ketuk untuk lanjut (ketuk saat mengetik = selesaikan baris), tombol Lewati; game dijeda selama adegan. Tiap adegan diputar otomatis SEKALI per dunia (status di save slot), lalu bisa dibaca ulang dari **Menu → Cerita** (adegan belum dibuka tampil "???").
- Diuji (story_bot 16 cek, story_stage_bot 9 cek): data valid, prolog otomatis, jeda/lanjut, ketuk lewat, intro menjeda stage sebelum gelombang, outro tampil sebelum layar hasil. Ditemukan & diperbaiki: pemutar gagal dipasang saat dipanggil dari `_ready` (kini `call_deferred`).
- Belum: suara/musik khusus adegan, potret karakter, pilihan dialog bercabang.

## Efek serangan (dioptimalkan)
- **Tebasan menyapu**: selain juring statis, ada "ujung tebasan" terang yang menyapu dari satu sisi ke sisi lain; arah bergantian per kombo (`Fx.slash(..., flip)`). Tampak di rumput terang (blend biasa, bukan aditif).
- **Hit-stop**: waktu melambat ~94% selama 0,03–0,075 dtk saat kritikal (0,075), skill/hantaman berat (0,055), atau memukul bos (0,03). Bisa dimatikan di Pengaturan → Grafis → "Hit-stop". Waktu dipastikan kembali normal (juga saat stage ditutup/dijeda).
- **Percikan searah pukulan** (menjauhi pemain), **cincin kilat + angka "meletup"** saat kritikal.
- Diuji (fx_bot 11 cek): efek membersihkan diri (0 node sisa setelah 40 pukulan), hit-stop kembali normal/mati lewat pengaturan/tak aktif saat jeda, angka kritikal mengendap ke skala 1. Kecepatan frame di HP BELUM diukur (renderer uji adalah llvmpipe); efek memakai ≤ ~12 node per pukulan.

## Gaya serang per karakter (diperbarui)
Keluhan: Assassin (Zeya) bergaya sama dengan Swordsman (Ren) — keduanya memakai animasi pedang yang sama, dan jeda serangan terasa tidak ada.
- **Zeya (Assassin) kini beda total**: memakai **dua belati**, animasi sendiri (kuda-kuda rendah, tebas kanan → tebas kiri → penutup putaran silang sambil melompat kecil). Satu kombo = 3 pukulan cepat (jeda 0,26 dtk; animasi 0,30 dtk), tiap pukulan kecil (×0,5), **penutup ×2,0** dengan tebasan lebar + dorongan keras dan jeda ekstra 0,4 dtk. Kritikal 25%, mengabaikan 60% DEF musuh (agar pukulan kecil tidak habis dimakan DEF). Skill **Tebasan Bayangan**: menerjang ke depan (kebal ±0,5 dtk) dan menyilang dua tebasan beruntun.
- **Ren (Swordsman)** dibuat lebih berbobot: jeda 0,42 → 0,55 dtk (+0,15 dtk setelah kombo 2 pukulan), damage ×1,1.
- **Jeda serangan kini benar-benar berlaku**: serangan berikutnya tidak bisa lebih cepat dari `attack_cooldown` (+ `combo_recovery` pada penutup), walau tombol ditahan. Brann dinaikkan ×1,35 → ×1,55 karena DPS-nya terlalu rendah.
- Data baru di `CharacterData`: `anim_style`, `combo_hits`, `finisher_mult`, `combo_recovery`, `crit_chance`, `armor_pen`.
- **Animasi lebih tidak kaku (semua karakter)**: pinggul ikut memutar saat menyerang (torsi kaki-pinggul-bahu), lari/jalan punya putaran pinggul berlawanan bahu + kemiringan, napas & berat badan berpindah saat diam.
- Diuji bot (`tools/combat_bot.gd`, 5 karakter menyerang 6 dtk ke target latihan): jeda minimum antar-serangan ≥ cooldown data untuk semua; pola kombo Zeya 0,1,2,0,1,2; DPS terukur di putaran terakhir (6 dtk, level & perlengkapan sama, ada acak kritikal sehingga bergeser antar-putaran): Ren 37,5 · Zeya 38,8 · Brann 36,8 · Lyra 37 · Sera 34,7 (putaran sebelumnya Brann hanya 22 sebelum dinaikkan ke ×1,55, jadi selisih besar itu juga ikut dipengaruhi acak — belum diulang berkali-kali). `attack_sheet`: damage jatuh ≤0,08 dtk dari momen impak animasi untuk semua 16 aksi.
- **Belum**: rasa pukulan/animasi hanya dinilai lewat foto pose & angka bot di llvmpipe; belum dirasakan di HP asli, jadi angka balans mungkin perlu disetel setelah kamu main. Efek belati (kilau/bekas tebasan) masih memakai efek tebasan yang sama dengan lebar/durasi berbeda. Animasi musuh belum diubah.

## Efek serangan khas tiap karakter (`scripts/stages/char_fx.gd`)
Sebelumnya semua karakter berbagi efek yang mirip (juring + percikan sama; Ember & Brann sama-sama "gelombang"). Sekarang tiap karakter punya identitas sendiri:
- **Ren (es & fajar)**: sabit es biru tegak yang menyapu, serpihan es & salju; skill = dua sabit biru-emas + garis fajar.
- **Zeya (bayangan)**: sabit tipis merah muda dengan bayangan ungu di belakangnya; penutup kombo berbentuk "X" + cincin bayangan + kelopak; skill = garis terjang + asap bayangan + tebasan silang; kena = kilatan "X".
- **Lyra (bintang)**: peluru bintang 8 sudut berputar + kerlip ungu/putih; Nova Bintang ditambah kerlip naik.
- **Ember (api)**: bola api berdenyut dengan jejak api naik; skill "Gelombang Bara" = cincin api, lidah api melingkar, bekas hangus (tidak lagi sama dengan Brann).
- **Brann (tanah)**: retakan tanah + debu + pecahan batu; skill = retakan besar, debu melingkar, batu terlontar.
- **Sera (angin & daun)**: panah berkepala runcing dengan jejak angin; Hujan Panah diawali cincin angin + daun; kena = daun beterbangan.
- Hemat: partikel CPU sekali-jalan, mesh & material dipakai bersama (cache), partikel mengecil sendiri, jumlah partikel mengikut Pengaturan > Kualitas (Lancar = setengah & tanpa jejak peluru & tanpa lampu peluru). Id karakter lain memakai efek umum lama.
- **Perbaikan kamera**: di dekat tepi arena kamera sempat berada di dalam cincin pohon sehingga tajuk hijau besar menutupi layar (itulah "poligon hijau" yang muncul di foto sebelumnya). Kini kamera otomatis naik (pitch sampai 74°) bila berada di luar tepi arena, dan kembali normal di tengah.
- Diuji (`tools/charfx_bot.gd`, 6 karakter × serangan/kombo/skill): tak ada error skrip; semua efek membersihkan diri (sisa 0–1 node); node efek puncak 49–121 per ±2,4 dtk menyerang terus (batas uji 160); kamera tepi arena naik, kamera tengah tidak berubah. Foto fase efek diperiksa lewat tangkapan layar.
- Belum: frame-rate di HP asli tidak diukur (renderer uji llvmpipe, jadi "hemat" baru dibuktikan lewat jumlah node, bukan FPS); retakan Brann tampak seperti garis kuning-hitam bergaya (belum ideal); efek tidak bersuara khusus; efek bos/musuh tidak diubah.

## Dua gacha di Altar Bintang (Gacha Karakter & Gacha Perlengkapan)
Panel Altar Bintang kini punya dua tab terpisah, masing-masing dengan peluang, hadiah, dan **pity sendiri** (hitungan 50 tarikan tidak tercampur):
- **Gacha Karakter ("Panggilan Jiwa")**: ★5 2% = Sera/Zeya, ★4 13% = Ren/Lyra/Brann, ★3 85% = Pecahan Jiwa ×3 (karakter milikmu). Karakter baru langsung terbuka; yang sudah dimiliki jadi Pecahan Jiwa (★5 ×10, ★4 ×5). **Banner event** (karakter terbatas seperti Ember) ada di tab ini; Ember tidak pernah keluar di banner standar.
- **Gacha Perlengkapan ("Panggilan Perlengkapan")**: ★5 2% legendaris, ★4 10% epik, ★3 28% perlengkapan langka, ★2 30% Ramuan Besar ×2, ★1 30% Ramuan Kecil ×3. Tidak pernah memberi karakter/Pecahan Jiwa.
- Harga sama untuk keduanya (100 / 900 diamond, `GACHA_SINGLE/GACHA_TEN` di `game_state.gd`); 10× menjamin ≥ ★4; upacara pemanggilan sama. Simpanan lama tetap terbaca (`pity` lama = pity karakter, `pity_item` mulai 0).
- Diuji (`tools/gacha_split_bot.gd`, 17 cek + `save_test`): 1500 tarikan tiap gacha — item hanya item, karakter hanya karakter/pecahan (tanpa Ember); distribusi ★ sesuai (±6 poin); pity terpisah; banner ditolak di tab item; tab di panel berfungsi; pity item tersimpan di save.
- Catatan jujur: setelah semua karakter standar terbuka, Gacha Karakter praktis hanya memberi Pecahan Jiwa (karakter yang bisa didapat memang baru 6, dan Ember hanya lewat event). Harga/peluang belum diuji keseimbangannya dengan pemain nyata. Tarikan di HP asli belum dicoba.

## Tampilan Menu baru (laci dari samping, kartu miring)
- Menu kini **meluncur masuk dari sisi kanan** (0,3 dtk, latar memudar gelap) dan meluncur keluar saat ditutup (tombol panah bulat kiri-atas, ketuk area gelap di kiri, atau tombol Back).
- Warna tema **sama dengan panel lain** (biru malam + emas, judul emas, bingkai emas; kartu ber-hadiah berbingkai emas terang): panel biru malam bergaris miring; dua kartu besar miring (Hadiah Login, Misi & Pencapaian) dan tiga kartu lebih kecil (Event, Cerita, Profil & ID) dengan garis warna aksen, ikon besar pudar, dan lencana "!"/angka. Gerigi di kanan-atas membuka Pengaturan (lalu kembali ke Menu). Kartu muncul bertahap.
- Tata letak "kartu miring pilih mode" terinspirasi game bergenre sama, tetapi semua gambar/ikon/warna dibuat sendiri lewat kode (tidak memakai gambar atau merek game lain).
- Diuji (`tools/menu_bot.gd`, 12 cek): laci mulai di luar layar, berhenti di posisi akhir, menutup dengan animasi, tiap kartu membuka panelnya, lencana hilang setelah klaim. Foto layar diperiksa. Belum: sentuhan di HP asli (kartu memakai emulasi mouse dari sentuhan bawaan Godot; diuji lewat klik/sinyal, bukan jari sungguhan); tidak ada potret karakter di kartu (belum ada aset ilustrasi orisinal).

### Perapihan Menu
Margin dan jarak antar-elemen diseragamkan, ada garis pemisah emas di bawah header, ubin diperbesar, teks diletakkan di bagian atas ubin dan ikon pudar di pojok kanan bawah sehingga tidak saling menimpa, plus petunjuk "Ketuk area gelap untuk menutup" di bawah. Diuji lewat bot di layar 1280x720 (belum diuji di perangkat Android sungguhan).

### Karakter ★6 baru: Hakuya + sistem kelangkaan karakter
- **Hakuya** (Samurai, ★6, id `hakuya`): rambut perak panjang diikat tinggi, haori putih, hakama hitam, katana + sarung (tampilan dari kode, skin dari `tools/gen_skins.py`; semua orisinal, hanya terinspirasi gambar referensi). Serangan `arc` jangkauan 3,1 m, kombo 2 pukulan (penutup 1,9x), kritikal 22%, menembus 30% DEF. Skill **Tebasan Bulan Pucat** (`iai`): tebasan lurus sangat panjang (7,5 m) lalu tebasan lebar penutup berbalut api biru. Efek serang, skill, dan efek kena khasnya ada di `CharFx` (putih tipis + biru).
- **Kelangkaan** (`rarity` di CharacterData, terpisah dari bintang kebangkitan): Hakuya ★6; Lyra, Sera, Zeya, Ember ★4; Ren, Brann ★3. Sera, Zeya, Ember, dan Lyra dinerf statnya (ATK/pertumbuhan, kritikal/penetrasi Zeya, HP Ember).
- **Gacha karakter**: ★6 1,5% (pity 80), ★4 13,5% (Sera/Zeya/Lyra), ★3 85% (Ren/Brann atau Pecahan Jiwa). Pecahan duplikat: ★6 ×20, ★4 ×5, ★3 ×3. Banner event kini mengganti sebagian hasil ★4 (Ember). Gacha perlengkapan tidak berubah (★5 tertinggi, pity 50).

### Gulir sentuh yang ramah Android + efek lebih tebal + api biru Hakuya
- **Gulir (`scripts/ui/touch_scroll.gd`, kelas `TouchScroll`)** dipakai semua daftar (Toko, Inventori, Quest, Karakter, Party, Equipment, Stage, Pengaturan, Gacha, dst.). Seret di mana pun, termasuk di atas kartu/tombol, menggulir (ambang 12 px) dengan inersia; begitu seretan mulai, tekanan tombol dibatalkan sehingga tidak ada pembelian/pilihan nyasar. Kartu kini aktif saat jari DILEPAS di dalam kartu (`BasePanel.tap_on`), dan posisi gulir dipertahankan saat daftar dibangun ulang (sebelumnya melompat ke atas setiap memilih item). Penggulir sentuh bawaan Godot dimatikan agar tidak bentrok. Roda mouse tetap bekerja.
- **Efek**: tebasan/bulan sabit lebih tebal + lapisan cahaya tambahan, garis terjang lebih lebar, jumlah partikel naik ±25% (menyesuaikan Pengaturan > Kualitas).
- **Api biru Hakuya**: aura api biru menyala di kaki (dipasang otomatis saat Hakuya aktif), lidah api biru halus (billboard bertekstur, bukan balok) di penutup kombo, jejak api sepanjang tebasan skill, dan kobaran api biru di tanah setelah skill. Jumlah node dijaga di bawah 160 per aksi.
- Uji: `tools/scroll_bot.gd` (simulasi seret/ketuk lewat peristiwa mouse), `tools/hakuya_look_bot.gd` (foto aura & skill).

### Efek Hakuya terinspirasi video referensi
Katana menyala: lidah api biru kecil sepanjang bilah + bara bercahaya yang tertinggal di udara saat diayun (`CharFx.blade_fire`); jejak tebasan berbentuk bulan sabit runcing (`CharFx.taper_mesh`, tebal di tengah, tajam di ujung); semburan garis percikan saat kena dan garis kecepatan di skill (`CharFx.spark_lines`); bara melayang (`CharFx.embers`); api memakai tekstur lidah api halus (billboard), bukan balok. Foto uji dekat: `tools/hakuya_look_bot.gd`.

### Hakuya: skin, rambut, dan jejak katana
- **Skin** (`tools/gen_skins.py`, `paint_hakuya`): dicat ulang mengikuti template 2D dari gambarmu: haori putih bermotif silang hitam, kimono dalam gelap berbentuk V, obi hitam, pembalut lengan hitam dengan X putih, hakama hitam berlipit, sepatu hitam, rambut perak berserat.
- **Rambut**: ekor kuda tinggi yang tebal, bergelombang dan berayun, helai liar tipis, sisi rambut mengembang, dan tudung rambut (`CharacterLooks._ponytail`).
- **Jejak katana sungguhan** (`CharFx.BladeTrail`): pita cahaya putih-biru yang mengikuti ujung dan pangkal bilah selama serangan dasar dan skill, memudar cepat, seperti di video referensi. Kamera game tidak diubah.

### Panel Party baru (terinspirasi layar "Party Settings" gim sejenis, desain sendiri)
- Kiri: 4 kartu slot tinggi dengan potret 3D setengah badan, nama, bintang kelangkaan berwarna, peran + kekuatan; slot 1 bertanda ♛ Pemimpin.
- Kanan: grid karakter 3 kolom (potret kepala, bintang kelangkaan, "Slot N" / kekuatan / petunjuk quest bila terkunci) di dalam `TouchScroll`, tombol **Urut** (Rarity → Kekuatan → Nama).
- Bawah: bar info (kekuatan regu, petunjuk slot terpilih) + aksi "♛ Jadikan pemimpin" / "Lepas".
- Potret dirender sekali oleh `scripts/ui/portraits.gd` (SubViewport transparan per karakter, di-cache) dan panel menyegarkan diri saat siap.
- Uji: `tools/party_bot.gd` (potret ter-render berisi piksel, ketuk roster mengisi/menukar slot, urutan berganti), masuk `run_all.sh` sebagai `party`.

### 4 karakter baru (dari gambar referensi; semua orisinal berbasis voxel)
| Karakter | ★ | Senjata / gaya | Skill | Efek |
|---|---|---|---|---|
| **Vael** – Pemburu Fajar Biru | 5 | pedang raksasa bercahaya cyan, tebasan lebar berat (`arc`) | Gelombang Fajar Biru (`cone`) | bulan sabit cyan/putih, cincin, percikan, bara, aura api cyan |
| **Lucien** – Tuan Monokel Bertongkat | 5 | tongkat emas, peluru bayangan emas (`bolt`, tembus armor 35%) | Hujan Pedang Bayangan (`volley`) | bintang/bilah emas, cincin emas-ungu, bara |
| **Wenyu** – Peniup Seruling Senja | 4 | seruling, bola angin berkelopak (`bolt`) | Lagu Kelopak Senja (`nova`) | kelopak putih-biru, aura kelopak |
| **Kuroha** – Samurai Mantel Malam | 4 | katana, tebasan cepat (`arc`) | Terjang Bayangan Tinta (`dash_cut`) | bulan sabit tinta + perak, X flash, aura bayangan |
| **Aion** – Penjaga Jarum Waktu | 5 | tongkat jam, serpihan jarum jam (`bolt`) | **Jeda Waktu** (`chrono`): jam terbentang di tanah, damage sedang + musuh melambat 50% selama 3,5 dtk | gagak tinta, cipratan tinta biru, wajah jam berputar |
- Skin: `tools/gen_skins.py`; model/aksesori: `CharacterLooks._vael/_lucien/_wenyu/_kuroha`; efek: `CharFx` (per id).
- Gacha karakter kini punya ★5 (3,5%): pool ★6 Hakuya; ★5 Vael, Lucien; ★4 Sera, Zeya, Lyra, Wenyu, Kuroha; ★3 Ren, Brann. Pity 80 tetap untuk ★6.

### Ilustrasi beranimasi (GIF) — DIHAPUS
- Atas permintaan, GIF/ilustrasi beranimasi karakter (Lucien & Wenyu) dihapus seluruhnya: `assets/art/`, `scripts/ui/anim_art.gd` (`AnimArt`), dan tes `art_bot`/`seni_anim`. Panel Karakter dan kartu hasil gacha tidak lagi menampilkan gambar GIF; semua karakter memakai potret 3D `Portraits` / ikon seperti sebelum ada GIF.

### Panel Party v2 (gaya daftar karakter, lebih hidup)
- Kartu roster: latar gradien biru berkilau, lencana "Slot N" / "Lv", potret setengah badan, baris bawah berisi ikon senjata | bintang kelangkaan | kekuatan (atau petunjuk quest bila terkunci); bingkai emas untuk anggota regu.
- Kartu slot tinggi memakai gradien sesuai kelangkaan. **Semua karakter memakai potret 3D** yang dirender `Portraits` (kartu slot = seluruh badan, kartu roster = setengah badan). Render yang gagal/kosong otomatis diulang.

### Perbaikan bug serangan (audit semua karakter)
- **Ayunan hantu:** ayunan/skill yang tertunda (menunggu momen kena) kini dibatalkan saat **menghindar**, **ganti karakter**, atau **mati** (`Player.cancel_actions`). Sebelumnya tebasan/tembakan tetap keluar setelah animasinya terputus, bahkan memakai data karakter yang baru. Menghindar saat menyiapkan serangan mengembalikan cooldown serangan/skill yang belum sempat kena.
- **Arah serangan terkunci:** selama membidik sampai momen kena, arah hadap tidak lagi ikut berputar ke arah joystick, jadi tembakan/tebasan tidak meleset ke arah jalan.
- **Terkena saat menyiapkan serangan:** tidak lagi terhuyung (animasi hurt memutus ayunan lalu damage tetap keluar) — ayunan lanjut sampai selesai, damage tetap diterima.
- Ayunan yang jatuh tempo setelah stage berakhir / pemain mati diabaikan oleh stage.
- Uji: `tools/serang_bot.gd` (`audit_serang` di run_all) — 11 karakter × 10 pemeriksaan: serangan & skill mengenai walau awalnya menghadap salah, arah terkunci, dorongan wajar, batal saat dodge/ganti/mati, tetap keluar saat terkena, dan kembali normal setelah spam aksi acak.

## Build ADMIN (uji karakter penuh)
Build terpisah, **salinan persis** game ini + alat uji. Dibuat otomatis: `python3 tools/make_admin.py` → `../fantasy_life_rpg_admin` (ZIP: `fantasy_life_rpg_admin.zip`). Game utama tetap bersih (tanpa kode admin).
- Tombol merah **ADMIN** di tengah atas semua layar → jendela alat: buka semua karakter, ★ maks, level 50, +gold/diamond, buka semua stage, item ×99, senjata +10, pity gacha hampir penuh; God Mode, One-hit, Tanpa cooldown, pulihkan HP, bunuh semua musuh, kecepatan 0.4x/1x/2x; ganti ke karakter mana pun langsung (lobi & stage); mulai stage mana pun; spawn jenis musuh/bos apa pun.
- Nama proyek "... ADMIN" → save terpisah dari game asli.
- Kait di build admin saja: `player.take_damage` (god), cooldown di `player._physics_process`, `stage._hit_enemy` (one-hit).
- Tes: `tools/admin/admin_bot.gd` (stage, 18 cek) dan `admin_lobby_bot.gd` (lobi, 4 cek) — dijalankan di salinan admin.

## Perbaikan arah efek tebasan (laporan: efek/partikel tebasan ke atas, bukan ke depan)
- **Penyebab:** `CharFx.crescent()` (sabit tebasan semua karakter jarak dekat) memasang busur **berdiri tegak seperti pelangi ∩ di depan pemain** (bidang tegak lurus arah hadap), sehingga tampak seperti payung/topi di atas kepala. Partikel bara/serpihan juga disemburkan ke `Vector3.UP`.
- **Perbaikan:** busur kini **mendatar mengelilingi pemain pada jarak jangkauan, miring diagonal ±15° (ayunan pedang) dan menyapu dari satu sisi ke sisi lain searah hadap**. Bara/serpihan/percik pada tebasan & skill jarak dekat (Ren, Zeya, Hakuya, Vael, Kuroha, iai) disemburkan **ke arah hadap** (`embers()` punya parameter `dir`).
- **Tes baru:** `tools/fx_dir_bot.gd` (`run_all.sh` → `arah_tebasan`): setiap frame mengukur semua mesh busur efek — tinggi/lebar ≤ 0.5, puncak ≤ 3 m, pusat tidak di belakang pemain — untuk semua karakter jarak dekat (serangan & skill), plus foto `dir_*` di `--shots`.

## Performa perangkat ringan–menengah (Helio P22/P32, PowerVR GE8320) & grafis "Bagus" lebih bagus
Pengaturan → Grafis → **Kualitas: Otomatis / Lancar / Sedang / Bagus** + saklar **Resolusi dinamis**.
- **Otomatis** menebak kelas HP dari nama GPU (PowerVR/Adreno <510/Mali lama → Lancar; Mali-G52/G57/G72/Adreno 5xx–6xx → Sedang; Adreno 6xx+/Mali-G7x+/Immortalis → Bagus), RAM (≤3,3 GB → Lancar, ≤4,3 GB → maks Sedang) dan jumlah inti. Tidak dikenali → Sedang. Nama GPU dari Android kadang tidak informatif, jadi pemain bisa memilih manual.
- **Lancar**: resolusi 3D ≈ 0,55 MP (UI tetap tajam), tanpa bayangan nyata (diganti bayangan semu bulat di tanah), tanpa MSAA/glow, lampu titik dekor mati, jarak pandang 200 m.
- **Sedang**: ≈ 0,8 MP, bayangan 1 kaskade 1024 px dekat.
- **Bagus**: resolusi penuh, bayangan 2 kaskade 2048 px halus, MSAA 2x, glow lembut + kontras/saturasi sedikit naik.
- **Resolusi dinamis** (`autoload/perf.gd`): tiap detik mengukur waktu bingkai; bila rata-rata > 18,8 ms skala 3D turun bertahap (ada batas bawah per kelas), bila stabil dicoba naik lagi dengan jeda yang membesar bila gagal.
- Penyebab terbesar lag: bayangan teks Label memecah batching UI (lobi 547 draw call). Diganti outline → **lobi 195 draw call (Lancar), 223 (Sedang), 289 (Bagus)** (ukuran bot, deterministik).
- Uji: `tools/perf_test.tscn` (tebakan kelas HP, skala, governor, preset) — 25 cek lulus.
- **Jujur**: belum diuji di HP sungguhan. Jumlah draw call/segitiga terukur nyata, tetapi FPS hanya diukur di renderer perangkat lunak (relatif, bukan FPS Helio P22/P32). Target 60 FPS di Helio P22 belum bisa dijamin; governor akan menurunkan resolusi otomatis bila masih berat.

## Bangunan 10% lebih besar + tata letak dirapikan
- Semua bangunan (kecuali air mancur dan gerbang yang terikat plaza/tembok) diperbesar 10% (`LobbyLayout.BUILDING_SCALE`); area larangan pohon/dekorasi ikut membesar.
- Badan bangunan digeser mundur menjauhi jalan sebesar pertambahan kedalamannya, supaya muka bangunan tetap di garis jalan dan tidak menjorok ke jalan/NPC.
- Guild digeser 1,8 m ke selatan (z -39,2) agar tidak menempel tembok kota setelah membesar.
- Diperiksa lewat foto peta dari atas (`tools/lobby_overview.gd`) dan seluruh paket regresi. Catatan: uji `scroll` sekali gagal saat mesin sibuk dan lulus dua kali saat dijalankan ulang (uji berbasis waktu); belum diuji di HP sungguhan.

## Mode grafis "Klasik" (bawaan) — laporan performa turun setelah update optimasi
- Pengguna melaporkan FPS di HP-nya justru turun setelah update optimasi. Penyebab pasti tidak bisa diukur tanpa HP-nya; dugaan: resolusi dinamis (ubah ukuran render berulang kali), bayangan semu, glow/MSAA di kelas Bagus, dan pilihan Otomatis yang menebak kelas HP.
- Ditambah pilihan **Klasik** di Pengaturan → Grafis : resolusi 3D penuh, tanpa resolusi dinamis, tanpa bayangan semu/glow/MSAA, bayangan jarak 55 m, pandang 420 m (mendekati perilaku sebelum optimasi; bukan salinan byte-per-byte).
- Save pengaturan lama (tanpa `gfx_v`) otomatis dikembalikan ke Klasik sekali; pengaturan lain tidak berubah. Setelah itu pilihan pemain dihormati. Lancar/Sedang/Bagus/Otomatis tetap ada untuk dicoba.
- Perbaikan murah yang tetap aktif di semua mode: bayangan teks UI diganti outline (lobi 547→~195 draw call).

## Bawaan grafis = Sedang (laporan pengguna)
Laporan: sebelum grafis diperbagus 60 FPS; setelah update (saat masih ada GIF karakter) turun ke 48 FPS; setelah GIF dihapus + optimasi, kelas **Sedang** kembali 60 FPS di HP-nya. Maka bawaan sekarang **Sedang** (bukan Klasik); save lama dimigrasikan ke Sedang sekali. Klasik tetap tersedia sebagai pilihan. Ini laporan pengguna, bukan hasil ukur saya.

## Deploy ke GitHub -> APK otomatis (GitHub Actions)
File: `.github/workflows/buildapk.yml` (+ `export_presets.cfg` sudah mengaktifkan arm64 **dan** armeabi-v7a, karena banyak HP Helio P22/P32 memakai Android 32-bit).
0. Cara cepat: buat repo kosong di GitHub, lalu jalankan `bash kirim_ke_github.sh <URL-repo>` (skrip ini melakukan langkah 1 di bawah).
1. Buat repo baru di GitHub, lalu dari folder proyek: `git init && git add . && git commit -m "Fantasy Life RPG" && git branch -M main && git remote add origin <URL-repo> && git push -u origin main`.
2. Tab **Actions** -> workflow **Build APK** berjalan otomatis (menjalankan uji data/unit/save/perf lalu ekspor APK). Hasilnya ada di **Artifacts** -> `fantasy-life-rpg-apk`.
3. **Rilis**: `git tag v0.2.0 && git push origin v0.2.0` -> APK (game + admin) otomatis terlampir di halaman **Releases**; unduh dari HP lewat browser lalu pasang.
4. Versi ADMIN manual: Actions -> Build APK -> Run workflow -> centang "admin".
**Jujur:** workflow ini belum pernah dijalankan (saya tidak punya akses GitHub/Android SDK di sini). Langkah ekspor memakai praktik umum Godot 4.3 (setup-godot + Android SDK + keystore debug); kalau gagal di run pertama, kirim log-nya ke saya. APK bertanda-tangan debug (cukup untuk dipasang, bukan untuk Play Store).

## Menu diperbanyak & dirapikan (3 baris kartu)
- Menu (laci kanan) kini 8 kartu: Hadiah Login, Misi & Pencapaian, Event, Cerita, Profil & ID, **Koleksi** (bilah kemajuan karakter & item per jenis), **Statistik** (waktu main, musuh, stage/bintang, gacha, gold, tempa, cerita — dari data save nyata), **Panduan** (kontrol, tips, cara dapat karakter, performa, data).
- Kartu pendek tidak lagi ditimpa ikon (ukuran ikon dibatasi, teks menyisakan ruang). Diuji `tools/menu_bot.gd` (kartu -> panel benar) + dilihat lewat screenshot.
- Belum dikerjakan (saran): ikon HUD tombol atas bisa dikelompokkan/dikecilkan, panel Gacha/Toko perlu pass visual yang sama, dan lag di HP asli hanya bisa dipastikan lewat uji di perangkat.

## Poles lanjutan (Gacha, Toko, HUD, Statistik, Koleksi)
- Gacha: teks peluang tidak lagi terpotong (membungkus baris); area hasil yang kosong diisi petunjuk nyata (karakter yang belum dimiliki + hitungan pity).
- Toko: barang pertama otomatis terpilih sehingga panel detail tidak kosong.
- HUD: tombol atas diperkecil (72 px) agar tidak terlalu ramai dan tidak menutup dunia.
- Statistik: ditambah daftar kemajuan stage (bintang). Koleksi: galeri karakter (terkunci ditampilkan "???").
- Belum: uji rasa serangan di HP asli, dan musik/efek suara per area (belum dikerjakan).

## Poles Gacha, Toko, HUD, Statistik, Koleksi
- **Gacha**: baris peluang membungkus (tidak terpotong lagi); area hasil yang kosong kini menampilkan petunjuk nyata (karakter yang belum dimiliki + hitungan pity).
- **Toko**: barang pertama terpilih otomatis sehingga panel detail + tombol Beli langsung terisi.
- **HUD**: tombol atas dikecilkan (72 px, ikon 32) agar tidak menutupi dunia 3D.
- **Statistik**: ditambah daftar kemajuan stage; **Koleksi**: ditambah chip semua karakter (dimiliki / "???" bila belum). Margin kanan agar scrollbar tidak memotong.
- Tidak dikerjakan: tes rasa serangan di HP asli dan suara/musik per area (butuh perangkat / aset audio).

## Poles lanjutan: Karakter, Inventori, Pengaturan
- **Karakter**: daftar kiri kini bisa digulir (sebelumnya panel melebihi layar sehingga tombol "Pemimpin" & "Ganti Equipment" jatuh di luar layar — bug nyata, sudah diperbaiki); ditambah potret 3D seluruh badan di sisi kanan (siluet gelap bila terkunci).
- **Inventori**: item pertama terpilih otomatis (detail/tombol langsung terisi, baris tersorot).
- **Pengaturan**: tab lebih besar & jelas (area sentuh), teks catatan suara dirapikan.

## ULT (jurus pamungkas, 1× per match)
- Tiap karakter punya ULT (`ult_name/ult_kind/ult_mult/ult_range` di `resources/characters/<id>.tres`). Tombol ULT (ungu-pink, di atas-kanan tombol serang) / keyboard **U** / gamepad RB. Setelah dipakai tombol menampilkan "SUDAH" dan tidak bisa dipakai lagi di match itu (per karakter; karakter lain di party masih punya jatah sendiri; reset saat stage baru).
- Saat ULT: pemain terkunci ~1.7 dtk & kebal ~2.4 dtk; lingkaran sihir bercahaya → 7 serangan area di musuh → ledakan penutup (total ≈ ATK × ult_mult).
- Tiap ULT punya bahasa visual sendiri sesuai karakter: Ren pedang cahaya jatuh + pedang raksasa, Lyra konstelasi (lingkaran bintang), Brann hantaman bumi, Sera hujan panah, Ember api oranye, Zeya tebasan silang bayangan, Hakuya api biru, Vael pilar cahaya, Lucien lingkaran jam emas, **Wenyu simfoni nota musik + paranada**, Kuroha naga bayangan. Lingkaran sihir hanya untuk penyihir (Lyra, Lucien).
- Efek orisinal prosedural di `scripts/stages/ult_fx.gd` (tekstur dari `tools/gen_ult_art.py` → `assets/fx/`): pedang cahaya jatuh, pilar cahaya, kolom api (oranye/biru), gempa & kristal, naga tinta/bayangan.
- Tes: `tools/ult_bot.gd` (di run_all sebagai `ult`).

## Mata karakter
- Mesh mata/alis lama (titik hitam) dihapus dari `assets/hero/hero.glb`; diganti tekstur mata gaya chibi anime (iris besar gradasi warna karakter, 2 kilau, bulu mata) + alis + kedip acak. Dibuat oleh `tools/gen_eyes.py` → `assets/hero/eyes/`.

## Gerak per karakter (diam / jalan / lari / siaga)
- `AnimLibrary.STYLES` memberi tiap karakter animasi `idle@id`, `walk@id`, `run@id`, `ready@id` sendiri (Brann kuda-kuda lebar & langkah berat, Zeya merunduk, Wenyu memegang seruling & meliuk, Hakuya tenang tangan di sarung, dst). Dibuat lazy (`ensure_style`).
- Setelah serangan dasar/skill, karakter berpose siaga (`ready@id`) selama 3.5 dtk saat diam, lalu kembali santai (blend halus di `CharacterRig`).
- Brann: animasi hantam diperberat (kumpul tenaga, angkat, banting, tahan, bangkit) + partikel tanah (debu, pecahan batu, percikan, gelombang susulan; pukulan ke-3 lebih besar).
- Wenyu: peluru, skill ("Lagu Kelopak Senja"), dan ULT memakai NOTA musik (`assets/fx/note_*.png` dari `tools/gen_ult_art.py`) + paranada, tanpa lingkaran sihir.
- Foto pose: `tools/pose_bot.gd` (`POSE_IDS=brann,wenyu`).


## Update besar: Bab 4 "Kuil Bayangan" & Bab 5 "Menara Rantai Merah" (musuh karakter humanoid)
**Musuh baru berwujud manusia** (`scripts/stages/humanoid_enemy.gd`, turunan `Enemy`; memakai rig karakter hero.glb + skin sendiri + aksesori `CharacterLooks.apply_enemy`):
- Kroco: **Pengikut Berkerudung** (menusuk meluncur), **Penyihir Bayangan** (jarak jauh, menembak 1 bola / 3 bola menyebar, menjaga jarak), **Ksatria Rantai** (tebasan + sapuan rantai area), **Ronin Bayangan** (tebasan cepat + terjang menembus).
- Bos: **Uranos** (peluru kipas, hujan meteor, nova, berpindah tempat/teleport bila didekati, fase 2: memanggil pengikut) dan **Raja Rantai Merah** (bantingan pedang, sapuan rantai, sangkar rantai, seruduk; fase 2: memanggil Ksatria Rantai).
- Semua serangan punya telegraf merah dan animasi diselaraskan dengan momen pukulan (bukan di awal windup). Skin dibuat `tools/gen_skins.py` (varian `e_*`).
**Lokasi baru** (tema arena `temple` dan `chains` di `arena.gd`): 4-1 Gerbang Kuil, 4-2 Halaman Seribu Lentera, 4-3 Aula Bayangan, 4-B Singgasana Uranos; 5-1 Kaki Menara, 5-2 Lorong Belenggu, 5-B Takhta Rantai Merah. Total 16 stage; terbuka berantai mulai dari 3-B.
**Cerita**: 9 adegan baru (total 18) di `data/story.json`; penutup 3-B kini mengarah ke Bab 4; penutup 5-B membuka kelanjutan cerita.
**Uji**: `humanoid_bot` (4 kroco: muncul, mengejar, menyerang, mati, dibersihkan), `humanoid_boss_bot` (kedua bos, semua serangan, fase 2, mati), `test_data` (semua musuh/tema/rantai unlock valid), `story_bot`.
**Jujur**: belum diuji di perangkat Android sungguhan; keseimbangan angka (HP/ATK bos) baru diuji lewat bot, belum lewat bermain manual. Musik Bab 4-5 memakai ulang lagu yang ada (music_abyss / music_boss).

## Langit hidup & Pengaturan baru
- **Awan 3D, matahari/bulan bergerak** (`scripts/lobby/sky_life.gd`, `assets/sky/*`): awan kumulus kartun dari mesh blob (dasar rata + menara gumpalan, pencahayaan toon, bayangan abu-biru di bawah) melayang pelan di sekeliling kota; bayangan awan lembut bergeser di tanah (terlihat dari kamera biasa); matahari siang & bulan malam mengikuti arah cahaya DayNight. Awan terlihat saat kamera diturunkan: Pengaturan > Kamera > "Sudut miring" kini bisa sampai 10° (sebelumnya 25°). Aktif di lobi dan stage luar ruangan. Kualitas Lancar: awan lebih sedikit & tanpa bayangan awan. (Versi awal memakai gambar 2D tempel; dibuang karena jelek.)
- **Pengaturan dirombak**: tiap opsi dalam kartu dengan kolom label seragam, petunjuk di bawah nama, judul bagian, tab lebih besar, saklar AKTIF (hijau)/MATI, deskripsi kualitas dinamis. Opsi baru di tab Lobi: "Awan & matahari bergerak" dan "Bayangan awan di tanah".
- **Jujur**: kamera lobi menatap ke bawah, jadi langit 3D hampir tak terlihat; efek awan paling nyata lewat bayangan di tanah dan lapisan langit 2D di atas layar (halus, bukan awan 3D besar di layar). Belum diuji di HP sungguhan; dampak FPS belum diukur di perangkat (hanya ringan: <=12 quad awan, 1 bidang bayangan).

## Rig V2: jari & mata bertulang, pegangan & ayunan pedang diperbaiki

Sumber: paket `[ZN] RIG V2` (proyek Prisma 3D). Format `.proj` adalah MessagePack sehingga bisa dibaca skrip; rig asli punya tulang jari (4 jari x 2 ruas + telapak) dan tulang pupil. `hero.glb` lama (17 tulang) kini dipasca-proses oleh `tools/rig/add_fingers.py` (sumber lama: `tools/rig/hero_v1_backup.glb`):

- **Tangan baru**: plat tangan kotak dibuang, diganti telapak + 4 jari x 2 ruas + jempol x 2 ruas per tangan, **semua bertulang** (`f0_l_a`, `f0_l_b` ... `th_l_a`, `th_l_b`, sisi kanan `_r`). Total 39 sendi. Geometri jari buatan sendiri (kotak, mengikuti gaya blok), bukan salinan mesh jari Prisma (letaknya di rig asli adalah kepalan tertutup yang tidak bisa dibuka).
- **Genggaman**: `CharacterRig.set_grip("r"/"l", 0..1)`; otomatis 1.0 saat memegang senjata, santai (0.35) bila kosong. Gagang senjata sekarang tepat di pusat kepalan (`GRIP_X/Y/Z` di `character_rig.gd`).
- **Mata**: dua sendi `eye_l/eye_r`; kuad mata menempel di bidang wajah (z=0.29, dulu 0.455 sehingga melayang saat dilihat dari samping). Kedip = skala Y tulang, melirik acak = geser tulang (`set_eye_state`).
- **Ayunan pedang** (`attack_sword1/2`): pose dihitung lewat FK + optimasi (bilah tidak lagi menembus tanah/kaki, tangan tetap di depan badan) dan ada kunci tengah busur. Alat bantu: `tools/blade_probe.tscn` (cetak arah bilah per frame), `tools/preview_anims.tscn --anims=... --hero=ren --rigyaw=`.

## Multiplayer Co-op (WiFi / Hotspot)

Menu **Lainnya → Multiplayer**. Semua pemain harus di WiFi/hotspot yang sama (HP host boleh yang menyalakan hotspot).
- **Buat Room**: nama room, password (opsional), stage. Room disiarkan lewat UDP broadcast (port 47777); game ENet di port 47778. Maks 4 pemain.
- **Gabung**: daftar room otomatis (ikon kunci bila berpassword) atau ketik IP host manual (cadangan bila broadcast diblokir hotspot). Password salah / room penuh / game sudah mulai / versi beda → ditolak dengan pesan.
- **Ruang tunggu**: daftar pemain, host memilih stage lalu **Mulai!**.
- **Di dalam stage**: host menjalankan AI musuh, gelombang, bos, hasil (otoritatif, HP musuh x(1+0.6 per pemain tambahan)); client menjalankan pemain sendiri, mengirim posisi & damage (RPC), melihat musuh sebagai puppet dari snapshot 10 Hz; pemain lain tampil sebagai ghost bernama; musuh menarget pemain terdekat yang hidup; semua pingsan = kalah, satu hidup = pemain lain menonton; host putus → client kembali ke lobi.
- Kode: `autoload/net.gd` (room, password, RPC), `scripts/net/coop_sync.gd`, `scripts/net/coop_ghost.gd`, `scripts/ui/panels/multiplayer_panel.gd`; izin Android INTERNET/ACCESS_NETWORK_STATE/ACCESS_WIFI_STATE/CHANGE_WIFI_MULTICAST_STATE sudah di `export_presets.cfg`.
- Uji: `tools/coop_test.tscn` (dua proses di satu mesin, loopback: penemuan room, password salah, gabung, mulai, damage client→host, selesai).
- **Batas jujur**: PVP belum ada (ditunda). Belum diuji di dua HP sungguhan / hotspot sungguhan. Telegraph lingkaran serangan musuh tidak terlihat di client (hanya kilat peringatan). Password tidak mengenkripsi lalu lintas (cukup untuk LAN pribadi). Setelah stage selesai, room tetap ada dan host bisa memulai lagi dari panel.

## Mata kotak (pixel)
Mata kotak SOLID (tanpa lubang transparan): sklera lavender, iris besar bergradasi warna karakter, pupil, kilau, garis bulu mata tebal; ukuran besar ala skin Minecraft populer. Generator: `tools/gen_eyes_box.py`; tekstur anime sebelumnya ada di `tools/eyes_old/`. Kedip & lirikan lewat bone mata.

## Mata per karakter + kilau skill
Tiap karakter punya gaya mata sendiri (bentuk kelopak, lebar iris, pupil bulat/celah, jenis kilau, warna) lewat `tools/gen_eyes_box.py`. Saat skill/ULT mata bersinar sesaat (`eye_glow` di `character_looks.gd`, dipicu `CharacterRig.play_action("skill")`).

## Rambut berlapis (semua karakter + NPC)
`CharacterLooks._hair_volume` menambah poni berlapis, rambut samping, lapisan belakang bergoyang, jambul (Ren) dan ekor (Sera, Ember) di atas rambut bawaan skin; gaya per karakter di `HAIR_STYLE`. NPC memakai warna rambut hasil sampling skin dan kini juga punya mata. Hakuya/Wenyu/Kuroha tetap memakai rambut khusus mereka. Musuh humanoid (berkerudung/bertopeng) belum diubah.

## PVP (WiFi / Hotspot)
Di menu **Multiplayer**, pilih arena `PVP · ...` (Padang Duel, Hutan Bayangan, Gua Kristal, Aula Marmer) saat membuat room / sebagai host. Semua pemain di room (2-4) langsung bertarung: hitung mundur 3-2-1, lalu tanpa musuh. Serangan basic, skill, proyektil dan ULT mengenai pemain lain. Damage antar pemain = damage normal x0.5 (`Stage.PVP_SCALE`). Pemain tersingkir bila seluruh party-nya pingsan; pertandingan selesai saat tersisa 1 pemain atau waktu 150 dtk habis (menang = kill terbanyak di antara yang hidup; imbang = SERI). Tidak ada hadiah/EXP (arena PVP bukan stage petualangan).
- Model: tiap pemain menghitung damage serangannya sendiri, dikirim lewat host (`Net._pvp_hit` → `_pvp_hurt`); host mengatur skor, waktu, dan akhir pertandingan. Lag/curang tidak dicegah (tidak ada server otoritatif penuh).
- Uji: `tools/coop_test.gd` dengan `--stage=pvp_meadow` (dua proses, loopback). Bot menempel ke lawan agar fokus menguji rute damage; gerak/akurasi arah asli belum diuji di HP.

## Optimasi perangkat ringan (tahap lanjut)
- Pengaturan tidak lagi memuat sebutan kelas perangkat; ringkasan memakai "Kualitas otomatis".
- Kualitas Lancar: NPC & warga yang jauh dari kamera (>42 m) disembunyikan dan animasinya dihentikan; rambut NPC dilewati; helai rambut lebih sedikit; kilau mata disembunyikan secara default.
- Angka perf hanya dari rasterizer software (relatif), belum diuji di perangkat asli.

## PVP duel 1v1 (perbaikan)
- PVP kini duel 2 pemain (room PVP maks. 2), jadi pilihan teratas di menu Multiplayer ("[DUEL 1v1]"); co-op tetap ada ("[CO-OP]", maks. 4).
- Efek tebasan/skill/proyektil pemain lain kini terlihat (`Stage.ghost_fx`, visual saja; damage tetap dihitung penyerang).
- Match langsung selesai bila lawan keluar; klien yang lambat memuat stage tetap ikut mulai (sinkron lewat skor); host menunggu hingga 30 dtk.

## Peta stage lebih luas, jarak render, rekor PVP, poles Menu
- **Jarak render (chunk)**: Pengaturan → Grafis → "Jarak render": Otomatis / 6 / 9 / 12 chunk (1 chunk = 16 m). Otomatis = 6 (Lancar), 9 (Sedang), 12 (Bagus). Jarak ini juga menentukan seberapa jauh pemandangan di luar arena dibangun.
- **Arena diperbesar 1,3x** (`StageArena.R_SCALE`) dan dunia di luar arena diisi: gunung bersalju, bukit, hutan jauh, danau (padang/hutan); dinding gua, stalaktit & kristal (gua/sarang); pagoda, lentera & pegunungan (kuil); pulau melayang & menara pilar (jurang/rantai/bos). Tiap objek jauh berkurang di kualitas Lancar. Alat: `tools/arena_view_bot.gd` (tangkapan layar pemandangan).
- **Rekor duel PVP**: menang/kalah/seri/kill tersimpan (`GameState.record_pvp`), tampil di layar hasil, Statistik, dan Profil.
- **Poles Menu**: helper `BasePanel.section/info_row` (gaya kartu Pengaturan); Profil & Quest ditata ulang, daftar gulir tidak lagi menutupi kartu; menu "Co-op WiFi" menjadi "Multiplayer".


## Aion – manipulasi waktu (karakter ★5 baru)
- Desain orisinal: rambut putih disisir miring dengan kuncir rendah berklip emas, mata heterokromia (ungu & hijau), mantel panjang putih-hitam ramping dengan pelindung bahu bersudut, jubah pendek asimetris, dasi pita teal & bros jam emas, tongkat berhias cincin jam (versi ramping: stola bulu, simpul bulat, sanggul & anting sudah dihapus). Skin `tools/gen_skins.py`, mata `tools/gen_eyes_box.py` (`aion`, `aion_r`), model `CharacterLooks._aion/_clock_staff`.
- Seimbang (tidak OP): HP/ATK di bawah Vael & Lucien, serangan dasar lambat-sedang (`attack_mult` 0,85), skill cooldown 8 dtk. Kekuatan utamanya kontrol, bukan damage:
  - **Jeda Waktu** (skill): damage 1,7x + slow 50% (3,5 dtk). Slow tidak menumpuk; bos hanya melambat maksimal 40% (faktor ≥ 0,6).
  - **Putaran Jam Raya** (ULT): musuh dalam jangkauan melambat 80% selama 3 dtk, tujuh serpihan jarum jam jatuh + ledakan penutup (mult 7, lebih rendah dari ULT lain).
- Mekanik `Enemy.apply_slow(factor, dur)`: skala waktu lokal (gerak, serangan, animasi), semburat biru + cincin jam kecil di kaki.
- Efek: `scripts/stages/chrono_fx.gd` (wajah jam, jarum, cipratan tinta, gagak), tekstur buatan `tools/gen_clock_art.py` (`clock_face.png`, `ink_splash.png`). Pool gacha ★5: Vael, Lucien, Aion.
- Batasan: slow hanya mempengaruhi AI musuh di sisi host; klien co-op melihat tandanya saja; PVP tidak memperlambat lawan. Belum diuji di perangkat nyata.


## Musuh lebih tangguh & lebih bagus
- **Keluhan:** musuh mudah dikalahkan, HP sedikit, tampilan kurang bagus.
- **HP/ATK:** musuh biasa HP ×2,6 & ATK ×1,2; bos HP ×1,8 & ATK ×1,1 (konstanta `HP_MULT_*`/`ATK_MULT_*` di `enemy.gd`). Kecepatan naik 2,5% per level rekomendasi.
- **Poise:** pukulan kecil tidak lagi membatalkan aba-aba serangan musuh (dulu setiap pukulan membuat musuh terpental/stagger). Hanya pukulan ≥ 28% HP maks yang memotong, dan setelah stagger ada kekebalan 0,9 dtk (tidak bisa di-stunlock).
- **Lebih agresif:** pemulihan musuh biasa 25% lebih cepat, serangan menukik kelelawar lebih sering, terjang slime lebih cepat.
- **Slime pecah:** slime mati → dua Slime Kecil (HP kecil, cepat) muncul.
- **Musuh ELIT:** sebagian musuh gelombang (10% + 5% per gelombang, maks 35%) jadi elit: HP ×2, ATK ×1,3, DEF +1, lebih besar, berpendar emas, label "ELIT", bar HP emas selalu tampak, tidak terpotong serangannya.
- **Tampilan:** slime punya 3 warna (hijau/biru/merah muda), inti berpendar, kilap, gelembung, pipi, jambul; kelelawar punya taring & dada terang. Elit pada klien co-op belum ditandai (host yang menentukan).
- Uji: `tools/enemy_look_bot.gd` (statistik, poise, slime pecah, foto close-up).


## Perbaikan logika: rumah tembus pandang, gerak, goresan pedang
- **Rumah tembus pandang saat didekati:** penyebabnya kotak bangunan diperbesar 0,3 m sebelum dites terhadap garis kamera→kepala, sehingga berdiri dekat dinding saja sudah membuat bangunan memudar. Sekarang kotak diperkecil 0,25 m dan garis harus menembus bangunan minimal 0,8 m sebelum sampai ke pemain (`segment_hits_aabb(..., end_margin)`). Bangunan hanya memudar bila benar-benar berada di antara kamera dan pemain. Uji: `tools/occlusion_bot.gd`.
- **Gerak & gravitasi** (`player.gd`): percepatan 46 m/s² dan perlambatan 60 m/s² (tidak lagi langsung loncat ke kecepatan penuh / berhenti mendadak), kontrol di udara 35%, jatuh 1,35× lebih berat dengan kecepatan jatuh maksimum 38 m/s, menempel ke lantai lebih kuat (turun lereng tidak melayang), bergerak sambil menyerang 45% (dulu 35%). Uji: `tools/gerak_bot.gd`.
- **Goresan/“salinan” pedang di belakang karakter:** pita jejak bilah (`BladeTrail`) dulu menyimpan titik 0,26 dtk dan menutupi seluruh panjang bilah, sehingga saat diayun ia tertinggal seperti bayangan pedang. Kini hidup 0,15 dtk, hanya sepertiga ujung bilah, memudar lebih cepat; pita "ujung tebasan" di tanah dibuat lebih tipis dan tidak seputih sebelumnya. Penyebab pasti di perangkat nyata belum bisa direproduksi di PC (hanya diverifikasi lewat tangkapan layar), jadi mohon dicek ulang di HP.



## Detail untuk semua karakter
- Skin 10 karakter lama diberi motif halus (bintang/daun/api/awan/rivet/kisi, tenunan kain, garis jahitan) lewat `apply_detail` di `tools/gen_skins.py`.
- Model 3D bersama: jubah kini punya lipatan kain + jahitan emas di tepi; sabuk punya paku, bingkai gesper, kilau tepi, kancing & jahitan kantong; manset/bracer punya garis & paku; tabard punya lambang dan rumbai.
- Uji: test_data LULUS, looks_cost_bot FAILS=0 (jumlah segitiga per karakter ~20 ribu; belum diuji di HP asli).

## Stage misi baru (opsional)
Ditambah 4 stage: 1-4 Padang Bintang Jatuh, 2-4 Reruntuhan Bara, 4-4 Lorong Doa, 5-3 Ruang Gembok. Masing-masing 3 gelombang, intro cerita singkat, dan terbuka setelah stage sebelumnya, tanpa mengunci jalur bos lama (progres lama aman).
Uji: test_data LULUS (24 stage); stage_bot 1-4 menang (fails=0); 5-3 hanya diuji kalah sengaja (`--lose=1`) dengan party level 1, jadi keseimbangan tingkat kesulitannya belum diuji dengan party yang sesuai level.

## Perbaikan bug peta
- Bug ditemukan lewat bot baru `tools/map_bot.gd`: musuh bisa muncul di dalam pohon/batu/tiang (14 dari 400 titik acak terblokir di 1-1). Sekarang `Stage._spawn_pos()` dan titik bos memakai `spot_blocked`/`free_spot` (cek tabrakan fisik) sehingga selalu di tempat kosong.
- Bot menguji tiap peta: pemain mulai di lantai, titik spawn musuh/bos bebas dari benda padat, berjalan ke 8 arah tepi tidak bisa keluar/jatuh. Hasil: 24 dari 24 stage/arena (termasuk 4 arena PVP) lulus, fails=0.
- Batas uji: hanya tabrakan dan batas arena; tidak mencakup tampilan visual, performa di HP asli, atau perilaku co-op/PVP lewat jaringan.

## Upgrade besar - Batch 1: Eksplorasi
Audit awal: minimap, teleport, fishing, cooking, housing, crafting, pet/mount, skill tree, awakening, kostum, world boss, dungeon, treasure chest dan area rahasia belum ada di kode. Batch 1 (dipilih pemain) mengerjakan Eksplorasi; sisanya BELUM dikerjakan.
- **Minimap HUD** (kiri, di bawah tracker quest): mengikuti pemain & berputar sesuai kamera, tombol +/- untuk zoom, ketuk untuk membuka **Peta penuh**. Di stage: minimap arena dengan musuh/bos/elit/peti.
- **Peta penuh** (`map_panel.gd`): seluruh kota, titik teleport, peti (belum/sudah dibuka), area rahasia, statistik penemuan. Ketuk titik teleport lalu tombol Teleport.
- **Treasure chest**: 8 peti biasa + 5 peti emas tersembunyi di lobi (`scripts/systems/explore.gd`, `scripts/lobby/explore_world.gd`), hadiah Gold/Diamond/ramuan menurut tingkat (kayu/perak/emas). Satu peti medan per stage (Gold tiap kali, Diamond bonus sekali per stage).
- **Area rahasia**: Lorong Rahasia, Sudut Senja, Celah Selatan (lorong sempit di balik deretan rumah). Ditemukan saat dimasuki, hadiah Diamond sekali.
- **Teleport**: 9 batu teleport di lobi; 2 terbuka sejak awal, sisanya terbuka saat didekati. Teleport hanya ke titik yang sudah terbuka.
- Data tersimpan di `GameState.flags["explore"]` (ikut simpan aman). Posisi semua peti/titik diverifikasi dapat dicapai dari gerbang lewat `tools/reach_scan.gd`.
- Uji: `explore_bot` (22 cek, lulus), `stage_chest_bot` (8 cek, lulus), test_data, occlusion, gerak, menu, panel lulus. Belum diuji di HP asli; ketepatan ketukan minimap di layar sentuh dan keterbacaan label peta perlu dicek di HP. Quest "buka peti" dan peti di dalam dungeon belum ada.

## Rapikan HUD
HUD lobi kini hanya Quest, Gacha, Shop, Menu (sebaris). Karakter, Party, Inventori, Equipment, dan Peta pindah jadi kartu di dalam Menu; Pengaturan tetap lewat ikon roda gigi di kepala Menu. Tombol zoom minimap dihapus (ketuk minimap = peta penuh). panel_bot diperbarui (10 panel dibuka lewat HUD + Menu, lulus).

## Wilayah Jelajah (map baru selain lobi)
Tiga wilayah bebas jelajah, dibuka dari **Start Adventure -> daftar "Wilayah Jelajah"**: Padang Angin (buka setelah 1-1), Hutan Berbisik (setelah 2-1), Gua Kristal (setelah 2-3). Dibangun di atas Stage (mode `field`, id berawalan `f_`):
- Arena ~2,3x lebih luas (radius ~46-52 m), tanpa gelombang/waktu; monster muncul terus (maks 5/7/9 sesuai kualitas), minimal 14 m dari pemain, elit 12%. Tiap monster memberi Gold & EXP kecil.
- 6 peti per wilayah (4 biasa + 2 emas tersembunyi) dan 2 area rahasia (Diamond sekali) — semua tersimpan di `flags["explore"]`, peti yang sudah dibuka tetap terbuka.
- Minimap mengikuti pemain, menampilkan musuh, peti yang ditemukan, area rahasia, dan gerbang. Gerbang Lobi: berdiri ~1 detik (harus menjauh dulu). Pingsan semua = bangkit di gerbang dengan HP 50%, tanpa hukuman.
- Uji: `field_bot` (15 cek x3 wilayah), `map_bot` (3 wilayah), test_data, panel/menu/explore/stage/combat bot lulus.
- Batas: wilayah masih lengang dibanding lobi (dekor tengah arena sedikit), belum ada boss/quest wilayah, tidak mendukung co-op, belum diuji di HP asli (performa arena luas perlu dicek di HP kelas bawah).

## Layar pemuatan menyesuaikan HP
`autoload/flow.gd` (`Flow.goto`): scene dimuat di thread (ResourceLoader.load_threaded_*) dengan bilah progres dan titik animasi, bukan lagi `change_scene_to_file` yang membekukan layar. Waktu muat tiap perpindahan dicatat (rata-rata, `user://device_speed.cfg`, terpisah dari save) lalu menentukan "kelambatan HP" 0..1 (juga dipengaruhi grafis Lancar): HP cepat = fade lebih panjang dan layar ditahan ~0,35 dtk agar teks terbaca; HP lambat = fade pendek dan layar muat ditahan sampai 4 bingkai berturut-turut halus (maks 2,2 dtk) sebelum dibuka, sehingga patah-patah saat scene baru muncul tidak terlihat. Perbaikan bug: gagal memuat scene tidak lagi macet di layar "Memuat" (kunci dilepas + toast), ketukan ganda diabaikan.
Uji: `flow_bot` lulus (8 cek). Angka waktu muat di sini dari mesin uji tanpa GPU (~3 dtk), bukan HP; efek nyata di HP perlu dicek langsung.

## Audit bug & optimasi untuk Android (Back, Party, HUD)

Perbaikan (semua diuji bot di Godot 4.3 + GL virtual; **belum diuji di HP sungguhan**):
- **Tombol Back Android menutup seluruh game.** `application/config/quit_on_go_back` masih `true` (bawaan), dan Back tidak menghasilkan event keyboard sehingga menu/jeda tak pernah tersambung. Kini `quit_on_go_back=false`; `Flow` mengubah notifikasi Back menjadi aksi `menu_back` (panel menutup, stage jeda/lanjut). Di lobi/judul tanpa panel: Back dua kali dalam 2 detik untuk keluar. Handler Back ganda di `PanelHost` dihapus. Uji: `tools/back_party_bot.gd`, `tools/back_stage_bot.gd`.
- **Save dengan party > 4** kini dipotong ke `PARTY_SIZE` saat dimuat. `set_party_slot` ke slot yang sama tidak lagi memancarkan sinyal/menyimpan.
- **Urutan roster Party tidak stabil** saat rarity/kekuatan sama (kartu bisa melompat); kini urut nama lalu id.
- **`InputSetup.ensure()`** menambah event gamepad/stik berulang tiap pindah scene; kini sekali.
- **Potret yang gagal dirender** tak lagi dicoba ulang tiap panel dibuka (`Portraits._failed`).

Optimasi (angka dari 1 CPU + llvmpipe, bandingkan rasio, bukan angka mutlak; bot: `tools/party_perf_bot.gd`, `tools/hud_perf_bot.gd`):
- Panel Party: kekuatan dihitung sekali per refresh; refresh dipecah (slot/roster/bar); gradien & StyleBox dipakai bersama. Ketuk slot 67 -> 24 ms. Refresh penuh tetap ~68 ms (didominasi pembuatan node).
- Potret 3D yang selesai dirender kini mengisi **hanya kartunya** (`_on_portrait_ready`), bukan membangun ulang seluruh panel: saat Party pertama dibuka, `refresh()` penuh 17x -> 1x (terukur dengan `tools/party_open_bot.gd`; total waktu muat dominan oleh render potret).
- `BasePanel.queue_refresh()`: beberapa sinyal dalam satu frame = satu refresh (dulu satu per sinyal).
- `StageHud.update_party`: StyleBox kartu dibuat sekali, bukan 4 objek baru tiap 0,1 dtk (0,164 -> 0,010 ms per panggilan).
- `Enemy._separate` (tiap musuh tiap frame fisika) memakai jarak kuadrat: hasil identik (checksum sama), 0,291 -> 0,181 ms per frame untuk 24 musuh (-38%). `Projectile` tidak lagi membuat array gabungan tiap frame bila tak ada pemain ghost (co-op/PVP). Bot ukur: `tools/sep_perf_bot.gd`.
- CI: langkah **APK RILIS** opsional (`buildapk.yml`), jalan bila Secrets `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEY_ALIAS`, `ANDROID_KEYSTORE_PASSWORD` diisi. Belum pernah dijalankan.

Catatan: `tools/scroll_bot.gd` (cek inersia) tidak stabil di mesin 1 CPU (gagal acak juga di kode sebelum perubahan). Play Store butuh AAB (Gradle build) dan keystore rilis; proyek ini belum disiapkan untuk AAB.

Catatan uji: `tools/charfx_bot.gd` (batas 160 node efek) juga tidak stabil di mesin 1 CPU: puncak Zeya berkisar 118-220 pada kode sebelum perubahan. Opsi yang sengaja TIDAK dipasang karena belum bisa diuji di HP: `physics/common/max_physics_steps_per_frame` lebih kecil dari 8 (mencegah spiral fisika di HP lambat, tapi game melambat di bawah ~15 fps).

## Perbaikan lag & suara patah-patah (HP Android)
- `project.godot`: `audio/driver/output_latency=60` (bawaan 15 ms terlalu kecil, mixer audio kehabisan data saat HP sibuk -> suara patah).
- `autoload/sfx.gd`: suara yang sama tidak diputar lagi dalam jeda singkat (mencegah belasan "hit/swing" menumpuk), pemain suara 16 -> 10.
- `scripts/stages/fx.gd`: `Fx.burst` memakai mesh/material yang di-cache (dulu membuat baru tiap pukulan), maksimal 14 ledakan hidup bersamaan, jumlah partikel dikurangi di kualitas Lancar.
- `scripts/stages/enemy.gd`: pemisahan antar-musuh dikerjakan selang-seling tiap 2 frame (kekuatan 2x), memangkas pekerjaan O(n^2).
- `autoload/game_state.gd`: kualitas grafis bawaan jadi Otomatis dan Resolusi dinamis aktif (save lama dimigrasikan, `gfx_v` = 3). Bisa diubah lagi di Pengaturan.

### Update lanjutan (lag masih terasa di HP)
- Bayangan nyata (shadow map) dan bayangan awan kini hanya aktif di kualitas **Bagus**; Otomatis/Lancar/Sedang memakai bayangan semu (blob). Ini beban terbesar di renderer Compatibility.
- Kualitas Otomatis + Resolusi dinamis jadi bawaan (`gfx_v` = 4, save lama dimigrasikan), batas bawah skala 3D Sedang 0.65 -> 0.55.
- `audio/driver/output_latency` 60 -> 80 ms; `physics/common/max_physics_steps_per_frame=3` supaya saat FPS jatuh fisika tidak menumpuk (spiral lag).

### Layar memuat
- `scripts/ui/loading_screen.gd` (`LoadingScreen`): tampilan layar memuat disamakan dengan layar judul: langit malam + bulan + pegunungan + bintang berkelip, logo emas "FANTASY LIFE RPG" di kiri, bar berpelat emas (gaya tombol menu), persen, dan kotak TIPS. Dipakai oleh `Flow`.
- `autoload/flow.gd`: perpindahan scene (judul, lobi, stage) kini memakai layar memuat tersebut: bar kemajuan, persen, dan tips acak. Scene dan aset berat (atlas dunia, model hero/bos, tekstur efek) dimuat di thread latar (`ResourceLoader.load_threaded_request`), jadi bar mengikuti kemajuan nyata dan scene lebih sedikit patah saat mulai. Tampil minimal 0,9 detik. Daftar aset ada di konstanta `PRELOAD`, tips di `TIPS`.
- `project.godot`: boot splash memakai latar biru malam tanpa logo Godot.

### Musik utama diperkecil
- `assets/audio/music_main.mp3`: 4,96 MB -> 1,64 MB (-67%). MP3 stereo 32 kHz 64 kbps, gambar sampul dan metadata dibuang, durasi tetap 3:25. Nama file tidak berubah, jadi kode dan import tetap sama. Kekerasan turun sekitar 0,4 dB. File asli bisa dibuat ulang dari lagu Suno-nya bila ingin kualitas penuh.

### Panel menu dirapikan (tas, party, toko, karakter, dll)
- `scripts/ui/ui_theme.gd`: tombol, tombol aksen, dan kartu kini bergaya "pelat" seperti tombol menu judul (tepi kiri emas tebal, tepi lain tipis); sudut seragam (9 px); pemisah (`HSeparator`) jadi garis emas tipis; ada helper baru `UiTheme.plate()` dan `UiTheme.gold_rule()` (garis emas memudar).
- `scripts/ui/base_panel.gd`: jendela panel menghormati area aman layar (notch / sudut membulat), bingkai dan judul bergaya (huruf agak renggang), tombol tutup bergaya pelat merah, garis emas di bawah judul, judul bagian dan kartu memakai gaya yang sama. Semua panel yang turunan `BasePanel` otomatis ikut.

## Penggabungan: versi eksplorasi + versi perbaikan Android
Proyek ini hasil gabungan dua cabang yang sama-sama berawal dari versi 10-11 November.
- **Dari cabang eksplorasi:** minimap, peta penuh & teleport, peti, area rahasia, 3 Wilayah Jelajah, 4 stage misi baru (1-4, 2-4, 4-4, 5-3), detail kain/sabuk/manset semua karakter, HUD lobi 4 tombol, bot uji eksplorasi/peta, skrip `kirim_ke_github.sh`.
- **Dari cabang perbaikan:** tombol Back Android, perbaikan lag/audio, layar memuat bergaya judul, musik diperkecil, gaya panel pelat emas, panel Party lebih cepat, layar hasil + tombol Lanjut, anti-nyangkut musuh, mode SUSAH, cerita baru, CI APK rilis opsional.
- **Titik yang disatukan manual:**
  - `autoload/flow.gd`: layar memuat baru (`LoadingScreen`, tips, preload aset) + penyesuaian kecepatan per HP (`speed_slow`, `_wait_settled`) + jalur gagal-muat yang tidak macet.
  - `scripts/stages/stage.gd` dan `arena.gd`: mode Wilayah Jelajah tetap jalan (`R_SCALE` tetap variabel); stage biasa memakai titik spawn tetap (anti-nyangkut) yang dipastikan bebas benda padat lewat `free_spot`.
  - `data/story.json`: gabungan per id (adegan baru 1-2, 1-3, 2-2, 2-3 dan intro 4 stage misi).
  - Aion memakai desain **ramping** (versi terbaru); karakter lain tetap memakai skin & model berdetail. `tools/gen_skins.py` sudah disesuaikan.
  - Workflow CI: hanya `buildapk.yml` (versi baru); `build-apk.yml` lama dihapus agar build tidak ganda.
- **Belum diuji:** hasil gabungan ini belum dijalankan di Godot (tidak ada Godot di lingkungan penggabungan). Uji bot (`tools/run_all.sh`) dan coba di HP sebelum dipakai.

## Perbaikan setelah penggabungan: musuh nyangkut & tata letak
Diukur dengan bot baru `tools/stuck_bot.gd` (pemain berputar di sela rintangan; musuh darat berstatus mengejar yang bergeser < 0,6 m selama 3 dtk dihitung macet). Godot 4.3 headless, bukan HP asli.
- **Penyebab nyangkut:** slime melompat, jadi di fase diam antar-lompatan hitungan mandeknya terhapus dan tidak pernah terdeteksi; selain itu penyelamatan baru jalan setelah 3x mandek (±3,6 dtk). Sekarang hitungan ditahan di fase diam, penyelamatan setelah 2x mandek, pergeseran samping 0,6 dtk.
- **Penyelamatan lebih andal:** `_free_spot_near` mencoba 30x dengan jangkauan melebar, lalu cadangan mundur ke arah tengah arena.
- **Tata letak:** batu/kristal/stalagmit kini tersebar dari 36% radius sampai tepi (dulu hanya cincin tepi 72%+), tengah arena tetap bebas.
- **Titik muncul musuh:** acak di sabuk 55-88% radius, minimal 11 m dari pemain dan bebas benda padat (dulu 6 titik tetap di tepi).
- Hasil: sebelum perbaikan ±2 dari 4 percobaan di s2_1 ada slime macet; sesudahnya 1 dari 16 musuh (s2_1) dan 0 dari 27 musuh di s1_1, s1_3, s4_1, s5_1. Bot lain lulus: map, field (2 wilayah), flow, panel, explore, peti stage, back party/stage, test_data.
- Batas: yang dites hanya 4 gelombang awal tiap stage dan bos tidak diukur; gugus batu masih bisa menjebak sesaat (maks ±1,5 dtk sebelum dipindahkan).

## Perbaikan suara terpotong/hilang saat menyerang (APK)
- **Penyebab (dugaan kuat dari kode):** pool efek suara dikecilkan jadi 10 dan jeda minimum antar suara yang sama 0,06-0,07 dtk. Saat serangan beruntun atau serangan area (banyak "hit"), tebasan ikut dibuang atau pemutarnya dipakai ulang sehingga terpotong; suara bos panjang juga hanya punya 1 pemutar.
- **Perbaikan** (`autoload/sfx.gd`): pool 14; jeda minimum disaring hanya untuk salinan di bingkai yang sama (0,03-0,05 dtk); `swing` (3), `hurt` (2), `dash` (2), `die` (1) punya pemutar khusus bergantian sehingga tidak dipotong efek lain; suara bos memakai 3 pemutar bergantian.
- **Uji:** `tools/sfx_bot.gd` (Godot 4.3 headless, driver audio Dummy): 3 tebasan serentak terdengar semua, tebasan tak terpotong 40 "hit", salinan hit di bingkai sama disaring, 2 suara bos jalan bersamaan, semua efek termuat. Ini menguji logika, bukan audio di HP asli.
- **Belum terbukti di HP:** bila masih patah-patah, penyebab lain yang mungkin adalah CPU HP (dekode musik MP3 + efek). Coba turunkan grafis ke Lancar, atau beri tahu tipe HP-nya.

## Perbaikan game terasa berat/patah-patah setelah jadi APK
- **Penyebab utama (dari konfigurasi build):** APK utama dan admin diekspor dengan `--export-debug`. Template debug Godot menjalankan GDScript dengan pemeriksaan debugger/profiler tambahan dan jauh lebih lambat daripada template rilis; di HP kelas menengah ke bawah ini terasa sebagai lag.
- **Perbaikan** (`.github/workflows/buildapk.yml`): APK game dan admin sekarang diekspor sebagai **RILIS** (`--export-release`). Bila rahasia keystore rilis tidak diisi, ditandatangani memakai keystore debug otomatis; bila ekspor rilis gagal, otomatis jatuh ke debug dan memberi peringatan `Ekspor rilis gagal` di log Actions.
- **Setelah build:** hapus dulu versi lama di HP sebelum memasang (tanda tangan berbeda), lalu cek FPS di Pengaturan.
- **Belum teruji:** build APK tidak bisa dijalankan di lingkungan penggabungan (tidak ada Android SDK), jadi efek di HP belum diukur. Bila masih berat, catat tipe HP, tingkat grafis, dan FPS yang tampil.

## Peta lobi diperbesar 50%
- Seluruh tata letak lobi (`lobby_layout.gd`, `explore.gd`, `lobby_world.gd`, `npc_defs.gd`, langit/ambien) diskalakan 1,5× pada posisi; bangunan hanya sedikit lebih besar (×1,2) agar jalan dan alun-alun terasa luas. Titik muncul, tembok, batas, jalan, area pohon, peti, area rahasia, titik teleport, dan lingkaran warga ikut diskalakan.
- Jarak pandang dan jumlah potongan (chunk) yang digambar tetap dibatasi tingkat grafis, jadi beban render tidak naik; yang bertambah hanya waktu membangun dunia saat memuat.
- `tools/reach_scan.gd` kini memeriksa 38 titik desain terhadap tata letak baru (toleransi 2,5 m untuk titik yang berisi objeknya sendiri). Peti Bengkel digeser agar tidak tertimpa pohon/batu. `explore_bot` memakai koordinat baru.
- Peta mini: lebar 184 px, radius pandang 52 m.

## Rapi-rapi UI
- Menu utama (`more_panel.gd`): kartu kini punya tiga pola tanpa teks bertabrakan dengan ikon: lebar (ikon kiri), ringkas (ikon kecil di pojok), dan inti (ikon di atas judul, rata tengah); judul dipangkas dengan elipsis bila terlalu panjang.
- Tes `perf_test` disesuaikan dengan `quality.gd` versi update (bayangan nyata hanya di tingkat Bagus).

## Rapi-rapi ekonomi (masukan viewer)
- Modal awal dunia baru: 800 emas + 1.000 berlian (sebelumnya 500 emas + 3.000 berlian yang membuat gacha terasa gratis). Konstanta `GameState.START_GOLD/START_DIAMONDS`. Simpanan lama tidak berubah.
- Bonus login 3 hari: 1.000 emas+100 berlian, 1.500 emas+150 berlian, Zeya+200 berlian (sebelumnya 2.000/3.000 emas, lebih besar daripada hadiah satu bab).
- Harga toko diseragamkan per tingkat: senjata ★2 = 400, ★3 = 1.300 (sebelumnya 400/410/420 dan 1.300/1.320/1.350); armor 120/400/1.200; aksesori 150/450/1.400.
- Harga jual: barang toko tetap separuh harga beli; barang gacha (tanpa harga toko) memakai tabel yang sama dengan separuh harga toko per bintang: ★1 50, ★2 200, ★3 650, ★4 1.800, ★5 4.500 (sebelumnya ★2/★3 hanya 40/120 padahal di toko laku 200/650).
- Hadiah stage, biaya gacha (100 / 900 per 10), pity, dan biaya upgrade senjata tidak diubah. Diamond tetap datang dari klaim pertama stage, bos, misi, pencapaian, dan login.
- `test_data` kini memeriksa keseragaman harga senjata per bintang, tidak ada jual > separuh beli, dan harga jual naik tiap bintang.

## Dunia lebih hidup (lobi)
- 8 warga baru berpatroli bolak-balik di jalan kota (jalan utama, bulevar barat/timur, jalan samping, jalan guild, lorong altar); berjalan di sisi jalan, sesekali berhenti 3–7 detik. Rig warga yang jauh dari kamera (>70 m; >42 m di Lancar) disembunyikan agar hemat gambar.
- 7 burung berputar tinggi di atas kota dan 18 kelopak/daun berguguran di sekitar pemain (siang). Keduanya berupa quad kecil di `Ambient`, mati bersama kupu-kupu/kunang-kunang di kualitas Lancar.
- Peta 1,5× tetap memakai jarak render yang sama, jadi beban gambar tidak naik; yang bertambah hanya 8 rig warga (disembunyikan bila jauh).

## Adventure satu alur (tanpa pilih stage)
- Start Adventure kini langsung membuka langkah berikutnya, bukan daftar stage. Urutan di `Data.adventure_order`: stage cerita dengan wilayah jelajah disisipkan tepat setelah stage pembukanya (Padang Angin setelah 1-1, Hutan Berbisik setelah 2-1, Gua Kristal setelah 2-3). `GameState.adventure_next()` memilih langkah pertama yang terbuka dan belum selesai.
- Wilayah jelajah jadi bagian Adventure: kalahkan 12 monster (`Stage.FIELD_GOAL`) untuk menaklukkannya (sekali). Hadiah tamat: Padang 250 emas/120 EXP/40 berlian, Hutan 450/220/70, Gua 650/300/90, lalu langkah berikutnya terbuka. Peti, area rahasia, dan emas/EXP per monster tetap ada.
- Tombol "Stage berikutnya" di layar hasil mengikuti urutan Adventure (bisa berupa wilayah).
- Panel Adventure menampilkan kemajuan dan hanya menawarkan ◀ Ulangi sebelumnya / Ulangi berikutnya ▶ untuk langkah yang SUDAH selesai (farming). Tidak ada daftar pilih. Mode daftar lama tetap ada di kode (`stage_select` tanpa argumen `adventure`) untuk tes lama.
- Tes baru: `adventure_flow_bot` (alur panel & urutan), `field_goal_bot` (penaklukan wilayah), dan pemeriksaan urutan di `test_data`.

## Ringan untuk HP kelas bawah & menengah
Diukur dengan `tools/render_cost_bot.gd`, `combat_cost_bot.gd`, `cpu_cost_bot.gd` (draw call/objek/primitif tidak bergantung GPU, jadi berlaku juga di render software; waktu ms hanya pembanding relatif).
- **Temuan utama:** tiap karakter/monster humanoid (`hero.glb`) ±19.000 segitiga + rangka 39 tulang. Satu gelombang 11 monster ≈ 209.000 segitiga; di Lancar stage 4-3 sempat ±270.000 primitif/bingkai. Mesh dibangun per-piksel kulit (kuadrat tak berbagi titik) sehingga LOD otomatis Godot tidak menghasilkan apa-apa (diuji) dan tidak mengubah apa pun di renderer Compatibility; menyederhanakannya butuh rekayasa ulang model, jadi tidak dilakukan.
- **Batas monster hidup bersamaan** (`Quality.enemy_alive_cap()`): Lancar 7, Sedang 10, Bagus tanpa batas. Jumlah total per gelombang tetap (sisanya muncul bergiliran saat ada yang kalah; gelombang belum dianggap selesai selama masih ada antrean). Hanya mode tunggal. Puncak primitif Lancar stage 4-3: ±270 ribu → ±192 ribu; rata-rata ±238 ribu → ±151 ribu.
- **Warga lobi per kualitas** (`Quality.villager_budget()`): Lancar 3 / Sedang 7 / Bagus 12 (dipilih menyebar di alun-alun dan jalan, `NpcDefs.VILLAGER_PRIORITY`).
- **Rig jauh dimatikan** (`Quality.rig_cull_dist()`: 34 / 55 / 90 m): NPC dan warga yang jauh disembunyikan dan animasi/rangkanya dihentikan (`process_mode` nonaktif) di semua kualitas, bukan hanya Lancar. Warga tidak memanggil animasi saat tak terlihat.
- **Label 3D** dinding bangunan dan nama wilayah dibatasi jarak tampil (70 m / 45 m).
- **Jarak render** Lancar/Sedang 5/8 chunk (sebelumnya 6/9); kabut linear dirapatkan di Lancar/Sedang agar tepi jarak tidak terlihat muncul tiba-tiba (tanpa biaya tambahan).
- Tidak diubah: resolusi 3D dinamis (Perf governor), bayangan semu di Lancar/Sedang, lampu titik mati di Lancar, kupu-kupu/burung/kelopak mati di Lancar.
- Belum diukur di perangkat sungguhan. Titik berikutnya bila masih berat: draw call lobi (±200; sebagian besar kerangka karakter ±11-20 mesh per rig dan 6-8 permukaan per chunk) dan mesh karakter.
- Catatan tes: `efek`, `audit_serang`, `efek_karakter` peka waktu; bila dijalankan bersamaan dengan proses lain di render software kadang gagal sesaat (angka puncak/penyelesaian efek), tetapi lulus semua saat dijalankan sendiri. `stuck_bot` kini cukup n >= 1 (jumlah musuh darat bervariasi karena kelelawar tidak dihitung).

## Bangunan rapi & warga bisa diajak bicara

**Bangunan.** Rumah di `scripts/lobby/lobby_layout.gd` ditata seragam: dua baris di jalan utama (x=±18, z=36 dan 78) dan dua jalan samping (x=±71,25) dengan jarak tetap antar rumah. Pindai keterjangkauan (`tools/reach_scan.gd`): 0 dari 38 titik bermasalah; tampak atas kota (`tools/lobby_overview.gd`) simetris.

**Warga.** Dua belas penduduk yang berjalan-jalan kini punya nama, gelar, dan kalimat khas (`NpcDefs.VILLAGERS`). Dekati mereka dan tombol Interaksi muncul ("Bicara dengan …"). Saat bicara mereka berhenti dan menghadap pemain, lalu lanjut berjalan sekitar 1 detik setelah dialog ditutup. Pilihan dialog: *Ada kabar apa?* (kabar umum dari `VILLAGER_RUMORS`, berganti tiap kunjungan), *Apa yang sebaiknya kulakukan?* (petunjuk menyesuaikan kemajuan: quest siap klaim, langkah Adventure berikutnya, atau sudah tamat). Uji: `tools/villager_talk_bot.gd` (`run_all.sh` → `warga_bicara`).

Belum diuji di perangkat/APK sungguhan.

## Rumah berpenghuni & bangunan tidak tembus pandang

- **Tidak tembus pandang lagi.** Efek memudarnya bangunan saat menghalangi kamera dihapus (`Building.can_fade` default `false`, pembaruan oklusi di `lobby.gd` dibuang). Bangunan selalu padat dan tetap punya tabrakan, jadi pemain tidak bisa menembusnya.
- **Penghuni tiap rumah.** Setiap rumah punya satu penghuni (`NpcDefs.RESIDENTS`, 15 orang) yang mondar-mandir pendek di depan pintu rumahnya, bisa diajak bicara seperti warga lain (sapaan "Selamat datang! … tinggal di rumah ini."). Jumlah yang tampil mengikuti kualitas (`Quality.resident_budget()` = 3 / 8 / semua); rumah terdekat dari alun-alun diutamakan, dan rig di luar jarak pandang tetap dimatikan.
- Uji: `tools/occlusion_bot.gd` (`oklusi`) kini memeriksa: tidak ada bangunan transparan, rumah punya tabrakan, penghuni ada di dekat rumahnya, dan dialognya.
- Catatan: tanpa efek transparan, atap/dinding bisa sesekali menutupi pemain dari kamera. Belum diuji di perangkat sungguhan.

## Pintu rumah bisa dibuka & ada isinya

- Dekati pintu rumah warga: tombol Interaksi menjadi **"Buka pintu"**. Daun pintu berayun terbuka, layar memudar, lalu pemain masuk ke interior (tempat tidur, meja + bangku, perapian menyala, rak buku, karpet, tong/peti, tanaman, lukisan/perisai). Penghuni rumah menyambut di dalam dan bisa diajak bicara; tombol **"Keluar rumah"** di dekat pintu membawa pemain kembali tepat di depan pintu.
- **Tetap ringan:** interior (`scripts/buildings/house_interior.gd`) dibuat hanya saat dimasuki (1 mesh gabungan + 1 tubuh tabrakan + 1 lampu, lampu dimatikan di kualitas terendah) dan dibuang saat keluar. Selama di dalam, kota/ambient/NPC disembunyikan dan dimatikan prosesnya: adegan 3D ±26 draw call (di luar ±200). Daun pintu hanya ada sesaat saat animasi. Tidak ada efek tembus pandang: dinding depan ruangan rendah dan kamera dikunci menghadap ke dalam.
- Uji: `tools/house_bot.gd` (`rumah_isi`): pintu ada di 15 rumah, masuk/keluar, interior dibuang, penghuni dalam rumah, dinding padat, tidak ada simpul bocor, draw call kecil.
- Belum diuji di perangkat/APK sungguhan; layar interior terlihat gelap di malam hari (lampu hangat sudah ditambah).

## Jalan, langkah kaki, dan jalan di luar kota

- **Jalan kota lebih rapi.** Jalan batu kini bertepi trotoar batu terang; jalan besar (lebar ≥ 8) punya garis tengah (inlay). Ujung buntu jalan samping (4 titik) diberi lingkaran putar batu bertepi dan medalion tengah, bukan terpotong. Setapak ke tiap rumah kini dihitung dari titik tepat di depan anak tangga pintu sebenarnya, jadi menyatu dengan pintu dan jalan (15/15 pintu tertaut; dicek di `step_bot`).
- **Luar gerbang.** Jalan tanah di luar kota diberi lampu penanda di kedua sisi, papan penunjuk "Wilayah Luar", dan ujungnya melebar (tidak lagi terpotong mendadak).
- **Jalan di stage/wilayah.** Arena rumput (hutan & padang, termasuk wilayah jelajah) mendapat jalan tanah berkelok dari tepi selatan ke lapangan tanah di tengah; hanya hiasan lantai (tanpa tabrakan, tanpa beban tambahan berarti).
- **Cara berjalan: suara langkah.** Sebelumnya pemain berjalan tanpa bunyi langkah. Kini tiap tapak berbunyi sesuai permukaan: batu (jalan/alun-alun/arena batu), rumput (taman/arena rumput), kayu (lantai rumah). Langkah berjarak tetap (±1,1 m) sehingga lari lebih rapat dari jalan, berhenti saat diam/melompat/dash, dan pelan agar tidak menutupi efek pertempuran. Suara dibuat `tools/gen_steps.py` (WAV mono 22 kHz, ±5–7 KB masing-masing); slider Efek Suara berlaku.
- Uji: `tools/step_bot.gd` (`langkah_jalan`).
- Belum diuji di perangkat/APK sungguhan; suara langkah belum didengar manusia (hanya dicek pemicunya).

### Pemandangan arena luar ruang (revisi)
Gunung abu-abu bersalju di sekeliling arena rumput/hutan dihapus (terlihat aneh dari kamera tinggi). Gantinya: bukit hijau rendah di kejauhan, sabuk hutan tinggi rapat di tepi pandangan, dan hutan berlapis ke arah arena (hutan lebih rapat di Hutan Berbisik). Lantai luar tidak lagi dikaburkan ke abu-abu. Jumlah pohon setengahnya di kualitas terendah. Tema gua/kuil/void tidak berubah.

## Lobi tidak lagi gelap kebiruan (bug bayangan)
Dengan bayangan aktif (bawaan), seluruh lobi tampak redup dan kebiruan sekalipun jam 11 siang. Penyebabnya: potongan gunung/pemandangan jauh (tinggi 50–60 m, jarak >150 m) ikut melempar bayangan matahari sehingga kotak bayangan melebar dan menggelapkan semuanya. Kini potongan jauh/tinggi tidak melempar bayangan (`lobby_world._commit`); hanya benda kota yang membuat bayangan, jadi siang cerah, sore punya bayangan panjang yang bagus, dan beban render bayangan ikut turun. Terang siang/sore di `day_night.gd` juga disetel ulang (matahari 0,88–0,92, ambien 0,6) agar tidak pudar.

## Desa Fajar — peta baru di luar kota

Di luar gerbang kota Aurelia kini ada **Desa Fajar**, peta terpisah bergaya desa. Cara ke sana: bicara dengan Penjaga Gerbang → "Pergi ke Desa Fajar", atau tekan papan penunjuk di luar gerbang selatan kota. Layar loading singkat lalu pemain muncul di gerbang utara desa. Untuk kembali: lengkung "Kota Aurelia ↑" atau Penjaga Gerbang Pandu. Lengkung selatan desa menuju padang petualangan; tombol Mulai Petualangan di desa juga berfungsi dan setelah stage pemain kembali ke peta yang sama.

Isi desa: 12 rumah (semua pintu bisa dibuka, ada interior dan penghuni), Balai Desa, Warung Desa (beli/jual), Bengkel Desa (tempa senjata), alun-alun bersumur dengan 3 lapak dan bangku, 3 ladang berpagar dengan orang-orangan sawah, kincir angin berputar pelan, kolam bertepi bangku, jalan tanah berbatu, lampu jalan, hutan di sekeliling. Rumah disusun rapi dalam dua barisan lurus sejajar jalan utama dengan jarak sama dan semua menghadap jalan.

NPC (±20, semua bisa diajak bicara dan punya nama): 4 fungsional (Kepala Desa Pak Wiryo → quest/petualangan, Bu Sekar → toko/jual, Tarno → tempa, Pandu → gerbang), 8 pengembara berjalan (Mbah Kerto, Soleh, Minah, Karyo, Gito, Cahyo si anak, Mbok Inem, Jaka), dan penghuni rumah yang duduk di depan rumah dan ada di dalamnya saat pintu dibuka.

Ringan untuk ponsel:
- Satu peta dimuat pada satu waktu (kota dibuang saat ke desa), tanpa ExploreWorld (peti/teleport) di desa.
- Dunia desa memakai mesin yang sama dengan kota: chunk 32 m digabung, tabrakan tergabung, pohon hutan luar tanpa tabrakan, bayangan jauh dimatikan.
- Jumlah NPC mengikuti kualitas: Lancar 10 / Sedang 15 / Bagus 24; NPC jauh otomatis disembunyikan; NPC fungsional berdiri diam (tanpa pathfinding).
- Terukur di headless: ±40 draw call di desa (kota ±200).

Teknis: `scripts/lobby/village_layout.gd` (data tata letak), `village_world.gd` (VillageWorld extends LobbyWorld), `Flow.lobby_map` / `go_village()` / `go_town()`, `Lobby.map_id`, `NpcDefs.VILLAGE_NPCS / VILLAGE_RESIDENTS`, `Quality.village_npc_budget()`. Tes: `tools/village_bot.gd` (desa_fajar) dan `tools/desa_akses_bot.gd` (desa_akses).

## Bab Desa: Kabut di Fajar
Alur cerita kedua, terpisah dari Kastil (Aurelia). Hanya muncul saat pemain berada di Desa Fajar (Pak Wiryo, papan quest, dan tombol Start Adventure mengikuti peta yang sedang dibuka).
- **Cerita:** panen gagal tiga kali, kabut keluar dari hutan. Penjaga hutan, **Arunika**, dulu dijanjikan Sedekah Bumi oleh warga, lalu janji itu dilupakan dan hutannya ditebang. Kehampaan yang bocor dari segel Aurelia memperparah amarahnya. Bos dikalahkan agar terbebas dari Kehampaan, bukan dibunuh sebagai penjahat.
- **Stage (5):** `v1_1` Ladang Subuh, `v1_2` Kabut di Jalan Setapak, `v1_3` Hutan yang Menunggu, `v1_4` Lumbung yang Dijaga, `v1_boss` Hutan Arunika. Berantai lewat `unlock_after`. Id berawalan `v<angka>_` otomatis dianggap stage desa (`Data.is_village_stage`) dan tidak masuk `stage_order`/`adventure_order` Kastil.
- **Musuh tema desa:** Slime Embun, Gagak, Jamur Layu, Slime Kabut, Jamur Berduri (varian berwarna dari model yang sudah ada, tanpa mesh baru) dan bos Arunika (empat serangan: duri, akar, mekar, lompat).
- **Quest (8, `region = "village"`):** `qv_wiryo` → `qv_ladang` → `qv_kerto` → `qv_kabut` → `qv_jaka` → `qv_hutan` → `qv_lumbung` → `qv_arunika` (hadiah akhir: aksesori Daun Arunika).
- **Cerita di data/story.json:** `v_prolog` (diputar sekali saat pertama masuk desa), intro tiap stage, outro v1_1, v1_3, v1_4, dan v1_boss.
- **Warga hidup:** Pak Wiryo, Mbah Kerto, Jaka, Cahyo, Soleh, Bu Sekar berganti ucapan sesuai kemajuan (`NpcDefs.VILLAGE_STORY`).
- **Tes:** `tools/bab_desa_bot.gd` (keutuhan data) dan `bos_arunika` di `run_all.sh`.

## Simpan otomatis + deteksi kecurangan (tanpa blokir akun)
**Simpan otomatis** (`autoload/game_state.gd`)
- Progres disimpan berkala selama bermain (lobi, stage, wilayah jelajah). Pengaturan → Data → *Simpan otomatis*: AKTIF/MATI dan jeda **30 dtk / 1 mnt (bawaan) / 2 mnt / 5 mnt** (`autosave`, `autosave_idx`).
- Tetap berlaku seperti sebelumnya: simpan terjadwal 1,5 dtk setelah perubahan (`queue_save`), simpan saat game ke latar belakang / kehilangan fokus / ditutup, dan di akhir stage.
- Indikator kecil "Tersimpan otomatis" muncul sebentar di kanan-atas (menghormati area aman notch) hanya bila penyimpanan berhasil. Tidak menyimpan bila belum ada dunia (sebelum menekan Mulai/Lanjutkan) dan tidak menulis di mode uji `--fresh`.
- Memakai jalur simpan aman yang sama (tulis `.tmp` → verifikasi → ganti nama), jadi file lama tetap utuh bila game mati saat menulis.

**Blokir akun dihapus; diganti deteksi saja** (`scripts/systems/cheat_guard.gd`)
- Tidak ada lagi blokir, layar "AKUN DIBLOKIR", maupun penolakan masuk lobi/stage. Temuan hanya **dicatat** (`flags["cheat_log"]`, maks 20, jenis yang sama dalam 1 jam tidak dicatat ulang), memunculkan peringatan singkat sekali per jenis per sesi, dan terlihat di Pengaturan → Data → *Deteksi kecurangan*. Game tetap berjalan normal.
- Jenis temuan: **tamper** (isi save diubah di luar game; tanda tangan HMAC `sig` tidak cocok), **clock_back** (jam diputar mundur lebih dari 10 menit dari waktu tertinggi yang tercatat, memakai waktu unix UTC sehingga ganti zona waktu tidak dihitung), **anomaly** (level/bintang di atas batas, gold/diamond negatif atau tak masuk akal), **other_device** (kode cadangan perangkat lain, ditolak).
- Save lama tanpa `sig` diterima tanpa temuan dan ditandatangani pada simpan berikutnya. Save yang diedit hanya dicatat sekali lalu dianggap sah pada simpan berikutnya (tidak dikembalikan/dihapus).
- Batas jujur: offline dan kunci tertanam di aplikasi, jadi ini menangkap edit biasa, bukan orang yang membongkar aplikasi. Pemain yang memajukan jam (bukan memundurkan) tidak bisa dideteksi tanpa server.
- Diuji headless di Godot 4.3: `tools/save_test` (semua cek LULUS), `tools/title_bot`, `test_data`, `unit_test`, bot Pengaturan/Misi Harian/Panel. Belum diuji di HP asli.


## Musik utama jadi WAV (suara patah/lag di HP)
- `assets/audio/music_main.mp3` diganti `music_main.wav` (PCM 16-bit mono 22,05 kHz, ±9 MB, durasi tetap 3:25). Alasan: dekode MP3 stereo tiap saat membebani CPU HP kelas bawah, ikut berebut dengan render 3D sehingga thread audio telat dan suara efek/lagu patah; WAV tinggal dibaca dari memori (tanpa dekode) dan pengulangannya tepat tanpa lompatan seek MP3. `Sfx._load` sudah memilih .wav lebih dulu, jadi kode lain tidak berubah; `MUSIC_GAIN` music_main 3.0 -> 4.7 dB menyamakan kekerasan (mono lebih pelan ±1,7 dB).
- Harga: APK +±7,5 MB dan ±9 MB RAM saat lagu dimuat; lagu jadi mono.
- Belum terbukti di HP asli (tidak ada perangkat di lingkungan ini).

## Kunci 30 FPS otomatis saat CPU kewalahan (suara patah)
- `autoload/perf.gd`: governor sebelumnya hanya menurunkan resolusi 3D, padahal bila beban ada di CPU (skrip, fisika, node) itu tidak membantu dan thread audio tetap telat. Sekarang bila skala 3D sudah di batas bawah dan rata-rata bingkai tetap > 18,8 ms selama 6 detik beruntun, FPS dikunci 30 (`Perf.capped`, `Engine.max_fps = 30`) agar bingkai stabil dan CPU punya ruang untuk audio. Kunci dilepas saat Pengaturan diubah (reset ke 60 FPS). Tidak berlaku bila Resolusi dinamis dimatikan atau kualitas Klasik.
- Harga: pada HP yang kewalahan game jadi 30 FPS (stabil) alih-alih 25-45 FPS naik-turun.
- Belum terbukti di HP asli.

## Perbaikan tata letak kota: pohon, lampu, jalan, portal (audit otomatis)
- **Alat baru `tools/layout_audit.tscn`** (headless, tanpa layar): membangun kota lalu memeriksa pohon/lampu yang menimpa jalan atau menempel bangunan, bangunan yang menimpa jalan/bangunan lain, pintu yang jauh dari jalan, dan titik interaksi/NPC yang tak terjangkau. Jalankan: `godot --headless --path . res://tools/layout_audit.tscn` (peta ASCII di /tmp/audit_map.txt).
- **Sebelum:** 44 masalah — 25 pohon menempel/di dalam beranda & atap rumah, 8 pohon dan 5 lampu tepat di atas jalan atau jalan setapak rumah, 1 lampu di dalam rumah, toko senjata/toko ramuan/menara 7-10 m dari jalan tanpa jalan setapak.
- **Sesudah:** 0 masalah nyata (sisa 1 temuan guild = artefak ujung jalan bulat pada alat ukur). Jumlah pohon kota 222 -> 191, lampu 44 -> 38 (yang dibuang memang yang salah tempat).
- `lobby_world.gd`: `mesh_rects` (kotak mesh tiap bangunan, termasuk beranda/atap/tangga) + `_near_mesh()`; pohon jalan, pohon taman, dan lampu kini menjauh dari badan bangunan dan dari semua jalan/setapak (`dist_to_roads`); lampu tidak lagi dipasang di persimpangan jalan lain. Jalan setapak kini juga dibuat untuk toko senjata, toko ramuan, dan menara (`DOOR_LOCAL`), bukan hanya rumah warga.
- `lobby_layout.gd`: jalan diperpanjang sampai menyentuh bangunan ujungnya: bulevar timur -> portal (69 -> 71,4), bulevar barat -> tenda (70,5 -> 73,2), lorong altar (39 -> 41,8), lorong kolam (39 -> 40), lorong bengkel (28,5 -> 34,6; dulu bengkel terpisah rumput ±7 m padahal perpustakaan di sisi seberang menyentuh lorongnya).
- Uji: test_data, unit_test, save_test, perf_test lulus; `reach_scan` 54/54 titik desain (peti, teleport, NPC, interaksi) dapat dicapai dari spawn.
- Batas jujur: diuji dengan fisika headless (tanpa render), jadi tampilan akhirnya belum dilihat langsung; tabrakan antar-objek diperiksa dari bentuk tabrakan nyata, tetapi bagian visual yang memang tanpa tabrakan (dedaunan di atas 2,5 m, atap, anak tangga) tetap bisa dilewati/tembus.

## Perbaikan tata letak lobi: rumah berumus, jalan tersambung, portal padat
- **Rumah 15 -> 31, ditempatkan dengan rumus** (`LobbyLayout.buildings()` / `house_rows()` / `houses()`), bukan koordinat tangan. Tiap deret = satu sisi satu ruas jalan: muka rumah = tepi tanah jalan + `FRONT_GAP` (2,5 m); rentang deret = batas landmark/persimpangan + `SPACE`; jumlah rumah = n terbesar dengan jarak rata antar rumah >= `HOUSE_GAP_MIN`; posisi dibagi rata. Rumah kini ada di kedua sisi jalan samping (dulu hanya sisi luar) dan dua ruas jalan utama. Landmark tetap di `LobbyLayout.LANDMARKS`.
- **Jalan:** konstanta jalan (`MAIN_W`, `SIDE_X`, `LORONG_Z`, ...) jadi satu sumber untuk `ROADS` dan rumus rumah. Lorong altar/kolam dulu mulai 2,25 m dari tepi jalan utama (celah rumput); kini tersambung. Setapak rumah dulu bisa melengkung menyamping ke ujung lorong; kini hanya menuju jalan di depan pintu (maks. ~35 derajat). Garis tengah jalan besar terputus di persimpangan (tidak lagi melintang di atas jalan yang menyilang).
- **Portal tembus:** hanya pedestal & pilar yang punya tabrakan, jadi pemain bisa berjalan menembus pusaran. Kini ada lempeng tabrakan 7,2 x 8,4 x 0,5 m di bidang cincin (`b_landmarks.gd`).
- **Penghuni:** `NpcDefs.RESIDENTS` 15 -> 31 (satu per rumah).
- **Audit:** `tools/layout_audit.gd` kini juga memeriksa jumlah rumah/penghuni, rumah menimpa peti/teleport/NPC, jarak antar bangunan < 1 m, dan portal padat (sinar fisika). `tools/layout_dump.gd` mencetak geometri ke JSON untuk digambar sebagai peta atas.
- Hasil: audit 0 masalah baru (sisa artefak guild lama), jarak mesh minimum 1,77 m; test_data, unit, save, perf, rumah_isi, oklusi, eksplorasi, warga_bicara, desa_fajar (`--map=village`), desa_akses, step_bot (setapak 31/31) lulus. Belum dilihat di HP/render GPU sungguhan.

## Gabungan 5 versi (audio_fix + Yumantara + tahap2 + autosave_nobans + Kyomu)
- **Dasar:** versi Yumantara terbaru (Desa Fajar, dukungan/watermark, penguatan jaringan & simpanan) + semua perbaikan audio/tata kota sebelumnya. `autosave_nobans` ternyata subset lama dari Yumantara (tidak ada isi unik).
- **Dari tahap2:** animasi baru (idle bernapas/melirik, `attack_sword3/staff2/smash2/bow2`, `CharacterRig.set_move_speed` agar kaki tidak meluncur). Digabung dengan gaya animasi Kyomu lewat merge 3 arah.
- **Dari Kyomu:** hanya fitur karakter Kyomu yang dicangkok (cabang itu lebih tua: tanpa Desa Fajar dan masih memakai sistem blokir akun, jadi bagian lain tidak diambil): data & aset, tampilan, animasi Vortex, efek, ULT Gerbang Vortex, `Enemy.pull_toward`, kolam gacha ★5. Dua perbaikan agar kompatibel Godot 4.3 (CI): tipe eksplisit pada `left` di `character_looks.gd`.
- **Uji baru:** `tools/kyomu_bot.gd` (serang, skill, ULT Kyomu di stage), `tools/layout_audit.tscn` (tata kota), `tools/cost_probe.gd` (ukur beban skrip), keduanya terdaftar di `run_all.sh` (kecuali cost_probe).
- Hasil: test_data/unit/save/perf lulus, audit kota 0 masalah, reach_scan 54/54, bot Kyomu lulus, foto render lobi & Kyomu diperiksa.

### Karakter ★5 baru: Kyomu (虚) — petarung pedang ganda ungu, tubuh ramping
- **Kyomu** (id `kyomu`, Assassin ★5): pemuda ramping berambut putih-lavender mengembang, mata biru tajam, masker/kerah hitam menutup wajah bagian bawah, anting salib hitam,
  baju hitam tanpa lengan dengan emblem **虚 KYOMU** di dada, lengan telanjang berpembalut hitam, **tato retakan hitam bermata ungu di lengan kiri**, sabuk hitam bergem ungu
  dengan rantai perak + liontin wajik, rok berlapis hitam/ungu/lavender, celana hitam bercorak camo-api ungu, sepatu hitam-putih bergem ungu, dan **dua pedang kristal ungu** (bilah piksel bergerigi, inti hitam).
- **Tubuh ramping:** `CharacterRig.set_slim(s)` (dipanggil dari `CharacterLooks.apply_hero` lewat tabel `SLIM`, Kyomu = 0,84) menyempitkan lebar badan, lengan, dan kaki; kepala & tangan dikembalikan ke ukuran normal supaya wajah dan senjata tidak ikut tipis. Karakter lain tidak terpengaruh.
- **Tempur:** serangan `dagger` (kombo 3 pukulan, penutup 2,1x, kritikal 20%, tembus 35% DEF), skill **Vortex Kehampaan** (`vortex`: memutar tubuh, pusaran bilah ungu, 3 tebasan 360° beruntun + kebal sesaat; animasi `skill_vortex`, gaya rig `dagger_vortex`), ULT **Gerbang Vortex Kehampaan** (`vortex_gate`: 6 portal vortex ~2,4 dtk di bawah musuh terdekat, menyedot musuh ke pusat via `Enemy.pull_toward` dan menebas tipis 8 kali; 1 musuh di 1 portal ≈ 40% total ULT, bertumpuk bila tersedot ke beberapa portal; ditutup ledakan kecil; kode `Stage._ult_vortex_gate`). Efek ungu: bulan sabit ungu/lavender silang, bara & serpihan kristal, api ungu di kedua bilah, aura bayangan ungu di kaki, efek kena khas.
- **Berkas:** `resources/characters/kyomu.tres`, skin `assets/hero/skin_kyomu.png` (`paint_kyomu` di `tools/gen_skins.py`), mata `assets/hero/eyes/eye_kyomu.png` (`tools/gen_eyes_box.py`), emblem `assets/hero/kyomu_emblem.png` (`tools/gen_kyomu_emblem.py`),
  tampilan `CharacterLooks._kyomu/_kyomu_blades`, gaya animasi `kyomu` di `anim_library.gd`, efek di `char_fx.gd`. Terdaftar di `Data.CHAR_ORDER` dan kolam gacha ★5.
- **Celana:** skin bercorak api ungu-lavender dari ujung celana + camo gelap; di model ada celana longgar (volume paha, lipatan lutut, lidah api bertumpuk, tambalan lavender, gem & rantai di lutut kiri, manset lavender di betis).
- **Belum diuji:** Godot tidak ada di lingkungan pembuatan, jadi kode GDScript, tampilan 3D, skala tubuh ramping, posisi emblem/gem/rok, dan efek **belum pernah dijalankan** — kemungkinan perlu penyetelan angka posisi
  setelah dilihat di Godot (`tools/looks_preview.gd --set=kyomu`). Skin dan mata sudah dilihat sebagai gambar 2D saja.

## Gabungan 6 (gabungan_3 + layout_fix)
- Dasar: `gabungan_3` (Kyomu, animasi tahap2). Ditambah semua perbaikan tata letak lobi dari `layout_fix` (rumah 31 berumus, jalan tersambung, portal padat, 31 penghuni, audit/dump baru). Tidak ada file yang bentrok selain `layout_audit.gd` (digabung manual: blok pemeriksaan rumah/portal + ringkasan PASS/FAIL).
- Belum dijalankan di Godot (tidak ada di lingkungan ini).

## Animasi serang & skill khas tiap karakter
- Sebelumnya hanya diam/jalan/lari/siaga yang beda per karakter; serang dan skill memakai gerakan kelas senjata yang sama (Ren = Hakuya = Kuroha = Vael, semua mage memakai ayunan tongkat yang sama).
- Kini `AnimLibrary.ATK` memberi tiap karakter (13) varian serang & skill sendiri, dibuat lazy dari animasi dasar: durasi (lincah/berat), putaran badan, dorongan maju, merunduk, dan pose tangan/kepala/badan khas (mis. Hakuya iai rendah dengan tangan kiri di sarung, Kuroha berat menekan, Vael tegak anggun, Kyomu menari memutar, Brann berat kuda-kuda lebar, Aion lambat terukur, Wenyu meliuk).
- Waktu impak tetap sinkron (fraksi impak sama; `AnimLibrary.impact_time` mengenali nama `anim@id`); `CharacterRig.set_weapon_class/set_style` memasang varian otomatis, jadi pemain, co-op ghost, dan potret ikut.
- Uji: `tools/test_data.gd` memeriksa semua karakter punya gaya dan semua varian terbentuk. Sintaks GDScript diperiksa dengan parser (gdparse), **belum dijalankan di Godot** — angka di tabel `ATK` perlu disetel setelah dilihat di game (cek tembus pedang/badan di `tools/looks_preview.gd`).

## Polish animasi — Tahap 1 (Idle, Walk, Run, Turn)
- **Audit:** `anim_library.gd` (`_p_idle`, `_p_loco` IK kaki, `_p_turn`, gaya per karakter), `character_rig.gd` (blend, laju siklus dari m/s), `player.gd` (gerak, pemicu belok). Idle (napas, lirik, regang, berat badan), Walk/Run (IK kaki anti-meluncur, ayun tangan, pinggul/bahu, condong), dan Turn (kepala-dada-pinggul-kaki menyusul) sudah ada dan tidak diubah.
- **Kekurangan yang ditemukan:** badan berputar kaku mengikuti arah, tanpa condong saat akselerasi/pengereman dan tanpa miring ke tikungan.
- **Perubahan:** `CharacterRig._update_momentum` — node model condong depan saat berakselerasi, ke belakang saat mengerem, dan miring ke dalam tikungan saat bergerak (maks ±0,1 / ±0,13 rad, dihaluskan). Hanya untuk rig yang tahu kecepatannya (pemain, co-op ghost), nol saat diam/serang/skill/dodge/mati. Tidak menyentuh tulang, hitbox, damage, kontrol, atau animasi; tanpa alokasi objek per frame.
- **Belum selesai (tahap berikut):** basic attack & combo, skill/dodge, ULTI, monster/boss, polishing.
- **Pemeriksaan:** sintaks diperiksa dengan parser GDScript (lolos); **belum dijalankan di Godot**. Angka `LEAN_MAX_*` dan pengali (0,006 / 0,03) perlu disetel setelah dicoba di HP.

## Polish animasi — Tahap 2 (Basic Attack & Combo)
- **Audit:** `anim_library.gd` (`_p_sword`, `_p_sword_finisher`, `_p_dagger`, `_p_staff/2`, `_p_smash/2`, `_p_bow`), `character_rig.gd` (`set_weapon_class`, `play_action`, `action_impact`), `player.gd` (`do_attack`, alur combo, `_pending_swing`). Serangan 1-2 semua kelas sudah menggerakkan seluruh badan (antisipasi, putaran pinggang/bahu, perpindahan berat, kaki, kedua tangan, pemulihan ke siaga) dan serangan 2 sudah beda arah.
- **Kekurangan:** penutup (serangan 3) hanya khusus untuk pedang & belati; untuk tongkat, palu Guardian, dan busur serangan 3 mengulang serangan 1 (tidak lebih kuat).
- **Perubahan:** `attack_staff3` (putar-angkat tinggi-hunjam, badan menukik), `attack_smash3` (jongkok dalam, palu setinggi mungkin, ditahan, banting, tekan tanah lebih lama), `attack_bow3` (tembakan kuat: kuda-kuda rendah, tarik penuh & bidik, hentakan balik mundur). Terdaftar di `defs`, `IMPACT` (waktu impak 0,48 / 0,58 / 0,62 dari panjang animasi) dan `CharacterRig.set_weapon_class`; varian per karakter (`ATK`) otomatis ikut. Uji `tools/test_data.gd` diperluas ke animasi baru.
- **Tidak diubah:** `combo_hits`, damage, cooldown, `combo_recovery`, hit detection, kontrol. Saat ini hanya Vael, Zeya, dan Kyomu yang punya kombo 3 pukulan; karakter dengan `combo_hits` 1-2 tidak mencapai serangan 3, jadi penutup baru baru terlihat bila `combo_hits` dinaikkan (keputusan balans, tidak saya ubah).
- **Belum diuji di Godot** (sintaks lolos parser). Posisi tulang/ayunan baru perlu dilihat langsung (tembus badan/senjata, ketepatan waktu impak).

## Polish animasi — Tahap 3 (Skill & Dodge)
- **Audit:** animasi skill dipilih per kelas senjata (`set_weapon_class`), bukan per jenis skill, sehingga Hakuya (`iai`), Kuroha (`dash_cut`), dan Lucien (`volley`) memakai gerakan kelas yang tidak cocok (tebasan putar / hantam tongkat). Dodge hanya satu animasi simetris (kaki mengayun seperti lari di tempat, tangan lurus ke belakang).
- **Skill baru:** `skill_iai` (kuda-kuda rendah, tangan di sarung/gagang, menahan, cabut-tebas kilat, tahan, kibas & sarungkan), `skill_dashcut` (menggulung, lunge panjang badan nyaris mendatar, tebas menembus, meluncur berhenti), `skill_volley` (bidik dua tangan, tiga sentakan beruntun, hentakan penutup). Dipasang lewat `CharacterRig.SKILL_OVERRIDE` + `set_skill_kind(data.skill_kind)` (dipanggil di `player.gd` & `coop_ghost.gd`). Skill lain tidak berubah (cone/nova/shockwave/chrono/vortex/volley busur & dagger_dash sudah cocok dengan animasi kelasnya). Varian per karakter (`ATK`) ikut otomatis.
- **Dodge baru:** 3 fase — dorongan (jongkok, satu kaki menolak), meluncur (badan rendah, satu kaki menjangkau depan, satu terentang belakang, lengan ke belakang), mendarat (lutut meredam, berat ke kaki depan, lengan menyeimbangkan). Panjang 0,5 dtk; gerak dash 0,26 dtk = fase 0–0,52 animasi.
- **Catatan:** ULT masih memutar animasi "skill" milik karakter, jadi ULT Hakuya/Kuroha/Lucien kini ikut memakai animasi baru; animasi ULT khusus ada di Tahap 4.
- **Tidak diubah:** fungsi/cooldown/damage skill & dodge, kebal sesaat dash_cut, hit detection, kontrol, `ult_kind`.
- Sintaks diperiksa dengan parser GDScript (lolos); **belum dijalankan di Godot**.

## Polish animasi — Tahap 4 (ULTI per karakter / ult_kind)
- **Audit:** `Player.do_ult` memutar animasi "skill" biasa untuk semua karakter; hanya efek (`Stage._ult_cast/_ult_charge/_ult_strike/_ult_finale`) yang dibedakan lewat `ult_kind`. Alur waktu: charge FX 0 dtk -> jeda 0,6 dtk -> 7 serangan beruntun (0,18 dtk) -> ledakan penutup (~2,0 dtk); kunci aksi 1,7 dtk, kebal 2,4 dtk.
- **Perubahan:** aksi baru `ult` pada `CharacterRig` (node state "Ult") + `set_ult_kind(data.ult_kind)`; `AnimLibrary.ensure_ult(kind)` membuat animasi `ult_<kind>` (1,7 dtk, lazy) untuk 13 jenis: sword_rain, pillars, inferno, inferno_blue, shadow_dragon, shadow_blades, vortex_gate, symphony, starfall, quake, sigil_gold, sigil (default), chrono. Tiap animasi 5 fase: preparation (pose khas) -> charging (tahan, tubuh/tangan/kepala/senjata mengumpulkan energi) -> execution+impact (pose release tepat ~0,63 dtk, sinkron dengan serangan pertama setelah jeda 0,6 dtk) -> channel (pose bertahan berdenyut a<->b selama serangan beruntun) -> recovery bertahap ke siaga (tidak teleport ke idle).
- **Kamera/hit-stop:** `cam.shake(0.16)` saat pelepasan; shake & hit-stop per serangan dan penutup yang sudah ada tidak diubah.
- **Ikut diperbarui:** `Player.do_ult`, `CoopGhost.play("ult")`, menu Pengaturan > Uji Animasi (tombol "ULTI"), `Player.play_test`.
- **Tidak diubah:** ULTI tetap 1x per karakter per match, `ult_mult/ult_range`, damage, efek ULTI, kunci aksi/kebal, kontrol.
- Uji: `tools/test_data.gd` memeriksa tiap karakter punya animasi ULTI (panjang 1,7 dtk, impak < panjang). Sintaks lolos parser GDScript; **belum dijalankan di Godot** — pose (terutama tembus senjata/badan) perlu dilihat langsung.

## Sistem Mana (anti-spam skill)
- Tiap karakter punya mana (`CharacterData`: `max_mana` 100, `skill_mana_cost` 30, `mana_regen` 3/dtk, `mana_per_attack` 3). Skill butuh mana cukup selain cooldown; bila kurang: skill ditolak, teks "Mana kurang!", bar MP berkedip, tombol Skill meredup.
- Mana pulih pelan (3/dtk) dan diisi serangan biasa (+3, penutup kombo +4,8), jadi bertarung aktif mengisi mana, sedangkan menekan skill terus-menerus tidak bisa. Dari penuh: 3 skill beruntun, lalu harus menyerang/menunggu.
- Mana tersimpan per karakter saat ganti party (`party_state["mana"]`), jadi tidak bisa mengisi ulang dengan berganti karakter; revive wilayah jelajah mengisi 50%.
- ULTI tidak memakai mana (tetap 1x per match). Lobi tidak memakai mana (`Player.use_mana` hanya aktif di stage). Bar MP ada di HUD stage tepat di bawah HP.
- Semua angka bisa disetel per karakter di file `.tres` (mis. mage `skill_mana_cost` lebih besar). Belum dijalankan di Godot; sintaks lolos parser kecuali `touch_controls.gd` yang memang tak bisa diurai parser (gagal juga pada file asli), jadi dua edit kecilnya belum terperiksa mesin.

## Polish animasi — Tahap 5 (Monster, Humanoid Enemy, Boss)
- **Audit:** `enemy.gd`, `humanoid_enemy.gd`. Slime/Kelelawar/Jamur sudah punya animasi per fase (kejar, aba-aba, serang, pulih, tersentak, mati) dan boss GLB (Penguasa Gua, Dewa Wither) memakai klip bawaan modelnya (hit/roar/death) — tidak diubah. Kekurangan: (1) musuh humanoid hanya berdiri berkedip merah selama aba-aba panjang, tanpa kuda-kuda, tanpa gerak terengah setelah menyeruduk, dan fase 2 bos hanya memutar animasi skill; (2) Golem Kristal hanya menggerakkan lengan (badan tidak ikut aba-aba/serang/pulih/terpukul, fase 2 tanpa gerak, mati cuma gepeng).
- **Humanoid/boss:** tiga kuda-kuda persiapan baru (`enemy_wind_sword` menarik pedang & merunduk, `enemy_wind_staff` tongkat diangkat & menengadah, `enemy_wind_heavy` khusus bos: senjata tinggi dua tangan, kuda-kuda lebar), `enemy_winded` (terengah setelah charge/leap = celah membalas), `enemy_roar` (raungan fase 2 + aura bos lebih terang). Dimainkan lewat `CharacterRig.play_pose` (node state "Wind") hanya bila aba-aba cukup panjang (>0,3 dtk sebelum impak), lalu animasi serang biasa mengambil alih tepat saat sebelum impak seperti sebelumnya, jadi waktu hantam/damage tak berubah. Langkah Ksatria Rantai/Raja Rantai dibuat lebih berat (laju siklus x0,93 / x0,85).
- **Golem:** `_animate_golem` — jalan menghentak (miring bergantian, lengan mengayun), aba-aba badan mundur & terangkat sambil gemetar, serangan badan menghantam maju (slam) / melebar (wave), pulih bahu merosot terengah, tersentak ringan saat terpukul, terhuyung saat stagger, raungan fase 2 (mendongak, lengan terangkat) dan langkah 25% lebih cepat di fase 2, mati runtuh (terhuyung, amblas melebar, lenyap).
- **Tidak diubah:** AI, hitbox, damage, telegraf, cooldown, statistik, urutan state, mode co-op (klien tidak memutar pose baru; tetap memakai animasi sebelumnya).
- Sintaks diperiksa parser GDScript (lolos); **belum dijalankan di Godot**. Perlu dilihat langsung: pose bos tidak menembus senjata, gerak Golem tidak "mencuat" dari bentuknya.

## Polish animasi — Tahap 6 (polishing, optimasi, pengujian akhir)
**Pemeriksaan yang dilakukan (semua statis, Godot tidak tersedia di lingkungan pembuatan):**
- Parser GDScript (gdtoolkit) pada semua 100+ file `.gd`: hasil sama dengan versi dasar `gabungan_3` — hanya `scripts/ui/touch_controls.gd` yang tidak bisa diurai parser (gagal juga pada file asli; diduga keterbatasan parser pada lambda satu baris, bukan bug), sehingga dua edit kecil saya di file itu (`set_dim`, redup tombol) hanya diperiksa dengan membaca.
- Semua kunci tulang pada pose baru dicocokkan dengan kunci valid `_pz/_p_idle` (tidak ada yang salah ketik); semua identifier yang saya tambahkan dicocokkan dengan deklarasi/bawaan Godot.
- Dua temuan yang diperbaiki: variabel `tr` menimpa fungsi global `tr()` (diganti `trem`, termasuk satu pemakaian yang tertinggal), dan `AnimLibrary._defs()` membangun ulang ±70 lambda tiap panggilan (termasuk tiap serangan lewat `impact_time`) -> kini di-cache.
- **Belum teruji:** tidak ada yang dijalankan di Godot. `tools/test_data.gd` sudah diperluas (gaya serang 13 karakter, varian serang/skill/dodge, animasi ULTI, mana, pose musuh) tetapi belum pernah dijalankan; jalankan `tools/run_all.sh` / buka proyek di Godot untuk melihat error sebenarnya.

**Optimasi:** varian animasi (serang, ULTI) dibuat lazy sekali per karakter; momentum badan tanpa alokasi per frame dan nol saat diam/aksi; cache `_defs`; partikel/efek tidak ditambah (hanya `cam.shake` sekali per ULTI).

**Daftar uji manual (di HP/Godot), urut dari yang paling mungkin bermasalah:**
1. Buka proyek: cek panel Output Godot untuk error (nama tulang, tipe, node "Wind"/"Ult" pada state machine).
2. Pengaturan > Uji Animasi: putar Serang 1/2, Skill, ULTI, Hindar tiap karakter; cari pedang/senjata menembus badan (paling rawan: Kuroha, Zeya, Kyomu, Brann, Hakuya iai/ULTI).
3. Satu stage: kombo 3 pukulan (Vael/Zeya/Kyomu) — waktu damage sinkron dengan ayunan; skill & ULTI tidak menghambat kontrol setelah 1,7 dtk.
4. Mana: skill ditolak saat mana kurang (teks "Mana kurang!", bar MP berkedip), pulih lewat menyerang; ganti party tidak mengisi ulang.
5. Musuh humanoid: kuda-kuda persiapan lalu ayunan tepat saat telegraf selesai; Raja Rantai charge -> terengah; fase 2 raungan.
6. Golem: gerak, fase 2, mati runtuh. Co-op: klien tidak melihat pose baru (diketahui).
7. FPS di HP kentang/menengah (Lancar): bandingkan dengan versi sebelum Tahap 1.
8. Lobi: tata letak 31 rumah/jalan dari `layout_fix` (jalankan `tools/layout_audit.gd`).

**Ringkasan Tahap 1-6:** T1 momentum badan (condong/miring); T2 penutup kombo tongkat/palu/busur; T3 skill khusus (iai, dash_cut, volley) + dodge 3 fase; T4 ULTI 13 jenis; T5 pose musuh/boss humanoid + Golem; T6 pemeriksaan & perbaikan. Ditambah di luar tahap: gaya serang/skill khas per karakter (`ATK`) dan sistem Mana.


## Perbaikan pose: anti-tembus senjata + gerak tidak kaku
**Alat ukur** — `tools/clip_probe.tscn` (jalankan dengan layar/xvfb: `xvfb-run godot --rendering-driver opengl3 res://tools/clip_probe.tscn`; `CLIP_IDS=ren,vael` untuk memilih karakter). Tiap animasi tiap karakter dimainkan pada skeleton asli, lalu semua vertex mesh senjata diuji terhadap elipsoid badan dan kepala (diukur dari `hero.glb`). Hasil: berapa meter senjata masuk ke badan/kepala dan pada detik berapa.
- Sebelum: 57 dari 182 kombinasi karakter×animasi menembus > 3 cm (terparah dodge semua karakter, serangan staf, serangan ke-3 Vael, bilah Kyomu).
- Sesudah: 6 dari 195. Sisanya: seruling Wenyu (sengaja menempel di bibir saat idle/lari, ±4 cm) dan animasi `death` Kyomu (jatuh).

**Anti-tembus (`AnimLibrary.fit`)** — dijalankan sekali per karakter di `CharacterRig.set_style` / `set_weapon_class` / `_apply_ult_anim`. Tiap frame dicek lewat FK ringan; bila senjata menembus, bahu (buka ke samping / angkat) dan pergelangan digeser seperlunya, lalu koreksi dihaluskan antar-frame. Animasi yang sudah bersih tidak disentuh. Hasil: varian `@id` diganti di tempat; animasi bersama (dodge, hurt, ult_*) dibuat salinan bernama `<nama>#<id>`. Panjang animasi dan waktu impak tidak berubah (`impact_time` mengenali `#`). Titik senjata ada di `AnimLibrary.FIT_WEAPONS` (diambil dari mesh senjata asli; bila bentuk senjata di `character_looks.gd` diubah, buat ulang dari `clip_probe` baris `GEN`). Biaya: 50–250 ms per karakter di PC, sekali saja.

**Tidak kaku (`AnimLibrary._overlap`)** — follow-through: lengan bawah, pergelangan, kepala, dan dada tertinggal 1–2 frame dari gerakan pangkalnya (tabel `OVERLAP`), jadi pose tidak lagi patah dari kunci ke kunci. Bahu, pinggul, dan kaki tidak diubah, jadi momen impak dan langkah tetap. Tidak dipakai untuk animasi musuh dan `death`/`victory`.

**Pengujian** (Godot 4.3 headless/xvfb, sungguhan): `clip_probe` (angka di atas), `test_data`, `unit_test`, `save_test`, dan bot `pose`, `ult`, `fx_dir` (arah tebasan), `charfx`, `serang`, `kyomu`, `stage_bot`, bot wilayah, dsb. — semua lulus. Satu-satunya gagal: `combat_bot` "jeda antar-serangan >= cooldown" untuk Sera (0.417 < 0.50); gagal juga pada paket asli `gabungan_3` (Brann ikut gagal di sana, sekarang lulus), jadi bukan akibat perubahan ini.

## Pose gaya (diam & siaga) — terinspirasi render referensi
Pose idle/siaga dulu seragam: senjata dipegang tegak di depan badan. Sekarang tiap karakter punya sikap sendiri di `AnimLibrary.POSES`:
- **Sikap badan** (`att`): pinggul miring dengan bahu menyeimbangkan (contrapposto), badan diputar 3/4, kepala miring dan dagu naik/turun, pinggul bergeser. Berlaku untuk ke-13 karakter.
- **Pegangan senjata** (`idle` / `ready`) untuk Ren (pedang dijuntai rendah, tangan kiri di pinggang), Vael (pedang besar bertumpu ujungnya di depan), Hakuya (katana menjuntai), Kuroha (pedang diseret di belakang, badan condong), Kyomu (satu bilah di belakang bahu, satu rendah), Zeya (bilah rendah, merunduk), dan Lyra (tangan kiri terbuka merapal).
- Arah bilah = sumbu +Z tangan; `hand_x` positif memutar bilah ke bawah. Mengubah/menambah gaya cukup mengedit tabel `POSES`.
- Hanya pose diam/siaga yang diubah; serangan, skill, ULT, damage, cooldown, dan kontrol tidak disentuh. Anti-tembus (`fit`) tetap berlaku di atasnya: `clip_probe` tetap 6 dari 195 (seruling Wenyu dan death Kyomu).
- Untuk melihat hasilnya: `tools/pose_bot.gd` (env `POSE_IDS`, `POSE_YAW`, `POSE_DIST`, `POSE_PITCH` mengatur kamera).

## Serangan: badan tidak ikut terdorong (revisi)
Senjata tipis (pedang, katana, dagger, tongkat, busur) tidak butuh dorongan badan, jadi `AnimLibrary._damp_body` meredam gerak badan pada semua animasi `attack_*` dan `skill_*` (termasuk varian per karakter): condong ke depan/belakang (x) ×0,3, miring (z) ×0,5, putaran (y) ×0,6 untuk pinggul/tulang belakang/dada, dan perpindahan pinggul ×0,3 (kiri-kanan, depan-belakang) / ×0,5 (naik-turun). Lengan, pedang, dan kaki tidak diubah, jadi yang bergerak tebasan tangan, bukan seluruh badan. Hanya palu berat (`smash`) dapat sedikit bobot (`_polish_attack`, skala 0,25), dan pose penutup palu Brann (`_p_smash3`) dikurangi dari membungkuk hampir mendatar (spine 1,2 rad) menjadi ±0,8 rad. Panjang animasi dan momen impak tidak berubah, jadi damage/cooldown/hit detection tetap.
- Lihat hasilnya per frame: `tools/strip_bot.gd` (env `STRIP_ID`, `STRIP_ANIMS=Attack1,Skill`, `STRIP_FR`, `POSE_YAW/DIST/PITCH`) memasang tiap frame langsung ke skeleton lalu memotret.

## Aksi diam acak (fidget)
Saat karakter berdiri diam 5–10 detik, ia memainkan satu aksi kecil secara acak lalu kembali ke pose diam (tidak sama dua kali berturut-turut). Tiap karakter punya 4 aksi sesuai kepribadian/senjatanya (`AnimLibrary.FIDGETS`): melihat sekeliling (`look`), meregang (`stretch`), memutar senjata (`twirl`), memeriksa senjata (`inspect`), merapikan rambut/kacamata (`hair`), mengetuk tongkat (`tap`), menyundul perisai (`shield`, Brann), melompat-lompat kecil (`bounce`), bergoyang (`sway`), dan menghela napas (`sigh`). Pose awal/akhir = pose diam karakter itu (`POSES`), jadi sambungannya mulus; animasi dibuat lazy (`AnimLibrary.fidgets(id)`) dan ikut anti-tembus (`fit`).
- Pemicu ada di `CharacterRig._fidget_tick` (state "Wind" yang sama dengan pose musuh). Bergerak atau menyerang langsung memutus aksi. Tidak jalan saat siaga pasca-serang, mati, atau kecepatan dunia tidak diketahui (hantu co-op, NPC). `CharacterRig.fidget_enabled = false` mematikannya.
- Uji: `tools/fidget_bot.gd` (lobi): berdiri 26 dtk → minimal 2 aksi, tidak berulang berturut-turut, bergerak memutus aksi, serangan memutus aksi, kembali ke Move. Lihat per frame: `tools/strip_bot.gd` dengan `STRIP_ANIMS=fid_twirl@ren`.

### Catatan pembaruan (fidget & jalan)
- Kyomu memakai aksi diam `look/sway/sigh/bounce` (putar bilah ganda menembus kepala/badan di film-strip, jadi dibuang).
- Jalan/lari: kemiringan kepala dan dagu khas tiap karakter (`POSES[id].att`) ikut terbawa (×0,6 jalan, ×0,35 lari); kaki dan pinggul tidak disentuh.
- Aksi diam "hair" (tangan ke samping kepala) dan "stretch" (dua lengan terangkat ke atas) dirapikan; dilihat di film-strip dari depan untuk Lyra dan Sera.

### Performa di HP: animasi di-"bake" (anti-lag saat karakter muncul)
- Penyebab lag yang saya temukan dari sisi kode saya: pencarian anti-tembus (`AnimLibrary.fit`), varian serang, ulti, dan fidget dihitung saat runtime. Di desktop ±70–220 ms per karakter (total ±0,9 dtk untuk 13 karakter), di HP bisa beberapa kali lipat, dan fidget pertama juga menyebabkan patah saat berdiri.
- Sekarang semuanya dihitung sekali dan disimpan di `resources/anim_baked.res` (±1,2 MB). `AnimLibrary.get_library()` memuatnya; fit saat runtime jadi 0 ms (diukur). Bila file tidak ada game tetap jalan seperti dulu (hanya lebih lambat).
- **Wajib di-bake ulang** setiap mengubah pose/senjata/gaya di `anim_library.gd`: `godot --headless --path . res://tools/bake_anims.tscn`. Workflow GitHub (`buildapk.yml`) melakukannya otomatis sebelum ekspor.
- Belum dapat diukur di perangkat Android sungguhan dari lingkungan ini; angka HP di atas hanya perkiraan.

### Anti-patah saat memukul/skill: pemanasan efek (`Stage._prewarm_fx`)
- Keluhan: jalan lancar tapi saat memukul/skill patah-patah (di Godot PC lancar). Dugaan utama: di renderer GL Compatibility (Android) tiap bahan/shader partikel dan huruf `Label3D` dikompilasi saat PERTAMA digambar, sehingga pukulan/skill pertama tiap jenis macet.
- Perbaikan: saat stage dibuka, efek tiap anggota party (percikan kena, tebasan, skill, proyektil, ulti umum, angka damage, cincin, telegraf) dimunculkan sekali di balik layar gelap ±0,3–0,9 dtk (3 bingkai) lalu disembunyikan dan dibuang sendiri. Visual saja, tanpa damage/suara.
- Dilewati saat bot uji (`--bot`), kecuali `--prewarm=1`.
- Belum diukur di HP; efek ulti khusus (naga, hujan pedang, dst.) belum ikut dipanaskan. Bila ulti masih patah, lapor.

### Patah-patah saat memukul di SEMUA device: penyebab = hit-stop (diperbaiki)
- Dari rekaman layar pengguna (23,6 dtk, 30 FPS): selain satu celah 331 ms saat layar berputar di awal, celah lain 62–80 ms muncul tiap beberapa pukulan. Itu sama dengan lama hit-stop (`Stage._hit_stop`: 0,03–0,12 dtk, waktu game diperlambat ke 6%). Karena bukan beban GPU/CPU, terjadi di semua perangkat.
- Perbaikan: hit-stop sekarang MATI secara bawaan. Kunci setelan diganti `hit_stop2` (default false) supaya setelan lama "hit_stop = true" di save pemain tidak ikut. Bisa dinyalakan lagi di Pengaturan → Hit-stop.
- Pemanasan efek (bagian sebelumnya) tetap ada untuk kompilasi shader pertama kali.

### Animasi serangan: lengan lebih hidup (pedang tipis)
- Audit `tools/arm_audit.tscn` (jangkauan rotasi bahu/siku/tangan per karakter & animasi). Temuan: setelah badan diredam, serangan 1-2 Ren/Vael/Kuroha/Hakuya hanya menggerakkan lengan 35-50° dan siku 2-3°, tangan kiri nyaris diam.
- `AnimLibrary._damp_body` sekarang memindahkan putaran badan yang dibuang ke bahu (`ARM_TAKEOVER` 0,75), menguatkan ayunan bahu (`ARM_AMP` 1,25) dan siku (`ARM_AMP_ELBOW` 1,6), serta memberi jentikan pergelangan di momen impak. Contoh: serangan 2 Ren 45°→76°, tangan 25°→39°. Waktu impak, damage, cooldown tidak berubah. Anti-tembus tetap dijalankan sesudahnya (clip_probe tetap 10/247). Animasi di-bake ulang.

### Sinematik cerita (tokoh utama: Ren)
- `scripts/ui/cinematic_player.gd` + `data/cinematics.json`: panggung 3D kecil (SubViewport setengah resolusi, dunia sendiri), kamera bergerak, aktor memakai model & animasi karakter yang sama dengan game (Ren, Lyra, Brann; Master Orwen memakai model Aion), efek (tanda bintang menyala, pilar cahaya, rantai putus, mata raksasa, kedip lampu, guncangan), kartu judul, bar sinematik, subtitle film. Ketuk = lanjut, otomatis maju bila dibiarkan, "Lewati" menutup.
- Enam sinematik yang berpusat pada Ren, satu untuk tiap bab 1-5 (+prolog): `prolog` (Anak Bintang), `s1_boss_outro` (Bisikan di Serpihan), `s2_boss_outro` (Prasasti di Dinding), `s3_boss_outro` (Kunci Segel), `s4_boss_outro` (Rantai di Balik Kerudung), `s5_boss_outro` (Menjaga Bukan Mengurung). Adegan lain (pembuka stage, bab Desa Fajar) tetap kotak dialog.
- Terhubung lewat `StoryPlayer.play`: adegan di `data/story.json` yang punya kunci `"cine"` memutar sinematik; menu Cerita "Baca ulang" juga memakainya. Bila data sinematik tidak ada, kotak dialog (baris cadangan di story.json) dipakai.
- Uji: `tools/cine_shots.tscn` (env CINE_OUT, CINE_IDS, CINE_VIA_STORY=1).
- Belum diukur di HP; sinematik hanya berjalan beberapa menit sekali (saat adegan cerita dibuka).

### Diam tidak lagi menggoyang seluruh badan
- Keluhan: saat karakter berdiri diam, seluruh badan bergoyang kiri-kanan. Diukur dengan `tools/sway_audit.tscn`: putaran miring pinggul pada idle/siaga 9–20° dan tulang belakang 4–11° per siklus.
- Penyebab: gerak "berat badan" di `_p_idle` (suku `ws`) ditambah ayunan gaya `STYLES[id].sway` di `_p_idle_s`, plus fidget "sway".
- Perbaikan: suku goyang samping pada pinggul/tulang belakang/dada/kepala dikecilkan, `IDLE_SWAY = 0.2`, fidget "sway" diganti "tap". Hasil ukur: pinggul 2–4°, tulang belakang 0–2° pada idle/siaga; napas dan gerak kepala tetap. Animasi di-bake ulang.

## Petualangan nyambung dengan cerita (Ren)
- Setiap langkah Petualangan kini punya adegan: stage cerita dan **Wilayah Jelajah** (`f_plains`, `f_forest`, `f_cave`), masing-masing intro + outro di `data/story.json`. Wilayah jelajah memutar intro saat masuk (sebelumnya dilewati) dan outro setelah menang; tiap adegan hanya sekali.
- Alurnya: 1-1 Padang di Luar Gerbang → **Padang Angin** (jejak lendir bertemu ke hutan) → 1-2 → 1-3 → … → **Hutan di Atas Sarang** (akar menembus urat kristal) → **Gua Urat Kristal** (nyanyian kristal mengenali tanda Ren) → bos Bab 2. Benang Ren (tanda hangat, panggilan dari sarang, "kau tidak sendirian") dilanjutkan.
- Intro 1-1 ditulis ulang (dulu bicara soal gua padahal stage-nya padang). Nama wilayah jelajah diganti agar tidak kembar dengan stage cerita (`Hutan Berbisik`/`Gua Kristal` milik 1-2/1-3). Panel Cerita memberi label "Wilayah Jelajah".
- Diuji (di mesin ini, bukan di HP): test_data, unit_test, adventure_flow_bot, story_stage_bot untuk f_plains/f_forest/f_cave (intro jeda → stage jalan → outro → hasil) semua lulus. `story_bot` gagal di "prolog otomatis" karena prolog sekarang sinematik (bot belum diperbarui; sudah begitu sebelum perubahan ini).

## Lengan & tangan hidup saat diam (audit semua klip)
- `tools/anim_all_audit.gd` (`godot --headless --path . --script tools/anim_all_audit.gd`) mengukur jangkauan gerak lengan/tangan/kaki/tulang belakang SEMUA klip dan menandai yang lengannya nyaris beku. Klip serangan/skill/ulti semua sudah bergerak (arm_audit: 0 lengan diam dari 65).
- Temuan: idle/ready hampir semua lengan beku (0–5°; tangan pemegang senjata dikunci pose "hold"), dan fidget look/sigh/bounce lengannya tidak bergerak.
- Perbaikan: lengan idle/ready ikut napas & bobot (~8–20°), tangan pemegang senjata kini ikut napas lewat `_hold_breath` (Wenyu dikurangi agar seruling tidak makin dekat kepala); fidget look (lengan menyeimbangkan), sigh (lengan naik lalu jatuh lemas), bounce (lengan memantul). Gerak badan/pinggul saat diam tidak ditambah (sway_audit tetap rendah).
- `resources/anim_baked.res` sudah di-bake ulang. Cek tembus (clip_probe): kumpulan klip bermasalah sama seperti sebelumnya (hanya seruling Wenyu dekat kepala, sudah begitu di versi 26), tidak ada klip baru yang tembus.
- Belum diperiksa secara visual (render) untuk idle/fidget, hanya lewat angka; belum diuji di HP.

### Tambahan (gabungan 28)
- **Jalan kaki:** tangan pemegang senjata dulu nyaris beku (±3°) saat walk/run; kini mengayun (satu tangan ~9–12°, dua tangan ~7°) dengan siku & pergelangan menyusul langkah (`_p_loco_s`). Cek tembus: tidak ada klip baru bermasalah.
- `story_bot` kini dijalankan dengan `--nocine=1` (memaksa dialog biasa, karena prolog sekarang sinematik); `run_all.sh` sudah diperbarui. `strip_bot` bisa memotret klip `nama@id` (mis. `walk@ren`, `idle@lyra`).
- Dicek visual: strip walk@ren dan idle@lyra (lengan bergerak wajar, tidak tembus). Belum diuji di HP.

### Jalan di sinematik (gabungan 29)
- Dulu aktor sinematik memakai `set_move(0.45/1.0)` tanpa tahu kecepatan sebenarnya, jadi kaki berayun tidak sesuai jarak (meluncur; mis. "lari" hanya 1,6 m/s). Kini aktor dengan `to`+`dur` memakai `set_move_speed(mps/5.8, mps)` sehingga blend jalan/lari & laju siklus mengikuti jarak÷durasi seperti pemain.
- Data prolog disesuaikan: Orwen jalan ±2,1 m/s, Lyra/Brann berlari ±3,5 m/s. Diuji: sinematik prolog diputar penuh tanpa error (13 tangkapan). Belum diuji di HP.

## Resolusi 3D bertingkat + latar sinematik baru (gabungan 30)
- **Pengaturan → Resolusi 3D:** Auto / 50% / 60% / 70% / 80% / 90% / 100% (`res_scale`). Manual menimpa preset; resolusi dinamis tetap boleh menurunkan tapi tidak melewati 50%. UI/HUD tetap tajam (hanya dunia 3D yang diskalakan).
- **Anti-aliasing:** Auto / Mati / 2x / 4x (`aa`). Anisotropic filtering 4x (project setting) dan debanding (kualitas ≥ Sedang) untuk tanah/langit lebih bersih.
- Tes: `perf_test` ditambah cek 50–100%, batas governor, dan AA (0 gagal).
- **Sinematik:** latar dibangun ulang tanpa aset luar: tekstur batu dibuat lewat kode (triplanar), langit gradasi + bulan + gunung, tanah luas tanpa tepi. Plaza Aurelia: rumah beratap pelana berjendela hangat, pintu, cerobong, pohon, menara jam. Gua: dinding batu melingkar, langit-langit, stalaktit, gugus kristal. Altar: undakan, cincin rune bercahaya, pilar bertapak, lengkung runtuh. Aula Menara: dinding bata, jendela merah, pilar, singgasana, spanduk. Bintang kini bulat (bukan kotak); jendela tidak silau putih.
- Catatan: scene lebih banyak objek (plaza ±300 mesh) — dirender di setengah resolusi; belum diukur FPS di HP.

### Rumah sinematik = rumah fantasi lobi (gabungan 31)
Plaza prolog kini memakai kelas `Building` yang sama dengan kota lobi (pondok, rumah kayu dua lantai berbingkai kayu, rumah menara, rumah sayap silang) dengan warna atap/dinding bervariasi, plus Balai Serikat Bintang Fajar dan menara di belakang air mancur — bukan lagi kotak+prisma buatan sendiri. Lebih sedikit draw call (tiap bangunan satu mesh gabungan). `_house()` lama tidak dipakai lagi.

## Cerita Bab 5 diubah: raja tak terkalahkan (gabungan 32)
- **Raja Rantai Merah tidak dikalahkan Ren.** Intro bos menekankan kekuatannya (ada sebelum Wither lahir). Outro (sinematik "Kunci yang Belum Matang"): Ren hanya menggores zirahnya dan memaksanya melangkah; satu ayunan pedang menghempaskan party; sang raja menahan diri ("pulanglah, tumbuhlah"); tanda Ren menarik mereka keluar. Ren menutup prolog: kalah tapi hidup. Mekanik stage tidak diubah (stage tetap "selesai").
- **Sinematik:** aktor raja raksasa dibuat lewat kode (`_spawn_king`, fx `king`, `king_strike`: ayunan pedang → guncangan, kilatan, party `hurt`), akting Lyra/Ren/Brann memakai hurt/death/fidget, kamera dipecah jadi 7 shot. Prolog: Ren menghela napas/bertekad (`attack1`) di shot tertentu.
- **Desa penghubung:** `v_prolog` kini menyebut Desa Fajar sebagai persimpangan jalan ke kastil (selatan), kuil (utara), menara (timur). Adegan baru `v_hub` "Persimpangan Fajar" diputar sekali di lobi setelah `s5_boss` selesai (Ren, Lyra, Brann terbangun di Desa Fajar). Ini teks cerita saja; belum ada peta kastil baru.
- Diuji: test_data, unit_test, story_bot (--nocine=1), story_stage_bot s5_boss, render sinematik s5 (10 tangkapan). Belum diuji di HP.

## Prolog & alur cerita disambungkan ke peta gameplay (gabungan 33)
- **Prolog ditulis ulang**, tidak ada lagi "dipanggil begitu saja": Ren adalah pesuruh magang Serikat Bintang Fajar (bangunan yang terlihat di alun-alun) yang jaga malam; kristal berkedip tiga malam, tandanya hangat tiap kedipan (reaksi, bukan panggilan). Orwen membawa laporan: tiga rombongan penambang tidak pulang dari Gua Kristal di luar gerbang. Lyra membawa sampel lendir dari perpustakaan, Brann (anak bekas penambang) jadi penunjuk jalan. Ren *memilih* ikut (kontrak serikat, boleh menolak). Orwen mengarahkan: toko & bengkel → **Portal Petualangan di sisi timur alun-alun** → Padang Gerbang → Hutan Berbisik → Gua Kristal. Toast "Misi pertama: …" muncul sekali setelah prolog di kota.
- **Peta Aurelia ↔ Desa Fajar:** Desa Fajar = pos di luar gerbang kota, di pertemuan jalan raya (kembali ke kota & kastil, ke kuil di kaki pegunungan, ke hutan tua). Setelah `s5_boss` selesai: di kota diputar `a_return` ("Pulang ke Aurelia": pulih di ruang rawat serikat, Orwen menyuruh menempa senjata & mendatangi Desa Fajar); di peta desa diputar `v_hub` ("Persimpangan Fajar"). Masing-masing sekali (`tools/hub_bot.gd`, masuk `run_all.sh`).
- Judul adegan `s2_1_intro` diselaraskan dengan nama stage (Lorong Bayangan).
- Diuji: test_data, unit_test, story_bot, hub_bot (kota & desa, sekali putar), render sinematik prolog (16 tangkapan). Belum diuji di HP.
- Belum dilakukan: Bab 3 hanya punya stage bos (struktur stage tidak diubah); adegan pembuka Bab 2/4 & sinematik Desa Fajar.

## Putaran optimasi ringan (gabungan 33 → 33-opt)
Semua perubahan kecil dan berisiko rendah; **belum diuji di Godot/HP** (tidak ada Godot di lingkungan pengubah). Mohon jalankan `tools/test_data`, `unit_test`, `perf_test` dan coba main sebentar.
- **Musik dimuat saat dibutuhkan** (`autoload/sfx.gd`, `_ensure_sound`): saat start hanya efek suara pendek yang dimuat; 9 lagu (±13 MB PCM) tidak lagi dimuat semua di awal. Lagu cadangan (`FALLBACK`) tetap bekerja.
- **`music_main` diubah WAV → OGG Vorbis** (`assets/audio/music_main.ogg`, mono 22,05 kHz, q4): 9,0 MB → 1,0 MB (APK lebih kecil, RAM ±8 MB lebih hemat). Loop diatur lewat kode (`AudioStreamOggVorbis.loop`). Lagu chiptune pendek tetap WAV agar loop-nya mulus.
- **Musuh**: parameter shader kilatan (`flash_amount`/`flash_color`) dan warna overlay hanya dikirim ke renderer bila nilainya berubah (dulu 2–3 panggilan per musuh per bingkai fisika). Tampilan sama.
- **Kontrol sentuh**: gambar ulang tiap bingkai hanya saat joystick dipakai / tombol ditekan / cooldown / tombol interaksi berdenyut; saat diam ~8×/detik.
- **Project**: `rendering/mesh_lod/lod_change/threshold_pixels=2.0` (LOD model GLB berpindah sedikit lebih awal; hemat segitiga). Export: `*.sh` dan `*.py` tidak ikut APK.

## Aplikasi Android lengkap (ikon, getar, AAB Play Store)
Belum diuji di Godot/HP (tidak ada Godot di lingkungan pengubah); ekspor pertama sebaiknya dicoba lewat GitHub Actions atau editor.
- **Ikon aplikasi sendiri**: `assets/app_icon/` (ikon 192 px + adaptive foreground/background 432 px, dirender dari `icon.svg`; permata di zona aman adaptive). Sudah dipasang di `export_presets.cfg` (`launcher_icons/*`), jadi APK tidak lagi memakai ikon bawaan Godot.
- **Izin getar**: `permissions/vibrate=true`. Sebelumnya game memanggil `Input.vibrate_handheld` (tombol sentuh & stage) tetapi izin `VIBRATE` belum diminta, sehingga getar tidak pernah jalan di HP.
- **Preset kedua "Android AAB (Play Store)"** (`build/fantasy_life_rpg.aab`): format AAB untuk diunggah ke Google Play. Butuh build gradle: sekali saja di editor pilih *Project → Install Android Build Template*, lalu *Project → Export → Android AAB (Play Store)*. Wajib ditandatangani keystore RILIS milikmu sendiri (isi `keystore/release*` atau variabel `GODOT_ANDROID_KEYSTORE_RELEASE_*`); simpan keystore itu baik-baik, sebab update berikutnya harus memakai kunci yang sama.
- APK biasa tetap lewat preset "Android" (alur GitHub Actions tidak berubah). Layar penuh sudah aktif (`screen/immersive_mode=true`, orientasi landscape sensor).
- Catatan: ID paket `com.fantasylife.rpg.lobby` tidak diubah (mengubahnya membuat HP menganggapnya aplikasi lain dan data simpanan tidak terbawa). Ganti hanya bila belum pernah dirilis.

## Layar pembuka aplikasi (splash + memuat)
Belum diuji di Godot/HP (tidak ada Godot di lingkungan pengubah); mohon dicoba sekali di perangkat dan lihat apakah peralihan terasa mulus.
- **Splash bawaan Godot berlogo** (`project.godot` → `boot_splash/*`, gambar `assets/app_icon/splash.png` 1920×1080: permata + "FANTASY LIFE RPG"). Sebelumnya hanya layar biru-tua polos. Warna latar gambar sama dengan `boot_splash/bg_color`, dan `fullsize=true` supaya pas di semua rasio layar.
- **Scene pembuka baru** `scenes/boot.tscn` (`scripts/boot/boot.gd`) kini menjadi `run/main_scene`. Ia menampilkan gambar splash yang sama (tanpa loncatan dari splash bawaan), lalu memanggil `Flow.goto(SCENE_TITLE, "Menyiapkan petualangan...")`: layar memuat yang sudah ada (langit malam, logo, bar kemajuan nyata, tips) memuat layar judul di thread, menunggu bingkai stabil, lalu memudar ke judul.
- **Alat uji tidak tertunda**: bila mode headless atau ada argumen pengguna (`--bot=1`, `--shots=…`, dst) boot langsung pindah ke `title.tscn` tanpa layar memuat. `tools/title_bot` dan skrip uji lain tidak terpengaruh karena memuat scene-nya sendiri.
- Total tampil sekitar 1–2 detik saat membuka aplikasi (lebih lama di HP lambat karena menunggu bingkai stabil). Untuk menghapus: kembalikan `run/main_scene` ke `res://scenes/title.tscn`.

## Optimasi gameplay (putaran ini)
Belum diuji di Godot/HP (tidak ada Godot di lingkungan pengubah). Perilaku gameplay sengaja tidak diubah; hanya biaya per bingkai yang dikurangi. Mohon jalankan `unit_test`/`perf_test` dan mainkan satu stage.
- **Peluru** (`scripts/stages/projectile.gd`): uji tabrakan memakai akses properti langsung untuk `Enemy` (dulu pencarian properti lewat string `"dead" in t` / `"hit_radius" in t` per kandidat per peluru per bingkai). Pemain/hantu co-op tetap memakai jalur lama.
- **Pemisahan musuh** (`scripts/stages/enemy.gd`, `_separate`): daftar musuh dibuat sekali per tick fisika dan dipakai bersama (dulu tiap musuh meminta salinan array grup sendiri, jadi biaya naik kira-kira kuadrat terhadap jumlah musuh). Musuh yang baru mati dilewati dan ada pemeriksaan `is_instance_valid`.
- **Pemain** (`scripts/player/player.gd`): salinan array `_pending_swing` hanya dibuat bila ada ayunan tertunda (dulu tiap bingkai fisika).
- Sudah dicek dan **tidak perlu diubah**: pemulihan `Engine.time_scale` saat hit-stop (sudah dipulihkan di `_exit_tree`), deteksi musuh nyangkut/jatuh keluar arena, antrean spawn berbatas (`Quality.enemy_alive_cap`), dan pembaruan parameter shader musuh.

## Peta Dunia (penghubung Kota Aurelia ↔ Desa Fajar)
Belum diuji di Godot/HP (tidak ada Godot di lingkungan pengubah). Tata letak sudah dicek lewat render pratinjau terpisah, tetapi tampilan asli di perangkat perlu dilihat sekali.
- **Panel baru "Peta Dunia"** (`scripts/ui/panels/world_map_panel.gd`, id `world_map`, terdaftar di `panel_host.gd`): peta bergaya ilustrasi yang digambar lewat kode (tanpa aset gambar/tekstur; digambar ulang ~12x/detik hanya selama panel terbuka). Menampilkan Kota Aurelia, Portal Petualangan, Desa Fajar, dan Padang Petualangan, dihubungkan jalan, dengan penanda posisi pemain yang berdenyut.
- Ketuk lokasi → info, progres stage wilayah itu, jumlah quest aktif/siap klaim, dan satu tombol aksi: **pergi** ke kota/desa (memakai `Flow.go_town()` / `Flow.go_village()`, layar memuat yang sama dengan papan penunjuk dan gerbang) atau **buka daftar stage**. Daftar stage mengikuti wilayah aktif (`Flow.lobby_map`), jadi pintu stage wilayah lain meminta pemain pergi ke kota/desanya dulu.
- **Pintu masuk**: di Desa Fajar, tombol peta (minimap/Menu → Peta) sekarang membuka Peta Dunia (dulu hanya muncul toast "Desa Fajar kecil…"). Di Aurelia, panel "Peta & Teleport" punya tombol **Peta Dunia**, dan Peta Dunia punya tombol balik **Peta Kota & Teleport**.
- Tidak ada syarat buka: kota dan desa bisa dikunjungi kapan saja, sama seperti papan penunjuk dan gerbang yang sudah ada.
- **Tidak diubah (disengaja)**: pembangun dunia (`lobby_world.gd`, `village_world.gd`). Peta sudah memakai mesh per-chunk 32 m, jarak pandang & kabut mengikuti pengaturan kualitas, bayangan dimatikan untuk chunk jauh, dan sebaran pohon/batu/bunga sudah memakai seed tetap dengan pemeriksaan jarak ke jalan, bangunan, ladang, dan pohon lain. Merombaknya tanpa bisa melihat hasil render berisiko. Bila ada area tertentu yang terlihat berantakan, catat lokasinya (peta + sekitar apa) untuk dirapikan.

## Jebakan, rintangan, puzzle & variasi musuh (stage Adventure)
Belum diuji di Godot/HP (tidak ada Godot di lingkungan pengubah). Semua nilai (damage, waktu, jarak) adalah konstanta di awal `scripts/stages/stage_gimmicks.gd` sehingga mudah disetel setelah dicoba.
- **`StageGimmicks`** (`scripts/stages/stage_gimmicks.gd`, dipasang oleh `Stage._add_gimmicks()`): dibangun malas saat gelombang pertama mulai; layout deterministik per stage (seed dari id stage); semua bahaya **bertelegraf**.
  - **Jebakan duri**: pelat batu di tanah berkedip merah 0,9 dtk, lalu duri menyembul 0,8 dtk. Hanya "bangun" bila pemain dalam 6,5 m. Kena = `7 + 2×level` damage (lewat `Stage._on_enemy_hit`, jadi DEF, kebal dodge, & getar tetap berlaku). Musuh biasa (bukan bos / terbang) juga bisa kena (~20% HP maks).
  - **Batang kayu menggelinding** (khusus hutan): jalur merah melintasi arena lewat posisi pemain, 1,6 dtk kemudian batang menggelinding (11 m/dtk). `9 + 2×level` damage; musuh biasa kena ~30% HP maks. Jeda 9-14 dtk.
  - **Puzzle rune** (semua tema): 10 dtk setelah gelombang pertama, tiga rune (merah/biru/hijau) muncul dan menyala berurutan (3 langkah untuk level ≤ 3, 4 langkah di atasnya). Injak sesuai urutan → hadiah emas `60 + 25×lv`, EXP `30 + 18×lv`, HP pulih 35%. Salah → sengatan `4 + lv`, urutan diputar ulang. Kalau tak dikerjakan 35 dtk, rune padam dan muncul lagi 18 dtk kemudian.
  - **Tidak aktif** di: stage 1-1 (pengenalan), bos, co-op, PVP, wilayah jelajah (`f_`), bot uji / headless. Bisa dimatikan di **Pengaturan > Efek > Jebakan & puzzle** (`gimmicks`, bawaan aktif).
- **Musuh baru** (data saja di `Enemy.KINDS`, model dasar sama): `wasp` Tawon Hutan (terbang, cepat, rapuh), `moss_slime` Slime Lumut (tebal; tetap pecah jadi slime kecil), `cave_bat` Kelelawar Kristal (lebih tangguh dari kelelawar biasa). Kill tetap dihitung sebagai jenis dasar sehingga quest lama tidak terpengaruh. Gelombang stage 1-2 (Hutan Berbisik), 1-3 (gua) dan 1-4 (padang) diganti sebagian dengan varian ini; jumlah musuh per gelombang tidak diubah.
- **Jaring pengaman** (`Stage._keep_player_in_arena`): bila pemain berada >1,8 m di luar tembok arena atau jatuh di bawah lantai, ia dikembalikan ke dalam arena. Normalnya tidak pernah aktif.
- **Bug hutan 1-2**: dari pembacaan kode (pohon/batu/semak, tembok, titik muncul) tidak ditemukan bug jelas selain kemungkinan keluar arena di atas; bila masih ada yang aneh di hutan, catat apa yang terjadi (kapan, di mana, gejalanya) agar bisa diperbaiki tepat sasaran.

## Ekspor APK langsung dari Godot (tanpa GitHub)
**Lewat editor Godot 4.3 (paling mudah):**
1. Editor → Manage Export Templates → Download and Install (versi 4.3.stable).
2. Pasang JDK 17 dan Android SDK (platform-tools, build-tools;34.0.0, platforms;android-34, cmdline-tools;latest). Editor → Editor Settings → Export → Android: isi `Android Sdk Path` dan `Java Sdk Path`.
3. Buat keystore (sekali saja): `keytool -genkeypair -v -keystore keystore/fantasy_life.keystore -alias fantasylife -keyalg RSA -keysize 2048 -validity 10000`. Isi path/user/password di Project → Export → Android (bagian Keystore → Release). Simpan keystore baik-baik, jangan di-commit.
4. Project → Export → pilih "Android" → **matikan centang "Export With Debug"** → Export Project. Wajib build *release*; build debug terasa patah-patah di HP.
5. Jika animasi diubah, jalankan dulu `res://tools/bake_anims.tscn`.

**Lewat skrip (Linux/macOS/Windows):** `bash tools/ekspor_apk.sh` atau `tools\ekspor_apk.bat`. Skrip mengecek Godot, template, JDK, Android SDK, membuat keystore otomatis bila belum ada, lalu mengekspor release ke `build/fantasy_life_rpg.apk`. Opsi `--no-bake` melewati bake animasi.

Catatan jujur: skrip dicek sintaksnya dan berhenti dengan pesan jelas bila template/SDK belum ada, tetapi ekspor APK asli belum bisa diuji di lingkungan saya (tidak ada template & Android SDK); `.bat` belum diuji sama sekali.

## Gabungan 35 (gabungan 34 + kiriman "33_gimmicks")
Zip kiriman (optimasi ringan, ikon/AAB, splash `boot.tscn`, Peta Dunia, jebakan/puzzle, musuh varian) digabung ke versi 34 (skrip ekspor APK langsung dari Godot). Kiriman itu murni tambahan di atas gabungan 33, jadi tidak ada konflik: semua file kiriman dipakai apa adanya, ditambah `tools/ekspor_apk.sh|.bat` dan bagian README ekspor.
- **Diuji di Godot 4.3 (Linux, layar virtual) untuk pertama kali**: seluruh paket `tools/run_all.sh` → 52 lulus, 3 gagal (semuanya sudah gagal juga di gabungan 34 / zip lama, bukan akibat gabungan): `gaya_serang` (jeda serang Sera 0,417 < cooldown 0,50), `efek_karakter` (Zeya puncak node 169–187 > 160, tergantung beban), `cerita_stage` (kurang `--nocine=1`; sudah diperbaiki di `run_all.sh`, lulus).
- Bot baru: `tools/gimmick_bot.gd` (jebakan duri, batang kayu, puzzle rune di stage 1-2: semua terbangun dan puzzle terselesaikan → hadiah masuk) dan `tools/worldmap_bot.gd` (Peta Dunia di kota & desa; semua lokasi bisa dipilih). Keduanya masuk `run_all.sh`.
- Bot otomatis `stage_bot` kalah di stage 1-3 (juga di versi 34 sebelum varian musuh), jadi itu bukan akibat musuh baru. Keseimbangan di HP belum dinilai.
- Belum diuji: tampilan splash/`boot.tscn` di HP, ikon & AAB, ekspor APK asli, performa di perangkat nyata.

## Perbaikan tekstur & resolusi manual (digabung dengan "grafis poles 1")
Belum diuji di Godot/HP (tidak ada Godot di lingkungan pengubah): semua perubahan di bawah ini dicek lewat pembacaan kode saja. **Lihat hasilnya sekali di HP**; bila dunia tampak hitam/magenta, penyebab paling mungkin adalah `shaders/world_common.gdshaderinc` (lihat bagian "Bila bermasalah").
Penyebab yang ditemukan dan diperbaiki:
- **Resolusi dinamis menurunkan gambar walau sudah memilih 100%** (`autoload/perf.gd`): governor FPS masih bisa menurunkan skala 3D sampai 50%. Sekarang resolusi dinamis hanya bekerja pada **Resolusi 3D = Auto**; persentase yang dipilih sendiri (50-100%) dihormati penuh. Konsekuensi: di HP lemah, 100% bisa terasa lebih berat, turunkan manual bila perlu.
- **Resolusi Auto lebih tinggi**: sudah dinaikkan di versi "grafis poles" (`Perf.TARGET_PIXELS` 0,85 / 1,5 / 3,6 MP); angka itu dipakai apa adanya, tidak ditimpa.
- **Tekstur dunia tanpa mipmap** (`world_atlas.png` diimpor `mipmaps/generate=false`): permukaan jauh berbintik/berkedip. Atlas kini dipecah menjadi `Texture2DArray` saat dimuat (`WorldMats._build_array`, 32 lapisan × 64 px) dengan mipmap per lapisan, jadi tidak ada kebocoran warna antar petak. Shader (`world_common.gdshaderinc`) memakai `sampler2DArray` + filter **anisotropik** (lantai/jalan miring lebih tajam) + pengulangan mulus (dulu ada ±2% petak terpotong di tiap sambungan).
- **Halo gelap di tepi rumput/bunga**: piksel transparan pada atlas berwarna hitam sehingga tertarik masuk saat difilter; warna tepi kini diisi dari tetangga terdekat (`tools/gen_textures.py` juga diperbarui).
- **Anti-aliasing Auto**: MSAA 2x kini ikut menyala bila Resolusi 3D 90-100% (dulu hanya di kualitas Bagus), sehingga tepi tidak bergerigi.
- **Warna**: kejenuhan 0,82 → 0,90 dan kecerahan 0,90 → 0,95 pada `world_common.gdshaderinc` (sedikit lebih hidup, tetap pastel).
- Pengaturan > Grafis: keterangan Resolusi 3D, Anti-aliasing & Resolusi dinamis diperbarui. `tools/perf_test.gd` ditambah satu uji untuk aturan baru.
- **Tidak diubah**: jumlah polygon/model karakter, pencahayaan & tonemap, jarak render, bayangan.
### Bila bermasalah
- Dunia hitam/magenta atau muncul galat shader: kembalikan `uniform sampler2DArray atlas ...` menjadi `sampler2D` + versi `world_sample` lama (ada di arsip versi sebelumnya) dan `WorldMats.atlas()` menjadi `load(ATLAS_PATH)`.
- Terlalu berat: Pengaturan > Grafis > Resolusi 3D → Auto (atau 70-80%).

## Gabungan 36 (kiriman "grafis_poles_1" + perbaikan tampilan tekstur)
Dasar: `fantasy_life_rpg_grafis_poles_1.zip` (sudah memuat gabungan 35: jebakan/puzzle, Peta Dunia, stage 3 & 6, cerita Ren, Berkah Bintang, UI Kristal, ekspor APK). Perbaikan tampilan dari putaran sebelumnya ditumpangkan lewat penggabungan 3 arah (basis = `33_gimmicks`):
- File yang hanya diubah di sisi saya dipakai apa adanya: `world_atlas.png` (tepi transparan diisi warna), `shaders/world_common.gdshaderinc` (array tekstur + anisotropik), `scripts/systems/world_mats.gd`, `tools/gen_textures.py`, `tools/perf_test.gd` (+1 uji).
- Tumpang tindih (`perf.gd`, `quality.gd`, `settings_panel.gd`): keduanya digabung. Angka resolusi & komentar milik grafis_poles dipertahankan; ditambah aturan "resolusi manual dihormati" (`Perf.dyn_enabled`), MSAA Auto bila resolusi 90-100% (`Quality.apply`), dan keterangan pengaturan.
- Pengujian: kode digabung & dicek indentasi/kurung saja di lingkungan penggabung (tanpa Godot). Jalankan `bash tools/run_all.sh` di mesin yang punya Godot 4.3 sebelum merilis.


## Gabungan 43+ — Ember & Kiriel masuk Gacha Karakter (peluang naik 2% selama 2 hari, lalu 0,4%)

Dua karakter diperlakukan khusus di **Gacha Karakter (Panggilan Jiwa)** lewat `Gacha.EXTRA_CHARS` (`scripts/systems/gacha.gd`): **Ember** (★4; sebelumnya hanya lewat banner "Festival Bara" yang sudah berakhir) dan **Kiriel** (★6; dikeluarkan dari `CHAR_POOL[6]` supaya peluangnya persis 0,4%, bukan 0,4% + bagian dari ★6 biasa).

- **Peluang dasar 0,4% per tarikan** masing-masing, mutlak per tarikan, diambil dari jatah ★3. Peluang baris ★ lain di `RATES_CHAR` tidak berubah, tetapi total ★4 naik 0,4 poin (Ember) dan total ★6 naik 0,4 poin (Kiriel); sebagai gantinya Hakuya & Kyomu kini berbagi ★6 1,5% berdua (±0,75% masing-masing, dulu ±0,5%). Panel gacha menampilkan tabel yang sudah dikoreksi (`Gacha.display_rates`).
- **Peluang naik 2% per tarikan selama 2 hari**: dua event bertipe `rate_up` di `data/events.json` (`ev_ember_boost`, `ev_kiriel_boost`; 25 Nov 2026 00:00 s/d 26 Nov 2026 23:59). Saat aktif: panel gacha menampilkan "PELUANG NAIK!" + hitung mundur dan tabel peluang menyesuaikan, event muncul di menu Event dengan tombol ke Gacha Karakter. Setelah `end` lewat peluang otomatis kembali 0,4% (karakter tetap ada di gacha). Saat kedua boost aktif, total ★6 ≈ 3,5% dan ★4 ≈ 15% (belum termasuk pity).
- Hasil mengikuti `rarity` karakter: Ember ★4 (duplikat → Pecahan ×5), Kiriel ★6 (duplikat → Pecahan ×20, mereset pity ★6, tidak menambah hitungan pity). Pity ★6 (80 tarikan) memilih dari `CHAR_POOL[6]` saja (Hakuya/Kyomu), jadi Kiriel hanya datang lewat peluangnya sendiri.
- Mengubah jadwal/angka: edit `start`/`end`/`rate` pada event `rate_up` (tanpa menyentuh kode); angka dasar di `Gacha.EXTRA_CHARS`. Karakter ekstra baru: taruh id-nya di `EXTRA_CHARS` (+ opsional event `rate_up`). `data/events.json` ikut terkemas di APK, jadi mengubah jadwal butuh ekspor ulang. Waktu memakai jam perangkat pemain.
- Kode: `Gacha.extra_rate / extra_boost_event / display_rates / _roll_extra`, `LiveEvents` (tipe `rate_up` + validasi), `gacha_panel.gd`, `event_panel.gd`, `character_panel.gd` (petunjuk "cara mendapatkan").
- Perbaikan sampingan: daftar karakter per bintang di panel gacha sebelumnya usang; kini cocok dengan pool asli.
- Uji: `tools/gacha_split_bot.gd` (peluang dasar ≈ 0,4% & boost ≈ 2% untuk Ember dan Kiriel, batas jam 24 Nov 23:59 → 25 Nov 00:00 → 26 Nov 23:59 → 27 Nov 00:00) dan `tools/event_bot.gd` diperbarui. **Belum dijalankan di Godot**; jalankan `bash tools/run_all.sh` sebelum rilis.

### Kyomu: damage disetarakan dengan ★6
- Serangan biasa Kyomu (`attack_mult` 0,55 → 0,95) dan skill Vortex (`skill_mult` 3,3 → 4,2) dinaikkan. Estimasi DPS kombo (pengali × pukulan / waktu kombo, termasuk jeda penutup): Kyomu dulu ±1,9 (terendah di antara ★6; Hakuya ±2,5, Kiriel ±2,9), sekarang ±3,2 (tertinggi, wajar untuk petarung jarak dekat ±2,4 m). Skill 4,2 (Hakuya 3,6, Kiriel 3,4); ULTI 10 sudah tertinggi.
- Stat dasar (HP/ATK/DEF dan pertumbuhan) sengaja **tidak diubah**, jadi "power" Kyomu tetap 157 (Hakuya 159, Kiriel 159) dan aturan `test_data` (★6 > semua ★5) tetap terpenuhi. Angka dipilih dari hitungan di atas, bukan hasil playtest; kalau terasa kurang/berlebih ubah `attack_mult`/`skill_mult` di `resources/characters/kyomu.tres`.

## Kiriel: serangan biasa jadi sambaran petir + ULTI khusus bintang max (kebal 4 dtk, 2x)
- **Serangan biasa**: bukan bola lagi. Peluru Kiriel kini sambaran petir bergerigi memanjang (±2 m, inti putih + pendar kuning, bentuk zig-zag diacak ulang ±16x/dtk supaya berkedip), ditambah percikan listrik dari telapak saat melepas. Peluru terbang lebih cepat (28 m/dtk, dulu 15) agar terasa seperti petir; jangkauan, damage, jeda, dan hitbox tidak diubah. Kode: `StormFx.bolt_visual`, `CharFx.decorate_projectile` (kasus `kiriel`), `Stage._on_swing`.
- **Jatah ULTI**: `ult_charges` kini berarti jatah pada **bintang kebangkitan maksimum** (Kiriel = 2). Di bawah ★ max semua karakter 1x per match (`Stage._ult_max`).
- **Kebal 4 detik**: khusus Kiriel di ★ max, begitu Pedang Petir ditempa (setelah animasi ULTI yang sendiri sudah kebal 2,4 dtk) ia kebal total dari semua serangan 4 dtk, dengan selubung petir berpendar; diulang saat ULTI ke-2. Di bawah ★ max tidak ada kebal tambahan. Kode: `Player.set_immune / immune_t` (terpisah dari `invuln` agar tidak tertimpa dodge/hit/co-op), `Stage._enter_blade_form`, konstanta `BLADE_IMMUNE_SECS`.
- Panel Karakter menampilkan "1× per match (2× di ★ max) · ★ max: kebal 4 dtk".
- Uji: `tools/kiriel_bot.gd` dan `tools/ult_bot.gd` diperbarui (jatah bintang 1 vs max, kebal menolak damage lalu habis). **Belum dijalankan di Godot** dan tampilan sambaran belum dilihat langsung; periksa bentuk/ketebalan sambaran di HP.

## Kombo serangan biasa tersendiri untuk semua 14 karakter
Serangan biasa tiap karakter kini punya **pola kombo sendiri** (3-4 langkah dengan bentuk, jangkauan, jeda, dan efek berbeda), tidak lagi "pukul-pukul yang sama". Data ada di `scripts/systems/combo_defs.gd` (tabel `TABLE`, mudah diubah tanpa menyentuh logika); pelaksananya `scripts/stages/combo_runner.gd`.
| Karakter | Kombo |
|---|---|
| Ren | Tebas → Tebas Balik → Tusuk Es (tusukan sempit & panjang, terjang maju) |
| Zeya | Tusuk → Tusuk → Silang → Bayangan Ganda (2 tebasan beruntun) |
| Kyomu | Tebas → Tebas → Tarik Hampa (menyedot musuh, bukan bos) → Ledak Hampa (hantaman area) |
| Hakuya | Cabut (terjang) → Tebas Balik → Gelombang Api Biru (gelombang menembus) |
| Vael | Tebas → Tebas Balik → Putaran 360° → Tebas Naik (dorongan kuat) |
| Kuroha | Cabut → Balik → Silang (2 tebasan beruntun) |
| Brann | Pukul → Tabrak Bahu (maju) → Hantam Bumi (area + retakan) |
| Sera | Panah → Panah Cepat → Tiga Panah menyebar |
| Lyra | Bintang → Bintang Kembar → Bintang Jatuh (menghantam area di musuh terdekat) |
| Ember | Bola Api → Bola Api → Bola Api Meledak (besar, area) |
| Wenyu | Nada → Nada Ganda → Akor (ledakan nada di sekeliling) |
| Aion | Pecahan → Pecahan Gema (tembakan susulan) → Pecahan Jam (4 pecahan menyebar) |
| Lucien | Tembak → Dua Tembak cepat → Peluru Emas (besar, menembus) |
| Kiriel | Sambar → Sambar Kembar → Petir Berantai (melompat ke 3 musuh); wujud Pedang Petir: Tebas Petir → Tebas Balik → Sambaran Penutup |
- Tipe langkah: arc, cone, spin, slam, pull, multi, wave, shot, twin, fan, burst/echo, pierce, big, rain, nova, chain (lihat komentar di `combo_defs.gd`). Menambah kombo karakter baru: tambah entri id di `TABLE`; tanpa entri dipakai pola lama dari `combo_hits`.
- Keseimbangan: damage per detik putaran kombo disetel ±5-10% dari pola lama (`ComboDefs.cycle`, dicek `tools/combo_bot.gd`), jadi bukan buff besar. Penutup kombo punya jeda lebih panjang.
- Panel Karakter (tab Skill) menampilkan urutan kombo. Kontrol tidak berubah: tetap satu tombol serang, urutan jalan otomatis sesuai ketukan beruntun.
- Keterbatasan: pemain lain di co-op/PVP masih melihat efek serangan versi dasar (visual saja; damage dihitung di penyerang).
- Uji: `tools/combo_bot.gd` dijalankan di Godot 4.3 headless: 14 karakter × tiap langkah melukai musuh, tanpa error skrip. `tools/combo_shots.gd` untuk tangkapan layar.

## Equipment dirombak total (layout 3 kolom, selisih stat nyata, Pasang Terbaik)
Masalah sebelumnya (terlihat di tangkapan layar HP): 14 tombol karakter berjejer horizontal 130 px sehingga lebar minimum jendela melebihi layar — panel terpotong di kanan, karakter di ujung (Wenyu, Kuroha, Aion, Kyomu, Kiriel) tak terjangkau, semua senjata berikon pedang, dan tidak ada perbandingan stat yang jujur.
- **Kiri**: daftar karakter vertikal (bisa digulir, otomatis menggulir ke karakter terpilih): nama, bintang, Kekuatan.
- **Tengah**: 3 slot (ketuk untuk memilih slot, "Lepas" per slot) + kotak stat HP/ATK/DEF/Kekuatan.
- **Kanan**: hanya item yang cocok untuk slot terpilih, tiap baris menampilkan **selisih stat nyata** (sudah termasuk pengali bintang & tempaan +N lewat `GameState.char_stats_with`), tanda **TERBAIK**, jumlah item (×N), urut Kekuatan/Langka. **Satu ketukan = pasang**, toast menunjukkan Kekuatan sebelum → sesudah. Tombol **Pasang Terbaik** memilih item berkekuatan tertinggi untuk ketiga slot (hanya bila benar-benar lebih kuat).
- Semua label dipotong (`clip_text`) dan tiap kolom bisa digulir, jadi lebar jendela tak lagi melebihi layar.
- Ikon senjata kini menurut kelas: **busur, tongkat, kapak/palu, pedang** (`UiIcon` kind `bow`/`staff`/`axe`, `BasePanel.weapon_icon_kind`) — ikut berlaku di Inventori, Toko, dan hasil gacha perlengkapan.
- Uji: `tools/panel_bot.gd` +3 cek (pratinjau stat, lepas senjata, ikon kelas). **Belum dijalankan di Godot** dan tampilannya belum dilihat langsung; periksa di HP, terutama tinggi kolom tengah di layar pendek (kolom tengah bisa digulir).

### Rombak panel Karakter (menu Karakter)
- `scripts/ui/panels/character_panel.gd` ditulis ulang. Daftar kiri: baris dibuat sekali lalu hanya diperbarui/diurutkan (party dulu, lalu dimiliki menurut kelangkaan, terkunci terakhir; tag ♛ / Party). Mengetuk karakter hanya mengganti detail.
- Detail kanan dibagi 3 tab: **Status** (kekuatan, Lv, batang HP/ATK/DEF/Gerak, angka hijau = tambahan bila naik ★, deskripsi), **Skill** (serangan, skill, ULT + kritikal, tembus DEF, mana, durasi wujud), **Perlengkapan** (3 slot, ketuk untuk Equipment). Tombol aksi dipaku di bawah (tidak lagi terpotong layar).
- Tombol kiri bawah pintar: Pemimpin / Jadikan Pemimpin / Masukkan ke Party (bila slot ada) / Atur di Party (bila penuh).
- `GameState`: tambah `STAR_STEP` dan `star_factor(n)`; `char_stats_with` memakainya (hasil statistik sama persis dengan sebelumnya).
- **Belum diuji**: Godot tidak tersedia di lingkungan penyusunan, jadi skrip belum dijalankan. Hanya dicek sintaks dasar (indentasi tab, kurung seimbang). Mohon uji buka menu Karakter di HP/editor.

### Moto hidup dan cerita karakter
- `CharacterData` punya dua field baru: `motto` (satu kalimat, suara si karakter) dan `story` (cerita singkat, paragraf dipisah baris kosong). Semua 14 karakter di `resources/characters/*.tres` sudah terisi, disesuaikan dengan lore di `data/story.json` (Aurelia, Kehampaan, Serikat Bintang Fajar, dll).
- Tampil di tab **Kisah** pada panel Karakter. Karakter yang belum didapat hanya menampilkan moto; ceritanya terbuka setelah karakter bergabung.
- Mengubah teks cukup edit baris `motto` / `story` di file `.tres` (di editor Godot: Inspector > Motto / Story). Tulis `\n\n` di antara paragraf bila lewat file teks.
- Catatan: `tools/generate_resources.gd` hanya memuat 4 karakter awal dan sudah tertinggal dari `.tres` (mis. belum ada ULT). Jangan dijalankan ulang untuk karakter, karena akan menimpa moto/cerita dan data lain.
