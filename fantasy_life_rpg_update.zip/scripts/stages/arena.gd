class_name StageArena
extends Node3D
## Arena bundar bertema (meadow / forest / cave / boss / lair), dibangun prosedural dengan MeshKit. Tabrakan: lantai, tembok tak terlihat di tepi, dan batu/pilar di dalam.

const T_GRASS := MeshKit.T_GRASS
const T_COBBLE := MeshKit.T_COBBLE
const T_MARBLE := MeshKit.T_MARBLE
const T_DIRT := MeshKit.T_DIRT

const R_SCALE := 1.3                  # arena diperbesar (tanpa mengubah aturan main)
## Tata letak anti-nyangkut: tengah arena (< FREE_ZONE * radius) bebas rintangan; batu/pilar hanya di cincin tepi,
## menjauhi 6 titik spawn tetap (GATES) supaya monster tidak muncul di dalam/terjepit batu.
const FREE_ZONE := 0.72
const GATES := 6
const GATE_R := 0.80                 # jarak titik spawn dari pusat (fraksi radius)
const GATE_CLEAR := 0.2              # sudut (rad) di sekitar titik spawn yang dikosongkan dari rintangan
var radius := 20.0
var theme := "meadow"
var hour := 11.0                # jam langit untuk DayNight
var fog := 0.0
var music := "music_desert"


## Enam titik spawn tetap di cincin tepi (dipakai Stage). Titik ke-i ada di sudut i * 60°.
func spawn_points() -> Array:
	var out: Array = []
	for i in GATES:
		var a := float(i) / GATES * TAU
		out.append(Vector3(cos(a) * radius * GATE_R, 0.05, sin(a) * radius * GATE_R))
	return out


static func _near_gate(a: float) -> bool:
	var step := TAU / GATES
	var d := fposmod(a, step)
	return minf(d, step - d) < GATE_CLEAR


func build(p_theme: String) -> void:
	theme = p_theme
	var rng := RandomNumberGenerator.new()
	rng.seed = 777 + theme.length()
	var k := MeshKit.new(31)
	var s := ColliderSink.new()
	match theme:
		"forest":
			radius = 21.0 * R_SCALE
			hour = 15.5
			fog = 0.006
			_ground(k, Color(0.5, 0.72, 0.52), T_GRASS)
			_ring_trees(k, s, rng, 1, Color(0.3, 0.6, 0.42), 52)
			_ring_trees(k, s, rng, 0, Color(0.38, 0.66, 0.4), 18)
			_scatter(k, s, rng, 5, "rock")
			_scatter(k, s, rng, 6, "bush")
			Decor.flower_patch(k, Vector3(-6, 0, 4), 3.0, 14)
		"cave":
			radius = 20.0 * R_SCALE
			hour = 22.5
			fog = 0.012
			_ground(k, Color(0.5, 0.52, 0.66), T_COBBLE)
			_ring_rocks(k, s, rng, Color(0.42, 0.44, 0.58))
			_crystals(k, rng, 26, [], s)
			_scatter(k, s, rng, 6, "rock")
		"boss":
			radius = 23.0 * R_SCALE
			hour = 18.4
			fog = 0.004
			_ground(k, Color(0.5, 0.54, 0.7), T_MARBLE)
			k.ring(Vector3(0, 0.03, 0), radius * 0.42, radius * 0.45, 48, T_MARBLE, MeshKit.glow(Color(0.4, 0.85, 1.0), 0.8))
			k.ring(Vector3(0, 0.03, 0), radius * 0.15, radius * 0.17, 32, T_MARBLE, MeshKit.glow(Color(0.4, 0.85, 1.0), 0.8))
			_pillars(k, s, 10)
			_crystals(k, rng, 18, [], s)
			music = "music_boss"
		"lair":
			radius = 24.0 * R_SCALE
			hour = 20.3
			fog = 0.014
			_ground(k, Color(0.46, 0.38, 0.42), T_COBBLE)
			_ring_rocks(k, s, rng, Color(0.4, 0.33, 0.38))
			# retakan bara menyala di lantai
			k.ring(Vector3(0, 0.03, 0), radius * 0.30, radius * 0.315, 48, T_COBBLE, MeshKit.glow(Color(1.0, 0.45, 0.15), 0.9))
			k.ring(Vector3(0, 0.03, 0), radius * 0.62, radius * 0.635, 56, T_COBBLE, MeshKit.glow(Color(1.0, 0.35, 0.12), 0.8))
			for i in 7:
				var a := rng.randf() * TAU
				var r := radius * (0.25 + rng.randf() * 0.6)
				k.disc(Vector3(cos(a) * r, 0.025, sin(a) * r), 0.7 + rng.randf() * 0.9, 14, T_COBBLE, MeshKit.glow(Color(1.0, 0.4, 0.12), 0.85))
			_crystals(k, rng, 22, [Color(1.0, 0.55, 0.2), Color(1.0, 0.35, 0.3), Color(0.85, 0.45, 0.9)], s)
			_stalagmites(k, s, rng, 12)
			_scatter(k, s, rng, 5, "rock")
			music = "music_boss"
		"abyss":
			radius = 25.0 * R_SCALE
			hour = 21.6
			fog = 0.012
			_ground(k, Color(0.3, 0.25, 0.4), T_MARBLE)
			k.ring(Vector3(0, 0.03, 0), radius * 0.78, radius * 0.795, 64, T_MARBLE, MeshKit.glow(Color(0.7, 0.3, 1.0), 0.9))
			k.ring(Vector3(0, 0.03, 0), radius * 0.50, radius * 0.512, 56, T_MARBLE, MeshKit.glow(Color(0.7, 0.3, 1.0), 0.8))
			_pillars(k, s, 12, Color(0.32, 0.26, 0.42))
			_crystals(k, rng, 26, [Color(0.75, 0.35, 1.0), Color(1.0, 0.4, 0.9), Color(0.5, 0.45, 1.0)], s)
			_floating_cubes(k, rng, 22)
			_scatter(k, s, rng, 4, "rock")
			music = "music_abyss"
		"temple":
			# Kuil Bayangan: halaman batu gelap, pilar lak merah, gerbang pagoda & lentera batu, lingkaran segel merah menyala
			radius = 24.0 * R_SCALE
			hour = 20.2
			fog = 0.010
			_ground(k, Color(0.34, 0.31, 0.38), T_COBBLE)
			k.disc(Vector3(0, 0.02, 0), radius * 0.92, 56, T_MARBLE, Color(0.4, 0.36, 0.44), 1.0)
			k.ring(Vector3(0, 0.04, 0), radius * 0.40, radius * 0.415, 56, T_MARBLE, MeshKit.glow(Color(1.0, 0.2, 0.25), 0.9))
			k.ring(Vector3(0, 0.04, 0), radius * 0.70, radius * 0.712, 64, T_MARBLE, MeshKit.glow(Color(1.0, 0.25, 0.3), 0.7))
			for i in 4:
				var a := i * PI * 0.5 + PI * 0.25
				k.box(Vector3(cos(a) * radius * 0.2, 0.045, sin(a) * radius * 0.2), Vector3(radius * 0.4, 0.02, 0.18), T_MARBLE, MeshKit.glow(Color(1.0, 0.2, 0.25), 0.8))
			_red_pillars(k, s, 10, radius - 1.4)
			_pagoda(k, Vector3(0, 0, -radius - 9.0), 1.6)
			_pagoda(k, Vector3(-radius - 7.0, 0, 6.0), 1.0)
			_pagoda(k, Vector3(radius + 8.0, 0, 9.0), 1.1)
			_stone_lanterns(k, s, rng, 9)
			_torii(k, s, Vector3(0, 0, radius * 0.88), 4.2)
			_scatter(k, s, rng, 4, "rock")
			music = "music_abyss"
		"chains":
			# Menara Rantai Merah: aula gelap, karpet merah, rantai raksasa menjuntai, pilar berduri, retakan merah menyala
			radius = 25.0 * R_SCALE
			hour = 23.0
			fog = 0.014
			_ground(k, Color(0.24, 0.22, 0.28), T_MARBLE)
			k.disc(Vector3(0, 0.02, 0), radius * 0.95, 56, T_MARBLE, Color(0.3, 0.27, 0.34), 1.0)
			k.box(Vector3(0, 0.035, 0), Vector3(5.0, 0.02, radius * 2.0), T_MARBLE, Color(0.55, 0.08, 0.12))          # karpet
			k.box(Vector3(0, 0.04, 0), Vector3(5.4, 0.015, radius * 2.0), T_MARBLE, MeshKit.glow(Color(1.0, 0.7, 0.3), 0.3))
			k.box(Vector3(0, 0.05, 0), Vector3(4.8, 0.012, radius * 2.0), T_MARBLE, Color(0.5, 0.06, 0.1))
			k.ring(Vector3(0, 0.06, 0), radius * 0.30, radius * 0.315, 48, T_MARBLE, MeshKit.glow(Color(1.0, 0.15, 0.2), 0.95))
			k.ring(Vector3(0, 0.06, 0), radius * 0.62, radius * 0.632, 56, T_MARBLE, MeshKit.glow(Color(1.0, 0.15, 0.2), 0.8))
			_red_pillars(k, s, 12, radius - 1.2, Color(0.2, 0.2, 0.26), true)
			_hanging_chains(k, rng, 18)
			_crystals(k, rng, 16, [Color(1.0, 0.2, 0.3), Color(1.0, 0.45, 0.35), Color(0.7, 0.2, 0.5)], s)
			_throne(k, s, Vector3(0, 0, -radius + 3.5))
			_scatter(k, s, rng, 4, "rock")
			music = "music_boss"
		_:
			radius = 20.0 * R_SCALE
			hour = 11.0
			fog = 0.0
			_ground(k, Color(0.64, 0.82, 0.52), T_GRASS)
			_ring_trees(k, s, rng, 0, Color(0.45, 0.8, 0.42), 46)
			_ring_trees(k, s, rng, 2, Color(0.55, 0.85, 0.5), 8)
			_scatter(k, s, rng, 4, "rock")
			_scatter(k, s, rng, 6, "bush")
			Decor.flower_patch(k, Vector3(5, 0, -6), 4.0, 22)
			Decor.flower_patch(k, Vector3(-7, 0, 5), 3.5, 18)
	_outer_world(k, s, rng)
	var mesh := k.build()
	k.apply_materials(mesh)
	var mi := MeshInstance3D.new()
	mi.name = "ArenaMesh"
	mi.mesh = mesh
	add_child(mi)
	_colliders(s)
	if theme == "abyss":
		_magic_floor()


## Lingkaran sihir raksasa di lantai (dua lapisan berputar berlawanan arah), memakai tekstur assets/fx/magic_*.png.
var _floor_layers: Array = []


func _magic_floor() -> void:
	for i in 2:
		var mi := MeshInstance3D.new()
		var pm := PlaneMesh.new()
		var d := radius * (1.55 if i == 0 else 1.0)
		pm.size = Vector2(d, d)
		mi.mesh = pm
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
		m.albedo_texture = load("res://assets/fx/magic_outer.png" if i == 0 else "res://assets/fx/magic_inner.png")
		m.albedo_color = Color(0.7, 0.35, 1.0, 0.75 if i == 0 else 0.6)
		mi.material_override = m
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.position.y = 0.05 + 0.01 * i
		add_child(mi)
		_floor_layers.append(mi)


func _process(delta: float) -> void:
	if _floor_layers.size() == 2:
		_floor_layers[0].rotation.y += delta * 0.08
		_floor_layers[1].rotation.y -= delta * 0.13


## Pilar lak merah (alas batu, kepala emas); spiked = pilar baja berduri (Menara Rantai).
func _red_pillars(k: MeshKit, s: ColliderSink, count: int, rad: float, col: Color = Color(0.62, 0.1, 0.14), spiked: bool = false) -> void:
	for i in count:
		var a := (float(i) + 0.5) / count * TAU
		var p := Vector3(cos(a) * rad, 0, sin(a) * rad)
		k.cylinder(p, 1.25, 1.1, 0.5, 8, T_MARBLE, Color(0.3, 0.28, 0.34), true)
		k.cylinder(p + Vector3(0, 0.5, 0), 0.85, 0.75, 7.2, 10, T_MARBLE, col, true)
		k.cylinder(p + Vector3(0, 7.5, 0), 1.2, 1.2, 0.5, 10, T_MARBLE, Color(0.16, 0.14, 0.18), true)
		k.cylinder(p + Vector3(0, 3.2, 0), 0.9, 0.9, 0.18, 10, T_MARBLE, Color(1.0, 0.82, 0.32), false, -1, false, 1.0)
		if spiked:
			for j in 6:
				var ja := j * TAU / 6.0
				k.cylinder(p + Vector3(cos(ja) * 0.8, 4.4 + (j % 3) * 0.9, sin(ja) * 0.8), 0.14, 0.0, 0.5, 4, T_MARBLE, Color(0.5, 0.52, 0.6), false, -1, false, 1.0)
		else:
			k.crystal(p + Vector3(0, 8.0, 0), 0.3, 1.1, Color(1.0, 0.25, 0.3), 0.9, 5, 0.0)
		s.cyl(k.xf, p, 1.0, 7.5)


## Pagoda bertingkat 3 (dinding merah gelap, atap melengkung gelap berbibir emas, lentera menyala).
func _pagoda(k: MeshKit, pos: Vector3, sc: float) -> void:
	var wall := Color(0.5, 0.08, 0.12)
	var roof := Color(0.14, 0.12, 0.18)
	var y := 0.0
	k.box(pos + Vector3(0, 0.4, 0), Vector3(11, 0.8, 11) * sc, T_MARBLE, Color(0.32, 0.3, 0.36))
	y = 0.8 * sc
	for t in 3:
		var w := (8.0 - t * 1.9) * sc
		var h := 3.0 * sc
		k.box(pos + Vector3(0, y + h * 0.5, 0), Vector3(w, h, w), T_MARBLE, wall)
		for sx in [-1.0, 1.0]:
			for sz in [-1.0, 1.0]:
				k.cylinder(pos + Vector3(sx * w * 0.5, y, sz * w * 0.5), 0.26 * sc, 0.26 * sc, h, 6, T_MARBLE, Color(0.28, 0.06, 0.08), true)
		k.box(pos + Vector3(0, y + h * 0.6, w * 0.5 + 0.02), Vector3(w * 0.36, h * 0.42, 0.06), T_MARBLE, MeshKit.glow(Color(1.0, 0.7, 0.3), 0.7))
		y += h
		k.gable_roof(pos + Vector3(0, y, 0), w + 1.0 * sc, w + 1.0 * sc, 1.6 * sc, 1.5 * sc, T_MARBLE, roof, T_MARBLE, wall)
		k.box(pos + Vector3(0, y + 0.1, 0), Vector3(w + 3.2 * sc, 0.16 * sc, w + 3.2 * sc), T_MARBLE, Color(1.0, 0.82, 0.32))
		y += 1.0 * sc
	k.cylinder(pos + Vector3(0, y + 1.4 * sc, 0), 0.4 * sc, 0.0, 3.0 * sc, 6, T_MARBLE, Color(1.0, 0.82, 0.32), false, -1, false, 1.0)
	k.blob(pos + Vector3(0, y + 1.5 * sc, 0), 0.5 * sc, T_MARBLE, MeshKit.glow(Color(1.0, 0.3, 0.3), 0.9), 3, 6)


func _stone_lanterns(k: MeshKit, s: ColliderSink, rng: RandomNumberGenerator, count: int) -> void:
	for i in count:
		var a := (float(i) + rng.randf() * 0.5) / count * TAU
		var r := radius * (0.8 + rng.randf() * 0.1)
		var p := Vector3(cos(a) * r, 0, sin(a) * r)
		k.cylinder(p, 0.4, 0.28, 1.5, 6, T_MARBLE, Color(0.42, 0.4, 0.46), true)
		k.box(p + Vector3(0, 1.85, 0), Vector3(0.8, 0.7, 0.8), T_MARBLE, MeshKit.glow(Color(1.0, 0.45, 0.25), 0.8))
		k.cylinder(p + Vector3(0, 2.2, 0), 0.8, 0.1, 0.5, 4, T_MARBLE, Color(0.3, 0.28, 0.34), true)
		s.cyl(k.xf, p, 0.45, 2.4)


func _torii(k: MeshKit, s: ColliderSink, pos: Vector3, w: float) -> void:
	var red := Color(0.68, 0.1, 0.12)
	for sx in [-1.0, 1.0]:
		k.cylinder(pos + Vector3(sx * w * 0.5, 0, 0), 0.34, 0.3, 5.0, 8, T_MARBLE, red, true)
		s.cyl(k.xf, pos + Vector3(sx * w * 0.5, 0, 0), 0.4, 5.0)
	k.box(pos + Vector3(0, 4.3, 0), Vector3(w + 1.6, 0.3, 0.4), T_MARBLE, red)
	k.box(pos + Vector3(0, 5.2, 0), Vector3(w + 2.6, 0.38, 0.5), T_MARBLE, Color(0.12, 0.1, 0.14))
	k.box(pos + Vector3(0, 4.85, 0), Vector3(0.4, 0.6, 0.3), T_MARBLE, Color(1.0, 0.82, 0.32))


## Rantai raksasa menjuntai dari kegelapan di atas (mata rantai bergantian arah).
func _hanging_chains(k: MeshKit, rng: RandomNumberGenerator, count: int) -> void:
	for i in count:
		var a := rng.randf() * TAU
		var r := radius * (0.25 + rng.randf() * 0.7)
		var p := Vector3(cos(a) * r, 0, sin(a) * r)
		var top := 10.0 + rng.randf() * 4.0
		var low := 3.0 + rng.randf() * 3.5
		var n := int((top - low) / 0.42)
		for j in n:
			var yy := top - j * 0.42
			var big := j % 2 == 0
			k.box(p + Vector3(0, yy, 0), Vector3(0.34, 0.5, 0.1) if big else Vector3(0.1, 0.5, 0.34), T_METAL_T, Color(0.46, 0.46, 0.54) if big else Color(0.32, 0.32, 0.4))
		k.box(p + Vector3(0, low - 0.35, 0), Vector3(0.7, 0.45, 0.5), T_METAL_T, MeshKit.glow(Color(1.0, 0.15, 0.2), 0.7))


const T_METAL_T := MeshKit.T_METAL


## Singgasana Raja Rantai (di belakang titik muncul bos).
func _throne(k: MeshKit, s: ColliderSink, pos: Vector3) -> void:
	k.box(pos + Vector3(0, 0.4, -2.0), Vector3(9, 0.8, 5), T_MARBLE, Color(0.2, 0.18, 0.24))
	k.box(pos + Vector3(0, 1.0, -2.0), Vector3(6, 0.5, 3.4), T_MARBLE, Color(0.3, 0.06, 0.1))
	k.box(pos + Vector3(0, 3.2, -3.6), Vector3(3.2, 4.4, 0.6), T_MARBLE, Color(0.14, 0.12, 0.17))
	for i in 5:
		k.cylinder(pos + Vector3((i - 2) * 0.75, 5.2, -3.6), 0.2, 0.0, 1.5 + (2 - absi(i - 2)) * 0.5, 4, T_MARBLE, Color(0.55, 0.55, 0.62), false, -1, false, 1.0)
	k.box(pos + Vector3(0, 3.2, -3.28), Vector3(1.0, 1.0, 0.08), T_MARBLE, MeshKit.glow(Color(1.0, 0.15, 0.2), 0.9))
	s.box(k.xf, pos + Vector3(0, 0.8, -2.0), Vector3(9, 1.6, 5))


func _floating_cubes(k: MeshKit, rng: RandomNumberGenerator, count: int) -> void:
	for i in count:
		var a := rng.randf() * TAU
		var r := radius * (0.55 + rng.randf() * 0.55)
		var sz := 0.5 + rng.randf() * 1.0
		var y := 2.0 + rng.randf() * 5.0
		var shade := 0.28 + rng.randf() * 0.15
		k.box(Vector3(cos(a) * r, y, sin(a) * r), Vector3(sz, sz, sz), T_MARBLE, Color(shade, shade * 0.85, shade * 1.4), T_MARBLE, Color(shade * 1.6, shade * 1.2, shade * 2.0), 0.7, true)


func _ground(k: MeshKit, col: Color, tile: int) -> void:
	k.disc(Vector3(0, 0, 0), radius + 16.0, 64, tile, col, 1.0)
	_ground_col = col
	_ground_tile = tile


func _ring_trees(k: MeshKit, s: ColliderSink, rng: RandomNumberGenerator, kind: int, crown: Color, count: int) -> void:
	count = int(count * R_SCALE * (0.6 if _lite() else 1.0))
	for i in count:
		var a := rng.randf() * TAU
		var r := radius + 1.5 + rng.randf() * 9.0
		var h := 4.2 + rng.randf() * 2.8
		Decor.tree(k, s if r < radius + 3.0 else null, Vector3(cos(a) * r, 0, sin(a) * r), h, crown, kind, r > radius + 6.0)


func _ring_rocks(k: MeshKit, s: ColliderSink, rng: RandomNumberGenerator, col: Color) -> void:
	var n_rock := int(34 * R_SCALE)
	for i in n_rock:
		var a := float(i) / n_rock * TAU + rng.randf() * 0.1
		var r := radius + 0.5 + rng.randf() * 3.0
		Decor.rock(k, s, Vector3(cos(a) * r, 0, sin(a) * r), 2.0 + rng.randf() * 2.2, col)
	for i in int(22 * R_SCALE * (0.6 if _lite() else 1.0)):
		var a2 := rng.randf() * TAU
		var r2 := radius + 4.0 + rng.randf() * 8.0
		Decor.rock(k, null, Vector3(cos(a2) * r2, 0, sin(a2) * r2), 3.0 + rng.randf() * 3.0, col.darkened(0.1))


func _stalagmites(k: MeshKit, s: ColliderSink, rng: RandomNumberGenerator, count: int) -> void:
	count = int(count * R_SCALE)
	var placed := 0
	var tries := 0
	while placed < count and tries < count * 12:
		tries += 1
		var a := rng.randf() * TAU
		if _near_gate(a):
			continue
		var r := radius * (FREE_ZONE + 0.05) + rng.randf() * (radius * (1.0 - FREE_ZONE - 0.05) - 3.0)
		var p := Vector3(cos(a) * r, 0, sin(a) * r)
		var h := 2.2 + rng.randf() * 2.6
		k.cylinder(p, 0.9, 0.12, h, 7, T_COBBLE, Color(0.36, 0.3, 0.35), false)
		s.cyl(k.xf, p, 0.8, h)
		placed += 1


func _crystals(k: MeshKit, rng: RandomNumberGenerator, count: int, palette: Array = [], s: ColliderSink = null) -> void:
	count = int(count * R_SCALE * (0.7 if _lite() else 1.0))
	var cols := [Color(0.4, 0.85, 1.0), Color(0.65, 0.55, 1.0), Color(1.0, 0.55, 0.85)]
	if not palette.is_empty():
		cols = palette
	var placed := 0
	var tries := 0
	while placed < count and tries < count * 12:
		tries += 1
		var a := rng.randf() * TAU
		if _near_gate(a):
			continue
		# kristal itu padat: hanya di cincin tepi (tengah arena bebas) dan punya tabrakan
		var r := radius * (FREE_ZONE + 0.03) + rng.randf() * (radius * (1.0 - FREE_ZONE - 0.03) - 2.5)
		var c: Color = cols[rng.randi() % cols.size()]
		var h := 0.8 + rng.randf() * 1.8
		var cr := 0.25 + rng.randf() * 0.3
		var p := Vector3(cos(a) * r, 0, sin(a) * r)
		k.crystal(p, cr, h, c, 0.85, 5, rng.randf_range(-15.0, 15.0))
		if s != null:
			s.cyl(k.xf, p, cr * 0.9, h * 0.9)
		placed += 1


func _pillars(k: MeshKit, s: ColliderSink, count: int, col: Color = Color(0.62, 0.66, 0.82)) -> void:
	count = int(count * R_SCALE)
	for i in count:
		var a := float(i) / count * TAU
		var p := Vector3(cos(a) * (radius - 1.2), 0, sin(a) * (radius - 1.2))
		k.cylinder(p, 1.0, 0.8, 7.0, 10, T_MARBLE, col, true)
		k.cylinder(p + Vector3(0, 7.0, 0), 1.2, 1.2, 0.5, 10, T_MARBLE, Color(0.72, 0.76, 0.9), true)
		k.crystal(p + Vector3(0, 7.5, 0), 0.35, 1.3, Color(0.4, 0.85, 1.0), 0.9, 5, 0.0)
		s.cyl(k.xf, p, 1.0, 7.0)


func _scatter(k: MeshKit, s: ColliderSink, rng: RandomNumberGenerator, count: int, what: String) -> void:
	count = int(count * R_SCALE * R_SCALE)
	var placed := 0
	var tries := 0
	while placed < count and tries < count * 12:
		tries += 1
		var a := rng.randf() * TAU
		if _near_gate(a):
			continue
		var r := radius * (FREE_ZONE + 0.04) + rng.randf() * (radius * (1.0 - FREE_ZONE - 0.04) - 3.5)   # hanya cincin tepi
		var p := Vector3(cos(a) * r, 0, sin(a) * r)
		if what == "rock":
			Decor.rock(k, s, p, 0.55 + rng.randf() * 0.4, Pal.STONE_DARK)
		else:
			Decor.bush(k, s, p, 0.7 + rng.randf() * 0.5)
		placed += 1


func _colliders(s: ColliderSink) -> void:
	var body := StaticBody3D.new()
	body.name = "ArenaBody"
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	var fcs := CollisionShape3D.new()
	var fb := BoxShape3D.new()
	fb.size = Vector3(200, 2, 200)
	fcs.shape = fb
	fcs.position = Vector3(0, -1.0, 0)
	body.add_child(fcs)
	var n := 32
	for i in n:
		var a := float(i) / n * TAU
		var cs := CollisionShape3D.new()
		var b := BoxShape3D.new()
		b.size = Vector3(TAU * radius / n + 1.2, 12, 1.5)
		cs.shape = b
		cs.position = Vector3(cos(a) * (radius + 0.75), 5, sin(a) * (radius + 0.75))
		cs.rotation.y = -a + PI / 2.0
		body.add_child(cs)
	s.apply_to(body)


# =====================================================================
#  Dunia di luar arena: lantai luas, gunung/tebing, hutan & hiasan jauh.
#  Jarak ikut jarak render (6/9/12 chunk) supaya selalu terisi tanpa memboroskan objek di luar jangkauan kamera.
# =====================================================================
var _ground_col := Color(0.5, 0.7, 0.5)
var _ground_tile := MeshKit.T_GRASS


func _lite() -> bool:
	return Quality.level() == 0


## Jarak (dari pusat arena) tempat pemandangan jauh ditaruh: kamera bisa di tepi arena, jadi sisakan radius.
func _scenery_d() -> float:
	return clampf(Quality.view_far() - radius - 6.0, radius + 24.0, 190.0)


func _haze(c: Color, f: float) -> Color:
	var sky := Color(0.62, 0.7, 0.86) if hour > 7.0 and hour < 18.0 else Color(0.2, 0.18, 0.3)
	return c.lerp(sky, f)


func _outer_world(k: MeshKit, s: ColliderSink, rng: RandomNumberGenerator) -> void:
	var d := _scenery_d()
	var lite := _lite()
	var outdoor := theme in ["meadow", "forest"] or not (theme in ["cave", "lair", "abyss", "boss", "temple", "chains"])
	# lantai luas sampai ke kaki gunung (sedikit lebih gelap & lebih kabur)
	k.disc(Vector3(0, -0.04, 0), d + 40.0, 56, _ground_tile, _haze(_ground_col.darkened(0.12), 0.25), 1.0)
	if outdoor:
		_outer_outdoor(k, rng, d, lite)
	else:
		match theme:
			"cave", "lair":
				_outer_cavern(k, rng, d, lite, theme == "lair")
			"temple":
				_outer_temple(k, rng, d, lite)
			"abyss":
				_outer_void(k, rng, d, lite, Color(0.3, 0.22, 0.42), Color(0.75, 0.35, 1.0))
			"chains":
				_outer_void(k, rng, d, lite, Color(0.26, 0.18, 0.26), Color(1.0, 0.25, 0.3))
			_:
				_outer_void(k, rng, d, lite, Color(0.3, 0.34, 0.5), Color(0.4, 0.85, 1.0))


func _cone(k: MeshKit, p: Vector3, r: float, h: float, col: Color, tex: int, seg: int = 7) -> void:
	k.cylinder(p, r, r * 0.07, h, seg, tex, col, false, -1, false, 0.9)


func _outer_outdoor(k: MeshKit, rng: RandomNumberGenerator, d: float, lite: bool) -> void:
	var forest := theme == "forest"
	# gunung berpuncak salju membentuk cincin penuh
	var n_m := 12 if lite else 20
	for i in n_m:
		var a := (float(i) + rng.randf() * 0.6) / n_m * TAU
		var dd := d + rng.randf_range(-4.0, 22.0)
		var h := rng.randf_range(26.0, 52.0)
		var r := h * rng.randf_range(0.95, 1.3)
		var p := Vector3(cos(a) * dd, 0, sin(a) * dd)
		var col := _haze(Color(0.46, 0.6, 0.5) if forest else Color(0.5, 0.64, 0.74), 0.38)
		_cone(k, p, r, h, col, MeshKit.T_PLASTER)
		_cone(k, p + Vector3(0, h * 0.7, 0), r * 0.07 + (r - r * 0.07) * 0.3, h * 0.3 + 0.4, Color(0.97, 0.98, 1.0), MeshKit.T_PLASTER)
	# bukit rendah berumput di depan gunung
	var n_h := 14 if lite else 26
	for i in n_h:
		var a2 := (float(i) + rng.randf()) / n_h * TAU
		var d2 := d * rng.randf_range(0.6, 0.85)
		k.blob(Vector3(cos(a2) * d2, 0, sin(a2) * d2), rng.randf_range(12.0, 22.0), MeshKit.T_GRASS, _haze(_ground_col.darkened(0.04), 0.12), 4, 8, 0.4, 0.3)
	# hutan jauh (pohon rendah tanpa tabrakan), rapat di hutan
	var n_t := (70 if forest else 40) * (0.5 if lite else 1.0)
	for i in int(n_t):
		var a3 := rng.randf() * TAU
		var d3 := radius + 12.0 + rng.randf() * (d * 0.55 - radius)
		var crown := Color(0.3, 0.58, 0.4) if forest else Color(0.45, 0.78, 0.42)
		Decor.tree(k, null, Vector3(cos(a3) * d3, 0, sin(a3) * d3), 5.5 + rng.randf() * 4.0, _haze(crown, 0.12), 1 if forest else 0, true)
	# batu besar & bunga di padang luar
	for i in (6 if lite else 14):
		var a4 := rng.randf() * TAU
		var d4 := radius + 6.0 + rng.randf() * (d * 0.5)
		Decor.rock(k, null, Vector3(cos(a4) * d4, 0, sin(a4) * d4), 1.4 + rng.randf() * 2.0, Pal.STONE_DARK)
	for i in (3 if lite else 7):
		var a5 := rng.randf() * TAU
		var d5 := radius + 8.0 + rng.randf() * (d * 0.4)
		Decor.flower_patch(k, Vector3(cos(a5) * d5, 0, sin(a5) * d5), 5.0, 14)
	# danau kecil
	var la := rng.randf() * TAU
	var lp := Vector3(cos(la), 0, sin(la)) * (radius + 26.0)
	k.disc(lp + Vector3(0, 0.03, 0), 9.0 + rng.randf() * 4.0, 20, MeshKit.T_MARBLE, Color(0.35, 0.65, 0.9), 0.4)


func _outer_cavern(k: MeshKit, rng: RandomNumberGenerator, d: float, lite: bool, lava: bool) -> void:
	var rock := Color(0.34, 0.3, 0.38) if lava else Color(0.34, 0.36, 0.5)
	# dinding gua tinggi melingkar + stalaktit menggantung
	var n_w := 14 if lite else 24
	for i in n_w:
		var a := (float(i) + rng.randf() * 0.5) / n_w * TAU
		var dd := d * 0.78 + rng.randf_range(0.0, 14.0)
		var h := rng.randf_range(24.0, 46.0)
		var r := rng.randf_range(10.0, 17.0)
		var p := Vector3(cos(a) * dd, 0, sin(a) * dd)
		k.cylinder(p, r, r * 0.55, h, 8, MeshKit.T_COBBLE, _haze(rock, 0.25), false, -1, false, 0.9)
	var n_s := 14 if lite else 30
	for i in n_s:
		var a2 := rng.randf() * TAU
		var d2 := rng.randf_range(radius + 6.0, d * 0.75)
		var h2 := rng.randf_range(5.0, 12.0)
		k.cylinder(Vector3(cos(a2) * d2, 24.0 - h2, sin(a2) * d2), 0.15, rng.randf_range(1.0, 2.0), h2, 6, MeshKit.T_COBBLE, rock.darkened(0.15), false)
	# kristal besar menyala di luar arena
	var pal := [Color(1.0, 0.5, 0.2), Color(1.0, 0.35, 0.3)] if lava else [Color(0.4, 0.85, 1.0), Color(0.65, 0.55, 1.0), Color(1.0, 0.55, 0.85)]
	for i in (10 if lite else 22):
		var a3 := rng.randf() * TAU
		var d3 := rng.randf_range(radius + 5.0, d * 0.7)
		k.crystal(Vector3(cos(a3) * d3, 0, sin(a3) * d3), 0.6 + rng.randf() * 0.7, 2.0 + rng.randf() * 3.5, pal[rng.randi() % pal.size()], 0.85, 5, rng.randf_range(-12.0, 12.0))
	if lava:
		for i in (3 if lite else 6):
			var a4 := rng.randf() * TAU
			var d4 := radius + 12.0 + rng.randf() * 22.0
			k.disc(Vector3(cos(a4) * d4, 0.03, sin(a4) * d4), 4.0 + rng.randf() * 5.0, 18, MeshKit.T_COBBLE, MeshKit.glow(Color(1.0, 0.4, 0.12), 0.85), 0.5)


func _outer_temple(k: MeshKit, rng: RandomNumberGenerator, d: float, lite: bool) -> void:
	for i in (10 if lite else 18):
		var a := (float(i) + rng.randf() * 0.5) / (10 if lite else 18) * TAU
		var dd := d + rng.randf_range(-2.0, 18.0)
		var h := rng.randf_range(28.0, 54.0)
		var r := h * rng.randf_range(0.8, 1.1)
		_cone(k, Vector3(cos(a) * dd, 0, sin(a) * dd), r, h, _haze(Color(0.3, 0.3, 0.42), 0.45), MeshKit.T_PLASTER)
	for i in (3 if lite else 6):
		var a2 := (float(i) + rng.randf()) / (3 if lite else 6) * TAU
		var d2 := radius + 16.0 + rng.randf() * 22.0
		_pagoda(k, Vector3(cos(a2) * d2, 0, sin(a2) * d2), rng.randf_range(0.9, 1.7))
	# jalan lentera batu menuju gerbang
	for i in (8 if lite else 16):
		var z := radius * 0.9 + 4.0 + float(i) * 3.2
		for sx in [-1.0, 1.0]:
			k.cylinder(Vector3(sx * 4.2, 0, z), 0.35, 0.3, 1.5, 6, T_COBBLE, Color(0.5, 0.48, 0.55), true)
			k.box(Vector3(sx * 4.2, 1.7, z), Vector3(0.7, 0.6, 0.7), MeshKit.T_PLASTER, MeshKit.glow(Color(1.0, 0.7, 0.35), 0.8))
	for i in (14 if lite else 30):
		var a3 := rng.randf() * TAU
		var d3 := radius + 6.0 + rng.randf() * d * 0.55
		Decor.tree(k, null, Vector3(cos(a3) * d3, 0, sin(a3) * d3), 4.5 + rng.randf() * 3.0, Color(0.5, 0.3, 0.4), 2, true)


func _outer_void(k: MeshKit, rng: RandomNumberGenerator, d: float, lite: bool, rock: Color, glow: Color) -> void:
	# pulau-pulau melayang & menara pilar jauh
	for i in (10 if lite else 20):
		var a := rng.randf() * TAU
		var dd := rng.randf_range(radius + 14.0, d * 0.85)
		var y := rng.randf_range(2.0, 22.0)
		var r := rng.randf_range(5.0, 11.0)
		var p := Vector3(cos(a) * dd, y, sin(a) * dd)
		var ih := rng.randf_range(5.0, 9.0)
		k.cylinder(p - Vector3(0, ih, 0), r * 0.15, r, ih, 8, MeshKit.T_MARBLE, rock, true)       # alas runcing ke bawah
		k.crystal(p + Vector3(0, 0.1, 0), 0.5 + rng.randf() * 0.5, 2.5 + rng.randf() * 3.0, glow, 0.9, 5, 0.0)
	for i in (8 if lite else 16):
		var a2 := (float(i) + rng.randf() * 0.5) / (8 if lite else 16) * TAU
		var dd2 := d * 0.8 + rng.randf_range(0.0, 20.0)
		var h2 := rng.randf_range(30.0, 60.0)
		k.cylinder(Vector3(cos(a2) * dd2, 0, sin(a2) * dd2), 3.0, 2.2, h2, 8, MeshKit.T_MARBLE, _haze(rock.lightened(0.05), 0.35), true)
		k.crystal(Vector3(cos(a2) * dd2, h2, sin(a2) * dd2), 1.2, 4.0, glow, 0.9, 5, 0.0)
