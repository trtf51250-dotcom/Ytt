extends CanvasLayer
## Autoload "Flow": perpindahan scene dengan fade + layar "Memuat...", dan notifikasi singkat (toast).

const SCENE_TITLE := "res://scenes/title.tscn"
const SCENE_LOBBY := "res://scenes/lobby/lobby.tscn"
const SCENE_STAGE := "res://scenes/stages/stage.tscn"

const MIN_SHOW := 0.9                  # layar memuat tampil minimal sekian detik agar tidak berkedip
const TIPS := [
	"Tekan Dodge tepat sebelum serangan bos mengenai untuk menghindar.",
	"Ganti karakter party di tengah pertarungan untuk mengatur ritme serangan.",
	"Ultimate hanya bisa dipakai sekali per stage, simpan untuk saat genting.",
	"Ramuan bisa dibeli di Toko Ramuan Mira. Bawa cukup sebelum melawan bos.",
	"Pity gacha: bintang 5 dijamin dalam 50 tarikan.",
	"Game terasa berat? Turunkan Kualitas grafis di Pengaturan.",
	"Selesaikan misi harian untuk hadiah tambahan.",
	"Aksesori dan senjata bisa ditempa di Pandai Besi.",
]
## Aset berat yang dimuat di latar belakang (thread) selagi layar memuat tampil: bar kemajuan nyata & mengurangi patah saat scene mulai.
const PRELOAD := {
	"res://scenes/lobby/lobby.tscn": [
		"res://assets/textures/world_atlas.png", "res://assets/hero/hero.glb",
		"res://assets/sky/cloud_1.png", "res://assets/sky/cloud_2.png", "res://assets/sky/cloud_3.png",
		"res://assets/sky/cloud_noise.png", "res://assets/sky/sun_disc.png", "res://assets/sky/moon_disc.png",
	],
	"res://scenes/stages/stage.tscn": [
		"res://assets/hero/hero.glb", "res://assets/boss/cave_monster_rigged.glb", "res://assets/boss/wither_god_rigged.glb",
		"res://assets/fx/magic_outer.png", "res://assets/fx/magic_inner.png", "res://assets/fx/sigil_a.png",
		"res://assets/fx/sigil_b.png", "res://assets/fx/flare.png",
	],
}

var _fade: Control                   # LoadingScreen (di-fade dengan modulate)
var _ls: LoadingScreen
var _bar_target := 0.0
var _bar_shown := 0.0
var _busy := false
var _toast_box: PanelContainer
var _toast_label: Label
var _toast_tween: Tween
var _back_last := -10.0               # waktu (detik) Back terakhir yang tidak ditangani siapa pun
const BACK_EXIT_WINDOW := 2.0


func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	_ls = LoadingScreen.new()
	_fade = _ls
	_fade.modulate.a = 0.0
	add_child(_fade)
	set_process(false)

	_toast_box = PanelContainer.new()
	_toast_box.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_toast_box.position = Vector2(0, 86)
	_toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.08, 0.11, 0.24, 0.92)
	sb.border_color = Color(0.95, 0.76, 0.3)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(14)
	sb.content_margin_left = 22
	sb.content_margin_right = 22
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10
	_toast_box.add_theme_stylebox_override("panel", sb)
	_toast_label = Label.new()
	_toast_label.add_theme_font_size_override("font_size", 22)
	_toast_label.add_theme_color_override("font_color", Color(1, 1, 1))
	_toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_box.add_child(_toast_label)
	_toast_box.modulate.a = 0.0
	add_child(_toast_box)


func is_busy() -> bool:
	return _busy


## Tombol Back Android TIDAK menghasilkan tombol keyboard: hanya notifikasi. Diubah jadi aksi "menu_back" supaya panel,
## menu jeda, dan semua penangan Esc memakai satu jalur. (project.godot: quit_on_go_back=false, jadi app tidak langsung tertutup.)
func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		InputSetup.ensure()
		for pressed in [true, false]:
			var ev := InputEventAction.new()
			ev.action = &"menu_back"
			ev.pressed = pressed
			Input.parse_input_event(ev)


## Sampai sini hanya bila tak ada panel/menu jeda yang menangani Back: tekan dua kali dalam 2 detik untuk keluar.
func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventAction) or not event.is_action_pressed(&"menu_back"):
		return
	get_viewport().set_input_as_handled()
	if _busy:
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now - _back_last <= BACK_EXIT_WINDOW:
		GameState.save_game()
		get_tree().quit()
		return
	_back_last = now
	toast("Tekan Back sekali lagi untuk keluar")


## Bar kemajuan dibuat halus (mengejar target); animasi latar berjalan hanya selama layar aktif.
func _process(delta: float) -> void:
	_bar_shown = move_toward(_bar_shown, _bar_target, delta * 0.9)
	_ls.set_progress(_bar_shown)


## Pindah scene dengan layar memuat. Aset berat dimuat di thread (bar kemajuan), lalu scene diganti. Mengembalikan setelah scene baru dimuat.
func goto(path: String, text: String = "Memuat...") -> void:
	if _busy:
		return
	if GameState.banned and path != SCENE_TITLE:      # akun diblokir: hanya layar judul yang boleh dibuka
		path = SCENE_TITLE
	_busy = true
	_fade.mouse_filter = Control.MOUSE_FILTER_STOP
	_ls.set_status(text)
	_ls.set_tip(TIPS[randi() % TIPS.size()])
	_bar_target = 0.0
	_bar_shown = 0.0
	_ls.set_progress(0.0)
	_ls.set_active(true)
	set_process(true)
	var t := create_tween()
	t.tween_property(_fade, "modulate:a", 1.0, 0.25)
	await t.finished
	await get_tree().process_frame
	var t_start := Time.get_ticks_msec()
	# 1) muat scene + aset berat di thread
	var reqs: Array[String] = []
	if ResourceLoader.load_threaded_request(path) == OK:
		reqs.append(path)
	for p: String in PRELOAD.get(path, []):
		if ResourceLoader.exists(p) and ResourceLoader.load_threaded_request(p) == OK:
			reqs.append(p)
	while not reqs.is_empty():
		var finished := 0
		var total := 0.0
		for p in reqs:
			var pr: Array = []
			var st := ResourceLoader.load_threaded_get_status(p, pr)
			if st == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
				total += float(pr[0]) if pr.size() > 0 else 0.0
			else:
				finished += 1
				total += 1.0
		_bar_target = 0.8 * total / float(reqs.size())
		if finished == reqs.size() or Time.get_ticks_msec() - t_start > 12000:
			break
		await get_tree().process_frame
	var hold: Array = []                              # tahan referensi supaya aset tidak dibuang sebelum scene memakainya
	var packed: PackedScene = null
	for p in reqs:
		if ResourceLoader.load_threaded_get_status(p) == ResourceLoader.THREAD_LOAD_LOADED:
			var r = ResourceLoader.load_threaded_get(p)
			hold.append(r)
			if p == path and r is PackedScene:
				packed = r
	# 2) ganti scene
	_bar_target = 0.88
	await get_tree().process_frame
	await get_tree().process_frame
	if packed != null:
		get_tree().change_scene_to_packed(packed)
	else:
		get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	_bar_target = 1.0
	while Time.get_ticks_msec() - t_start < int(MIN_SHOW * 1000.0) or _bar_shown < 0.999:
		await get_tree().process_frame
	hold.clear()
	var t2 := create_tween()
	t2.tween_property(_fade, "modulate:a", 0.0, 0.3)
	await t2.finished
	set_process(false)
	_ls.set_active(false)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_busy = false


func go_lobby() -> void:
	goto(SCENE_LOBBY, "Kembali ke Aurelia...")


func start_stage(stage_id: String) -> void:
	GameState.current_stage_id = stage_id
	var sd := Data.stage(stage_id)
	goto(SCENE_STAGE, "Menuju %s..." % (sd.display_name if sd else "stage"))


## Notifikasi singkat di atas layar.
func toast(text: String, seconds: float = 2.0) -> void:
	_toast_label.text = text
	_toast_box.reset_size()
	_toast_box.position.x = (get_viewport().get_visible_rect().size.x - _toast_box.size.x) * 0.5
	if _toast_tween:
		_toast_tween.kill()
	_toast_box.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(seconds)
	_toast_tween.tween_property(_toast_box, "modulate:a", 0.0, 0.4)
